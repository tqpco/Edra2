# گزارش بررسی و اصلاح EDRA — نسخه v32 (روی v31)

> تاریخ: ۴ اکتبر ۲۰۲۶ — دامنه: فرانت‌اند (Next.js)، بک‌اند (Django)، استقرار (Docker/Nginx)

## ۰) خلاصه‌ی صادقانه

| موضوع | وضعیت |
|---|---|
| صفحات ایجاد/ویرایش ناقص (مشتری، کارشناس) | ✅ ساخته شد، با کیت فرم واحد |
| باگ‌های واقعی پیدا و اصلاح‌شده | **۲۶ مورد** (جدول بخش ۳) |
| ۲۰۰ کاربر همزمان | ⚠️ گلوگاه‌ها اصلاح شد، ولی **تست بار اجرا نشده** → ثابت نشده |
| اجرای تست‌ها / `next build` / `nginx -t` / Docker | ❌ **اجرا نشد** (در محیط من Django، node_modules و Docker نیست) |
| بررسی «خط به خط» | ⚠️ **همه‌ی ۵۵٬۵۰۰ خط با ابزار پوشش داده شد؛ همه‌ی خطوط را نخواندم** (بخش ۱) |

نتیجه‌ی اصلی: پروژه با تغییرات این نسخه به «عملیاتی» نزدیک‌تر شد، ولی تا اجرای
مراحل بخش ۶ نمی‌توانم عملیاتی‌بودن آن را تأیید کنم.

## ۱) روش بررسی (و محدودیت‌هایش)

حجم کد برنامه: بک‌اند ۱۸۸ فایل / ≈۲۵٬۵۰۰ خط (+≈۴٬۵۰۰ خط تست)، فرانت ۱۹۴ فایل / ≈۳۰٬۰۰۰ خط، ۸۲ صفحه، ۴۹ ViewSet.

**الف) بررسی ماشینی روی ۱۰۰٪ فایل‌ها** (ابزارها را خودم نوشتم چون pyflakes/eslint در دسترس نبود):
1. نام‌های تعریف‌نشده و خطای class-body در همه‌ی فایل‌های پایتون (تحلیلگر AST؛ روی نمونه‌ی باگ‌دار صحت‌سنجی شد) → ۱ باگ واقعی
2. ۷۸۸ import محلی فرانت: وجود ماژول و export شدن هر نام → ۲ باگ واقعی
3. مرز `"use client"`/Server Component در ۱۶۱ فایل tsx → ۲ باگ واقعی
4. تطبیق ۱۷۹ فراخوانی API فرانت با ۱۸۲ route واقعی بک‌اند (از `urls.py` و `@action`ها، شامل HTTP method) → ۲ باگ واقعی
5. هر فیلد مدل (۵۱۴ فیلد) در migration ها حضور دارد → ۰ مشکل (روش heuristic)
6. الگوهای خطرناک: `eval/exec/pickle/raw SQL` → ۰؛ `except` بدون نوع → ۲ (فقط ویجت تاریخ)؛ ۲۱ نقطه‌ی `AllowAny` فهرست شد؛ ۷ مورد حساس‌تر (پرداخت، ثبت درخواست، قیمت‌گذاری) در context خوانده شد و بقیه (محتوای عمومی، تخفیف، callback) فقط در حد نام و محل بررسی شد
7. اسکن IDOR روی ۴۹ ViewSet → فقط داده‌ی مرجع عمومی بدون scope (عمدی)
8. اسکن N+1 در SerializerMethodField → ۲ مورد

**ب) خواندن دستی** (خط‌به‌خط، فقط مسیرهای پرخطر): `UserSerializer/UserViewSet`، `InspectionRequestSerializer.create`، `perform_create` ثبت درخواست، `OTPRequestView`، `initiate_payment` و `request_credit_deposit` (بخش ورودی)، `PaymentMethod*`، `CityMultiplierViewSet`، `pricing/views.py` (محاسبه‌ی مالیات)، `pricing/utils.py` (موتور قیمت)، `deepseek.py`، `settings.py` (بخش‌های امنیتی/throttle/DB)، `nginx.conf`، `docker-compose.yml`، `gunicorn.conf`، لایه‌ی BFF فرانت (`api-server`, `session`, `proxy`, `auth/*`, `download`) و ۶ صفحه‌ی admin.

**ج) خوانده نشده یا فقط سطحی:** منطق داخلی بیشتر ViewSetهای پشتیبانی/تیکت، سرویس‌های PDF و گزارش، ledger/credit (بیرون از ورودی‌ها)، WebSocket consumers، و اغلب کامپوننت‌های ویزارد. **این بخش‌ها «بدون مشکل» تأیید نشده‌اند.**

## ۲) صفحات ایجاد/ویرایش — استاندارد واحد

- `components/admin/form-kit.tsx`: `FormShell` (هدر، انصراف، بنر خطا، گرید ۲/۳، ذخیره)، `FormSection`، `Field`، `FieldRow`، `SwitchField`
- `hooks/use-resource-submit.ts`: ارسال، قفل ضددوبار‌کلیک، toast، redirect، خطای هر فیلد
- `lib/form-errors.ts`: پارس یکسان خطای DRF (`detail`/`error`/`non_field_errors`/خطای فیلد)
- صفحات جدید: `customers/new`, `customers/[id]/edit`, `experts/new`, `experts/[id]/edit` با فرم مشترک `user-form.tsx`
- لیست مشتری/کارشناس: دکمه‌ی «جدید» و «ویرایش»؛ شمارنده اکنون تعداد کل را نشان می‌دهد
- فرم‌های equipment و city-multipliers به پارس خطای واحد وصل شدند

**هنوز با الگوی خودشان:** FAQ، اعلانیه، تخفیف، چک‌لیست، تنظیمات تیکت (دیالوگی)، و pricing/requests/tickets (خطای اختصاصی). انتقال آن‌ها اجباری نیست ولی برای «استاندارد واحد ۱۰۰٪» باید انجام شود.

## ۳) باگ‌های پیدا و اصلاح‌شده

شدت: 🔴 بحرانی · 🟠 بالا · 🟡 متوسط · ⚪ پایین

| # | شدت | محل | مشکل | اصلاح |
|---|---|---|---|---|
| 1 | 🔴 | `.env.production.example` | یک `SECRET_KEY` ثابت (امضای JWT) در نمونه‌ی «production» و `.env` داخل zip؛ `DEBUG=True`؛ نبود `DJANGO_ENV=production`؛ `DEV_OTP_ENABLED=true` انتهای فایل مقدار false قبلی را override می‌کرد | قالب production واقعی با placeholder؛ فایل لوکال جدا (`.env.local.example`)؛ در `settings.py` کلید لو‌رفته با hash در حالت `DEBUG=False` بالا نمی‌آید |
| 2 | 🔴 | nginx.conf | `/api/auth`, `/api/proxy`, `/api/download` روت‌های **Next.js** بودند ولی به جنگو می‌رفتند → لاگین/داده در production ۴۰۴ | مسیرهای BFF به فرانت |
| 3 | 🔴 | BFF → Django | جنگو فقط IP کانتینر Next را می‌دید؛ throttle ها (`otp_request=5/h` و …) یک سطل مشترک برای کل سایت بود | فوروارد `X-Forwarded-For` در همه‌ی fetch های سرور + `NUM_PROXIES=1` |
| 4 | 🔴 | `step-5-scheduling.tsx` | import از `useAccurateNow` که وجود ندارد → خطای type/build ویزارد | حذف import مرده |
| 5 | 🔴 | `customer/invoices`, `customer/payments` | `onClick` تابعی در Server Component + `<a>` تو‌در‌تو داخل `<Link>` → خطای رندر/hydration | الگوی stretched-link؛ بدون onClick |
| 6 | 🟠 | UserSerializer | `phone`/`company_name`/`registration_number` هرگز ذخیره/نمایش نمی‌شدند؛ `full_name` خالی؛ شماره تکراری = ۵۰۰؛ ساخت کاربر/پروفایل غیراتمیک | بازنویسی با `source='profile.*'`، اعتبارسنجی، تراکنش |
| 7 | 🟠 | صفحه «روش‌های پرداخت» | POST/PUT/DELETE همه ۴۰۵ (ViewSet فقط‌خواندنی)؛ فیلد `code` در مدل نیست؛ `is_active` در هیچ جریان پرداختی چک نمی‌شد | ViewSet قابل‌ویرایش برای ادمین (بدون ساخت/حذف)، اعمال `is_active` در `initiate_payment` و `request_credit_deposit`، بازنویسی صفحه |
| 8 | 🟠 | `pricing/views.py` | `timezone` import نشده و `except: pass` آن را می‌بلعید → مالیات پیش‌نمایش همیشه ۱۰٪ (فاکتور: TaxRate/۹٪)؛ گرد‌کردن متفاوت | استفاده از `resolve_tax_rate_percent()` فاکتور + گرد‌کردن یکسان |
| 9 | 🟠 | `InspectionRequestSerializer.create` | مصرف کد تخفیف commit می‌شد و سپس سقف «۵ درخواست باز» چک می‌شد → هر تلاش ناموفق ظرفیت کد را می‌سوزاند | کل `create` در یک تراکنش |
| 10 | 🟠 | ثبت درخواست | `AllowAny`: هر درخواست ناشناس یک کاربر `guest_*` می‌ساخت و به **همه‌ی ادمین‌ها** اعلان/SMS می‌فرستاد | فقط کاربر واردشده |
| 11 | 🟠 | ثبت درخواست | اعلان SMS/ایمیل برای مشتری+تک‌تک ادمین‌ها **داخل** درخواست HTTP (timeout ۱۰ث) | تسک Celery + fallback sync |
| 12 | 🟠 | ASGI برای HTTP | view های sync زیر uvicorn هر worker یک درخواست همزمان (۵ worker = ۵) | HTTP روی gunicorn (۴×۸=۳۲)، WebSocket روی سرویس جدا `backend-ws` |
| 13 | 🟠 | لیست تیکت‌ها | ≈۶ کوئری اضافه برای هر ردیف (۵ FK + count) ≈۱۵۰ کوئری/صفحه | `select_related` + `annotate` |
| 14 | 🟠 | throttle | `otp_request=5/h` به‌ازای IP؛ در ایران CGNAT هزاران کاربر را پشت یک IP می‌گذارد | نرخ‌های واقع‌بینانه (env-configurable) + سقف ساعتی هر شماره + cooldown |
| 15 | 🟠 | compose | `ALLOWED_HOSTS` ثابت، `.env.production` را نادیده می‌گرفت → callback درگاه با Host=دامنه ۴۰۰؛ `env_file` با مستندات ناهماهنگ | interpolation + `BACKEND_ENV_FILE` |
| 16 | 🟡 | ویرایش شماره موبایل | OTP با `username==phone` کاربر را پیدا می‌کند؛ تغییر `phone` بدون username حساب تکراری می‌ساخت | هم‌گام‌سازی username + بررسی برخورد |
| 17 | 🟡 | `deepseek.py` | کارت ۱۶رقمی چسبیده و شبا redact نمی‌شدند (کارت جدا: ۴ رقم آخر لو می‌رفت) | الگوهای جدید + تست دستی |
| 18 | 🟡 | `lib/format.ts` | `formatNumber` در تست‌ها بود ولی وجود نداشت؛ `toLocaleString('fa-IR')` وابسته به ICU (خطر hydration)؛ مبلغ منفی «۰ تومان» | پیاده‌سازی قطعی؛ تست‌ها پاس می‌شوند |
| 19 | 🟡 | تجهیز/شهر غیرفعال | برای عموم نمایش داده می‌شد و قابل رزرو بود | فیلتر `is_active` + اعتبارسنجی |
| 20 | 🟡 | تاریخچه ضریب شهر | route نداشت؛ دکمه همیشه غیرفعال | ثبت در AuditLog + `history` |
| 21 | 🟡 | Postgres | `max_connections` پیش‌فرض ۱۰۰ | ۲۰۰؛ `CONN_HEALTH_CHECKS` |
| 22 | 🟡 | Redis | `PARSER_CLASS=HiredisParser` بدون پکیج hiredis | حذف |
| 23 | 🟡 | nginx | بدون keepalive/gzip/کش `_next/static`/rate-limit لبه | افزوده شد |
| 24 | ⚪ | فرم‌های ادمین | خطای واقعی DRF با پیام عمومی جایگزین می‌شد | `parseApiError` |
| 25 | ⚪ | `CityMultiplier.reorder` | N آپدیت بدون تراکنش | atomic |
| 26 | ⚪ | لاگ/ممیزی | IP همیشه IP کانتینر | `_client_ip` |

### نیازمند تصمیم شما (اصلاح نشد، فقط شفاف‌سازی شد)
- **`custom_formula` قیمت‌گذاری ذخیره می‌شود ولی در هیچ محاسبه‌ای استفاده نمی‌شود.** ادمین فرمول می‌نویسد و اثری ندارد. فعلاً هشدار در UI گذاشتم. یا باید پیاده شود (با evaluator امن) یا فیلد حذف شود.
- **`PriceComponentsView`/`preview` عمومی** نرخ پایه و نرخ تک‌تک پارامترها را برای هر کس فاش می‌کند. اگر ساختار قیمت محرمانه است محدودش کنید.
- مصرف کد تخفیف در **زمان ثبت درخواست** شمرده می‌شود نه پرداخت؛ کاربر می‌تواند با درخواست‌های پرداخت‌نشده (تا ۵ تا) ظرفیت کد را اشغال کند.
- `DEV_OTP_ENABLED` فقط در `production` ممنوع است، در `staging` مجاز است.

## ۴) اقدام‌های فوری برای شما (خارج از کد)

1. **`SECRET_KEY` را عوض کنید** (کلید قبلی منتشر شده و امضای JWT را تعیین می‌کند؛ هر توکنی با آن جعل‌شدنی است). همه‌ی نشست‌ها بعد از تغییر باطل می‌شوند.
2. رمز دیتابیس و هر کلید موجود در `.env` ریشه را هم عوض کنید.
3. `db.sqlite3`، `db.sqlite3.backup`، `.env` و `repomix-output.*` را در بسته‌ی تحویل/گیت نگذارید (در zip تحویلی من حذف شده‌اند).
4. `.env.production` را از قالب جدید بسازید و همه‌ی `REPLACE_*` را پر کنید.

## ۵) ظرفیت: ۲۰۰ کاربر همزمان (تحلیل، نه اندازه‌گیری)

- هر کاربر فعال ≈ یک درخواست در ۳–۶ ثانیه → ≈۴۰–۷۰ rps. ظرفیت جدید: ۳۲ درخواست همزمان؛ با میانگین ۵۰–۱۵۰ms ≈ ۲۰۰–۶۰۰ rps.
- اتصال DB ≈ ۳۲ (gunicorn) + ۲–۴ (uvicorn WS) + celery ≈ ۴۰–۵۰ از ۲۰۰.
- ۲۰۰ اتصال WebSocket برای uvicorn سبک است.
- ریسک‌های باقی‌مانده: حدود ۳۶ فراخوانی دیگر `send_notification` هنوز sync هستند؛ رندر سمت سرور Next.js (چند fetch ترتیبی در هر داشبورد)؛ تولید PDF اگر `PDF_GENERATION_ASYNC=false` باشد.
- **اجرای `loadtest/` الزامی است** (راهنما: `loadtest/README.md`).

## ۶) آنچه باید قبل از دیپلوی اجرا شود

```bash
# بک‌اند
cd backend/backend && pytest -q                      # شامل core/tests/test_v32_fixes.py (جدید، اجرا‌نشده)
python manage.py check --deploy
# فرانت
cd frontend/frontend && npm ci && npx tsc --noEmit && npm run lint && npm test && npm run build
# استقرار
nginx -t -c deploy/nginx.conf      # یا داخل کانتینر
docker compose --env-file backend/backend/.env.production config
docker compose --env-file backend/backend/.env.production up -d --build
# بار
locust -f loadtest/locustfile.py --host https://staging... --users 200 --spawn-rate 10 --run-time 10m --headless
```

اگر `tsc`/`pytest` خطا داد، آن را برایم بفرستید؛ ممکن است اصلاحات من خطای نوع/وابستگی داشته باشد که بدون اجرا قابل تشخیص نبود.

## ۷) فایل‌های تغییرکرده

**بک‌اند:** `core/serializers.py`، `core/views/{user_views,common_views,inspection_views,payment_views,credit_views}.py`، `core/tasks.py`، `core/middleware.py`، `core/services/deepseek.py`، `pricing/views.py`، `support/{views,serializers}.py`، `edra/settings.py`، `gunicorn.conf.py`، `.env.production.example`، `.env.local.example` (جدید)، `core/tests/test_v32_fixes.py` (جدید)

**فرانت:** `lib/{client-ip,form-errors}.ts` (جدید)، `lib/{api-server,session,format}.ts`، `hooks/use-resource-submit.ts` (جدید)، `components/admin/{form-kit,user-form}.tsx` (جدید)، `components/wizard/step-5-scheduling.tsx`، `app/api/{auth/*,proxy,download}/route.ts`، `app/dashboard/admin/{customers,experts}/{page,new,[id]/edit}`، `admin/payment-methods/page.tsx`، `admin/{city-multipliers,equipment,pricing}/*`، `customer/{invoices,payments}/page.tsx`

**زیرساخت:** `docker-compose.yml`، `deploy/nginx.conf`، `loadtest/` (جدید)

# گزارش EDRA v33 — بازبینی و بازنویسی سیستم اعلان‌ها

> **وضعیت راستی‌آزمایی (مهم):** در محیط ساخت این نسخه Django، Redis و `node_modules` در دسترس نبود.
> - ✅ **انجام‌شده:** کامپایل (syntax) کل بک‌اند + تست‌های جدید؛ بررسی TypeScript فایل‌های تغییرکرده (بدون خطای syntax؛ خطاهای نوع به‌خاطر نبودن پکیج‌ها قابل‌قضاوت نیست)؛ **۲۹ سناریو** روی منطق `notifications/services.py` با Django/مدل‌های stub (شماره‌ها، کانال‌ها، خودترمیمی قالب، مخفی‌ماندن کلید API، fail-closed، ایدمپوتنسی).
> - ❌ **اجرا نشده:** `pytest` (از جمله `test_v33_notifications.py`)، migration ها، WebSocket واقعی با Redis، ارسال واقعی SMS/ایمیل، بیلد Next.js.
> - دو چک در شبیه‌سازی ضعیف بودند (stub قالب‌ساز autoescape ندارد): «بدون html-escape در پیامک» فقط با تست واقعی Django (`test_sms_body_is_not_html_escaped`) اثبات می‌شود.
> - **ادعای تحلیلی بدون اجرا:** رد شدن ticket وب‌سوکت روی django-redis را از رفتار کتابخانه استنتاج کرده‌ام؛ اصلاح آن بی‌ضرر و صحیح‌تر است، ولی قبل از انتشار روی Redis واقعی بسنجید.

## ۱) ریشه‌ی «اعلان‌ها کار نمی‌کند»

| # | مشکل | اثر | اصلاح |
|---|------|-----|-------|
| 1 | `NotificationsConfig` بدون `ready()`؛ `notifications.signals` هیچ‌جا import نمی‌شد | اعلان لحظه‌ای هرگز به زنگوله نمی‌رسید | `apps.ready()` + push بعد از commit |
| 2 | `_consume_ticket` روی Redis کلید خام `GETDEL` می‌زد (django-redis کلید را prefix و مقدار را pickle می‌کند) | احراز WebSocket همه‌ی نقش‌ها شکست می‌خورد | فقط API کش Django + `delete()` اتمیک، اعتبارسنجی فرمت ticket |
| 3 | قالب‌ها فقط با دستور دستی seed می‌شدند؛ ۴ کد (`ticket_created`, `ticket_assigned`, `payment_refunded`, `request_reminder`) اصلاً seed نداشتند | `send_notification` بی‌صدا هیچ نمی‌کرد؛ اکشن ادمین «ارسال یادآوری» موفقیت جعلی می‌داد | `defaults.py` (۳۳ قالب) + migration `0004` + خودترمیمی در سرویس |
| 4 | کانال `both`: شماره موبایل به `send_mail` داده می‌شد | ایمیل خطا می‌داد، **پیامک هرگز ارسال نمی‌شد** | گیرنده‌ی جدا برای هر کانال |
| 5 | تسک `process_pending_notifications` پیامک را فقط `logger.info` می‌کرد و «sent» ثبت می‌کرد (و متن/OTP را لاگ می‌کرد) | همه‌ی اعلان‌های صف‌شده (تخفیف…) هرگز نمی‌رفتند | تسک از `deliver_log` مشترک استفاده می‌کند؛ قفل سطری؛ انقضای ۲۴ ساعته |
| 6 | اگر کاربر ایمیل/موبایل معتبر نداشت هیچ لاگی ساخته نمی‌شد | مشتری OTP برای قالب ایمیلی، مدیر/کارشناس (username غیرموبایل) هیچ اعلان داشبوردی نداشتند | اعلان درون‌برنامه‌ای **همیشه** ساخته می‌شود؛ کانال جدید `in_app` |
| 7 | پروکسی BFF `query string` را حذف می‌کرد | صفحه‌ی ۲ اعلان‌ها = صفحه‌ی ۱؛ همه‌ی فیلترها/صفحه‌بندی‌های کلاینتی | فوروارد `search` |
| 8 | هوک WebSocket: بدون reconnect، بدون heartbeat، زنگوله فقط از WS | با اولین قطع، زنگوله تا رفرش می‌مرد و «اعلانی ندارید» نشان می‌داد | reconnect نمایی با ticket تازه، ping، fallback REST، dedupe |
| 9 | کارشناس صفحه‌ی اعلان نداشت؛ مدیر فقط قالب/لاگ می‌دید | — | `NotificationInbox` مشترک + `/expert/notifications` و `/admin/inbox` + nav |
| 10 | تغییر وضعیت درخواست (شروع بازرسی، ارجاع، زمان‌بندی، اتمام) در بیشتر مسیرها بی‌اعلان | مشتری/کارشناس خبردار نمی‌شدند | سیگنال واحد `post_save` (همه‌ی مسیرها)، برچسب فارسی وضعیت |

## ۲) مشکلات امنیتی و تکرار (حین بازبینی)

- **نشت کد تخفیف:** هر `DiscountCode` جدید (حتی کد یک‌بارمصرف اختصاصی کمپین) به *همه‌ی مشتریان* اعلان می‌شد → فقط `is_public=True`. هشدار انقضا هم همین‌طور و فقط یک‌بار برای هر کاربر/کد.
- **نشت کلید API پیامک:** متن خطای HTTP شامل URL با کلید بود و با `fields='__all__'` به هر مشتری می‌رسید → سریالایزر محدود صندوق (`NotificationInboxSerializer`)، مخفی‌سازی کلید هنگام ثبت و هنگام خروجی ادمین.
- **ticket وب‌سوکت تیکت (IDOR):** هر کاربر با هر `ticket_id` داده‌ی تیکت دیگران را می‌گرفت → فقط مشتری/ارجاع‌شده/پشتیبان.
- **`TicketConsumer` اصلاً کار نمی‌کرد:** `is_support_or_admin` از `core.permissions` import می‌شد ولی وجود نداشت (ImportError در connect). اضافه شد.
- **تغییر وضعیت تیکت همیشه ۴۰۰ می‌داد** (ماشین حالت با نام انگلیسی، وضعیت‌ها فارسی و FK). مستقیماً FK ست می‌شود + اعلان به مشتری.
- **پاسخ پشتیبانی به مشتری اعلام نمی‌شد** → `ticket_reply` / `ticket_customer_reply` / `ticket_assigned`.
- **پیامک/اعلان تکراری:** `payment_successful` (سیگنال + view)، رد فیش (قالب + `send_sms` دستی)، `ticket_created` (apply_rules و webhook دوبار)، اعلان state machine + سیگنال.
- `payment_failed` تعریف شده بود ولی ارسال نمی‌شد → در callback ناموفق/لغو (فقط اولین بار).
- اعلان پیامک داخل تراکنش مالی قبل از commit (reject_payment) → بعد از commit.
- **تسک ۷۲ ساعته:** `from ..services.credit_service` (relative import خارج از پکیج) خطا می‌داد؛ اعتبار رزروشده هرگز آزاد نمی‌شد → `.services`.
- `retry_failed_notifications` بدون context دوباره می‌ساخت و لاگ اصلی همیشه failed می‌ماند → همان لاگ در جا ارسال می‌شود.
- حذف قالب دارای لاگ (PROTECT) → ۵۰۰؛ حالا ۴۰۹ با پیام فارسی.
- `invoice_pdf_failed_admin` متغیر `invoice_id` را می‌خواست ولی ارسال نمی‌شد.
- مدیران در جاهای مختلف با تعریف‌های متفاوت (`is_staff` / `Q(...Admin)`) → `get_admin_users()` واحد.

## ۳) سازگاری و مهاجرت

- `migrations 0003` (فقط choices کانال) و `0004` (seed idempotent؛ قالب‌های ویرایش‌شده‌ی ادمین دست نمی‌خورند): `python manage.py migrate`.
- قالب‌های موجود در دیتابیس شما **بازنویسی نمی‌شوند**؛ بنابراین قالب `status_changed` قدیمی همان متن را نگه می‌دارد، ولی `new_status` حالا برچسب فارسی است.
- payload WebSocket هر دو کلید `title/message` و `subject/content` را دارد (تست قدیمی `test_websocket` + فرانت).
- توسعه‌ی محلی: `backend-ws` روی پورت `8001` منتشر شد و `.env.local.example` اصلاح شد (`FRONTEND_PUBLIC_WS_URL=ws://localhost:8001`)؛ مقدار قبلی `ws://backend:8000` از مرورگر قابل‌دسترس نبود.

## ۴) فایل‌های تغییرکرده

بک‌اند: `notifications/{services,signals,apps,tasks,consumers,serializers,api_views,models,defaults(new),payloads(new)}.py`، migrations 0003/0004، `edra/ws_auth.py`، `core/{signals,tasks,events,state_machine,permissions,urls}.py`، `core/views/{notification,credit,payment}_views.py`، `core/services/invoice_service.py`، `core/admin/request.py`، `discounts/tasks.py`، `support/{views,consumers}.py`، دو management command، تست `test_v33_notifications.py`.
فرانت: `hooks/use-notification-socket.ts`، `components/shared/{notification-bell,notification-inbox(new)}.tsx`، پروکسی، صفحه‌های `customer|expert/notifications` و `admin/inbox`، `nav-config.ts`، صفحه‌ی لاگ ادمین و فرم قالب.
زیرساخت: `docker-compose.yml`، `.env.local.example`، `DEPLOYMENT.md`.

## ۵) هنوز انجام نشده / توصیه‌ها

1. **اجرای واقعی تست‌ها** (`pytest`) و یک بار تست دستی روی Docker با Redis: ورود → زنگوله وصل شود → ثبت درخواست → اعلان لحظه‌ای.
2. ارسال SMS/ایمیل هنوز همزمان داخل درخواست است (timeout ۱۰ ثانیه). برای ۲۰۰ کاربر همزمان بهتر است `send_notification` فقط لاگ بسازد و ارسال به Celery برود (نیازمند broker واقعی).
3. در `docker-compose.yml` سرویس‌های backend/ws/celery منتظر پایان `migrate` نمی‌مانند (depends_on کامنت است) — تغییر ندادم چون بدون اجرا قابل‌تست نبود.
4. رویداد `status_changed` تیکت و درخواست نام مشترک دارند و `AuditLog` با شناسه‌ی هر دو پر می‌شود.
5. برای افزودن SMS الگو-محور (Verify/Lookup کاوه‌نگار) برای OTP، در صورت نیاز به خط اختصاصی `SMS_SENDER` را تنظیم کنید (در v33 به درخواست اضافه شد).

# گزارش EDRA v36 — بازرسی کامل بک‌اند

> مبنا: نسخه‌ی v35 (که خودش شامل اصلاحات بخش مالی بود). این گزارش فقط تغییرات v36 را شرح می‌دهد.

## 🆕 الحاقیه‌ی v36.1 (کشف‌شده هنگام تهیه‌ی گزارش معماری)

**آدرس بازگشت از درگاه (Callback) در Production اشتباه ساخته می‌شد.** `initiate_payment` و افزایش اعتبار آنلاین آدرس را با `request.build_absolute_uri(...)` می‌ساختند؛ ولی درخواست از BFF فرانت (Next.js) با Host داخلی `backend:8000` می‌رسد، پس آدرس بازگشت `http://backend:8000/api/core/payment/callback/` می‌شد (برای مرورگر مشتری غیرقابل دسترس و برای زرین‌پال نامعتبر). تنظیم `ZARINPAL_CALLBACK_URL`/`SITE_URL` (که `.env.example` می‌گوید منبع آدرس است) هرگز استفاده نمی‌شد. اکنون اگر `SITE_URL` یا `ZARINPAL_CALLBACK_URL` در محیط تنظیم باشد همان استفاده می‌شود (`_payment_callback_url` در `payment_views.py`)؛ در توسعه‌ی محلی رفتار قبلی حفظ شد. **در production حتماً `SITE_URL=https://دامنه‌ی-شما` را تنظیم کنید.** (اصلاح فقط خوانده/کامپایل شده؛ با درگاه واقعی/sandbox امتحان نشده.)

---

## ⚠️ سطح راستی‌آزمایی (صادقانه)

در این محیط Django نصب نیست و شبکه بسته است؛ پس **هیچ تست Django/pytest اجرا نشد**. به‌جای آن:

| روش | نتیجه |
|---|---|
| `compileall` روی کل بک‌اند | ✅ بدون خطا |
| تحلیل‌گر نام‌های تعریف‌نشده (با `symtable`، آگاه از scope) روی همه‌ی ماژول‌ها | ✅ ۰ خطای واقعی |
| تطبیق خودکار فیلدهای همه‌ی `filter/exclude/values/order_by/select_related/Q/F/Sum` با مدل‌ها | ✅ ۰ خطای واقعی |
| تطبیق فیلدهای ۶۲ مدل با migrations (از جمله migration جدید ۰۰۰۵) | ✅ هم‌خوان |
| تطبیق `list_display/readonly_fields/...` همه‌ی adminها با مدل‌ها | ✅ ۰ خطای واقعی |
| تطبیق importهای شخص‌ثالث با `requirements.txt` | ✅ |
| تعریف‌های تکراری متد/کلاس، پیش‌فرض mutable، `except:` خالی، `default=now()` | ✅ ۰ مورد |
| تمام `select_for_update` ها داخل تراکنش‌اند | ✅ |
| **اجرای واقعی** (با stub): `params_validation`، `validators` (magic bytes)، پارس GPS، کلاس زرین‌پال، ماه جلالی، `openpyxl` | ✅ اجرا شد |
| بقیه (view ها، قفل‌های دیتابیس، سیگنال‌ها، ORM، permission ها) | ⚠️ فقط خواندن و استدلال |

پیش از دیپلوی حتماً:
```
cd backend/backend
python manage.py migrate            # migration جدید core/0005
python manage.py check
pytest core/tests -x                # شامل test_v35_finance و test_v36_backend (اجرا‌نشده)
```

## پوشش بازرسی

**خط‌به‌خط خوانده شد:** settings (+production)، urls، middleware، permissions، security، exceptions، pagination، validators، search/filters، authentication، common/user/profile/audit/notification/dashboard/payment/credit/discount/inspection/pdf viewها، بخش اصلی report_views، expert/views، همه‌ی services (payment، credit، discount، invoice، ledger، report)، tasks، signals، serializers (اصلی)، models (finance، request، equipment، بخش‌هایی از user/checklist)، inspections/views (گزارش‌ها)، support (views، serializers، tasks، consumers)، notifications (services، tasks، consumers)، discounts (views، signals، tasks)، public، pricing (views، serializers، utils، بخشی از models)، celery، utils/*، events.

**فقط با ابزار ایستا (خط‌به‌خط خوانده نشد):** core/admin/{checklist،logs،menu،location،settings}، pricing/admin، inspections (serializers/models/admin و viewهای قالب چک‌لیست)، support/{models،admin،signals}، notifications/{views،serializers،signals،admin}، discounts/{models،admin}، core/models/{logs،menu،settings،location،dashboard}، management commands، scripts، deepseek.py، ntp_views، و `edra_jalalidate` (کتابخانه‌ی داخلی ۱٬۷۰۰ خطی؛ فقط API آن اجرا و تست شد).

---

## 🔴 بحرانی

1. **دور زدن قیمت با params** — `params` درخواست هیچ اعتبارسنجی نداشت: عدد منفی (`tonnage=-50`) یا حذف پارامتر اجباری قیمت را ارزان می‌کرد، `NaN/Infinity` خطای ۵۰۰ می‌داد و کلید رزروشده‌ی `is_deposit` قابل تزریق بود. ماژول جدید `core/params_validation.py` (سمت سرور، مرجع واحد).
2. **ویرایش قیمت‌ساز بعد از ثبت** — مشتری (با مجوز guardian) تا قبل از پرداخت می‌توانست `equipment_type/params/city/install_state/service_type` را PATCH کند در حالی که قیمت دوباره محاسبه نمی‌شد. برای غیرادمین قفل شد.
3. **شهر نامعتبر = هزینه‌ی شهر صفر** — فقط preview شهر را چک می‌کرد، نه ثبت.
4. **فیلدهای داخلی قابل‌نوشتن توسط مشتری** — `assigned_expert` (حتی مجوز guardian به آن کاربر داده می‌شد)، `request_number`، `project`، `price_breakdown`.
5. **مشتری/کارشناس می‌توانستند `DELETE` درخواست بزنند** (مجوز مالکیت برای همه‌ی متدها `True` بود). حالا مالکیت فقط خواندن؛ ویرایش فقط مالک با مجوز change؛ حذف فقط ادمین. حذف درخواست دارای پرداخت (PROTECT) ۵۰۰ نمی‌دهد.
6. **ابطال refresh token هرگز کار نمی‌کرد** — `token.blacklistedtoken_id` وجود ندارد؛ `AttributeError` قورت داده می‌شد و بعد از تغییر رمز/غیرفعال‌سازی هیچ توکنی باطل نمی‌شد.
7. **`DEFAULT_FILE_STORAGE` در Django ≥ 5.1 حذف شده** — با تنظیم S3 هم فایل‌ها (فیش/فاکتور/گزارش) روی دیسک کانتینر می‌ماندند. با `STORAGES` اصلاح شد.
8. **تعلیق/انقضای حساب هیچ‌جا اعمال نمی‌شد** (`is_suspended` فقط ذخیره می‌شد). کلاس `core/authentication.EdraJWTAuthentication` (کش ۶۰ثانیه‌ای) + ورود OTP + مسیرهای دستی JWT (PDF و media).
9. **ادمین `User` در Django admin از `UserAdmin` ارث نمی‌برد** — رمزِ واردشده بدون هش (plaintext) ذخیره می‌شد و آن حساب هرگز لاگین نمی‌کرد.
10. **`UserProfile.phone` یکتا + مقدار پیش‌فرض خالی** — دومین کاربر بدون شماره (ادمین/کارشناس ساخته‌شده از پنل) `IntegrityError/۵۰۰` می‌گرفت. migration `0005` یکتایی را فقط برای شماره‌ی «غیرخالی» می‌کند.

## 🟠 مهم

11. تزریق فرمول در اکسل (`=HYPERLINK(...)` در نام/پیام خطا/مسیر) — سلول‌ها متن می‌شوند.
12. `ChangePasswordView`/`ExpertChangePasswordView`: throttle بدون `throttle_classes` عملاً غیرفعال بود.
13. پشتیبانی: مشتری می‌توانست `status/priority/sla/is_pinned/due_date` تیکت خودش را PATCH کند؛ تیکت خودش را حذف کند؛ `sla/due_date` را هنگام ساخت تعیین کند؛ پیوست «کامنت داخلی» و `activity_logs` داخلی در جزئیات تیکت به او می‌رسید؛ «پاسخ‌های آماده»‌ی داخلی را می‌خواند؛ `is_internal=false` در فرم multipart «داخلی» ثبت می‌شد (`bool('false')`)؛ با پیوست نامعتبر، کامنت/تیکت ساخته می‌شد و ۴۰۰ برمی‌گشت (تکراری با تلاش مجدد).
14. فرم تیکت مشتری لیست دسته/اولویت/دپارتمان را می‌خواند ولی endpoint ها فقط ادمین بودند (۴۰۳) — خواندن برای کاربر واردشده (فقط فعال‌ها).
15. KnowledgeBase: «مفید بود؟» برای غیرادمین همیشه ۴۰۳ بود؛ شمارنده‌ها read-modify-write (افت شمارش) → `F()`.
16. SLA: تسک هر ۳۰ دقیقه سطح ارتقا را +۱ و برای همه‌ی ادمین‌ها اعلان می‌ساخت (۴۸ ارتقا/روز برای یک تیکت). حالا سطح از «تعداد دوره‌ی SLA» محاسبه و حداکثر ۳ است.
17. آمار تیکت: `ExtractHour` فقط مولفه‌ی ساعت (۰–۲۳) بود نه کل ساعت‌ها (۵۱ ساعت → ۳).
18. قطعی Celery/Redis: `.delay()` داخل signal پرداخت، تسویه (و پول گرفته‌شده) را rollback و ۵۰۰ می‌کرد؛ حالا بعد از commit و بدون پرتاب خطا. webhook تیکت، retry PDF و اکشن‌های تخفیف هم ایمن شدند.
19. کدهای کمپین (وفاداری) به کاربر هدف وابسته نبودند — هر کسی با کد می‌توانست مصرف کند؛ `used_at` هرگز پر نمی‌شد؛ کمپین‌ها «افزایش اعتبار» را خرید حساب می‌کردند.
20. جستجوی `?search=` در لیست درخواست‌ها همه‌ی فیلترها (status/city/تاریخ/ترتیب) را دور می‌زد و فقط «کلمه‌ی کامل» پیدا می‌کرد؛ `request_number` جستجوپذیر نبود.
21. dashboard مشتری: درخواست‌های موقت «واریز اعتبار» در شمارنده‌ها و «اخیرها» می‌آمدند؛ وضعیت‌های assigned/rescheduled «فعال» نبودند.
22. `DiscountCode` : جستجوی کد حساس به حروف/فاصله (کد کمپین حروف بزرگ است)؛ اعتبارسنجی مقدار در مدل (فرم ادمین).
23. تنظیمات: `sslmode=require` برای هر محیط غیر dev (Postgres داخلی docker را می‌شکست) → `DB_SSLMODE`؛ تنظیمات production گزینه‌های DB/Redis (timeout، health-check) را حذف می‌کرد؛ guard‌ی `DEV_OTP_ENABLED` فقط به `DJANGO_ENV` وابسته بود؛ آدرس broker (با رمز) در لاگ چاپ می‌شد.
24. media: `AuthenticationFailed` ۵۰۰ می‌داد؛ کارکنان پشتیبانی پیوست تیکت را نمی‌دیدند؛ پیوست کامنت داخلی برای مشتری باز بود.

## 🟡 سایر
- GPS: `NaN/Infinity/خارج بازه` ثبت کل چک‌لیست را ۵۰۰ می‌کرد.
- فشرده‌سازی تصویر: حالت‌های I;16/1 می‌شکستند؛ هر `save()` بعدی عکس را دوباره فشرده و فایل قبلی را یتیم می‌کرد.
- validators: `.doc/.xls` مجاز بودند ولی magic آن‌ها شناسایی نمی‌شد (همیشه رد)؛ `.zip/.docx/.xlsx` بدون تطبیق نوع.
- `PricingRuleSerializer`: هر PATCH ناقص رد می‌شد؛ نرخ پارامتر منفی/پارامتر تجهیز دیگر مجاز بود؛ لاگ تغییر قیمت دوبار ثبت می‌شد.
- schema ویزارد پارامترهای «غیرفعال» را هم نشان می‌داد؛ preview های عمومی قیمت params را پاک‌سازی نمی‌کردند.
- پروفایل: ورودی بدون اعتبارسنجی (طول/ایمیل/شماره تکراری → ۵۰۰)؛ `available_balance` اضافه شد.
- تسک‌ها: یادآوری/لغو برای «درخواست»های موقت واریز؛ پیام خطای خام PDF برای مشتری.
- `ContactMessage` بدون سقف طول (ناشناس)؛ مسیر فیش با `random` به‌جای توکن امن؛ نسخه‌ی امضاشده‌ی گزارش در دانلود مشتری.

---

## ⛔ تصمیم/اقدام با شما
1. **اجرای `migrate`** (migration `core/0005`) و در صورت نیاز تنظیم `DB_SSLMODE`.
2. **`PricingRule` نبودن → قیمت پیش‌فرض ۱٬۰۰۰٬۰۰۰ تومان بی‌صدا** (تست `test_v32_fixes` عمداً آن را حفظ می‌کند). پیشنهاد: ثبت درخواست بدون قانون قیمت خطا بدهد.
3. `send_to_selected_users` در ادمین تخفیف هنوز نیمه‌کاره است (پیام «صفحه‌ی واسط بسازید»).
4. پیام «پیام تماس جدید» به ادمین ارسال نمی‌شود (فقط لاگ).
5. عودت آنلاین زرین‌پال در Production همچنان نیازمند API رسمی (توکن/`session_id`) است (از v35).
6. Reconciliation پرداخت‌های آنلاین `pending` و تاریخچه‌ی authority (از v35).
7. اگر کاربری با `is_staff=False` در گروه `Support` باشد، به endpoint های `IsAdminUserOrGroup` دسترسی ندارد (طراحی فعلی؛ تغییر ندادم).

## فایل‌های جدید/تغییریافته
جدید: `core/params_validation.py`، `core/authentication.py`، `core/migrations/0005_userprofile_phone_conditional_unique.py`، `core/tests/test_v36_backend.py`.
تغییر: `edra/{settings,settings_production,urls}.py`، `core/{permissions,security,middleware,serializers,signals,tasks,search,validators}.py`، `core/models/{request,user}.py`، `core/admin/{request,user}.py`، `core/services/{discount_service,report_service}.py`، `core/utils/image_utils.py`، `core/views/{common,credit,dashboard,discount,inspection,payment,pdf,profile,report}_views.py`، `core/expert/views.py`، `discounts/{signals,tasks,views}.py`، `pricing/{views,serializers}.py`، `public/serializers.py`، `support/{views,serializers,tasks}.py`.

# core/admin/__init__.py
# -*- coding: utf-8 -*-

from .user import CustomUserAdmin, OTPCodeAdmin, GroupAdmin
from .request import InspectionRequestAdmin, DiscountCodeAdmin
from .finance import (
    PaymentAdmin, InvoiceAdmin, UserCreditAdmin, CreditTransactionAdmin,
    PaymentMethodAdmin, RefundAdmin, TaxRateAdmin
)
from .logs import AuditLogAdmin, ErrorLogAdmin, SequenceCounterAdmin
from .checklist import (
    ChecklistCategoryAdmin,
    ChecklistTemplateAdmin,
    ChecklistItemAdmin,
    InspectionReportAdmin,
    ReportVerificationAdmin,
    ChecklistPhotoAdmin,
)
from .location import CityMultiplierAdmin, OrganizationAdmin, ProjectAdmin
from .equipment import EquipmentTypeAdmin
from .settings import SystemSettingAdmin
from .dashboard import DashboardLayoutAdmin
from .menu import MenuAdmin, MenuItemAdmin
# core/admin/checklist.py
# -*- coding: utf-8 -*-

import json

from django.contrib import admin, messages
from django.urls import path, reverse
from django.shortcuts import redirect, render
from django.http import JsonResponse
from django.db import transaction
from django.db import models

from ..models import (
    ChecklistTemplate, ChecklistItem, ChecklistCategory,
    InspectionReport, ChecklistPhoto, ReportVerification,
)

from edra_jalalidate.jalali_widgets import EdraJalaliAdminMixin


class ChecklistItemInline(admin.TabularInline):
    model = ChecklistItem
    extra = 0
    fields = ('order_handle', 'title', 'category', 'order', 'requires_photo', 'requires_note', 'is_critical', 'is_active')
    readonly_fields = ('order_handle',)
    
    def order_handle(self, obj):
        return '⠿'
    order_handle.short_description = 'ترتیب'
    order_handle.admin_order_field = 'order'

    class Media:
        css = {
            'all': ('admin/css/checklist_admin.css',)
        }
        js = (
            'admin/js/jquery-ui.min.js',
            'admin/js/checklist_inline.js',
        )


@admin.register(ChecklistTemplate)
class ChecklistTemplateAdmin(EdraJalaliAdminMixin, admin.ModelAdmin):
    change_list_template = 'admin/checklist/change_list.html'
    change_form_template = 'admin/checklist/change_form.html'
    
    # ✅ اصلاح: استفاده از متدهای جلالی برای نمایش تاریخ
    list_display = (
        'name', 'equipment_type', 'version', 'is_active', 'items_count',
        'jalali_created_at', 'jalali_updated_at'
    )
    list_filter = ('is_active', 'equipment_type')
    search_fields = ('name', 'description', 'equipment_type__name_fa')
    readonly_fields = ('created_at', 'updated_at')
    inlines = [ChecklistItemInline]

    def get_queryset(self, request):
        qs = super().get_queryset(request)
        return qs.prefetch_related('items')

    def items_count(self, obj):
        return obj.items.filter(is_active=True).count()
    items_count.short_description = 'تعداد آیتم‌ها'

    def get_urls(self):
        urls = super().get_urls()
        custom_urls = [
            path('get-items/', self.get_items, name='core_checklisttemplate_get_items'),
            path('reorder-items/', self.reorder_items, name='core_checklisttemplate_reorder_items'),
            path('add-item/', self.add_item, name='core_checklisttemplate_add_item'),
            path('delete-item/<int:item_id>/', self.delete_item, name='core_checklisttemplate_delete_item'),
            path('import-excel/', self.import_excel, name='core_checklisttemplate_import_excel'),
            path('export-template/', self.export_template, name='core_checklisttemplate_export_template'),
        ]
        return custom_urls + urls

    def get_items(self, request):
        template_id = request.GET.get('template_id')
        category_id = request.GET.get('category_id')
        search = request.GET.get('search', '').strip()

        if not template_id:
            return JsonResponse({'error': 'شناسه قالب الزامی است.'}, status=400)

        try:
            template = ChecklistTemplate.objects.get(pk=template_id)
        except ChecklistTemplate.DoesNotExist:
            return JsonResponse({'error': 'قالب یافت نشد.'}, status=404)

        items = template.items.filter(is_active=True).select_related('category')
        if category_id:
            items = items.filter(category_id=category_id)
        if search:
            items = items.filter(title__icontains=search)

        data = []
        for item in items.order_by('category__order', 'order'):
            data.append({
                'id': item.id,
                'title': item.title,
                'description': item.description,
                'category': item.category.name if item.category else None,
                'category_color': item.category.color if item.category else '#64748b',
                'requires_photo': item.requires_photo,
                'requires_note': item.requires_note,
                'is_critical': item.is_critical,
                'edit_url': reverse('admin:core_checklistitem_change', args=[item.id]),
            })

        return JsonResponse({'items': data, 'total': len(data)})

    @transaction.atomic
    def reorder_items(self, request):
        if request.method != 'POST':
            return JsonResponse({'error': 'روش مجاز نیست.'}, status=405)

        try:
            data = json.loads(request.body)
        except json.JSONDecodeError:
            return JsonResponse({'error': 'داده‌های JSON نامعتبر است.'}, status=400)

        ids = data.get('ids')
        template_id = data.get('template_id')

        if not ids or not template_id:
            return JsonResponse({'error': 'اطلاعات ناقص است.'}, status=400)

        try:
            template = ChecklistTemplate.objects.get(pk=template_id)
        except ChecklistTemplate.DoesNotExist:
            return JsonResponse({'error': 'قالب یافت نشد.'}, status=404)

        for idx, item_id in enumerate(ids):
            ChecklistItem.objects.filter(pk=item_id, checklist_template=template).update(order=idx)

        return JsonResponse({'success': True, 'message': 'ترتیب با موفقیت به‌روزرسانی شد.'})

    @transaction.atomic
    def add_item(self, request):
        if request.method != 'POST':
            return JsonResponse({'error': 'روش مجاز نیست.'}, status=405)

        template_id = request.POST.get('template_id')
        title = request.POST.get('title', '').strip()
        category_id = request.POST.get('category')
        new_category = request.POST.get('new_category', '').strip()
        description = request.POST.get('description', '').strip()
        requires_photo = request.POST.get('requires_photo') == 'on'
        requires_note = request.POST.get('requires_note') == 'on'
        is_critical = request.POST.get('is_critical') == 'on'

        if not template_id or not title:
            return JsonResponse({'error': 'عنوان و شناسه قالب الزامی است.'}, status=400)

        try:
            template = ChecklistTemplate.objects.get(pk=template_id)
        except ChecklistTemplate.DoesNotExist:
            return JsonResponse({'error': 'قالب یافت نشد.'}, status=404)

        if new_category:
            category, _ = ChecklistCategory.objects.get_or_create(
                name=new_category,
                defaults={'is_active': True}
            )
        elif category_id:
            try:
                category = ChecklistCategory.objects.get(pk=category_id)
            except ChecklistCategory.DoesNotExist:
                category = None
        else:
            category = None

        last_order = template.items.filter(is_active=True).aggregate(
            max_order=models.Max('order')
        )['max_order'] or 0
        order = last_order + 1

        item = ChecklistItem.objects.create(
            checklist_template=template,
            title=title,
            description=description,
            category=category,
            order=order,
            requires_photo=requires_photo,
            requires_note=requires_note,
            is_critical=is_critical,
            is_active=True,
        )

        return JsonResponse({
            'success': True,
            'message': f'آیتم "{title}" با موفقیت افزوده شد.',
            'item_id': item.id,
        })

    @transaction.atomic
    def delete_item(self, request, item_id):
        if request.method != 'POST':
            return JsonResponse({'error': 'روش مجاز نیست.'}, status=405)

        try:
            item = ChecklistItem.objects.get(pk=item_id)
            title = item.title
            item.is_active = False
            item.save(update_fields=['is_active'])
            return JsonResponse({'success': True, 'message': f'آیتم "{title}" با موفقیت حذف شد.'})
        except ChecklistItem.DoesNotExist:
            return JsonResponse({'error': 'آیتم یافت نشد.'}, status=404)

    def import_excel(self, request):
        from ..models import ChecklistCategory

        selected_template_id = request.GET.get('template_id')
        template = None
        if selected_template_id:
            try:
                template = ChecklistTemplate.objects.get(pk=selected_template_id)
            except ChecklistTemplate.DoesNotExist:
                pass

        templates = ChecklistTemplate.objects.filter(is_active=True).order_by('name', 'version')
        categories = ChecklistCategory.objects.filter(is_active=True).order_by('order', 'name')

        if request.method == 'POST':
            uploaded_file = request.FILES.get('file')
            if not uploaded_file:
                messages.error(request, 'لطفاً یک فایل اکسل انتخاب کنید.')
                return redirect('admin:core_checklisttemplate_import_excel')

            if not uploaded_file.name.endswith(('.xlsx', '.xls')):
                messages.error(request, 'فایل باید با پسوند .xlsx یا .xls باشد.')
                return redirect('admin:core_checklisttemplate_import_excel')

            template_id = request.POST.get('checklist_template')
            if not template_id:
                messages.error(request, 'لطفاً یک قالب انتخاب کنید.')
                return redirect('admin:core_checklisttemplate_import_excel')

            try:
                template = ChecklistTemplate.objects.get(pk=template_id)
            except ChecklistTemplate.DoesNotExist:
                messages.error(request, 'قالب انتخاب‌شده معتبر نیست.')
                return redirect('admin:core_checklisttemplate_import_excel')

            try:
                import openpyxl
                wb = openpyxl.load_workbook(uploaded_file, data_only=True)
                ws = wb.active
                rows = list(ws.iter_rows(values_only=True))
                if len(rows) < 2:
                    messages.error(request, 'فایل حداقل باید یک ردیف هدر و یک ردیف داده داشته باشد.')
                    return redirect('admin:core_checklisttemplate_import_excel')

                headers = [str(cell).strip() if cell else '' for cell in rows[0]]
                expected = ['دسته‌بندی', 'عنوان', 'توضیحات', 'ترتیب', 'نیاز به عکس', 'نیاز به یادداشت', 'نیاز حیاتی']
                header_map = {}
                for idx, h in enumerate(headers):
                    h_norm = h.replace(' ', '').lower()
                    for exp in expected:
                        if exp.replace(' ', '').lower() == h_norm or h_norm.startswith(exp.replace(' ', '').lower()):
                            header_map[idx] = exp
                            break

                required_cols = ['دسته‌بندی', 'عنوان']
                missing = [c for c in required_cols if c not in header_map.values()]
                if missing:
                    messages.error(request, f'ستون‌های الزامی یافت نشد: {", ".join(missing)}')
                    return redirect('admin:core_checklisttemplate_import_excel')

                items_data = []
                errors = []
                for row_idx, row in enumerate(rows[1:], start=2):
                    if all(cell is None or str(cell).strip() == '' for cell in row):
                        continue
                    item = {}
                    for idx, col_name in header_map.items():
                        val = row[idx] if idx < len(row) else None
                        item[col_name] = str(val).strip() if val is not None else ''
                    category = item.get('دسته‌بندی', '')
                    title = item.get('عنوان', '')
                    if not category or not title:
                        errors.append(f'ردیف {row_idx}: دسته‌بندی و عنوان الزامی هستند.')
                        continue
                    items_data.append({
                        'category': category,
                        'title': title,
                        'description': item.get('توضیحات', ''),
                        'order': int(item.get('ترتیب', 0)) if item.get('ترتیب', '').isdigit() else 0,
                        'requires_photo': item.get('نیاز به عکس', '').lower() in ('بله', 'true', '1', 'yes'),
                        'requires_note': item.get('نیاز به یادداشت', '').lower() in ('بله', 'true', '1', 'yes'),
                        'is_critical': item.get('نیاز حیاتی', '').lower() in ('بله', 'true', '1', 'yes'),
                    })

                if not items_data:
                    messages.error(request, 'هیچ داده معتبری در فایل یافت نشد.')
                    return redirect('admin:core_checklisttemplate_import_excel')

                created_count = 0
                with transaction.atomic():
                    for item_data in items_data:
                        category_obj, _ = ChecklistCategory.objects.get_or_create(
                            name=item_data['category'],
                            defaults={'is_active': True}
                        )
                        if ChecklistItem.objects.filter(
                            checklist_template=template,
                            category=category_obj,
                            title=item_data['title']
                        ).exists():
                            continue
                        ChecklistItem.objects.create(
                            checklist_template=template,
                            category=category_obj,
                            title=item_data['title'],
                            description=item_data['description'],
                            order=item_data['order'],
                            requires_photo=item_data['requires_photo'],
                            requires_note=item_data['requires_note'],
                            is_critical=item_data['is_critical'],
                            is_active=True,
                        )
                        created_count += 1

                if errors:
                    messages.warning(request, f'{created_count} آیتم با موفقیت افزوده شد. خطاها: {" | ".join(errors)}')
                else:
                    messages.success(request, f'{created_count} آیتم با موفقیت از فایل اکسل وارد شدند.')

                return redirect('admin:core_checklisttemplate_changelist')

            except Exception as e:
                messages.error(request, f'خطا در پردازش فایل: {str(e)}')
                return redirect('admin:core_checklisttemplate_import_excel')

        context = {
            'title': 'ایمپورت از اکسل',
            'template': template,
            'templates': templates,
            'categories': categories,
            'opts': self.model._meta,
        }
        return render(request, 'admin/checklist/import_excel.html', context)

    def export_template(self, request):
        from openpyxl import Workbook
        from openpyxl.styles import Font, PatternFill, Alignment
        from django.http import HttpResponse

        wb = Workbook()
        ws = wb.active
        ws.title = 'قالب چک‌لیست'
        ws.sheet_view.rightToLeft = True

        header_fill = PatternFill(start_color='1F2937', end_color='1F2937', fill_type='solid')
        header_font = Font(color='FFFFFF', bold=True, size=11)

        headers = ['دسته‌بندی', 'عنوان', 'توضیحات', 'ترتیب', 'نیاز به عکس', 'نیاز به یادداشت', 'نیاز حیاتی']
        for col_idx, header in enumerate(headers, start=1):
            cell = ws.cell(row=1, column=col_idx, value=header)
            cell.fill = header_fill
            cell.font = header_font
            cell.alignment = Alignment(horizontal='center')

        sample = ['سازه فلزی', 'بررسی سلامت جوش‌ها', 'تست بصری جوش‌ها', 1, 'بله', 'خیر', 'بله']
        for col_idx, val in enumerate(sample, start=1):
            ws.cell(row=2, column=col_idx, value=val)

        for col_idx in range(1, len(headers)+1):
            ws.column_dimensions[chr(64 + col_idx)].width = max(len(headers[col_idx-1]) + 4, 18)

        response = HttpResponse(content_type='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')
        response['Content-Disposition'] = 'attachment; filename="checklist_template.xlsx"'
        wb.save(response)
        return response


@admin.register(ChecklistCategory)
class ChecklistCategoryAdmin(EdraJalaliAdminMixin, admin.ModelAdmin):
    # ✅ اصلاح: نمایش تاریخ جلالی
    list_display = ('name', 'color', 'order', 'is_active', 'jalali_created_at', 'jalali_updated_at')
    list_editable = ('order', 'is_active')
    search_fields = ('name',)


@admin.register(ChecklistItem)
class ChecklistItemAdmin(EdraJalaliAdminMixin, admin.ModelAdmin):
    # ✅ اصلاح: نمایش تاریخ جلالی
    list_display = ('title', 'category', 'checklist_template', 'order', 'is_active', 'jalali_created_at', 'jalali_updated_at')
    list_filter = ('is_active', 'category', 'checklist_template')
    search_fields = ('title', 'description')
    raw_id_fields = ('checklist_template', 'category')


@admin.register(InspectionReport)
class InspectionReportAdmin(EdraJalaliAdminMixin, admin.ModelAdmin):
    # ✅ اصلاح: نمایش تاریخ جلالی
    list_display = ('report_number', 'inspection_request', 'overall_result', 'jalali_created_at', 'jalali_updated_at')
    list_filter = ('overall_result',)
    search_fields = ('report_number', 'inspection_request__request_number')
    readonly_fields = ('created_at', 'updated_at')


@admin.register(ChecklistPhoto)
class ChecklistPhotoAdmin(EdraJalaliAdminMixin, admin.ModelAdmin):
    # ✅ اصلاح: نمایش تاریخ جلالی
    list_display = ('id', 'report', 'checklist_item', 'jalali_created_at')
    list_filter = ('created_at',)
    raw_id_fields = ('report', 'checklist_item')


@admin.register(ReportVerification)
class ReportVerificationAdmin(EdraJalaliAdminMixin, admin.ModelAdmin):
    # ✅ اصلاح: نمایش تاریخ جلالی
    list_display = ('verification_code', 'report', 'view_count', 'jalali_created_at')
    search_fields = ('verification_code', 'report__report_number')
    readonly_fields = ('created_at',)
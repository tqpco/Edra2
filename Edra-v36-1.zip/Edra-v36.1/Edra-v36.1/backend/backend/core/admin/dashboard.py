# core/admin/dashboard.py
# -*- coding: utf-8 -*-

from django.contrib import admin
from ..models.dashboard import DashboardLayout
from edra_jalalidate.admin import EdraJalaliAdminMixin
from edra_jalalidate import to_jalali


@admin.register(DashboardLayout)
class DashboardLayoutAdmin(EdraJalaliAdminMixin, admin.ModelAdmin):
    list_display = ('user', 'widgets_preview', 'updated_at_display')
    search_fields = ('user__username',)
    readonly_fields = ('updated_at_display',)

    def widgets_preview(self, obj):
        return ', '.join([w.get('id', '') for w in obj.widgets])[:50]
    widgets_preview.short_description = 'ویجت‌ها'

    def updated_at_display(self, obj):
        return to_jalali(obj.updated_at, "%Y/%m/%d %H:%M")
    updated_at_display.short_description = "تاریخ بروزرسانی (جلالی)"
    updated_at_display.admin_order_field = 'updated_at'
# core/dashboard/widgets.py
# -*- coding: utf-8 -*-

from django.db.models import Count, Sum, Q
from django.utils import timezone
from datetime import timedelta


class WidgetRegistry:
    """ثبت‌کننده ویجت‌های داشبورد."""
    _widgets = {}

    @classmethod
    def register(cls, widget_id: str, widget_class):
        cls._widgets[widget_id] = widget_class

    @classmethod
    def get_widget(cls, widget_id):
        return cls._widgets.get(widget_id)

    @classmethod
    def get_all_widgets(cls):
        return cls._widgets


class BaseWidget:
    """کلاس پایه ویجت."""
    id = None
    title = ""
    description = ""
    icon = "📊"
    permission = None  # نام permission یا None برای عمومی

    def get_data(self, user, **kwargs):
        """داده‌های ویجت را برمی‌گرداند."""
        raise NotImplementedError

    def to_dict(self, user, **kwargs):
        return {
            'id': self.id,
            'title': self.title,
            'description': self.description,
            'icon': self.icon,
            'data': self.get_data(user, **kwargs)
        }


class StatsWidget(BaseWidget):
    id = 'stats'
    title = 'آمار کلی'
    description = 'نمایش آمار درخواست‌ها، پرداخت‌ها و کاربران'
    icon = '📈'
    permission = 'core.view_inspectionrequest'

    def get_data(self, user, **kwargs):
        from core.models import InspectionRequest, Payment
        from django.contrib.auth import get_user_model
        User = get_user_model()

        now = timezone.now()
        month_start = now.replace(day=1, hour=0, minute=0, second=0, microsecond=0)

        return {
            'total_requests': InspectionRequest.objects.count(),
            'pending_payments': InspectionRequest.objects.filter(status='pending_payment').count(),
            'total_payments': Payment.objects.filter(status='paid').count(),
            'total_users': User.objects.count(),
            'monthly_revenue': Payment.objects.filter(
                status='paid', created_at__gte=month_start
            ).aggregate(total=Sum('amount'))['total'] or 0,
        }


class RecentActivitiesWidget(BaseWidget):
    id = 'recent_activities'
    title = 'فعالیت‌های اخیر'
    description = 'آخرین اقدامات انجام‌شده در سیستم'
    icon = '🔄'
    permission = 'core.view_auditlog'

    def get_data(self, user, **kwargs):
        from core.models import AuditLog
        logs = AuditLog.objects.select_related('user').order_by('-timestamp')[:10]
        return [
            {
                'user': log.user.get_full_name() if log.user else 'سیستم',
                'action': log.action,
                'object_id': log.object_id,
                'timestamp': log.timestamp.isoformat()
            }
            for log in logs
        ]


class AlertWidget(BaseWidget):
    id = 'alerts'
    title = 'هشدارها'
    description = 'هشدارهای مهم سیستم'
    icon = '⚠️'
    permission = 'core.view_inspectionrequest'

    def get_data(self, user, **kwargs):
        from core.models import InspectionRequest
        from support.models import Ticket

        alerts = []

        # درخواست‌های پرداخت‌نشده قدیمی
        old_pending = InspectionRequest.objects.filter(
            status='pending_payment',
            created_at__lt=timezone.now() - timedelta(days=2)
        ).count()
        if old_pending:
            alerts.append({
                'type': 'warning',
                'message': f'{old_pending} درخواست پرداخت‌نشده قدیمی وجود دارد.',
                'link': '/admin/core/inspectionrequest/?status=pending_payment'
            })

        # تیکت‌های بدون پاسخ
        no_response = Ticket.objects.filter(
            first_response_at__isnull=True,
            created_at__lt=timezone.now() - timedelta(hours=24)
        ).count()
        if no_response:
            alerts.append({
                'type': 'danger',
                'message': f'{no_response} تیکت بدون پاسخ بیش از ۲۴ ساعت مانده است.',
                'link': '/admin/support/ticket/'
            })

        return alerts


# ثبت ویجت‌ها
WidgetRegistry.register('stats', StatsWidget)
WidgetRegistry.register('recent_activities', RecentActivitiesWidget)
WidgetRegistry.register('alerts', AlertWidget)
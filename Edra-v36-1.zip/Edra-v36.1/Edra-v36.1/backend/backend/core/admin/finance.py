# core/admin/finance.py
# -*- coding: utf-8 -*-

from django.contrib import admin
from django.utils.html import format_html, mark_safe
from django.urls import reverse
from django.utils import timezone
from django.contrib import messages
from ..models import (
    Payment, Invoice, PaymentMethod, UserCredit, CreditTransaction, TaxRate,
    Refund)
from .common import get_customer_info, to_jalali
from edra_jalalidate.admin import EdraJalaliAdminMixin, make_jalali_date_filter


@admin.register(Payment)
class PaymentAdmin(EdraJalaliAdminMixin, admin.ModelAdmin):
    list_display = (
        'id',
        'inspection_request_link',
        'customer_name_phone',
        'amount_display',
        'method',
        'status_display',
        'created_at_display')
    list_filter = (
        'status', 'method',
        make_jalali_date_filter('created_at', 'تاریخ ایجاد'))
    search_fields = (
        'inspection_request__id',
        'inspection_request__title',
        'inspection_request__request_number',
        'inspection_request__customer__username',
        'inspection_request__customer__profile__phone',
        'transaction_id',
        'reference_code')
    # EDRA v35: وضعیت و مبلغ فقط‌خواندنی‌اند. ویرایش مستقیم status→paid در فرم
    # ادمین پرداخت را بدون مصرف اعتبار/اعتبارسنجی درخواست «paid» می‌کرد؛
    # مسیر درست اکشن «تایید پرداخت (settlement)» است.
    readonly_fields = (
        'status',
        'amount',
        'created_at_display',
        'updated_at_display',
        'verified_at_display',
        'bank_receipt_preview',
        'customer_name_phone')
    fields = (
        'inspection_request',
        'customer_name_phone',
        'amount',
        'method',
        'status',
        'transaction_id',
        'reference_code',
        'bank_receipt_preview',
        'bank_receipt',
        'bank_receipt_uploaded_at',
        'verified_by',
        'verified_at_display',
        'notes',
        'created_at_display',
        'updated_at_display')
    actions = ['mark_as_paid', 'mark_as_verification']

    def get_queryset(self, request):
        qs = super().get_queryset(request)
        return qs.select_related(
            'inspection_request__customer__profile',
            'method'
        )

    def inspection_request_link(self, obj):
        url = reverse(
            'admin:core_inspectionrequest_change', args=[
                obj.inspection_request.id])
        return format_html('<a href="{}">درخواست #{}</a>',
                           url, obj.inspection_request.id)
    inspection_request_link.short_description = "درخواست"

    def customer_name_phone(self, obj):
        return get_customer_info(obj)
    customer_name_phone.short_description = "مشتری (نام و شماره)"

    def amount_display(self, obj):
        return f"{obj.amount:,} تومان"
    amount_display.short_description = "مبلغ"

    def status_display(self, obj):
        colors = {
            'pending': 'orange',
            'pending_verification': 'orange',
            'paid': 'green',
            'failed': 'red',
            'refunded': 'purple',
            'rejected': 'darkred'}
        color = colors.get(obj.status, 'gray')
        return format_html(
            '<span style="background-color: {}; color: white; padding: 2px 8px; border-radius: 12px;">{}</span>',
            color,
            dict(
                Payment.STATUS_CHOICES).get(
                obj.status,
                obj.status))
    status_display.short_description = "وضعیت"

    def bank_receipt_preview(self, obj):
        if obj.bank_receipt:
            return format_html(
                '<a href="{}" target="_blank">📄 مشاهده فیش</a>',
                obj.bank_receipt.url)
        return "فیشی آپلود نشده است"
    bank_receipt_preview.short_description = "پیش‌نمایش فیش"

    # ✅ اصلاح: اضافه کردن ساعت به فرمت
    def created_at_display(self, obj):
        return to_jalali(obj.created_at, "%Y/%m/%d %H:%M")
    created_at_display.short_description = "تاریخ ایجاد (جلالی)"
    created_at_display.admin_order_field = 'created_at'

    def updated_at_display(self, obj):
        return to_jalali(obj.updated_at, "%Y/%m/%d %H:%M")
    updated_at_display.short_description = "تاریخ بروزرسانی (جلالی)"
    updated_at_display.admin_order_field = 'updated_at'

    def verified_at_display(self, obj):
        return to_jalali(obj.verified_at, "%Y/%m/%d %H:%M")
    verified_at_display.short_description = "تاریخ تایید (جلالی)"
    verified_at_display.admin_order_field = 'verified_at'

    @admin.action(description='تایید پرداخت (مسیر سرویس رسمی settlement)')
    def mark_as_paid(self, request, queryset):
        from ..services.payment_service import settle_admin_payment

        updated = 0
        errors = 0
        for payment in queryset:
            try:
                settle_admin_payment(
                    payment, verified_by=request.user)
                updated += 1
            except Exception as exc:
                errors += 1
                self.message_user(
                    request,
                    f'پرداخت #{payment.id} تأیید نشد: {exc}',
                    messages.ERROR)
        self.message_user(
            request,
            f'{updated} پرداخت از طریق سرویس رسمی تسویه شد.',
            messages.SUCCESS)
        if errors:
            self.message_user(
                request, f'{errors} پرداخت با خطا مواجه شد.', messages.ERROR)

    @admin.action(description='انتقال به وضعیت در انتظار تایید')
    def mark_as_verification(self, request, queryset):
        updated = 0
        for payment in queryset:
            if payment.status == 'pending':
                payment.status = 'pending_verification'
                payment.save()
                updated += 1
        self.message_user(
            request,
            f'{updated} پرداخت به وضعیت "در انتظار تایید" منتقل شد.',
            messages.SUCCESS)


@admin.register(Invoice)
class InvoiceAdmin(EdraJalaliAdminMixin, admin.ModelAdmin):
    list_display = (
        'invoice_number',
        'inspection_request_link',
        'customer_name_phone',
        'customer_company',
        'customer_project',
        'final_amount',
        'is_paid'
    )
    list_filter = ('is_paid',)
    search_fields = (
        'invoice_number',
        'inspection_request__title',
        'inspection_request__request_number',
        'inspection_request__customer__username',
        'inspection_request__customer__profile__phone'
    )
    readonly_fields = (
        'customer_name_phone',
        'customer_company',
        'customer_project')

    def get_queryset(self, request):
        qs = super().get_queryset(request)
        return qs.select_related(
            'inspection_request__customer__profile',
            'inspection_request__project'
        )

    def inspection_request_link(self, obj):
        url = reverse(
            'admin:core_inspectionrequest_change', args=[
                obj.inspection_request.id])
        return format_html('<a href="{}">درخواست #{}</a>',
                           url, obj.inspection_request.id)
    inspection_request_link.short_description = "درخواست"

    def customer_name_phone(self, obj):
        return get_customer_info(obj)
    customer_name_phone.short_description = "مشتری (نام و شماره)"

    def customer_company(self, obj):
        customer = obj.inspection_request.customer
        if hasattr(
                customer,
                'profile') and customer.profile and customer.profile.company_name:
            return customer.profile.company_name
        return "—"
    customer_company.short_description = "شرکت"

    def customer_project(self, obj):
        project = obj.inspection_request.project
        if project:
            return project.name
        return "—"
    customer_project.short_description = "پروژه"


@admin.register(CreditTransaction)
class CreditTransactionAdmin(EdraJalaliAdminMixin, admin.ModelAdmin):
    list_display = (
        'user_name_phone',
        'amount',
        'transaction_type',
        'created_at_display')
    list_filter = ('transaction_type',)
    search_fields = ('user__username', 'user__email', 'user__profile__phone')
    readonly_fields = ('created_at_display',)

    def get_queryset(self, request):
        qs = super().get_queryset(request)
        return qs.select_related('user__profile')

    def user_name_phone(self, obj):
        if obj.user:
            phone = obj.user.profile.phone if hasattr(
                obj.user, 'profile') and obj.user.profile else "—"
            return f"{obj.user.get_full_name()} - {phone}"
        return "—"
    user_name_phone.short_description = "کاربر (نام و شماره)"

    def created_at_display(self, obj):
        return to_jalali(obj.created_at, "%Y/%m/%d %H:%M")
    created_at_display.short_description = "تاریخ ایجاد (جلالی)"
    created_at_display.admin_order_field = 'created_at'


@admin.register(PaymentMethod)
class PaymentMethodAdmin(admin.ModelAdmin):
    list_display = ('name', 'is_active')
    list_filter = ('is_active',)


@admin.register(Refund)
class RefundAdmin(EdraJalaliAdminMixin, admin.ModelAdmin):
    list_display = (
        'id', 'payment', 'customer_display', 'amount_toman', 'status',
        'gateway_status', 'requested_at_display')
    list_filter = (
        'status', 'gateway_status',
        make_jalali_date_filter('requested_at', 'تاریخ درخواست'))
    search_fields = (
        'payment__id', 'inspection_request__request_number',
        'customer__username', 'gateway_reference')
    readonly_fields = (
        'payment', 'inspection_request', 'customer', 'invoice',
        'amount_toman', 'amount_rial', 'credit_amount', 'online_amount',
        'reason', 'requested_by', 'gateway_reference', 'gateway_status',
        'status', 'failure_reason', 'requested_at_display',
        'processed_at_display', 'completed_at_display',
        'created_at_display', 'updated_at_display')

    def customer_display(self, obj):
        if obj.customer:
            return f"{obj.customer.get_full_name()} ({obj.customer.username})"
        return "—"
    customer_display.short_description = "مشتری"

    def requested_at_display(self, obj):
        return to_jalali(obj.requested_at, "%Y/%m/%d %H:%M")
    requested_at_display.short_description = "تاریخ درخواست (جلالی)"
    requested_at_display.admin_order_field = 'requested_at'

    def processed_at_display(self, obj):
        return to_jalali(obj.processed_at, "%Y/%m/%d %H:%M")
    processed_at_display.short_description = "تاریخ پردازش (جلالی)"
    processed_at_display.admin_order_field = 'processed_at'

    def completed_at_display(self, obj):
        return to_jalali(obj.completed_at, "%Y/%m/%d %H:%M")
    completed_at_display.short_description = "تاریخ تکمیل (جلالی)"
    completed_at_display.admin_order_field = 'completed_at'

    def created_at_display(self, obj):
        return to_jalali(obj.created_at, "%Y/%m/%d %H:%M")
    created_at_display.short_description = "تاریخ ایجاد (جلالی)"
    created_at_display.admin_order_field = 'created_at'

    def updated_at_display(self, obj):
        return to_jalali(obj.updated_at, "%Y/%m/%d %H:%M")
    updated_at_display.short_description = "تاریخ بروزرسانی (جلالی)"
    updated_at_display.admin_order_field = 'updated_at'


@admin.register(TaxRate)
class TaxRateAdmin(EdraJalaliAdminMixin, admin.ModelAdmin):
    list_display = (
        'rate_percent',
        'effective_from_display',
        'effective_to_display',
        'is_active',
        'created_at_display')
    list_filter = ('is_active',)
    search_fields = ('rate_percent',)
    ordering = ('-effective_from',)
    readonly_fields = ('created_at_display', 'updated_at_display')

    def save_model(self, request, obj, form, change):
        if not obj.created_by_id:
            obj.created_by = request.user
        super().save_model(request, obj, form, change)

    def effective_from_display(self, obj):
        return to_jalali(obj.effective_from, "%Y/%m/%d")
    effective_from_display.short_description = "از تاریخ (جلالی)"
    effective_from_display.admin_order_field = 'effective_from'

    def effective_to_display(self, obj):
        return to_jalali(obj.effective_to, "%Y/%m/%d")
    effective_to_display.short_description = "تا تاریخ (جلالی)"
    effective_to_display.admin_order_field = 'effective_to'

    def created_at_display(self, obj):
        return to_jalali(obj.created_at, "%Y/%m/%d %H:%M")
    created_at_display.short_description = "تاریخ ایجاد (جلالی)"
    created_at_display.admin_order_field = 'created_at'

    def updated_at_display(self, obj):
        return to_jalali(obj.updated_at, "%Y/%m/%d %H:%M")
    updated_at_display.short_description = "تاریخ بروزرسانی (جلالی)"
    updated_at_display.admin_order_field = 'updated_at'


@admin.register(UserCredit)
class UserCreditAdmin(EdraJalaliAdminMixin, admin.ModelAdmin):
    list_display = ('user', 'balance', 'credit_limit', 'is_active')
    list_filter = ('is_active',)
    search_fields = ('user__username',)
from django.contrib import admin
from ..models import CityMultiplier, Organization, Project


@admin.register(CityMultiplier)
class CityMultiplierAdmin(admin.ModelAdmin):
    list_display = ('city', 'multiplier', 'base_cost')
    search_fields = ('city',)
    fieldsets = (
        ('اطلاعات شهر', {'fields': ('city',)}),
        ('محاسبه هزینه شهر', {
            'fields': ('base_cost', 'multiplier'),
            'description': 'هزینه نهایی شهر = base_cost × multiplier'
        }),
    )


@admin.register(Organization)
class OrganizationAdmin(admin.ModelAdmin):
    list_display = ('name', 'billing_contact')
    search_fields = ('name',)


@admin.register(Project)
class ProjectAdmin(admin.ModelAdmin):
    list_display = ('name', 'organization')
    search_fields = ('name',)
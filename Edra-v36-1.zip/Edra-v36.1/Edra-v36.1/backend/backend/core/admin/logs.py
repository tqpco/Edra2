# core/admin/logs.py
# -*- coding: utf-8 -*-

from django.contrib import admin
from django.utils.html import format_html
from django.utils import timezone
from django.contrib import messages
from ..models import AuditLog, ErrorLog, SequenceCounter
from .common import to_jalali
from edra_jalalidate.admin import EdraJalaliAdminMixin


@admin.register(AuditLog)
class AuditLogAdmin(EdraJalaliAdminMixin, admin.ModelAdmin):
    list_display = ('user', 'action', 'object_id', 'timestamp_display')
    list_filter = ('action',)
    search_fields = ('user__username',)
    readonly_fields = ('timestamp_display',)

    def timestamp_display(self, obj):
        return to_jalali(obj.timestamp, "%Y/%m/%d %H:%M")
    timestamp_display.short_description = "زمان (جلالی)"
    timestamp_display.admin_order_field = 'timestamp'


@admin.register(SequenceCounter)
class SequenceCounterAdmin(admin.ModelAdmin):
    list_display = ('key', 'value')
    search_fields = ('key',)


@admin.register(ErrorLog)
class ErrorLogAdmin(admin.ModelAdmin):
    list_display = (
        'error_id',
        'severity_display',
        'error_type',
        'status_code',
        'user',
        'timestamp_display',
        'resolved')
    list_filter = ('severity', 'status_code', 'resolved', 'timestamp')
    search_fields = (
        'error_id',
        'error_type',
        'error_message',
        'path',
        'user__username')
    readonly_fields = (
        'error_id',
        'timestamp',
        'user',
        'path',
        'method',
        'status_code',
        'error_type',
        'error_message',
        'traceback',
        'request_data',
        'user_agent',
        'ip_address')
    date_hierarchy = 'timestamp'
    actions = ['mark_as_resolved', 'export_as_xlsx']

    fieldsets = (
        ('اطلاعات خطا', {
            'fields': (
                'error_id', 'severity', 'timestamp_display', 'status_code', 'error_type')}),
        ('کاربر و درخواست', {
            'fields': (
                'user', 'path', 'method', 'ip_address', 'user_agent')}),
        ('جزئیات خطا', {
            'fields': (
                'error_message', 'traceback', 'request_data')}),
        ('رفع خطا', {
            'fields': (
                'resolved', 'resolved_at', 'resolved_by', 'resolution_note')}),
    )

    def severity_display(self, obj):
        colors = {
            'debug': 'gray',
            'info': 'blue',
            'warning': 'orange',
            'error': 'red',
            'critical': 'darkred'}
        return format_html(
            '<span style="color: {}; font-weight: bold;">{}</span>',
            colors.get(obj.severity, 'black'),
            obj.get_severity_display())
    severity_display.short_description = 'شدت'

    def timestamp_display(self, obj):
        return to_jalali(obj.timestamp, "%Y/%m/%d %H:%M")
    timestamp_display.short_description = "زمان (جلالی)"
    timestamp_display.admin_order_field = 'timestamp'

    @admin.action(description='علامت‌گذاری به عنوان برطرف‌شده')
    def mark_as_resolved(self, request, queryset):
        updated = queryset.update(
            resolved=True,
            resolved_at=timezone.now(),
            resolved_by=request.user)
        self.message_user(
            request,
            f'{updated} خطا به عنوان برطرف‌شده علامت‌گذاری شد.')

    @admin.action(description='خروجی اکسل از خطاهای انتخاب‌شده')
    def export_as_xlsx(self, request, queryset):
        from openpyxl import Workbook
        from core.views.report_views import _sheet_from_rows, _xlsx_response

        headers = [
            'شناسه خطا', 'زمان (شمسی)', 'شدت', 'کد وضعیت', 'متد', 'مسیر',
            'نوع خطا', 'پیام خطا', 'کاربر', 'IP', 'برطرف‌شده',
            'یادداشت رفع خطا', 'Traceback (خلاصه)',
        ]
        rows = []
        for log in queryset.select_related('user').order_by('-timestamp'):
            rows.append([
                log.error_id,
                to_jalali(log.timestamp, "%Y/%m/%d %H:%M"),
                log.get_severity_display(),
                log.status_code,
                log.method,
                log.path,
                log.error_type,
                log.error_message,
                log.user.get_full_name() if log.user else '',
                log.ip_address,
                'بله' if log.resolved else 'خیر',
                log.resolution_note,
                (log.traceback or '')[:2000],
            ])

        wb = Workbook()
        wb.remove(wb.active)
        _sheet_from_rows(wb, 'لاگ خطاها', headers, rows)
        filename = f"error-logs-{timezone.now().strftime('%Y%m%d-%H%M')}.xlsx"
        return _xlsx_response(wb, filename)
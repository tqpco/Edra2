# core/admin/menu.py
# -*- coding: utf-8 -*-

from django.contrib import admin
from django.urls import reverse, path
from django.utils.html import format_html
from django.utils.translation import gettext_lazy as _
from django.http import JsonResponse
from django.db import transaction
import json

from edra_jalalidate.admin import EdraJalaliAdminMixin

from ..models import Menu, MenuItem
from ..validators import validate_excel_file


class MenuItemInline(admin.TabularInline):
    """نمایش آیتم‌های منو در صفحه ویرایش منو"""
    model = MenuItem
    extra = 1
    fields = ('title', 'url', 'icon', 'parent', 'order', 'is_active')
    ordering = ('parent__order', 'order')
    show_change_link = True
    classes = ('collapse',)
    verbose_name = _('آیتم منو')
    verbose_name_plural = _('آیتم‌های منو')


@admin.register(Menu)
class MenuAdmin(EdraJalaliAdminMixin, admin.ModelAdmin):
    list_display = ('name', 'icon_preview', 'order', 'is_active', 'items_count', 'created_at_display')
    list_editable = ('order', 'is_active')
    list_filter = ('is_active',)
    search_fields = ('name',)
    ordering = ('order', 'name')
    inlines = [MenuItemInline]
    save_on_top = True

    fieldsets = (
        ('اطلاعات منو', {
            'fields': ('name', 'icon', 'is_active', 'order')
        }),
    )

    class Media:
        css = {'all': ('admin/css/menu_manager.css',)}
        js = ('admin/js/menu_manager.js',)

    def icon_preview(self, obj):
        return format_html(
            '<span style="font-size:20px;">{}</span>',
            obj.get_icon_display()
        )
    icon_preview.short_description = 'آیکون'

    def items_count(self, obj):
        return obj.items.filter(is_active=True).count()
    items_count.short_description = 'تعداد آیتم‌ها'

    def created_at_display(self, obj):
        from edra_jalalidate import to_jalali
        return to_jalali(obj.created_at, "%Y/%m/%d %H:%M")
    created_at_display.short_description = "تاریخ ایجاد"
    created_at_display.admin_order_field = 'created_at'


@admin.register(MenuItem)
class MenuItemAdmin(EdraJalaliAdminMixin, admin.ModelAdmin):
    list_display = (
        'drag_handle',
        'title',
        'menu',
        'parent',
        'order',
        'is_active',
        'url_preview',
    )
    list_editable = ('order', 'is_active')
    list_filter = ('menu', 'is_active', 'parent')
    search_fields = ('title', 'url')
    ordering = ('menu', 'parent__order', 'order')
    save_on_top = True

    fieldsets = (
        ('اطلاعات آیتم', {
            'fields': ('menu', 'parent', 'title', 'url', 'icon', 'target')
        }),
        ('تنظیمات', {
            'fields': ('order', 'is_active', 'permission_required')
        }),
    )

    class Media:
        css = {'all': ('admin/css/menu_manager.css',)}
        js = ('admin/js/menu_manager.js',)

    # ============================================================
    # متدهای نمایشی
    # ============================================================

    def drag_handle(self, obj):
        return format_html('<span class="drag-handle">⠿</span>')
    drag_handle.short_description = ''

    def url_preview(self, obj):
        if obj.url.startswith('http'):
            return format_html(
                '<a href="{}" target="_blank" style="color:#3b82f6;">🌐 {}</a>',
                obj.url, obj.url[:30]
            )
        return format_html(
            '<span style="color:#64748b;">{}</span>',
            obj.url
        )
    url_preview.short_description = 'لینک'

    # ============================================================
    # URLهای سفارشی (API برای AJAX)
    # ============================================================

    def get_urls(self):
        urls = super().get_urls()
        custom_urls = [
            path('reorder/', self.reorder_items, name='menuitem_reorder'),
            path('get-items/', self.get_items_json, name='menuitem_get_items'),
        ]
        return custom_urls + urls

    # ============================================================
    # اکشن‌های AJAX
    # ============================================================

    def reorder_items(self, request):
        """جابه‌جایی آیتم‌های منو با Drag & Drop (AJAX)"""
        if request.method != 'POST':
            return JsonResponse({'error': 'روش غیرمجاز'}, status=405)

        try:
            data = json.loads(request.body)
            ids = data.get('ids', [])
            menu_id = data.get('menu_id')

            if not ids:
                return JsonResponse({'success': False, 'error': 'لیست آیتم‌ها ارسال نشد'}, status=400)

            items = MenuItem.objects.filter(id__in=ids)
            if menu_id:
                items = items.filter(menu_id=menu_id)

            if items.count() != len(ids):
                return JsonResponse({'success': False, 'error': 'برخی آیتم‌ها به این منو تعلق ندارند'}, status=400)

            with transaction.atomic():
                for index, item_id in enumerate(ids):
                    MenuItem.objects.filter(id=item_id).update(order=index + 1)

            return JsonResponse({'success': True, 'message': 'ترتیب آیتم‌ها با موفقیت به‌روزرسانی شد'})

        except Exception as e:
            return JsonResponse({'success': False, 'error': str(e)}, status=500)

    def get_items_json(self, request):
        """دریافت لیست آیتم‌های یک منو به‌صورت JSON"""
        menu_id = request.GET.get('menu_id')
        if not menu_id:
            return JsonResponse({'error': 'شناسه منو الزامی است'}, status=400)

        items = MenuItem.objects.filter(menu_id=menu_id, is_active=True).select_related('parent')
        data = []
        for item in items.order_by('parent__order', 'order'):
            data.append({
                'id': item.id,
                'title': item.title,
                'parent_id': item.parent_id,
                'url': item.url,
                'icon': item.icon,
                'order': item.order,
                'is_active': item.is_active,
            })

        return JsonResponse({'items': data, 'count': len(data)})
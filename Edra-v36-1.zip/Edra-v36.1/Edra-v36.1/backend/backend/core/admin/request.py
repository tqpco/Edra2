# core/admin/request.py
# -*- coding: utf-8 -*-

from django.contrib import admin
from django import forms
from django.utils.html import format_html, format_html_join, mark_safe
from django.urls import reverse
from django.db.models import Prefetch
from django.contrib import messages
from django.utils import timezone
from ..models import InspectionRequest, Payment, Invoice, DiscountCode
from .common import get_customer_info
from edra_jalalidate import to_jalali
from edra_jalalidate.admin import EdraJalaliAdminMixin, make_jalali_date_filter
from edra_jalalidate.widgets import AdminjDateTimeSeparateWidget
import json

from discounts.tasks import send_discount_to_all_users, send_discount_to_user


class PaymentInline(EdraJalaliAdminMixin, admin.TabularInline):
    model = Payment
    extra = 0
    fields = (
        'amount',
        'method',
        'status',
        'transaction_id',
        'bank_receipt_link',
        'created_at_display')
    readonly_fields = (
        'amount',
        'method',
        'status',
        'transaction_id',
        'bank_receipt_link',
        'created_at_display')
    can_delete = False

    def bank_receipt_link(self, obj):
        if obj.bank_receipt:
            return format_html(
                '<a href="{}" target="_blank">📄 مشاهده فیش</a>',
                obj.bank_receipt.url)
        return mark_safe("—")
    bank_receipt_link.short_description = "فیش واریزی"

    def created_at_display(self, obj):
        return to_jalali(obj.created_at, "%Y/%m/%d %H:%M")
    created_at_display.short_description = "تاریخ ایجاد (جلالی)"


class InvoiceInline(EdraJalaliAdminMixin, admin.TabularInline):
    model = Invoice
    extra = 0
    fields = ('invoice_number', 'final_amount', 'is_paid', 'pdf_link')
    readonly_fields = ('invoice_number', 'final_amount', 'is_paid', 'pdf_link')
    can_delete = False

    def pdf_link(self, obj):
        if obj.pdf_file:
            return format_html(
                '<a href="{}" target="_blank">📄 دانلود فاکتور</a>',
                obj.pdf_file.url)
        return mark_safe("—")
    pdf_link.short_description = "فایل فاکتور"


@admin.register(InspectionRequest)
class InspectionRequestAdmin(EdraJalaliAdminMixin, admin.ModelAdmin):
    list_display = (
        'request_number',
        'title',
        'customer_name_phone',
        'equipment_type_display',
        'city',
        'status_display',
        'payment_status_display',
        'final_price_display',
        'scheduled_at_display',
        'created_at_display')
    list_filter = (
        'status', 'city', 'equipment_type',
        make_jalali_date_filter('created_at', 'تاریخ ایجاد'))
    search_fields = (
        'request_number', 'title', 'customer__username', 'customer__email',
        'customer__profile__phone', 'address', 'brand_model'
    )
    list_select_related = (
        'customer',
        'customer__profile',
        'equipment_type',
        'assigned_expert')
    readonly_fields = (
        'request_number',
        'customer',
        'calculated_price',
        'final_price',
        'created_at_display',
        'updated_at_display',
        'payment_details_display',
        'params_display',
        'install_state_display',
        'brand_model_display',
        'address_display',
        'status')
    inlines = [PaymentInline, InvoiceInline]
    actions = ['mark_as_paid', 'send_reminder']

    fieldsets = (
        ('شناسه درخواست', {'fields': ('request_number', 'title')}),
        ('اطلاعات مشتری', {'fields': ('customer', 'project')}),
        ('اطلاعات دستگاه و سرویس', {
            'fields': ('equipment_type', 'brand_model_display', 'manufacture_year', 'params_display', 'install_state_display')
        }),
        ('مکان و زمان', {'fields': ('city', 'address_display', 'scheduled_at')}),
        ('قیمت و تخفیف', {'fields': ('calculated_price', 'discount_code', 'final_price')}),
        ('وضعیت', {'fields': ('status',)}),
        ('جزئیات پرداخت', {'fields': ('payment_details_display',), 'classes': ('collapse',)}),
        ('اطلاعات سیستمی', {
            'fields': ('created_at_display', 'updated_at_display', 'assigned_expert'),
            'classes': ('collapse',)
        }),
    )

    def get_queryset(self, request):
        qs = super().get_queryset(request)
        return qs.select_related(
            'customer',
            'customer__profile',
            'equipment_type',
            'assigned_expert').prefetch_related(
            Prefetch(
                'payments',
                queryset=Payment.objects.select_related(
                    'method').order_by('-created_at'),
                to_attr='payments_ordered'),
            'invoice')

    def customer_name_phone(self, obj):
        return get_customer_info(obj)
    customer_name_phone.short_description = "مشتری (نام و شماره)"

    def equipment_type_display(self, obj):
        return obj.equipment_type.name_fa if obj.equipment_type else "—"
    equipment_type_display.short_description = "نوع تجهیز"

    def brand_model_display(self, obj):
        if obj.params and obj.params.get('is_deposit'):
            return mark_safe(
                '<span style="color: #0d9488; font-weight: bold;">💰 واریز اعتبار</span>')
        return format_html('{}', obj.brand_model or "—")
    brand_model_display.short_description = "برند/مدل"

    def params_display(self, obj):
        if not obj.params:
            return "—"
        if obj.params.get('is_deposit'):
            return mark_safe(
                '<span style="color: #0d9488;">💰 واریز اعتبار</span>')
        return format_html(
            '<pre style="margin:0; background:#f5f5f5; padding:5px; border-radius:4px;">{}</pre>',
            json.dumps(
                obj.params,
                indent=2,
                ensure_ascii=False))
    params_display.short_description = "پارامترها"

    def install_state_display(self, obj):
        if not obj.install_state:
            return mark_safe(
                '<span style="color: #999;">وضعیت نصب مشخص نشده</span>')
        states = {
            'installed': '✅ دستگاه نصب می‌باشد',
            'not_installed': '❌ دستگاه نصب نمی‌باشد',
            'dismantle': '❌ دستگاه دمونتاژ می‌باشد',
        }
        return states.get(obj.install_state, obj.install_state)
    install_state_display.short_description = "وضعیت نصب"

    def address_display(self, obj):
        if obj.params and obj.params.get('is_deposit'):
            return mark_safe(
                '<span style="color: #0d9488;">💰 واریز اعتبار</span>')
        return obj.address or "—"
    address_display.short_description = "آدرس"

    def status_display(self, obj):
        colors = {
            'draft': 'gray',
            'pending_payment': 'orange',
            'paid': 'green',
            'scheduled': 'blue',
            'in_progress': 'purple',
            'completed': 'teal',
            'cancelled': 'red'}
        color = colors.get(obj.status, 'gray')
        return format_html(
            '<span style="background-color: {}; color: white; padding: 2px 8px; border-radius: 12px;">{}</span>',
            color,
            dict(
                InspectionRequest.STATUS_CHOICES).get(
                obj.status,
                obj.status))
    status_display.short_description = "وضعیت درخواست"

    def payment_status_display(self, obj):
        payments = getattr(obj, 'payments_ordered', None)
        payment = payments[0] if payments else None
        if not payment:
            return mark_safe('<span style="color: gray;">بدون پرداخت</span>')
        colors = {
            'pending': 'orange',
            'pending_verification': 'orange',
            'paid': 'green',
            'failed': 'red',
            'refunded': 'purple',
            'rejected': 'red'}
        color = colors.get(payment.status, 'gray')
        method_name = payment.method.name if payment.method else "نامشخص"
        return format_html(
            '<span style="background-color: {}; color: white; padding: 2px 8px; border-radius: 12px;">{} ({})</span>',
            color,
            dict(
                Payment.STATUS_CHOICES).get(
                payment.status,
                payment.status),
            method_name)
    payment_status_display.short_description = "وضعیت پرداخت"

    def final_price_display(self, obj):
        return f"{obj.final_price:,} تومان" if obj.final_price else "—"
    final_price_display.short_description = "قیمت نهایی"

    # ✅ اصلاح: اضافه کردن ساعت به فرمت
    def scheduled_at_display(self, obj):
        return to_jalali(obj.scheduled_at, "%Y/%m/%d %H:%M")
    scheduled_at_display.short_description = "زمان بازرسی (جلالی)"
    scheduled_at_display.admin_order_field = 'scheduled_at'

    def created_at_display(self, obj):
        return to_jalali(obj.created_at, "%Y/%m/%d %H:%M")
    created_at_display.short_description = "تاریخ ایجاد (جلالی)"
    created_at_display.admin_order_field = 'created_at'

    def updated_at_display(self, obj):
        return to_jalali(obj.updated_at, "%Y/%m/%d %H:%M")
    updated_at_display.short_description = "تاریخ بروزرسانی (جلالی)"
    updated_at_display.admin_order_field = 'updated_at'

    def payment_details_display(self, obj):
        payments = getattr(obj, 'payments_ordered', None)
        if not payments:
            return mark_safe("هیچ پرداختی ثبت نشده است.")

        rows = []
        for p in payments:
            method_name = p.method.name if p.method else "نامشخص"
            if p.bank_receipt:
                receipt_link = format_html(
                    '<a href="{}" target="_blank">📄 مشاهده</a>',
                    p.bank_receipt.url)
            else:
                receipt_link = '—'
            rows.append(format_html(
                '<tr><td>{}</td><td>{} تومان</td><td>{}</td>'
                '<td>{}</td><td>{}</td></tr>',
                method_name,
                f'{p.amount or 0:,}',
                dict(Payment.STATUS_CHOICES).get(p.status, p.status),
                p.transaction_id or '—',
                receipt_link,
            ))
        header = ('<tr style="background:#f0f0f0;"><th>روش</th><th>مبلغ</th>'
                  '<th>وضعیت</th><th>شناسه تراکنش</th><th>فیش</th></tr>')
        return format_html(
            '<table style="width:100%; border-collapse: collapse;">'
            '{}{}{}</table>',
            mark_safe(header),
            format_html_join('', '{}', ((r,) for r in rows)),
            mark_safe(''),
        )
    payment_details_display.short_description = "جزئیات پرداخت"

    @admin.action(description='تایید پرداخت (فقط از طریق سرویس رسمی)')
    def mark_as_paid(self, request, queryset):
        from ..services.invoice_service import InvoiceSettlementService

        updated = 0
        skipped = 0
        for req in queryset:
            paid_payment = req.payments.filter(status='paid').first()
            if not paid_payment:
                skipped += 1
                continue
            try:
                InvoiceSettlementService.settle(
                    req, payment=paid_payment,
                    is_paid=True, paid_at=paid_payment.verified_at,
                    user=req.customer)
                updated += 1
            except Exception as exc:
                self.message_user(
                    request,
                    f'درخواست #{req.id}: خطا در settlement — {exc}',
                    messages.ERROR)
        if skipped:
            self.message_user(
                request,
                f'{skipped} درخواست پرداختِ تأییدشده‌ای نداشتند — ابتدا '
                'پرداخت را از ادمین Payment تأیید کنید (اکشن تأیید پرداخت).',
                messages.WARNING)
        if updated:
            self.message_user(
                request,
                f'{updated} درخواست از طریق سرویس رسمی تسویه شد.',
                messages.SUCCESS)
        if updated == 0:
            self.message_user(
                request,
                'هیچ درخواستی در وضعیت "در انتظار پرداخت" نبود.',
                messages.WARNING)
        else:
            self.message_user(
                request,
                f'{updated} درخواست با موفقیت تایید شد.',
                messages.SUCCESS)

    @admin.action(description='ارسال یادآوری به مشتری')
    def send_reminder(self, request, queryset):
        from notifications.services import send_notification
        from django.utils import timezone as _tz

        sent = 0
        for req in queryset:
            customer = req.customer
            if not customer:
                continue
            try:
                log = send_notification(
                    customer, 'request_reminder',
                    {
                        'request_id': req.id,
                        'request_number': req.request_number,
                        'message': (
                            f'یادآوری: درخواست بازرسی {req.request_number} '
                            'در انتظار اقدام شماست.'),
                    })
                # EDRA v33: قبلاً با قالب ناموجود هم «موفق» شمرده می‌شد.
                if log is None:
                    raise RuntimeError('قالب اعلان یافت نشد یا غیرفعال است.')
                if log.status == 'failed':
                    raise RuntimeError(log.error_message or 'ارسال ناموفق بود.')
                sent += 1
            except Exception as exc:
                self.message_user(
                    request,
                    f'ارسال یادآوری برای درخواست #{req.id} ناموفق بود: {exc}',
                    messages.ERROR)
        if sent:
            self.message_user(
                request,
                f'یادآوری برای {sent} درخواست ارسال شد.',
                messages.SUCCESS)
        else:
            self.message_user(
                request,
                'یادآوری‌ای ارسال نشد (مشتری معتبری یافت نشد).',
                messages.WARNING)

    def save_model(self, request, obj, form, change):
        if change and 'status' in form.changed_data and obj.status == 'paid':
            from django.contrib import messages as dj_messages
            dj_messages.error(
                request,
                'تغییر مستقیم به «پرداخت‌شده» مجاز نیست؛ از اکشن رسمی '
                'تأیید پرداخت در ادمین Payment استفاده کنید.')
            obj.status = form.initial.get('status', obj.status)
        super().save_model(request, obj, form, change)


# ------------------------------------------------------------
# فرم و ادمین کدهای تخفیف با ویجت جداگانه تاریخ و ساعت
# ------------------------------------------------------------

class DiscountCodeForm(forms.ModelForm):
    class Meta:
        model = DiscountCode
        fields = '__all__'
        widgets = {
            'expires_at': AdminjDateTimeSeparateWidget(),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        if self.instance and self.instance.pk and self.instance.apply_to_all:
            self.fields['equipment_type'].required = False
            self.fields['equipment_type'].widget.attrs['disabled'] = 'disabled'


@admin.register(DiscountCode)
class DiscountCodeAdmin(EdraJalaliAdminMixin, admin.ModelAdmin):
    form = DiscountCodeForm
    list_display = (
        'code',
        'discount_type',
        'value',
        'is_active',
        'is_public',
        'apply_to_all',
        'equipment_type',
        'expires_at_display')
    list_filter = ('is_active', 'is_public', 'discount_type', 'apply_to_all')
    list_editable = ('is_public',)  # EDRA v32: تغییر سریع بدون باز کردن فرم
    search_fields = ('code',)
    actions = ['send_to_all_users', 'send_to_selected_users']
    fieldsets = (
        ('اطلاعات اصلی', {
            'fields': ('code', 'discount_type', 'value')
        }),
        ('محدودیت‌ها', {
            'fields': ('min_amount', 'max_amount', 'usage_limit', 'per_user_limit', 'expires_at')
        }),
        ('نوع تجهیزات', {
            'fields': ('apply_to_all', 'equipment_type'),
            'description': 'اگر "اعمال برای همه تجهیزات" را تیک بزنید، تخفیف بدون محدودیت نوع تجهیزات اعمال می‌شود.'
        }),
        ('نمایش عمومی', {
            'fields': ('is_public',),
            'description': 'هشدار: فقط کدهای عمومی/بازاریابی را فعال کنید؛ کدهای هدفمند (ریفرال و مشابه) باید خاموش بمانند وگرنه هر مشتری آن را می‌بیند و مصرف می‌کند.'
        }),
        ('سایر', {
            'fields': ('is_active', 'description')
        }),
    )

    def expires_at_display(self, obj):
        if obj.expires_at:
            return to_jalali(obj.expires_at, "%Y/%m/%d %H:%M")
        return "—"
    expires_at_display.short_description = "تاریخ انقضا (جلالی)"
    expires_at_display.admin_order_field = 'expires_at'

    def formfield_for_dbfield(self, db_field, request, **kwargs):
        if db_field.name == 'expires_at':
            return self.form.base_fields['expires_at']
        return super().formfield_for_dbfield(db_field, request, **kwargs)

    @admin.action(description='ارسال کد تخفیف به همه کاربران')
    def send_to_all_users(self, request, queryset):
        queued = 0
        for discount in queryset:
            try:
                send_discount_to_all_users.delay(discount.id)
                queued += 1
            except Exception as exc:  # EDRA v36: قطعی broker نباید صفحه را ۵۰۰ کند
                self.message_user(
                    request,
                    f'کد {discount.code}: صف‌بندی ناموفق بود ({exc}).',
                    messages.ERROR)
        if queued:
            self.message_user(
                request,
                f'کد تخفیف برای {queued} کد به همه کاربران ارسال شد.',
                messages.SUCCESS)

    @admin.action(description='ارسال کد تخفیف به کاربران انتخاب‌شده')
    def send_to_selected_users(self, request, queryset):
        request.session['selected_discount_ids'] = list(
            queryset.values_list('id', flat=True))
        self.message_user(
            request,
            'این اکشن نیاز به یک صفحه واسط دارد. لطفاً ویو و قالب مربوطه را ایجاد کنید.',
            messages.WARNING)
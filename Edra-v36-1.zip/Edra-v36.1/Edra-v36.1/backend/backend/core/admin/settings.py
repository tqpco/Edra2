# core/admin/settings.py
# -*- coding: utf-8 -*-

from django.contrib import admin
from ..models.settings import SystemSetting
from edra_jalalidate.admin import EdraJalaliAdminMixin
from edra_jalalidate import to_jalali


@admin.register(SystemSetting)
class SystemSettingAdmin(EdraJalaliAdminMixin, admin.ModelAdmin):
    list_display = ('key', 'value_preview', 'is_active', 'updated_at_display')
    list_filter = ('is_active',)
    search_fields = ('key', 'description')
    readonly_fields = ('updated_at_display',)

    def value_preview(self, obj):
        return str(obj.value)[:50] + ('...' if len(str(obj.value)) > 50 else '')
    value_preview.short_description = 'مقدار'

    def updated_at_display(self, obj):
        return to_jalali(obj.updated_at, "%Y/%m/%d %H:%M")
    updated_at_display.short_description = 'تاریخ بروزرسانی'
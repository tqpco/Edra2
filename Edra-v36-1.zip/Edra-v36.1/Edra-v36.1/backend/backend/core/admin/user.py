# core/admin/user.py
# -*- coding: utf-8 -*-
"""
مدیریت کاربران، پروفایل و OTP در پنل ادمین با پشتیبانی از تاریخ جلالی.
"""

from django.contrib import admin
from django.contrib.auth.admin import UserAdmin as DjangoUserAdmin
from django.contrib.auth.models import User, Group

from ..models import UserProfile, OTPCode
from .common import to_jalali
from edra_jalalidate.admin import EdraJalaliAdminMixin


# ============================================================
# ابتدا مدل‌های پیش‌فرض را از ادمین خارج می‌کنیم تا دوباره ثبت شوند
# ============================================================
try:
    admin.site.unregister(User)
except admin.sites.NotRegistered:
    pass

try:
    admin.site.unregister(Group)
except admin.sites.NotRegistered:
    pass


# ============================================================
# تعریف کلاس‌های ادمین سفارشی با دکوراتور
# ============================================================
class UserProfileInline(EdraJalaliAdminMixin, admin.StackedInline):
    model = UserProfile
    can_delete = False
    verbose_name = 'پروفایل'
    verbose_name_plural = 'پروفایل'
    fields = ('phone', 'registration_number', 'company_name', 'projects')
    filter_horizontal = ('projects',)


@admin.register(User)
class CustomUserAdmin(EdraJalaliAdminMixin, DjangoUserAdmin):
    # EDRA v36 — باگ جدی: این کلاس از admin.ModelAdmin ساده ارث می‌برد و UserAdmin
    # استاندارد جنگو (فرم ساخت کاربر، فیلد رمز با هش‌کردن، لینک «تغییر رمز»،
    # مدیریت صحیح groups/permissions) را کنار گذاشته بود؛ در نتیجه رمزی که ادمین
    # در فرم وارد می‌کرد «بدون هش» (plaintext) در دیتابیس ذخیره می‌شد و آن حساب
    # هرگز نمی‌توانست لاگین کند. اکنون از UserAdmin ارث می‌برد و سفارشی‌سازی‌های
    # قبلی (لیست، جستجو، پروفایل inline) حفظ شده‌اند.
    list_display = (
        'username',
        'email',
        'first_name',
        'last_name',
        'phone_display',
        'is_staff',
        'date_joined_jalali',
        'last_login_jalali',
    )
    list_filter = ('is_staff', 'is_superuser', 'is_active')
    search_fields = (
        'username',
        'email',
        'first_name',
        'last_name',
        'profile__phone',
    )
    inlines = [UserProfileInline]

    def phone_display(self, obj):
        if hasattr(obj, 'profile') and obj.profile:
            return obj.profile.phone
        return "—"
    phone_display.short_description = "شماره موبایل"

    def date_joined_jalali(self, obj):
        return to_jalali(obj.date_joined, fmt="%Y/%m/%d %H:%M")
    date_joined_jalali.short_description = "تاریخ عضویت (جلالی)"
    date_joined_jalali.admin_order_field = 'date_joined'

    def last_login_jalali(self, obj):
        if obj.last_login:
            return to_jalali(obj.last_login, fmt="%Y/%m/%d %H:%M")
        return "—"
    last_login_jalali.short_description = "آخرین ورود (جلالی)"
    last_login_jalali.admin_order_field = 'last_login'


@admin.register(OTPCode)
class OTPCodeAdmin(EdraJalaliAdminMixin, admin.ModelAdmin):
    list_display = ('phone', 'created_at_display', 'is_used', 'attempts')
    list_filter = ('is_used',)
    search_fields = ('phone',)
    readonly_fields = ('phone', 'code', 'is_used', 'attempts', 'created_at')
    list_per_page = 50

    def created_at_display(self, obj):
        return to_jalali(obj.created_at, fmt="%Y/%m/%d %H:%M")
    created_at_display.short_description = "تاریخ ایجاد (جلالی)"


@admin.register(Group)
class GroupAdmin(admin.ModelAdmin):
    list_display = ('name',)
    search_fields = ('name',)
# core/authentication.py
# -*- coding: utf-8 -*-
"""
EDRA v36 — احراز هویت JWT با اعمال «تعلیق/انقضای حساب».

باگ قبلی: فیلدهای UserAccountSettings.is_suspended / account_expiry (پنل ادمین
و تسک deactivate_expired_accounts) فقط ذخیره می‌شدند و هیچ‌جا اعمال نمی‌شدند؛
کاربرِ تعلیق‌شده/منقضی همچنان لاگین می‌کرد و تمام API را می‌دید. اکنون هر
درخواست JWT این وضعیت را (با کش ۶۰ ثانیه‌ای برای جلوگیری از کوئری اضافه در هر
درخواست) بررسی می‌کند. سوپریوزر هرگز قفل نمی‌شود (جلوگیری از قفل‌شدن کل پنل).
"""
from django.core.cache import cache
from django.db.models import Q
from django.utils import timezone
from rest_framework.exceptions import AuthenticationFailed
from rest_framework_simplejwt.authentication import JWTAuthentication

_CACHE_TTL = 60
SUSPENDED_MESSAGE = 'حساب کاربری شما تعلیق یا منقضی شده است.'


def is_account_suspended(user):
    """True اگر حساب (غیر سوپریوزر) تعلیق یا منقضی شده باشد."""
    if user is None or not getattr(user, 'pk', None) or user.is_superuser:
        return False
    key = f'acct_suspended:{user.pk}'
    cached = cache.get(key)
    if cached is not None:
        return bool(cached)
    try:
        from support.models import UserAccountSettings
        suspended = UserAccountSettings.objects.filter(user_id=user.pk).filter(
            Q(is_suspended=True)
            | Q(account_expiry__isnull=False,
                account_expiry__lte=timezone.now())
        ).exists()
    except Exception:
        # خرابی کوئری نباید همه را قفل کند؛ fail-open فقط برای همین بررسی.
        return False
    cache.set(key, suspended, _CACHE_TTL)
    return suspended


class EdraJWTAuthentication(JWTAuthentication):
    def get_user(self, validated_token):
        user = super().get_user(validated_token)
        if is_account_suspended(user):
            raise AuthenticationFailed(SUSPENDED_MESSAGE, code='user_suspended')
        return user

# core/events.py
# -*- coding: utf-8 -*-
"""
سیستم رویداد محور برای جایگزینی سیگنال‌های پراکنده.
همه رویدادها (ایجاد، به‌روزرسانی، حذف) از این سیستم عبور می‌کنند و هندلرها به‌صورت ثبت‌شده اجرا می‌شوند.
"""

from typing import Dict, List, Callable, Any, Optional
from dataclasses import dataclass, field
import logging

logger = logging.getLogger(__name__)


@dataclass
class Event:
    """یک رویداد با نام و داده‌های مرتبط."""
    name: str
    payload: Dict[str, Any]
    sender: Optional[Any] = None


EventHandler = Callable[[Event], None]


class EventRegistry:
    """ثبت‌کننده و توزیع‌کننده رویدادها."""
    _handlers: Dict[str, List[EventHandler]] = {}

    @classmethod
    def register(cls, event_name: str, handler: EventHandler):
        if event_name not in cls._handlers:
            cls._handlers[event_name] = []
        cls._handlers[event_name].append(handler)

    @classmethod
    def dispatch(cls, event: Event):
        handlers = cls._handlers.get(event.name, [])
        for handler in handlers:
            try:
                handler(event)
            except Exception as e:
                logger.error(f"Error in event handler for {event.name}: {e}")

    @classmethod
    def clear(cls):
        cls._handlers = {}


# ============================================================
# دکوراتور برای ثبت خودکار هندلرها
# ============================================================

def on_event(event_name: str):
    """دکوراتور برای ثبت یک تابع به‌عنوان هندلر رویداد."""
    def decorator(func: EventHandler):
        EventRegistry.register(event_name, func)
        return func
    return decorator


# ============================================================
# هندلرهای پیش‌فرض (قابل توسعه)
# ============================================================

# نمونه هندلر برای رویداد ایجاد تیکت
@on_event('ticket_created')
def handle_ticket_created(event: Event):
    from support.models import Ticket
    ticket = event.payload.get('instance')
    if ticket and isinstance(ticket, Ticket):
        # EDRA v33: apply_rules و trigger_webhook اینجا حذف شد — خودِ view
        # (support/views.py: perform_create) قبل از dispatch همین دو را اجرا
        # می‌کرد؛ نتیجه: قوانین دو بار اعمال و وب‌هوک دو بار ارسال می‌شد.
        from notifications.services import send_notification
        send_notification(ticket.customer, 'ticket_created', {
            'ticket_id': ticket.id,
            'title': ticket.title
        })


# نمونه هندلر برای رویداد تغییر وضعیت
@on_event('status_changed')
def handle_status_changed(event: Event):
    instance = event.payload.get('instance')
    old_status = event.payload.get('old_status')
    new_status = event.payload.get('new_status')
    actor = event.payload.get('actor')
    # لاگ
    from core.models import AuditLog
    if instance and hasattr(instance, 'id'):
        AuditLog.objects.create(
            user=actor,
            action='status_changed',
            object_id=instance.id,
            changes={'old': old_status, 'new': new_status}
        )
# core/expert/views.py
# -*- coding: utf-8 -*-

from rest_framework import generics, status, serializers
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated
from core.permissions import IsAdminUserOrGroup
from rest_framework.parsers import MultiPartParser, FormParser
from django.contrib.auth import get_user_model
from django.db import transaction
from django.db.models import Count, Q
from django.db.models.functions import TruncMonth
from django.utils import timezone
from django.template.loader import render_to_string
from django.http import HttpResponse, FileResponse
from decimal import Decimal, InvalidOperation
import logging
import re
from django.conf import settings

# ✅ ایمپورت to_jalali از پکیج edra_jalalidate
from edra_jalalidate import to_jalali

from ..models import (
    InspectionRequest, InspectionReport, ChecklistTemplate, ChecklistItem,
    ChecklistPhoto, SequenceCounter
)
from ..utils.geo import haversine_distance_meters
from ..serializers import InspectionReportSerializer, UserSerializer
from ..permissions import is_admin_user
from ..services.inspection_service import (
    EXPERT_EXECUTABLE_STATUSES, apply_status_change)

User = get_user_model()
logger = logging.getLogger(__name__)

# ============================================================
# سریالایزرها
# ============================================================


class ExpertTaskSerializer(serializers.ModelSerializer):
    customer_name = serializers.SerializerMethodField()
    customer_phone = serializers.SerializerMethodField()
    equipment_name = serializers.SerializerMethodField()
    has_report = serializers.SerializerMethodField()
    report_id = serializers.SerializerMethodField()
    scheduled_at_jalali = serializers.SerializerMethodField()
    created_at_jalali = serializers.SerializerMethodField()  # ✅ جدید
    can_submit = serializers.SerializerMethodField()

    class Meta:
        model = InspectionRequest
        fields = (
            'id',
            'request_number',
            'customer_name',
            'customer_phone',
            'equipment_name',
            'brand_model',
            'manufacture_year',
            'params',
            'install_state',
            'service_type',
            'city',
            'address',
            'address_lat',
            'address_lng',
            'scheduled_at_jalali',
            'status',
            'final_price',
            'created_at',
            'created_at_jalali',  # ✅ جدید
            'has_report',
            'report_id',
            'can_submit')

    def get_scheduled_at_jalali(self, obj):
        """نمایش زمان بازرسی با فرمت شامل ساعت"""
        if obj.scheduled_at:
            return to_jalali(obj.scheduled_at, "%Y/%m/%d %H:%M")
        return None

    def get_created_at_jalali(self, obj):
        """نمایش تاریخ ایجاد با فرمت شامل ساعت"""
        if obj.created_at:
            return to_jalali(obj.created_at, "%Y/%m/%d %H:%M")
        return None

    def get_customer_name(self, obj):
        return obj.customer.get_full_name() or obj.customer.username

    def get_customer_phone(self, obj):
        return obj.customer.username

    def get_equipment_name(self, obj):
        return obj.equipment_type.name_fa if obj.equipment_type else "نامشخص"

    def get_has_report(self, obj):
        return hasattr(obj, 'report')

    def get_report_id(self, obj):
        return obj.report.id if hasattr(obj, 'report') else None

    def get_can_submit(self, obj):
        """آیا کارشناس هم‌اکنون می‌تواند گزارش ثبت کند؟ (فرانت فرم را فقط
        در این حالت نشان می‌دهد؛ قبلاً فرم برای هر وضعیتی باز بود و کارشناس
        بعد از پر کردن کل چک‌لیست خطا می‌گرفت.)"""
        return obj.status in EXPERT_EXECUTABLE_STATUSES and not hasattr(
            obj, 'report')


# ============================================================
# ویوها
# ============================================================


def _require_expert(user):
    """کارشناس/استاف/ادمین؛ در غیر این صورت None (caller ۴۰۳ می‌دهد)."""
    return bool(
        user.is_staff or is_admin_user(user)
        or user.groups.filter(name='Expert').exists())


def _expert_tasks(user):
    return InspectionRequest.objects.filter(assigned_expert=user).exclude(
        params__is_deposit=True)


class ExpertDashboardView(generics.GenericAPIView):
    permission_classes = [IsAuthenticated]

    def get(self, request):
        user = request.user
        if not _require_expert(user):
            return Response({'error': 'دسترسی غیرمجاز'}, status=403)

        tasks = _expert_tasks(user)
        total = tasks.count()
        # «در انتظار انجام»: همه‌ی وضعیت‌هایی که کارشناس باید روی آن‌ها کار
        # کند (قبلاً فقط scheduled؛ درخواست‌های assigned/rescheduled جا
        # می‌افتادند).
        pending = tasks.filter(
            status__in=['paid', 'assigned', 'scheduled', 'rescheduled']
        ).count()
        in_progress = tasks.filter(status='in_progress').count()
        completed = tasks.filter(status='completed').count()
        # گزارش‌های ثبت‌شده توسط کارشناس (قبلاً signed_by=user بود؛ signed_by
        # هنگام ثبت خالی است و فقط بعد از امضا پر می‌شود → همیشه ۰).
        reports_count = InspectionReport.objects.filter(
            inspection_request__assigned_expert=user).count()

        recent = tasks.select_related(
            'customer', 'equipment_type', 'report').order_by('-created_at')[:5]
        recent_data = ExpertTaskSerializer(recent, many=True).data

        return Response({
            'statistics': {
                'total_assigned': total,
                'pending': pending,
                'in_progress': in_progress,
                'completed': completed,
                'reports_count': reports_count
            },
            'recent_tasks': recent_data,
            'user': {
                'id': user.id,
                'username': user.username,
                'full_name': user.get_full_name() or user.username,
                'date_joined_jalali': to_jalali(user.date_joined, "%Y/%m/%d %H:%M") if user.date_joined else None,
                'last_login_jalali': to_jalali(user.last_login, "%Y/%m/%d %H:%M") if user.last_login else None,
            }
        })


class ExpertTaskListView(generics.GenericAPIView):
    permission_classes = [IsAuthenticated]
    PAGE_SIZE = 25  # هم‌اندازه‌ی پیش‌فرض کامپوننت Pagination فرانت (۲۵)

    def get(self, request):
        user = request.user
        if not _require_expert(user):
            return Response({'error': 'دسترسی غیرمجاز'}, status=403)

        status_filter = request.query_params.get('status', '')
        search = request.query_params.get('search', '').strip()

        queryset = _expert_tasks(user).select_related(
            'customer', 'equipment_type', 'report')
        if status_filter:
            queryset = queryset.filter(status=status_filter)
        if search:
            queryset = queryset.filter(
                Q(customer__username__icontains=search)
                | Q(brand_model__icontains=search)
                | Q(request_number__icontains=search))

        queryset = queryset.order_by('-created_at', '-id')

        # صفحه‌بندی واقعی. قبلاً پارامتر page نادیده گرفته می‌شد و کل لیست
        # در هر صفحه تکرار می‌شد (فرانت صفحه‌بندی نشان می‌داد ولی صفحه‌ی ۲ =
        # صفحه‌ی ۱).
        try:
            page = max(1, int(request.query_params.get('page', 1)))
        except (TypeError, ValueError):
            page = 1
        total = queryset.count()
        start = (page - 1) * self.PAGE_SIZE
        items = list(queryset[start:start + self.PAGE_SIZE])
        serializer = ExpertTaskSerializer(items, many=True)
        return Response({
            'tasks': serializer.data,
            'count': total,
            'page': page,
            'page_size': self.PAGE_SIZE,
        })


class ExpertTaskDetailView(generics.GenericAPIView):
    permission_classes = [IsAuthenticated]

    def get(self, request, task_id):
        user = request.user
        try:
            task = InspectionRequest.objects.select_related(
                'customer', 'equipment_type', 'report').get(
                id=task_id, assigned_expert=user)
        except InspectionRequest.DoesNotExist:
            return Response({'error': 'وظیفه یافت نشد'}, status=404)

        # اگر گزارش از قبل با نسخه‌ی مشخصی از قالب شروع شده، همان قالب؛
        # وگرنه جدیدترین قالب فعال (هم‌خوان با سرویس ثبت نتایج).
        report = getattr(task, 'report', None)
        template = (report.checklist_template_version if report
                    and report.checklist_template_version_id else None)
        if template is None:
            template = ChecklistTemplate.objects.filter(
                equipment_type=task.equipment_type,
                is_active=True).order_by('-version').first()
        existing_report = None
        if report is not None:
            existing_report = {
                'id': report.id,
                'report_number': report.report_number,
                'overall_result': report.overall_result,
                'pdf_ready': bool(report.signed_pdf_file or report.pdf_file),
                'signed': bool(report.signed_at),
            }

        checklist_data = None
        if template:
            items = ChecklistItem.objects.filter(
                checklist_template=template,
                is_active=True).select_related('category').order_by(
                'category__order', 'order', 'id')
            checklist_data = {
                'id': template.id,
                'name': template.name,
                'version': template.version,
                'items': [{
                    'id': i.id,
                    # category یک FK است؛ نام آن به فرانت داده می‌شود (قبلاً
                    # خود شیء مدل در JSON می‌رفت → خطای سریالایز/۵۰۰).
                    'category': i.category.name if i.category_id else 'سایر',
                    'title': i.title,
                    'description': i.description,
                    'requires_photo': i.requires_photo,
                    'requires_note': i.requires_note,
                    'is_critical': i.is_critical,
                } for i in items]
            }

        from ..utils.geo import gps_antifraud_enabled
        return Response({
            'task': ExpertTaskSerializer(task).data,
            'checklist_template': checklist_data,
            'existing_report': existing_report,
            'gps_enabled': gps_antifraud_enabled(),
        })


class ExpertStartInspectionView(generics.GenericAPIView):
    permission_classes = [IsAuthenticated]

    def post(self, request, task_id):
        user = request.user
        try:
            task = InspectionRequest.objects.get(
                id=task_id, assigned_expert=user)
        except InspectionRequest.DoesNotExist:
            return Response({'error': 'وظیفه یافت نشد'}, status=404)

        if task.status == 'in_progress':
            return Response({'success': True, 'status': task.status})
        # قبلاً فقط scheduled/paid؛ وضعیت assigned (که خودِ تخصیص ادمین
        # می‌ساخت) اجازه‌ی شروع نداشت و کارشناس هرگز نمی‌توانست کار را شروع کند.
        if task.status not in EXPERT_EXECUTABLE_STATUSES:
            label = dict(task.STATUS_CHOICES).get(task.status, task.status)
            return Response(
                {'error': f'وضعیت «{label}» اجازه‌ی شروع بازرسی را نمی‌دهد.'},
                status=400)
        try:
            apply_status_change(
                task, 'in_progress', actor=user, force=True,
                reason='شروع بازرسی توسط کارشناس')
        except Exception as exc:
            logger.error(f'start inspection failed task={task_id}: {exc}')
            return Response({'error': 'شروع بازرسی انجام نشد.'}, status=500)
        return Response({'success': True, 'status': task.status})


class ExpertSubmitChecklistView(generics.GenericAPIView):
    permission_classes = [IsAuthenticated]
    parser_classes = [MultiPartParser, FormParser]

    def post(self, request):
        """
        ثبت چک‌لیست از سرویس یکپارچه report_service.submit_checklist
        (همه‌ی قوانین سمت سرور enforce می‌شود؛ جزئیات در همان سرویس).
        تولید PDF بعد از commit در صف Celery قرار می‌گیرد؛ شکست صف، ثبت
        گزارش را خراب نمی‌کند.
        """
        from ..services.report_service import (
            submit_checklist, ChecklistSubmissionError)

        user = request.user
        task_id = request.data.get('request_id')
        results = request.data.get('results')
        if not task_id or results is None:
            return Response({'error': 'اطلاعات کامل نیست'}, status=400)
        try:
            task_id = int(task_id)
        except (TypeError, ValueError):
            return Response({'error': 'شناسه‌ی درخواست نامعتبر است.'}, status=400)

        try:
            task = InspectionRequest.objects.select_related(
                'equipment_type').get(id=task_id, assigned_expert=user)
        except InspectionRequest.DoesNotExist:
            return Response({'error': 'وظیفه یافت نشد'}, status=404)

        try:
            result = submit_checklist(
                user=user,
                task=task,
                results=results,
                overall_result=request.data.get('overall_result'),
                inspector_notes=(request.data.get('inspector_notes', '') or '')[:5000],
                request=request,
                gps_start_lat=request.data.get('gps_start_lat'),
                gps_start_lng=request.data.get('gps_start_lng'),
                gps_end_lat=request.data.get('gps_end_lat'),
                gps_end_lng=request.data.get('gps_end_lng'),
                inspection_started_at=request.data.get(
                    'inspection_started_at'),
            )
        except ChecklistSubmissionError as e:
            return Response({'error': str(e)}, status=e.status_code)
        except Exception as e:
            logger.error(f"submit_checklist error task={task_id}: {e}",
                         exc_info=True)
            return Response({'error': 'خطای داخلی در ثبت گزارش.'}, status=500)

        report_id = result['report_id']

        def _queue_pdf():
            try:
                from ..tasks import generate_report_pdf_task
                generate_report_pdf_task.delay(report_id, user.id)
            except Exception as pdf_q_error:
                logger.error(
                    f"Error queueing report PDF (report {report_id}): "
                    f"{pdf_q_error}")
        transaction.on_commit(_queue_pdf)

        return Response({'success': True, **result})


class ExpertGenerateReportView(generics.GenericAPIView):
    """
    دانلود PDF گزارش برای کارشناسِ تخصیص‌یافته/ادمین.

    EDRA v34: قبلاً با قالب جداگانه‌ی expert_report_pdf.html هر بار یک PDF
    «دیگر» (متفاوت با نسخه‌ی مشتری/امضاشده) تولید می‌شد، weasyprint در سطح ماژول
    import می‌شد (نبود کتابخانه‌های سیستمی، کل API را از کار می‌انداخت)، متن خام
    استثنا به کلاینت می‌رفت و ادمین دسترسی نداشت. حالا همان فایل رسمی ذخیره‌شده
    (امضاشده یا تولیدشده) سرو می‌شود؛ اگر هنوز ساخته نشده باشد با مولد رسمی
    تولید می‌شود.
    """
    permission_classes = [IsAuthenticated]

    def get(self, request, report_id):
        user = request.user
        try:
            report = InspectionReport.objects.select_related(
                'inspection_request').get(id=report_id)
        except InspectionReport.DoesNotExist:
            return Response({'error': 'گزارش یافت نشد'}, status=404)

        req = report.inspection_request
        if req.assigned_expert_id != user.id and not is_admin_user(user):
            return Response({'error': 'دسترسی غیرمجاز'}, status=403)

        from ..utils.http_headers import build_content_disposition
        disposition = build_content_disposition(
            f'گزارش_{report.report_number}.pdf',
            f'report_{report.report_number}.pdf')

        stored = report.signed_pdf_file or report.pdf_file
        if stored:
            try:
                response = FileResponse(
                    stored.open('rb'), content_type='application/pdf')
                response['Content-Disposition'] = disposition
                return response
            except (FileNotFoundError, OSError):
                logger.error(f'Report PDF missing on disk: {report.pk}')

        try:
            from ..report_pdf_generator import generate_report_pdf
            pdf = generate_report_pdf(
                report=report, inspection_request=req,
                customer=req.customer, equipment=req.equipment_type,
                checklist_items=report.results or [])
        except Exception as e:
            logger.error(f'Report PDF generation failed {report.pk}: {e}',
                         exc_info=True)
            return Response(
                {'error': 'تولید PDF گزارش با خطا مواجه شد؛ لطفاً دوباره '
                          'تلاش کنید.'}, status=500)
        # PDF ساخته‌شده ذخیره می‌شود تا مشتری هم بتواند دانلود کند (بازیابی
        # دستی وقتی تسک Celery شکست خورده است؛ بدون ساز و کار اضافه).
        if not report.signed_at and not report.pdf_file:
            from django.core.files.base import ContentFile
            report.pdf_file.save(
                f'report_{report.report_number}.pdf', ContentFile(pdf),
                save=False)
            report.save(update_fields=['pdf_file', 'updated_at'])
        response = HttpResponse(pdf, content_type='application/pdf')
        response['Content-Disposition'] = disposition
        return response


class ExpertHistoryView(generics.GenericAPIView):
    permission_classes = [IsAuthenticated]
    MAX_LIMIT = 100

    def get(self, request):
        user = request.user
        try:
            limit = int(request.query_params.get('limit', 20))
            offset = int(request.query_params.get('offset', 0))
        except (TypeError, ValueError):
            return Response({'error': 'limit/offset نامعتبر است.'}, status=400)
        limit = max(1, min(limit, self.MAX_LIMIT))
        offset = max(0, offset)

        queryset = _expert_tasks(user).filter(
            status='completed').select_related(
            'customer', 'equipment_type', 'report').order_by(
            '-updated_at', '-id')
        total = queryset.count()
        items = queryset[offset:offset + limit]
        serializer = ExpertTaskSerializer(items, many=True)
        return Response({
            'history': serializer.data,
            'total': total,
            'limit': limit,
            'offset': offset
        })


class ExpertProfileView(generics.GenericAPIView):
    permission_classes = [IsAuthenticated]

    def get(self, request):
        user = request.user
        return Response({
            'id': user.id,
            'username': user.username,
            'first_name': user.first_name,
            'last_name': user.last_name,
            'full_name': user.get_full_name() or user.username,
            'email': user.email,
            'date_joined': user.date_joined,
            'date_joined_jalali': to_jalali(user.date_joined, "%Y/%m/%d %H:%M") if user.date_joined else None,
            'last_login': user.last_login,
            'last_login_jalali': to_jalali(user.last_login, "%Y/%m/%d %H:%M") if user.last_login else None,
            'groups': [g.name for g in user.groups.all()]
        })

    def put(self, request):
        user = request.user
        data = request.data
        fields = []
        for name, max_len in (('first_name', 150), ('last_name', 150)):
            if name in data:
                value = str(data.get(name) or '').strip()
                if len(value) > max_len:
                    return Response(
                        {'error': f'{name} بیش از حد مجاز است.'}, status=400)
                setattr(user, name, value)
                fields.append(name)
        if 'email' in data:
            email = str(data.get('email') or '').strip()
            if email:
                from django.core.validators import validate_email
                from django.core.exceptions import ValidationError as DjErr
                try:
                    validate_email(email)
                except DjErr:
                    return Response(
                        {'error': 'ایمیل نامعتبر است.'}, status=400)
            user.email = email
            fields.append('email')
        if fields:
            user.save(update_fields=fields)
        return Response({'success': True})


class ExpertChangePasswordView(generics.GenericAPIView):
    permission_classes = [IsAuthenticated]
    # EDRA v36: محدودیت حدس old_password (قبلاً throttle اختصاصی نداشت).
    from rest_framework.throttling import ScopedRateThrottle as _SRT
    throttle_classes = [_SRT]
    throttle_scope = 'password_change'

    def post(self, request):
        user = request.user
        old = request.data.get('old_password')
        new = request.data.get('new_password')
        confirm = request.data.get('confirm_password')

        if not old or not new or not confirm:
            return Response({'error': 'همه فیلدها پر شوند'}, status=400)
        if new != confirm:
            return Response({'error': 'رمزها مطابقت ندارند'}, status=400)
        if not user.check_password(old):
            return Response({'error': 'رمز فعلی اشتباه است'}, status=400)

        # EDRA v27 — رفع باگ امنیتی واقعی (بازبینی دوم، سپتامبر ۲۰۲۶):
        # AUTH_PASSWORD_VALIDATORS در settings.py کامل تعریف شده بود
        # (حداقل ۱۲ کاراکتر، رد رمزهای رایج، ...) ولی هیچ‌جا برای این
        # endpoint واقعاً فراخوانی نمی‌شد — یعنی رمز جدید بدون هیچ بررسی
        # قدرتی مستقیم set_password می‌شد.
        from django.contrib.auth.password_validation import validate_password
        from django.core.exceptions import ValidationError as DjangoValidationError
        try:
            validate_password(new, user=user)
        except DjangoValidationError as e:
            return Response({'error': ' '.join(e.messages)}, status=400)

        user.set_password(new)
        user.save()
        # P1-07 (EDRA v8): باطل کردن همه refresh token های قبلی
        from ..security import revoke_user_refresh_tokens
        revoke_user_refresh_tokens(user)
        return Response({'success': True})


class SuggestExpertsForRequestView(generics.GenericAPIView):
    """
    GET /api/expert/suggest/<request_id>/
    پیشنهاد هوشمند کارشناس برای یک درخواست خاص - برای کاهش دخالت دستی
    مدیر (طبق سرویس Assignment در سند معماری): بر اساس پوشش شهر، تجربه‌ی
    قبلی با همین نوع تجهیز، و بار کاری فعلی (کمتر = در دسترس‌تر) رتبه‌بندی
    می‌شود. تصمیم نهایی همچنان با مدیر است - این فقط لیست را برایش
    اولویت‌بندی می‌کند تا مجبور نباشد بین همه کارشناس‌ها دستی بگردد.
    """
    permission_classes = [IsAdminUserOrGroup]

    def get(self, request, request_id):
        try:
            target = InspectionRequest.objects.select_related(
                'equipment_type').get(id=request_id)
        except InspectionRequest.DoesNotExist:
            return Response({'error': 'درخواست یافت نشد'}, status=404)

        experts = User.objects.filter(
            groups__name='Expert', is_active=True
        ).select_related('profile').prefetch_related('profile__covered_cities')

        suggestions = []

        # EDRA v24 (گزارش V23 — N+1): قبلاً برای هر کارشناس ۳ کوئری جدا
        # زده می‌شد (۳N+2) و prefetch شهرها با .filter() دوباره بی‌اثر
        # می‌شد. حالا aggregate یک‌باره قبل از حلقه + استفاده از cache
        # پیش‌بارگذاری‌شده → کل endpoint بدون توجه به N، ۴ کوئری ثابت.
        expert_ids = [exp.id for exp in experts]
        workloads = dict(
            InspectionRequest.objects.filter(
                assigned_expert_id__in=expert_ids,
                status__in=['assigned', 'scheduled', 'in_progress'],
            ).values('assigned_expert_id').annotate(
                c=Count('id')).values_list('assigned_expert_id', 'c'))
        experiences = dict(
            InspectionReport.objects.filter(
                inspection_request__assigned_expert_id__in=expert_ids,
                inspection_request__equipment_type=target.equipment_type,
            ).values('inspection_request__assigned_expert_id').annotate(
                c=Count('id')).values_list(
                'inspection_request__assigned_expert_id', 'c'))

        for exp in experts:
            profile = getattr(exp, 'profile', None)
            covers_city = False
            if profile:
                # استفاده از cache پیش‌بارگذاری‌شده (prefetch) — بدون کوئری
                # جدید؛ فیلتر در پایتون انجام می‌شود نه در دیتابیس.
                covered_city_ids = {
                    c.city for c in profile.covered_cities.all()}
                covers_city = target.city in covered_city_ids

            active_workload = workloads.get(exp.id, 0)
            equipment_experience = experiences.get(exp.id, 0)

            # امتیازدهی ساده: پوشش شهر مهم‌ترین عامل، بعد تجربه، بعد بار کاری کمتر
            score = (
                (100 if covers_city else 0)
                + min(equipment_experience * 10, 50)
                - min(active_workload * 15, 60)
            )

            suggestions.append({
                'expert_id': exp.id,
                'name': exp.get_full_name() or exp.username,
                'phone': getattr(profile, 'phone', None),
                'covers_city': covers_city,
                'equipment_experience': equipment_experience,
                'active_workload': active_workload,
                'score': score,
            })

        suggestions.sort(key=lambda s: s['score'], reverse=True)

        return Response({
            'request_id': target.id,
            'request_number': target.request_number,
            'city': target.city,
            'equipment_type': target.equipment_type.name_fa if target.equipment_type else None,
            'suggestions': suggestions[:10],
        })
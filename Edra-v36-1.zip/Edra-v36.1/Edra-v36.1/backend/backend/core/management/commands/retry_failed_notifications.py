# backend/core/management/commands/retry_failed_notifications.py
# -*- coding: utf-8 -*-
from django.core.management.base import BaseCommand

from notifications.models import NotificationLog
from notifications.services import deliver_log


class Command(BaseCommand):
    help = 'تلاش مجدد برای ارسال نوتیفیکیشن‌های ناموفق (status=failed)'

    def add_arguments(self, parser):
        parser.add_argument(
            '--limit', type=int, default=100,
            help='حداکثر تعداد لاگ برای تلاش مجدد (پیش‌فرض ۱۰۰)')
        parser.add_argument(
            '--log-id', type=int, default=None,
            help='تلاش مجدد فقط برای یک لاگ خاص')

    def handle(self, *args, **options):
        qs = NotificationLog.objects.filter(status='failed')
        if options['log_id']:
            qs = qs.filter(id=options['log_id'])
        ids = list(qs.order_by('-created_at').values_list(
            'id', flat=True)[:options['limit']])

        success = failed = 0
        for pk in ids:
            # EDRA v33: همان لاگ با همان محتوای رندرشده دوباره ارسال می‌شود.
            # نسخه‌ی قبلی send_notification(user, log.type) را بدون context
            # صدا می‌زد (متن با متغیرهای خالی) و یک لاگ *جدید* می‌ساخت، در حالی
            # که لاگ ناموفق اصلی برای همیشه failed می‌ماند (تکرار بی‌پایان).
            NotificationLog.objects.filter(pk=pk, status='failed').update(
                status='pending', error_message='')
            log = NotificationLog.objects.get(pk=pk)
            result = deliver_log(log)
            if result.status == 'sent':
                success += 1
                self.stdout.write(f"  ✓ retry #{pk} ({log.type})")
            else:
                failed += 1
                self.stdout.write(f"  ✗ retry #{pk}: {result.error_message}")

        self.stdout.write(self.style.SUCCESS(
            f"Retry done: {success} ok, {failed} failed (از {len(ids)} مورد)."))

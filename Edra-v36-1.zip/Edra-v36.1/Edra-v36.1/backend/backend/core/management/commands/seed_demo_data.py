# backend/core/management/commands/seed_demo_data.py
"""
داده اولیه برای محیط توسعه/دمو: تجهیزات، پارامترها، قوانین قیمت،
شهرها، کاربران نمونه، قالب‌های اعلان، و (EDRA v25 — جدید) قالب چک‌لیست
واقعی + سناریوهای کاری کامل برای تست دستی (درخواست در انتظار پرداخت،
درخواست تکمیل‌شده با گزارش، و یک تیکت پشتیبانی باز).

استفاده:
  python manage.py seed_demo_data --with-users
"""
from decimal import Decimal

from django.contrib.auth import get_user_model
from django.core.management import call_command
from django.core.management.base import BaseCommand
from django.db import transaction

from core.models import (
    CityMultiplier, EquipmentParameter, EquipmentType, UserProfile,
    ChecklistTemplate, ChecklistItem, InspectionRequest, InspectionReport,
    ChecklistCategory,  # ✅ اضافه شد
)
from pricing.models import ParameterPrice, PricingRule

User = get_user_model()

# EDRA v25: رمز عبور یکسان و مشخص برای کاربران دمو
DEMO_PASSWORD = 'EdraDemo@1404'

CHECKLIST_ITEMS = [
    # (دسته‌بندی, عنوان, توضیح, نیاز به عکس, نیاز به یادداشت, حیاتی)
    ('سازه فلزی', 'بررسی سلامت جوش‌های اتصال برج', 'بازرسی چشمی ترک/خوردگی در نقاط اتصال', True, False, True),
    ('سازه فلزی', 'بررسی پیچ و مهره‌های اصلی', 'گشتاور و شل‌نبودن اتصالات', False, True, True),
    ('سیستم بالابر', 'تست ترمز موتور اصلی', 'توقف کامل زیر بار نامی', True, True, True),
    ('سیستم بالابر', 'بازرسی سیم‌بکسل اصلی', 'بررسی سایش/پارگی رشته‌ها', True, False, True),
    ('ایمنی', 'وجود و اعتبار لیمیت‌سوئیچ‌ها', '', False, False, True),
    ('ایمنی', 'کپسول اطفا حریق و تاریخ شارژ', '', True, False, False),
    ('مدارک', 'گواهی سلامت فنی قبلی', 'تطبیق با شرایط فعلی', True, True, False),
]


class Command(BaseCommand):
    help = 'Seed داده اولیه دمو (تجهیزات/قیمت/شهر/چک‌لیست/سناریوهای کاری/کاربران اختیاری)'

    def add_arguments(self, parser):
        parser.add_argument(
            '--with-users', action='store_true',
            help='ساخت کاربران نمونه (admin/expert/customer) با رمز قابل‌استفاده')
        parser.add_argument(
            '--with-scenarios', action='store_true',
            help='ساخت سناریوهای کاری نمونه (نیازمند --with-users)')

    EQUIPMENT = [
        # (code, name_fa, base_price, [params: (name, label, rate)])
        ('tower_crane', 'جرثقیل برجی', 1500000, [
            ('capacity', 'ظرفیت (تن)', 200000),
            ('height', 'ارتفاع (متر)', 50000),
        ]),
        ('mobile_crane', 'جرثقیل سیار', 1200000, [
            ('capacity', 'ظرفیت (تن)', 150000),
        ]),
        ('excavator', 'بیل مکانیکی', 900000, [
            ('weight', 'وزن (تن)', 80000),
        ]),
        ('wheel_loader', 'لودر چرخ لاستیکی', 800000, [
            ('bucket_capacity', 'ظرفیت جام (مترمکعب)', 100000),
        ]),
        ('forklift', 'لیفتراک', 600000, [
            ('capacity', 'ظرفیت (تن)', 70000),
        ]),
    ]

    CITIES = [
        ('تهران', Decimal('1.0'), 200000),
        ('کرج', Decimal('1.0'), 150000),
        ('اصفهان', Decimal('1.05'), 180000),
        ('مشهد', Decimal('1.05'), 160000),
        ('شیراز', Decimal('1.05'), 160000),
        ('تبریز', Decimal('1.0'), 150000),
    ]

    @transaction.atomic
    def handle(self, *args, **options):
        # ---------- تجهیزات + قیمت ----------
        equipment_objs = {}
        for code, name_fa, base, params in self.EQUIPMENT:
            eq, created = EquipmentType.objects.get_or_create(
                code=code,
                defaults={'name_fa': name_fa, 'param_schema': [
                    {'key': k, 'label_fa': lbl, 'unit': ''}
                    for k, lbl, _ in params]})
            equipment_objs[code] = eq
            rule, _ = PricingRule.objects.get_or_create(
                equipment_type=eq,
                defaults={
                    'base_price': base,
                    'standard_multiplier': Decimal('1.0'),
                    'pro_multiplier': Decimal('1.2'),
                })
            for name, label, rate in params:
                param, _ = EquipmentParameter.objects.get_or_create(
                    equipment_type=eq, name=name,
                    defaults={'label': label, 'field_type': 'number'})
                ParameterPrice.objects.get_or_create(
                    pricing_rule=rule, parameter=param,
                    defaults={'rate_type': 'per_unit', 'rate': rate})
            self.stdout.write(f"  ✓ {code} ({name_fa})")

        # ---------- شهرها ----------
        for city, mult, base_cost in self.CITIES:
            CityMultiplier.objects.get_or_create(
                city=city,
                defaults={'multiplier': mult, 'base_cost': base_cost})
        self.stdout.write("  ✓ city multipliers")

        # ---------- قالب‌های اعلان ----------
        call_command('seed_notification_templates')
        self.stdout.write("  ✓ notification templates")

        # ============================================================
        # ✅ بخش اصلاح‌شده: ایجاد دسته‌بندی‌های چک‌لیست و آیتم‌ها
        # ============================================================
        # ۱. ابتدا دسته‌بندی‌های موردنیاز را ایجاد یا دریافت می‌کنیم
        category_names = set(item[0] for item in CHECKLIST_ITEMS)
        category_map = {}
        for cat_name in category_names:
            cat, _ = ChecklistCategory.objects.get_or_create(
                name=cat_name,
                defaults={'is_active': True}
            )
            category_map[cat_name] = cat

        # ۲. قالب چک‌لیست را ایجاد می‌کنیم
        tower_crane_template, created = ChecklistTemplate.objects.get_or_create(
            name='بازرسی استاندارد جرثقیل برجی',
            equipment_type=equipment_objs['tower_crane'],
            defaults={
                'description': 'قالب نمونه — تولیدشده توسط seed_demo_data',
                'version': 1,
                'is_active': True,
            },
        )

        # ۳. آیتم‌های چک‌لیست را با دسته‌بندی صحیح ایجاد می‌کنیم
        if created or not tower_crane_template.items.exists():
            for order, (cat_name, title, desc, need_photo, need_note, critical) in enumerate(CHECKLIST_ITEMS, start=1):
                category_obj = category_map.get(cat_name)
                ChecklistItem.objects.get_or_create(
                    checklist_template=tower_crane_template,
                    title=title,
                    defaults={
                        'category': category_obj,
                        'description': desc,
                        'order': order,
                        'requires_photo': need_photo,
                        'requires_note': need_note,
                        'is_critical': critical,
                        'is_active': True,
                    },
                )
        self.stdout.write(
            f"  ✓ checklist template «{tower_crane_template.name}» "
            f"({tower_crane_template.items.count()} آیتم)")

        # ---------- گروه‌ها و کاربران نمونه (اختیاری) ----------
        demo_users = {}
        if options['with_users']:
            call_command('setup_expert_group')
            from django.contrib.auth.models import Group
            Group.objects.get_or_create(name='Admin')

            users = [
                ('09120000000', 'demo_admin', 'Admin'),
                ('09120000001', 'demo_expert', 'Expert'),
                ('09120000002', 'demo_customer', None),
            ]
            for phone, username, group_name in users:
                user, created = User.objects.get_or_create(
                    username=username, defaults={'is_staff': group_name == 'Admin'})
                user.set_password(DEMO_PASSWORD)
                if group_name == 'Admin':
                    user.is_staff = True
                    user.is_superuser = True
                user.save()
                if group_name:
                    user.groups.add(Group.objects.get(name=group_name))
                UserProfile.objects.get_or_create(
                    user=user, defaults={'phone': phone})
                demo_users[username] = user
                self.stdout.write(
                    f"  ✓ user {username} / رمز: {DEMO_PASSWORD} "
                    f"(تازه‌ساخت: {created})")

        # ---------- سناریوهای کاری نمونه ----------
        if options['with_users'] and options['with_scenarios']:
            self._seed_scenarios(demo_users, equipment_objs, tower_crane_template)
        elif options['with_scenarios'] and not options['with_users']:
            self.stdout.write(self.style.WARNING(
                "  ⚠ --with-scenarios نیازمند --with-users هم هست؛ سناریوها ساخته نشدند."))

        self.stdout.write(self.style.SUCCESS("Seed demo data: done."))

    def _seed_scenarios(self, demo_users, equipment_objs, checklist_template):
        customer = demo_users.get('demo_customer')
        expert = demo_users.get('demo_expert')
        if not customer:
            return

        common_kwargs = dict(
            customer=customer,
            equipment_type=equipment_objs['tower_crane'],
            city='تهران',
            address='تهران، بزرگراه چمران، کارگاه نمونه',
            calculated_price=1500000,
            final_price=1500000,
        )

        # سناریو ۱: در انتظار پرداخت
        try:
            with transaction.atomic():
                req, created = InspectionRequest.objects.get_or_create(
                    title='بازرسی جرثقیل برجی — کارگاه نمونه (در انتظار پرداخت)',
                    customer=customer,
                    defaults={**common_kwargs, 'status': 'pending_payment'},
                )
                self.stdout.write(
                    f"  ✓ سناریو «در انتظار پرداخت»: {req.request_number or req.id} "
                    f"(تازه‌ساخت: {created})")
        except Exception as exc:
            self.stdout.write(self.style.WARNING(
                f"  ⚠ سناریو «در انتظار پرداخت» ساخته نشد: {exc}"))

        # سناریو ۲: تکمیل‌شده با گزارش امضاشده
        try:
            with transaction.atomic():
                req, created = InspectionRequest.objects.get_or_create(
                    title='بازرسی جرثقیل برجی — کارگاه نمونه (تکمیل‌شده)',
                    customer=customer,
                    defaults={
                        **common_kwargs,
                        'status': 'completed',
                        'assigned_expert': expert,
                    },
                )
                if created or not InspectionReport.objects.filter(inspection_request=req).exists():
                    from django.utils import timezone as dj_timezone
                    InspectionReport.objects.get_or_create(
                        inspection_request=req,
                        defaults={
                            'report_number': f'RPT-DEMO-{req.id}',
                            'checklist_template_version': checklist_template,
                            'overall_result': 'pass',
                            'inspector_notes': 'گزارش نمونه — تولیدشده توسط seed_demo_data.',
                            'inspection_started_at': dj_timezone.now(),
                            'inspection_ended_at': dj_timezone.now(),
                            'signed_at': dj_timezone.now(),
                            'signed_by': expert,
                        },
                    )
                self.stdout.write(
                    f"  ✓ سناریو «تکمیل‌شده با گزارش»: {req.request_number or req.id} "
                    f"(تازه‌ساخت: {created})")
        except Exception as exc:
            self.stdout.write(self.style.WARNING(
                f"  ⚠ سناریو «تکمیل‌شده با گزارش» ساخته نشد: {exc}"))

        # سناریو ۳: تیکت پشتیبانی باز
        try:
            with transaction.atomic():
                call_command('init_ticket_data')
                from support.models import (
                    Ticket, TicketCategory, TicketPriority, TicketStatus)
                category = TicketCategory.objects.filter(name='فنی').first()
                priority = TicketPriority.objects.filter(name='متوسط').first()
                open_status = TicketStatus.objects.filter(name='باز').first()
                if category and priority and open_status:
                    ticket, created = Ticket.objects.get_or_create(
                        title='مشکل در نمایش گزارش بازرسی',
                        customer=customer,
                        defaults={
                            'description': 'تیکت نمونه — تولیدشده توسط seed_demo_data.',
                            'category': category,
                            'priority': priority,
                            'status': open_status,
                        },
                    )
                    self.stdout.write(
                        f"  ✓ سناریو «تیکت باز»: #{ticket.id} (تازه‌ساخت: {created})")
                else:
                    self.stdout.write(self.style.WARNING(
                        "  ⚠ سناریو «تیکت باز» ساخته نشد: داده‌ی اولیه‌ی تیکتینگ ناقص است."))
        except Exception as exc:
            self.stdout.write(self.style.WARNING(
                f"  ⚠ سناریو «تیکت باز» ساخته نشد: {exc}"))
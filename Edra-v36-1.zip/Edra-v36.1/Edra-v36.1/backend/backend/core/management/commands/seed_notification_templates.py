# backend/core/management/commands/seed_notification_templates.py
# -*- coding: utf-8 -*-
from django.core.management.base import BaseCommand

from notifications.defaults import DEFAULT_TEMPLATES
from notifications.models import NotificationTemplate


class Command(BaseCommand):
    help = ('ساخت قالب‌های پیش‌فرض اعلان (idempotent). از v33 همین کار خودکار '
            'با migration notifications.0004 انجام می‌شود؛ این دستور برای '
            'بازسازی قالب‌های حذف‌شده است. قالب‌های موجود بازنویسی نمی‌شوند.')

    def handle(self, *args, **options):
        # منبع واحد: notifications/defaults.py (قالب‌ها با سینتکس Django Template)
        for t in DEFAULT_TEMPLATES:
            _, created = NotificationTemplate.objects.get_or_create(
                code=t['code'],
                defaults={
                    'channel': t['channel'],
                    'subject': t['subject'],
                    'body_template': t['body_template'],
                    'is_active': True,
                })
            if created:
                self.stdout.write(
                    self.style.SUCCESS(f'Created template: {t["code"]}'))
            else:
                self.stdout.write(
                    self.style.WARNING(f'Template {t["code"]} already exists'))

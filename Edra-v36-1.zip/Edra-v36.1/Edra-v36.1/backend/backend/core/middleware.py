# ============================================================
# ۲. فایل core/middleware.py (جدید)
# ============================================================
import uuid
import logging
import traceback
from django.conf import settings
from django.utils import timezone
from django.http import JsonResponse
from django.core.exceptions import MiddlewareNotUsed
from .models import ErrorLog
from .logging import set_request_id

logger = logging.getLogger(__name__)


def _client_ip(request):
    """
    EDRA v32 — IP واقعی کلاینت با احترام به NUM_PROXIES (همان تنظیمی که
    throttleهای DRF استفاده می‌کنند). بدون آن، لاگ خطا/ممیزی همیشه IP
    داخلی کانتینر Nginx/Next را ثبت می‌کرد.
    """
    remote = request.META.get('REMOTE_ADDR', '')
    try:
        num_proxies = int(
            getattr(settings, 'REST_FRAMEWORK', {}).get('NUM_PROXIES') or 0)
    except (TypeError, ValueError):
        num_proxies = 0
    forwarded = request.META.get('HTTP_X_FORWARDED_FOR')
    if num_proxies <= 0 or not forwarded:
        return remote
    addrs = [a.strip() for a in forwarded.split(',') if a.strip()]
    if not addrs:
        return remote
    return addrs[-min(num_proxies, len(addrs))]


class RequestIdMiddleware:
    """
    P1-10: correlation/request ID برای هر درخواست.

    - یک X-Request-ID یکتا تولید/انتقال می‌دهد (احترام به هدر ورودی کلاینت
      برای tracing یکپارچه با reverse proxy).
    - شناسه در request.request_id، هدر پاسخ X-Request-ID و thread-local
      (برای لاگ JSON) قرار می‌گیرد تا همه لاگ‌های یک درخواست قابل دنبال
      کردن باشند.
    """

    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        request_id = (
            request.META.get('HTTP_X_REQUEST_ID')
            or uuid.uuid4().hex[:12])
        request.request_id = request_id
        set_request_id(request_id)
        try:
            response = self.get_response(request)
            response['X-Request-ID'] = request_id
            return response
        finally:
            # پاک‌سازی thread-local تا request_id بین درخواست‌های بعدی
            # روی همان thread (thread pool) نشت نکند.
            set_request_id(None)


class ErrorLoggingMiddleware:
    """
    Middleware برای ثبت خودکار خطاها و ارسال شناسه خطا به کاربر
    """

    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        # ذخیره اطلاعات درخواست برای استفاده در صورت بروز خطا
        # EDRA v27 — رفع باگ واقعی (تایید ممیزی هوش مصنوعی، سپتامبر
        # ۲۰۲۶): 'user' دیگر اینجا capture نمی‌شود — چون این خط قبل از
        # اجرای view است، و احراز هویت JWT (DRF) داخل خودِ view اجرا
        # می‌شود، نه در AuthenticationMiddleware جنگو. یعنی برای تقریباً
        # همه‌ی درخواست‌های API (که این اپ کاملاً بر همان پایه است)،
        # request.user در این نقطه هنوز AnonymousUser بود و ErrorLog.user
        # همیشه خالی ثبت می‌شد. حالا کاربر در _log_error (بعد از اجرای
        # view) به‌صورت تازه خوانده می‌شود.
        request._error_log_data = {
            'method': request.method,
            'path': request.path,
            'user_agent': request.META.get('HTTP_USER_AGENT', ''),
            'ip_address': _client_ip(request),
            'request_data': self._get_request_data(request),
        }

        try:
            response = self.get_response(request)

            # اگر کد وضعیت ۵۰۰ یا بیشتر باشد، خطا ثبت می‌شود
            if response.status_code >= 500:
                try:
                    self._log_error(request, response.status_code, None, None)
                except Exception as log_failure:
                    # EDRA v36: خرابیِ خودِ ثبت لاگ (مثلاً قطعی دیتابیس) نباید
                    # پاسخ اصلی را بپوشاند.
                    logger.error(f"ErrorLog write failed: {log_failure}")

            return response
        except Exception as e:
            # خطای غیرمنتظره — همیشه در ErrorLog ثبت می‌شود (صرف‌نظر از مسیر)
            try:
                error_id = self._log_error(
                    request, 500, e, traceback.format_exc())
            except Exception as log_failure:
                logger.error(f"ErrorLog write failed: {log_failure}")
                error_id = 'UNLOGGED'

            # EDRA v25 — root-cause فیکس: قبلاً این middleware همهٔ
            # exception ها را — حتی در پنل ادمین جنگو و صفحات HTML — قورت
            # می‌داد و یک JSON عمومی برمی‌گرداند. نتیجه: حتی روی لوکال با
            # DEBUG=True هم صفحهٔ traceback واقعی جنگو هرگز دیده نمی‌شد؛
            # دقیقاً همان چیزی که ریشه‌یابی خطاهای ۵۰۰ پنل ادمین را تا این حد
            # سخت کرده بود. رفتار جدید:
            #   • مسیرهای API (زیر /api/) مثل قبل JSON دوستانه می‌گیرند،
            #     چون کلاینت‌های API انتظار JSON دارند، نه صفحهٔ HTML جنگو.
            #   • بقیهٔ مسیرها (ادمین، صفحات دیگر) exception را دوباره raise
            #     می‌کنند تا خودِ جنگو مدیریتش کند: با DEBUG=True یعنی صفحهٔ
            #     traceback کامل و واقعی (دقیقاً چیزی که برای دیباگ لازم
            #     است)، و با DEBUG=False یعنی صفحهٔ ۵۰۰ استاندارد جنگو
            #     (handler500). ثبت در ErrorLog در هر دو حالت انجام می‌شود؛
            #     چیزی از دست نمی‌رود، فقط دیگر مخفی نمی‌ماند.
            if request.path.startswith('/api/'):
                return JsonResponse({
                    'success': False,
                    'error': 'خطای داخلی سرور رخ داده است.',
                    'error_id': error_id,
                    'message': 'لطفاً این شناسه را به پشتیبانی ارائه دهید.'
                }, status=500)
            raise

    # P1 (EDRA v9): فیلدهای حساس که باید در لاگ خطا mask شوند
    _SENSITIVE_KEYS = frozenset({
        'password', 'old_password', 'new_password', 'confirm_password',
        'otp', 'otp_code', 'code', 'access', 'refresh', 'access_token',
        'refresh_token', 'token', 'authorization', 'api_key', 'apikey',
        'secret', 'secret_key', 'credit_amount', 'card_number', 'cvv2',
        'bank_receipt', 'receipt_file',
    })

    @classmethod
    def _redact(cls, value, key=''):
        """
        mask داده‌های حساس به‌صورت بازگشتی — توکن‌ها/رمزها/OTP/مبالغ مالی
        هرگز به‌صورت خام در ErrorLog ذخیره نمی‌شوند.
        """
        if isinstance(value, dict):
            return {
                k: ('***REDACTED***'
                    if k.lower() in cls._SENSITIVE_KEYS
                    else cls._redact(v, k))
                for k, v in value.items()
            }
        if isinstance(value, (list, tuple)):
            return [cls._redact(v, key) for v in value]
        if key.lower() in cls._SENSITIVE_KEYS:
            return '***REDACTED***'
        return value

    def _get_request_data(self, request):
        """استخراج داده‌های درخواست برای ذخیره (با redaction اجباری)"""
        data = {}

        # داده‌های GET
        if request.GET:
            data['get'] = self._redact(dict(request.GET))

        # داده‌های POST (به جز فایل‌ها)
        if request.POST:
            data['post'] = self._redact({
                k: v for k,
                v in request.POST.items() if not hasattr(
                    v,
                    'read')})

        # داده‌های JSON (در صورت وجود)
        if request.content_type == 'application/json' and request.body:
            try:
                import json
                data['json'] = self._redact(
                    json.loads(request.body.decode('utf-8')))
            except Exception as e:
                pass

        # هدرهای مهم
        headers = {}
        for key in [
            'CONTENT_TYPE',
            'CONTENT_LENGTH',
            'HTTP_REFERER',
                'HTTP_X_REQUESTED_WITH']:
            if key in request.META:
                headers[key] = request.META[key]
        if headers:
            data['headers'] = headers

        return data

    def _log_error(self, request, status_code, exception, tb_text):
        """ثبت خطا در دیتابیس و بازگرداندن شناسه"""
        error_id = self._generate_error_id()

        error_data = getattr(request, '_error_log_data', {})

        # کاربر را همین‌جا (پس از اجرای view) تازه می‌خوانیم — نگاه کنید
        # به کامنت v27 در __call__.
        current_user = getattr(request, 'user', None)
        resolved_user = (
            current_user
            if current_user is not None and getattr(current_user, 'is_authenticated', False)
            else None)

        error_log = ErrorLog.objects.create(
            error_id=error_id,
            severity='critical' if status_code >= 500 else 'error',
            user=resolved_user,
            path=error_data.get('path', request.path),
            method=error_data.get('method', request.method),
            status_code=status_code,
            error_type=exception.__class__.__name__ if exception else 'HTTPError',
            error_message=str(exception) if exception else f'HTTP {status_code}',
            traceback=tb_text or '',
            request_data=error_data.get('request_data', {}),
            user_agent=error_data.get('user_agent', ''),
            ip_address=error_data.get('ip_address', ''),
        )

        # لاگ در سیستم لاگ
        logger.error(
            f"Error {error_id}: {error_log.error_type} - {error_log.error_message}",
            extra={'error_id': error_id})

        # P2: ارسال به Sentry (اختیاری — فقط اگر SENTRY_DSN تنظیم باشد)
        if getattr(settings, 'SENTRY_DSN', ''):
            try:
                import sentry_sdk
                with sentry_sdk.configure_scope() as scope:
                    scope.set_tag('error_id', error_id)
                    scope.set_tag('request_id', getattr(request, 'request_id', None))
                    scope.set_tag('path', error_log.path)
                sentry_sdk.capture_exception(
                    exception or Exception(f"HTTP {status_code}"))
            except Exception:
                pass  # fail-open: خطای Sentry نباید جریان را بشکند

        return error_id

    def _generate_error_id(self):
        """تولید شناسه یکتا برای خطا"""
        import random
        import string
        chars = string.ascii_uppercase + string.digits
        return ''.join(random.choices(chars, k=10))

# EDRA v27 — افزودن فیلد ریزاجزای قیمت به InspectionRequest
# (برای نمایش هزینه‌ی تجهیز/شهر به‌صورت جدا در فاکتور)
from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('core', '0001_initial'),
    ]

    operations = [
        migrations.AddField(
            model_name='inspectionrequest',
            name='price_breakdown',
            field=models.JSONField(
                blank=True,
                default=dict,
                null=True,
                verbose_name='ریز اجزای قیمت',
            ),
        ),
    ]

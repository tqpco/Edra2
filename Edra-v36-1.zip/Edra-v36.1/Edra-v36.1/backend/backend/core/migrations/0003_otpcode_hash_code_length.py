# EDRA v27 — رفع باگ بحرانی: افزایش طول فیلد code برای ذخیره هش
# (به‌جای کد ۶ رقمی متن‌ساده)
from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('core', '0002_inspectionrequest_price_breakdown'),
    ]

    operations = [
        migrations.AlterField(
            model_name='otpcode',
            name='code',
            field=models.CharField(max_length=64, verbose_name='کد'),
        ),
    ]

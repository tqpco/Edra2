# EDRA v32 — SEC: کدهای تخفیف باید صریحاً برای «نمایش عمومی مشتری» علامت
# بخورند. پیش از این مهاجرت، /api/core/customer/discount-codes/ هر کد
# فعال و منقضی‌نشده را (بدون توجه به مقصودِ هدفمند بودنش) به هر کاربر
# واردشده‌ای نشان می‌داد. پیش‌فرض False است تا کدهای فعلی تا تصمیم آگاهانه‌ی
# ادمین، مخفی بمانند (fail-closed) — نه این‌که همه‌شان ناگهان عمومی شوند.
from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('core', '0003_otpcode_hash_code_length'),
    ]

    operations = [
        migrations.AddField(
            model_name='discountcode',
            name='is_public',
            field=models.BooleanField(
                default=False,
                db_index=True,
                verbose_name='نمایش در فهرست عمومی مشتری',
                help_text=(
                    'اگر فعال باشد، این کد بدون وارد کردن کد هم برای هر مشتری '
                    'واردشده در لیست کدهای قابل‌استفاده نمایش داده می‌شود. '
                    'برای کدهای هدفمند/اختصاصی (ریفرال و مشابه) خاموش بماند.'
                ),
            ),
        ),
    ]

# EDRA v36 — یکتایی شماره‌ی پروفایل فقط برای مقدار «غیرخالی».
# قبلاً unique=True با مقدار پیش‌فرض '' باعث IntegrityError برای دومین کاربرِ
# بدون شماره می‌شد. شماره‌های واقعی هم‌چنان یکتا می‌مانند (داده‌ی موجود بدون
# تکرار است چون قبلاً unique بود، پس مهاجرت امن است).
import django.core.validators
from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('core', '0004_discountcode_is_public'),
    ]

    operations = [
        migrations.AlterField(
            model_name='userprofile',
            name='phone',
            field=models.CharField(
                db_index=True,
                max_length=15,
                validators=[django.core.validators.RegexValidator(
                    '^09\\d{9}$',
                    'شماره موبایل باید با 09 شروع شود و 11 رقم باشد.')],
                verbose_name='شماره موبایل'),
        ),
        migrations.AddConstraint(
            model_name='userprofile',
            constraint=models.UniqueConstraint(
                condition=models.Q(('phone', ''), _negated=True),
                fields=('phone',),
                name='uniq_userprofile_phone_nonempty'),
        ),
    ]

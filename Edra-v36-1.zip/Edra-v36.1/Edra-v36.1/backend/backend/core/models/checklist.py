# core/models/checklist.py
# -*- coding: utf-8 -*-
"""
مدل‌های بخش چک‌لیست – طراحی اصولی و حرفه‌ای
"""

from django.db import models
from django.contrib.auth import get_user_model
from django.utils import timezone
from django.core.exceptions import ValidationError
from django.utils.translation import gettext_lazy as _

from ..utils.upload_paths import (
    report_pdf_upload_path,
    signed_report_pdf_upload_path,
    checklist_photo_upload_path,
)
from ..utils.image_utils import compress_and_save_image_field

User = get_user_model()


class ChecklistCategory(models.Model):
    """دسته‌بندی آیتم‌های چک‌لیست"""
    name = models.CharField(max_length=100, unique=True, verbose_name=_('نام دسته‌بندی'), db_index=True)
    name_en = models.CharField(max_length=100, blank=True, verbose_name=_('نام انگلیسی'))
    color = models.CharField(max_length=7, default='#64748b', verbose_name=_('رنگ (Hex)'))
    icon = models.CharField(max_length=50, blank=True, verbose_name=_('آیکون'))
    order = models.PositiveSmallIntegerField(default=0, verbose_name=_('ترتیب نمایش'), db_index=True)
    is_active = models.BooleanField(default=True, verbose_name=_('فعال'), db_index=True)
    created_at = models.DateTimeField(auto_now_add=True, verbose_name=_('تاریخ ایجاد'), db_index=True)
    updated_at = models.DateTimeField(auto_now=True, verbose_name=_('تاریخ بروزرسانی'))

    class Meta:
        verbose_name = _('دسته‌بندی چک‌لیست')
        verbose_name_plural = _('دسته‌بندی‌های چک‌لیست')
        ordering = ['order', 'name']

    def __str__(self):
        return self.name


class ChecklistTemplate(models.Model):
    """قالب چک‌لیست – مجموعه‌ای از آیتم‌ها برای یک نوع تجهیزات"""
    equipment_type = models.ForeignKey(
        'EquipmentType',
        on_delete=models.CASCADE,
        related_name='checklist_templates',
        verbose_name=_('نوع تجهیزات'),
        db_index=True,
    )
    version = models.PositiveIntegerField(default=1, verbose_name=_('نسخه'))
    name = models.CharField(max_length=200, verbose_name=_('نام'))
    description = models.TextField(blank=True, verbose_name=_('توضیحات'))
    is_active = models.BooleanField(default=True, verbose_name=_('فعال'), db_index=True)
    created_at = models.DateTimeField(auto_now_add=True, verbose_name=_('تاریخ ایجاد'), db_index=True)
    created_by = models.ForeignKey(
        User,
        on_delete=models.PROTECT,
        null=True,
        verbose_name=_('ایجادکننده'),
        related_name='created_checklist_templates',
    )
    updated_at = models.DateTimeField(auto_now=True, verbose_name=_('تاریخ بروزرسانی'), db_index=True)

    class Meta:
        verbose_name = _('قالب چک‌لیست')
        verbose_name_plural = _('چک‌لیست')
        ordering = ['-version', 'equipment_type__name_fa']
        constraints = [
            models.UniqueConstraint(fields=['equipment_type', 'version'], name='unique_template_per_equipment_version'),
        ]
        indexes = [
            models.Index(fields=['equipment_type', 'is_active']),
            models.Index(fields=['is_active', 'created_at']),
        ]

    def __str__(self):
        return f"{self.equipment_type.name_fa} - v{self.version}"

    def get_active_items_count(self):
        return self.items.filter(is_active=True).count()


class ChecklistItem(models.Model):
    """آیتم چک‌لیست – یک سطر از چک‌لیست"""
    RESULT_CHOICES = [
        ('pass', _('قبول')),
        ('fail', _('مردود')),
        ('na', _('غیرقابل‌اجرا')),
        ('pending', _('در انتظار بررسی')),
    ]

    checklist_template = models.ForeignKey(
        ChecklistTemplate,
        on_delete=models.CASCADE,
        related_name='items',
        verbose_name=_('قالب چک‌لیست'),
        db_index=True,
    )
    category = models.ForeignKey(
        ChecklistCategory,
        on_delete=models.PROTECT,
        related_name='items',
        verbose_name=_('دسته‌بندی'),
        db_index=True,
        null=True,
        blank=True,
    )
    title = models.CharField(max_length=200, verbose_name=_('عنوان'), db_index=True)
    description = models.TextField(blank=True, verbose_name=_('توضیحات'))
    order = models.PositiveSmallIntegerField(default=0, verbose_name=_('ترتیب'), db_index=True)
    requires_photo = models.BooleanField(default=False, verbose_name=_('نیاز به عکس'))
    requires_note = models.BooleanField(default=False, verbose_name=_('نیاز به یادداشت'))
    is_critical = models.BooleanField(default=False, verbose_name=_('آیتم حیاتی'), db_index=True)
    is_active = models.BooleanField(default=True, verbose_name=_('فعال'), db_index=True)
    created_at = models.DateTimeField(auto_now_add=True, verbose_name=_('تاریخ ایجاد'), db_index=True)
    updated_at = models.DateTimeField(auto_now=True, verbose_name=_('تاریخ بروزرسانی'), db_index=True)

    class Meta:
        verbose_name = _('آیتم چک‌لیست')
        verbose_name_plural = _('آیتم‌های چک‌لیست')
        ordering = ['checklist_template', 'category__order', 'order']
        constraints = [
            models.UniqueConstraint(
                fields=['checklist_template', 'category', 'title'],
                name='unique_item_per_template_category_title'
            ),
        ]
        indexes = [
            models.Index(fields=['checklist_template', 'category']),
            models.Index(fields=['category', 'is_active']),
            models.Index(fields=['is_critical', 'is_active']),
        ]

    def __str__(self):
        return f"{self.category.name if self.category else 'بدون دسته'} - {self.title}"

    def clean(self):
        if not self.title:
            raise ValidationError({'title': _('عنوان الزامی است.')})
        if self.order < 0:
            raise ValidationError({'order': _('ترتیب نمی‌تواند منفی باشد.')})

    def save(self, *args, **kwargs):
        self.full_clean()
        super().save(*args, **kwargs)


class InspectionReport(models.Model):
    """گزارش کارشناسی – یکپارچه با سیستم موجود"""
    OVERALL_RESULT_CHOICES = [
        ('pass', _('قبول')),
        ('conditional', _('مشروط')),
        ('fail', _('مردود')),
    ]

    inspection_request = models.OneToOneField(
        'InspectionRequest',
        on_delete=models.PROTECT,
        related_name='report',
        verbose_name=_('درخواست کارشناسی'),
        db_index=True,
    )
    report_number = models.CharField(max_length=40, unique=True, verbose_name=_('شماره گزارش'), db_index=True)
    checklist_template_version = models.ForeignKey(
        ChecklistTemplate,
        on_delete=models.PROTECT,
        null=True,
        verbose_name=_('نسخه قالب چک‌لیست'),
    )
    results = models.JSONField(default=list, verbose_name=_('نتایج'))
    overall_result = models.CharField(max_length=20, choices=OVERALL_RESULT_CHOICES, verbose_name=_('نتیجه کلی'), db_index=True)
    inspector_notes = models.TextField(blank=True, verbose_name=_('یادداشت کارشناس'))

    gps_start_lat = models.DecimalField(max_digits=9, decimal_places=6, null=True, blank=True, verbose_name=_('عرض جغرافیایی شروع'))
    gps_start_lng = models.DecimalField(max_digits=9, decimal_places=6, null=True, blank=True, verbose_name=_('طول جغرافیایی شروع'))
    gps_end_lat = models.DecimalField(max_digits=9, decimal_places=6, null=True, blank=True, verbose_name=_('عرض جغرافیایی پایان'))
    gps_end_lng = models.DecimalField(max_digits=9, decimal_places=6, null=True, blank=True, verbose_name=_('طول جغرافیایی پایان'))
    gps_distance_meters = models.FloatField(null=True, blank=True, verbose_name=_('فاصله از محل پروژه (متر)'))
    inspection_started_at = models.DateTimeField(null=True, blank=True, verbose_name=_('زمان شروع کارشناسی در محل'), db_index=True)
    inspection_ended_at = models.DateTimeField(null=True, blank=True, verbose_name=_('زمان پایان کارشناسی در محل'))

    pdf_file = models.FileField(upload_to=report_pdf_upload_path, blank=True, null=True, verbose_name=_('فایل PDF'))
    signed_pdf_file = models.FileField(upload_to=signed_report_pdf_upload_path, blank=True, null=True, verbose_name=_('PDF امضا شده'))
    signature_hash = models.CharField(max_length=255, blank=True, verbose_name=_('هش امضا'), db_index=True)
    signed_at = models.DateTimeField(null=True, blank=True, verbose_name=_('تاریخ امضا'), db_index=True)
    signed_by = models.ForeignKey(
        User,
        on_delete=models.PROTECT,
        null=True,
        related_name='signed_reports',
        verbose_name=_('امضاکننده'),
    )

    created_at = models.DateTimeField(auto_now_add=True, verbose_name=_('تاریخ ایجاد'), db_index=True)
    updated_at = models.DateTimeField(auto_now=True, verbose_name=_('تاریخ بروزرسانی'), db_index=True)

    class Meta:
        verbose_name = _('گزارش کارشناسی')
        verbose_name_plural = _('گزارش‌های کارشناسی')
        ordering = ['-created_at']
        indexes = [
            models.Index(fields=['report_number']),
            models.Index(fields=['inspection_request']),
            models.Index(fields=['overall_result', 'created_at']),
            models.Index(fields=['signed_at']),
        ]

    def __str__(self):
        return self.report_number


class ChecklistPhoto(models.Model):
    """عکس ثبت‌شده برای یک آیتم چک‌لیست"""
    report = models.ForeignKey(
        InspectionReport,
        on_delete=models.CASCADE,
        related_name='photos',
        verbose_name=_('گزارش بازرسی'),
        db_index=True,
    )
    checklist_item = models.ForeignKey(
        ChecklistItem,
        on_delete=models.PROTECT,
        related_name='photo_responses',
        verbose_name=_('آیتم چک‌لیست'),
        db_index=True,
    )
    image = models.ImageField(upload_to=checklist_photo_upload_path, verbose_name=_('عکس'))
    caption = models.CharField(max_length=255, blank=True, verbose_name=_('توضیح کوتاه'))
    gps_lat = models.DecimalField(max_digits=9, decimal_places=6, null=True, blank=True, verbose_name=_('عرض جغرافیایی ثبت عکس'))
    gps_lng = models.DecimalField(max_digits=9, decimal_places=6, null=True, blank=True, verbose_name=_('طول جغرافیایی ثبت عکس'))
    created_at = models.DateTimeField(auto_now_add=True, verbose_name=_('تاریخ ثبت'), db_index=True)

    class Meta:
        verbose_name = _('عکس چک‌لیست')
        verbose_name_plural = _('عکس‌های چک‌لیست')
        ordering = ['checklist_item__category__order', 'checklist_item__order', 'created_at']
        indexes = [
            models.Index(fields=['report', 'checklist_item']),
            models.Index(fields=['created_at']),
        ]

    def __str__(self):
        return f"{self.report.report_number} - {self.checklist_item.title}"

    def save(self, *args, **kwargs):
        if self.image and not kwargs.pop('_skip_compression', False):
            compress_and_save_image_field(self, 'image')
        super().save(*args, **kwargs)


class ReportVerification(models.Model):
    """تأییدیه گزارش – کد یکتا برای استعلام عمومی"""
    report = models.OneToOneField(
        InspectionReport,
        on_delete=models.CASCADE,
        related_name='verification',
        verbose_name=_('گزارش'),
        db_index=True,
    )
    verification_code = models.CharField(max_length=50, unique=True, verbose_name=_('کد تأیید'), db_index=True)
    view_count = models.PositiveIntegerField(default=0, verbose_name=_('تعداد بازدید'))
    last_viewed_at = models.DateTimeField(null=True, blank=True, verbose_name=_('آخرین بازدید'), db_index=True)
    created_at = models.DateTimeField(auto_now_add=True, verbose_name=_('تاریخ ایجاد'), db_index=True)

    class Meta:
        verbose_name = _('تأییدیه گزارش')
        verbose_name_plural = _('تأییدیه‌های گزارش')
        ordering = ['-created_at']
        indexes = [
            models.Index(fields=['verification_code']),
            models.Index(fields=['report']),
        ]

    def __str__(self):
        return f"{self.report.report_number} - {self.verification_code}"

    def increment_view_count(self):
        from django.db.models import F
        self.view_count = F('view_count') + 1
        self.last_viewed_at = timezone.now()
        self.save(update_fields=['view_count', 'last_viewed_at'])
# core/models/dashboard.py
# -*- coding: utf-8 -*-

from django.db import models
from django.contrib.auth import get_user_model
from django.core.validators import MinValueValidator, MaxValueValidator

User = get_user_model()


class DashboardLayout(models.Model):
    """
    چیدمان داشبورد برای هر کاربر.
    """
    user = models.OneToOneField(
        User,
        on_delete=models.CASCADE,
        related_name='dashboard_layout',
        verbose_name='کاربر',
        db_index=True,
    )
    widgets = models.JSONField(
        default=list,
        verbose_name='لیست ویجت‌ها',
    )
    created_at = models.DateTimeField(
        auto_now_add=True,
        verbose_name='تاریخ ایجاد',
        db_index=True,
    )
    updated_at = models.DateTimeField(
        auto_now=True,
        verbose_name='تاریخ بروزرسانی',
        db_index=True,
    )

    class Meta:
        verbose_name = 'چیدمان داشبورد'
        verbose_name_plural = 'چیدمان داشبوردها'
        ordering = ['-updated_at']

    def __str__(self) -> str:
        return f"داشبورد {self.user.username}"
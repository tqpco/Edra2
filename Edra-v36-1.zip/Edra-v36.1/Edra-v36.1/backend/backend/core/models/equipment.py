# core/models/equipment.py
# -*- coding: utf-8 -*-

from django.db import models
from django.contrib.auth import get_user_model

User = get_user_model()


class EquipmentType(models.Model):
    """نوع تجهیزات - مدیریت انواع تجهیزات قابل بازرسی"""
    code = models.SlugField(
        unique=True,
        verbose_name='کد',
        help_text='کد یکتا و مختصر برای تجهیز (مثلاً "tower-crane")',
        db_index=True,
    )
    name_fa = models.CharField(
        max_length=100,
        verbose_name='نام فارسی',
        db_index=True,
    )
    supports_install_state = models.BooleanField(
        default=False,
        verbose_name='پشتیبانی از وضعیت نصب',
        help_text='آیا این تجهیز دارای وضعیت نصب/دمونتاژ است؟',
    )
    install_state_required = models.BooleanField(
        default=False,
        verbose_name='وضعیت نصب اجباری',
        help_text='آیا ثبت وضعیت نصب برای این تجهیز الزامی است؟',
    )
    param_schema = models.JSONField(
        verbose_name='شِمای پارامترها',
        blank=True,
        null=True,
        help_text='این فیلد به‌صورت خودکار توسط سیگنال‌ها به‌روز می‌شود',
    )
    order = models.PositiveSmallIntegerField(
        default=0,
        verbose_name='ترتیب نمایش',
        help_text='عدد کوچک‌تر زودتر نمایش داده می‌شود',
        db_index=True,
    )
    is_active = models.BooleanField(
        default=True,
        verbose_name='فعال',
        db_index=True,
    )
    created_at = models.DateTimeField(
        auto_now_add=True,
        verbose_name='تاریخ ایجاد',
        db_index=True,
    )
    updated_at = models.DateTimeField(
        auto_now=True,
        verbose_name='تاریخ بروزرسانی',
        db_index=True,
    )

    class Meta:
        verbose_name = 'نوع تجهیزات'
        verbose_name_plural = 'انواع تجهیزات'
        ordering = ['order', 'name_fa']
        indexes = [
            models.Index(fields=['code']),
            models.Index(fields=['is_active', 'order']),
        ]

    def __str__(self) -> str:
        return f"{self.name_fa} ({self.code})"

    def save(self, *args, **kwargs):
        """ذخیره با به‌روزرسانی خودکار schema"""
        super().save(*args, **kwargs)
        # اگر سیگنال‌ها فعال باشند، schema به‌روز می‌شود


class EquipmentParameter(models.Model):
    """
    پارامترهای اضافی برای یک نوع تجهیزات
    این مدل جایگزین نوشتن دستی JSON در فیلد param_schema می‌شود.
    """
    FIELD_TYPE_CHOICES = [
        ('string', 'متن'),
        ('number', 'عدد'),
        ('select', 'منوی کشویی'),
        ('boolean', 'تیک/خیر'),
        ('date', 'تاریخ'),
        ('time', 'زمان'),
    ]

    equipment_type = models.ForeignKey(
        EquipmentType,
        on_delete=models.CASCADE,
        related_name='parameters',
        verbose_name='نوع تجهیزات',
        db_index=True,
    )
    name = models.SlugField(
        max_length=50,
        verbose_name='نام متغیر (انگلیسی)',
        help_text='نام یکتا در سطح نوع تجهیزات، برای استفاده در فرمول‌ها',
        db_index=True,
    )
    label = models.CharField(
        max_length=100,
        verbose_name='برچسب (فارسی)',
        help_text='نام نمایشی در فرم‌ها',
    )
    field_type = models.CharField(
        max_length=20,
        choices=FIELD_TYPE_CHOICES,
        default='string',
        verbose_name='نوع فیلد',
        db_index=True,
    )
    options = models.TextField(
        blank=True,
        help_text='گزینه‌های منوی کشویی را با کاما جدا کنید (فقط برای نوع "منوی کشویی")',
        verbose_name='گزینه‌ها',
    )
    required = models.BooleanField(
        default=False,
        verbose_name='اجباری',
        help_text='آیا پر کردن این فیلد برای کاربر الزامی است؟',
    )
    default_value = models.JSONField(
        blank=True,
        null=True,
        verbose_name='مقدار پیش‌فرض',
        help_text='مقدار پیش‌فرض برای این پارامتر (در صورت نیاز)',
    )
    order = models.PositiveSmallIntegerField(
        default=0,
        verbose_name='ترتیب نمایش',
        db_index=True,
    )
    is_active = models.BooleanField(
        default=True,
        verbose_name='فعال',
        db_index=True,
    )

    class Meta:
        verbose_name = 'پارامتر تجهیزات'
        verbose_name_plural = 'پارامترهای تجهیزات'
        ordering = ['order', 'name']
        constraints = [
            models.UniqueConstraint(
                fields=['equipment_type', 'name'],
                name='unique_parameter_per_equipment',
            ),
        ]
        indexes = [
            models.Index(fields=['equipment_type', 'is_active']),
            models.Index(fields=['field_type']),
        ]

    def __str__(self) -> str:
        return f"{self.equipment_type.name_fa} - {self.label}"

    def get_options_list(self) -> list:
        """دریافت لیست گزینه‌ها به‌صورت لیست پایتون"""
        if self.options:
            return [opt.strip() for opt in self.options.split(',') if opt.strip()]
        return []

    def to_json_schema(self) -> dict:
        """
        تبدیل پارامتر به فرمت JSON schema برای استفاده در param_schema
        """
        schema = {
            'name': self.name,
            'label': self.label,
            'type': self.field_type,
            'required': self.required,
        }
        if self.default_value is not None:
            schema['default'] = self.default_value
        if self.field_type == 'select' and self.options:
            schema['options'] = self.get_options_list()
        return schema

    def clean(self):
        """اعتبارسنجی سطح مدل"""
        from django.core.exceptions import ValidationError
        if self.field_type == 'select' and not self.options:
            raise ValidationError({
                'options': 'برای نوع "منوی کشویی" باید گزینه‌ها را وارد کنید.'
            })
        if self.field_type == 'select' and self.options:
            options = self.get_options_list()
            if len(options) < 2:
                raise ValidationError({
                    'options': 'حداقل دو گزینه برای منوی کشویی لازم است.'
                })
# core/models/finance.py
# -*- coding: utf-8 -*-

from decimal import Decimal
from django.db import models
from django.contrib.auth import get_user_model
from django.core.exceptions import ValidationError
from django.utils import timezone

from ..utils.upload_paths import bank_receipt_upload_path, invoice_pdf_upload_path

User = get_user_model()


class PaymentMethod(models.Model):
    METHOD_CHOICES = [
        ('online', 'درگاه آنلاین'),
        ('manual', 'واریز دستی'),
        ('credit', 'اعتبار شرکتی'),
    ]
    name = models.CharField(
        max_length=50,
        choices=METHOD_CHOICES,
        unique=True,
        verbose_name='نام',
        db_index=True,
    )
    is_active = models.BooleanField(
        default=True,
        verbose_name='فعال',
        db_index=True,
    )
    description = models.TextField(
        blank=True,
        verbose_name='توضیحات',
    )
    created_at = models.DateTimeField(
        auto_now_add=True,
        verbose_name='تاریخ ایجاد',
        db_index=True,
    )

    def __str__(self) -> str:
        return self.get_name_display()

    class Meta:
        verbose_name = 'روش پرداخت'
        verbose_name_plural = 'روش‌های پرداخت'
        ordering = ['name']


class Payment(models.Model):
    STATUS_CHOICES = [
        ('pending', 'در انتظار'),
        ('paid', 'پرداخت‌شده'),
        ('failed', 'ناموفق'),
        ('cancelled', 'لغو شده'),
        ('refunded', 'عودت داده‌شده'),
        ('pending_verification', 'در انتظار تایید'),
        ('rejected', 'رد شده'),
    ]

    inspection_request = models.ForeignKey(
        'InspectionRequest',
        on_delete=models.PROTECT,
        related_name='payments',
        verbose_name='درخواست بازرسی',
        db_index=True,
    )
    amount = models.DecimalField(
        max_digits=12,
        decimal_places=0,
        verbose_name='مبلغ کل',
    )
    amount_rial = models.DecimalField(
        max_digits=14,
        decimal_places=0,
        null=True,
        blank=True,
        verbose_name='مبلغ ریالی (دفتر مالی)',
    )
    credit_amount = models.DecimalField(
        max_digits=12,
        decimal_places=0,
        default=0,
        verbose_name='مبلغ از اعتبار',
    )
    online_amount = models.DecimalField(
        max_digits=12,
        decimal_places=0,
        default=0,
        verbose_name='مبلغ آنلاین',
    )
    manual_amount = models.DecimalField(
        max_digits=12,
        decimal_places=0,
        default=0,
        verbose_name='مبلغ دستی',
    )
    method = models.ForeignKey(
        PaymentMethod,
        on_delete=models.PROTECT,
        verbose_name='روش پرداخت',
        db_index=True,
    )
    status = models.CharField(
        max_length=20,
        choices=STATUS_CHOICES,
        default='pending',
        verbose_name='وضعیت',
        db_index=True,
    )
    authority = models.CharField(
        max_length=100,
        blank=True,
        null=True,
        unique=True,
        db_index=True,
        verbose_name='شناسه درگاه (Authority)',
    )
    ref_id = models.CharField(
        max_length=100,
        blank=True,
        null=True,
        db_index=True,
        verbose_name='کد مرجع پرداخت (RefID)',
    )
    transaction_id = models.CharField(
        max_length=100,
        blank=True,
        null=True,
        verbose_name='شناسه تراکنش',
    )
    reference_code = models.CharField(
        max_length=100,
        blank=True,
        null=True,
        verbose_name='کد مرجع',
    )
    bank_receipt = models.FileField(
        upload_to=bank_receipt_upload_path,
        blank=True,
        null=True,
        verbose_name='فیش بانکی',
    )
    bank_receipt_uploaded_at = models.DateTimeField(
        null=True,
        blank=True,
        verbose_name='تاریخ آپلود فیش',
        db_index=True,
    )
    bank_receipt_hash = models.CharField(
        max_length=64,
        blank=True,
        default='',
        verbose_name='هش محتوای فیش (SHA-256)',
        db_index=True,
    )
    verified_by = models.ForeignKey(
        User,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name='verified_payments',
        verbose_name='تاییدکننده',
        db_index=True,
    )
    verified_at = models.DateTimeField(
        null=True,
        blank=True,
        verbose_name='تاریخ تایید',
        db_index=True,
    )
    rejected_by = models.ForeignKey(
        User,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name='rejected_payments',
        verbose_name='ردکننده',
    )
    rejected_at = models.DateTimeField(
        null=True,
        blank=True,
        verbose_name='تاریخ رد',
        db_index=True,
    )
    rejection_reason = models.TextField(
        blank=True,
        verbose_name='دلیل رد',
    )
    notes = models.TextField(
        blank=True,
        verbose_name='یادداشت',
    )
    created_at = models.DateTimeField(
        auto_now_add=True,
        verbose_name='تاریخ ایجاد',
        db_index=True,
    )
    updated_at = models.DateTimeField(
        auto_now=True,
        verbose_name='تاریخ بروزرسانی',
        db_index=True,
    )

    @property
    def total_parts(self) -> Decimal:
        """
        مجموع اجزای پرداخت.
        EDRA v27 — رفع باگ واقعی (گزارش ممیزی کاربر، سپتامبر ۲۰۲۶):
        قبلاً float برمی‌گرداند و در clean() با self.amount (Decimal)
        مقایسه می‌شد — Decimal != float می‌تواند به‌خاطر خطای دقت ممیز
        شناور، مبلغ‌های واقعاً برابر را نابرابر تشخیص دهد (یا برعکس).
        همه‌چیز باید Decimal بماند.
        """
        return self.credit_amount + self.online_amount + self.manual_amount

    def clean(self):
        """اعتبارسنجی سطح مدل"""
        if self.amount != self.total_parts:
            raise ValidationError({
                'amount': (
                    f'مبلغ پرداخت ({self.amount}) با مجموع اجزا '
                    f'({self.total_parts}) برابر نیست.'
                )
            })

    # EDRA v27 — رفع باگ واقعی (گزارش ممیزی کاربر، سپتامبر ۲۰۲۶): فیلدهای
    # مبلغ که تغییرشان باید اعتبارسنجی amount==total_parts را دوباره
    # اجرا کند.
    _AMOUNT_FIELDS = frozenset({'amount', 'credit_amount', 'online_amount', 'manual_amount'})

    def save(self, *args, **kwargs):
        update_fields = kwargs.get('update_fields')
        # قبلاً full_clean() فقط در ساخت اولیه (_state.adding) اجرا
        # می‌شد؛ یعنی هیچ ویرایش بعدی amount/credit_amount/... دوباره
        # چک نمی‌شد. حالا هر وقت این فیلدها دست‌نخورده نباشند (یا کل
        # آبجکت ذخیره شود، نه فقط update_fields محدود) اعتبارسنجی دوباره
        # اجرا می‌شود.
        should_validate = self._state.adding or update_fields is None or (
            self._AMOUNT_FIELDS & set(update_fields))
        if should_validate:
            self.full_clean()
        super().save(*args, **kwargs)

    def __str__(self) -> str:
        return f"Payment #{self.id} - {self.inspection_request_id} - {self.get_status_display()}"

    class Meta:
        verbose_name = 'پرداخت'
        verbose_name_plural = 'پرداخت‌ها'
        ordering = ['-created_at']
        indexes = [
            models.Index(fields=['inspection_request', 'status']),
            models.Index(fields=['authority']),
            models.Index(fields=['ref_id']),
            models.Index(fields=['status', 'created_at']),
        ]


class Invoice(models.Model):
    STATUS_CHOICES = [
        ('pending', 'در انتظار تولید'),
        ('generated', 'تولید شده'),
        ('failed', 'خطا در تولید'),
    ]

    inspection_request = models.OneToOneField(
        'InspectionRequest',
        on_delete=models.PROTECT,
        related_name='invoice',
        verbose_name='درخواست کارشناسی',
        db_index=True,
    )
    invoice_number = models.CharField(
        max_length=50,
        unique=True,
        verbose_name='شماره فاکتور',
        db_index=True,
    )
    issue_date = models.DateTimeField(
        auto_now_add=True,
        verbose_name='تاریخ صدور',
        db_index=True,
    )
    due_date = models.DateTimeField(
        verbose_name='تاریخ سررسید',
        db_index=True,
    )
    base_amount = models.DecimalField(
        max_digits=12,
        decimal_places=0,
        default=0,
        verbose_name='مبلغ پایه (پیش از تخفیف)',
    )
    total_amount = models.DecimalField(
        max_digits=12,
        decimal_places=0,
        verbose_name='مبلغ کل (پس از تخفیف، پیش از مالیات)',
    )
    discount_amount = models.DecimalField(
        max_digits=12,
        decimal_places=0,
        default=0,
        verbose_name='مبلغ تخفیف',
    )
    tax_amount = models.DecimalField(
        max_digits=12,
        decimal_places=0,
        default=0,
        verbose_name='مبلغ مالیات',
    )
    tax_rate_percent = models.DecimalField(
        max_digits=5,
        decimal_places=2,
        default=0,
        verbose_name='نرخ مالیات (٪)',
    )
    final_amount = models.DecimalField(
        max_digits=12,
        decimal_places=0,
        verbose_name='مبلغ نهایی (تومان)',
    )
    final_rial = models.DecimalField(
        max_digits=14,
        decimal_places=0,
        null=True,
        blank=True,
        verbose_name='مبلغ نهایی به ریال (دفتر مالی)',
        db_index=True,
    )
    pricing_version = models.CharField(
        max_length=20,
        blank=True,
        default='1.0',
        verbose_name='نسخه قانون قیمت‌گذاری',
    )
    calculated_at = models.DateTimeField(
        null=True,
        blank=True,
        verbose_name='زمان محاسبه قیمت',
        db_index=True,
    )
    pdf_file = models.FileField(
        upload_to=invoice_pdf_upload_path,
        blank=True,
        null=True,
        verbose_name='فایل PDF',
    )
    is_paid = models.BooleanField(
        default=False,
        verbose_name='پرداخت شده',
        db_index=True,
    )
    paid_at = models.DateTimeField(
        null=True,
        blank=True,
        verbose_name='تاریخ پرداخت',
        db_index=True,
    )
    status = models.CharField(
        max_length=20,
        choices=STATUS_CHOICES,
        default='pending',
        verbose_name='وضعیت فاکتور',
        db_index=True,
    )
    retry_count = models.PositiveIntegerField(
        default=0,
        verbose_name='تعداد تلاش مجدد',
    )
    last_error = models.TextField(
        blank=True,
        verbose_name='آخرین خطا',
    )

    @property
    def is_fully_paid(self) -> bool:
        """آیا فاکتور به‌طور کامل پرداخت شده است؟"""
        return self.is_paid and self.paid_at is not None

    def __str__(self) -> str:
        return self.invoice_number

    class Meta:
        verbose_name = 'فاکتور'
        verbose_name_plural = 'فاکتورها'
        ordering = ['-issue_date']
        indexes = [
            models.Index(fields=['invoice_number']),
            models.Index(fields=['inspection_request']),
            models.Index(fields=['is_paid', 'due_date']),
            models.Index(fields=['status']),
        ]


class TaxRate(models.Model):
    rate_percent = models.DecimalField(
        max_digits=5,
        decimal_places=2,
        verbose_name='نرخ مالیات (٪)',
    )
    effective_from = models.DateField(
        verbose_name='تاریخ شروع اعتبار',
        db_index=True,
    )
    effective_to = models.DateField(
        null=True,
        blank=True,
        verbose_name='تاریخ پایان اعتبار (اختیاری)',
        db_index=True,
    )
    is_active = models.BooleanField(
        default=True,
        verbose_name='فعال',
        db_index=True,
    )
    created_by = models.ForeignKey(
        User,
        null=True,
        blank=True,
        on_delete=models.SET_NULL,
        related_name='tax_rates_created',
        verbose_name='ایجادکننده',
    )
    created_at = models.DateTimeField(
        auto_now_add=True,
        verbose_name='تاریخ ایجاد',
        db_index=True,
    )
    updated_at = models.DateTimeField(
        auto_now=True,
        verbose_name='تاریخ بروزرسانی',
        db_index=True,
    )

    class Meta:
        verbose_name = 'نرخ مالیات'
        verbose_name_plural = 'نرخ‌های مالیات'
        ordering = ['-effective_from']
        indexes = [
            models.Index(fields=['is_active', 'effective_from']),
        ]

    def __str__(self) -> str:
        return f'{self.rate_percent}٪ از {self.effective_from}'

    def clean(self):
        if self.rate_percent is None or self.rate_percent < 0:
            raise ValidationError({'rate_percent': 'نرخ نمی‌تواند منفی باشد.'})
        if self.effective_to and self.effective_to < self.effective_from:
            raise ValidationError(
                {'effective_to': 'تاریخ پایان نمی‌تواند قبل از شروع باشد.'}
            )
        if not self.is_active:
            return
        from django.db.models import Q
        new_start = self.effective_from
        new_end = self.effective_to
        overlaps = type(self).objects.filter(
            is_active=True,
            effective_from__lte=(new_end if new_end else new_start),
        ).filter(
            Q(effective_to__isnull=True) | Q(effective_to__gte=new_start)
        ).exclude(pk=self.pk)
        if overlaps.exists():
            raise ValidationError({
                'effective_from': (
                    'یک نرخ فعال هم‌پوشان وجود دارد — بازه‌ها نباید هم‌پوشی کنند.'
                )
            })

    def save(self, *args, **kwargs):
        self.full_clean()
        super().save(*args, **kwargs)


class Refund(models.Model):
    STATUS_CHOICES = [
        ('requested', 'درخواست شده'),
        ('gateway_processing', 'در حال پردازش درگاه'),
        ('gateway_refunded', 'عودت درگاه تأیید شد'),
        ('completed', 'تکمیل شده'),
        ('gateway_failed', 'خطای درگاه در عودت'),
    ]

    payment = models.ForeignKey(
        Payment,
        on_delete=models.PROTECT,
        related_name='refunds',
        verbose_name='پرداخت',
        db_index=True,
    )
    inspection_request = models.ForeignKey(
        'InspectionRequest',
        on_delete=models.PROTECT,
        related_name='refunds',
        verbose_name='درخواست بازرسی',
        db_index=True,
    )
    customer = models.ForeignKey(
        User,
        on_delete=models.PROTECT,
        related_name='refunds',
        verbose_name='مشتری',
        db_index=True,
    )
    invoice = models.ForeignKey(
        Invoice,
        null=True,
        blank=True,
        on_delete=models.SET_NULL,
        related_name='refunds',
        verbose_name='فاکتور',
    )
    amount_toman = models.DecimalField(
        max_digits=12,
        decimal_places=0,
        verbose_name='مبلغ عودت (تومان)',
    )
    amount_rial = models.DecimalField(
        max_digits=14,
        decimal_places=0,
        verbose_name='مبلغ عودت (ریال)',
    )
    credit_amount = models.DecimalField(
        max_digits=12,
        decimal_places=0,
        default=0,
        verbose_name='سهم اعتبار (تومان)',
    )
    online_amount = models.DecimalField(
        max_digits=12,
        decimal_places=0,
        default=0,
        verbose_name='سهم آنلاین (تومان)',
    )
    reason = models.TextField(verbose_name='علت عودت')
    requested_by = models.ForeignKey(
        User,
        null=True,
        blank=True,
        on_delete=models.SET_NULL,
        related_name='refunds_requested',
        verbose_name='درخواست‌دهنده',
    )
    approved_by = models.ForeignKey(
        User,
        null=True,
        blank=True,
        on_delete=models.SET_NULL,
        related_name='refunds_approved',
        verbose_name='تأییدکننده',
    )
    gateway_reference = models.CharField(
        max_length=200,
        blank=True,
        default='',
        verbose_name='Reference عودت درگاه',
        db_index=True,
    )
    gateway_status = models.CharField(
        max_length=50,
        blank=True,
        default='',
        verbose_name='وضعیت اعلام‌شده توسط درگاه',
    )
    status = models.CharField(
        max_length=30,
        choices=STATUS_CHOICES,
        default='requested',
        verbose_name='وضعیت عودت',
        db_index=True,
    )
    failure_reason = models.TextField(
        blank=True,
        default='',
        verbose_name='دلیل خطا',
    )
    requested_at = models.DateTimeField(
        auto_now_add=True,
        verbose_name='زمان درخواست',
        db_index=True,
    )
    processed_at = models.DateTimeField(
        null=True,
        blank=True,
        verbose_name='زمان پردازش درگاه',
        db_index=True,
    )
    completed_at = models.DateTimeField(
        null=True,
        blank=True,
        verbose_name='زمان تکمیل',
        db_index=True,
    )
    created_at = models.DateTimeField(
        auto_now_add=True,
        verbose_name='تاریخ ایجاد',
        db_index=True,
    )
    updated_at = models.DateTimeField(
        auto_now=True,
        verbose_name='تاریخ بروزرسانی',
        db_index=True,
    )

    class Meta:
        verbose_name = 'عودت'
        verbose_name_plural = 'عودت‌ها'
        ordering = ['-created_at']
        indexes = [
            models.Index(fields=['payment', 'status']),
            models.Index(fields=['customer']),
            models.Index(fields=['gateway_reference']),
        ]

    def __str__(self) -> str:
        return f'Refund #{self.id} — {self.payment_id} ({self.get_status_display()})'


class UserCredit(models.Model):
    user = models.OneToOneField(
        User,
        on_delete=models.CASCADE,
        related_name='credit',
        verbose_name='کاربر',
        db_index=True,
    )
    balance = models.DecimalField(
        max_digits=12,
        decimal_places=0,
        default=0,
        verbose_name='موجودی',
    )
    credit_limit = models.DecimalField(
        max_digits=12,
        decimal_places=0,
        default=0,
        verbose_name='سقف اعتبار',
    )
    is_active = models.BooleanField(
        default=True,
        verbose_name='فعال',
        db_index=True,
    )
    updated_at = models.DateTimeField(
        auto_now=True,
        verbose_name='تاریخ بروزرسانی',
        db_index=True,
    )

    def __str__(self) -> str:
        return f"{self.user.username} - {self.balance}"

    class Meta:
        verbose_name = 'اعتبار کاربر'
        verbose_name_plural = 'اعتبار کاربران'
        indexes = [
            models.Index(fields=['user']),
        ]


class CreditTransaction(models.Model):
    TRANSACTION_TYPES = [
        ('deposit', 'افزایش اعتبار'),
        ('withdraw', 'کاهش اعتبار'),
        ('purchase', 'خرید'),
        ('refund', 'عودت'),
    ]

    user = models.ForeignKey(
        User,
        on_delete=models.PROTECT,
        related_name='credit_transactions',
        verbose_name='کاربر',
        db_index=True,
    )
    amount = models.DecimalField(
        max_digits=12,
        decimal_places=0,
        verbose_name='مبلغ',
    )
    transaction_type = models.CharField(
        max_length=20,
        choices=TRANSACTION_TYPES,
        verbose_name='نوع تراکنش',
        db_index=True,
    )
    description = models.CharField(
        max_length=200,
        verbose_name='توضیحات',
    )
    reference_id = models.CharField(
        max_length=100,
        blank=True,
        null=True,
        verbose_name='شناسه مرجع',
        db_index=True,
    )
    balance_after = models.DecimalField(
        max_digits=12,
        decimal_places=0,
        verbose_name='موجودی پس از تراکنش',
    )
    created_at = models.DateTimeField(
        auto_now_add=True,
        verbose_name='تاریخ ایجاد',
        db_index=True,
    )

    def __str__(self) -> str:
        return f"{self.user.username} - {self.amount} - {self.get_transaction_type_display()}"

    class Meta:
        verbose_name = 'تراکنش اعتباری'
        verbose_name_plural = 'تراکنش‌های اعتباری'
        ordering = ['-created_at']
        indexes = [
            models.Index(fields=['user', 'transaction_type']),
            models.Index(fields=['reference_id']),
        ]


class LedgerEntry(models.Model):
    ENTRY_TYPES = [
        ('settlement', 'تسویه پرداخت'),
        ('refund', 'عودت'),
        ('credit_consumed', 'مصرف اعتبار'),
        ('adjustment', 'تعدیل دستی'),
    ]

    payment = models.ForeignKey(
        Payment,
        on_delete=models.PROTECT,
        related_name='ledger_entries',
        verbose_name='پرداخت',
        db_index=True,
    )
    entry_type = models.CharField(
        max_length=30,
        choices=ENTRY_TYPES,
        verbose_name='نوع ورودی',
        db_index=True,
    )
    amount_toman = models.DecimalField(
        max_digits=14,
        decimal_places=0,
        verbose_name='مبلغ (تومان)',
    )
    amount_rial = models.DecimalField(
        max_digits=14,
        decimal_places=0,
        verbose_name='مبلغ (ریال)',
    )
    reference = models.CharField(
        max_length=100,
        blank=True,
        default='',
        verbose_name='مرجع (RefID/Authority)',
        db_index=True,
    )
    performed_by = models.ForeignKey(
        User,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name='ledger_entries',
        verbose_name='انجام‌دهنده',
        db_index=True,
    )
    metadata = models.JSONField(
        default=dict,
        blank=True,
        verbose_name='فراداده',
    )
    created_at = models.DateTimeField(
        auto_now_add=True,
        verbose_name='تاریخ ثبت',
        db_index=True,
    )

    class Meta:
        verbose_name = 'ورودی دفتر کل'
        verbose_name_plural = 'دفتر کل حسابداری'
        ordering = ['created_at']
        constraints = [
            models.UniqueConstraint(
                fields=['payment', 'entry_type'],
                name='uniq_payment_ledger_type',
            ),
        ]
        indexes = [
            models.Index(fields=['payment']),
            models.Index(fields=['entry_type']),
            models.Index(fields=['reference']),
        ]

    def save(self, *args, **kwargs):
        """ضمانت append-only بودن"""
        if self.pk and LedgerEntry.objects.filter(pk=self.pk).exists():
            raise ValueError('LedgerEntry را نمی‌توان تغییر داد (append-only).')
        super().save(*args, **kwargs)

    def delete(self, *args, **kwargs):
        raise ValueError('LedgerEntry را نمی‌توان حذف کرد (append-only).')

    def __str__(self) -> str:
        return f"{self.get_entry_type_display()} - {self.payment_id}"


class CreditReservation(models.Model):
    STATUS_CHOICES = [
        ('reserved', 'رزرو شده'),
        ('consumed', 'مصرف شده'),
        ('released', 'آزاد شده'),
    ]

    user = models.ForeignKey(
        User,
        on_delete=models.PROTECT,
        related_name='credit_reservations',
        verbose_name='کاربر',
        db_index=True,
    )
    inspection_request = models.ForeignKey(
        'InspectionRequest',
        on_delete=models.PROTECT,
        related_name='credit_reservations',
        null=True,
        blank=True,
        verbose_name='درخواست بازرسی',
        db_index=True,
    )
    payment = models.ForeignKey(
        Payment,
        on_delete=models.SET_NULL,
        related_name='credit_reservations',
        null=True,
        blank=True,
        verbose_name='پرداخت',
        db_index=True,
    )
    amount = models.DecimalField(
        max_digits=12,
        decimal_places=0,
        verbose_name='مبلغ رزرو شده (تومان)',
    )
    status = models.CharField(
        max_length=20,
        choices=STATUS_CHOICES,
        default='reserved',
        verbose_name='وضعیت',
        db_index=True,
    )
    created_at = models.DateTimeField(
        auto_now_add=True,
        verbose_name='تاریخ رزرو',
        db_index=True,
    )
    consumed_at = models.DateTimeField(
        null=True,
        blank=True,
        verbose_name='تاریخ مصرف',
        db_index=True,
    )
    released_at = models.DateTimeField(
        null=True,
        blank=True,
        verbose_name='تاریخ آزادسازی',
        db_index=True,
    )

    def __str__(self) -> str:
        return f"{self.user.username} - {self.amount} - {self.get_status_display()}"

    class Meta:
        verbose_name = 'رزرو اعتبار'
        verbose_name_plural = 'رزروهای اعتبار'
        ordering = ['-created_at']
        indexes = [
            models.Index(fields=['user', 'status']),
            models.Index(fields=['inspection_request']),
        ]
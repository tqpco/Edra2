# core/models/location.py
# -*- coding: utf-8 -*-

from django.db import models
from django.contrib.auth import get_user_model

User = get_user_model()


class CityMultiplier(models.Model):
    city = models.CharField(
        max_length=80,
        unique=True,
        verbose_name='شهر',
        db_index=True,
    )
    multiplier = models.DecimalField(
        max_digits=5,
        decimal_places=2,
        default=1.00,
        verbose_name='ضریب',
    )
    base_cost = models.DecimalField(
        max_digits=12,
        decimal_places=0,
        default=100000,
        verbose_name='هزینه پایه شهر (تومان)',
        help_text='این مقدار در ضریب ضرب شده و به‌صورت هزینه ثابت به قیمت اضافه می‌شود.',
    )
    is_active = models.BooleanField(
        default=True,
        verbose_name='فعال',
        db_index=True,
    )
    order = models.PositiveSmallIntegerField(
        default=0,
        verbose_name='ترتیب نمایش',
        help_text='عدد کوچک‌تر زودتر نمایش داده می‌شود',
        db_index=True,
    )
    created_at = models.DateTimeField(
        auto_now_add=True,
        verbose_name='تاریخ ایجاد',
        db_index=True,
    )
    updated_at = models.DateTimeField(
        auto_now=True,
        verbose_name='تاریخ بروزرسانی',
        db_index=True,
    )

    def __str__(self) -> str:
        return self.city

    class Meta:
        verbose_name = 'ضریب شهر'
        verbose_name_plural = 'ضرایب شهرها'
        ordering = ['order', 'city']
        indexes = [
            models.Index(fields=['city']),
            models.Index(fields=['is_active', 'order']),
        ]


class Organization(models.Model):
    name = models.CharField(
        max_length=150,
        verbose_name='نام',
        db_index=True,
    )
    billing_contact = models.ForeignKey(
        User,
        on_delete=models.SET_NULL,
        null=True,
        related_name='orgs',
        verbose_name='تماس مالی',
        db_index=True,
    )
    is_active = models.BooleanField(
        default=True,
        verbose_name='فعال',
        db_index=True,
    )
    created_at = models.DateTimeField(
        auto_now_add=True,
        verbose_name='تاریخ ایجاد',
        db_index=True,
    )
    updated_at = models.DateTimeField(
        auto_now=True,
        verbose_name='تاریخ بروزرسانی',
        db_index=True,
    )

    def __str__(self) -> str:
        return self.name

    class Meta:
        verbose_name = 'سازمان'
        verbose_name_plural = 'سازمان‌ها'
        ordering = ['name']
        indexes = [
            models.Index(fields=['name']),
            models.Index(fields=['is_active']),
        ]


class Project(models.Model):
    organization = models.ForeignKey(
        Organization,
        on_delete=models.CASCADE,
        null=True,
        blank=True,
        verbose_name='سازمان',
        db_index=True,
    )
    name = models.CharField(
        max_length=150,
        verbose_name='نام',
        db_index=True,
    )
    is_active = models.BooleanField(
        default=True,
        verbose_name='فعال',
        db_index=True,
    )
    created_at = models.DateTimeField(
        auto_now_add=True,
        verbose_name='تاریخ ایجاد',
        db_index=True,
    )
    updated_at = models.DateTimeField(
        auto_now=True,
        verbose_name='تاریخ بروزرسانی',
        db_index=True,
    )

    def __str__(self) -> str:
        return f"{self.name} ({self.organization.name if self.organization else 'بدون سازمان'})"

    class Meta:
        verbose_name = 'پروژه'
        verbose_name_plural = 'پروژه‌ها'
        ordering = ['organization__name', 'name']
        indexes = [
            models.Index(fields=['organization']),
            models.Index(fields=['name']),
            models.Index(fields=['is_active']),
        ]
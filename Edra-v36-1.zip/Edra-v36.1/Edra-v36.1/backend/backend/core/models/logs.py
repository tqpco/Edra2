# core/models/logs.py
# -*- coding: utf-8 -*-

from django.db import models
from django.contrib.auth import get_user_model
from django.utils import timezone

User = get_user_model()


class AuditLog(models.Model):
    user = models.ForeignKey(
        User,
        on_delete=models.SET_NULL,
        null=True,
        verbose_name='کاربر',
        db_index=True,
    )
    action = models.CharField(
        max_length=50,
        verbose_name='عملیات',
        db_index=True,
    )
    object_id = models.PositiveIntegerField(
        verbose_name='شناسه شیء',
        db_index=True,
    )
    changes = models.JSONField(
        verbose_name='تغییرات',
    )
    timestamp = models.DateTimeField(
        auto_now_add=True,
        verbose_name='زمان',
        db_index=True,
    )

    class Meta:
        verbose_name = 'لاگ ممیزی'
        verbose_name_plural = 'لاگ‌های ممیزی'
        ordering = ['-timestamp']
        indexes = [
            models.Index(fields=['user', 'action']),
            models.Index(fields=['object_id']),
            models.Index(fields=['timestamp']),
        ]

    def __str__(self) -> str:
        return f"{self.user.username if self.user else 'سیستم'} - {self.action}"


class SequenceCounter(models.Model):
    key = models.CharField(
        max_length=100,
        unique=True,
        verbose_name='کلید',
        db_index=True,
    )
    value = models.PositiveIntegerField(
        default=0,
        verbose_name='مقدار',
    )
    updated_at = models.DateTimeField(
        auto_now=True,
        verbose_name='تاریخ بروزرسانی',
        db_index=True,
    )

    def __str__(self) -> str:
        return f"{self.key}: {self.value}"

    class Meta:
        verbose_name = 'شمارنده ترتیبی'
        verbose_name_plural = 'شمارنده‌های ترتیبی'


class ErrorLog(models.Model):
    SEVERITY_CHOICES = [
        ('debug', 'Debug'),
        ('info', 'Info'),
        ('warning', 'Warning'),
        ('error', 'Error'),
        ('critical', 'Critical'),
    ]

    error_id = models.CharField(
        max_length=20,
        unique=True,
        verbose_name='شناسه خطا',
        db_index=True,
    )
    timestamp = models.DateTimeField(
        auto_now_add=True,
        verbose_name='زمان',
        db_index=True,
    )
    severity = models.CharField(
        max_length=10,
        choices=SEVERITY_CHOICES,
        default='error',
        verbose_name='شدت',
        db_index=True,
    )
    user = models.ForeignKey(
        User,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        verbose_name='کاربر',
        db_index=True,
    )
    path = models.CharField(
        max_length=500,
        verbose_name='مسیر',
        db_index=True,
    )
    method = models.CharField(
        max_length=10,
        verbose_name='متد',
        db_index=True,
    )
    status_code = models.PositiveSmallIntegerField(
        verbose_name='کد وضعیت',
        db_index=True,
    )
    error_type = models.CharField(
        max_length=100,
        verbose_name='نوع خطا',
        db_index=True,
    )
    error_message = models.TextField(
        verbose_name='پیام خطا',
    )
    traceback = models.TextField(
        verbose_name='Traceback',
        blank=True,
    )
    request_data = models.JSONField(
        default=dict,
        verbose_name='داده‌های درخواست',
    )
    user_agent = models.CharField(
        max_length=500,
        blank=True,
        verbose_name='مرورگر',
    )
    ip_address = models.CharField(
        max_length=50,
        blank=True,
        verbose_name='آی‌پی',
        db_index=True,
    )
    resolved = models.BooleanField(
        default=False,
        verbose_name='برطرف شده',
        db_index=True,
    )
    resolution_note = models.TextField(
        blank=True,
        verbose_name='توضیح رفع خطا',
    )
    resolved_at = models.DateTimeField(
        null=True,
        blank=True,
        verbose_name='تاریخ رفع',
        db_index=True,
    )
    resolved_by = models.ForeignKey(
        User,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name='resolved_errors',
        verbose_name='برطرف شده توسط',
        db_index=True,
    )

    class Meta:
        verbose_name = 'لاگ خطا'
        verbose_name_plural = 'لاگ‌های خطا'
        ordering = ['-timestamp']
        indexes = [
            models.Index(fields=['error_id']),
            models.Index(fields=['timestamp']),
            models.Index(fields=['status_code']),
            models.Index(fields=['resolved']),
            models.Index(fields=['severity']),
            models.Index(fields=['ip_address']),
        ]

    def __str__(self) -> str:
        return f"{self.error_id} - {self.error_type} - {self.timestamp}"

    # ✅ راه‌حل نهایی: استفاده از # type: ignore برای نادیده گرفتن خطای Type Checker
    def mark_as_resolved(self, user: User, note: str = '') -> None:  # type: ignore
        """
        علامت‌گذاری خطا به‌عنوان برطرف‌شده.
        
        Args:
            user: کاربری که خطا را برطرف کرده است.
            note: توضیح اختیاری درباره نحوه رفع خطا.
        """
        self.resolved = True
        self.resolved_at = timezone.now()
        self.resolved_by = user
        if note:
            self.resolution_note = note
        self.save(update_fields=['resolved', 'resolved_at', 'resolved_by', 'resolution_note'])
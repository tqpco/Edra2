# core/models/menu.py
# -*- coding: utf-8 -*-

from django.db import models
from django.contrib.auth import get_user_model
from django.utils.translation import gettext_lazy as _

User = get_user_model()


class Menu(models.Model):
    """
    منوی اصلی – هر منو شامل چندین آیتم است.
    """
    name = models.CharField(
        max_length=100,
        verbose_name=_('نام منو'),
        db_index=True,
    )
    icon = models.CharField(
        max_length=50,
        blank=True,
        verbose_name=_('آیکون'),
        help_text=_('نام آیکون از Lucide یا Emoji. مثال: "home", "settings", "📋"'),
    )
    is_active = models.BooleanField(
        default=True,
        verbose_name=_('فعال'),
        db_index=True,
    )
    order = models.PositiveSmallIntegerField(
        default=0,
        verbose_name=_('ترتیب'),
        db_index=True,
    )
    created_at = models.DateTimeField(
        auto_now_add=True,
        verbose_name=_('تاریخ ایجاد'),
        db_index=True,
    )
    updated_at = models.DateTimeField(
        auto_now=True,
        verbose_name=_('تاریخ بروزرسانی'),
        db_index=True,
    )

    class Meta:
        verbose_name = _('منو')
        verbose_name_plural = _('منوها')
        ordering = ['order', 'name']
        indexes = [
            models.Index(fields=['is_active', 'order']),
        ]

    def __str__(self) -> str:
        return self.name

    def get_icon_display(self) -> str:
        """برگرداندن آیکون به‌صورت نمایشی"""
        if self.icon:
            return self.icon
        return '📄'


class MenuItem(models.Model):
    """
    آیتم منو – هر آیتم به یک منو تعلق دارد و می‌تواند زیرمجموعه داشته باشد.
    """
    menu = models.ForeignKey(
        Menu,
        on_delete=models.CASCADE,
        related_name='items',
        verbose_name=_('منو'),
        db_index=True,
    )
    parent = models.ForeignKey(
        'self',
        on_delete=models.CASCADE,
        null=True,
        blank=True,
        related_name='children',
        verbose_name=_('والد'),
        db_index=True,
    )
    title = models.CharField(
        max_length=100,
        verbose_name=_('عنوان'),
        db_index=True,
    )
    url = models.CharField(
        max_length=500,
        verbose_name=_('لینک'),
        help_text=_('مسیر داخلی یا لینک کامل. مثال: "/admin/core/inspectionrequest/" یا "https://example.com"'),
    )
    icon = models.CharField(
        max_length=50,
        blank=True,
        verbose_name=_('آیکون'),
        help_text=_('نام آیکون از Lucide یا Emoji. مثال: "file-text", "📋"'),
    )
    target = models.CharField(
        max_length=10,
        choices=[
            ('_self', _('همان پنجره')),
            ('_blank', _('پنجره جدید')),
        ],
        default='_self',
        verbose_name=_('نحوه باز شدن'),
    )
    permission_required = models.CharField(
        max_length=255,
        blank=True,
        verbose_name=_('مجوز مورد نیاز'),
        help_text=_('مثال: "core.view_inspectionrequest"'),
    )
    is_active = models.BooleanField(
        default=True,
        verbose_name=_('فعال'),
        db_index=True,
    )
    order = models.PositiveSmallIntegerField(
        default=0,
        verbose_name=_('ترتیب'),
        db_index=True,
    )
    created_at = models.DateTimeField(
        auto_now_add=True,
        verbose_name=_('تاریخ ایجاد'),
        db_index=True,
    )
    updated_at = models.DateTimeField(
        auto_now=True,
        verbose_name=_('تاریخ بروزرسانی'),
        db_index=True,
    )

    class Meta:
        verbose_name = _('آیتم منو')
        verbose_name_plural = _('آیتم‌های منو')
        ordering = ['menu', 'parent__order', 'order']
        constraints = [
            models.UniqueConstraint(
                fields=['menu', 'parent', 'title'],
                name='unique_menu_item_title_per_menu',
            ),
        ]
        indexes = [
            models.Index(fields=['menu', 'parent']),
            models.Index(fields=['is_active', 'order']),
        ]

    def __str__(self) -> str:
        prefix = '├─ ' if self.parent else '└─ '
        return f"{prefix}{self.title}"

    def get_full_url(self) -> str:
        """برگرداندن URL کامل (با prefix admin در صورت نیاز)"""
        if self.url.startswith('/'):
            return self.url
        if self.url.startswith('http'):
            return self.url
        return f"/admin/{self.url}"

    def has_permission(self, user) -> bool:
        """بررسی دسترسی کاربر به این آیتم"""
        if not self.permission_required:
            return True
        return user.has_perm(self.permission_required)
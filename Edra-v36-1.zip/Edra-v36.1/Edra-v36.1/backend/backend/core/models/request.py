# core/models/request.py
# -*- coding: utf-8 -*-

from django.db import models
from django.contrib.auth import get_user_model
from django.db import transaction
from django.utils import timezone
from django.core.exceptions import ValidationError

User = get_user_model()


class InspectionRequest(models.Model):
    STATUS_CHOICES = [
        ('draft', 'پیش‌نویس'),
        ('pending_payment', 'در انتظار پرداخت آنلاین'),
        ('waiting_manual_payment', 'در انتظار تایید فیش واریزی'),
        ('paid', 'پرداخت‌شده'),
        ('assigned', 'ارجاع‌شده به کارشناس'),
        ('scheduled', 'زمان‌بندی‌شده'),
        ('rescheduled', 'زمان‌بندی مجدد شده'),
        ('in_progress', 'در حال بازرسی'),
        ('completed', 'تکمیل‌شده'),
        ('cancelled', 'لغو‌شده'),
        ('expired', 'منقضی‌شده (عدم پرداخت طی ۴۸ ساعت)'),
    ]

    title = models.CharField(
        max_length=200,
        blank=True,
        verbose_name='عنوان درخواست',
    )
    request_number = models.CharField(
        max_length=20,
        unique=True,
        blank=True,
        null=True,
        verbose_name='شماره درخواست',
        db_index=True,
    )

    customer = models.ForeignKey(
        User,
        on_delete=models.PROTECT,
        related_name='requests',
        verbose_name='مشتری',
        db_index=True,
    )
    project = models.ForeignKey(
        'Project',
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        verbose_name='پروژه',
        db_index=True,
    )
    equipment_type = models.ForeignKey(
        'EquipmentType',
        on_delete=models.PROTECT,
        verbose_name='نوع تجهیزات',
        db_index=True,
    )
    brand_model = models.CharField(
        max_length=200,
        verbose_name='برند/مدل',
        blank=True,
        null=True,
        default='نامشخص',
    )
    manufacture_year = models.PositiveSmallIntegerField(
        verbose_name='سال ساخت',
        blank=True,
        null=True,
        default=1990,
    )
    params = models.JSONField(
        verbose_name='پارامترها',
        blank=True,
        null=True,
        default=dict,
    )
    # EDRA v27 — قابلیت تازه (گزارش کاربر، سپتامبر ۲۰۲۶): «فاکتور هزینه
    # حمل شهر + هزینه آیتم تجهیزات را نمایش نمی‌دهد». قبلاً فقط
    # final_price/calculated_price (مبلغ نهایی تجمیعی) ذخیره می‌شد و
    # جزئیات محاسبه (هزینه پایه‌ی تجهیز، هزینه پارامترها، هزینه سفر/شهر)
    # هیچ‌جا برای فاکتور نگه داشته نمی‌شد. این فیلد در زمان ساخت درخواست
    # از همان components که در پیش‌نمایش قیمت محاسبه می‌شود پر می‌شود.
    price_breakdown = models.JSONField(
        verbose_name='ریز اجزای قیمت',
        blank=True,
        null=True,
        default=dict,
    )
    install_state = models.CharField(
        max_length=20,
        null=True,
        blank=True,
        verbose_name='وضعیت نصب',
        db_index=True,
    )
    SERVICE_TYPE_CHOICES = [
        ('standard', 'استاندارد'),
        ('pro', 'حرفه‌ای'),
    ]
    service_type = models.CharField(
        max_length=20,
        choices=SERVICE_TYPE_CHOICES,
        default='standard',
        verbose_name='سطح سرویس',
        db_index=True,
    )
    city = models.CharField(
        max_length=80,
        verbose_name='شهر',
        db_index=True,
    )
    address = models.TextField(
        verbose_name='آدرس',
    )
    address_lat = models.DecimalField(
        max_digits=9,
        decimal_places=6,
        null=True,
        blank=True,
        verbose_name='عرض جغرافیایی آدرس',
        help_text='برای مقایسه با GPS کارشناس در سرویس ضدتقلب',
    )
    address_lng = models.DecimalField(
        max_digits=9,
        decimal_places=6,
        null=True,
        blank=True,
        verbose_name='طول جغرافیایی آدرس',
    )
    scheduled_at = models.DateTimeField(
        null=True,
        blank=True,
        verbose_name='زمان بازرسی',
        db_index=True,
    )
    assigned_expert = models.ForeignKey(
        User,
        on_delete=models.SET_NULL,
        null=True,
        related_name='assigned_requests',
        verbose_name='کارشناس',
        db_index=True,
    )
    calculated_price = models.DecimalField(
        max_digits=12,
        decimal_places=0,
        default=0,
        verbose_name='قیمت محاسبه‌شده',
    )
    discount_code = models.ForeignKey(
        'DiscountCode',
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        verbose_name='کد تخفیف',
        db_index=True,
    )
    final_price = models.DecimalField(
        max_digits=12,
        decimal_places=0,
        default=0,
        verbose_name='قیمت نهایی',
    )
    status = models.CharField(
        max_length=30,
        choices=STATUS_CHOICES,
        default='draft',
        verbose_name='وضعیت',
        db_index=True,
    )
    created_at = models.DateTimeField(
        auto_now_add=True,
        verbose_name='تاریخ ایجاد',
        db_index=True,
    )
    updated_at = models.DateTimeField(
        auto_now=True,
        verbose_name='تاریخ بروزرسانی',
        db_index=True,
    )

    def save(self, *args, **kwargs):
        """ذخیره با تولید خودکار شماره و محاسبه قیمت پیش‌فرض"""
        # محاسبه خودکار قیمت (در صورت خالی بودن) — قبل از تراکنش شماره‌دهی
        if not self.calculated_price or self.calculated_price == 0:
            if self.final_price and self.final_price > 0:
                self.calculated_price = self.final_price
            else:
                # مقدار پیش‌فرض موقت برای جلوگیری از خطای NOT NULL
                self.calculated_price = 1_000_000  # ۱ میلیون تومان

        # EDRA v35: صفر برای final_price وقتی «کد تخفیف» دارد (تخفیف ۱۰۰٪ یا
        # ثابتِ ≥ قیمت) عمدی است؛ قبلاً هر save() کامل آن را به قیمت کامل
        # برمی‌گرداند و تخفیف بی‌صدا از بین می‌رفت (مثلاً در ثبت درخواست با
        # کد ۱۰۰٪).
        if (not self.final_price or self.final_price == 0) and not self.discount_code_id:
            self.final_price = self.calculated_price

        # EDRA v27 — رفع باگ واقعی (گزارش ممیزی کاربر، سپتامبر ۲۰۲۶):
        # قبلاً افزایش شمارنده در یک تراکنش atomic جدا از super().save()
        # انجام می‌شد و commit می‌شد؛ اگر super().save() به هر دلیلی بعداً
        # شکست می‌خورد (مثلاً محدودیت دیگری در دیتابیس)، آن شماره برای
        # همیشه هدر می‌رفت (gap در شماره‌گذاری). حالا هر دو در یک
        # تراکنش‌اند — یا هر دو commit می‌شوند یا هیچ‌کدام.
        if not self.request_number:
            from .logs import SequenceCounter
            with transaction.atomic():
                year = timezone.now().year
                counter, _ = SequenceCounter.objects.select_for_update().get_or_create(
                    key=f'inspection_request_{year}'
                )
                counter.value += 1
                counter.save()
                self.request_number = f"IR-{year}-{counter.value:05d}"
                super().save(*args, **kwargs)
        else:
            super().save(*args, **kwargs)

    def __str__(self) -> str:
        return f"{self.request_number} - {self.title or self.customer.get_full_name()}"

    class Meta:
        verbose_name = 'درخواست کارشناسی'
        verbose_name_plural = 'درخواست‌های کارشناسی'
        ordering = ['-created_at']
        indexes = [
            models.Index(fields=['status', '-created_at']),
            models.Index(fields=['city']),
            models.Index(fields=['customer']),
            models.Index(fields=['assigned_expert']),
            models.Index(fields=['request_number']),
            models.Index(fields=['scheduled_at']),
        ]


class DiscountCode(models.Model):
    DISCOUNT_TYPES = [
        ('percent', 'درصد'),
        ('fixed', 'مبلغ ثابت'),
    ]

    code = models.CharField(
        max_length=50,
        unique=True,
        verbose_name='کد',
        db_index=True,
    )
    discount_type = models.CharField(
        max_length=10,
        choices=DISCOUNT_TYPES,
        verbose_name='نوع تخفیف',
        db_index=True,
    )
    value = models.DecimalField(
        max_digits=10,
        decimal_places=0,
        verbose_name='مقدار',
    )
    min_amount = models.DecimalField(
        max_digits=12,
        decimal_places=0,
        null=True,
        blank=True,
        verbose_name='حداقل مبلغ',
    )
    max_amount = models.DecimalField(
        max_digits=12,
        decimal_places=0,
        null=True,
        blank=True,
        verbose_name='حداکثر مبلغ',
    )
    equipment_type = models.ForeignKey(
        'EquipmentType',
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        verbose_name='نوع تجهیزات',
        db_index=True,
    )
    apply_to_all = models.BooleanField(
        default=False,
        verbose_name='اعمال برای همه تجهیزات',
        db_index=True,
    )
    usage_limit = models.PositiveIntegerField(
        null=True,
        blank=True,
        verbose_name='محدودیت استفاده',
    )
    used_count = models.PositiveIntegerField(
        default=0,
        verbose_name='تعداد استفاده',
    )
    per_user_limit = models.PositiveIntegerField(
        default=1,
        verbose_name='محدودیت هر کاربر',
    )
    expires_at = models.DateTimeField(
        null=True,
        blank=True,
        verbose_name='تاریخ انقضا',
        db_index=True,
    )
    is_active = models.BooleanField(
        default=True,
        verbose_name='فعال',
        db_index=True,
    )
    # EDRA v32 — SEC: قبلاً /api/core/customer/discount-codes/ همه‌ی کدهای فعال را
    # با سریالایزر کامل ادمین (fields='__all__') به هر کاربر واردشده نشان می‌داد؛
    # هیچ صفحه‌ای هم آن را صدا نمی‌زد (کد مرده‌ی در معرض). کدهای هدفمند/اختصاصی
    # (مثلاً ریفرال با usage_limit کم) این‌طور توسط هر کاربری قابل کشف و مصرف بودند.
    # پیش‌فرض False: کد فقط وقتی در این مرور عمومی دیده می‌شود که ادمین صریحاً
    # تیک بزند.
    is_public = models.BooleanField(
        default=False,
        verbose_name='نمایش در فهرست عمومی مشتری',
        help_text='اگر فعال باشد، این کد بدون وارد کردن کد هم برای هر مشتری '
                  'واردشده در لیست کدهای قابل‌استفاده نمایش داده می‌شود. '
                  'برای کدهای هدفمند/اختصاصی (ریفرال و مشابه) خاموش بماند.',
        db_index=True,
    )
    description = models.TextField(
        blank=True,
        verbose_name='توضیحات',
    )
    created_at = models.DateTimeField(
        auto_now_add=True,
        verbose_name='تاریخ ایجاد',
        db_index=True,
    )
    updated_at = models.DateTimeField(
        auto_now=True,
        verbose_name='تاریخ بروزرسانی',
        db_index=True,
    )

    def clean(self):
        # EDRA v36: اعتبارسنجی سطح مدل (فرم ادمین جنگو هم از آن می‌گذرد).
        # مقدار منفی/صفر یا درصد بالای ۱۰۰ قبلاً در ادمین ذخیره می‌شد؛ مقدار منفی
        # در مسیر ثبت درخواست قیمت را «بالا می‌برد».
        from django.core.exceptions import ValidationError
        errors = {}
        if self.value is not None and self.value <= 0:
            errors['value'] = 'مقدار تخفیف باید بیشتر از صفر باشد.'
        elif (self.discount_type == 'percent' and self.value is not None
              and self.value > 100):
            errors['value'] = 'درصد تخفیف نمی‌تواند بیشتر از ۱۰۰ باشد.'
        if errors:
            raise ValidationError(errors)

    def is_valid(self, amount: float = 0, equipment_type_id: int = None) -> tuple:
        """
        بررسی اعتبار کد تخفیف
        برگرداندن: (is_valid, error_message)
        """
        if not self.is_active:
            return False, 'کد تخفیف غیرفعال است.'

        if self.expires_at and timezone.now() > self.expires_at:
            return False, 'کد تخفیف منقضی شده است.'

        if self.usage_limit and self.used_count >= self.usage_limit:
            return False, 'ظرفیت استفاده از این کد تخفیف تمام شده است.'

        if self.min_amount and amount < self.min_amount:
            return False, f'حداقل مبلغ برای این کد تخفیف {self.min_amount:,} تومان است.'

        if equipment_type_id and not self.apply_to_all:
            if self.equipment_type_id and self.equipment_type_id != equipment_type_id:
                return False, 'این کد تخفیف برای این نوع تجهیزات معتبر نیست.'

        return True, ''

    def __str__(self) -> str:
        return self.code

    class Meta:
        verbose_name = 'کد تخفیف'
        verbose_name_plural = 'کدهای تخفیف'
        indexes = [
            models.Index(fields=['code']),
            models.Index(fields=['is_active', 'expires_at']),
            models.Index(fields=['equipment_type']),
        ]
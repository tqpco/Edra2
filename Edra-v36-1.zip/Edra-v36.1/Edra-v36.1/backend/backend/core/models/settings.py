# core/models/settings.py
# -*- coding: utf-8 -*-

from django.db import models
from django.core.cache import cache
from django.utils import timezone


class SystemSetting(models.Model):
    """
    تنظیمات پویای سیستم که در پنل ادمین قابل ویرایش است و نیازی به دیپلوی مجدد ندارد.
    """
    key = models.CharField(
        max_length=100,
        unique=True,
        verbose_name='کلید',
        db_index=True,
    )
    value = models.JSONField(
        default=dict,
        verbose_name='مقدار',
    )
    description = models.TextField(
        blank=True,
        verbose_name='توضیحات',
    )
    is_active = models.BooleanField(
        default=True,
        verbose_name='فعال',
        db_index=True,
    )
    updated_at = models.DateTimeField(
        auto_now=True,
        verbose_name='تاریخ بروزرسانی',
        db_index=True,
    )
    created_at = models.DateTimeField(
        auto_now_add=True,
        verbose_name='تاریخ ایجاد',
        db_index=True,
    )

    class Meta:
        verbose_name = 'تنظیمات سیستم'
        verbose_name_plural = 'تنظیمات سیستم'
        ordering = ['key']

    def __str__(self) -> str:
        return self.key

    @classmethod
    def get_value(cls, key: str, default=None):
        """
        دریافت مقدار یک تنظیم با کش خودکار.
        """
        cache_key = f'system_setting_{key}'
        value = cache.get(cache_key)
        if value is not None:
            return value

        try:
            setting = cls.objects.get(key=key, is_active=True)
            cache.set(cache_key, setting.value, 3600)  # کش ۱ ساعته
            return setting.value
        except cls.DoesNotExist:
            return default

    @classmethod
    def set_value(cls, key: str, value):
        """
        تنظیم مقدار و پاک کردن کش.
        """
        setting, created = cls.objects.get_or_create(key=key)
        setting.value = value
        setting.save(update_fields=['value', 'updated_at'])
        cache.delete(f'system_setting_{key}')

    def save(self, *args, **kwargs):
        super().save(*args, **kwargs)
        cache.delete(f'system_setting_{self.key}')
# core/models/user.py
# -*- coding: utf-8 -*-

import hashlib
import hmac

from django.conf import settings
from django.db import models
from django.contrib.auth import get_user_model
from django.core.validators import RegexValidator

User = get_user_model()


def hash_otp_code(raw_code: str) -> str:
    """
    EDRA v27 — رفع باگ بحرانی (گزارش ممیزی کاربر، سپتامبر ۲۰۲۶): تابع
    یکتای هش‌کردن کد OTP — هم در ساخت (OTPRequestView) و هم در تایید
    (OTPVerifyView) باید دقیقاً همین تابع استفاده شود، وگرنه تایید کدها
    شکست می‌خورد. HMAC-SHA256 با SECRET_KEY به‌عنوان کلید — سریع (چون
    OTP کوتاه‌عمر و rate-limited است، نیازی به PBKDF2/Argon2 کند نیست).
    """
    return hmac.new(
        settings.SECRET_KEY.encode(), raw_code.encode(), hashlib.sha256
    ).hexdigest()


class UserProfile(models.Model):
    user = models.OneToOneField(
        User,
        on_delete=models.CASCADE,
        related_name='profile',
        verbose_name='کاربر',
        db_index=True,
    )
    # EDRA v36 — باگ: `unique=True` روی فیلدی که برای کاربرِ بدون شماره مقدار
    # خالی '' می‌گیرد؛ دومین کاربر بدون شماره (ادمین/کارشناس ساخته‌شده از پنل،
    # یا اولین باز شدن /profile) با IntegrityError و خطای ۵۰۰ مواجه می‌شد.
    # یکتایی اکنون فقط برای شماره‌های «غیرخالی» است (UniqueConstraint شرطی).
    phone = models.CharField(
        max_length=15,
        validators=[
            RegexValidator(r'^09\d{9}$', 'شماره موبایل باید با 09 شروع شود و 11 رقم باشد.')
        ],
        verbose_name='شماره موبایل',
        db_index=True,
    )
    registration_number = models.CharField(
        max_length=50,
        blank=True,
        verbose_name='شماره ثبت / کد ملی',
        db_index=True,
    )
    company_name = models.CharField(
        max_length=200,
        blank=True,
        verbose_name='نام شرکت',
        db_index=True,
    )
    projects = models.ManyToManyField(
        'Project',
        blank=True,
        verbose_name='پروژه‌ها',
    )
    covered_cities = models.ManyToManyField(
        'CityMultiplier',
        blank=True,
        related_name='covering_experts',
        verbose_name='شهرهای تحت پوشش (کارشناس)',
    )
    bio = models.TextField(
        blank=True,
        verbose_name='بیوگرافی (کارشناس)',
    )
    expertise = models.CharField(
        max_length=255,
        blank=True,
        verbose_name='حوزه تخصص (کارشناس)',
        db_index=True,
    )
    years_experience = models.PositiveSmallIntegerField(
        null=True,
        blank=True,
        verbose_name='سابقه کار به سال (کارشناس)',
    )
    created_at = models.DateTimeField(
        auto_now_add=True,
        verbose_name='تاریخ ایجاد',
        db_index=True,
    )
    updated_at = models.DateTimeField(
        auto_now=True,
        verbose_name='تاریخ بروزرسانی',
        db_index=True,
    )

    def __str__(self) -> str:
        return f"{self.user.get_full_name()} - {self.phone}"

    class Meta:
        verbose_name = 'پروفایل کاربر'
        verbose_name_plural = 'پروفایل‌های کاربران'
        ordering = ['user__username']
        indexes = [
            models.Index(fields=['phone']),
            models.Index(fields=['user']),
        ]
        constraints = [
            models.UniqueConstraint(
                fields=['phone'],
                condition=~models.Q(phone=''),
                name='uniq_userprofile_phone_nonempty'),
        ]


class OTPCode(models.Model):
    phone = models.CharField(
        max_length=15,
        verbose_name='شماره موبایل',
        db_index=True,
    )
    code = models.CharField(
        max_length=64,
        verbose_name='کد',
        # EDRA v27 — رفع باگ بحرانی (گزارش ممیزی کاربر، سپتامبر ۲۰۲۶):
        # قبلاً کد ۶ رقمی OTP به‌صورت متن‌ساده ذخیره می‌شد؛ در صورت نشت
        # دیتابیس/بکاپ، تمام کدها قابل‌خواندن بودند. حالا هش HMAC-SHA256
        # ذخیره می‌شود (نه خودِ کد) — طول فیلد برای همین افزایش یافت.
    )
    created_at = models.DateTimeField(
        auto_now_add=True,
        verbose_name='تاریخ ایجاد',
        db_index=True,
    )
    is_used = models.BooleanField(
        default=False,
        verbose_name='استفاده شده',
        db_index=True,
    )
    attempts = models.PositiveSmallIntegerField(
        default=0,
        verbose_name='تعداد تلاش',
    )

    class Meta:
        verbose_name = 'کد تایید'
        verbose_name_plural = 'کدهای تایید'
        ordering = ['-created_at']
        indexes = [
            models.Index(fields=['phone', 'created_at']),
            models.Index(fields=['is_used']),
        ]

    def __str__(self) -> str:
        return f"OTP {self.phone} ({'استفاده‌شده' if self.is_used else 'معتبر'})"
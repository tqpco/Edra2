# core/pagination.py
from rest_framework.pagination import PageNumberPagination


class EdraPageNumberPagination(PageNumberPagination):
    """
    EDRA v27 — قابلیت تازه (گزارش کاربر، سپتامبر ۲۰۲۶): قبلاً هیچ
    page_size_query_param تنظیم نشده بود، یعنی هر پارامتر ?page_size=
    که کلاینت می‌فرستاد بی‌صدا نادیده گرفته می‌شد (مثلاً تقویم کارشناس
    که برای گرفتن همه‌ی بازرسی‌های یک ماه در یک درخواست به آن نیاز
    داشت). max_page_size برای جلوگیری از سوءاستفاده (درخواست هزاران
    رکورد در یک صفحه) محدود شده است.
    """
    page_size = 25
    page_size_query_param = 'page_size'
    max_page_size = 200

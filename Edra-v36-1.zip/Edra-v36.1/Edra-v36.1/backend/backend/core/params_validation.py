# core/params_validation.py
# -*- coding: utf-8 -*-
"""
EDRA v36 — اعتبارسنجی سمت سرور برای «params» درخواست بازرسی.

ریشه‌ی مشکل: params مستقیماً از کلاینت (JSONField) ذخیره و در قیمت‌گذاری
(pricing.utils.calculate_price_with_components) ضرب می‌شد، بدون هیچ اعتبارسنجی:
  • عدد منفی (مثلاً tonnage=-50) هزینه‌ی پارامتر را منفی و قیمت را ارزان می‌کرد؛
  • حذف پارامترِ «اجباری» هزینه‌ی آن را حذف و قیمت را ارزان می‌کرد؛
  • NaN/Infinity در quantize خطای ۵۰۰ می‌داد؛
  • کلید رزروشده‌ی is_deposit (که سیستم برای «واریز اعتبار» دارد) قابل تزریق بود.
فرانت‌اند فقط UX است؛ این تابع تنها مرجع معتبر است.
"""
from decimal import Decimal, InvalidOperation

from rest_framework import serializers

# کلیدهایی که فقط سیستم می‌نویسد و کلاینت هرگز نباید بفرستد.
RESERVED_PARAM_KEYS = frozenset({'is_deposit'})
# «service_type» را view بعد از اعتبارسنجی خودش اضافه می‌کند.
SYSTEM_PARAM_KEYS = frozenset({'service_type'})

MAX_NUMBER = Decimal('1000000000')   # سقف منطقی برای هر پارامتر عددی
MAX_TEXT_LEN = 200


def _is_empty(value):
    return value is None or (isinstance(value, str) and not value.strip())


def clean_request_params(equipment_type, params, strict=True):
    """
    params ورودی را با پارامترهای «فعال» همان نوع تجهیز اعتبارسنجی و پاک‌سازی
    می‌کند و dict تمیز (JSON-safe) برمی‌گرداند. در خطا ValidationError.

    strict=False (فقط برای «پیش‌نمایش قیمت» وسط تایپ کاربر): مقدارهای نامعتبر
    و پارامترهای اجباریِ هنوز-پرنشده خطا نمی‌دهند و صرفاً از محاسبه کنار
    گذاشته می‌شوند؛ ثبت واقعی همیشه strict است.
    """
    if params is None:
        params = {}
    if not isinstance(params, dict):
        raise serializers.ValidationError(
            {'params': 'پارامترها باید یک شیء (dict) باشند.'})

    definitions = {}
    if equipment_type is not None:
        definitions = {
            p.name: p for p in equipment_type.parameters.filter(is_active=True)}

    cleaned = {}
    errors = {}

    for name, definition in definitions.items():
        value = params.get(name)
        label = definition.label or name

        if _is_empty(value):
            if definition.required:
                errors[name] = f'«{label}» الزامی است.'
            continue

        ftype = definition.field_type
        if ftype == 'number':
            if isinstance(value, bool):
                errors[name] = f'«{label}» باید عدد باشد.'
                continue
            try:
                number = Decimal(str(value).strip())
            except (InvalidOperation, ValueError):
                errors[name] = f'«{label}» باید عدد باشد.'
                continue
            if not number.is_finite():
                errors[name] = f'«{label}» باید عدد معتبر باشد.'
                continue
            if number < 0:
                errors[name] = f'«{label}» نمی‌تواند منفی باشد.'
                continue
            if number > MAX_NUMBER:
                errors[name] = f'«{label}» بیش از حد مجاز است.'
                continue
            cleaned[name] = (
                int(number) if number == number.to_integral_value()
                else float(number))
        elif ftype == 'boolean':
            if isinstance(value, bool):
                cleaned[name] = value
            elif str(value).strip().lower() in ('true', '1', 'yes', 'on'):
                cleaned[name] = True
            elif str(value).strip().lower() in ('false', '0', 'no', 'off'):
                cleaned[name] = False
            else:
                errors[name] = f'«{label}» باید بله/خیر باشد.'
        elif ftype == 'select':
            options = definition.get_options_list()
            text = str(value).strip()
            if options and text not in options:
                errors[name] = f'«{label}»: گزینه‌ی انتخاب‌شده معتبر نیست.'
                continue
            cleaned[name] = text
        else:  # string / date / time
            text = str(value).strip()
            if len(text) > MAX_TEXT_LEN:
                errors[name] = f'«{label}» بیش از حد طولانی است.'
                continue
            cleaned[name] = text

    if errors and strict:
        raise serializers.ValidationError({'params': errors})

    # کلیدهای ناشناخته (خارج از تعریف تجهیز) حذف می‌شوند؛ فقط کلیدهای سیستمی
    # مجاز و کلیدهای رزروشده هرگز از کلاینت پذیرفته نمی‌شوند.
    for key in SYSTEM_PARAM_KEYS:
        if key in params and key not in RESERVED_PARAM_KEYS:
            cleaned[key] = params[key]
    return cleaned

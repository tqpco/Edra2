# ============================================================
# ۱. فایل core/permissions.py (کامل)
# مسیر: backend/core/permissions.py
# ============================================================
from rest_framework.permissions import BasePermission, SAFE_METHODS
from guardian.shortcuts import get_perms


def is_admin_user(user) -> bool:
    """
    EDRA v6 — P1 (نقش canonical): تعریف واحد Admin.
    قبلاً بعضی جاها فقط is_staff و بعضی فقط group=Admin بود؛ این ناسازگاری
    باعث می‌شد staff بدون گروه Admin در بعضی endpointها دسترسی مدیریتی
    داشته باشد ولی queryset کامل نگیرد. همه‌جا باید از همین helper استفاده
    شود.
    EDRA v27 — رفع N+1 (تایید ممیزی هوش مصنوعی، سپتامبر ۲۰۲۶): این تابع
    می‌تواند چندین‌بار در پردازش یک درخواست فراخوانی شود (چند permission
    class/چک جدا)؛ نتیجه‌ی کوئری گروه روی خودِ آبجکت user (نه cache
    سراسری/بین‌درخواستی — تا هیچ ریسک stale شدن مجوز نداشته باشد) ذخیره
    می‌شود.
    """
    if not (user and user.is_authenticated):
        return False
    if user.is_staff or user.is_superuser:
        return True
    cached = getattr(user, '_edra_is_admin_group_cache', None)
    if cached is None:
        cached = user.groups.filter(name='Admin').exists()
        try:
            user._edra_is_admin_group_cache = cached
        except Exception:
            pass  # اگر user قابل‌تغییر نبود (مثلاً AnonymousUser)، نادیده گرفته می‌شود
    return cached


def is_expert_user(user) -> bool:
    return bool(
        user and user.is_authenticated
        and user.groups.filter(name='Expert').exists())


def is_support_user(user) -> bool:
    return bool(
        user and user.is_authenticated
        and user.groups.filter(name='Support').exists())


def is_support_or_admin(user) -> bool:
    """
    مدیر/پشتیبان: staff یا عضو گروه Support/Admin.

    EDRA v33: consumer تیکت (support/consumers.py) این تابع را از همین ماژول
    import می‌کرد ولی وجود نداشت → ImportError در هر اتصال به ws/tickets/
    (WebSocket تیکت هرگز کار نمی‌کرد). تعریف واحد اینجاست و support/views.py
    هم از همین استفاده می‌کند.
    """
    if not (user and user.is_authenticated):
        return False
    return bool(user.is_staff or user.groups.filter(
        name__in=['Support', 'Admin']).exists())


def get_user_role(user) -> str:
    """
    EDRA v27 — قابلیت تازه (گزارش کاربر، سپتامبر ۲۰۲۶): «سیستم تفکیک
    اتوماتیک مدیر/کارشناس/مشتری». این تابع تنها منبع واحد نقش برای
    embed کردن در claim توکن JWT است (هم برای middleware فرانت‌اند، هم
    هرجای دیگر) — از همان canonical helperهای بالا استفاده می‌کند تا
    هیچ‌وقت با UserSerializer.get_role ناهماهنگ نشود.
    """
    if is_admin_user(user) or is_support_user(user):
        return 'admin'
    if is_expert_user(user):
        return 'expert'
    return 'customer'


class IsAdminGroup(BasePermission):
    """کاربر باید عضو گروه Admin باشد"""

    def has_permission(self, request, view):
        return request.user and request.user.is_authenticated and request.user.groups.filter(
            name='Admin').exists()


class IsAdminOrReadOnly(BasePermission):
    """
    CRITICAL-02 / HIGH-09: برای resourceهای مدیریتی (Blog/FAQ/KB/Announcement/
    SavedReply) — خواندن برای همه مجاز است (یا طبق نیاز احراز هویت)، ولی
    create/update/delete فقط برای Admin (is_staff یا گروه Admin).

    این کلاس جایگزین ترکیب‌های ناامن `IsAuthenticatedOrReadOnly` / `AllowAny`
    روی ModelViewSet می‌شود که در عمل متدهای write را برای کاربر عادی باز
    می‌کردند.
    """

    #: اگر True باشد، متدهای خواندن نیاز به احراز هویت دارند (برای
    #: Announcement/SavedReply که محتوای داخلی دارند).
    require_auth_for_read = False
    #: نقش‌های دیگری که علاوه بر Admin اجازه‌ی write دارند (مثلاً Support
    #: برای SavedReply).
    write_groups = ('Admin',)

    def _is_admin(self, user):
        # EDRA v27 — رفع باگ واقعی (گزارش ممیزی کاربر، سپتامبر ۲۰۲۶):
        # is_superuser چک نمی‌شد — این کلاس پایه به سه کلاس دیگر هم به
        # ارث می‌رسد (FAQ/Announcement/SavedReply/KnowledgeBase/BlogPost)
        # پس یک سوپریوزر بدون is_staff صریح از مدیریت همه‌ی این‌ها ۴۰۳
        # می‌گرفت.
        return bool(
            user and user.is_authenticated
            and (user.is_staff or user.is_superuser or user.groups.filter(
                name__in=self.write_groups).exists()))

    def has_permission(self, request, view):
        if request.method in SAFE_METHODS:
            if self.require_auth_for_read:
                return bool(
                    request.user and request.user.is_authenticated)
            return True
        return self._is_admin(request.user)


class IsAdminOrSupportOrReadOnly(IsAdminOrReadOnly):
    """خواندن برای کاربران احراز هویت‌شده؛ write فقط Admin یا Support."""
    require_auth_for_read = True
    write_groups = ('Admin', 'Support')


class IsAdminOrAuthenticatedReadOnly(IsAdminOrReadOnly):
    """خواندن برای کاربران احراز هویت‌شده؛ write فقط Admin."""
    require_auth_for_read = True


class IsAdminUserOrGroup(BasePermission):
    """
    یکسان‌سازی مجوز ادمین: یا is_staff/is_superuser است یا عضو گروه
    Admin. ادمین‌های پنل که از طریق گروه ساخته شده‌اند (بدون is_staff)
    باید به تمام endpoint های مدیریتی دسترسی داشته باشند.
    EDRA v27 — رفع باگ واقعی (گزارش ممیزی کاربر، سپتامبر ۲۰۲۶): این
    کلاس is_superuser را چک نمی‌کرد (فقط is_staff/گروه)، درحالی‌که تابع
    canonical بالای همین فایل (is_admin_user) از قبل درست بود — حالا
    مستقیماً از همان تابع استفاده می‌شود تا این دو هیچ‌وقت دوباره از هم
    جدا نیفتند.
    """

    def has_permission(self, request, view):
        return is_admin_user(request.user)


class IsExpertGroup(BasePermission):
    """کاربر باید عضو گروه Expert باشد"""

    def has_permission(self, request, view):
        return request.user and request.user.is_authenticated and request.user.groups.filter(
            name='Expert').exists()


class IsAdminOrExpert(BasePermission):
    """
    EDRA v26 — اصلاح: کاربر یا Admin است یا Expert
    قبلاً فقط عضویت در گروه Admin/Expert بررسی می‌شد و
    کاربران is_staff بدون گروه (مثل سوپریوزر) 403 می‌خوردند.
    """

    def has_permission(self, request, view):
        if not request.user or not request.user.is_authenticated:
            return False
        return (request.user.is_staff
                or request.user.is_superuser
                or request.user.groups.filter(name__in=['Admin', 'Expert']).exists())


class IsCustomerOrAdmin(BasePermission):
    """کاربر یا Admin است یا مالک درخواست (مشتری)"""

    def has_object_permission(self, request, view, obj):
        # L-4 (v17): استفاده از helper canonical (is_staff یا گروه Admin)
        if is_admin_user(request.user):
            return True
        if hasattr(obj, 'customer'):
            return obj.customer == request.user
        return False


class ObjectPermissionForInspectionReport(BasePermission):
    """
    مجوز سطح شیء برای InspectionReport
    """

    def has_object_permission(self, request, view, obj):
        # L-4 (v17): استفاده از helper canonical (is_staff یا گروه Admin)
        if is_admin_user(request.user):
            return True
        perms = get_perms(request.user, obj)
        if request.method in SAFE_METHODS:
            return 'view_inspectionreport' in perms
        elif request.method in ['PUT', 'PATCH']:
            return 'change_inspectionreport' in perms
        elif request.method == 'DELETE':
            return 'delete_inspectionreport' in perms
        return False


class IsAdminOrHasObjectPermissionForInspectionRequest(BasePermission):
    """
    مجوز برای InspectionRequest (EDRA v6 — P1 defense-in-depth):

    قبلاً GET در has_object_permission برای همه برمی‌گشت True و امنیت فقط
    به queryset ViewSet وابسته بود؛ اگر View دیگری از این permission استفاده
    می‌کرد و queryset را فراموش می‌کرد، IDOR رخ می‌داد. حالا مالکیت در
    خود permission هم enforce می‌شود:
      - Admin (is_staff یا گروه Admin) → کامل
      - مالک مشتری / کارشناس assigned → کامل
      - بقیه → رد
    """

    def has_permission(self, request, view):
        return bool(request.user and request.user.is_authenticated)

    def has_object_permission(self, request, view, obj):
        user = request.user
        if not user or not user.is_authenticated:
            return False
        if is_admin_user(user):
            return True
        # مالکیت (defense-in-depth — مستقل از queryset)
        is_owner = (hasattr(obj, 'customer')
                    and obj.customer_id == user.id)
        is_assigned_expert = (hasattr(obj, 'assigned_expert_id')
                              and obj.assigned_expert_id == user.id)
        # EDRA v36: مالک/کارشناس قبلاً برای «همه‌ی متدها» (از جمله DELETE) True
        # می‌گرفتند؛ مشتری می‌توانست درخواست خودش را حذف کند (و کارشناسِ
        # تخصیص‌یافته هم) در حالی که مستندات ViewSet «فقط ادمین» می‌گوید.
        # اکنون مالکیت فقط خواندن را می‌دهد؛ نوشتن نیاز به مجوز صریح دارد.
        if request.method in SAFE_METHODS and (is_owner or is_assigned_expert):
            return True
        perms = get_perms(user, obj)
        if request.method in SAFE_METHODS:
            return 'view_inspectionrequest' in perms
        if request.method in ['PUT', 'PATCH']:
            # ویرایش فقط توسط «مالک مشتری» با مجوز change (کارشناس هرگز).
            return is_owner and 'change_inspectionrequest' in perms
        # DELETE فقط ادمین (بالاتر برگشت)؛ مجوز guardian برای حذف ندهید.
        return False
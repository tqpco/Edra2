# core/search.py
# -*- coding: utf-8 -*-

from django.contrib.postgres.search import SearchVector, SearchQuery, SearchRank
from django.db.models import Q
from typing import List, Tuple, Any


class FullTextSearchMixin:
    """
    Mixin برای افزودن قابلیت جستجوی فول‌تکست به ViewSet‌ها.
    """

    search_fields: List[str] = []  # لیست فیلدهای جستجو
    search_vector_fields: List[str] = []  # فیلدهایی که در SearchVector استفاده می‌شوند

    def get_search_queryset(self, queryset, search_term: str):
        if not search_term or not self.search_vector_fields:
            return queryset

        # ساخت SearchVector از فیلدهای مشخص
        from django.contrib.postgres.search import SearchVector
        vector = SearchVector(*self.search_vector_fields)
        query = SearchQuery(search_term)
        return queryset.annotate(rank=SearchRank(vector, query)).filter(rank__gt=0.01).order_by('-rank')

    # EDRA v36: با وجود search_vector_fields، پارامتر ?search= قبلاً «کل»
    # filter_queryset را دور می‌زد: فیلترهای status/city/تاریخ/ترتیب نادیده
    # گرفته می‌شدند، جستجو فقط با «کلمه‌ی کامل» (SearchRank>0.01) پیدا می‌کرد
    # (تایپ نیمه‌کاره‌ی «تهر» هیچ نتیجه‌ای نداشت) و روی SQLite اصلاً کار نمی‌کرد.
    # اکنون جستجوی فول‌تکست فقط در صورت `use_fulltext = True` فعال می‌شود و
    # در حالت پیش‌فرض SearchFilter استاندارد DRF (icontains روی search_fields) روی
    # همه‌ی فیلترها اعمال می‌شود.
    use_fulltext = False

    def filter_queryset(self, queryset):
        queryset = super().filter_queryset(queryset)
        search_term = self.request.query_params.get('search', '')
        if self.use_fulltext and search_term and self.search_vector_fields:
            return self.get_search_queryset(queryset, search_term)
        return queryset
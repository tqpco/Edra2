# ============================================================
# فایل: core/serializers.py (اصلاح شده نهایی - جایگزینی با edra_jalalidate)
# ============================================================
from rest_framework import serializers
from django.contrib.auth import get_user_model
from django.utils import timezone
from .models import (
    EquipmentType, CityMultiplier, Organization, Project,
    InspectionRequest, DiscountCode, AuditLog, OTPCode,
    PaymentMethod, Payment, Invoice, UserCredit, CreditTransaction,
    ChecklistTemplate, ChecklistItem, InspectionReport,
    ReportVerification, SequenceCounter, ErrorLog, EquipmentParameter,
    UserProfile,
)
# ✅ جایگزینی utils.date_utils با edra_jalalidate
from edra_jalalidate import to_jalali


User = get_user_model()


# ============================================================
# سریالایزرهای پایه
# ============================================================

class EquipmentTypeSerializer(serializers.ModelSerializer):
    class Meta:
        model = EquipmentType
        fields = '__all__'


class CityMultiplierSerializer(serializers.ModelSerializer):
    class Meta:
        model = CityMultiplier
        fields = '__all__'


class OrganizationSerializer(serializers.ModelSerializer):
    class Meta:
        model = Organization
        fields = '__all__'


class ProjectSerializer(serializers.ModelSerializer):
    class Meta:
        model = Project
        fields = '__all__'


# ============================================================
# سریالایزر کاربر (با قابلیت نوشتن)
# ============================================================

class UserSerializer(serializers.ModelSerializer):
    # EDRA v32 — بازنویسی ریشه‌ای (دو باگ واقعی که صفحات ادمین را خراب می‌کرد):
    #  ۱) phone/company_name/registration_number فیلدهای «بدون source» بودند و
    #     مقدارشان روی مدل User وجود ندارد (داده در UserProfile است) → همیشه
    #     null برمی‌گشت و در ساخت/ویرایش هم هرگز ذخیره نمی‌شد (کلید profile
    #     ساخته‌شده توسط to_internal_value در super حذف می‌شد).
    #  ۲) full_name هم CharField ساده بود (متد get_full_name روی مدل است نه
    #     attribute) → هرگز در خروجی نبود.
    # علاوه بر آن: شماره موبایل (unique) قبل از ذخیره اعتبارسنجی نمی‌شد →
    # شماره تکراری = IntegrityError = خطای 500؛ و ساخت User + Profile اتمیک نبود.
    full_name = serializers.SerializerMethodField()
    date_joined_jalali = serializers.SerializerMethodField()
    role = serializers.SerializerMethodField()

    phone = serializers.CharField(
        source='profile.phone', required=False, allow_blank=True, allow_null=True)
    registration_number = serializers.CharField(
        source='profile.registration_number', required=False,
        allow_blank=True, allow_null=True)
    company_name = serializers.CharField(
        source='profile.company_name', required=False,
        allow_blank=True, allow_null=True)

    projects = serializers.PrimaryKeyRelatedField(
        source='profile.projects', many=True, read_only=True)
    project_names = serializers.SerializerMethodField()
    groups = serializers.SlugRelatedField(
        slug_field='name', many=True, read_only=True)

    class Meta:
        model = User
        fields = (
            'id', 'username', 'email', 'first_name', 'last_name', 'full_name',
            'is_active', 'is_staff', 'is_superuser', 'groups', 'role', 'phone',
            'date_joined', 'date_joined_jalali', 'registration_number',
            'company_name', 'projects', 'project_names'
        )
        read_only_fields = ('id', 'date_joined', 'date_joined_jalali', 'is_staff', 'is_superuser')

    _PERSIAN_DIGITS = str.maketrans('۰۱۲۳۴۵۶۷۸۹٠١٢٣٤٥٦٧٨٩', '01234567890123456789')

    def get_full_name(self, obj):
        return obj.get_full_name() or obj.username

    def get_date_joined_jalali(self, obj):
        return to_jalali(obj.date_joined)

    def get_role(self, obj):
        # EDRA v27 — هر دو (claim توکن و این فیلد) از یک منبع واحد می‌آیند.
        from .permissions import get_user_role
        return get_user_role(obj)

    def get_project_names(self, obj):
        profile = getattr(obj, 'profile', None)
        if profile:
            return [p.name for p in profile.projects.all()]
        return []

    def validate_phone(self, value):
        if value in (None, ''):
            return value
        import re
        value = str(value).strip().translate(self._PERSIAN_DIGITS)
        if not re.match(r'^09\d{9}$', value):
            raise serializers.ValidationError(
                'شماره موبایل باید با 09 شروع شود و 11 رقم باشد.')
        qs = UserProfile.objects.filter(phone=value)
        if self.instance is not None:
            qs = qs.exclude(user=self.instance)
        if qs.exists():
            raise serializers.ValidationError('این شماره موبایل قبلاً ثبت شده است.')
        # ورود OTP کاربر را با username == phone پیدا می‌کند؛ پس شماره نباید با
        # username کاربر دیگری برخورد کند.
        user_qs = User.objects.filter(username=value)
        if self.instance is not None:
            user_qs = user_qs.exclude(pk=self.instance.pk)
        if user_qs.exists():
            raise serializers.ValidationError('این شماره موبایل قبلاً ثبت شده است.')
        return value

    def validate(self, attrs):
        # شماره موبایل در مدل unique و غیرخالی است؛ بدون آن، دومین کاربر
        # با phone='' نیز IntegrityError می‌دهد.
        if self.instance is None:
            phone = (attrs.get('profile') or {}).get('phone')
            if not phone:
                raise serializers.ValidationError(
                    {'phone': 'شماره موبایل الزامی است.'})
        return attrs

    def to_internal_value(self, data):
        mutable_data = data.copy() if hasattr(data, 'copy') else dict(data)

        full_name = mutable_data.pop('full_name', None)
        if isinstance(full_name, list):  # QueryDict.pop لیست برمی‌گرداند
            full_name = full_name[0] if full_name else None
        if full_name and not mutable_data.get('first_name') and not mutable_data.get('last_name'):
            parts = str(full_name).strip().split(' ', 1)
            mutable_data['first_name'] = parts[0]
            mutable_data['last_name'] = parts[1] if len(parts) > 1 else ''

        # فقط هنگام ساخت: اگر username نیامد، شماره موبایل جایگزین می‌شود
        if self.instance is None and not mutable_data.get('username'):
            phone = mutable_data.get('phone')
            if phone:
                mutable_data['username'] = str(phone).strip().translate(self._PERSIAN_DIGITS)

        return super().to_internal_value(mutable_data)

    def create(self, validated_data):
        from django.db import transaction
        profile_data = validated_data.pop('profile', None) or {}
        with transaction.atomic():
            user = User.objects.create_user(
                username=validated_data['username'],
                email=validated_data.get('email', ''),
                first_name=validated_data.get('first_name', ''),
                last_name=validated_data.get('last_name', ''),
            )
            if 'is_active' in validated_data and not validated_data['is_active']:
                user.is_active = False
                user.save(update_fields=['is_active'])
            UserProfile.objects.create(
                user=user,
                phone=profile_data.get('phone') or '',
                company_name=profile_data.get('company_name') or '',
                registration_number=profile_data.get('registration_number') or '',
            )
        return user

    def update(self, instance, validated_data):
        from django.db import transaction
        profile_data = validated_data.pop('profile', None) or {}
        with transaction.atomic():
            # EDRA v32: ورود OTP با username == phone انجام می‌شود. اگر شماره‌ی کاربرِ
            # OTP‌محور عوض شد، username هم هم‌گام می‌شود؛ وگرنه شماره‌ی جدید یک حساب
            # تکراریِ خالی می‌ساخت و حساب اصلی با شماره‌ی قدیمی می‌ماند.
            new_phone = profile_data.get('phone')
            old_profile = getattr(instance, 'profile', None)
            old_phone = getattr(old_profile, 'phone', None)
            if (new_phone and 'username' not in validated_data
                    and instance.username == old_phone and new_phone != old_phone):
                validated_data['username'] = new_phone

            for attr in ('first_name', 'last_name', 'email', 'username', 'is_active'):
                if attr in validated_data:
                    setattr(instance, attr, validated_data[attr])
            instance.save()

            if profile_data:
                profile = getattr(instance, 'profile', None)
                if profile is None:
                    if profile_data.get('phone'):
                        UserProfile.objects.create(
                            user=instance,
                            phone=profile_data.get('phone'),
                            company_name=profile_data.get('company_name') or '',
                            registration_number=profile_data.get('registration_number') or '',
                        )
                else:
                    for attr in ('phone', 'company_name', 'registration_number'):
                        if attr in profile_data and (attr != 'phone' or profile_data[attr]):
                            setattr(profile, attr, profile_data[attr] or '')
                    profile.save()
        return instance


# ============================================================
# سریالایزر InspectionRequest (با امکان تعیین مشتری توسط ادمین)
# ============================================================

class InspectionRequestSerializer(serializers.ModelSerializer):
    equipment_type_name = serializers.CharField(
        source='equipment_type.name_fa', read_only=True)
    customer_name = serializers.CharField(
        source='customer.username', read_only=True)
    assigned_expert_name = serializers.CharField(
        source='assigned_expert.username', read_only=True)
    created_at_jalali = serializers.SerializerMethodField()
    updated_at_jalali = serializers.SerializerMethodField()
    scheduled_at_jalali = serializers.SerializerMethodField()
    discount_code = serializers.SlugRelatedField(
        slug_field='code',
        queryset=DiscountCode.objects.all(),
        required=False,
        allow_null=True,
    )

    class Meta:
        model = InspectionRequest
        fields = '__all__'
        read_only_fields = (
            'customer',  # ✅ مشتری فقط از طریق ویو تنظیم می‌شود و در validation اجباری نیست
            'calculated_price',
            'final_price',
            'created_at',
            'updated_at')

    def get_created_at_jalali(self, obj):
        return to_jalali(obj.created_at)

    def get_updated_at_jalali(self, obj):
        return to_jalali(obj.updated_at)

    def get_scheduled_at_jalali(self, obj):
        return to_jalali(obj.scheduled_at)

    def validate_city(self, value):
        # EDRA v36: شهرِ نامعتبر قبلاً هزینه‌ی شهر (base_cost × multiplier) را صفر
        # می‌کرد (calculate_price_with_components بی‌صدا از آن رد می‌شود) و فقط
        # پیش‌نمایش آن را چک می‌کرد، نه ثبت. اگر ضرایب شهر تعریف شده باشد، شهر
        # باید یکی از شهرهای «فعال» باشد.
        if value in (None, ''):
            return value
        inst = getattr(self, 'instance', None)
        if inst is not None and inst.city == value:
            return value
        from .models import CityMultiplier
        if (CityMultiplier.objects.exists()
                and not CityMultiplier.objects.filter(
                    city=value, is_active=True).exists()):
            raise serializers.ValidationError(
                'شهر انتخاب‌شده معتبر یا فعال نیست.')
        return value

    def validate_equipment_type(self, value):
        # EDRA v32: تجهیز غیرفعال‌شده توسط ادمین قابل رزرو نیست (فقط هنگام ساخت)
        if self.instance is None and not getattr(value, 'is_active', True):
            raise serializers.ValidationError('این نوع تجهیز در حال حاضر قابل رزرو نیست.')
        return value

    def validate_scheduled_at(self, value):
        if value is None:
            return value

        # EDRA v34: قواعد «از فردا به بعد / روز کاری / ساعت کاری» فقط وقتی
        # اعمال می‌شوند که زمان واقعاً تغییر کرده یا درخواست جدید است. قبلاً با
        # هر PATCH که scheduled_at فعلی (حتی قدیمی/امروز) را دوباره می‌فرستاد،
        # خطای حداقل‌زمان می‌آمد و ویرایش هر فیلد دیگر ادمین رد می‌شد.
        instance = getattr(self, 'instance', None)
        if instance is not None and instance.scheduled_at is not None:
            try:
                cmp_value = (value.togregorian()
                             if hasattr(value, 'togregorian') else value)
                if cmp_value == instance.scheduled_at:
                    return value
            except Exception:
                pass

        try:
            dt = value.togregorian() if hasattr(value, 'togregorian') else value
        except Exception:
            return value

        now = timezone.now()
        if timezone.is_naive(dt):
            dt = timezone.make_aware(dt, timezone.get_current_timezone())
        now_local = timezone.localtime(now)
        dt_local = timezone.localtime(dt)

        # EDRA v34: هم‌راستا با ویزارد (قابلیت v27: رزرو «امروز» با حداقل ۳
        # ساعت فاصله). قبلاً اینجا «حداقل از فردا» بود و مشتری که امروز را
        # انتخاب می‌کرد تا مرحله‌ی آخر پیش می‌رفت و بعد خطا می‌گرفت.
        if dt_local < now_local + timezone.timedelta(hours=3):
            raise serializers.ValidationError(
                'زمان کارشناسی باید حداقل ۳ ساعت بعد از اکنون باشد.')
        if dt_local.weekday() == 4:
            raise serializers.ValidationError(
                'جمعه‌ها جزو بازه کاری نیست، لطفاً روز دیگری انتخاب کنید.')
        if not (8 <= dt_local.hour < 16 or (dt_local.hour == 16 and dt_local.minute == 0)):
            raise serializers.ValidationError(
                'زمان کارشناسی فقط بین ساعت ۸:۰۰ تا ۱۶:۰۰ قابل انتخاب است.')
        return value

    def validate(self, attrs):
        request = self.context.get('request')
        user = request.user if request else None

        # ✅ اعتبارسنجی مشتری: فقط ادمین می‌تواند برای کاربر دیگری درخواست ثبت کند
        customer = attrs.get('customer')
        if customer and user and not (user.is_staff or user.groups.filter(name='Admin').exists()):
            raise serializers.ValidationError(
                {'customer': 'شما اجازه ثبت درخواست برای کاربر دیگری را ندارید.'})

        # ------------------------------------------------------------
        # EDRA v36 — اعتبارسنجی سمت سرور (باگ بحرانی مالی/امنیتی)
        # ------------------------------------------------------------
        _is_admin = bool(
            user and user.is_authenticated and (
                user.is_staff or user.is_superuser
                or user.groups.filter(name='Admin').exists()))
        if self.instance is None:
            # فیلدهای workflow/داخلی هرگز از مشتری پذیرفته نمی‌شوند: قبلاً هر
            # مشتری می‌توانست در ثبت، assigned_expert (و بعد مجوز guardian آن
            # کاربر)، request_number یا project سازمان دیگر را بنویسد.
            for _internal in ('price_breakdown',):
                attrs.pop(_internal, None)
            if not _is_admin:
                for _internal in ('assigned_expert', 'request_number', 'project'):
                    attrs.pop(_internal, None)

        if self.instance is None or 'params' in attrs:
            # قبلاً params هیچ اعتبارسنجی نداشت: مقدار منفی/حذف پارامتر اجباری
            # قیمت را ارزان می‌کرد و is_deposit قابل تزریق بود.
            from core.params_validation import clean_request_params
            _eq = attrs.get('equipment_type') or getattr(
                self.instance, 'equipment_type', None)
            attrs['params'] = clean_request_params(_eq, attrs.get('params'))

        # اعتبارسنجی کد تخفیف
        discount = attrs.get('discount_code')
        if discount:
            if not discount.is_active:
                raise serializers.ValidationError(
                    {'discount_code': 'این کد تخفیف غیرفعال است.'})
            if discount.expires_at and discount.expires_at < timezone.now():
                raise serializers.ValidationError(
                    {'discount_code': 'این کد تخفیف منقضی شده است.'})
            if discount.usage_limit and discount.used_count >= discount.usage_limit:
                raise serializers.ValidationError(
                    {'discount_code': 'ظرفیت استفاده از این کد تخفیف تمام شده است.'})
            equipment_type = attrs.get('equipment_type')
            if (not discount.apply_to_all and discount.equipment_type_id
                    and equipment_type and discount.equipment_type_id != equipment_type.id):
                raise serializers.ValidationError(
                    {'discount_code': 'این کد تخفیف برای این نوع تجهیزات معتبر نیست.'})
            if discount.per_user_limit and user and user.is_authenticated:
                used_by_user = InspectionRequest.objects.filter(
                    customer=user, discount_code=discount
                ).exclude(status__in=('cancelled', 'expired')).count()
                if used_by_user >= discount.per_user_limit:
                    raise serializers.ValidationError(
                        {'discount_code': 'شما قبلاً از این کد تخفیف استفاده کرده‌اید.'})
            if not _is_admin:
                from .services.discount_service import campaign_owner_error
                _owner_err = campaign_owner_error(discount, user)
                if _owner_err:
                    raise serializers.ValidationError(
                        {'discount_code': _owner_err})
        return attrs

    def create(self, validated_data):
        # EDRA v32 — رفع باگ: مصرف کد تخفیف (used_count += 1) در تراکنش کوچک خودش
        # commit می‌شد و «بعدش» محدودیت ۵ درخواست باز / خطای ذخیره چک می‌شد؛ پس هر
        # تلاش ناموفق یک ظرفیت کد تخفیف را می‌سوزاند. حالا کل ساخت درخواست یک
        # تراکنش واحد است: هر خطا → used_count هم برمی‌گردد.
        from django.db import transaction as _tx
        with _tx.atomic():
            return self._create_atomic(validated_data)

    def _create_atomic(self, validated_data):
        from pricing.utils import calculate_price_with_components
        request = self.context.get('request')
        user = request.user if request else None
        equipment_type = validated_data['equipment_type']
        params = validated_data.get('params') or {}
        install_state = validated_data.get('install_state')
        city = validated_data.get('city')
        service_type = validated_data.get('service_type', 'standard')
        discount = validated_data.get('discount_code')

        components = calculate_price_with_components(
            equipment_type, params, install_state,
            city_name=city, service_type=service_type,
        )
        calculated_price = components['total']

        final_price = calculated_price
        if discount:
            from django.db import transaction
            with transaction.atomic():
                discount = DiscountCode.objects.select_for_update().get(pk=discount.pk)
                if discount.usage_limit and discount.used_count >= discount.usage_limit:
                    raise serializers.ValidationError(
                        {'discount_code': 'ظرفیت استفاده از این کد تخفیف تمام شده است.'})
                _limit_user = validated_data.get('customer') or user
                if discount.per_user_limit and _limit_user and _limit_user.is_authenticated:
                    used_by_user = InspectionRequest.objects.filter(
                        customer=_limit_user, discount_code=discount
                    ).exclude(status__in=('cancelled', 'expired')).count()
                    if used_by_user >= discount.per_user_limit:
                        raise serializers.ValidationError(
                            {'discount_code': 'شما قبلاً از این کد تخفیف استفاده کرده‌اید.'})
                if discount.min_amount and calculated_price < discount.min_amount:
                    raise serializers.ValidationError(
                        {'discount_code': 'مبلغ درخواست کمتر از حداقل مجاز برای این کد تخفیف است.'})
                if discount.discount_type == 'percent':
                    discount_amount = calculated_price * discount.value / 100
                else:
                    discount_amount = discount.value
                if discount.max_amount:
                    discount_amount = min(discount_amount, discount.max_amount)
                final_price = max(calculated_price - discount_amount, 0)
                discount.used_count = discount.used_count + 1
                discount.save(update_fields=['used_count'])
                from .services.discount_service import mark_discount_used
                mark_discount_used(discount, _limit_user)

        # ✅ تعیین مشتری: اگر ادمین مقدار ارسال کرده باشد از آن استفاده کن، در غیر این صورت کاربر جاری
        customer = validated_data.get('customer')
        if not customer:
            customer = user
        validated_data['customer'] = customer

        # EDRA v27 — قابلیت تازه (گزارش کاربر، سپتامبر ۲۰۲۶): کاربر
        # نباید بیش از ۵ «درخواست باز» (ثبت‌شده ولی هنوز پرداخت‌نشده)
        # هم‌زمان داشته باشد.
        if customer and customer.is_authenticated:
            OPEN_STATUSES = ('draft', 'pending_payment', 'waiting_manual_payment')
            open_count = InspectionRequest.objects.filter(
                customer=customer, status__in=OPEN_STATUSES
            ).count()
            if open_count >= 5:
                raise serializers.ValidationError(
                    {'non_field_errors': [
                        'شما حداکثر ۵ درخواست پرداخت‌نشده می‌توانید هم‌زمان داشته باشید. '
                        'لطفاً ابتدا یکی از درخواست‌های قبلی خود را پرداخت یا لغو کنید.'
                    ]})

        validated_data['calculated_price'] = calculated_price
        validated_data['final_price'] = final_price
        validated_data['price_breakdown'] = components
        validated_data.setdefault('status', 'draft')
        return super().create(validated_data)


class InspectionRequestUpdateSerializer(InspectionRequestSerializer):
    PROTECTED_AFTER_PAID = {
        'equipment_type', 'params', 'city', 'address', 'brand_model',
        'manufacture_year', 'service_type', 'install_state', 'scheduled_at',
    }

    class Meta(InspectionRequestSerializer.Meta):
        read_only_fields = InspectionRequestSerializer.Meta.read_only_fields + (
            'status', 'assigned_expert', 'request_number', 'discount_code', 'project'
        )

    def validate(self, attrs):
        instance = getattr(self, 'instance', None)
        if instance is not None:
            editable_states = {
                # EDRA v27 — رفع کد مرده (گزارش ممیزی کاربر): 'rejected'
                # حذف شد چون جزو STATUS_CHOICES مدل InspectionRequest
                # نیست (این مقدار مربوط به Payment.status است، نه
                # درخواست) — هرگز نمی‌توانست match شود.
                'draft', 'pending_payment', 'waiting_manual_payment',
                'cancelled', 'expired',
            }
            if instance.status not in editable_states:
                protected = set(self.PROTECTED_AFTER_PAID)
                # ادمین می‌تواند زمان بازرسی را بعد از پرداخت تغییر دهد
                # (جابه‌جایی زمان؛ وضعیت می‌شود rescheduled). فیلدهای فنی/
                # آدرس/قیمت‌ساز همچنان قفل می‌مانند.
                _req = self.context.get('request')
                _usr = _req.user if _req else None
                if _usr and (_usr.is_staff or _usr.groups.filter(
                        name='Admin').exists()):
                    protected.discard('scheduled_at')
                    if instance.status in ('completed', 'cancelled', 'expired',
                                           'in_progress'):
                        protected.add('scheduled_at')
                # فقط فیلدهایی که «مقدارشان واقعاً عوض شده» (فرم ویرایش
                # ادمین همه‌ی فیلدها را می‌فرستد؛ قبلاً صرفِ حضور کلید کافی
                # بود تا ذخیره‌ی هر تغییر مجاز رد شود).
                def _differs(key):
                    new_val = attrs.get(key)
                    old_val = getattr(instance, key, None)
                    try:
                        if key == 'scheduled_at' and new_val is not None:
                            new_val = (new_val.togregorian()
                                       if hasattr(new_val, 'togregorian')
                                       else new_val)
                        return new_val != old_val
                    except Exception:
                        return True
                changed = {k for k in (set(attrs.keys()) & protected)
                           if _differs(k)}
                if changed:
                    raise serializers.ValidationError(
                        {'detail': (
                            f'پس از پرداخت، فیلدهای '
                            f'{", ".join(sorted(changed))} قابل تغییر نیستند. '
                            'برای تغییر باید از پشتیبانی استفاده کنید.')})

        # ✅ اجازه تغییر مشتری فقط برای ادمین
        request = self.context.get('request')
        user = request.user if request else None
        customer = attrs.get('customer')
        if customer and user and not (user.is_staff or user.groups.filter(name='Admin').exists()):
            raise serializers.ValidationError(
                {'customer': 'شما اجازه تغییر مشتری درخواست را ندارید.'})

        attrs = super().validate(attrs)

        # EDRA v36 — باگ بحرانی مالی: قیمت فقط هنگام «ثبت» محاسبه می‌شد؛ مشتری
        # (که مجوز change گاردین دارد) تا قبل از پرداخت می‌توانست equipment_type /
        # params / install_state / service_type / city را عوض کند و قیمتِ قبلیِ
        # ارزان برای مشخصات گران می‌ماند. فیلدهای «قیمت‌ساز» برای غیرادمین پس از
        # ثبت قفل است (برای تغییر: درخواست جدید).
        _is_admin = bool(
            user and user.is_authenticated and (
                user.is_staff or user.is_superuser
                or user.groups.filter(name='Admin').exists()))
        if instance is not None and not _is_admin:
            from core.params_validation import SYSTEM_PARAM_KEYS

            def _strip(p):
                return {k: v for k, v in (p or {}).items()
                        if k not in SYSTEM_PARAM_KEYS}

            locked = []
            for key in ('equipment_type', 'params', 'city',
                        'install_state', 'service_type'):
                if key not in attrs:
                    continue
                new_val = attrs[key]
                if key == 'equipment_type':
                    changed = getattr(new_val, 'pk', new_val) != instance.equipment_type_id
                elif key == 'params':
                    changed = _strip(new_val) != _strip(instance.params)
                else:
                    changed = new_val != getattr(instance, key, None)
                if changed:
                    locked.append(key)
            if locked:
                raise serializers.ValidationError(
                    {'detail': (
                        'تغییر مشخصات تعیین‌کننده‌ی قیمت '
                        f'({", ".join(sorted(locked))}) پس از ثبت ممکن نیست؛ '
                        'یک درخواست جدید ثبت کنید.')})
        return attrs


class InspectionRequestListSerializer(InspectionRequestSerializer):
    class Meta(InspectionRequestSerializer.Meta):
        fields = (
            'id', 'title', 'request_number', 'status', 'city', 'address',
            'brand_model', 'install_state', 'service_type', 'params',
            'final_price', 'calculated_price', 'scheduled_at',
            'equipment_type', 'equipment_type_name',
            'customer', 'customer_name', 'assigned_expert',
            'assigned_expert_name', 'project', 'created_at',
            'created_at_jalali', 'updated_at_jalali',
            'scheduled_at_jalali',
        )
        read_only_fields = InspectionRequestSerializer.Meta.read_only_fields + (
            'status', 'assigned_expert', 'request_number', 'project',
        )


# ============================================================
# سریالایزرهای دیگر (بدون تغییر)
# ============================================================

class DiscountCodeSerializer(serializers.ModelSerializer):
    equipment_type_name = serializers.CharField(
        source='equipment_type.name_fa', read_only=True, allow_null=True)
    expires_at_jalali = serializers.SerializerMethodField()

    class Meta:
        model = DiscountCode
        fields = '__all__'
        read_only_fields = ('id', 'used_count')

    def validate(self, attrs):
        # EDRA v35: مقدار منفی/صفر یا درصد بالای ۱۰۰ قبلاً قابل ذخیره بود؛
        # مقدار منفی در مسیر ثبت درخواست «قیمت را بالا می‌برد».
        inst = getattr(self, 'instance', None)
        value = attrs.get('value', getattr(inst, 'value', None))
        dtype = attrs.get('discount_type', getattr(inst, 'discount_type', None))
        if value is not None and value <= 0:
            raise serializers.ValidationError(
                {'value': 'مقدار تخفیف باید بیشتر از صفر باشد.'})
        if dtype == 'percent' and value is not None and value > 100:
            raise serializers.ValidationError(
                {'value': 'درصد تخفیف نمی‌تواند بیشتر از ۱۰۰ باشد.'})
        return attrs

    def get_expires_at_jalali(self, obj):
        return to_jalali(obj.expires_at)

class PublicDiscountCodeSerializer(serializers.ModelSerializer):
    """
    EDRA v32 — SEC: سریالایزر جدا و محدود برای مرور عمومی مشتری
    (/api/core/customer/discount-codes/). عمداً مجزا از DiscountCodeSerializer
    نگه داشته شده تا فیلدهای مدیریتی/حساس (usage_limit، used_count،
    per_user_limit) هرگز با یک `fields = '__all__'` بی‌احتیاطانه به مشتری
    درز نکنند، حتی اگر فیلد جدیدی به مدل اضافه شود.
    """
    equipment_type_name = serializers.CharField(
        source='equipment_type.name_fa', read_only=True, allow_null=True)
    expires_at_jalali = serializers.SerializerMethodField()

    class Meta:
        model = DiscountCode
        fields = (
            'code', 'discount_type', 'value', 'min_amount', 'max_amount',
            'apply_to_all', 'equipment_type_name', 'expires_at', 'expires_at_jalali',
        )
        read_only_fields = fields

    def get_expires_at_jalali(self, obj):
        return to_jalali(obj.expires_at)


class PaymentMethodSerializer(serializers.ModelSerializer):
    # EDRA v32: `name` کلید سیستمی است (online/manual/credit) و قابل تغییر نیست؛
    # ادمین فقط is_active و description را ویرایش می‌کند.
    name_display = serializers.CharField(source='get_name_display', read_only=True)

    class Meta:
        model = PaymentMethod
        fields = ('id', 'name', 'name_display', 'is_active', 'description', 'created_at')
        read_only_fields = ('id', 'name', 'name_display', 'created_at')


class PaymentSerializer(serializers.ModelSerializer):
    created_at_jalali = serializers.SerializerMethodField()
    updated_at_jalali = serializers.SerializerMethodField()
    verified_at_jalali = serializers.SerializerMethodField()
    rejected_at_jalali = serializers.SerializerMethodField()
    bank_receipt_uploaded_at_jalali = serializers.SerializerMethodField()

    class Meta:
        model = Payment
        fields = '__all__'
        read_only_fields = [
            'status', 'authority', 'ref_id', 'transaction_id',
            'amount', 'amount_rial', 'credit_amount', 'online_amount',
            'manual_amount', 'verified_by', 'verified_at',
            'rejected_by', 'rejected_at', 'rejection_reason',
        ]

    def get_created_at_jalali(self, obj):
        return to_jalali(obj.created_at)

    def get_updated_at_jalali(self, obj):
        return to_jalali(obj.updated_at)

    def get_verified_at_jalali(self, obj):
        return to_jalali(obj.verified_at)

    def get_rejected_at_jalali(self, obj):
        return to_jalali(obj.rejected_at)

    def get_bank_receipt_uploaded_at_jalali(self, obj):
        return to_jalali(obj.bank_receipt_uploaded_at)


class InvoiceSerializer(serializers.ModelSerializer):
    issue_date_jalali = serializers.SerializerMethodField()
    due_date_jalali = serializers.SerializerMethodField()
    paid_at_jalali = serializers.SerializerMethodField()

    class Meta:
        model = Invoice
        fields = '__all__'

    def get_issue_date_jalali(self, obj):
        return to_jalali(obj.issue_date)

    def get_due_date_jalali(self, obj):
        return to_jalali(obj.due_date)

    def get_paid_at_jalali(self, obj):
        return to_jalali(obj.paid_at)


class UserCreditSerializer(serializers.ModelSerializer):
    updated_at_jalali = serializers.SerializerMethodField()

    class Meta:
        model = UserCredit
        fields = '__all__'

    def get_updated_at_jalali(self, obj):
        return to_jalali(obj.updated_at)


class CreditTransactionSerializer(serializers.ModelSerializer):
    created_at_jalali = serializers.SerializerMethodField()

    class Meta:
        model = CreditTransaction
        fields = '__all__'

    def get_created_at_jalali(self, obj):
        return to_jalali(obj.created_at)


class ChecklistItemSerializer(serializers.ModelSerializer):
    class Meta:
        model = ChecklistItem
        fields = '__all__'


class ChecklistTemplateSerializer(serializers.ModelSerializer):
    items = ChecklistItemSerializer(many=True, read_only=True)
    created_at_jalali = serializers.SerializerMethodField()
    updated_at_jalali = serializers.SerializerMethodField()

    class Meta:
        model = ChecklistTemplate
        fields = '__all__'

    def get_created_at_jalali(self, obj):
        return to_jalali(obj.created_at)

    def get_updated_at_jalali(self, obj):
        return to_jalali(obj.updated_at)


class InspectionReportSerializer(serializers.ModelSerializer):
    inspection_request_detail = InspectionRequestSerializer(
        source='inspection_request', read_only=True)
    overall_result_display = serializers.SerializerMethodField()
    created_at_jalali = serializers.SerializerMethodField()
    updated_at_jalali = serializers.SerializerMethodField()
    signed_at_jalali = serializers.SerializerMethodField()

    class Meta:
        model = InspectionReport
        fields = '__all__'
        read_only_fields = (
            'report_number', 'created_at', 'updated_at', 'signed_at', 'signature_hash'
        )

    def get_overall_result_display(self, obj):
        return obj.get_overall_result_display() if obj.overall_result else None

    def get_created_at_jalali(self, obj):
        return to_jalali(obj.created_at)

    def get_updated_at_jalali(self, obj):
        return to_jalali(obj.updated_at)

    def get_signed_at_jalali(self, obj):
        return to_jalali(obj.signed_at)


class InspectionReportDetailSerializer(InspectionReportSerializer):
    pass


class ReportVerificationSerializer(serializers.ModelSerializer):
    report_number = serializers.CharField(
        source='report.report_number', read_only=True)
    inspection_request_id = serializers.IntegerField(
        source='report.inspection_request.id', read_only=True)
    equipment_name = serializers.CharField(
        source='report.inspection_request.equipment_type.name_fa',
        read_only=True)
    overall_result = serializers.CharField(
        source='report.overall_result', read_only=True)
    signed_at = serializers.DateTimeField(
        source='report.signed_at', read_only=True)
    created_at_jalali = serializers.SerializerMethodField()
    last_viewed_at_jalali = serializers.SerializerMethodField()

    class Meta:
        model = ReportVerification
        fields = '__all__'

    def get_created_at_jalali(self, obj):
        return to_jalali(obj.created_at)

    def get_last_viewed_at_jalali(self, obj):
        return to_jalali(obj.last_viewed_at)


class AuditLogSerializer(serializers.ModelSerializer):
    timestamp_jalali = serializers.SerializerMethodField()

    class Meta:
        model = AuditLog
        fields = '__all__'

    def get_timestamp_jalali(self, obj):
        return to_jalali(obj.timestamp)


class ErrorLogSerializer(serializers.ModelSerializer):
    timestamp_jalali = serializers.SerializerMethodField()
    resolved_at_jalali = serializers.SerializerMethodField()

    class Meta:
        model = ErrorLog
        fields = '__all__'

    def get_timestamp_jalali(self, obj):
        return to_jalali(obj.timestamp)

    def get_resolved_at_jalali(self, obj):
        return to_jalali(obj.resolved_at)


class OTPRequestSerializer(serializers.Serializer):
    phone = serializers.CharField(max_length=15)


class OTPVerifySerializer(serializers.Serializer):
    phone = serializers.CharField(max_length=15)
    code = serializers.CharField(max_length=6)


class EquipmentParameterSerializer(serializers.ModelSerializer):
    class Meta:
        model = EquipmentParameter
        fields = '__all__'
        read_only_fields = ('id',)
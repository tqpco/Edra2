# core/services/discount_service.py
"""
سرویس مرکزی تخفیف — یک منبع واحد برای اعتبارسنجی و محاسبه.

قوانین:
- اعتبارسنجی: فعال بودن، انقضا، ظرفیت (usage_limit)، سقف هر کاربر
  (per_user_limit)، نوع تجهیزات، حداقل مبلغ.
- محاسبه: percent/fixed + سقف max_amount؛ نتیجه هرگز منفی نمی‌شود.
- شمارش used_count فقط یک‌بار به ازای هر درخواست (اتمیک با
  select_for_update) و فقط در زمان اعمال واقعی (create یا apply-discount)،
  نه در پیش‌نمایش.
"""
import logging
from decimal import Decimal

from django.db import transaction

logger = logging.getLogger(__name__)


def compute_discount_amount(discount, amount: Decimal) -> Decimal:
    """مبلغ تخفیف از روی مبلغ ورودی (percent/fixed + max_amount)."""
    amount = Decimal(amount)
    if discount.discount_type == 'percent':
        discount_amount = amount * discount.value / Decimal('100')
    else:
        discount_amount = discount.value
    if discount.max_amount:
        discount_amount = min(discount_amount, Decimal(discount.max_amount))
    return max(discount_amount, Decimal('0'))


def validate_discount(discount, *, amount=None, equipment_type=None, user=None,
                      exclude_request=None):
    """
    اعتبارسنجی کد تخفیف؛ در صورت نامعتبر بودن پیام خطای فارسی برمی‌گرداند.
    amount: برای بررسی min_amount (اختیاری)
    equipment_type: برای بررسی نوع تجهیزات (اختیاری)
    user: برای بررسی per_user_limit از طریق تعداد درخواست‌های کاربر (اختیاری)
    """
    from django.utils import timezone
    from ..models import InspectionRequest

    # EDRA v35: amount نامعتبر (رشته‌ی غیرعددی/NaN) قبلاً InvalidOperation و
    # خطای ۵۰۰ می‌داد.
    if amount is not None:
        try:
            amount = Decimal(str(amount))
            if not amount.is_finite():
                raise ValueError
        except Exception:
            return 'مبلغ نامعتبر است.'

    if not discount.is_active:
        return 'این کد تخفیف غیرفعال است.'
    if discount.expires_at and discount.expires_at < timezone.now():
        return 'این کد تخفیف منقضی شده است.'
    if discount.usage_limit and discount.used_count >= discount.usage_limit:
        return 'ظرفیت استفاده از این کد تخفیف تمام شده است.'
    if (amount is not None and discount.min_amount
            and Decimal(amount) < Decimal(discount.min_amount)):
        return f'حداقل مبلغ برای این کد {discount.min_amount:,} تومان است.'
    if (equipment_type is not None and not discount.apply_to_all
            and discount.equipment_type_id
            and discount.equipment_type_id != equipment_type.id):
        return 'این کد تخفیف برای این نوع تجهیزات معتبر نیست.'
    if (user is not None and discount.per_user_limit
            and user.is_authenticated):
        # درخواست‌های لغو/منقضی ظرفیت کاربر را مصرف‌شده حساب نمی‌کنند؛ خودِ
        # درخواستی که کد را همین حالا دارد هم (اعمال مجدد = idempotent).
        used_qs = InspectionRequest.objects.filter(
            customer=user, discount_code=discount
        ).exclude(status__in=('cancelled', 'expired'))
        if exclude_request is not None:
            used_qs = used_qs.exclude(pk=exclude_request.pk)
        used_by_user = used_qs.count()
        if used_by_user >= discount.per_user_limit:
            return 'شما قبلاً از این کد تخفیف استفاده کرده‌اید.'
    return campaign_owner_error(discount, user)


class DiscountApplyError(Exception):
    """خطای اعمال تخفیف (پیام فارسی در .message)."""


def apply_discount_to_request(inspection_request, code, user=None):
    """
    اعمال کد تخفیف روی یک درخواست ساخته‌شده (idempotent).

    - کد تکراری روی همان درخواست → بدون تغییر (شمارش دوباره نمی‌شود).
    - تعویض کد → کد قبلی آزاد و کد جدید شمارش می‌شود.
    - used_count اتمیک (select_for_update).

    خروجی: (discount, discount_amount, new_final_price)
    """
    from ..models import DiscountCode

    discount = find_discount(code)
    if discount is None:
        raise DiscountApplyError('کد تخفیف نامعتبر است.')

    base_amount = (inspection_request.calculated_price
                   or inspection_request.final_price)
    old_discount = inspection_request.discount_code
    same_code = old_discount is not None and old_discount.pk == discount.pk
    # EDRA v35: اعمال مجدد «همان کد» روی همان درخواست idempotent است؛ قبلاً
    # خودِ درخواست در شمارش per_user_limit/usage_limit حساب می‌شد و اعمال
    # مجدد (مثلاً refresh صفحه) خطای «قبلاً استفاده کرده‌اید» می‌داد.
    error = validate_discount(
        discount, amount=base_amount,
        equipment_type=inspection_request.equipment_type,
        user=user or inspection_request.customer,
        exclude_request=inspection_request)
    if error and not (same_code and 'ظرفیت' in error):
        raise DiscountApplyError(error)

    with transaction.atomic():
        discount = DiscountCode.objects.select_for_update().get(pk=discount.pk)
        # بررسی مجدد ظرفیت درون تراکنش (فقط وقتی کد تازه شمارش می‌شود)
        if (not same_code and discount.usage_limit
                and discount.used_count >= discount.usage_limit):
            raise DiscountApplyError('ظرفیت استفاده از این کد تخفیف تمام شده است.')

        if old_discount is not None and not same_code:
            # آزادسازی کد قبلی (با قفل ردیف)
            prev = DiscountCode.objects.select_for_update().get(
                pk=old_discount.pk)
            prev.used_count = max(prev.used_count - 1, 0)
            prev.save(update_fields=['used_count'])

        if not same_code:
            discount.used_count += 1
            discount.save(update_fields=['used_count'])
            mark_discount_used(discount, user or inspection_request.customer)

        discount_amount = compute_discount_amount(discount, base_amount)
        new_final_price = max(base_amount - discount_amount, Decimal('0'))

        inspection_request.discount_code = discount
        inspection_request.final_price = new_final_price
        inspection_request.save(
            update_fields=['discount_code', 'final_price'])

    logger.info(
        f"Discount {discount.code} applied to request "
        f"{inspection_request.id}: -{discount_amount}")
    return discount, discount_amount, new_final_price


def release_request_holds(inspection_request):
    """
    EDRA v35 — آزادسازی «نگه‌داشته‌ها» وقتی درخواست پرداخت‌نشده لغو/منقضی می‌شود:
      ۱) یک واحد از used_count کد تخفیف آن درخواست کم می‌شود؛
      ۲) رزروهای فعال اعتبار همان درخواست آزاد می‌شوند.
    درخواست پرداخت‌شده هرگز به cancelled/expired نمی‌رود (state machine)،
    ولی برای اطمینان اگر پرداخت موفقی دارد، چیزی آزاد نمی‌شود.
    """
    from ..models import CreditReservation, DiscountCode
    from .credit_service import CreditService

    if inspection_request.payments.filter(status='paid').exists():
        return

    with transaction.atomic():
        if inspection_request.discount_code_id:
            code = DiscountCode.objects.select_for_update().get(
                pk=inspection_request.discount_code_id)
            code.used_count = max(code.used_count - 1, 0)
            code.save(update_fields=['used_count'])
        for reservation in CreditReservation.objects.filter(
                inspection_request=inspection_request, status='reserved'):
            CreditService.release(
                reservation,
                reason=f'request {inspection_request.pk} closed')


def campaign_owner_error(discount, user):
    """
    EDRA v36 — کدهای «کمپین» (تخفیف وفاداری/اولین خرید) برای «یک کاربر مشخص»
    ساخته و پیامک می‌شوند (usage_limit=1) ولی هیچ‌جا به آن کاربر وابسته نبودند؛
    هر کسی که کد را می‌دید/می‌شنید می‌توانست مصرفش کند و صاحب واقعی بی‌نصیب
    می‌ماند. اگر کدی با کمپین به کاربری اختصاص یافته باشد فقط همان کاربر مجاز است.
    کدهای عادی/ارسال دستی ادمین (بدون کمپین) محدود نمی‌شوند.
    """
    from discounts.models import DiscountCodeUsage
    owners = list(DiscountCodeUsage.objects.filter(
        discount_code=discount, campaign__isnull=False
    ).values_list('user_id', flat=True))
    if not owners:
        return None
    if (user is None or not getattr(user, 'is_authenticated', False)
            or user.id not in owners):
        return 'این کد تخفیف اختصاصی کاربر دیگری است.'
    return None


def mark_discount_used(discount, user):
    """
    EDRA v36: DiscountCodeUsage.used_at هرگز مقداردهی نمی‌شد؛ ستون «تاریخ
    استفاده» در پنل ادمین (و فیلتر آن) همیشه خالی بود.
    """
    if discount is None or user is None:
        return
    try:
        from django.utils import timezone
        from discounts.models import DiscountCodeUsage
        DiscountCodeUsage.objects.filter(
            user=user, discount_code=discount, used_at__isnull=True
        ).update(used_at=timezone.now())
    except Exception:
        # ثبت تاریخ استفاده هرگز نباید مصرف تخفیف را بشکند
        pass


def find_discount(code, active_only=False):
    """
    EDRA v36: جستجوی کد تخفیف بدون حساسیت به حروف و فاصله‌ی ابتدا/انتها. کدهای
    کمپین به‌صورت حروف بزرگ ساخته می‌شوند و مشتری که آن را (از روی پیامک یا با
    کیبورد موبایل) با حروف کوچک یا با فاصله وارد می‌کرد «کد نامعتبر» می‌گرفت.
    تطبیق دقیق ارجح است؛ در غیر این صورت iexact (قدیمی‌ترین رکورد).
    """
    code = str(code or '').strip()
    if not code:
        return None
    from ..models import DiscountCode
    qs = DiscountCode.objects.all()
    if active_only:
        qs = qs.filter(is_active=True)
    return (qs.filter(code=code).first()
            or qs.filter(code__iexact=code).order_by('id').first())

# core/services/inspection_service.py
# -*- coding: utf-8 -*-
"""
EDRA v34 — منبع واحد گردش‌کار (workflow) وضعیت‌های InspectionRequest.

قبلاً سه تعریف ناهمسان وجود داشت: این فایل (کد مرده؛ هیچ‌جا import نمی‌شد)،
state_machine.py و شرط‌های پراکنده‌ی هر view (مثلاً «کارشناس فقط از
scheduled/paid شروع کند»). نتیجه: درخواستِ «assigned» (وضعیتی که خودِ
assign_expert می‌ساخت) نه شروع می‌شد و نه ثبت گزارش می‌گرفت.

اکنون:
  • ALLOWED_STATUS_TRANSITIONS  → جدول مجاز برای تغییر دستی/ادمین
  • EXPERT_EXECUTABLE_STATUSES  → وضعیت‌هایی که کارشناس می‌تواند بازرسی را
                                  شروع کند / گزارش ثبت کند
  • apply_status_change()       → تنها نقطه‌ی تغییر وضعیت (قفل ردیف + AuditLog)
"""
from __future__ import annotations

import logging
from typing import Dict, Optional, Set

from django.db import transaction

logger = logging.getLogger(__name__)

# وضعیت‌های پایانی: بعد از رسیدن به این وضعیت‌ها دیگر transition مجازی نیست.
TERMINAL_STATUSES = {'completed', 'cancelled', 'expired'}

# وضعیت‌هایی که کارشناسِ تخصیص‌یافته می‌تواند در آن‌ها بازرسی را شروع کند و
# گزارش ثبت کند. («paid» برای ردیف‌های قدیمی که کارشناس دارند ولی هنوز
# «assigned» نشده‌اند.)
EXPERT_EXECUTABLE_STATUSES = (
    'paid', 'assigned', 'scheduled', 'rescheduled', 'in_progress')

# وضعیت‌هایی که ادمین هنوز می‌تواند کارشناس را تخصیص/تعویض کند.
REASSIGNABLE_STATUSES = ('paid', 'assigned', 'scheduled', 'rescheduled')

# map: old_status → set of allowed new_status (workflow مجاز)
ALLOWED_STATUS_TRANSITIONS: Dict[str, Set[str]] = {
    'draft': {'pending_payment', 'cancelled'},
    'pending_payment': {
        'waiting_manual_payment', 'paid', 'cancelled', 'expired',
    },
    'waiting_manual_payment': {
        'pending_payment', 'paid', 'cancelled', 'expired',
    },
    # paid → cancelled/expired بدون refund مجاز نیست (P1-05).
    'paid': {'assigned', 'scheduled', 'in_progress'},
    'assigned': {'scheduled', 'rescheduled', 'in_progress', 'cancelled'},
    'scheduled': {'rescheduled', 'in_progress', 'cancelled'},
    'rescheduled': {'scheduled', 'in_progress', 'cancelled'},
    'in_progress': {'completed', 'cancelled'},
    'completed': set(),      # terminal
    'cancelled': set(),      # terminal
    'expired': set(),        # terminal
}

TRANSITION_ERROR_MESSAGES: Dict[str, str] = {
    'draft': 'درخواست در وضعیت پیش‌نویس است و این تغییر وضعیت مجاز نیست.',
    'pending_payment': 'در انتظار پرداخت — این تغییر وضعیت مجاز نیست.',
    'waiting_manual_payment': 'در انتظار تأیید فیش — این تغییر وضعیت مجاز نیست.',
    'paid': 'پرداخت‌شده — تغییر وضعیت فقط از طریق تخصیص/زمان‌بندی مجاز است.',
    'assigned': 'ارجاع‌شده — این تغییر وضعیت مجاز نیست.',
    'scheduled': 'زمان‌بندی‌شده — این تغییر وضعیت مجاز نیست.',
    'rescheduled': 'زمان‌بندی مجدد — این تغییر وضعیت مجاز نیست.',
    'in_progress': 'در حال بازرسی — این تغییر وضعیت مجاز نیست.',
    'completed': 'درخواست تکمیل‌شده است و وضعیت آن قابل تغییر نیست.',
    'cancelled': 'درخواست لغو شده است و وضعیت آن قابل تغییر نیست.',
    'expired': 'درخواست منقضی شده است و وضعیت آن قابل تغییر نیست.',
}


def can_transition(old_status: str, new_status: str) -> bool:
    """آیا تغییر از old_status به new_status در workflow مجاز است؟"""
    return new_status in ALLOWED_STATUS_TRANSITIONS.get(old_status, set())


def transition_error(old_status: str, new_status: str) -> str:
    base = TRANSITION_ERROR_MESSAGES.get(
        old_status, 'تغییر وضعیت درخواست از وضعیت فعلی مجاز نیست.')
    return f'{base} (از «{old_status}» به «{new_status}»).'


def assert_transition(old_status: str, new_status: str) -> None:
    """raise ValueError اگر transition مجاز نباشد."""
    if not can_transition(old_status, new_status):
        raise ValueError(transition_error(old_status, new_status))


def apply_status_change(inspection_request, new_status: str, *, actor=None,
                        reason: str = '', force: bool = False,
                        extra_update_fields: Optional[list] = None):
    """
    تنها نقطه‌ی تغییر وضعیت درخواست.

    - ردیف با select_for_update قفل و تازه خوانده می‌شود (جلوگیری از race بین
      دو درخواست همزمان: مثلاً دو بار «ثبت گزارش»).
    - اگر force=False باشد، جدول ALLOWED_STATUS_TRANSITIONS اعمال می‌شود؛
      force=True فقط برای مسیرهای سیستمی (ثبت گزارش از هر وضعیت قابل‌اجرا،
      پرداخت و ...) که خودشان پیش‌شرط را بررسی کرده‌اند.
    - updated_at هم به‌روز می‌شود (قبلاً با update_fields=['status'] نمی‌شد).
    - AuditLog با old/new واقعی ثبت می‌شود.
    - اگر وضعیت از قبل برابر باشد، بدون خطا و بدون تغییر برمی‌گردد (idempotent).

    باید داخل transaction.atomic() فراخوانی شود یا خودش یکی باز می‌کند.
    """
    from core.models import AuditLog, InspectionRequest
    from django.utils import timezone

    with transaction.atomic():
        locked = InspectionRequest.objects.select_for_update().get(
            pk=inspection_request.pk)
        old_status = locked.status
        if old_status == new_status:
            inspection_request.status = old_status
            return inspection_request
        if not force:
            assert_transition(old_status, new_status)

        locked.status = new_status
        locked.updated_at = timezone.now()
        fields = ['status', 'updated_at'] + list(extra_update_fields or [])
        locked.save(update_fields=fields)

        try:
            AuditLog.objects.create(
                user=actor if getattr(actor, 'pk', None) else None,
                action='change_status',
                object_id=locked.pk,
                changes={
                    'request_id': locked.pk,
                    'old_status': old_status,
                    'new_status': new_status,
                    'reason': reason,
                })
        except Exception as log_error:  # audit نباید جریان را بشکند
            logger.error(f'AuditLog write failed: {log_error}')

    # نمونه‌ی در دست caller هم همگام شود.
    inspection_request.status = new_status
    inspection_request.updated_at = locked.updated_at
    # سیگنال اعلان روی نمونه‌ی «locked» (با old درست) اجرا شد؛ این نمونه
    # نباید در save بعدی دوباره اعلان بسازد.
    inspection_request._edra_orig_status = new_status
    return inspection_request

# core/services/invoice_service.py
"""
سرویس مرکزی فاکتور — اصلاح FIN-01 / FIN-02 / FIN-03 / FIN-06 از گزارش ممیزی

قوانین:
- تنها نقطه مجاز ایجاد Invoice.objects.create همین سرویس است.
- شماره فاکتور هرگز random نیست؛ از SequenceCounter (شمارنده دیتابیسی)
  با کلید سال شمسی تولید می‌شود: INV-{jalali_year}-{counter:05d}
- عملیات idempotent است: برای هر درخواست فقط یک فاکتور (unique on request).
- snapshot قیمت (پایه/تخفیف/مالیات/نهایی تومان + نهایی ریال) در همین سرویس
  از منبع واحد (InspectionRequest) ساخته و ذخیره می‌شود تا Invoice/Payment
  و گزارش مالی همه از یک مقدار استفاده کنند.
"""
import logging
from decimal import ROUND_HALF_UP, Decimal

from django.conf import settings
from django.contrib.auth import get_user_model
from django.core.files.base import ContentFile
from django.db import IntegrityError, transaction
from django.utils import timezone

from ..models import Invoice, SequenceCounter
from .money import toman_to_rial
# ✅ جایگزینی jalali_date با edra_jalalidate
from edra_jalalidate import JalaliDateTime

logger = logging.getLogger(__name__)

# نرخ مالیات — P0-08 (EDRA v9): از مدل مدیریتی TaxRate (versioned)
# خوانده می‌شود؛ fallback به تنظیمات فقط اگر هیچ نرخی ثبت نشده باشد.
DEFAULT_TAX_RATE = getattr(settings, 'INVOICE_TAX_RATE', Decimal('0.09'))
# مدت سررسید فاکتور
INVOICE_DUE_DAYS = getattr(settings, 'INVOICE_DUE_DAYS', 30)


def resolve_tax_rate_percent(at=None) -> Decimal:
    """
    نرخ مالیات معتبر در تاریخ at (پیش‌فرض: هم‌اکنون) را به‌صورت درصد
    برمی‌گرداند. اگر TaxRate ثبت نشده باشد، از تنظیمات fallback می‌شود.
    """
    try:
        from ..models import TaxRate
        qs = TaxRate.objects.filter(
            is_active=True,
            effective_from__lte=(at or timezone.now()).date(),
        ).order_by('-effective_from')
        rate = qs.first()
        if rate is not None:
            return Decimal(str(rate.rate_percent))
    except Exception:  # pragma: no cover - defensive (جدول هنوز migrate نشده)
        pass
    return Decimal(str((DEFAULT_TAX_RATE * 100).quantize(Decimal('0.01'))))


class DuplicateInvoiceError(Exception):
    """فاکتور برای این درخواست قبلاً ایجاد شده است (idempotency)."""


class InvoiceNumberService:
    """شماره فاکتور قطعی و بدون تصادف."""

    @staticmethod
    def _jalali_year() -> int:
        """دریافت سال جلالی فعلی با استفاده از edra_jalalidate"""
        # ✅ جایگزینی jalali_date با edra_jalalidate
        jdt = JalaliDateTime.from_datetime(timezone.now())
        return jdt.date.year

    @classmethod
    def next_number(cls) -> str:
        """
        شماره بعدی را به‌صورت اتمیک و همزمان‌ایمن تولید می‌کند.
        select_for_update تضمین می‌کند دو درخواست همزمان شماره تکراری نگیرند.
        """
        year = cls._jalali_year()
        with transaction.atomic():
            counter, _ = SequenceCounter.objects.select_for_update().get_or_create(
                key=f'invoice_{year}')
            counter.value += 1
            counter.save(update_fields=['value'])
            return f"INV-{year}-{counter.value:05d}"


class InvoiceSettlementService:
    """ایجاد/تسویه فاکتور — ورودی واحد برای همه مسیرهای مالی."""

    @classmethod
    def payment_snapshot(cls, inspection_request, credit_amount=0) -> dict:
        """
        مبالغ پرداخت از snapshot فاکتور (P0 — گزارش V3 بند ۶/۹/۱۶):
        قانون: Invoice snapshot = immutable؛ Payment = derived from Invoice.

        خروجی:
          amount        = final_amount (پس از تخفیف + مالیات) — تومان
          amount_rial   = final_rial (کل مبلغ به ریال — حسابداری)
          credit_amount = سهم اعتبار (≤ final)
          online_amount = amount − credit_amount (سهم درگاه — تومان)
          online_rial   = مبلغ درگاه به ریال
          tax_amount / discount_amount / total_amount = اجزای snapshot
        """
        snap = cls.build_snapshot(inspection_request)
        final = snap['final_amount']
        credit = Decimal('0')
        if credit_amount:
            # L-3 (v17): clamp مقدار منفی — کلاینت نباید با credit_amount
            # منفی مبلغ آنلاین را بزرگ‌تر از قیمت واقعی کند
            credit = min(
                max(Decimal(str(credit_amount)), Decimal('0')), final)
        online = final - credit
        return {
            'amount': final,
            'amount_rial': snap['final_rial'],
            'tax_amount': snap['tax_amount'],
            'discount_amount': snap['discount_amount'],
            'total_amount': snap['total_amount'],
            'credit_amount': credit,
            'online_amount': online,
            'online_rial': toman_to_rial(online),
        }

    @classmethod
    def build_snapshot(cls, inspection_request, payment=None) -> dict:
        """
        ساخت snapshot قیمت از منبع واحد (درخواست بازرسی).

        قرارداد:
          base_amount      = calculated_price (پیش از تخفیف) یا final_price
          total_amount     = final_price (پس از تخفیف، پیش از مالیات)
          discount_amount  = base - total (≥ 0)
          tax_amount       = درصد نرخ مالیات از base_amount (قبل از تخفیف —
                             تصمیم صریح کاربر، سپتامبر ۲۰۲۶؛ باید دقیقاً با
                             فرمول pricing/views.py هماهنگ بماند)
          final_amount     = total_amount + tax_amount  (تومان)
          final_rial       = toman_to_rial(final_amount) (ریال — canonical)
        """
        base = Decimal(
            inspection_request.calculated_price
            if inspection_request.calculated_price
            else inspection_request.final_price or 0)
        # EDRA v35: `final_price or base` مبلغ صفرِ عمدی (تخفیف ۱۰۰٪) را به
        # قیمت کامل برمی‌گرداند؛ فقط None باید fallback شود.
        total = Decimal(
            inspection_request.final_price
            if inspection_request.final_price is not None else base)
        discount = max(base - total, Decimal('0'))
        # P0-08 (EDRA v9): نرخ از مدل مدیریتی TaxRate (versioned) می‌آید
        tax_rate_percent = resolve_tax_rate_percent()
        # EDRA v27 — تغییر قانونی/کسب‌وکاری (تایید صریح کاربر، سپتامبر
        # ۲۰۲۶): مالیات روی base (قبل از تخفیف) محاسبه می‌شود، نه total.
        tax = (base * tax_rate_percent / Decimal('100')).quantize(
            Decimal(1), rounding=ROUND_HALF_UP)
        final = total + tax
        return {
            'base_amount': base,
            'total_amount': total,
            'discount_amount': discount,
            'tax_rate_percent': tax_rate_percent,
            'tax_amount': tax,
            'final_amount': final,
            'final_rial': toman_to_rial(final),
            'pricing_version': getattr(settings, 'PRICING_VERSION', '1.0'),
            'calculated_at': timezone.now(),
            # EDRA v27 — قابلیت تازه (گزارش کاربر، سپتامبر ۲۰۲۶): ریز
            # اجزای قیمت (هزینه پایه تجهیز، هزینه شهر/سفر، ...) که قبلاً
            # هیچ‌جا برای فاکتور در دسترس نبود.
            'breakdown': inspection_request.price_breakdown or {},
        }

    @classmethod
    def settle(cls, inspection_request, payment=None, *,
               is_paid=True, paid_at=None, user=None,
               raise_on_duplicate=False):
        """
        ایجاد فاکتور برای یک درخواست (idempotent).

        اگر فاکتور وجود داشته باشد:
          - raise_on_duplicate=False → (invoice, False) بدون تغییر
          - raise_on_duplicate=True  → DuplicateInvoiceError
        در غیر این صورت فاکتور + PDF + نوتیفیکیشن ساخته می‌شود → (invoice, True)
        """
        existing = Invoice.objects.filter(
            inspection_request=inspection_request).first()
        if existing:
            if raise_on_duplicate:
                raise DuplicateInvoiceError(
                    f"فاکتور {existing.invoice_number} برای این درخواست قبلاً صادر شده است.")
            return existing, False

        snapshot = cls.build_snapshot(inspection_request, payment)

        try:
            with transaction.atomic():
                invoice = Invoice.objects.create(
                    inspection_request=inspection_request,
                    invoice_number=InvoiceNumberService.next_number(),
                    due_date=timezone.now() + timezone.timedelta(days=INVOICE_DUE_DAYS),
                    base_amount=snapshot['base_amount'],
                    total_amount=snapshot['total_amount'],
                    discount_amount=snapshot['discount_amount'],
                    tax_rate_percent=snapshot['tax_rate_percent'],
                    tax_amount=snapshot['tax_amount'],
                    final_amount=snapshot['final_amount'],
                    final_rial=snapshot['final_rial'],
                    pricing_version=snapshot['pricing_version'],
                    calculated_at=snapshot['calculated_at'],
                    is_paid=is_paid,
                    paid_at=paid_at if is_paid else None,
                    status='pending',
                    retry_count=0,
                    last_error='',
                )
                # EDRA v5 — HIGH-28: ثبت دفتر کل داخل همان transaction؛
                # شکست ledger = شکست کل تسویه (نه silently ادامه).
                # (record_settlement به‌خاطر IntegrityError/duplicate خودش
                # idempotent برمی‌گردد؛ خطاهای واقعی propagate می‌شوند.)
                if payment is not None and is_paid:
                    from .ledger_service import record_settlement
                    record_settlement(payment, performed_by=user)
        except IntegrityError:
            # Race (P0 — گزارش V3 بند ۶): دو تسویه همزمان برای یک درخواست؛
            # unique constraint برنده شد → نتیجه idempotent برمی‌گردد.
            existing = Invoice.objects.filter(
                inspection_request=inspection_request).first()
            if existing:
                return existing, False
            raise

        # تولید PDF: همزمان (پیش‌فرض dev/test) یا از طریق Celery task
        if getattr(settings, 'PDF_GENERATION_ASYNC', False):
            from ..tasks import generate_invoice_pdf_task
            transaction.on_commit(
                lambda: generate_invoice_pdf_task.delay(
                    invoice.id, user.id if user else None))
            logger.info(
                f"Invoice {invoice.invoice_number} created; PDF queued async.")
            return invoice, True

        cls._generate_pdf_and_notify(invoice, user)
        return invoice, True

    @classmethod
    def _generate_pdf_and_notify(cls, invoice, user=None):
        """
        تولید PDF فاکتور (همزمان، قابل retry) + نوتیفیکیشن.
        خارج از تراکنش اجرا می‌شود تا خطای PDF کل تراکنش مالی را نشکند.
        """
        from ..invoice_pdf_generator import generate_invoice_pdf
        from notifications.services import send_notification

        inspection_request = invoice.inspection_request
        customer = inspection_request.customer

        try:
            pdf_content = generate_invoice_pdf(
                invoice=invoice,
                inspection_request=inspection_request,
                customer=customer,
                equipment=inspection_request.equipment_type,
            )
            invoice.pdf_file.save(
                f"invoice_{invoice.invoice_number}.pdf",
                ContentFile(pdf_content),
                save=True)
            invoice.status = 'generated'
            invoice.last_error = ''
            invoice.save(update_fields=['status', 'last_error', 'pdf_file'])
            logger.info(
                f"Invoice {invoice.invoice_number} created and PDF generated.")
            try:
                send_notification(customer, 'invoice_pdf_ready', {
                    'invoice_number': invoice.invoice_number,
                    'invoice_id': invoice.id,
                })
            except Exception as notif_error:
                logger.error(f"Error sending invoice notification: {notif_error}")
        except Exception as pdf_error:
            invoice.status = 'failed'
            invoice.last_error = str(pdf_error)
            invoice.retry_count += 1
            invoice.save(update_fields=['status', 'last_error', 'retry_count'])
            logger.error(
                f"Failed to generate PDF for invoice {invoice.invoice_number}: {pdf_error}")
            try:
                send_notification(customer, 'invoice_pdf_failed', {
                    'request_id': inspection_request.id,
                    'invoice_number': invoice.invoice_number,
                    'error': str(pdf_error),
                })
                from notifications.services import get_admin_users
                for admin in get_admin_users():
                    send_notification(admin, 'invoice_pdf_failed_admin', {
                        'invoice_id': invoice.id,
                        'invoice_number': invoice.invoice_number,
                        'error': str(pdf_error)[:300],
                        'customer': customer.username,
                    })
            except Exception as notif_error:
                logger.error(
                    f"Error sending invoice error notification: {notif_error}")
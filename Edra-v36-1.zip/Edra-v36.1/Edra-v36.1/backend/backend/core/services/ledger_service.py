# core/services/ledger_service.py
"""
دفتر کل حسابداری (P0 — گزارش V3 بند ۱۵/۲۳).

قوانین:
- هر تسویه موفق و هر عودت، یک LedgerEntry غیرقابل‌تغییر ثبت می‌کند.
- idempotent: برای هر payment+entry_type فقط یک ورودی (dedup در مسیرهای
  تکرارشونده مثل callback تکراری).
- گزارش مالی از همین ورودی‌ها reconcile می‌شود.
"""
import logging

from django.db import transaction

# MEDIUM-2 (v17): تبدیل ارز فقط از ماژول مرکزی money
from .money import toman_to_rial

logger = logging.getLogger(__name__)


def record_settlement(payment, performed_by=None, reference=None):
    """
    ثبت تسویه پرداخت موفق (idempotent).

    EDRA v5 — HIGH-29/30: علاوه بر check application-level، یکتایی با
    UniqueConstraint(payment, entry_type) در database تضمین می‌شود؛ در
    race condition، IntegrityError به‌معنای «قبلاً ثبت شده» است.
    """
    from django.db import IntegrityError
    from ..models import LedgerEntry
    if LedgerEntry.objects.filter(
            payment=payment, entry_type='settlement').exists():
        return None
    try:
        with transaction.atomic():
            entry = LedgerEntry.objects.create(
                payment=payment,
                entry_type='settlement',
                amount_toman=payment.amount,
                amount_rial=payment.amount_rial or toman_to_rial(payment.amount),
                reference=reference or payment.ref_id or payment.authority or '',
                performed_by=performed_by,
                metadata={'status_at_settlement': payment.status},
            )
    except IntegrityError:
        logger.warning(
            f"Ledger settlement race: payment={payment.id} already exists")
        return None
    logger.info(
        f"Ledger settlement: payment={payment.id} rial={entry.amount_rial}")
    return entry


def record_refund(payment, performed_by=None, reason='', gateway_ref='',
                  refund=None):
    """ثبت عودت (reversal ledger entry) — idempotent در سطح database."""
    from django.db import IntegrityError
    from ..models import LedgerEntry
    if LedgerEntry.objects.filter(
            payment=payment, entry_type='refund').exists():
        return None
    try:
        with transaction.atomic():
            metadata = {'reason': reason}
            if refund is not None:
                metadata['refund_id'] = refund.id
                metadata['refund_status'] = refund.status
                metadata['gateway_reference'] = refund.gateway_reference
            entry = LedgerEntry.objects.create(
                payment=payment,
                entry_type='refund',
                amount_toman=payment.amount,
                amount_rial=payment.amount_rial or toman_to_rial(payment.amount),
                reference=gateway_ref or payment.ref_id or '',
                performed_by=performed_by,
                metadata=metadata,
            )
    except IntegrityError:
        logger.warning(
            f"Ledger refund race: payment={payment.id} already exists")
        return None
    logger.info(
        f"Ledger refund: payment={payment.id} rial={entry.amount_rial} "
        f"reason={reason}")
    return entry


def ledger_totals(date_from=None, date_to=None):
    """
    مجموع تسویه و عودت از دفتر کل (برای reconciliation).
    EDRA v35: بازه‌ی تاریخ اختیاری (بر اساس تاریخ ثبت ورودی).
    """
    from django.db.models import Sum
    from ..models import LedgerEntry
    qs = LedgerEntry.objects.all()
    if date_from:
        qs = qs.filter(created_at__date__gte=date_from)
    if date_to:
        qs = qs.filter(created_at__date__lte=date_to)
    settlement = qs.filter(
        entry_type='settlement').aggregate(
        total=Sum('amount_rial'))['total'] or 0
    refunds = qs.filter(
        entry_type='refund').aggregate(total=Sum('amount_rial'))['total'] or 0
    return settlement, refunds

# backend/core/services/payment_service.py
# -*- coding: utf-8 -*-

import requests
from django.conf import settings
import logging

logger = logging.getLogger(__name__)


def _gateway_data(result):
    """
    EDRA v35 — زرین‌پال در خطا `"data": []` (لیست خالی) برمی‌گرداند، نه dict.
    قبلاً `result.get('data', {}).get('code')` روی لیست AttributeError می‌داد
    و پیام واقعی خطای درگاه گم می‌شد (کاربر «'list' object has no
    attribute 'get'» می‌دید). همیشه یک dict برگردان.
    """
    data = result.get('data') if isinstance(result, dict) else None
    return data if isinstance(data, dict) else {}


def _gateway_error(result, default):
    errors = result.get('errors') if isinstance(result, dict) else None
    if isinstance(errors, dict):
        return errors.get('message') or default
    return default


class ZarinpalService:
    """
    سرویس ارتباط با درگاه زرین‌پال (نسخه v4).
    تمام مقادیر پیکربندی هر بار از settings خوانده می‌شوند تا با
    @override_settings در تست‌ها سازگار باشند.
    """

    @classmethod
    def _merchant_id(cls):
        return settings.ZARINPAL_MERCHANT_ID

    @classmethod
    def _sandbox(cls):
        return getattr(settings, 'ZARINPAL_SANDBOX', True)

    @classmethod
    def get_base_url(cls):
        if cls._sandbox():
            return 'https://sandbox.zarinpal.com/pg/v4/payment/'
        return 'https://api.zarinpal.com/pg/v4/payment/'

    @classmethod
    def create_payment(cls, amount, description, callback_url, metadata=None):
        url = cls.get_base_url() + 'request.json'
        data = {
            'merchant_id': cls._merchant_id(),
            'amount': int(amount),
            'description': description,
            'callback_url': callback_url,
            'metadata': metadata or {},
        }
        try:
            response = requests.post(url, json=data, timeout=10)
            result = response.json()
            gw = _gateway_data(result)
            if gw.get('code') == 100 and gw.get('authority'):
                authority = gw['authority']
                payment_url = f"https://{'sandbox.' if cls._sandbox() else ''}zarinpal.com/pg/StartPay/{authority}"
                return {
                    'success': True,
                    'authority': authority,
                    'payment_url': payment_url,
                }
            else:
                error = _gateway_error(result, 'خطا در ایجاد پرداخت')
                logger.error(f"Zarinpal create error: {error}")
                return {'success': False, 'error': error}
        except Exception as e:
            logger.exception("Zarinpal create exception")
            return {'success': False, 'error': str(e)}

    @classmethod
    def verify_payment(cls, authority, amount):
        url = cls.get_base_url() + 'verify.json'
        data = {
            'merchant_id': cls._merchant_id(),
            'authority': authority,
            'amount': int(amount),
        }
        try:
            response = requests.post(url, json=data, timeout=10)
            result = response.json()
            gw = _gateway_data(result)
            # کد ۱۰۰ = تایید موفق؛ کد ۱۰۱ = «قبلاً تایید شده» (مثلاً callback
            # قبلی بعد از verify موفق و قبل از commit دیتابیس قطع شده) — در هر
            # دو حالت پول واقعاً دریافت شده و ref_id در پاسخ هست.
            if gw.get('code') in (100, 101) and gw.get('ref_id') is not None:
                return {
                    'success': True,
                    'ref_id': str(gw['ref_id']),
                }
            else:
                error = _gateway_error(result, 'خطا در تایید پرداخت')
                logger.error(f"Zarinpal verify error: {error}")
                return {'success': False, 'error': error}
        except Exception as e:
            # خطای شبکه/timeout/JSON نامعتبر = «نامعلوم»، نه «ناموفق». نتیجه‌ی
            # تراکنش را نمی‌دانیم؛ caller نباید پرداخت را قطعی ناموفق کند.
            logger.exception("Zarinpal verify exception")
            return {'success': False, 'error': str(e), 'transient': True}

    @classmethod
    def refund_payment(cls, authority, ref_id, amount_rial):
        """
        عودت واقعی وجه به درگاه زرین‌پال.

        - Sandbox: عودت واقعی در sandbox زرین‌پال پشتیبانی کامل ندارد؛
          برای تست، موفقیت شبیه‌سازی می‌شود (مستند در پاسخ gateway_status).
        - Production: فراخوانی API عودت زرین‌پال انجام می‌شود؛ فقط پاسخ
          موفق یعنی پول واقعاً برگشته است.
        خروجی: {'success': bool, 'reference': str|None, 'error': str|None}
        """
        if cls._sandbox():
            # شبیه‌سازی صادقانه برای sandbox — در Production واقعی است
            return {
                'success': True,
                'reference': f'SANDBOX-REFUND-{ref_id or authority}',
                'gateway_status': 'sandbox_simulated',
                'error': None,
            }
        try:
            url = 'https://api.zarinpal.com/pg/v4/payment/refund.json'
            data = {
                'merchant_id': cls._merchant_id(),
                'authority': authority,
                'amount': int(amount_rial),
            }
            response = requests.post(url, json=data, timeout=15)
            result = response.json()
            gw = _gateway_data(result)
            # در Zarinpal v4، کد 100 در data یعنی موفق
            if gw.get('code') == 100:
                return {
                    'success': True,
                    'reference': str(gw.get(
                        'ref_id', gw.get('reference', ''))),
                    'gateway_status': 'refunded',
                    'error': None,
                }
            error = _gateway_error(result, 'خطای ناشناخته در عودت درگاه')
            logger.error(f"Zarinpal refund error: {error}")
            return {
                'success': False, 'reference': None,
                'gateway_status': 'refund_failed', 'error': error}
        except Exception as e:
            logger.exception("Zarinpal refund exception")
            return {
                'success': False, 'reference': None,
                'gateway_status': 'refund_failed', 'error': str(e)}


# ============================================================
# settle_admin_payment — مسیر رسمی تأیید دستی پرداخت از Admin
# ============================================================
def settle_admin_payment(payment, verified_by):
    """
    تأیید یک پرداخت (manual/online) توسط Admin با settlement کامل.

    - فقط pending / pending_verification قابل تأییدند.
    - مصرف رزروهای اعتبار (consume_for_payment)
    - فاکتور + ledger از InvoiceSettlementService (idempotent)
    - درخواست به 'paid' منتقل می‌شود
    - برای واریز اعتبار (is_deposit) به‌جای آن موجودی افزایش می‌یابد
    """
    from django.db import transaction
    from django.utils import timezone
    from django.contrib.auth import get_user_model
    from ..models import UserCredit, CreditTransaction
    from .credit_service import CreditService
    from .invoice_service import InvoiceSettlementService
    from notifications.services import send_notification
    import logging
    logger = logging.getLogger(__name__)

    with transaction.atomic():
        from django.db.models import F
        payment = type(payment).objects.select_for_update().get(
            pk=payment.pk)
        if payment.status not in ('pending', 'pending_verification'):
            raise ValueError(
                f'پرداخت #{payment.id} در وضعیت قابل تأیید نیست '
                f'({payment.status}).')

        # EDRA v35: درخواست هم قفل می‌شود و «قبل از» هر تغییر مالی بررسی
        # می‌شود (قبلاً فقط view تایید این چک را داشت؛ اکشن Django-admin
        # می‌توانست پرداخت درخواستِ لغو/منقضی را «paid» کند).
        from ..models import InspectionRequest
        inspection_request = InspectionRequest.objects.select_for_update(
        ).get(pk=payment.inspection_request_id)
        user = inspection_request.customer

        is_deposit = bool(
            inspection_request.params
            and inspection_request.params.get('is_deposit'))

        if not is_deposit and inspection_request.status not in (
                'pending_payment', 'waiting_manual_payment', 'paid'):
            raise ValueError(
                f'وضعیت درخواست ({inspection_request.status}) برای تایید '
                'پرداخت مناسب نیست (لغو یا منقضی شده است). این پرداخت را '
                'رد یا بازپرداخت کنید.')

        payment.status = 'paid'
        payment.verified_by = verified_by
        payment.verified_at = timezone.now()
        if not payment.amount_rial:
            from .money import toman_to_rial
            payment.amount_rial = toman_to_rial(payment.amount)
        payment.save()

        if is_deposit:
            # واریز اعتبار: موجودی افزایش + تراکنش ثبت
            credit, _ = UserCredit.objects.select_for_update().get_or_create(
                user=user)
            credit.balance += payment.amount
            credit.save(update_fields=['balance'])
            CreditTransaction.objects.create(
                user=user,
                amount=payment.amount,
                transaction_type='deposit',
                description=(
                    f'واریز اعتبار به مبلغ {payment.amount:,} تومان - '
                    f'تأیید شده توسط {verified_by.username}'),
                balance_after=credit.balance,
                reference_id=str(payment.id))
            inspection_request.status = 'completed'
            inspection_request.save(update_fields=['status'])
        else:
            # مصرف رزروهای اعتبار (اگر ترکیبی باشد)
            if payment.credit_amount:
                CreditService.consume_for_payment(payment)
            # فاکتور + ledger idempotent
            InvoiceSettlementService.settle(
                inspection_request, payment=payment,
                is_paid=True, paid_at=payment.verified_at,
                user=user)
            if inspection_request.status in ('pending_payment', 'paid'):
                inspection_request.status = 'scheduled'
                inspection_request.save(update_fields=['status'])

    try:
        send_notification(
            user,
            'payment_verified_request' if not is_deposit
            else 'payment_verified',
            {
                'request_id': inspection_request.id,
                'payment_id': payment.id,
                'amount': str(payment.amount),
                'message': 'پرداخت شما تأیید شد.'
            })
    except Exception as notif_error:
        logger.error(f"Error sending payment verified notification: "
                     f"{notif_error}")
    return payment
# core/signals.py
# -*- coding: utf-8 -*-

from django.db.models.signals import post_save, post_delete, post_migrate, post_init
from django.dispatch import receiver
from django.utils import timezone
from decimal import Decimal
import logging
from django.contrib.auth.models import Group, Permission
from django.contrib.contenttypes.models import ContentType
from django.db import IntegrityError, transaction
from django.core.files.base import ContentFile
from django.contrib.auth import get_user_model

from .models import (
    Payment, InspectionRequest, InspectionReport, DiscountCode,
    EquipmentParameter, EquipmentType
)
from .events import Event, EventRegistry
from notifications.services import send_notification, queue_notification

User = get_user_model()
logger = logging.getLogger(__name__)


# ============================================================
# سیگنال‌های جدید برای به‌روزرسانی خودکار param_schema
# ============================================================

@receiver(post_save, sender=EquipmentParameter)
def update_param_schema_on_save(sender, instance, created, **kwargs):
    """
    پس از ذخیره‌سازی یک پارامتر، param_schema نوع تجهیزات مرتبط را به‌روز می‌کند.
    """
    equipment = instance.equipment_type
    # EDRA v36: فقط پارامترهای «فعال» وارد schema ویزارد می‌شوند؛ قبلاً پارامتر
    # غیرفعال هم به مشتری نشان داده (و حتی «اجباری») می‌شد در حالی که قیمت‌گذاری
    # و اعتبارسنجی سرور آن را نادیده می‌گیرد.
    active_params = equipment.parameters.filter(is_active=True)
    if active_params.exists():
        schema = [p.to_json_schema()
                  for p in active_params.order_by('order')]
        equipment.param_schema = schema
    else:
        equipment.param_schema = None
    equipment.save(update_fields=['param_schema'])


@receiver(post_delete, sender=EquipmentParameter)
def update_param_schema_on_delete(sender, instance, **kwargs):
    """
    پس از حذف یک پارامتر، param_schema نوع تجهیزات مرتبط را به‌روز می‌کند.
    """
    equipment = instance.equipment_type
    # EDRA v36: فقط پارامترهای «فعال» وارد schema ویزارد می‌شوند؛ قبلاً پارامتر
    # غیرفعال هم به مشتری نشان داده (و حتی «اجباری») می‌شد در حالی که قیمت‌گذاری
    # و اعتبارسنجی سرور آن را نادیده می‌گیرد.
    active_params = equipment.parameters.filter(is_active=True)
    if active_params.exists():
        schema = [p.to_json_schema()
                  for p in active_params.order_by('order')]
        equipment.param_schema = schema
    else:
        equipment.param_schema = None
    equipment.save(update_fields=['param_schema'])


# ============================================================
# سیگنال‌های قبلی (با ارسال رویدادها)
# ============================================================

@receiver(post_migrate)
def create_default_groups_and_permissions(sender, **kwargs):
    if sender.name != 'core':
        return

    admin_group, _ = Group.objects.get_or_create(name='Admin')
    expert_group, _ = Group.objects.get_or_create(name='Expert')

    inspection_request_ct = ContentType.objects.get_for_model(InspectionRequest)
    inspection_report_ct = ContentType.objects.get_for_model(InspectionReport)

    def get_or_create_permission(codename, name, content_type):
        try:
            perm, created = Permission.objects.get_or_create(
                codename=codename,
                defaults={'name': name},
                content_type=content_type,
            )
            return perm
        except IntegrityError:
            return Permission.objects.get(
                codename=codename,
                content_type=content_type,
            )

    view_request_perm = get_or_create_permission(
        'view_inspectionrequest',
        'Can view inspection request',
        inspection_request_ct
    )
    change_request_perm = get_or_create_permission(
        'change_inspectionrequest',
        'Can change inspection request',
        inspection_request_ct
    )
    delete_request_perm = get_or_create_permission(
        'delete_inspectionrequest',
        'Can delete inspection request',
        inspection_request_ct
    )

    view_report_perm = get_or_create_permission(
        'view_inspectionreport',
        'Can view inspection report',
        inspection_report_ct
    )
    change_report_perm = get_or_create_permission(
        'change_inspectionreport',
        'Can change inspection report',
        inspection_report_ct
    )
    delete_report_perm = get_or_create_permission(
        'delete_inspectionreport',
        'Can delete inspection report',
        inspection_report_ct
    )

    admin_group.permissions.add(
        view_request_perm, change_request_perm, delete_request_perm,
        view_report_perm, change_report_perm, delete_report_perm
    )
    expert_group.permissions.add(
        view_report_perm, change_report_perm
    )
    expert_group.permissions.add(view_request_perm)

    logger.info("Default groups and permissions created successfully.")


@receiver(post_save, sender=Payment)
def create_invoice_on_payment_success(sender, instance, created, **kwargs):
    """
    پس از پرداخت‌شدن (paid)، فاکتور فقط از طریق سرویس مرکزی
    InvoiceSettlementService.settle ساخته می‌شود (idempotent — FIN-01/FIN-02).
    """
    if instance.status != 'paid':
        return

    from .services.invoice_service import InvoiceSettlementService

    try:
        inspection_request = instance.inspection_request
        # EDRA v35: «درخواست» واریز اعتبار یک خدمت فروخته‌شده نیست؛ برایش
        # فاکتور (با مالیات!)، شماره‌ی فاکتور، ثبت درآمد در دفتر کل و اعلان
        # «فاکتور آماده است» صادر نمی‌شد درست. افزایش اعتبار بدهی است نه درآمد.
        _p = inspection_request.params
        if isinstance(_p, dict) and _p.get('is_deposit'):
            return
        invoice, created_invoice = InvoiceSettlementService.settle(
            inspection_request,
            payment=instance,
            is_paid=True,
            paid_at=instance.verified_at or timezone.now(),
            user=inspection_request.customer,
        )

        # EDRA v33: اعلان «پرداخت موفق» دیگر اینجا ارسال نمی‌شود. همه‌ی مسیرهای
        # پرداخت (callback درگاه، پرداخت اعتباری، تایید ادمین) خودشان اعلان
        # مخصوص و غنی‌تری می‌فرستند؛ ارسال از این سیگنال باعث دو پیامک یکسان
        # (و ارسال پیامک داخل تراکنش مالی قبل از commit) می‌شد.

        # ارسال رویداد پرداخت موفق
        EventRegistry.dispatch(Event('payment_successful', {
            'instance': instance,
            'invoice': invoice,
            'created_invoice': created_invoice
        }))

    except Exception as e:
        logger.error(
            f"Critical error in invoice creation for payment {instance.id}: {e}",
            exc_info=True)
        try:
            import sentry_sdk
            sentry_sdk.capture_exception(e)
        except Exception:
            pass
        # EDRA v27 — رفع باگ بحرانی (تایید ممیزی هوش مصنوعی، سپتامبر
        # ۲۰۲۶): این signal بعد از save موفق Payment اجرا می‌شود؛ raise
        # کردن اینجا کل تراکنش بیرونی (شامل خودِ Payment که واقعاً و
        # موفق ذخیره شده) را rollback می‌کرد — یعنی یک خطای بی‌ربط در
        # ساخت فاکتور (مثلاً قالب/PDF) می‌توانست پرداخت واقعی و کامل‌شده‌ی
        # مشتری را از دیتابیس پاک کند. حالا خطا فقط لاگ/Sentry می‌شود؛
        # فاکتور بعداً از طریق اکشن موجود «تلاش مجدد PDF» در ادمین قابل
        # ساخت است، ولی خودِ پرداخت هرگز از بین نمی‌رود.


@receiver(post_save, sender=DiscountCode)
def notify_new_discount_code(sender, instance, created, **kwargs):
    """
    اعلان کد تخفیف جدید به مشتریان — فقط برای کدهای «عمومی».

    EDRA v33 — SEC (نشت مالی): قبلاً هر DiscountCode تازه‌ساخته‌ای (از جمله کد
    یک‌بارمصرف اختصاصی که کمپین برای یک کاربر می‌سازد) به *همه‌ی* مشتریان
    اعلان می‌شد؛ یعنی کد شخصی هر کاربر برای همه فاش می‌شد. حالا فقط وقتی
    ادمین صراحتاً is_public را تیک زده باشد broadcast می‌شود. اعلان‌ها در صف
    (pending) ساخته می‌شوند و تسک دوره‌ای آن‌ها را دسته‌ای می‌فرستد.
    """
    if not (created and instance.is_active and instance.usage_limit != 0
            and getattr(instance, 'is_public', False)):
        return
    try:
        from edra_jalalidate import to_jalali
        expires = (to_jalali(instance.expires_at, fmt="%Y/%m/%d")
                   if instance.expires_at else 'نامحدود')
        context = {
            'code': instance.code,
            'discount_value': instance.value,
            'discount_type': instance.get_discount_type_display(),
            'expires_at': expires,
        }
        # بدنه‌ی قالب (code را دارد) + جزئیات؛ اگر ادمین قالب را سفارشی کرده بود
        # همان رندر می‌شود.
        queued = 0
        for user in User.objects.filter(
                is_staff=False, is_superuser=False, is_active=True
        ).iterator(chunk_size=500):
            if queue_notification(user, 'new_discount_code', context):
                queued += 1
        logger.info(f"Queued {queued} discount code notifications.")
    except Exception as e:
        logger.error(f"Failed to queue discount notifications: {e}")


# ============================================================
# EDRA v33 — اعلان تغییر وضعیت درخواست (نقطه‌ی واحد برای همه‌ی مسیرها)
# ============================================================
# قبلاً فقط تغییرات عبوری از state machine (و فقط paid/completed/cancelled)
# اعلان می‌ساختند؛ شروع بازرسی، ارجاع، زمان‌بندی و اتمام (که مستقیماً در
# view های کارشناس/ادمین/سرویس‌ها تغییر می‌کنند) هیچ اعلانی نداشتند.

@receiver(post_init, sender=InspectionRequest)
def _remember_request_status(sender, instance, **kwargs):
    instance._edra_orig_status = instance.__dict__.get('status')


_CUSTOMER_STATUSES = {'assigned', 'rescheduled', 'in_progress',
                      'completed', 'cancelled'}
_EXPERT_STATUSES = {'scheduled', 'rescheduled', 'cancelled'}
# وضعیت‌هایی که قبل از «scheduled» یعنی پرداخت تازه تایید شده (اعلان پرداخت
# جداگانه ارسال می‌شود؛ تکراری نشود)
_PAYMENT_FLOW_PREV = {'draft', 'pending_payment', 'waiting_manual_payment',
                      'paid'}


@receiver(post_save, sender=InspectionRequest)
def notify_request_status_change(sender, instance, created, update_fields=None,
                                 **kwargs):
    new = instance.status
    old = getattr(instance, '_edra_orig_status', None)
    instance._edra_orig_status = new
    if created or old is None or old == new:
        return
    if update_fields is not None and 'status' not in update_fields:
        return
    # EDRA v35: لغو/انقضای درخواست پرداخت‌نشده → آزادسازی ظرفیت کد تخفیف و
    # اعتبار رزروشده. قبلاً هیچ‌کدام آزاد نمی‌شد: کد تخفیف برای همیشه
    # «مصرف‌شده» می‌ماند (و per_user_limit مشتری را قفل می‌کرد) و اعتبار
    # رزروشده‌ی پرداخت رهاشده برای همیشه از موجودی قابل مصرف کم می‌ماند.
    if new in ('cancelled', 'expired') and old not in ('cancelled', 'expired'):
        try:
            from .services.discount_service import release_request_holds
            release_request_holds(instance)
        except Exception as hold_error:
            logger.error(
                f"release_request_holds failed (request {instance.pk}): "
                f"{hold_error}")
    params = instance.params if isinstance(instance.params, dict) else {}
    if params.get('is_deposit'):
        return  # «درخواست» واریز اعتبار، بازرسی واقعی نیست

    to_customer = new in _CUSTOMER_STATUSES or (
        new == 'scheduled' and old not in _PAYMENT_FLOW_PREV)
    to_expert = new in _EXPERT_STATUSES and bool(instance.assigned_expert_id)
    if not (to_customer or to_expert):
        return

    request_id = instance.pk
    customer_id = instance.customer_id
    expert_id = instance.assigned_expert_id
    context = {
        'request_id': request_id,
        'request_number': instance.request_number,
        'new_status': instance.get_status_display(),
        'old_status': old,
    }

    def _send():
        try:
            if to_customer and customer_id:
                send_notification(
                    User.objects.get(pk=customer_id), 'status_changed', context)
            if to_expert and expert_id:
                send_notification(
                    User.objects.get(pk=expert_id), 'expert_request_updated',
                    context)
        except Exception as e:
            logger.error(f"Status-change notification failed "
                         f"(request {request_id}): {e}")

    transaction.on_commit(_send)

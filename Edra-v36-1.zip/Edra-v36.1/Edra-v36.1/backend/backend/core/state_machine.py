# core/state_machine.py
# -*- coding: utf-8 -*-
"""
ماشین حالت متمرکز برای مدیریت وضعیت‌های درخواست‌ها و تیکت‌ها.
همه transitions در یک نقطه تعریف می‌شوند و اکشن‌های جانبی (لاگ، نوتیفیکیشن، وب‌هوک) به‌صورت خودکار اجرا می‌شوند.
"""

from typing import Dict, Set, Callable, Any, Optional, List
from enum import Enum
from dataclasses import dataclass, field
import logging

logger = logging.getLogger(__name__)


class StateMachineError(Exception):
    """خطای مرتبط با ماشین حالت."""


@dataclass
class Transition:
    """یک انتقال از وضعیت قدیم به جدید با شرط و اکشن‌های جانبی."""
    from_state: str
    to_state: str
    condition: Optional[Callable[[Any], bool]] = None
    before_action: Optional[Callable[[Any], None]] = None
    after_action: Optional[Callable[[Any], None]] = None
    description: str = ""


class StateMachine:
    """
    ماشین حالت عمومی که برای هر مدلی قابل استفاده است.
    """

    def __init__(self, model_class, transitions: List[Transition], initial_state: str):
        self.model_class = model_class
        self.transitions = transitions
        self.initial_state = initial_state
        self._transition_map: Dict[str, Dict[str, Transition]] = {}
        self._build_map()

    def _build_map(self):
        for t in self.transitions:
            if t.from_state not in self._transition_map:
                self._transition_map[t.from_state] = {}
            self._transition_map[t.from_state][t.to_state] = t

    def get_allowed_transitions(self, current_state: str) -> List[str]:
        """لیست وضعیت‌های مجاز برای انتقال از وضعیت فعلی."""
        return list(self._transition_map.get(current_state, {}).keys())

    def can_transition(self, obj, to_state: str) -> bool:
        """بررسی امکان انتقال."""
        current = obj.status if hasattr(obj, 'status') else obj.state
        if current not in self._transition_map:
            return False
        trans = self._transition_map[current].get(to_state)
        if not trans:
            return False
        if trans.condition and not trans.condition(obj):
            return False
        return True

    def transition(self, obj, to_state: str, actor=None, **kwargs) -> Any:
        """
        اجرای انتقال با رعایت شرط‌ها و اکشن‌ها.
        """
        current = obj.status if hasattr(obj, 'status') else obj.state
        if current not in self._transition_map:
            raise StateMachineError(f"وضعیت '{current}' اجازه انتقال ندارد.")
        trans = self._transition_map[current].get(to_state)
        if not trans:
            raise StateMachineError(f"انتقال از '{current}' به '{to_state}' مجاز نیست.")
        if trans.condition and not trans.condition(obj):
            raise StateMachineError(f"شرط انتقال از '{current}' به '{to_state}' برآورده نشده است.")

        # اجرای اکشن قبل
        if trans.before_action:
            trans.before_action(obj, actor=actor, **kwargs)

        # تغییر وضعیت
        setattr(obj, 'status' if hasattr(obj, 'status') else 'state', to_state)
        obj.save(update_fields=['status' if hasattr(obj, 'status') else 'state'])

        # اجرای اکشن بعد
        if trans.after_action:
            trans.after_action(obj, actor=actor, **kwargs)

        # ثبت لاگ
        logger.info(f"State transition: {obj} {current} -> {to_state} by {actor}")

        return obj


# ============================================================
# تعریف ماشین‌های حالت اختصاصی
# ============================================================

def get_inspection_request_state_machine():
    """
    ماشین حالت برای InspectionRequest.

    EDRA v34: جدول گذارها از یک منبع واحد
    (core.services.inspection_service.ALLOWED_STATUS_TRANSITIONS) ساخته می‌شود؛
    قبلاً این‌جا یک جدول جداگانه و ناقص بود (بدون rescheduled/لغو ارجاع‌شده
    و ...). اکشن «ارسال وب‌هوک» حذف شد: Webhook فقط رویدادهای تیکت دارد
    ('ticket_updated') و این کد وضعیت درخواست‌های بازرسی را به مشتری‌های
    وب‌هوک تیکت می‌فرستاد، آن هم همزمان داخل درخواست HTTP (timeout ۳ ثانیه
    برای هر وب‌هوک). تغییر وضعیت و AuditLog در apply_status_change انجام
    می‌شود و اعلان مشتری/کارشناس را سیگنال post_save می‌فرستد.
    """
    from core.models import InspectionRequest
    from core.services.inspection_service import ALLOWED_STATUS_TRANSITIONS

    transitions = [
        Transition(old, new, description=f'{old} → {new}')
        for old, targets in ALLOWED_STATUS_TRANSITIONS.items()
        for new in sorted(targets)
    ]
    return InspectionRequestStateMachine(
        InspectionRequest, transitions, 'draft')


class InspectionRequestStateMachine(StateMachine):
    """StateMachine با تغییر وضعیتِ قفل‌شده و ثبت AuditLog (apply_status_change)."""

    def transition(self, obj, to_state: str, actor=None, **kwargs) -> Any:
        from core.services.inspection_service import apply_status_change

        current = obj.status
        trans = self._transition_map.get(current, {}).get(to_state)
        if trans is None:
            if current not in self._transition_map or not self._transition_map[current]:
                raise StateMachineError(f"وضعیت '{current}' اجازه انتقال ندارد.")
            raise StateMachineError(
                f"انتقال از '{current}' به '{to_state}' مجاز نیست.")
        try:
            apply_status_change(
                obj, to_state, actor=actor, reason=kwargs.get('reason', ''))
        except ValueError as exc:  # race: وضعیت بین خواندن و قفل عوض شده
            raise StateMachineError(str(exc)) from exc
        logger.info(f"State transition: {obj} {current} -> {to_state} by {actor}")
        return obj


def get_ticket_state_machine():
    """ماشین حالت برای Ticket."""
    from support.models import Ticket, TicketStatus

    # شرط‌ها
    def _is_closed_status(obj):
        return obj.status and obj.status.is_closed

    # اکشن‌ها
    def _set_closed_at(obj, actor=None, **kwargs):
        from django.utils import timezone
        if obj.status and obj.status.is_closed:
            obj.closed_at = timezone.now()
            obj.resolved_at = timezone.now()
            obj.save(update_fields=['closed_at', 'resolved_at'])

    def _notify_assignee(obj, actor=None, **kwargs):
        from notifications.services import send_notification
        if obj.assigned_to:
            send_notification(obj.assigned_to, 'ticket_assigned', {
                'ticket_id': obj.id,
                'title': obj.title,
                'assigned_by': actor.get_full_name() if actor else 'سیستم'
            })

    transitions = [
        Transition('open', 'in_progress', description='باز → در حال بررسی'),
        Transition('in_progress', 'resolved', description='در حال بررسی → حل شده'),
        Transition('resolved', 'closed', condition=_is_closed_status, description='حل شده → بسته شده'),
        Transition('open', 'closed', condition=_is_closed_status, description='باز → بسته شده'),
        Transition('in_progress', 'closed', condition=_is_closed_status, description='در حال بررسی → بسته شده'),
    ]

    for t in transitions:
        t.after_action = _set_closed_at
        if t.to_state == 'closed':
            t.after_action = lambda obj, actor=None, **kw: (_set_closed_at(obj, actor, **kw), _notify_assignee(obj, actor, **kw))

    return StateMachine(Ticket, transitions, 'open')
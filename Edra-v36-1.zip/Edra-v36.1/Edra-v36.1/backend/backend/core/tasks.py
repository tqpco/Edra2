# core/tasks.py
from celery import shared_task
from django.core.files.base import ContentFile
from django.utils import timezone
import logging

from .models import InspectionReport, Invoice, DiscountCode, InspectionRequest, Payment
from notifications.models import NotificationLog
from .report_pdf_generator import generate_report_pdf
from .invoice_pdf_generator import generate_invoice_pdf
from notifications.services import (
    send_notification, queue_notification, get_admin_users)
from django.contrib.auth import get_user_model

User = get_user_model()
logger = logging.getLogger(__name__)


@shared_task(bind=True, max_retries=3, default_retry_delay=60)
def generate_report_pdf_task(self, report_id, user_id=None):
    """
    تولید PDF گزارش.

    EDRA v34:
      • retry خودکار (۳ بار، فاصله‌ی ۶۰ ثانیه) — قبلاً با اولین خطا (مثلاً
        تسک قبل از commit اجرا شود یا weasyprint موقتاً خطا بدهد) گزارش برای
        همیشه بدون PDF می‌ماند و امضا/دانلود مشتری غیرممکن بود.
      • خطای نهایی: اعلان به ادمین‌ها (نه فقط کارشناس) و بدون متن خام
        استثنا؛ متن خطا فقط در لاگ.
      • اعلان «گزارش آماده شد» فقط یک‌بار و فقط برای گزارش نهایی‌شده‌ی درخواست
        تکمیل‌شده (قبلاً با هر بازتولید تکرار می‌شد).
      • اگر گزارش قبلاً امضا شده باشد، PDF دوباره ساخته نمی‌شود (هش امضا با
        فایل منطبق بماند).
    """
    try:
        report = InspectionReport.objects.select_related(
            'inspection_request', 'inspection_request__customer',
            'inspection_request__equipment_type').get(id=report_id)
    except InspectionReport.DoesNotExist:
        logger.error(f'generate_report_pdf_task: report {report_id} missing')
        return False

    if report.signed_at is not None or report.signed_pdf_file:
        return True
    if report.overall_result == 'pending' or not report.results:
        # گزارش هنوز نهایی نشده (مثلاً شروع بازرسی در مسیر دوم)؛ PDF خالی نساز.
        return False

    try:
        inspection_request = report.inspection_request
        customer = inspection_request.customer
        equipment = inspection_request.equipment_type
        first_time = not bool(report.pdf_file)

        pdf_content = generate_report_pdf(
            report=report,
            inspection_request=inspection_request,
            customer=customer,
            equipment=equipment,
            checklist_items=report.results or []
        )

        filename = f"report_{report.report_number}.pdf"
        report.pdf_file.save(filename, ContentFile(pdf_content), save=False)
        report.save(update_fields=['pdf_file', 'updated_at'])
        logger.info(f"PDF generated for report {report.report_number}")
    except Exception as e:
        logger.error(
            f"Error generating report PDF for report {report_id}: {e}",
            exc_info=True)
        if self.request.retries < self.max_retries:
            raise self.retry(exc=e)
        _notify_report_pdf_failed(report_id, user_id)
        return False

    if first_time:
        try:
            send_notification(customer, 'report_pdf_ready', {
                'report_number': report.report_number,
                'report_id': report.id,
            })
        except Exception as notif_error:
            logger.error(f'report_pdf_ready notification failed: {notif_error}')
    return True


def _notify_report_pdf_failed(report_id, user_id):
    """اعلان شکست نهایی تولید PDF به کارشناس + همه‌ی ادمین‌ها (بدون متن خطا)."""
    recipients = {}
    try:
        if user_id:
            u = User.objects.filter(id=user_id).first()
            if u:
                recipients[u.pk] = u
        for admin in get_admin_users():
            recipients[admin.pk] = admin
    except Exception as e:
        logger.error(f'resolving recipients for report_pdf_failed: {e}')
    for user in recipients.values():
        try:
            send_notification(user, 'report_pdf_failed', {
                'report_id': report_id})
        except Exception as e:
            logger.error(f'report_pdf_failed notification error: {e}')


@shared_task
def generate_invoice_pdf_task(invoice_id, user_id):
    """
    تسک تولید PDF فاکتور
    """
    try:
        invoice = Invoice.objects.get(id=invoice_id)
        inspection_request = invoice.inspection_request
        customer = inspection_request.customer
        equipment = inspection_request.equipment_type

        pdf_content = generate_invoice_pdf(
            invoice=invoice,
            inspection_request=inspection_request,
            customer=customer,
            equipment=equipment
        )

        filename = f"invoice_{invoice.invoice_number}.pdf"
        invoice.pdf_file.save(filename, ContentFile(pdf_content), save=True)
        invoice.status = 'generated'
        invoice.last_error = ''
        invoice.save(update_fields=['pdf_file', 'status', 'last_error'])

        # ارسال اعلان موفقیت
        send_notification(customer, 'invoice_pdf_ready', {
            'invoice_number': invoice.invoice_number,
            'invoice_id': invoice.id
        })

        logger.info(f"PDF generated for invoice {invoice.invoice_number}")
        return True
    except Exception as e:
        logger.error(
            f"Error generating invoice PDF for invoice {invoice_id}: {e}")
        # بروزرسانی وضعیت فاکتور به failed
        try:
            invoice = Invoice.objects.get(id=invoice_id)
            invoice.status = 'failed'
            invoice.last_error = str(e)
            invoice.retry_count += 1
            invoice.save(update_fields=['status', 'last_error', 'retry_count'])
        except Exception:
            pass
        # ارسال اعلان خطا
        try:
            user = User.objects.get(id=user_id)
            # EDRA v36: متن خام استثنا (مسیر فایل/جزئیات داخلی) به مشتری
            # نرفته و فقط در last_error/لاگ می‌ماند.
            send_notification(user, 'invoice_pdf_failed', {
                'invoice_id': invoice_id,
            })
        except Exception:
            pass
        return False


# ===== تسک بررسی کدهای تخفیف در حال انقضا =====
@shared_task
def check_expiring_discount_codes():
    """
    هشدار انقضا (کمتر از ۳ روز) برای کدهای تخفیف «عمومی».

    EDRA v33:
      • فقط is_public — کد اختصاصی کمپین/ریفرال نباید به همه اعلام شود (نشت).
      • هر کاربر برای هر کد فقط یک‌بار (قبلاً هر روز، تا ۳ بار)، با چک
        NotificationLog.
      • اعلان‌ها در صف می‌روند و تسک دوره‌ای دسته‌ای می‌فرستد (قبلاً هزاران
        تماس HTTP همزمان به سرویس پیامک داخل همین تسک).
      • days_left با گرد به بالا (قبلاً «۰ روز» نمایش داده می‌شد).
    """
    import math
    from edra_jalalidate import to_jalali

    now = timezone.now()
    expiring_soon = now + timezone.timedelta(days=3)

    codes = DiscountCode.objects.filter(
        is_active=True, is_public=True,
        expires_at__gt=now, expires_at__lte=expiring_soon)
    if not codes.exists():
        logger.info("No expiring discount codes found.")
        return 0

    queued = 0
    for code in codes:
        already = set(NotificationLog.objects.filter(
            type='discount_code_expiring', content__contains=code.code
        ).values_list('user_id', flat=True))
        days_left = max(1, math.ceil(
            (code.expires_at - now).total_seconds() / 86400))
        context = {
            'code': code.code,
            'expires_at': to_jalali(code.expires_at, fmt="%Y/%m/%d"),
            'days_left': days_left,
            'discount_type': code.discount_type,
            'value': code.value,
        }
        customers = User.objects.filter(
            is_staff=False, is_superuser=False, is_active=True
        ).exclude(id__in=already)
        for user in customers.iterator(chunk_size=500):
            try:
                if queue_notification(user, 'discount_code_expiring', context):
                    queued += 1
            except Exception as e:
                logger.error(
                    f"Failed to queue expiring notification for user "
                    f"{user.id}: {e}")
    logger.info(f"Queued {queued} expiring-discount notifications.")
    return queued


# ===== تسک مدیریت چرخه‌ی درخواست‌های پرداخت‌نشده (۲۴/۴۸/۷۲ ساعت) =====
# EDRA v27 — قابلیت تازه (گزارش کاربر، سپتامبر ۲۰۲۶): «هر درخواستی که تا
# ۷۲ ساعت پرداخت نشد باید... ابتدا ۲۴ و ۴۸ ساعت پس از درخواست پیامک
# یادآوری برود، و بعد از ۷۲ ساعت درخواست به‌صورت اتوماتیک بسته شود».
# این تسک جایگزین close_expired_manual_payments شد چون آن تسک فقط
# پرداخت‌های دستی را پوشش می‌داد (نه هر درخواست پرداخت‌نشده‌ای) و
# یادآوری میانی هم نداشت.
UNPAID_STATUSES = ('draft', 'pending_payment', 'waiting_manual_payment')


@shared_task
def manage_unpaid_request_lifecycle():
    now = timezone.now()
    # این تسک هر ساعت اجرا می‌شود (پایین در celery.py) — بازه‌ی یک‌ساعته
    # برای هر آستانه تضمین می‌کند دقیقاً یک‌بار پیامک یادآوری ارسال شود،
    # + یک چک NotificationLog اضافه برای اطمینان در برابر اجرای دیرهنگام.
    reminded_24h = 0
    reminded_48h = 0
    closed_count = 0

    # EDRA v36: «درخواست»های موقتِ افزایش اعتبار (params.is_deposit) واقعی نیستند؛
    # قبلاً مشتری‌ای که یک افزایش اعتبار آنلاین را نیمه‌کاره رها می‌کرد، پیامک
    # «درخواست شما پرداخت نشده» و بعد «درخواست لغو شد» برای درخواستی می‌گرفت که
    # هرگز نمی‌دید. این‌ها بی‌صدا در پایین پاک‌سازی می‌شوند.
    stale_deposits = InspectionRequest.objects.filter(
        status='pending_payment', params__is_deposit=True,
        created_at__lt=now - timezone.timedelta(hours=72),
    ).exclude(payments__status__in=['pending_verification', 'paid'])
    for dep in stale_deposits.iterator(chunk_size=200):
        try:
            dep.status = 'cancelled'
            dep.save(update_fields=['status'])
        except Exception as e:
            logger.error(f"Error closing stale deposit request {dep.id}: {e}")

    candidates = InspectionRequest.objects.filter(
        status__in=UNPAID_STATUSES
    ).exclude(params__is_deposit=True).exclude(
        # EDRA v27: درخواست‌هایی که پرداخت اعتباری/دستی‌شان ثبت شده و
        # منتظر تایید ادمین است، نباید «پرداخت‌نشده» حساب شوند — مشتری
        # قبلاً اقدام کرده، فقط تایید نهایی باقی مانده.
        payments__status='pending_verification'
    ).select_related('customer')
    candidates_count = candidates.count()

    # EDRA v27 — رفع باگ عملکردی (تایید ممیزی هوش مصنوعی، سپتامبر ۲۰۲۶):
    # .iterator() تا کل نتیجه یک‌جا در حافظه لود نشود — این تسک هر ساعت
    # اجرا می‌شود و با رشد تعداد درخواست‌های رهاشده می‌تواند حجم قابل‌توجهی
    # بگیرد.
    for req in candidates.iterator(chunk_size=200):
        if not req.customer or not req.created_at:
            continue
        age = now - req.created_at

        if timezone.timedelta(hours=24) <= age < timezone.timedelta(hours=25):
            already = NotificationLog.objects.filter(
                user=req.customer,
                template__code='request_payment_reminder_24h',
                created_at__gte=req.created_at,
            ).exists()
            if not already:
                try:
                    send_notification(
                        req.customer, 'request_payment_reminder_24h', {
                            'request_id': req.id,
                            'request_number': req.request_number,
                        })
                    reminded_24h += 1
                except Exception as e:
                    logger.error(f"Error sending 24h reminder for request {req.id}: {e}")

        elif timezone.timedelta(hours=48) <= age < timezone.timedelta(hours=49):
            already = NotificationLog.objects.filter(
                user=req.customer,
                template__code='request_payment_reminder_48h',
                created_at__gte=req.created_at,
            ).exists()
            if not already:
                try:
                    send_notification(
                        req.customer, 'request_payment_reminder_48h', {
                            'request_id': req.id,
                            'request_number': req.request_number,
                        })
                    reminded_48h += 1
                except Exception as e:
                    logger.error(f"Error sending 48h reminder for request {req.id}: {e}")

        elif age >= timezone.timedelta(hours=72):
            try:
                # رد کردن پرداخت دستی معلق (در صورت وجود) + آزادسازی اعتبار رزروشده
                stale_payment = Payment.objects.filter(
                    inspection_request=req,
                    status='pending_verification',
                ).first()
                if stale_payment:
                    stale_payment.status = 'rejected'
                    stale_payment.save(update_fields=['status'])
                    try:
                        from .services.credit_service import CreditService
                        CreditService.release_for_payment(stale_payment)
                    except Exception as release_error:
                        logger.error(
                            f"Error releasing credit for request {req.id}: {release_error}")

                req.status = 'expired'
                req.save(update_fields=['status'])
                closed_count += 1

                send_notification(
                    req.customer, 'request_auto_cancelled_72h', {
                        'request_id': req.id,
                        'request_number': req.request_number,
                    })
            except Exception as e:
                logger.error(f"Error auto-closing request {req.id}: {e}")

    logger.info(
        f"manage_unpaid_request_lifecycle: {reminded_24h} یادآوری ۲۴ساعته، "
        f"{reminded_48h} یادآوری ۴۸ساعته، {closed_count} درخواست بسته شد "
        f"(از {candidates_count} کاندید).")
    return {
        'reminded_24h': reminded_24h,
        'reminded_48h': reminded_48h,
        'closed': closed_count,
    }



# ============================================================
# EDRA v32 — اعلان «درخواست جدید» به‌صورت async
# ============================================================
# قبلاً perform_create داخل خودِ درخواست HTTP به مشتری و «تک‌تک ادمین‌ها»
# پیامک/ایمیل می‌فرستاد (هر کدام یک تماس HTTP به سرویس پیامک با timeout ۱۰s).
# زیر بار همزمان، هر ثبت درخواست = (۱ + تعداد ادمین‌ها) تماس بلاک‌کننده روی
# یکی از thread های محدود gunicorn. حالا فقط یک پیام به Celery می‌رود.

def notify_request_created(request_id, user_id):
    """ارسال اعلان ثبت درخواست به مشتری و ادمین‌های فعال (sync؛ در worker اجرا می‌شود)."""
    try:
        instance = InspectionRequest.objects.get(pk=request_id)
        user = User.objects.get(pk=user_id)
    except (InspectionRequest.DoesNotExist, User.DoesNotExist):
        logger.warning(f"notify_request_created: request/user not found ({request_id}, {user_id})")
        return 0

    sent = 0
    try:
        send_notification(user, 'request_created', {
            'request_id': instance.id,
            'status': instance.status,
        })
        sent += 1
    except Exception as e:
        logger.error(f"notify_request_created (customer) failed: {e}")

    for admin in get_admin_users():
        try:
            send_notification(admin, 'new_request_admin', {
                'request_id': instance.id,
                'customer': user.username,
            })
            sent += 1
        except Exception as e:
            logger.error(f"notify_request_created (admin {admin.id}) failed: {e}")
    return sent


@shared_task(ignore_result=True)
def notify_request_created_task(request_id, user_id):
    return notify_request_created(request_id, user_id)

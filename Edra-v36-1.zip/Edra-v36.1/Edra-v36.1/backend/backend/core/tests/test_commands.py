# core/tests/test_commands.py
"""تست مدیریت command های جدید (retry_failed_notifications، seed_demo_data)."""
import os

import pytest
from django.contrib.auth import get_user_model
from django.core.management import call_command

from core.models import CityMultiplier, EquipmentType
from edra_jalalidate import to_jalali
from notifications.models import NotificationLog, NotificationTemplate
from pricing.models import ParameterPrice, PricingRule

User = get_user_model()
pytestmark = pytest.mark.django_db
PASSWORD = os.getenv("PASSWORD", "CHANGE_ME")


def test_seed_demo_data_idempotent():
    call_command('seed_demo_data', '--with-users')
    call_command('seed_demo_data', '--with-users')

    assert EquipmentType.objects.count() == 5
    assert CityMultiplier.objects.filter(city='تهران').count() == 1
    assert EquipmentType.objects.get(code='tower_crane')
    rule = PricingRule.objects.get(equipment_type__code='tower_crane')
    assert ParameterPrice.objects.filter(pricing_rule=rule).count() == 2
    assert NotificationTemplate.objects.filter(
        code='request_created').exists()
    assert User.objects.filter(username='demo_admin').exists()


def test_retry_failed_notifications():
    user = User.objects.create_user(username="09120000123", password=PASSWORD)
    template = NotificationTemplate.objects.create(
        code='retry_test', channel='sms', subject='تست',
        body_template='پیام {user.username}', is_active=True)
    NotificationLog.objects.create(
        user=user, template=template, type='retry_test', subject='تست',
        content='قدیمی', channel='sms', status='failed',
        error_message='SMS provider error: test')

    call_command('retry_failed_notifications', '--limit', '10')
    sent = NotificationLog.objects.filter(type='retry_test', status='sent')
    assert sent.exists()
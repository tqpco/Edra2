# core/tests/test_concurrency.py
"""
تست همزمانی (P0 — گزارش V3 بند ۶/۱۲):

- Invoice race: N تسویه همزمان روی یک درخواست → دقیقاً ۱ فاکتور و ۱ شماره.
- Credit race: موجودی ۱۰,۰۰۰,۰۰۰ و دو رزرو همزمان ۸,۰۰۰,۰۰۰
  → یکی موفق، یکی رد؛ موجودی هرگز منفی نمی‌شود.

نکته صادقانه: در SQLite نوشتن همزمان می‌تواند «database is locked» بدهد؛
برای پایداری تست، retry محدود روی OperationalError انجام می‌شود.
روی PostgreSQL این retry فعال نمی‌شود (با select_for_update واقعی).
EDRA v9: تست‌های race واقعی فقط روی PostgreSQL اجرا می‌شوند — SQLite
select_for_update ندارد و تست ۲۰ thread ای حتی با retry هم در اجرای
full suite روی SQLite «database table is locked» می‌گیرد (محدودیت
ذاتی SQLite، نه باگ کد). در CI همین تست روی سرویس PostgreSQL واقعی
اجرا می‌شود. در محیط توسعه SQLite به‌جای fail، skip می‌شود.
"""
import os
import threading
from decimal import Decimal

import pytest
from django.conf import settings
from django.contrib.auth import get_user_model
from django.db import OperationalError, connections

from core.models import (
    CreditReservation, EquipmentType, InspectionRequest, Invoice, UserCredit,
)
from core.services.credit_service import InsufficientCreditError
from core.services.invoice_service import InvoiceSettlementService
from edra_jalalidate import to_jalali

User = get_user_model()
pytestmark = pytest.mark.django_db(transaction=True)
PASSWORD = os.getenv("PASSWORD", "CHANGE_ME")

MAX_RETRY = 8

# EDRA v9: تست race فقط روی PostgreSQL معنا دارد (select_for_update).
if 'sqlite' in str(settings.DATABASES.get('default', {}).get('ENGINE', '')):
    pytestmark = [
        pytest.mark.skip(
            reason='تست همزمانی فقط روی PostgreSQL معنا دارد — SQLite '
            'select_for_update ندارد و با lock محدود است (در CI روی '
            'PostgreSQL واقعی اجرا می‌شود).'),
        pytest.mark.django_db(transaction=True),
    ]


def _run_with_retry(fn, *args):
    """اجرای تابع در thread با retry محدود روی SQLite lock."""
    last = None
    for _ in range(MAX_RETRY):
        try:
            return fn(*args)
        except OperationalError as e:
            last = e
            import time
            time.sleep(0.2)
    raise last


def _invoice_worker(request_id, results, idx):
    try:
        req = InspectionRequest.objects.get(pk=request_id)

        def do():
            invoice, created = InvoiceSettlementService.settle(
                req, is_paid=False)
            return (invoice.id, created)
        results[idx] = _run_with_retry(do)
    except Exception as e:  # noqa: BLE001
        results[idx] = ('ERROR', str(e))
    finally:
        connections.close_all()


class TestInvoiceRace:
    def test_20_parallel_settles_one_invoice(self):
        user = User.objects.create_user(
            username="09120002001", password=PASSWORD)
        eq = EquipmentType.objects.create(
            code='race_eq', name_fa='تجهیز race')
        request = InspectionRequest.objects.create(
            customer=user, equipment_type=eq, city='تهران', address='تست',
            brand_model='م', calculated_price=1000000, final_price=1000000,
            status='pending_payment')

        # در تست همزمانی PDF ساخته نمی‌شود (فقط رقابت روی فاکتور)
        settings.PDF_GENERATION_ASYNC = True
        try:
            N = 20
            results = [None] * N
            threads = [
                threading.Thread(target=_invoice_worker,
                                 args=(request.id, results, i))
                for i in range(N)]
            for t in threads:
                t.start()
            for t in threads:
                t.join()
        finally:
            settings.PDF_GENERATION_ASYNC = False

        # هیچ خطای غیرمنتظره‌ای
        for r in results:
            assert r is not None and r[0] != 'ERROR', f"worker error: {r}"

        # دقیقاً یک فاکتور و یک شماره
        invoices = list(Invoice.objects.filter(
            inspection_request=request))
        assert len(invoices) == 1
        numbers = {r[0] for r in results if r[0] != 'ERROR'}
        assert numbers == {invoices[0].id}

        # شماره فاکتورهای سراسری هم یکتا هستند (تعداد = فاکتورهای موجود)
        assert Invoice.objects.count() == 1


def _credit_worker(user_id, request_id, results, idx):
    from core.services.credit_service import CreditService
    try:
        user = User.objects.get(pk=user_id)
        req = InspectionRequest.objects.get(pk=request_id)

        def do():
            reservation = CreditService.reserve(
                user, Decimal('8000000'), inspection_request=req)
            return ('OK', reservation.id)
        results[idx] = _run_with_retry(do)
    except InsufficientCreditError:
        results[idx] = ('REJECTED', None)
    except Exception as e:  # noqa: BLE001
        results[idx] = ('ERROR', str(e))
    finally:
        connections.close_all()


class TestCreditRace:
    def test_two_parallel_reserves_one_wins(self):
        user = User.objects.create_user(
            username="09120002002", password=PASSWORD)
        UserCredit.objects.create(user=user, balance=10000000)
        eq = EquipmentType.objects.create(
            code='race_eq2', name_fa='تجهیز race2')
        req_a = InspectionRequest.objects.create(
            customer=user, equipment_type=eq, city='تهران', address='a',
            brand_model='م', calculated_price=8000000, final_price=8000000,
            status='pending_payment')
        req_b = InspectionRequest.objects.create(
            customer=user, equipment_type=eq, city='تهران', address='b',
            brand_model='م', calculated_price=8000000, final_price=8000000,
            status='pending_payment')

        from core.services.credit_service import CreditService

        results = [None, None]
        threads = [
            threading.Thread(target=_credit_worker,
                             args=(user.id, req_a.id, results, 0)),
            threading.Thread(target=_credit_worker,
                             args=(user.id, req_b.id, results, 1)),
        ]
        for t in threads:
            t.start()
        for t in threads:
            t.join()

        statuses = sorted(r[0] for r in results)
        assert 'OK' in statuses, f"هیچ رزروی موفق نشد: {results}"
        assert 'REJECTED' in statuses, f"دومی رد نشد: {results}"

        # موجودی هرگز منفی نمی‌شود (رزرو کسر نمی‌کند؛ موجودی قابل‌مصرف ۲M)
        credit = UserCredit.objects.get(user=user)
        assert credit.balance == 10000000
        active = CreditReservation.objects.filter(status='reserved')
        assert active.count() == 1
        reserved_total = active.aggregate(
            total=__import__(
                'django.db.models', fromlist=['Sum']).Sum('amount'))['total']
        assert reserved_total == Decimal('8000000')
        assert credit.balance - reserved_total >= 0
# core/tests/test_e2e_acceptance.py
"""
TEST-01 — تست End-to-End سناریوی کامل پذیرش (گزارش ممیزی، بخش ۲۱):

Login → OTP → Equipment → Parameters → City → Price → Discount → Credit
→ Final Toman → Invoice → Rial Payment → Gateway → Callback → Verify → Paid
→ Accounting IRR → Expert Assignment → Jalali Scheduling → Checklist
→ Evidence → Technical Review → PDF → Signature/Integrity → Public
Verification → Notification → Financial Report

درگاه زرین‌پال با monkeypatch شبیه‌سازی می‌شود (Sandbox واقعی در Staging).
"""
import os
from decimal import Decimal

import pytest
from django.contrib.auth import get_user_model
from django.contrib.auth.models import Group
from rest_framework.test import APIClient

from core.models import (
    CityMultiplier, CreditTransaction, EquipmentParameter, EquipmentType,
    InspectionRequest, Invoice, Payment, ReportVerification, UserCredit,
)
from core.services.money import toman_to_rial
from edra_jalalidate import to_jalali
from notifications.models import NotificationLog, NotificationTemplate
from pricing.models import ParameterPrice, PricingRule

User = get_user_model()

def _cat(name):
    """ChecklistItem.category یک FK است؛ رشته‌ی نام را به رکورد تبدیل می‌کند."""
    from core.models import ChecklistCategory
    return ChecklistCategory.objects.get_or_create(name=name)[0]


pytestmark = pytest.mark.django_db

PASSWORD = os.getenv("PASSWORD", "CHANGE_ME")

# شبیه‌سازی درگاه
def _fake_create_payment(amount, description, callback_url, metadata=None):
    return {
        'success': True,
        'authority': 'E2E-AUTH-0001',
        'payment_url': 'https://sandbox.zarinpal.com/pg/StartPay/E2E-AUTH-0001',
    }


def _fake_verify_payment(authority, amount):
    return {'success': True, 'ref_id': 'E2E-REF-0001'}


class TestEndToEndAcceptance:
    def setup_method(self):
        self.customer_phone = '09120000111'
        self.client = APIClient()

        # ---- داده پایه قیمت‌گذاری ----
        self.eq = EquipmentType.objects.create(
            code='e2e_crane', name_fa='جرثقیل E2E',
            param_schema=[{'key': 'tonnage', 'label_fa': 'تناژ', 'unit': 'تن'}])
        self.param = EquipmentParameter.objects.create(
            equipment_type=self.eq, name='tonnage', label='تناژ',
            field_type='number')
        self.rule = PricingRule.objects.create(
            equipment_type=self.eq, base_price=1000000,
            standard_multiplier=Decimal('1.0'),
            pro_multiplier=Decimal('1.2'))
        ParameterPrice.objects.create(
            pricing_rule=self.rule, parameter=self.param,
            rate_type='per_unit', rate=100000)
        CityMultiplier.objects.create(
            city='تهران', multiplier=Decimal('1.0'), base_cost=200000)

        # ---- نقش‌ها ----
        self.admin_group, _ = Group.objects.get_or_create(name='Admin')
        self.expert_group, _ = Group.objects.get_or_create(name='Expert')
        self.admin = User.objects.create_user(
            username='e2e_admin', password=PASSWORD,
            is_staff=True)
        self.admin.groups.add(self.admin_group)
        self.expert = User.objects.create_user(
            username='e2e_expert', password=PASSWORD)
        self.expert.groups.add(self.expert_group)

        # ---- قالب‌های نوتیفیکیشن ----
        self._seed_templates()
        self._init_clients()

    @staticmethod
    def _seed_templates():
        templates = {
            'payment_successful': 'پرداخت موفق',
            'invoice_pdf_ready': 'فاکتور صادر شد',
            'request_created': 'درخواست ثبت شد',
            'payment_refunded': 'عودت پرداخت',
            'payment_verified_request': 'تأیید پرداخت',
            'invoice_pdf_failed': 'خطا در فاکتور',
        }
        for code, subject in templates.items():
            NotificationTemplate.objects.get_or_create(
                code=code, defaults={
                    'channel': 'sms', 'subject': subject,
                    'body_template': 'متن پیامک {request_id} {amount} {invoice_number}'})

    def _init_clients(self):
        self.admin_client = APIClient()
        self.admin_client.force_authenticate(user=self.admin)
        self.expert_client = APIClient()
        self.expert_client.force_authenticate(user=self.expert)

    def _otp_login(self, monkeypatch):
        from django.conf import settings
        monkeypatch.setattr(settings, 'DEV_OTP_ENABLED', True)
        monkeypatch.setattr(settings, 'DEV_OTP_ALLOWED_PHONES',
                            [self.customer_phone])
        monkeypatch.setattr(settings, 'DEV_OTP_CODE', '246810')

        r = self.client.post('/api/core/otp/request/',
                             {'phone': self.customer_phone})
        assert r.status_code == 200, r.content
        r = self.client.post('/api/core/otp/verify/',
                             {'phone': self.customer_phone, 'code': '246810'})
        assert r.status_code == 200, r.content
        token = r.data['access']
        self.client.credentials(
            HTTP_AUTHORIZATION=f'Bearer {token}')
        return r.data['user']

    def test_full_acceptance_scenario(self, monkeypatch):
        # ==========================================================
        # ۱) ورود با OTP
        # ==========================================================
        customer = self._otp_login(monkeypatch)
        assert customer['username'] == self.customer_phone

        # ==========================================================
        # ۲) ساخت درخواست بازرسی
        # ==========================================================
        r = self.client.post('/api/core/inspection-requests/', {
            'equipment_type': self.eq.id,
            'params': {'tonnage': 10},
            'city': 'تهران',
            'address': 'خ. صنعت، پلاک ۱',
            'brand_model': 'LIEBHERR 100',
            'manufacture_year': 1400,
            'service_type': 'standard',
        }, format='json')
        assert r.status_code == 201, r.content
        request_data = r.data
        request_id = request_data['id']
        assert int(request_data['final_price']) == 2200000
        assert request_data['status'] == 'pending_payment'

        # ==========================================================
        # ۳) کد تخفیف
        # ==========================================================
        r = self.admin_client.post('/api/core/discount-codes/', {
            'code': 'E2E10', 'discount_type': 'percent', 'value': 10,
            'apply_to_all': True, 'is_active': True,
            'usage_limit': 100, 'per_user_limit': 5,
        }, format='json')
        assert r.status_code in (200, 201), r.content

        from core.models import DiscountCode as DC
        preview_before = DC.objects.get(code='E2E10').used_count
        r = self.client.post('/api/core/discount-codes/apply/', {
            'code': 'E2E10', 'request_id': request_id,
        }, format='json')
        assert r.status_code == 200, r.content
        assert int(r.data['discount_amount']) == 220000
        assert int(r.data['final_price']) == 1980000
        assert DC.objects.get(code='E2E10').used_count == preview_before

        # اعمال واقعی
        r = self.client.post(
            f'/api/core/inspection-requests/{request_id}/apply-discount/',
            {'code': 'E2E10'}, format='json')
        assert r.status_code == 200, r.content
        assert int(r.data['discount_amount']) == 220000
        assert int(r.data['final_price']) == 1980000

        # اعمال تکراری → idempotent
        r = self.client.post(
            f'/api/core/inspection-requests/{request_id}/apply-discount/',
            {'code': 'E2E10'}, format='json')
        assert r.status_code == 200
        assert int(r.data['final_price']) == 1980000
        assert DC.objects.get(code='E2E10').used_count == 1

        # ==========================================================
        # ۴) اعتبار + پرداخت ترکیبی
        # ==========================================================
        UserCredit.objects.create(user=User.objects.get(
            username=self.customer_phone), balance=1000000)

        from core.views.payment_views import ZarinpalService
        monkeypatch.setattr(ZarinpalService, 'create_payment',
                            _fake_create_payment)
        monkeypatch.setattr(ZarinpalService, 'verify_payment',
                            _fake_verify_payment)

        r = self.client.post('/api/core/payment/initiate/', {
            'request_id': request_id, 'credit_amount': 1000000,
        }, format='json')
        assert r.status_code == 200, r.content
        assert 'payment_url' in r.data
        assert Decimal(r.data['online_amount']) == Decimal('1158200')
        assert 'E2E-AUTH-0001' in r.data['authority']

        # ==========================================================
        # ۵) Gateway → Callback → Verify → Paid
        # ==========================================================
        r = self.client.get(
            '/api/core/payment/callback/?Authority=E2E-AUTH-0001&Status=OK')
        assert r.status_code == 302
        assert 'payment/success' in r.url

        payment = Payment.objects.get(authority='E2E-AUTH-0001')
        assert payment.status == 'paid'
        assert payment.ref_id == 'E2E-REF-0001'
        assert int(payment.amount) == 2158200
        assert int(payment.amount_rial) == 21582000
        assert int(payment.online_amount) == 1158200
        assert int(payment.credit_amount) == 1000000

        credit = UserCredit.objects.get(user=payment.inspection_request.customer)
        assert int(credit.balance) == 0
        assert CreditTransaction.objects.filter(
            transaction_type='purchase').exists()

        inspection_request = InspectionRequest.objects.get(id=request_id)
        assert inspection_request.status == 'paid'

        # ==========================================================
        # ۶) فاکتور خودکار
        # ==========================================================
        invoice = Invoice.objects.get(inspection_request=inspection_request)
        assert invoice.invoice_number.startswith('INV-')
        assert invoice.is_paid is True
        assert int(invoice.base_amount) == 2200000
        assert int(invoice.discount_amount) == 220000
        assert int(invoice.total_amount) == 1980000
        assert int(invoice.tax_amount) == 178200
        assert int(invoice.final_amount) == 2158200
        assert int(invoice.final_rial) == 21582000

        # کال‌بک تکراری → بدون فاکتور دوم
        self.client.get(
            '/api/core/payment/callback/?Authority=E2E-AUTH-0001&Status=OK')
        assert Invoice.objects.filter(
            inspection_request=inspection_request).count() == 1

        # ==========================================================
        # ۷) Accounting IRR
        # ==========================================================
        r = self.admin_client.get('/api/core/admin/reports/financial/')
        assert r.status_code == 200
        assert int(r.data['summary']['total_revenue_rial']) == 21582000
        assert int(r.data['summary']['total_invoiced_rial']) == 21582000
        assert int(r.data['summary']['total_paid_count']) == 1
        assert payment.inspection_request_id == invoice.inspection_request_id

        # ==========================================================
        # ۸) Notification
        # ==========================================================
        customer_user = User.objects.get(username=self.customer_phone)
        notif = NotificationLog.objects.filter(user=customer_user)
        assert notif.exists(), "هیچ نوتیفیکیشنی برای مشتری ثبت نشده"

        # ==========================================================
        # ۹) Expert Assignment + Scheduling
        # ==========================================================
        r = self.admin_client.post(
            f'/api/core/inspection-requests/{request_id}/assign_expert/',
            {'expert_id': self.expert.id}, format='json')
        assert r.status_code == 200, r.content
        inspection_request.refresh_from_db()
        assert inspection_request.status == 'assigned'

        r = self.admin_client.post(
            f'/api/core/inspection-requests/{request_id}/change_status/',
            {'status': 'scheduled'}, format='json')
        assert r.status_code == 200, r.content
        inspection_request.scheduled_at = __import__(
            'django.utils', fromlist=['timezone']).timezone.now()
        inspection_request.save(update_fields=['scheduled_at'])

        r = self.expert_client.get('/api/core/inspection-requests/')
        assert r.status_code == 200
        ids = [item['id'] for item in r.data]
        assert request_id in ids

        # ==========================================================
        # ۱۰) Checklist → Evidence → Technical Review → PDF
        # ==========================================================
        from core.models import ChecklistItem, ChecklistTemplate
        template = ChecklistTemplate.objects.create(
            name='چک‌لیست E2E', equipment_type=self.eq,
            is_active=True)
        item = ChecklistItem.objects.create(
            checklist_template=template, category=_cat('هیدرولیک'),
            title='بررسی سیستم هیدرولیک', order=1, is_active=True)

        r = self.expert_client.get(
            f'/api/inspections/checklist-templates/{template.id}/items/')
        assert r.status_code == 200, r.content
        assert len(r.data) == 1

        r = self.expert_client.post('/api/inspections/inspection-reports/', {
            'inspection_request': request_id,
            'overall_result': 'pass',
        }, format='json')
        assert r.status_code == 201, r.content
        report_id = r.data['id']

        verification = ReportVerification.objects.get(report_id=report_id)

        r = self.expert_client.post(
            f'/api/inspections/inspection-reports/{report_id}/submit_results/',
            {'results': [{'item_id': item.id, 'result': 'pass',
                          'note': 'سالم'}],
             'overall_result': 'pass',
             'inspector_notes': 'بازرسی کامل انجام شد'}, format='json')
        assert r.status_code == 200, r.content
        inspection_request.refresh_from_db()
        assert inspection_request.status == 'completed'

        from core.models import InspectionReport
        from inspections.utils import generate_pdf_report
        report = InspectionReport.objects.get(id=report_id)
        generate_pdf_report(report)
        report.refresh_from_db()
        assert report.pdf_file
        assert report.pdf_file.read()[:5] == b'%PDF-'

        # ==========================================================
        # ۱۱) Signature/Integrity + Public Verification
        # ==========================================================
        r = self.expert_client.post(
            f'/api/inspections/inspection-reports/{report_id}/sign_report/')
        assert r.status_code == 200, r.content
        report.refresh_from_db()
        assert report.signed_at is not None
        assert report.signature_hash and len(report.signature_hash) == 64

        public_verify = APIClient()
        r = public_verify.get(
            f'/api/inspections/report-verification/{verification.verification_code}/')
        assert r.status_code == 200, r.content
        assert r.data['verification_code'] == verification.verification_code
        verification.refresh_from_db()
        assert verification.view_count >= 1

        # ==========================================================
        # ۱۲) گزارش مالی نهایی
        # ==========================================================
        r = self.admin_client.get('/api/core/admin/reports/financial/')
        assert r.status_code == 200
        assert int(r.data['summary']['total_revenue_rial']) == 21582000
        assert int(r.data['summary']['total_invoiced_rial']) == 21582000
        assert int(r.data['summary']['total_paid_count']) == 1


class TestPricingRoundingInfo:
    """تست تابع calculate_price_with_rounding_info."""

    def setup_method(self):
        self.eq = EquipmentType.objects.create(
            code='pc_crane', name_fa='جرثقیل قیمت')
        self.param = EquipmentParameter.objects.create(
            equipment_type=self.eq, name='tonnage', label='تناژ',
            field_type='number')
        self.rule = PricingRule.objects.create(
            equipment_type=self.eq, base_price=1000000,
            standard_multiplier=Decimal('1.0'),
            pro_multiplier=Decimal('1.0'))
        ParameterPrice.objects.create(
            pricing_rule=self.rule, parameter=self.param,
            rate_type='per_unit', rate=100000)
        CityMultiplier.objects.create(
            city='شیراز', multiplier=Decimal('1.0'), base_cost=150000)

    def test_exact_and_rounded(self):
        from pricing.utils import calculate_price_with_rounding_info
        info = calculate_price_with_rounding_info(
            self.eq, {'tonnage': 10}, city_name='شیراز')
        assert int(info['exact_total']) == 2150000
        assert int(info['rounded_total']) == 2200000
        assert info['rounding_discount'] >= 0

    def test_used_by_inspection_view(self):
        import importlib
        utils = importlib.import_module('pricing.utils')
        assert hasattr(utils, 'calculate_price_with_rounding_info')


class TestInvoiceNumberingConcurrency:
    """شماره فاکتور هرگز تکراری نمی‌شود (FIN-02)."""

    def test_100_numbers_all_unique(self):
        from core.services.invoice_service import InvoiceNumberService
        numbers = {
            InvoiceNumberService.next_number() for _ in range(100)
        }
        assert len(numbers) == 100
        for n in numbers:
            assert n.startswith('INV-')
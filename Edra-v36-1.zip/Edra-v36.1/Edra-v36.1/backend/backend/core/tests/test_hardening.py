# core/tests/test_hardening.py
"""
تست‌های فاز ۲ (Hardening) از گزارش ممیزی:
- NOT-01: لاگ/قالب نوتیفیکیشن فقط برای Admin
- Refund workflow (Phase 2)
- FILE-01: اعتبارسنجی magic bytes فیش بانکی
"""
import io
import os
import hashlib

import pytest
from django.contrib.auth import get_user_model
from django.contrib.auth.models import Group
from rest_framework.test import APIClient

from core.models import (
    CreditTransaction, EquipmentType, InspectionRequest, Payment,
    PaymentMethod, UserCredit,
)
from core.services.invoice_service import InvoiceSettlementService
from core.services.money import toman_to_rial
from edra_jalalidate import to_jalali
from notifications.models import NotificationLog, NotificationTemplate

User = get_user_model()

pytestmark = pytest.mark.django_db

PASSWORD = os.getenv("PASSWORD", "CHANGE_ME")


class _Base:
    def setup_method(self):
        self.client = APIClient()
        self.customer = User.objects.create_user(
            username="09120000011", password=PASSWORD)
        self.admin = User.objects.create_superuser(
            username="admin_test", password=PASSWORD)
        self.eq = EquipmentType.objects.create(
            name_fa="تست", code="TEST-H", param_schema={})
        self.request = InspectionRequest.objects.create(
            customer=self.customer,
            equipment_type=self.eq,
            city="تهران",
            address="آدرس",
            brand_model="مدل",
            calculated_price=1000000,
            final_price=1000000,
            status='pending_payment',
        )
        self.method_credit, _ = PaymentMethod.objects.get_or_create(
            name='credit', defaults={'is_active': True})


class TestNotificationScoping(_Base):
    """NOT-01: Template/Log فقط برای Admin."""

    def test_logs_admin_only(self):
        self.client.force_authenticate(user=self.customer)
        resp = self.client.get("/api/notifications/logs/")
        assert resp.status_code == 403

    def test_templates_admin_only(self):
        self.client.force_authenticate(user=self.customer)
        resp = self.client.get("/api/notifications/templates/")
        assert resp.status_code == 403

    def test_admin_can_read_logs(self):
        self.client.force_authenticate(user=self.admin)
        resp = self.client.get("/api/notifications/logs/")
        assert resp.status_code == 200

    def test_customer_cannot_create_template(self):
        self.client.force_authenticate(user=self.admin)
        resp = self.client.post("/api/notifications/templates/", {
            'code': 'X', 'channel': 'sms', 'subject': 't', 'body_template': 'b'})
        assert resp.status_code in (403, 405)


class TestRefundWorkflow(_Base):
    """Refund: فقط ادمین، فقط paid، برگشت سهم اعتباری."""

    def _make_paid_with_credit(self):
        UserCredit.objects.create(user=self.customer, balance=5000000)
        from core.services.credit_service import CreditService
        payment = Payment.objects.create(
            inspection_request=self.request,
            amount=1000000,
            amount_rial=toman_to_rial(1000000),
            credit_amount=1000000,
            online_amount=0,
            method=self.method_credit,
            status='paid',
            verified_at=None,
        )
        InvoiceSettlementService.settle(
            self.request, payment=payment, is_paid=True)
        return payment

    def test_refund_returns_credit(self):
        payment = self._make_paid_with_credit()
        self.client.force_authenticate(user=self.admin)
        resp = self.client.post(f"/api/core/payment/refund/{payment.id}/")
        assert resp.status_code == 200

        payment.refresh_from_db()
        assert payment.status == 'refunded'
        credit = UserCredit.objects.get(user=self.customer)
        assert credit.balance == 6000000
        tx = CreditTransaction.objects.filter(
            user=self.customer, transaction_type='refund').first()
        assert tx is not None and tx.amount == 1000000

    def test_refund_non_admin_forbidden(self):
        payment = self._make_paid_with_credit()
        self.client.force_authenticate(user=self.customer)
        resp = self.client.post(f"/api/core/payment/refund/{payment.id}/")
        assert resp.status_code == 403

    def test_refund_twice_rejected(self):
        payment = self._make_paid_with_credit()
        self.client.force_authenticate(user=self.admin)
        assert self.client.post(
            f"/api/core/payment/refund/{payment.id}/").status_code == 200
        assert self.client.post(
            f"/api/core/payment/refund/{payment.id}/").status_code == 400

    def test_refund_pending_rejected(self):
        payment = Payment.objects.create(
            inspection_request=self.request,
            amount=1000000,
            amount_rial=toman_to_rial(1000000),
            online_amount=1000000,
            method=self.method_credit,
            status='pending',
        )
        self.client.force_authenticate(user=self.admin)
        resp = self.client.post(f"/api/core/payment/refund/{payment.id}/")
        assert resp.status_code == 400


class TestReceiptProtection(_Base):
    """فیش بانکی فقط برای مالک/ادمین (IDOR)."""

    def _payment_with_receipt(self, user):
        from django.core.files.uploadedfile import SimpleUploadedFile
        content = b'\xff\xd8\xff\xe0JFIFfake'
        payment = Payment.objects.create(
            inspection_request=self.request,
            amount=1000000,
            amount_rial=toman_to_rial(1000000),
            manual_amount=1000000,
            method=self.method_credit,
            status='pending_verification',
            bank_receipt=SimpleUploadedFile(
                'r.jpg', content, content_type='image/jpeg'),
            bank_receipt_hash=hashlib.sha256(content).hexdigest(),
        )
        return payment

    def test_owner_can_download(self):
        payment = self._payment_with_receipt(self.customer)
        client = APIClient()
        client.force_authenticate(user=self.customer)
        r = client.get(f"/api/core/payments/{payment.id}/receipt/")
        assert r.status_code == 200
        assert r['Content-Type'].startswith('image/')

    def test_other_customer_forbidden(self):
        payment = self._payment_with_receipt(self.customer)
        other = User.objects.create_user(
            username="09120000099", password=PASSWORD)
        client = APIClient()
        client.force_authenticate(user=other)
        r = client.get(f"/api/core/payments/{payment.id}/receipt/")
        assert r.status_code == 403

    def test_admin_can_download(self):
        payment = self._payment_with_receipt(self.customer)
        client = APIClient()
        client.force_authenticate(user=self.admin)
        r = client.get(f"/api/core/payments/{payment.id}/receipt/")
        assert r.status_code == 200

    def test_no_receipt_404(self):
        payment = Payment.objects.create(
            inspection_request=self.request,
            amount=1000000,
            amount_rial=toman_to_rial(1000000),
            online_amount=1000000,
            method=self.method_credit,
            status='paid',
        )
        client = APIClient()
        client.force_authenticate(user=self.customer)
        r = client.get(f"/api/core/payments/{payment.id}/receipt/")
        assert r.status_code == 404


class TestReceiptValidation(_Base):
    """FILE-01: فایل فیش با magic bytes اشتباه رد می‌شود."""

    def test_fake_image_rejected(self):
        from core.views.credit_views import _validate_receipt_file
        from django.core.files.uploadedfile import SimpleUploadedFile

        fake = SimpleUploadedFile(
            "receipt.jpg", b"this is not a real jpeg", content_type="image/jpeg")
        error = _validate_receipt_file(fake)
        assert error is not None
        assert 'مطابقت' in error

    def test_real_pdf_accepted(self):
        from core.views.credit_views import _validate_receipt_file
        from django.core.files.uploadedfile import SimpleUploadedFile

        real = SimpleUploadedFile(
            "receipt.pdf", b"%PDF-1.4\nfake minimal pdf content",
            content_type="application/pdf")
        assert _validate_receipt_file(real) is None

    def test_oversize_rejected(self):
        from core.views.credit_views import (
            MAX_RECEIPT_SIZE, _validate_receipt_file)
        from django.core.files.uploadedfile import SimpleUploadedFile

        big = SimpleUploadedFile(
            "receipt.png", b"\x89PNG\r\n\x1a\n" + b"0" * (MAX_RECEIPT_SIZE + 1),
            content_type="image/png")
        error = _validate_receipt_file(big)
        assert error is not None
        assert 'مگابایت' in error
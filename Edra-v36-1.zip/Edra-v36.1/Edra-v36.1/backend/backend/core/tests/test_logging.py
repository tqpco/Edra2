# core/tests/test_logging.py
"""
تست لاگ‌گیری ساختاریافته (P2/P1-10):
- JsonFormatter خروجی JSON معتبر تک‌خطی تولید می‌کند
- request_id از thread-local در لاگ قرار می‌گیرد
- فیلدهای اضافی (extra=) قابل سریال شدن‌اند
"""
import json
import logging

import pytest

from core.logging import JsonFormatter, get_request_id, set_request_id


def _make_record(msg='سلام تست', extra=None, exc=False):
    logger = logging.getLogger('core.test')
    record = logger.makeRecord(
        logger.name, logging.INFO, __file__, 1, msg, None, None)
    if extra:
        for k, v in extra.items():
            setattr(record, k, v)
    return record


def test_formatter_emits_valid_json():
    set_request_id(None)
    record = _make_record()
    out = JsonFormatter().format(record)
    data = json.loads(out)
    assert data['message'] == 'سلام تست'
    assert data['level'] == 'INFO'
    assert data['logger'] == 'core.test'
    assert 'timestamp' in data
    assert data['request_id'] is None


def test_request_id_included_in_json():
    set_request_id('abc123')
    try:
        record = _make_record()
        out = JsonFormatter().format(record)
        data = json.loads(out)
        assert data['request_id'] == 'abc123'
    finally:
        set_request_id(None)
    assert get_request_id() is None


def test_extra_fields_serialized():
    record = _make_record(extra={'error_id': 'ERR123', 'count': 5})
    out = JsonFormatter().format(record)
    data = json.loads(out)
    assert data['error_id'] == 'ERR123'
    assert data['count'] == 5


def test_exception_included():
    try:
        raise ValueError('x')
    except ValueError:
        import sys
        record = _make_record(exc=True)
        record.exc_info = sys.exc_info()
    out = JsonFormatter().format(record)
    data = json.loads(out)
    assert 'exception' in data
    assert 'ValueError' in data['exception']
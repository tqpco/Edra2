import pytest
import os
from django.contrib.auth import get_user_model
from core.models import EquipmentType, InspectionRequest
from edra_jalalidate import to_jalali

User = get_user_model()

pytestmark = pytest.mark.django_db


class TestEquipmentType:
    def test_create_equipment_type(self):
        eq = EquipmentType.objects.create(
            name_fa="تست",
            code="TEST",
            param_schema={}
        )
        assert eq.name_fa == "تست"
        assert eq.code == "TEST"


class TestInspectionRequest:
    def test_create_inspection_request(self):
        user = User.objects.create_user(
            username="testuser", password=os.getenv(
                "PASSWORD", "CHANGE_ME"))
        eq = EquipmentType.objects.create(
            name_fa="تست",
            code="TEST",
            param_schema={}
        )
        request = InspectionRequest.objects.create(
            customer=user,
            equipment_type=eq,
            city="تهران",
            address="خیابان تست",
            brand_model="مدل تست",
            final_price=1000000,
            calculated_price=1000000,
            status="pending_payment"
        )
        assert request.customer == user
        assert request.status == "pending_payment"
        assert request.final_price == 1000000

    def test_request_status_choices(self):
        assert InspectionRequest.STATUS_CHOICES[0][0] == "draft"
        assert InspectionRequest.STATUS_CHOICES[1][0] == "pending_payment"

    def test_created_at_jalali_format(self):
        """تست تبدیل تاریخ ایجاد به جلالی با فرمت شامل ساعت"""
        user = User.objects.create_user(
            username="testuser2", password=os.getenv("PASSWORD", "CHANGE_ME"))
        eq = EquipmentType.objects.create(
            name_fa="تست2", code="TEST2", param_schema={})
        request = InspectionRequest.objects.create(
            customer=user, equipment_type=eq, city="تهران",
            address="تست", brand_model="مدل",
            calculated_price=1000000, final_price=1000000,
            status="pending_payment")
        jalali_str = to_jalali(request.created_at, "%Y/%m/%d %H:%M")
        assert jalali_str is not None
        assert len(jalali_str) >= 16  # شامل تاریخ و ساعت
# core/tests/test_serializers.py
from core.serializers import InspectionRequestSerializer
from core.models import EquipmentType
from django.contrib.auth import get_user_model
import pytest
import logging
from edra_jalalidate import to_jalali

logger = logging.getLogger(__name__)

User = get_user_model()

pytestmark = pytest.mark.django_db


class TestInspectionRequestSerializer:
    def test_validate_city_required(self):
        serializer = InspectionRequestSerializer(data={
            "address": "خیابان تست",
            "equipment_type_id": 1,
        })
        assert not serializer.is_valid()
        assert "city" in serializer.errors

    def test_validate_address_required(self):
        serializer = InspectionRequestSerializer(data={
            "city": "تهران",
            "equipment_type_id": 1,
        })
        assert not serializer.is_valid()
        assert "address" in serializer.errors

    def test_valid_data(self):
        user = User.objects.create_user(username="testuser")
        eq = EquipmentType.objects.create(
            name_fa="تست",
            code="TEST",
            param_schema={}
        )
        serializer = InspectionRequestSerializer(data={
            "city": "تهران",
            "address": "خیابان تست، پلاک ۱۲۳",
            "equipment_type": eq.id,
            "brand_model": "مدل تست",
            "manufacture_year": 1400,
            "params": {},
            "install_state": "installed",
        })
        is_valid = serializer.is_valid()
        if not is_valid:
            logger.info("Serialization errors:", serializer.errors)
        assert is_valid

    def test_created_at_jalali_format(self):
        """تست تبدیل تاریخ ایجاد به جلالی با فرمت شامل ساعت"""
        user = User.objects.create_user(username="testuser2")
        eq = EquipmentType.objects.create(
            name_fa="تست2", code="TEST2", param_schema={})
        from core.models import InspectionRequest
        request = InspectionRequest.objects.create(
            customer=user, equipment_type=eq, city="تهران",
            address="تست", brand_model="مدل",
            calculated_price=1000000, final_price=1000000,
            status="pending_payment")
        serializer = InspectionRequestSerializer(request)
        jalali_str = serializer.data.get('created_at_jalali')
        assert jalali_str is not None
        assert len(jalali_str) >= 16  # شامل تاریخ و ساعت
        assert '/' in jalali_str and ':' in jalali_str
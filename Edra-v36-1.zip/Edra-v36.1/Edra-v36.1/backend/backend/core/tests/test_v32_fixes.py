# core/tests/test_v32_fixes.py
"""
تست‌های رگرسیون اصلاحات EDRA v32.

توجه: این فایل در محیط ساخت v32 «اجرا نشده» (Django/pytest آنجا نصب نبود)؛
پیش از دیپلوی با `pytest core/tests/test_v32_fixes.py` اجرا کنید.

پوشش:
- UserSerializer/UserViewSet: ذخیره‌ی phone/company در پروفایل، شماره تکراری = 400
  (نه 500)، نقش اتمیک، DELETE = غیرفعال‌سازی (نه حذف سخت)
- PaymentMethodViewSet: ادمین PATCH می‌کند؛ POST/DELETE ممنوع؛ عموم فقط فعال‌ها
- تجهیز غیرفعال برای عموم دیده نمی‌شود
- ثبت درخواست بدون ورود رد می‌شود
- سقف ساعتی OTP برای هر شماره
- تاریخچه‌ی ضریب شهر
"""
import pytest
from django.contrib.auth import get_user_model
from django.contrib.auth.models import Group
from django.core.cache import cache
from rest_framework.test import APIClient

from core.models import CityMultiplier, EquipmentType, PaymentMethod, UserProfile

User = get_user_model()
pytestmark = pytest.mark.django_db


@pytest.fixture
def admin_client():
    admin = User.objects.create_user(username='v32_admin', password='x', is_staff=True)
    group, _ = Group.objects.get_or_create(name='Admin')
    admin.groups.add(group)
    c = APIClient()
    c.force_authenticate(user=admin)
    return c


@pytest.fixture
def customer_client():
    u = User.objects.create_user(username='v32_customer', password='x')
    c = APIClient()
    c.force_authenticate(user=u)
    return c


class TestUserAdminCrud:
    def test_create_saves_profile_fields_and_role(self, admin_client):
        r = admin_client.post('/api/core/users/', {
            'first_name': 'علی', 'last_name': 'رضایی',
            'phone': '09121234567', 'company_name': 'شرکت نمونه',
            'role': 'expert',
        }, format='json')
        assert r.status_code == 201, r.content
        assert r.data['phone'] == '09121234567'
        assert r.data['company_name'] == 'شرکت نمونه'
        assert r.data['role'] == 'expert'
        profile = UserProfile.objects.get(user_id=r.data['id'])
        assert profile.phone == '09121234567'

    def test_duplicate_phone_is_400_not_500(self, admin_client):
        body = {'first_name': 'الف', 'phone': '09120000001', 'role': 'customer'}
        assert admin_client.post('/api/core/users/', body, format='json').status_code == 201
        r = admin_client.post('/api/core/users/', body, format='json')
        assert r.status_code == 400
        assert 'phone' in r.data

    def test_persian_digits_phone_is_normalized(self, admin_client):
        r = admin_client.post('/api/core/users/', {
            'first_name': 'ب', 'phone': '۰۹۱۲۰۰۰۰۰۰۲', 'role': 'customer'}, format='json')
        assert r.status_code == 201, r.content
        assert r.data['phone'] == '09120000002'

    def test_invalid_phone_rejected(self, admin_client):
        r = admin_client.post('/api/core/users/', {
            'first_name': 'ج', 'phone': '12345', 'role': 'customer'}, format='json')
        assert r.status_code == 400
        assert 'phone' in r.data

    def test_patch_updates_profile(self, admin_client):
        r = admin_client.post('/api/core/users/', {
            'first_name': 'د', 'phone': '09120000003', 'role': 'customer'}, format='json')
        uid = r.data['id']
        r = admin_client.patch(f'/api/core/users/{uid}/', {'company_name': 'ACME'}, format='json')
        assert r.status_code == 200, r.content
        assert UserProfile.objects.get(user_id=uid).company_name == 'ACME'

    def test_delete_deactivates_instead_of_hard_delete(self, admin_client):
        r = admin_client.post('/api/core/users/', {
            'first_name': 'ه', 'phone': '09120000004', 'role': 'customer'}, format='json')
        uid = r.data['id']
        assert admin_client.delete(f'/api/core/users/{uid}/').status_code in (200, 204)
        user = User.objects.get(pk=uid)
        assert user.is_active is False

    def test_customer_cannot_create_users(self, customer_client):
        r = customer_client.post('/api/core/users/', {
            'first_name': 'x', 'phone': '09120000005', 'role': 'admin'}, format='json')
        assert r.status_code in (403, 404)


class TestPaymentMethods:
    def test_admin_can_toggle_but_not_create_or_delete(self, admin_client):
        pm = PaymentMethod.objects.create(name='manual', is_active=True)
        r = admin_client.patch(f'/api/core/payment-methods/{pm.id}/',
                               {'is_active': False}, format='json')
        assert r.status_code == 200, r.content
        pm.refresh_from_db()
        assert pm.is_active is False
        assert admin_client.post('/api/core/payment-methods/', {'name': 'online'},
                                 format='json').status_code == 405
        assert admin_client.delete(f'/api/core/payment-methods/{pm.id}/').status_code == 405

    def test_name_cannot_be_changed(self, admin_client):
        pm = PaymentMethod.objects.create(name='online', is_active=True)
        admin_client.patch(f'/api/core/payment-methods/{pm.id}/',
                           {'name': 'credit'}, format='json')
        pm.refresh_from_db()
        assert pm.name == 'online'

    def test_public_sees_only_active(self):
        PaymentMethod.objects.create(name='online', is_active=True)
        PaymentMethod.objects.create(name='manual', is_active=False)
        r = APIClient().get('/api/core/payment-methods/')
        assert r.status_code == 200
        names = [m['name'] for m in (r.data if isinstance(r.data, list) else r.data['results'])]
        assert names == ['online']

    def test_customer_cannot_patch(self, customer_client):
        pm = PaymentMethod.objects.create(name='credit', is_active=True)
        r = customer_client.patch(f'/api/core/payment-methods/{pm.id}/',
                                  {'is_active': False}, format='json')
        assert r.status_code == 403


class TestPublicReferenceData:
    def test_inactive_equipment_hidden_from_public_but_visible_to_admin(self, admin_client):
        EquipmentType.objects.create(code='v32_on', name_fa='فعال', is_active=True)
        EquipmentType.objects.create(code='v32_off', name_fa='غیرفعال', is_active=False)
        pub = APIClient().get('/api/core/equipment-types/')
        rows = pub.data if isinstance(pub.data, list) else pub.data['results']
        codes = {e['code'] for e in rows}
        assert 'v32_on' in codes and 'v32_off' not in codes
        adm = admin_client.get('/api/core/equipment-types/')
        rows = adm.data if isinstance(adm.data, list) else adm.data['results']
        assert {'v32_on', 'v32_off'} <= {e['code'] for e in rows}


class TestInspectionCreateRequiresLogin:
    def test_anonymous_create_denied(self):
        eq = EquipmentType.objects.create(code='v32_eq', name_fa='ت')
        r = APIClient().post('/api/core/inspection-requests/', {
            'equipment_type': eq.id, 'params': {}, 'city': 'تهران', 'address': 'x'},
            format='json')
        assert r.status_code in (401, 403)
        assert not User.objects.filter(username__startswith='guest_').exists()


class TestOtpHourlyCap:
    def test_sixth_request_in_an_hour_is_blocked(self, settings, monkeypatch):
        cache.clear()
        monkeypatch.setattr(settings, 'DEV_OTP_ENABLED', True)
        phone = '09129998877'
        monkeypatch.setattr(settings, 'DEV_OTP_ALLOWED_PHONES', [phone])
        c = APIClient()
        statuses = []
        for _ in range(7):
            cache.delete(f'otp_cooldown_{phone}')  # cooldown ۹۰ثانیه را کنار می‌گذاریم
            statuses.append(c.post('/api/core/otp/request/', {'phone': phone}).status_code)
        assert statuses[:5] == [200] * 5, statuses
        assert statuses[5] == 429 and statuses[6] == 429, statuses


class TestCityMultiplierHistory:
    def test_update_is_recorded_and_returned(self, admin_client):
        cm = CityMultiplier.objects.create(city='ازنا', multiplier='1.10', base_cost=900000)
        r = admin_client.patch(f'/api/core/city-multipliers/{cm.id}/',
                               {'multiplier': '1.25'}, format='json')
        assert r.status_code == 200, r.content
        h = admin_client.get(f'/api/core/city-multipliers/{cm.id}/history/')
        assert h.status_code == 200
        assert any(row['field'] == 'multiplier' and row['new_value'].startswith('1.25')
                   for row in h.data)

    def test_history_is_admin_only(self, customer_client):
        cm = CityMultiplier.objects.create(city='ازنا۲', multiplier='1.10', base_cost=900000)
        assert customer_client.get(
            f'/api/core/city-multipliers/{cm.id}/history/').status_code == 403


class TestPhoneEditKeepsOtpIdentity:
    def test_changing_phone_moves_username_too(self, admin_client):
        r = admin_client.post('/api/core/users/', {
            'first_name': 'و', 'phone': '09127770001', 'role': 'customer'}, format='json')
        uid = r.data['id']
        assert User.objects.get(pk=uid).username == '09127770001'
        r = admin_client.patch(f'/api/core/users/{uid}/', {'phone': '09127770002'}, format='json')
        assert r.status_code == 200, r.content
        user = User.objects.get(pk=uid)
        assert user.username == '09127770002'
        assert user.profile.phone == '09127770002'

    def test_phone_colliding_with_other_username_rejected(self, admin_client):
        User.objects.create_user(username='09127770003', password='x')
        r = admin_client.post('/api/core/users/', {
            'first_name': 'ز', 'phone': '09127770003', 'role': 'customer'}, format='json')
        assert r.status_code == 400
        assert 'phone' in r.data


# ============================================================
# EDRA v32 — SEC: افشای کدهای تخفیف (/api/core/customer/discount-codes/)
# ============================================================
# «حمله»ی اثبات‌شده: این endpoint با IsAuthenticated ساده و سریالایزر کامل
# ادمین (fields='__all__') ثبت شده بود و هیچ صفحه‌ای در فرانت آن را صدا
# نمی‌زد. هر کاربر واردشده (even a freshly-registered customer) می‌توانست
# با یک GET ساده، همه‌ی کدهای فعال از جمله کدهای هدفمند/ریفرال با ظرفیت کم
# را ببیند و قبل از مخاطب واقعی مصرف کند — و ارقام مدیریتی (used_count,
# usage_limit, per_user_limit) را هم ببیند.
from core.models import DiscountCode
from core.serializers import PublicDiscountCodeSerializer


class TestDiscountCodeExposure:
    def test_private_targeted_code_not_listed_to_other_customers(self, customer_client):
        """کد هدفمند (is_public=False، ظرفیت ۱، برای یک مشتری خاص) نباید
        برای کاربر دیگری در مرور عمومی ظاهر شود."""
        DiscountCode.objects.create(
            code='REFERRAL-VIP-9F2K', discount_type='fixed', value=500000,
            usage_limit=1, is_active=True, is_public=False,
        )
        r = customer_client.get('/api/core/customer/discount-codes/')
        assert r.status_code == 200
        codes = [c['code'] for c in (r.data if isinstance(r.data, list) else r.data['results'])]
        assert 'REFERRAL-VIP-9F2K' not in codes

    def test_public_code_is_listed(self, customer_client):
        DiscountCode.objects.create(
            code='PUBLIC-AUTUMN10', discount_type='percent', value=10,
            is_active=True, is_public=True,
        )
        r = customer_client.get('/api/core/customer/discount-codes/')
        codes = [c['code'] for c in (r.data if isinstance(r.data, list) else r.data['results'])]
        assert 'PUBLIC-AUTUMN10' in codes

    def test_public_listing_never_exposes_admin_only_fields(self, customer_client):
        """حتی برای کد عمومی، ارقام مدیریتی (ظرفیت/مصرف) نباید در پاسخ باشد —
        دفاع در عمق در برابر اضافه‌شدن فیلد حساس جدید به مدل در آینده."""
        DiscountCode.objects.create(
            code='PUBLIC-SPRING5', discount_type='percent', value=5,
            is_active=True, is_public=True, usage_limit=1000, per_user_limit=1,
        )
        r = customer_client.get('/api/core/customer/discount-codes/')
        row = next(c for c in (r.data if isinstance(r.data, list) else r.data['results'])
                   if c['code'] == 'PUBLIC-SPRING5')
        assert 'usage_limit' not in row
        assert 'used_count' not in row
        assert 'per_user_limit' not in row

    def test_exhausted_public_code_hidden(self, customer_client):
        DiscountCode.objects.create(
            code='PUBLIC-SOLDOUT', discount_type='percent', value=5,
            is_active=True, is_public=True, usage_limit=3, used_count=3,
        )
        r = customer_client.get('/api/core/customer/discount-codes/')
        codes = [c['code'] for c in (r.data if isinstance(r.data, list) else r.data['results'])]
        assert 'PUBLIC-SOLDOUT' not in codes

    def test_serializer_field_allowlist_is_minimal(self):
        """قفل رگرسیون: اگر کسی بعداً fields را به '__all__' برگرداند یا
        usage_limit/used_count را اضافه کند، این تست رد می‌شود."""
        fields = set(PublicDiscountCodeSerializer.Meta.fields)
        assert fields == {
            'code', 'discount_type', 'value', 'min_amount', 'max_amount',
            'apply_to_all', 'equipment_type_name', 'expires_at', 'expires_at_jalali',
        }


# ============================================================
# EDRA v32 — تست رگرسیون قیمت‌گذاری واقعی هنگام ساخت درخواست
# ============================================================
# تصحیح: در بررسی دور قبل، گمان شده بود که چون core/views/inspection_views.py
# مقدار final_price را به serializer.save() پاس نمی‌دهد، همه‌ی درخواست‌ها با
# ۱,۰۰۰,۰۰۰ تومان ثابت ذخیره می‌شوند. این تشخیص غلط بود: 
# InspectionRequestSerializer._create_atomic() مستقل از ویو، خودش
# calculate_price_with_components را فراخوانی می‌کند و calculated_price/
# final_price/price_breakdown را در همان متد، درست قبل از super().create()،
# می‌نویسد — یعنی این مقادیر از قبل درست محاسبه و ذخیره می‌شدند. این تست‌ها
# همان رفتار درستِ موجود را به‌عنوان قفل رگرسیون ثبت می‌کنند (نه رفع یک باگ).
from pricing.models import PricingRule
from core.models import CityMultiplier


class TestRequestPriceCalculationPersisted:
    def test_final_price_matches_real_calculation_not_flat_fallback(self, customer_client):
        eq = EquipmentType.objects.create(code='v32_crane', name_fa='تاور کرین تست')
        PricingRule.objects.create(
            equipment_type=eq, base_price=15_000_000, install_price=3_000_000,
            standard_multiplier=1, pro_multiplier=1.3)
        CityMultiplier.objects.create(city='تهران_تست', base_cost=100_000, multiplier=10)

        r = customer_client.post('/api/core/inspection-requests/', {
            'equipment_type': eq.id, 'params': {}, 'city': 'تهران_تست',
            'address': 'آدرس تست', 'install_state': 'installed',
        }, format='json')
        assert r.status_code == 201, r.content

        from core.models import InspectionRequest
        obj = InspectionRequest.objects.get(pk=r.data['id'])
        # (۱۵,۰۰۰,۰۰۰ + ۱۰۰,۰۰۰×۱۰) × ۱ + ۳,۰۰۰,۰۰۰ = ۱۹,۰۰۰,۰۰۰
        assert obj.final_price == 19_000_000, (
            f"قیمت ذخیره‌شده {obj.final_price} است؛ انتظار ۱۹,۰۰۰,۰۰۰ تومان. "
            f"اگر این مقدار ۱,۰۰۰,۰۰۰ باشد یعنی باگ fallback برگشته.")
        assert obj.calculated_price == 19_000_000
        assert obj.price_breakdown.get('base_price') == 15_000_000.0
        assert obj.price_breakdown.get('city_cost') == 1_000_000.0
        assert obj.price_breakdown.get('install_cost') == 3_000_000.0

    def test_cheap_equipment_not_overcharged_to_flat_fallback(self, customer_client):
        """تجهیز ارزان (مثلاً لیفتراک) نباید به ۱,۰۰۰,۰۰۰ تومان گران‌تر شود."""
        eq = EquipmentType.objects.create(code='v32_forklift', name_fa='لیفتراک تست')
        PricingRule.objects.create(
            equipment_type=eq, base_price=600_000, standard_multiplier=1, pro_multiplier=1.2)
        r = customer_client.post('/api/core/inspection-requests/', {
            'equipment_type': eq.id, 'params': {}, 'city': 'شهر_بدون_ضریب_تست', 'address': 'آدرس تست',
        }, format='json')
        assert r.status_code == 201, r.content
        from core.models import InspectionRequest
        obj = InspectionRequest.objects.get(pk=r.data['id'])
        assert obj.final_price == 600_000, obj.final_price

    def test_payment_snapshot_uses_real_price_not_zero_or_flat(self, customer_client):
        """پیوند با باگ قبلی: اگر final_price=0 ذخیره می‌شد، payment_snapshot
        هم مبلغ صفر برمی‌گرداند و initiate_payment یک پرداخت ۰ تومانی می‌ساخت."""
        eq = EquipmentType.objects.create(code='v32_snap', name_fa='تست اسنپ‌شات')
        PricingRule.objects.create(
            equipment_type=eq, base_price=2_000_000, standard_multiplier=1, pro_multiplier=1.2)
        r = customer_client.post('/api/core/inspection-requests/', {
            'equipment_type': eq.id, 'params': {}, 'city': 'شهر_بدون_ضریب_تست۲', 'address': 'آدرس تست',
        }, format='json')
        assert r.status_code == 201
        from core.services.invoice_service import InvoiceSettlementService
        from core.models import InspectionRequest
        obj = InspectionRequest.objects.get(pk=r.data['id'])
        snap = InvoiceSettlementService.payment_snapshot(obj)
        assert snap['amount'] > 0, "مبلغ پرداخت صفر است — یعنی باگ هنوز هست."
        assert snap['amount'] == 2_000_000


# ============================================================
# EDRA v32 — باگ بحرانی: درخواست‌هایی که ادمین «برای مشتری» می‌ساخت،
# همیشه به نام خودِ ادمین ثبت می‌شد (customer نادیده گرفته می‌شد)
# ============================================================
class TestAdminCreatesRequestForCustomer:
    def test_request_is_attributed_to_selected_customer_not_admin(self, admin_client):
        customer = User.objects.create_user(username='09130000111', password='x')
        eq = EquipmentType.objects.create(code='v32_attr', name_fa='تست انتساب')
        r = admin_client.post('/api/core/inspection-requests/', {
            'customer': customer.id, 'equipment_type': eq.id, 'params': {},
            'city': 'تست', 'address': 'آدرس تست',
        }, format='json')
        assert r.status_code == 201, r.content
        from core.models import InspectionRequest
        obj = InspectionRequest.objects.get(pk=r.data['id'])
        assert obj.customer_id == customer.id, (
            f"درخواست به customer_id={obj.customer_id} نسبت داده شد؛ "
            f"انتظار می‌رفت customer_id={customer.id} (مشتری انتخاب‌شده) باشد.")

    def test_customer_cannot_spoof_another_customer_as_themselves(self, customer_client):
        other = User.objects.create_user(username='09130000222', password='x')
        eq = EquipmentType.objects.create(code='v32_attr2', name_fa='تست انتساب ۲')
        r = customer_client.post('/api/core/inspection-requests/', {
            'customer': other.id, 'equipment_type': eq.id, 'params': {},
            'city': 'تست', 'address': 'آدرس تست',
        }, format='json')
        assert r.status_code == 201, r.content
        from core.models import InspectionRequest
        obj = InspectionRequest.objects.get(pk=r.data['id'])
        # مشتری عادی نباید بتواند customer را جعل کند؛ باید خودش بماند
        assert obj.customer_id != other.id


# ============================================================
# EDRA v32 — پیوست‌های ساخت تیکت بی‌صدا گم می‌شدند
# ============================================================
class TestTicketCreateAttachments:
    def test_attachments_sent_at_creation_are_saved(self, admin_client):
        from django.core.files.uploadedfile import SimpleUploadedFile
        from support.models import TicketAttachment
        file = SimpleUploadedFile('note.pdf', b'%PDF-1.4 test', content_type='application/pdf')
        r = admin_client.post('/api/support/tickets/', {
            'title': 'تیکت تست پیوست', 'description': 'توضیحات تست حداقل ده کاراکتر',
            'attachments': [file],
        }, format='multipart')
        assert r.status_code == 201, r.content
        assert TicketAttachment.objects.filter(ticket_id=r.data['id']).count() == 1


# ============================================================
# EDRA v32 — mark_read/mark_all_read فیلد اشتباه (status به‌جای is_read)
# را می‌نوشتند؛ اعلان هرگز واقعاً خوانده‌شده ثبت نمی‌شد
# ============================================================
class TestNotificationMarkRead:
    def test_mark_read_sets_is_read_not_status(self, customer_client):
        from notifications.models import NotificationLog, NotificationTemplate
        user = User.objects.get(username='v32_customer')
        template = NotificationTemplate.objects.create(
            code='v32_tpl', channel='sms', body_template='test')
        n = NotificationLog.objects.create(
            user=user, template=template, channel='sms', status='sent',
            content='test', is_read=False)
        r = customer_client.post(f'/api/core/notifications/{n.id}/mark_read/')
        assert r.status_code == 200, r.content
        n.refresh_from_db()
        assert n.is_read is True
        assert n.status == 'sent', (
            "status (وضعیت تحویل پیامک) نباید توسط mark_read دست‌کاری شود")

    def test_mark_all_read_uses_is_read_filter(self, customer_client):
        from notifications.models import NotificationLog, NotificationTemplate
        user = User.objects.get(username='v32_customer')
        template = NotificationTemplate.objects.create(
            code='v32_tpl2', channel='sms', body_template='test')
        n1 = NotificationLog.objects.create(
            user=user, template=template, channel='sms', status='failed',
            content='test', is_read=False)
        r = customer_client.post('/api/core/notifications/mark_all_read/')
        assert r.status_code == 200, r.content
        n1.refresh_from_db()
        assert n1.is_read is True
        assert n1.status == 'failed'


# ============================================================
# EDRA v32 — پیگیری: اقدامات پیشگیرانه‌ی کوچک این دور
# ============================================================
class TestFollowUpFixes:
    def test_invoice_filter_accepts_inspection_request(self, admin_client):
        r = admin_client.get('/api/core/invoices/?inspection_request=999999')
        assert r.status_code == 200

    def test_expired_announcement_hidden_from_customer(self, customer_client, admin_client):
        from django.utils import timezone
        from datetime import timedelta
        from support.models import Announcement
        expired = Announcement.objects.create(
            title='منقضی‌شده', content='x', audience='all', is_active=True,
            expires_at=timezone.now() - timedelta(days=1))
        active = Announcement.objects.create(
            title='فعال', content='x', audience='all', is_active=True)
        r = customer_client.get('/api/support/announcements/')
        titles = [a['title'] for a in (r.data if isinstance(r.data, list) else r.data['results'])]
        assert expired.title not in titles
        assert active.title in titles
        # ادمین باید هر دو را (حتی منقضی‌شده را) ببیند
        r2 = admin_client.get('/api/support/announcements/')
        titles2 = [a['title'] for a in (r2.data if isinstance(r2.data, list) else r2.data['results'])]
        assert expired.title in titles2


# ============================================================
# EDRA v32 — ادامه‌ی بررسی خط‌به‌خط: ویرایش درخواست توسط ادمین،
# تغییر مشتری همیشه بی‌صدا نادیده گرفته می‌شد
# ============================================================
class TestAdminEditRequestChangesCustomer:
    def test_put_with_new_customer_reassigns_request(self, admin_client):
        from core.models import InspectionRequest
        old_customer = User.objects.create_user(username='09140000111', password='x')
        new_customer = User.objects.create_user(username='09140000222', password='x')
        eq = EquipmentType.objects.create(code='v32_reassign', name_fa='تست انتقال')
        obj = InspectionRequest.objects.create(
            customer=old_customer, equipment_type=eq, city='تست', address='آدرس',
            status='draft')
        r = admin_client.put(f'/api/core/inspection-requests/{obj.id}/', {
            'customer': new_customer.id, 'equipment_type': eq.id,
            'city': 'تست', 'address': 'آدرس جدید',
        }, format='json')
        assert r.status_code == 200, r.content
        obj.refresh_from_db()
        assert obj.customer_id == new_customer.id, (
            f"بعد از PUT، customer_id هنوز {obj.customer_id} است؛ "
            f"انتظار می‌رفت {new_customer.id} باشد.")

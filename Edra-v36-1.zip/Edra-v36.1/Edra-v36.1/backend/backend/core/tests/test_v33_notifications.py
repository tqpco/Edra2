# core/tests/test_v33_notifications.py
# -*- coding: utf-8 -*-
"""
EDRA v33 — تست‌های بازنویسی سیستم اعلان.

توجه: این فایل در محیط ساخت v33 (بدون Django) *اجرا نشده* است؛ فقط syntax آن
کامپایل شده. قبل از انتشار حتماً اجرا شود:  pytest core/tests/test_v33_notifications.py
"""
import sys
from unittest import mock

import pytest
from django.contrib.auth import get_user_model
from rest_framework.test import APIClient

from core.models import DiscountCode, EquipmentType, InspectionRequest
from notifications.defaults import DEFAULT_TEMPLATES, DEFAULT_TEMPLATES_BY_CODE
from notifications.models import NotificationLog, NotificationTemplate
from notifications import services

User = get_user_model()
pytestmark = pytest.mark.django_db


def _user(username='09121110000', email=''):
    return User.objects.create_user(username=username, password='x', email=email)


# ------------------------------------------------------------------
# ریشه‌ها: ثبت سیگنال، seed، خودترمیم
# ------------------------------------------------------------------
class TestWiring:
    def test_signals_module_is_loaded_by_app_ready(self):
        assert 'notifications.signals' in sys.modules

    def test_all_default_templates_seeded_by_migration(self):
        codes = set(NotificationTemplate.objects.values_list('code', flat=True))
        missing = set(DEFAULT_TEMPLATES_BY_CODE) - codes
        assert not missing, f'seed ناقص: {missing}'

    def test_missing_template_self_heals(self):
        NotificationTemplate.objects.filter(code='ticket_created').delete()
        log = services.send_notification(
            _user(), 'ticket_created', {'ticket_id': 3, 'title': 'عنوان'})
        assert log is not None
        assert '#3' in log.content
        assert NotificationTemplate.objects.filter(code='ticket_created').exists()

    def test_every_code_used_in_defaults_has_unique_code(self):
        codes = [t['code'] for t in DEFAULT_TEMPLATES]
        assert len(codes) == len(set(codes))

    def test_in_memory_ws_ticket_roundtrip_single_use(self):
        from django.core.cache import cache
        from edra.ws_auth import _consume_ticket
        ticket = 'a' * 64
        cache.set(f'ws_ticket_{ticket}', 42, timeout=30)
        assert _consume_ticket(ticket) == 42
        assert _consume_ticket(ticket) is None  # یک‌بارمصرف
        assert _consume_ticket('not-a-valid-ticket') is None


# ------------------------------------------------------------------
# کانال‌ها / گیرنده‌ها
# ------------------------------------------------------------------
class TestChannels:
    def test_both_channel_uses_phone_for_sms_and_email_for_mail(self):
        user = _user(email='a@b.com')
        with mock.patch.object(services, '_send_sms_via_provider',
                               return_value=(True, None)) as sms, \
                mock.patch.object(services, 'send_mail') as mail:
            log = services.send_notification(user, 'request_created', {'request_id': 1})
        assert log.status == 'sent'
        sms.assert_called_once()
        assert sms.call_args[0][0] == '09121110000'
        mail.assert_called_once()
        assert mail.call_args.kwargs['recipient_list'] == ['a@b.com']

    def test_both_channel_without_email_still_sends_sms(self):
        user = _user()
        with mock.patch.object(services, '_send_sms_via_provider',
                               return_value=(True, None)) as sms, \
                mock.patch.object(services, 'send_mail') as mail:
            log = services.send_notification(user, 'request_created', {'request_id': 1})
        assert log.status == 'sent'
        sms.assert_called_once()
        mail.assert_not_called()

    def test_user_without_phone_or_email_still_gets_in_app_notification(self):
        admin = User.objects.create_user(username='admin_x', password='x')
        log = services.send_notification(
            admin, 'invoice_pdf_failed_admin',
            {'invoice_id': 1, 'invoice_number': 'N1', 'error': 'e', 'customer': 'c'})
        assert log is not None
        assert NotificationLog.objects.filter(user=admin, is_read=False).count() == 1
        assert log.status == 'sent'

    def test_sms_failure_marks_failed_and_never_leaks_api_key(self, settings):
        settings.SMS_PROVIDER = 'kavenegar'
        settings.SMS_API_KEY = 'SUPER-SECRET-KEY'
        with mock.patch('requests.post',
                        side_effect=RuntimeError(
                            'boom https://api.kavenegar.com/v1/SUPER-SECRET-KEY/sms/send.json')):
            log = services.send_notification(
                _user(), 'payment_successful', {'request_id': 1, 'amount': '10'})
        assert log.status == 'failed'
        assert 'SUPER-SECRET-KEY' not in log.error_message

    def test_deliver_log_is_idempotent(self):
        with mock.patch.object(services, '_send_sms_via_provider',
                               return_value=(True, None)) as sms:
            log = services.send_notification(
                _user(), 'payment_successful', {'request_id': 1, 'amount': '10'})
            services.deliver_log(log)
            services.deliver_log(log)
        assert sms.call_count == 1

    def test_sms_body_is_not_html_escaped(self):
        with mock.patch.object(services, '_send_sms_via_provider',
                               return_value=(True, None)):
            log = services.send_notification(
                _user(), 'payment_rejected',
                {'request_id': 1, 'reason': 'الف & ب <ج>'})
        assert 'الف & ب <ج>' in log.content

    def test_normalize_phone(self):
        n = services.normalize_phone
        assert n('+989121234567') == '09121234567'
        assert n('۰۹۱۲۱۲۳۴۵۶۷') == '09121234567'
        assert n('admin') == ''


# ------------------------------------------------------------------
# تسک صف
# ------------------------------------------------------------------
class TestPendingTask:
    def test_pending_sms_is_actually_sent(self):
        from notifications.tasks import process_pending_notifications
        user = _user()
        log = services.queue_notification(user, 'new_discount_code', {'code': 'ABC'})
        assert log.status == 'pending'
        with mock.patch.object(services, '_send_sms_via_provider',
                               return_value=(True, None)) as sms:
            result = process_pending_notifications()
        sms.assert_called_once()
        log.refresh_from_db()
        assert log.status == 'sent'
        assert result['sent'] >= 1

    def test_failed_log_can_be_retried_in_place(self):
        from django.core.management import call_command
        with mock.patch.object(services, '_send_sms_via_provider',
                               return_value=(False, 'down')):
            log = services.send_notification(
                _user(), 'payment_successful', {'request_id': 1, 'amount': '1'})
        assert log.status == 'failed'
        with mock.patch.object(services, '_send_sms_via_provider',
                               return_value=(True, None)):
            call_command('retry_failed_notifications')
        log.refresh_from_db()
        assert log.status == 'sent'
        assert NotificationLog.objects.filter(type='payment_successful').count() == 1


# ------------------------------------------------------------------
# API صندوق اعلان
# ------------------------------------------------------------------
class TestInboxApi:
    def _client(self, user):
        c = APIClient()
        c.force_authenticate(user)
        return c

    def test_inbox_hides_internal_fields(self):
        user = _user()
        services.send_notification(
            user, 'request_created', {'request_id': 1})
        r = self._client(user).get('/api/core/notifications/')
        assert r.status_code == 200
        rows = r.data['results'] if isinstance(r.data, dict) else r.data
        assert rows
        for forbidden in ('recipient', 'error_message', 'user', 'template'):
            assert forbidden not in rows[0]

    def test_unread_filter_and_count(self):
        user = _user()
        for i in range(3):
            services.send_notification(user, 'request_created', {'request_id': i})
        c = self._client(user)
        assert c.get('/api/core/notifications/unread_count/').data['count'] == 3
        first = NotificationLog.objects.filter(user=user).first()
        assert c.post(f'/api/core/notifications/{first.id}/mark_read/').status_code == 200
        r = c.get('/api/core/notifications/?is_read=false')
        rows = r.data['results'] if isinstance(r.data, dict) else r.data
        assert len(rows) == 2

    def test_user_cannot_read_others_notifications(self):
        a, b = _user('09121110001'), _user('09121110002')
        log = services.send_notification(a, 'request_created', {'request_id': 1})
        r = self._client(b).post(f'/api/core/notifications/{log.id}/mark_read/')
        assert r.status_code == 404


# ------------------------------------------------------------------
# نشت کد تخفیف / اعلان تغییر وضعیت
# ------------------------------------------------------------------
class TestDiscountBroadcast:
    def test_private_code_is_not_broadcast(self):
        other = _user('09121110003')
        DiscountCode.objects.create(
            code='PRIVATE-ONE', discount_type='fixed', value=1000,
            usage_limit=1, is_active=True, is_public=False)
        assert not NotificationLog.objects.filter(
            user=other, content__contains='PRIVATE-ONE').exists()

    def test_public_code_is_queued_for_customers(self):
        other = _user('09121110004')
        DiscountCode.objects.create(
            code='PUBLIC-ONE', discount_type='fixed', value=1000,
            usage_limit=100, is_active=True, is_public=True)
        assert NotificationLog.objects.filter(
            user=other, content__contains='PUBLIC-ONE', status='pending').exists()


class TestStatusChangeNotification:
    def _request(self, customer, status):
        eq = EquipmentType.objects.create(code='v33_eq', name_fa='تجهیز')
        return InspectionRequest.objects.create(
            customer=customer, equipment_type=eq, city='تهران', address='x',
            brand_model='m', calculated_price=1000, final_price=1000,
            status=status)

    def test_in_progress_notifies_customer_once_with_persian_label(
            self, django_capture_on_commit_callbacks):
        customer = _user('09121110005')
        req = self._request(customer, 'scheduled')
        with django_capture_on_commit_callbacks(execute=True):
            req.status = 'in_progress'
            req.save()
        logs = NotificationLog.objects.filter(user=customer, type='status_changed')
        assert logs.count() == 1
        assert 'in_progress' not in logs.first().content  # برچسب فارسی، نه کد خام

    def test_unchanged_status_sends_nothing(self, django_capture_on_commit_callbacks):
        customer = _user('09121110006')
        req = self._request(customer, 'scheduled')
        with django_capture_on_commit_callbacks(execute=True):
            req.city = 'شیراز'
            req.save()
        assert not NotificationLog.objects.filter(
            user=customer, type='status_changed').exists()

    def test_payment_flow_scheduled_not_duplicated(
            self, django_capture_on_commit_callbacks):
        customer = _user('09121110007')
        req = self._request(customer, 'pending_payment')
        with django_capture_on_commit_callbacks(execute=True):
            req.status = 'scheduled'
            req.save()
        assert not NotificationLog.objects.filter(
            user=customer, type='status_changed').exists()

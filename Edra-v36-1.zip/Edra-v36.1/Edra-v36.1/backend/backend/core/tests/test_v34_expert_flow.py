# core/tests/test_v34_expert_flow.py
"""
EDRA v34 — تست‌های بخش کارشناسی (درخواست ← ارجاع ← شروع ← ثبت گزارش ← PDF ←
تحویل به مشتری). توجه: این فایل در محیط ساخت v34 اجرا نشده است (Django نصب
نبود)؛ قبل از انتشار `pytest core/tests/test_v34_expert_flow.py` را اجرا کنید.
"""
import pytest
from django.contrib.auth import get_user_model
from django.contrib.auth.models import Group
from rest_framework.test import APIClient

from core.models import (
    ChecklistCategory, ChecklistItem, ChecklistTemplate, EquipmentType,
    InspectionReport, InspectionRequest,
)
from core.services.inspection_service import (
    ALLOWED_STATUS_TRANSITIONS, EXPERT_EXECUTABLE_STATUSES,
    apply_status_change, can_transition,
)

User = get_user_model()
pytestmark = pytest.mark.django_db


def _user(name, group=None, staff=False):
    u = User.objects.create_user(username=name, password='Pw-12345-xyz!')
    if staff:
        u.is_staff = True
        u.save()
    if group:
        g, _ = Group.objects.get_or_create(name=group)
        u.groups.add(g)
    return u


def _client(user):
    c = APIClient()
    c.force_authenticate(user)
    return c


class Base:
    def setup_method(self):
        self.admin = _user('adm', 'Admin', staff=True)
        self.expert = _user('exp1', 'Expert')
        self.other_expert = _user('exp2', 'Expert')
        self.customer = _user('09120000999')
        self.eq = EquipmentType.objects.create(code='t34', name_fa='جرثقیل ۳۴')
        self.cat = ChecklistCategory.objects.create(name='سازه')
        self.tpl = ChecklistTemplate.objects.create(
            name='قالب', equipment_type=self.eq, is_active=True)
        self.item = ChecklistItem.objects.create(
            checklist_template=self.tpl, category=self.cat,
            title='جوش', order=1)
        self.req = InspectionRequest.objects.create(
            customer=self.customer, equipment_type=self.eq, city='تهران',
            address='x', status='assigned', assigned_expert=self.expert,
            final_price=1000000, calculated_price=1000000)

    def submit(self, client, **extra):
        data = {
            'request_id': self.req.id,
            'results': '[{"item_id": %d, "result": "pass", "note": ""}]'
                       % self.item.id,
        }
        data.update(extra)
        return client.post('/api/expert/submit-checklist/', data,
                           format='multipart')


class TestWorkflowTable:
    def test_assigned_is_executable(self):
        assert 'assigned' in EXPERT_EXECUTABLE_STATUSES
        assert 'rescheduled' in EXPERT_EXECUTABLE_STATUSES

    def test_table_consistency(self):
        for old, targets in ALLOWED_STATUS_TRANSITIONS.items():
            for t in targets:
                assert can_transition(old, t)
        assert not can_transition('completed', 'in_progress')
        assert not can_transition('paid', 'cancelled')


class TestExpertStartAndSubmit(Base):
    def test_start_from_assigned(self):
        r = _client(self.expert).post(
            f'/api/expert/tasks/{self.req.id}/start/')
        assert r.status_code == 200, r.content
        self.req.refresh_from_db()
        assert self.req.status == 'in_progress'

    def test_start_is_idempotent(self):
        c = _client(self.expert)
        assert c.post(f'/api/expert/tasks/{self.req.id}/start/').status_code == 200
        assert c.post(f'/api/expert/tasks/{self.req.id}/start/').status_code == 200

    def test_other_expert_cannot_start(self):
        r = _client(self.other_expert).post(
            f'/api/expert/tasks/{self.req.id}/start/')
        assert r.status_code == 404

    def test_cancelled_cannot_submit(self):
        InspectionRequest.objects.filter(pk=self.req.pk).update(
            status='cancelled')
        r = self.submit(_client(self.expert))
        assert r.status_code == 400

    def test_submit_from_assigned_creates_report_and_verification(self):
        r = self.submit(_client(self.expert))
        assert r.status_code == 200, r.content
        self.req.refresh_from_db()
        assert self.req.status == 'completed'
        report = InspectionReport.objects.get(inspection_request=self.req)
        assert report.report_number.startswith('REP-')
        assert report.verification.verification_code
        # category در JSON نتایج رشته است (نه شیء مدل)
        assert report.results[0]['category'] == 'سازه'

    def test_double_submit_is_rejected_not_500(self):
        c = _client(self.expert)
        assert self.submit(c).status_code == 200
        assert self.submit(c).status_code in (400, 409)

    def test_task_detail_serializes_category_name(self):
        r = _client(self.expert).get(f'/api/expert/tasks/{self.req.id}/')
        assert r.status_code == 200, r.content
        items = r.data['checklist_template']['items']
        assert items[0]['category'] == 'سازه'
        assert r.data['task']['can_submit'] is True

    def test_task_list_is_paginated(self):
        r = _client(self.expert).get('/api/expert/tasks/?page=1')
        assert r.status_code == 200
        assert r.data['count'] == 1 and r.data['page'] == 1


class TestCustomerReportAccess(Base):
    def _finalize(self):
        assert self.submit(_client(self.expert)).status_code == 200
        return InspectionReport.objects.get(inspection_request=self.req)

    def test_customer_sees_own_completed_report_without_gps(self):
        report = self._finalize()
        r = _client(self.customer).get('/api/core/customer/reports/')
        assert r.status_code == 200
        data = r.data if isinstance(r.data, list) else r.data['results']
        assert [x['id'] for x in data] == [report.id]
        assert 'gps_start_lat' not in data[0]
        assert 'signature_hash' not in data[0]

    def test_customer_can_reach_pdf_endpoint(self):
        report = self._finalize()
        r = _client(self.customer).get(
            f'/api/inspections/inspection-reports/{report.id}/pdf/')
        # PDF هنوز تولید نشده (Celery) → ۴۰۴ با پیام، نه «پیدا نشد» به‌خاطر
        # کوئری‌ست؛ برای مشتری دیگر ۴۰۴ از کوئری‌ست است.
        assert r.status_code == 404
        assert 'PDF' in str(r.data.get('error', ''))
        other = _user('09129999999')
        r2 = _client(other).get(
            f'/api/inspections/inspection-reports/{report.id}/pdf/')
        assert r2.status_code == 404
        assert 'PDF' not in str(getattr(r2, 'data', {}))

    def test_customer_cannot_modify_report(self):
        report = self._finalize()
        r = _client(self.customer).patch(
            f'/api/inspections/inspection-reports/{report.id}/',
            {'inspector_notes': 'x'}, format='json')
        assert r.status_code == 403

    def test_pending_report_hidden_from_customer(self):
        InspectionReport.objects.create(
            inspection_request=self.req, report_number='REP-X-1',
            overall_result='pending')
        r = _client(self.customer).get('/api/core/customer/reports/')
        data = r.data if isinstance(r.data, list) else r.data['results']
        assert data == []


class TestAssignExpert(Base):
    def test_cannot_assign_cancelled(self):
        InspectionRequest.objects.filter(pk=self.req.pk).update(
            status='cancelled')
        r = _client(self.admin).post(
            f'/api/core/inspection-requests/{self.req.id}/assign_expert/',
            {'expert_id': self.other_expert.id}, format='json')
        assert r.status_code == 400

    def test_reassign_changes_expert(self):
        r = _client(self.admin).post(
            f'/api/core/inspection-requests/{self.req.id}/assign_expert/',
            {'expert_id': self.other_expert.id}, format='json')
        assert r.status_code == 200, r.content
        self.req.refresh_from_db()
        assert self.req.assigned_expert_id == self.other_expert.id

    def test_inactive_expert_rejected(self):
        self.other_expert.is_active = False
        self.other_expert.save()
        r = _client(self.admin).post(
            f'/api/core/inspection-requests/{self.req.id}/assign_expert/',
            {'expert_id': self.other_expert.id}, format='json')
        assert r.status_code == 400


class TestChecklistApi(Base):
    def test_item_api_uses_category_name(self):
        c = _client(self.admin)
        r = c.post('/api/inspections/checklist-items/', {
            'checklist_template': self.tpl.id, 'category': 'برق',
            'title': 'تابلو', 'order': 5}, format='json')
        assert r.status_code == 201, r.content
        assert r.data['category'] == 'برق'
        assert ChecklistCategory.objects.filter(name='برق').exists()
        r = c.get(f'/api/inspections/checklist-templates/{self.tpl.id}/items/')
        assert {i['category'] for i in r.data} == {'سازه', 'برق'}

    def test_duplicate_item_gives_400(self):
        c = _client(self.admin)
        r = c.post('/api/inspections/checklist-items/', {
            'checklist_template': self.tpl.id, 'category': 'سازه',
            'title': 'جوش', 'order': 9}, format='json')
        assert r.status_code == 400


class TestApplyStatusChange(Base):
    def test_audit_and_updated_at(self):
        from core.models import AuditLog
        before = self.req.updated_at
        apply_status_change(self.req, 'in_progress', actor=self.expert)
        self.req.refresh_from_db()
        assert self.req.status == 'in_progress'
        assert self.req.updated_at >= before
        log = AuditLog.objects.filter(
            action='change_status', object_id=self.req.id).last()
        assert log.changes['old_status'] == 'assigned'
        assert log.changes['new_status'] == 'in_progress'

    def test_invalid_transition_raises(self):
        with pytest.raises(ValueError):
            apply_status_change(self.req, 'expired')


class TestGpsToggle(Base):
    def test_gps_off_by_default_ignores_coordinates(self):
        from core.models import SystemSetting
        from core.utils.geo import gps_antifraud_enabled
        assert gps_antifraud_enabled() is False
        r = self.submit(_client(self.expert), gps_start_lat='35.7', gps_start_lng='51.4')
        assert r.status_code == 200, r.content
        report = InspectionReport.objects.get(inspection_request=self.req)
        assert report.gps_start_lat is None and report.gps_distance_meters is None

    def test_gps_on_records_coordinates(self):
        from core.models import SystemSetting
        SystemSetting.set_value('gps_antifraud_enabled', True)
        r = _client(self.expert).get(f'/api/expert/tasks/{self.req.id}/')
        assert r.data['gps_enabled'] is True
        r = self.submit(_client(self.expert), gps_start_lat='35.7', gps_start_lng='51.4')
        assert r.status_code == 200, r.content
        report = InspectionReport.objects.get(inspection_request=self.req)
        assert report.gps_start_lat is not None

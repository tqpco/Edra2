# core/tests/test_v35_finance.py
# -*- coding: utf-8 -*-
"""
EDRA v35 — تست‌های رگرسیون بازبینی کامل بخش مالی.

هر تست یک باگ واقعی پولی را قفل می‌کند:
  ۱) افزایش رایگان اعتبار با method=credit بدون request_id
  ۲) افزایش اعتبار آنلاین که پول می‌گرفت و موجودی را زیاد نمی‌کرد
  ۳) تایید دوباره/همزمان واریز اعتبار → موجودی دو برابر
  ۴) رد پرداخت: برگرداندن اعتبارِ مصرف‌نشده (اعتبار رایگان)
  ۵) تلاش مجدد عودت بعد از خطای درگاه → سهم اعتبار دو بار برگشت
  ۶) تخفیف ۱۰۰٪ بی‌صدا به قیمت کامل برمی‌گشت
  ۷) اعمال مجدد همان کد با per_user_limit=1
  ۸) لغو/انقضای درخواست: آزادسازی کد تخفیف و اعتبار رزروشده
  ۹) پرداخت واریز اعتبار فاکتور (با مالیات) نمی‌سازد
  ۱۰) تغییر دستی وضعیت به paid بدون پرداخت ممنوع است
"""
from decimal import Decimal

import pytest

from core.models import (
    CreditReservation, CreditTransaction, DiscountCode, InspectionRequest,
    Invoice, Payment, PaymentMethod, Refund, UserCredit,
)
from core.services.credit_service import CreditService
from core.services.money import toman_to_rial
from core.services.payment_service import ZarinpalService
from core.tests.test_discount_flow import _Base

pytestmark = pytest.mark.django_db


def _method(name):
    return PaymentMethod.objects.get_or_create(
        name=name, defaults={'is_active': True})[0]


def _deposit_request(customer, amount):
    from core.models import CityMultiplier, EquipmentType
    return InspectionRequest.objects.create(
        customer=customer,
        equipment_type=EquipmentType.objects.first(),
        city=CityMultiplier.objects.first().city,
        address='واریز اعتبار', brand_model='واریز اعتبار',
        calculated_price=amount, final_price=amount,
        status='pending_payment', params={'is_deposit': True})


class TestCreditInflationAndDeposit(_Base):
    def test_credit_method_without_request_cannot_inflate_balance(self):
        UserCredit.objects.create(user=self.customer, balance=1000000)
        r = self.client.post('/api/core/credit/deposit/', {
            'method': 'credit', 'amount': 500000}, format='json')
        assert r.status_code == 400
        assert UserCredit.objects.get(user=self.customer).balance == 1000000

    def test_online_deposit_callback_credits_balance_without_invoice(
            self, monkeypatch):
        monkeypatch.setattr(
            ZarinpalService, 'create_payment',
            lambda amount, description, callback_url, metadata=None: {
                'success': True, 'authority': 'DEP-AUTH-1',
                'payment_url': 'https://pay.example/DEP-AUTH-1'})
        monkeypatch.setattr(
            ZarinpalService, 'verify_payment',
            lambda authority, amount: {'success': True, 'ref_id': 'DEP-REF-1'})
        r = self.client.post('/api/core/credit/deposit/', {
            'method': 'online', 'amount': 50000}, format='json')
        assert r.status_code == 200, r.content
        cb = self.client.get(
            '/api/core/payment/callback/?Authority=DEP-AUTH-1&Status=OK')
        assert cb.status_code == 302 and 'payment/success' in cb.url
        assert UserCredit.objects.get(user=self.customer).balance == 50000
        assert CreditTransaction.objects.filter(
            user=self.customer, transaction_type='deposit').count() == 1
        assert Invoice.objects.count() == 0
        # callback تکراری → موجودی دوباره زیاد نمی‌شود
        self.client.get(
            '/api/core/payment/callback/?Authority=DEP-AUTH-1&Status=OK')
        assert UserCredit.objects.get(user=self.customer).balance == 50000

    def test_verify_deposit_twice_credits_once(self):
        req = _deposit_request(self.customer, 100000)
        p = Payment.objects.create(
            inspection_request=req, amount=100000,
            amount_rial=toman_to_rial(100000), manual_amount=100000,
            method=_method('manual'), status='pending_verification')
        assert self.admin_client.post(
            f'/api/core/credit/verify/{p.id}/').status_code == 200
        assert self.admin_client.post(
            f'/api/core/credit/verify/{p.id}/').status_code == 400
        assert UserCredit.objects.get(user=self.customer).balance == 100000
        assert Invoice.objects.count() == 0

    def test_reject_does_not_refund_unconsumed_credit(self):
        UserCredit.objects.create(user=self.customer, balance=1000000)
        data = self._make_request()
        req = InspectionRequest.objects.get(id=data['id'])
        p = Payment.objects.create(
            inspection_request=req, amount=500000,
            amount_rial=toman_to_rial(500000), credit_amount=500000,
            method=_method('credit'), status='pending_verification')
        r = self.admin_client.post(
            f'/api/core/credit/reject/{p.id}/',
            {'rejection_reason': 'x'}, format='json')
        assert r.status_code == 200
        assert UserCredit.objects.get(user=self.customer).balance == 1000000


class TestRefundRetry(_Base):
    def test_retry_after_gateway_failure_credits_once(self, monkeypatch):
        UserCredit.objects.create(user=self.customer, balance=0)
        data = self._make_request()
        req = InspectionRequest.objects.get(id=data['id'])
        p = Payment.objects.create(
            inspection_request=req, amount=200000,
            amount_rial=toman_to_rial(200000), credit_amount=100000,
            online_amount=100000, method=_method('online'), status='paid',
            authority='REF-A', ref_id='REF-1')
        calls = {'n': 0}

        def fake_refund(authority, ref_id, amount_rial):
            calls['n'] += 1
            if calls['n'] == 1:
                return {'success': False, 'reference': None,
                        'gateway_status': 'refund_failed', 'error': 'down'}
            return {'success': True, 'reference': 'RF-1',
                    'gateway_status': 'refunded', 'error': None}

        monkeypatch.setattr(ZarinpalService, 'refund_payment', fake_refund)
        r1 = self.admin_client.post(f'/api/core/payment/refund/{p.id}/')
        assert r1.status_code == 502
        r2 = self.admin_client.post(f'/api/core/payment/refund/{p.id}/')
        assert r2.status_code == 200, r2.content
        assert UserCredit.objects.get(user=self.customer).balance == 100000
        assert Refund.objects.filter(payment=p).count() == 1


class TestDiscountEdges(_Base):
    def test_full_discount_keeps_zero_final_price(self):
        DiscountCode.objects.create(
            code='FREE100', discount_type='percent', value=100,
            apply_to_all=True, is_active=True, usage_limit=10,
            per_user_limit=1)
        data = self._make_request(with_discount='FREE100')
        req = InspectionRequest.objects.get(id=data['id'])
        assert req.calculated_price > 0
        assert req.final_price == 0

    def test_reapply_same_code_with_per_user_limit_one(self):
        DiscountCode.objects.create(
            code='ONCE', discount_type='percent', value=10,
            apply_to_all=True, is_active=True, usage_limit=5,
            per_user_limit=1)
        data = self._make_request()
        url = f"/api/core/inspection-requests/{data['id']}/apply-discount/"
        assert self.client.post(url, {'code': 'ONCE'}, format='json').status_code == 200
        assert self.client.post(url, {'code': 'ONCE'}, format='json').status_code == 200
        assert DiscountCode.objects.get(code='ONCE').used_count == 1

    def test_expiry_releases_discount_and_credit(self):
        UserCredit.objects.create(user=self.customer, balance=1000000)
        data = self._make_request(with_discount='DISC10')
        req = InspectionRequest.objects.get(id=data['id'])
        assert DiscountCode.objects.get(code='DISC10').used_count == 1
        res = CreditService.reserve(
            self.customer, 100000, inspection_request=req)
        req.status = 'expired'
        req.save(update_fields=['status'])
        assert DiscountCode.objects.get(code='DISC10').used_count == 0
        res.refresh_from_db()
        assert res.status == 'released'


class TestStatusBypass(_Base):
    def test_deposit_payment_makes_no_invoice(self):
        req = _deposit_request(self.customer, 100000)
        Payment.objects.create(
            inspection_request=req, amount=100000,
            amount_rial=toman_to_rial(100000), online_amount=100000,
            method=_method('online'), status='paid')
        assert Invoice.objects.count() == 0

    def test_change_status_paid_requires_real_payment(self):
        data = self._make_request()
        r = self.admin_client.post(
            f"/api/core/inspection-requests/{data['id']}/change_status/",
            {'status': 'paid'}, format='json')
        assert r.status_code == 400
        assert InspectionRequest.objects.get(
            id=data['id']).status == 'pending_payment'

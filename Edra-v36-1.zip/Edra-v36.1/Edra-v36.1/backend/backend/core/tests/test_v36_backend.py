# core/tests/test_v36_backend.py
# -*- coding: utf-8 -*-
"""
EDRA v36 — تست‌های رگرسیون بازرسی کامل بک‌اند (بخش غیرمالی + امنیت).
هر تست یک باگ واقعی را قفل می‌کند (جزئیات: EDRA_V36_Report.md).
"""
import pytest
from django.core.cache import cache
from rest_framework.test import APIClient
from rest_framework_simplejwt.tokens import RefreshToken

from core.models import (
    CityMultiplier, DiscountCode, EquipmentParameter, InspectionRequest,
    UserProfile,
)
from core.tests.test_discount_flow import _Base, User

pytestmark = pytest.mark.django_db

REQ = '/api/core/inspection-requests/'


def _post(client, eq, **over):
    data = {'equipment_type': eq.id, 'params': {'tonnage': 10},
            'city': 'تهران', 'address': 'تست', 'brand_model': 'مدل'}
    data.update(over)
    return client.post(REQ, data, format='json')


class TestRequestCreationHardening(_Base):
    def test_negative_param_rejected(self):
        r = _post(self.client, self.eq, params={'tonnage': -50})
        assert r.status_code == 400

    def test_nan_param_rejected(self):
        r = _post(self.client, self.eq, params={'tonnage': 'NaN'})
        assert r.status_code == 400

    def test_required_param_cannot_be_omitted(self):
        EquipmentParameter.objects.filter(pk=self.param.pk).update(required=True)
        r = _post(self.client, self.eq, params={})
        assert r.status_code == 400

    def test_is_deposit_cannot_be_injected(self):
        r = _post(self.client, self.eq,
                  params={'tonnage': 10, 'is_deposit': True})
        assert r.status_code == 201, r.content
        req = InspectionRequest.objects.get(id=r.data['id'])
        assert not (req.params or {}).get('is_deposit')

    def test_customer_cannot_set_assigned_expert(self):
        other = User.objects.create_user(username='09129990001', password='x')
        r = _post(self.client, self.eq, assigned_expert=other.id,
                  request_number='HACK-1')
        assert r.status_code == 201, r.content
        req = InspectionRequest.objects.get(id=r.data['id'])
        assert req.assigned_expert_id is None
        assert req.request_number != 'HACK-1'

    def test_unknown_city_rejected_when_cities_defined(self):
        assert CityMultiplier.objects.exists()
        r = _post(self.client, self.eq, city='شهر-ساختگی')
        assert r.status_code == 400

    def test_price_fields_locked_after_creation(self):
        data = _post(self.client, self.eq).data
        r = self.client.patch(
            f"{REQ}{data['id']}/", {'params': {'tonnage': 500}}, format='json')
        assert r.status_code == 400

    def test_customer_cannot_delete_request(self):
        data = _post(self.client, self.eq).data
        r = self.client.delete(f"{REQ}{data['id']}/")
        assert r.status_code in (403, 404)
        assert InspectionRequest.objects.filter(id=data['id']).exists()


class TestAuthHardening(_Base):
    def test_suspended_account_blocked_by_jwt(self):
        from support.models import UserAccountSettings
        UserAccountSettings.objects.create(
            user=self.customer, is_suspended=True)
        cache.clear()
        token = str(RefreshToken.for_user(self.customer).access_token)
        c = APIClient()
        c.credentials(HTTP_AUTHORIZATION=f'Bearer {token}')
        assert c.get('/api/core/users/me/').status_code in (401, 403, 404)
        r = c.get(REQ)
        assert r.status_code == 401

    def test_password_change_revokes_refresh_tokens(self):
        from rest_framework_simplejwt.token_blacklist.models import (
            BlacklistedToken, OutstandingToken)
        from core.security import revoke_user_refresh_tokens
        RefreshToken.for_user(self.customer)
        RefreshToken.for_user(self.customer)
        revoke_user_refresh_tokens(self.customer)
        assert OutstandingToken.objects.filter(user=self.customer).count() == 2
        assert BlacklistedToken.objects.filter(
            token__user=self.customer).count() == 2


class TestProfileAndSupport(_Base):
    def test_two_users_without_phone_do_not_collide(self):
        u2 = User.objects.create_user(username='nophone2', password='x')
        UserProfile.objects.create(user=self.customer, phone='')
        UserProfile.objects.create(user=u2, phone='')   # قبلاً IntegrityError
        assert UserProfile.objects.filter(phone='').count() == 2

    def test_profile_duplicate_phone_is_400_not_500(self):
        other = User.objects.create_user(username='09128880001', password='x')
        UserProfile.objects.create(user=other, phone='09128880001')
        r = self.client.put('/api/core/customer/profile/',
                            {'phone': '09128880001'}, format='json')
        assert r.status_code == 400

    def test_saved_replies_hidden_from_customer(self):
        r = self.client.get('/api/support/saved-replies/')
        assert r.status_code in (403, 404)

    def test_contact_message_length_capped(self):
        r = APIClient().post('/api/public/contact-messages/', {
            'name': 'a', 'email': 'a@b.com', 'phone': '0912',
            'message': 'x' * 6000}, format='json')
        assert r.status_code == 400


class TestDiscountEdges36(_Base):
    def test_code_lookup_is_case_insensitive(self):
        data = self._make_request()
        url = f"{REQ}{data['id']}/apply-discount/"
        r = self.client.post(url, {'code': '  disc10 '}, format='json')
        assert r.status_code == 200, r.content

    def test_campaign_code_only_for_its_owner(self):
        from discounts.models import DiscountCampaign, DiscountCodeUsage
        owner = User.objects.create_user(username='09127770009', password='x')
        camp = DiscountCampaign.objects.create(
            name='c', condition_type='purchase_count', condition_value=1,
            discount_code_template=self.d10)
        DiscountCodeUsage.objects.create(
            user=owner, discount_code=self.d10, campaign=camp)
        data = self._make_request()
        url = f"{REQ}{data['id']}/apply-discount/"
        r = self.client.post(url, {'code': 'DISC10'}, format='json')
        assert r.status_code == 400

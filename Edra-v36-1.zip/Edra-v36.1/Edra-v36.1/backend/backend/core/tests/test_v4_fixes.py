# core/tests/test_v4_fixes.py
"""
تست‌های رگرسیون اصلاحات گزارش ممیزی EDRA v4 (P0):
- CRITICAL-02: بستن write endpointهای مدیریتی (Blog/FAQ/KB/Announcement/SavedReply)
- CRITICAL-01: read-only بودن فیلدهای workflow در update درخواست
- P0-03: state machine تغییر وضعیت (transition های غیرمجاز رد می‌شوند)
- HIGH-21: فیلد role صریح در UserSerializer (گروه Admin بدون is_staff → admin)
- HIGH-05: route blacklist ثبت شده است
- P0-08: ticket وب‌سوکت یکبارمصرف
"""
import os

import pytest
from django.contrib.auth import get_user_model
from django.contrib.auth.models import Group
from rest_framework.test import APIClient

from core.models import (
    AuditLog, EquipmentType, InspectionRequest,
)
from core.serializers import UserSerializer
from edra_jalalidate import to_jalali

User = get_user_model()
pytestmark = pytest.mark.django_db
PASSWORD = os.getenv("PASSWORD", "CHANGE_ME")


class _Base:
    def setup_method(self):
        self.client = APIClient()
        self.customer = User.objects.create_user(
            username="fix_customer", password=PASSWORD)
        self.expert = User.objects.create_user(
            username="fix_expert", password=PASSWORD)
        self.expert_group, _ = Group.objects.get_or_create(name='Expert')
        self.expert.groups.add(self.expert_group)

        self.admin_group, _ = Group.objects.get_or_create(name='Admin')
        self.group_admin = User.objects.create_user(
            username="fix_group_admin", password=PASSWORD, is_staff=False)
        self.group_admin.groups.add(self.admin_group)

        self.admin = User.objects.create_user(
            username="fix_admin", password=PASSWORD, is_staff=True)
        self.admin.groups.add(self.admin_group)

        self.admin_client = APIClient()
        self.admin_client.force_authenticate(user=self.admin)
        self.customer_client = APIClient()
        self.customer_client.force_authenticate(user=self.customer)
        self.expert_client = APIClient()
        self.expert_client.force_authenticate(user=self.expert)
        self.anon_client = APIClient()
        self.group_admin_client = APIClient()
        self.group_admin_client.force_authenticate(user=self.group_admin)

        self.eq = EquipmentType.objects.create(
            code='fix_eq', name_fa='تجهیز تست')
        self.request = InspectionRequest.objects.create(
            customer=self.customer,
            equipment_type=self.eq,
            city='تهران',
            address='تست',
            brand_model='م',
            calculated_price=1000000,
            final_price=1000000,
            status='pending_payment',
        )
        from guardian.shortcuts import assign_perm
        assign_perm('view_inspectionrequest', self.customer, self.request)
        assign_perm('change_inspectionrequest', self.customer, self.request)


class TestManagementWriteEndpointsClosed(_Base):
    CASES = [
        ('/api/public/blog-posts/', 'fix_blog'),
        ('/api/public/faqs/', 'fix_faq'),
        ('/api/support/knowledge-categories/', 'fix_kb_cat'),
        ('/api/support/knowledge-articles/', 'fix_kb_art'),
        ('/api/support/announcements/', 'fix_ann'),
        ('/api/support/saved-replies/', 'fix_saved'),
    ]

    def test_anonymous_post_denied(self):
        for url, _ in self.CASES:
            assert self.anon_client.post(url, {}).status_code in (401, 403)

    def test_customer_post_denied(self):
        for url, _ in self.CASES:
            assert self.customer_client.post(url, {}).status_code in (403, 400)

    def test_expert_post_denied(self):
        for url, _ in self.CASES:
            assert self.expert_client.post(url, {}).status_code in (403, 400)

    def test_admin_write_allowed(self):
        from public.models import BlogPost, FAQ
        from support.models import (
            KnowledgeBaseCategory, KnowledgeBaseArticle,
            Announcement, SavedReply)

        r = self.admin_client.post('/api/public/blog-posts/', {
            'title': 'پست تست', 'content': 'محتوا', 'is_published': False})
        assert r.status_code in (201, 400)
        r = self.admin_client.post('/api/public/faqs/', {
            'question': 'سوال', 'answer': 'جواب'})
        assert r.status_code in (201, 400)
        r = self.admin_client.post('/api/support/knowledge-categories/', {
            'name': 'دسته تست'})
        assert r.status_code in (201, 400)
        r = self.admin_client.post('/api/support/announcements/', {
            'title': 'اعلان تست', 'message': 'متن', 'audience': 'all'})
        assert r.status_code in (201, 400)
        r = self.admin_client.post('/api/support/saved-replies/', {
            'title': 'پاسخ تست', 'body': 'متن'})
        assert r.status_code in (201, 400)

    def test_group_admin_write_allowed(self):
        r = self.group_admin_client.post('/api/public/blog-posts/', {
            'title': 'پست گروهی', 'content': 'محتوا', 'is_published': False})
        assert r.status_code in (201, 400)


class TestInspectionRequestWorkflowProtected(_Base):
    def test_customer_cannot_change_status_via_patch(self):
        self.customer_client.patch(
            f'/api/core/inspection-requests/{self.request.id}/',
            {'status': 'completed'}, format='json')
        self.request.refresh_from_db()
        assert self.request.status == 'pending_payment'

    def test_customer_cannot_change_assigned_expert_via_patch(self):
        self.customer_client.patch(
            f'/api/core/inspection-requests/{self.request.id}/',
            {'assigned_expert': self.expert.id}, format='json')
        self.request.refresh_from_db()
        assert self.request.assigned_expert_id is None

    def test_customer_cannot_change_prices_via_patch(self):
        self.customer_client.patch(
            f'/api/core/inspection-requests/{self.request.id}/',
            {'final_price': 1, 'calculated_price': 1}, format='json')
        self.request.refresh_from_db()
        assert self.request.final_price == 1000000

    def test_customer_can_update_address(self):
        r = self.customer_client.patch(
            f'/api/core/inspection-requests/{self.request.id}/',
            {'address': 'آدرس جدید'}, format='json')
        assert r.status_code == 200
        self.request.refresh_from_db()
        assert self.request.address == 'آدرس جدید'

    def test_admin_cannot_change_status_via_patch(self):
        self.admin_client.patch(
            f'/api/core/inspection-requests/{self.request.id}/',
            {'status': 'paid'}, format='json')
        self.request.refresh_from_db()
        assert self.request.status == 'pending_payment'


class TestStatusTransitionGuard(_Base):
    def _change(self, client, new_status):
        return client.post(
            f'/api/core/inspection-requests/{self.request.id}/change_status/',
            {'status': new_status}, format='json')

    def test_valid_transition_pending_to_waiting_manual(self):
        r = self._change(self.admin_client, 'waiting_manual_payment')
        assert r.status_code == 200
        self.request.refresh_from_db()
        assert self.request.status == 'waiting_manual_payment'

    def test_invalid_transition_draft_to_completed(self):
        self.request.status = 'draft'
        self.request.save()
        r = self._change(self.admin_client, 'completed')
        assert r.status_code == 400

    def test_invalid_transition_paid_to_cancelled_direct(self):
        self.request.status = 'paid'
        self.request.save()
        r = self._change(self.admin_client, 'completed')
        assert r.status_code == 400

    def test_customer_cannot_change_status(self):
        r = self._change(self.customer_client, 'paid')
        assert r.status_code == 403

    def test_audit_log_written_on_valid_change(self):
        self._change(self.admin_client, 'waiting_manual_payment')
        assert AuditLog.objects.filter(
            action='change_status',
            object_id=self.request.id).exists()


class TestCanonicalRole(_Base):
    def test_group_admin_role_is_admin(self):
        data = UserSerializer(self.group_admin).data
        assert data['role'] == 'admin'

    def test_staff_admin_role_is_admin(self):
        data = UserSerializer(self.admin).data
        assert data['role'] == 'admin'

    def test_expert_role_is_expert(self):
        data = UserSerializer(self.expert).data
        assert data['role'] == 'expert'

    def test_customer_role_is_customer(self):
        data = UserSerializer(self.customer).data
        assert data['role'] == 'customer'

    def test_me_endpoint_returns_role_for_group_admin(self):
        r = self.group_admin_client.get('/api/core/users/me/')
        assert r.status_code == 200
        assert r.data['role'] == 'admin'


class TestLogoutBlacklist(_Base):
    def test_blacklist_route_exists(self):
        r = self.anon_client.post(
            '/api/token/blacklist/',
            {'refresh': 'invalid.token.here'}, format='json')
        assert r.status_code in (400, 401)

    def test_logout_revokes_refresh_token(self):
        from rest_framework_simplejwt.tokens import RefreshToken
        refresh = RefreshToken.for_user(self.customer)
        r = self.anon_client.post(
            '/api/token/blacklist/',
            {'refresh': str(refresh)}, format='json')
        assert r.status_code in (200, 205)
        r2 = self.anon_client.post(
            '/api/token/refresh/', {'refresh': str(refresh)}, format='json')
        assert r2.status_code == 401


class TestWsTicketEndpoint(_Base):
    def test_ticket_issued(self):
        r = self.customer_client.post('/api/notifications/ws-ticket/')
        assert r.status_code == 200
        assert r.data['ticket']
        assert r.data['expires_in'] == 60

    def test_ticket_requires_auth(self):
        r = self.anon_client.post('/api/notifications/ws-ticket/')
        assert r.status_code in (401, 403)

    def test_ticket_single_use(self):
        from django.core.cache import cache
        r = self.customer_client.post('/api/notifications/ws-ticket/')
        ticket = r.data['ticket']
        assert cache.get(f'ws_ticket_{ticket}') == self.customer.id
        from edra.ws_auth import _consume_ticket
        assert _consume_ticket(ticket) == self.customer.id
        assert _consume_ticket(ticket) is None
# core/tests/test_v5_fixes.py
"""
تست‌های رگرسیون اصلاحات گزارش ممیزی EDRA v5 (P0ها):
- CRITICAL-06/07/44: ثبت چک‌لیست — کامل‌بودن آیتم‌ها، foreign item، result،
  required note/photo، overall server-derived
- CRITICAL-08: signed_by/signed_at هنگام submit خالی است
- CRITICAL-09: PATCH عمومی گزارش محدود؛ گزارش نهایی/امضاشده تغییر نمی‌کند
- CRITICAL-10: فیلدهای business بعد از پرداخت immutable
- CRITICAL-13/14: کامنت داخلی تیکت فقط Support/Admin (ساخت + نمایش)
- HIGH-12: workflow تیکت فقط Support/Admin
- HIGH-16: organization پروژه سرور-محور
- HIGH-19: ایمپورت اکسل — dedupe + mode replace
- HIGH-29: یکتایی ledger در database
- HIGH-37: cooldown OTP
"""
import io
import os
import json

import pytest
from django.contrib.auth import get_user_model
from django.contrib.auth.models import Group
from django.core.files.uploadedfile import SimpleUploadedFile
from django.core.cache import cache
from openpyxl import Workbook
from rest_framework.test import APIClient

from core.models import (
    AuditLog, ChecklistItem, ChecklistPhoto, ChecklistTemplate,
    EquipmentType, InspectionReport, InspectionRequest, LedgerEntry,
    Payment, PaymentMethod, Project, Organization, UserCredit,
)
from support.models import (
    Ticket, TicketComment, TicketStatus,
    TicketDepartment, TicketPriority, TicketCategory,
)
from core.services.ledger_service import record_settlement
from core.validators import validate_excel_file
from edra_jalalidate import to_jalali

User = get_user_model()
def _cat(name):
    """ChecklistItem.category یک FK است؛ رشته‌ی نام را به رکورد تبدیل می‌کند."""
    from core.models import ChecklistCategory
    return ChecklistCategory.objects.get_or_create(name=name)[0]


pytestmark = pytest.mark.django_db
PASSWORD = os.getenv("PASSWORD", "CHANGE_ME")


class Base:
    def setup_method(self):
        self.customer = User.objects.create_user(
            username="v5_customer", password=PASSWORD)
        self.expert = User.objects.create_user(
            username="v5_expert", password=PASSWORD)
        g, _ = Group.objects.get_or_create(name='Expert')
        self.expert.groups.add(g)
        self.support_user = User.objects.create_user(
            username="v5_support", password=PASSWORD)
        sg, _ = Group.objects.get_or_create(name='Support')
        self.support_user.groups.add(sg)
        self.admin = User.objects.create_user(
            username="v5_admin", password=PASSWORD, is_staff=True)

        self.customer_c = APIClient()
        self.customer_c.force_authenticate(user=self.customer)
        self.expert_c = APIClient()
        self.expert_c.force_authenticate(user=self.expert)
        self.support_c = APIClient()
        self.support_c.force_authenticate(user=self.support_user)
        self.admin_c = APIClient()
        self.admin_c.force_authenticate(user=self.admin)

        self.eq = EquipmentType.objects.create(
            code='v5_eq', name_fa='تاور کرین')
        self.template = ChecklistTemplate.objects.create(
            equipment_type=self.eq, name='چک‌لیست v5', version=1)
        self.item1 = ChecklistItem.objects.create(
            checklist_template=self.template, category=_cat('سازه'),
            title='جوش‌ها', order=1)
        self.item2 = ChecklistItem.objects.create(
            checklist_template=self.template, category=_cat('بالابری'),
            title='سیم بکسل', order=2, requires_photo=True)
        self.item3 = ChecklistItem.objects.create(
            checklist_template=self.template, category=_cat('سازه'),
            title='پیچ‌ها', order=3, requires_note=True)

        self.task = InspectionRequest.objects.create(
            customer=self.customer,
            assigned_expert=self.expert,
            equipment_type=self.eq,
            city='تهران',
            address='آدرس تست',
            brand_model='تست',
            calculated_price=2000000,
            final_price=2000000,
            status='in_progress',
        )
        from guardian.shortcuts import assign_perm
        assign_perm('view_inspectionrequest', self.customer, self.task)
        assign_perm('change_inspectionrequest', self.customer, self.task)

    def _results(self, **overrides):
        base = [
            {'item_id': self.item1.id, 'result': 'pass', 'note': ''},
            {'item_id': self.item2.id, 'result': 'pass', 'note': ''},
            {'item_id': self.item3.id, 'result': 'pass', 'note': 'یادداشت'},
        ]
        out = []
        for b in base:
            b = dict(b)
            out.append({'item_id': b['item_id'], 'result': b['result'],
                        'note': b['note']})
        for key, val in overrides.items():
            if key == 'items':
                return val
            if key == 'item1_result':
                out[0]['result'] = val
            if key == 'item3_note':
                out[2]['note'] = val
            if key == 'remove_item3':
                out = [o for o in out if o['item_id'] != self.item3.id]
        return out

    @staticmethod
    def _make_jpeg():
        from PIL import Image
        buf = io.BytesIO()
        Image.new('RGB', (8, 8), color=(200, 50, 50)).save(
            buf, format='JPEG', quality=60)
        buf.seek(0)
        return SimpleUploadedFile('photo.jpg', buf.read(),
                                  content_type='image/jpeg')

    def _submit(self, client, results, with_photo=True, **extra):
        data = {
            'request_id': str(self.task.id),
            'results': json.dumps(results),
            'inspector_notes': 'یادداشت کلی',
            'overall_result': 'pass',
            'gps_start_lat': '35.7', 'gps_start_lng': '51.4',
            'gps_end_lat': '35.7', 'gps_end_lng': '51.4',
        }
        data.update(extra)
        if with_photo:
            data[f'photo_{self.item2.id}_0'] = self._make_jpeg()
        return client.post('/api/expert/submit-checklist/', data)


class TestChecklistSubmitIntegrity(Base):
    def test_complete_submission_ok(self):
        r = self._submit(self.expert_c, self._results())
        assert r.status_code == 200, r.content[:300]
        report = InspectionReport.objects.get(
            inspection_request=self.task)
        assert report.overall_result == 'pass'
        assert report.checklist_template_version_id == self.template.id
        assert report.signed_by_id is None
        assert report.signed_at is None
        self.task.refresh_from_db()
        assert self.task.status == 'completed'

    def test_missing_item_rejected(self):
        r = self._submit(self.expert_c, self._results(remove_item3=True))
        assert r.status_code == 400
        assert 'ناقص' in r.data.get('error', '')

    def test_foreign_item_rejected(self):
        other_eq = EquipmentType.objects.create(code='v5_other', name_fa='آسانسور')
        other_tmpl = ChecklistTemplate.objects.create(
            equipment_type=other_eq, name='قالب دیگر', version=1)
        other = ChecklistItem.objects.create(
            checklist_template=other_tmpl, category=_cat('x'),
            title='خارجی', order=1)
        results = self._results() + [
            {'item_id': other.id, 'result': 'pass', 'note': ''}]
        r = self._submit(self.expert_c, results)
        assert r.status_code == 400
        assert 'نامعتبر' in r.data.get('error', '')

    def test_duplicate_item_rejected(self):
        results = self._results()
        results.append(dict(results[0]))
        r = self._submit(self.expert_c, results)
        assert r.status_code == 400
        assert 'دوباره' in r.data.get('error', '')

    def test_invalid_result_rejected(self):
        r = self._submit(self.expert_c, self._results(item1_result='maybe'))
        assert r.status_code == 400

    def test_required_note_enforced(self):
        r = self._submit(self.expert_c, self._results(item3_note=''))
        assert r.status_code == 400
        assert 'یادداشت' in r.data.get('error', '')

    def test_required_photo_enforced(self):
        r = self._submit(self.expert_c, self._results(), with_photo=False)
        assert r.status_code == 400
        assert 'عکس' in r.data.get('error', '')

    def test_fail_leads_to_overall_fail(self):
        r = self._submit(self.expert_c, self._results(item1_result='fail'))
        assert r.status_code == 200
        report = InspectionReport.objects.get(
            inspection_request=self.task)
        assert report.overall_result == 'fail'

    def test_customer_cannot_submit(self):
        r = self._submit(self.customer_c, self._results())
        assert r.status_code == 404

    def test_unanswered_default_pass_impossible(self):
        results = [
            {'item_id': self.item1.id, 'result': 'pass', 'note': ''},
            {'item_id': self.item2.id, 'result': 'pass', 'note': ''},
        ]
        r = self._submit(self.expert_c, results, with_photo=False)
        assert r.status_code == 400


class TestReportMutationGuard(Base):
    def _make_report(self):
        self._submit(self.expert_c, self._results())
        return InspectionReport.objects.get(inspection_request=self.task)

    def test_patch_cannot_change_results(self):
        report = self._make_report()
        r = self.expert_c.patch(
            f'/api/inspections/inspection-reports/{report.id}/',
            {'overall_result': 'fail', 'results': []}, format='json')
        assert r.status_code == 200
        report.refresh_from_db()
        assert report.overall_result == 'pass'

    def test_signed_report_not_editable(self):
        report = self._make_report()
        from django.utils import timezone as tz
        report.signed_at = tz.now()
        report.signed_by = self.expert
        report.save()
        r = self.expert_c.patch(
            f'/api/inspections/inspection-reports/{report.id}/',
            {'inspector_notes': 'x'}, format='json')
        assert r.status_code in (403, 405)


class TestRequestImmutabilityAfterPaid(Base):
    def test_business_fields_locked_after_paid(self):
        self.task.status = 'paid'
        self.task.save()
        r = self.customer_c.patch(
            f'/api/core/inspection-requests/{self.task.id}/',
            {'equipment_type': self.eq.id, 'city': 'اصفهان'},
            format='json')
        assert r.status_code == 400
        assert 'قابل تغییر نیست' in json.dumps(r.data, ensure_ascii=False)
        self.task.refresh_from_db()
        assert self.task.city == 'تهران'

    def test_input_fields_editable_before_paid(self):
        self.task.status = 'pending_payment'
        self.task.save()
        r = self.customer_c.patch(
            f'/api/core/inspection-requests/{self.task.id}/',
            {'address': 'آدرس جدید'}, format='json')
        assert r.status_code == 200
        self.task.refresh_from_db()
        assert self.task.address == 'آدرس جدید'


class TestTicketAuthorization(Base):
    def _make_ticket(self, creator=None):
        status = TicketStatus.objects.create(name='باز')
        prio = TicketPriority.objects.create(name='متوسط', weight=1)
        cat = TicketCategory.objects.create(name='عمومی')
        dept = TicketDepartment.objects.create(name='پشتیبانی')
        return Ticket.objects.create(
            customer=creator or self.customer,
            title='تیکت تست',
            description='توضیحات تست',
            status=status,
            priority=prio,
            category=cat,
            department=dept,
        )

    def test_customer_cannot_change_status(self):
        t = self._make_ticket()
        status2 = TicketStatus.objects.create(name='بسته')
        r = self.customer_c.post(
            f'/api/support/tickets/{t.id}/change_status/',
            {'status_id': status2.id}, format='json')
        assert r.status_code == 403

    def test_support_can_change_status(self):
        t = self._make_ticket()
        status2 = TicketStatus.objects.create(name='بسته')
        r = self.support_c.post(
            f'/api/support/tickets/{t.id}/change_status/',
            {'status_id': status2.id}, format='json')
        assert r.status_code == 200

    def test_customer_cannot_create_internal_comment(self):
        t = self._make_ticket()
        r = self.customer_c.post(
            f'/api/support/tickets/{t.id}/add_comment/',
            {'content': 'متن', 'is_internal': True}, format='json')
        assert r.status_code == 403

    def test_support_can_create_internal_comment(self):
        t = self._make_ticket()
        r = self.support_c.post(
            f'/api/support/tickets/{t.id}/add_comment/',
            {'content': 'داخلی', 'is_internal': True}, format='json')
        assert r.status_code == 201

    def test_customer_cannot_see_internal_comments(self):
        t = self._make_ticket()
        TicketComment.objects.create(
            ticket=t, user=self.support_user,
            content='راز داخلی', is_internal=True)
        TicketComment.objects.create(
            ticket=t, user=self.support_user,
            content='کامنت عمومی', is_internal=False)
        r = self.customer_c.get(f'/api/support/tickets/{t.id}/')
        assert r.status_code == 200
        comments = r.data.get('comments', [])
        contents = [c['content'] for c in comments]
        assert 'راز داخلی' not in contents
        assert 'کامنت عمومی' in contents

    def test_support_sees_internal_comments(self):
        t = self._make_ticket()
        TicketComment.objects.create(
            ticket=t, user=self.support_user,
            content='راز داخلی', is_internal=True)
        r = self.support_c.get(f'/api/support/tickets/{t.id}/')
        comments = r.data.get('comments', [])
        assert any(c['content'] == 'راز داخلی' for c in comments)

    def test_patch_ticket_cannot_change_status(self):
        t = self._make_ticket()
        status2 = TicketStatus.objects.create(name='بسته')
        r = self.customer_c.patch(
            f'/api/support/tickets/{t.id}/',
            {'status': status2.id, 'priority': t.priority_id},
            format='json')
        t.refresh_from_db()
        assert t.status.name == 'باز'


class TestProjectOwnership(Base):
    def test_customer_project_org_forced(self):
        org = Organization.objects.create(name='سازمان تست')
        org.billing_contact = self.customer
        org.save()
        other = Organization.objects.create(name='سازمان دیگر')
        r = self.customer_c.post(
            '/api/core/projects/',
            {'name': 'پروژه تست', 'organization': other.id}, format='json')
        if r.status_code == 201:
            p = Project.objects.get(name='پروژه تست')
            assert p.organization_id == org.id


class TestExcelImportV5(Base):
    def _xlsx(self, rows, headers=None):
        headers = headers or [
            'دسته‌بندی', 'عنوان', 'توضیحات', 'ترتیب',
            'نیاز به عکس', 'نیاز به یادداشت']
        wb = Workbook()
        ws = wb.active
        ws.append(headers)
        for row in rows:
            ws.append(row)
        buf = io.BytesIO()
        wb.save(buf)
        buf.seek(0)
        return SimpleUploadedFile(
            't.xlsx', buf.read(),
            content_type='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')

    def _import(self, xlsx, mode='append', preview=False):
        url = (f'/api/inspections/checklist-templates/{self.template.id}/'
               f'import-items/?mode={mode}'
               + ('&preview=true' if preview else ''))
        return self.admin_c.post(url, {'file': xlsx}, format='multipart')

    def test_duplicate_rows_rejected(self):
        xlsx = self._xlsx([
            ['سازه', 'آیتم الف', '', 1, 'بله', 'خیر'],
            ['سازه', 'آیتم الف', '', 2, 'بله', 'خیر'],
        ])
        r = self._import(xlsx)
        assert r.status_code == 200
        assert r.data['created_count'] == 1
        assert any('تکراری' in e['error'] for e in r.data['errors'])

    def test_duplicate_orders_rejected(self):
        xlsx = self._xlsx([
            ['سازه', 'آیتم ۱', '', 5, 'بله', 'خیر'],
            ['سازه', 'آیتم ۲', '', 5, 'بله', 'خیر'],
        ])
        r = self._import(xlsx)
        assert r.data['created_count'] == 1

    def test_negative_order_rejected(self):
        xlsx = self._xlsx([
            ['سازه', 'آیتم', '', -3, 'بله', 'خیر'],
        ])
        r = self._import(xlsx)
        assert r.status_code == 400
        assert any('منفی' in e['error'] for e in r.data.get('errors', []))

    def test_invalid_boolean_rejected(self):
        xlsx = self._xlsx([
            ['سازه', 'آیتم', '', 1, 'شاید', 'خیر'],
        ])
        r = self._import(xlsx)
        assert r.status_code == 400
        assert any('boolean' in e['error'] for e in r.data.get('errors', []))

    def test_mode_replace_removes_old(self):
        ChecklistItem.objects.create(
            checklist_template=self.template, category=_cat('قدیمی'),
            title='آیتم قدیمی', order=1)
        xlsx = self._xlsx([
            ['جدید', 'آیتم جدید', '', 1, 'بله', 'خیر'],
        ])
        r = self._import(xlsx, mode='replace')
        assert r.status_code == 200
        assert r.data['created_count'] == 1
        assert ChecklistItem.objects.filter(
            checklist_template=self.template, is_active=True).count() == 1
        assert ChecklistItem.objects.filter(
            checklist_template=self.template, title='آیتم قدیمی',
            is_active=True).count() == 0

    def test_preview_reports_duplicate_with_existing(self):
        ChecklistItem.objects.create(
            checklist_template=self.template, category=_cat('سازه'),
            title='تکرار', order=1)
        xlsx = self._xlsx([
            ['سازه', 'تکرار', '', 2, 'بله', 'خیر'],
            ['سازه', 'جدید', '', 3, 'بله', 'خیر'],
        ])
        r = self._import(xlsx, preview=True)
        assert r.status_code == 200
        assert r.data['duplicate_with_existing'] == 1

    def test_renamed_zip_rejected(self):
        import zipfile
        buf = io.BytesIO()
        with zipfile.ZipFile(buf, 'w') as zf:
            zf.writestr('some.txt', 'not excel')
        buf.seek(0)
        fake = SimpleUploadedFile(
            'fake.xlsx', buf.read(), content_type='application/zip')
        assert validate_excel_file(fake) is not None


class TestLedgerUniqueness(Base):
    def test_duplicate_settlement_constraint(self):
        method = PaymentMethod.objects.create(name='online')
        pay = Payment.objects.create(
            inspection_request=self.task,
            amount=1000, amount_rial=10000,
            online_amount=1000,
            method=method, status='pending')
        first = record_settlement(pay)
        second = record_settlement(pay)
        assert first is not None
        assert second is None
        assert LedgerEntry.objects.filter(
            payment=pay, entry_type='settlement').count() == 1


class TestOtpCooldown(Base):
    def test_second_request_throttled(self):
        cache.clear()
        r1 = self.admin_c.post(
            '/api/core/otp/request/', {'phone': '09120001111'},
            format='json')
        assert r1.status_code == 200
        r2 = self.admin_c.post(
            '/api/core/otp/request/', {'phone': '09120001111'},
            format='json')
        assert r2.status_code == 429
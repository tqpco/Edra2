# core/tests/test_v7_fixes.py
"""
تست‌های رگرسیون اصلاحات گزارش بازرسی عمیق EDRA v7:
- SEC-01 (P0): Stored XSS در Admin — payment_details_display باید مقدار
  مخرب را escape کند (format_html) نه اینکه با mark_safe بگذارد.
- SEC-02 (P1): logout سفارشی فقط POST و CSRF-protected (GET → 405).
- PERF-01 (P1): view_count با F() اتمیک افزایش می‌یابد.
- PERF-01 (P1): N+1 — آخرین پرداخت بدون کوئری اضافه (Prefetch).
"""
import os

import pytest
from django.contrib.auth import get_user_model
from django.core.cache import cache
from django.utils.html import escape
from rest_framework.test import APIClient

from core.admin.request import InspectionRequestAdmin
from core.models import (
    EquipmentType, InspectionRequest, Payment, PaymentMethod,
    ReportVerification, InspectionReport,
)
from edra_jalalidate import to_jalali

User = get_user_model()
pytestmark = pytest.mark.django_db
PASSWORD = os.getenv("PASSWORD", "CHANGE_ME")


class Base:
    def setup_method(self):
        cache.clear()
        self.admin = User.objects.create_user(
            username="v7_admin", password=PASSWORD, is_staff=True)
        self.admin.set_password(PASSWORD)
        self.admin.is_superuser = True
        self.admin.save()
        self.customer = User.objects.create_user(
            username="v7_cust", password=PASSWORD)

        self.eq = EquipmentType.objects.create(code='v7_eq', name_fa='تجهیز')
        self.task = InspectionRequest.objects.create(
            customer=self.customer,
            equipment_type=self.eq,
            city='تهران', address='آدرس', brand_model='تست',
            calculated_price=1000000, final_price=1000000,
            status='pending_payment',
        )
        self.method = PaymentMethod.objects.create(name='آنلاین')


class TestAdminXss(Base):
    def test_payment_details_escapes_malicious_values(self):
        payload = '"><script>alert(1)</script>'
        pay = Payment.objects.create(
            inspection_request=self.task,
            amount=1000, amount_rial=10000,
            online_amount=1000,
            method=self.method, status='paid',
            transaction_id=payload,
        )
        admin = InspectionRequestAdmin(InspectionRequest, None)
        from django.db.models import Prefetch
        qs = InspectionRequest.objects.prefetch_related(
            Prefetch('payments',
                     queryset=Payment.objects.select_related('method')
                     .order_by('-created_at'),
                     to_attr='payments_ordered'))
        obj = qs.get(pk=self.task.pk)
        html = admin.payment_details_display(obj)
        assert '<script>alert(1)</script>' not in html
        assert escape(payload) in html

    def test_payment_status_escapes_method_name(self):
        payload = '<img src=x onerror=alert(1)>'
        evil_method = PaymentMethod.objects.create(name=payload)
        Payment.objects.create(
            inspection_request=self.task,
            amount=1000, amount_rial=10000,
            online_amount=1000,
            method=evil_method, status='paid',
        )
        admin = InspectionRequestAdmin(InspectionRequest, None)
        from django.db.models import Prefetch
        qs = InspectionRequest.objects.prefetch_related(
            Prefetch('payments',
                     queryset=Payment.objects.select_related('method')
                     .order_by('-created_at'),
                     to_attr='payments_ordered'))
        obj = qs.get(pk=self.task.pk)
        html = admin.payment_status_display(obj)
        assert '<img src=x' not in html
        assert escape(payload) in html


class TestLogoutPostOnly(Base):
    def test_logout_get_rejected(self):
        client = APIClient()
        client.force_login(self.admin)
        r = client.get('/admin/logout/')
        assert r.status_code == 405

    def test_logout_post_without_csrf_rejected(self):
        from django.test import Client as DjangoClient
        c = DjangoClient(enforce_csrf_checks=True)
        c.force_login(self.admin)
        r = c.post('/admin/logout/')
        assert r.status_code == 403

    def test_logout_post_with_csrf_works(self):
        from django.test import Client as DjangoClient
        c = DjangoClient(enforce_csrf_checks=True)
        c.force_login(self.admin)
        token = c.get('/admin/').cookies.get('csrftoken')
        r = c.post('/admin/logout/', HTTP_X_CSRFTOKEN=token.value)
        assert r.status_code in (302, 200)


class TestVerificationViewCount(Base):
    def _make_verification(self):
        report = InspectionReport.objects.create(
            inspection_request=self.task,
            report_number='R-V7-00001',
            results=[], overall_result='pass')
        return ReportVerification.objects.create(
            report=report,
            verification_code='V7TESTCODE01')

    def test_view_count_atomic_increment(self):
        v = self._make_verification()
        self.client = APIClient()
        for _ in range(3):
            r = self.client.get(
                f'/api/inspections/report-verification/{v.verification_code}/')
            assert r.status_code == 200
        v.refresh_from_db()
        assert v.view_count == 3
# core/tests/test_views.py
import pytest
import os
from django.contrib.auth import get_user_model
from django.contrib.auth.models import Group
from rest_framework.test import APIClient
from core.models import EquipmentType, InspectionRequest
from edra_jalalidate import to_jalali

User = get_user_model()

pytestmark = pytest.mark.django_db


class TestInspectionRequestAPI:
    def setup_method(self):
        self.client = APIClient()
        self.user = User.objects.create_user(
            username="testuser", password=os.getenv(
                "PASSWORD", "CHANGE_ME"))
        self.eq = EquipmentType.objects.create(
            name_fa="تست",
            code="TEST",
            param_schema={}
        )
        self.admin = User.objects.create_superuser(
            username="admin", password=os.getenv(
                "PASSWORD", "CHANGE_ME"))
        admin_group, _ = Group.objects.get_or_create(name="Admin")
        self.admin.groups.add(admin_group)

    def test_create_request_unauthenticated(self):
        response = self.client.post(
            "/api/core/inspection-requests/",
            {
                "city": "تهران",
                "address": "خیابان تست، پلاک ۱۲۳",
                "equipment_type": self.eq.id,
                "brand_model": "مدل تست",
                "manufacture_year": 1400,
                "params": {},
                "install_state": "installed",
                "phone": "09123456789",
            },
            format='json'
        )
        assert response.status_code == 201, f"Response data: {response.data}"

    def test_list_requests_authenticated(self):
        InspectionRequest.objects.create(
            customer=self.user,
            equipment_type=self.eq,
            city="تهران",
            address="خیابان تست",
            final_price=1000000,
            calculated_price=1000000,
            status="pending_payment"
        )
        self.client.force_authenticate(user=self.user)
        response = self.client.get("/api/core/inspection-requests/")
        assert response.status_code == 200
        assert len(response.data) >= 1

    def test_assign_expert_admin_only(self):
        expert = User.objects.create_user(
            username="expert", password=os.getenv(
                "PASSWORD", "CHANGE_ME"))
        request_obj = InspectionRequest.objects.create(
            customer=self.user,
            equipment_type=self.eq,
            city="تهران",
            address="خیابان تست",
            final_price=1000000,
            calculated_price=1000000,
            status="pending_payment"
        )
        self.client.force_authenticate(user=self.user)
        response = self.client.post(f"/api/core/inspection-requests/{request_obj.id}/assign_expert/", {
            "expert_id": expert.id
        })
        assert response.status_code == 403

        self.client.force_authenticate(user=self.admin)
        response = self.client.post(f"/api/core/inspection-requests/{request_obj.id}/assign_expert/", {
            "expert_id": expert.id
        })
        assert response.status_code == 200
        request_obj.refresh_from_db()
        assert request_obj.assigned_expert == expert
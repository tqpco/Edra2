# core/urls.py
# ✅ فایل کامل و اصلاح‌شده - تمام مسیرها + پرداخت زرین‌پال + پروفایل + کدهای تخفیف مشتری + رد فیش

from django.urls import path, include
from rest_framework.routers import DefaultRouter
from .views.audit_views import (
    ErrorLogViewSet, AuditLogViewSet
)
from .views.common_views import (
    EquipmentTypeViewSet, CityMultiplierViewSet, OrganizationViewSet,
    ProjectViewSet, OTPRequestView, OTPVerifyView, CurrentUserView,
    DebugView, ajax_delete_parameter, EquipmentParameterViewSet,
)
from .views.ntp_views import ntp_time_view
# EDRA v32 — نظافت: generate_invoice_pdf (از base_views) و generate_report_pdf
# (از pdf_views) اینجا import می‌شدند ولی به هیچ path متصل نبودند (کد مرده؛
# endpoint واقعی دانلود PDF برای هر دو، یک @action امن روی ViewSet مربوطه
# است: InvoiceViewSet.pdf و InspectionReportViewSet.pdf — هر دو جداگانه
# بررسی و تأیید شدند). حذف این دو import هیچ رفتاری را تغییر نمی‌دهد.
from .views.credit_views import (
    UserCreditViewSet, CreditTransactionViewSet,
    request_credit_deposit, upload_deposit_receipt,
    verify_deposit_payment, reject_payment,
)
from .views.dashboard_views import (
    AdminDashboardStatsView, CustomerDashboardView, CustomerRequestsView,
    CustomerReportsView, ExpertDashboardView
)
from .views.discount_views import (
    DiscountCodeViewSet, CustomerDiscountCodeViewSet, ValidateDiscountCodeView
)
from .views.inspection_views import (
    InspectionRequestViewSet
)
from .views.notification_views import (
    NotificationViewSet
)
from .views.payment_views import (
    PaymentMethodViewSet, PaymentViewSet, InvoiceViewSet,
    initiate_payment, payment_callback, refund_payment, payment_receipt,
)
from .views.profile_views import (
    CustomerProfileView, ExpertProfileView, CustomerCreditView
)
from .views.user_views import (
    UserViewSet
)
from .views.report_views import (
    AdminCustomerFullReportView,
    AdminFinancialReportView,
    AdminInspectionReportView,
)

app_name = "core"
router = DefaultRouter()

# EDRA v27 — رفع باگ ریشه‌ای (گزارش کاربر، سپتامبر ۲۰۲۶): این ViewSet
# تعریف شده بود ولی هرگز به router ثبت نشده بود؛ در نتیجه صفحه‌ی ادمین
# equipment/[id]/edit هنگام افزودن/ویرایش/حذف پارامتر همیشه ۴۰۴ می‌گرفت.
router.register(r'parameters', EquipmentParameterViewSet, basename='equipment_parameters')
router.register(r'equipment-types', EquipmentTypeViewSet, basename='equipment_types')
router.register(r'city-multipliers', CityMultiplierViewSet, basename='city_multipliers')
router.register(r'inspection-requests', InspectionRequestViewSet, basename='inspection_requests')
router.register(r'users', UserViewSet, basename='users')
router.register(r'payment-methods', PaymentMethodViewSet, basename='payment_methods')
router.register(r'payments', PaymentViewSet, basename='payments')
router.register(r'invoices', InvoiceViewSet, basename='invoices')
router.register(r'organizations', OrganizationViewSet, basename='organizations')
router.register(r'projects', ProjectViewSet, basename='projects')
router.register(r'credit', UserCreditViewSet, basename='credit')
router.register(r'credit-transactions', CreditTransactionViewSet, basename='credit_transactions')
router.register(r'discount-codes', DiscountCodeViewSet, basename='discount_codes')
router.register(r'error-logs', ErrorLogViewSet, basename='error_logs')
router.register(r'audit-logs', AuditLogViewSet, basename='audit_logs')
router.register(r'customer/discount-codes', CustomerDiscountCodeViewSet, basename='customer_discount_codes')

urlpatterns = [
    path('users/me/', CurrentUserView.as_view(), name='current_user'),
    path('admin/dashboard-stats/', AdminDashboardStatsView.as_view(), name='admin_dashboard_stats'),
    path('customer/dashboard/', CustomerDashboardView.as_view(), name='customer_dashboard'),
    path('expert/dashboard/', ExpertDashboardView.as_view(), name='expert_dashboard'),
    path('customer/requests/', CustomerRequestsView.as_view(), name='customer_requests'),
    path('customer/reports/', CustomerReportsView.as_view(), name='customer_reports'),
    path('admin/customers/<int:customer_id>/full-report/', AdminCustomerFullReportView.as_view(), name='admin_customer_full_report'),
    path('admin/reports/financial/', AdminFinancialReportView.as_view(), name='admin_financial_report'),
    path('admin/reports/inspections/', AdminInspectionReportView.as_view(), name='admin_inspection_report'),
    path('customer/profile/', CustomerProfileView.as_view(), name='customer_profile'),
    path('otp/request/', OTPRequestView.as_view(), name='otp_request'),
    path('otp/verify/', OTPVerifyView.as_view(), name='otp_verify'),
    # EDRA v27: ساعت دقیق سرور (NTP-synced) برای تقویم جلالی — قبلاً
    # ثبت نشده بود، فرانت‌اند همیشه به ساعت محلی مرورگر برمی‌گشت.
    path('ntp-time/', ntp_time_view, name='ntp_time'),
    path('credit/deposit/', request_credit_deposit, name='credit_deposit'),
    path('credit/upload-receipt/', upload_deposit_receipt, name='upload_receipt'),
    path('credit/verify/<int:payment_id>/', verify_deposit_payment, name='verify_deposit'),
    path('credit/reject/<int:payment_id>/', reject_payment, name='reject_payment'),
    path('notifications/', NotificationViewSet.as_view({'get': 'list'}), name='notifications'),
    path('notifications/unread_count/', NotificationViewSet.as_view({'get': 'unread_count'}), name='notification-unread-count'),
    path('notifications/<int:pk>/', NotificationViewSet.as_view({'get': 'retrieve'}), name='notification-detail'),
    path('notifications/<int:pk>/mark_read/', NotificationViewSet.as_view({'post': 'mark_read'}), name='notification-mark-read'),
    path('notifications/mark_all_read/', NotificationViewSet.as_view({'post': 'mark_all_read'}), name='notification-mark-all-read'),
    path('payment/initiate/', initiate_payment, name='initiate_payment'),
    path('payment/callback/', payment_callback, name='payment_callback'),
    path('payment/refund/<int:payment_id>/', refund_payment, name='payment_refund'),
    path('payments/<int:payment_id>/receipt/', payment_receipt, name='payment_receipt'),
    path('expert/profile/', ExpertProfileView.as_view(), name='expert_profile'),
    path('customer/credit/', CustomerCreditView.as_view(), name='customer_credit'),
    path('discount-codes/validate/', ValidateDiscountCodeView.as_view(), name='validate_discount_code'),
    path('debug/', DebugView.as_view(), name='debug'),
    path('', include(router.urls)),
    path('ajax/delete-parameter/<int:pk>/', ajax_delete_parameter, name='ajax_delete_parameter'),
]
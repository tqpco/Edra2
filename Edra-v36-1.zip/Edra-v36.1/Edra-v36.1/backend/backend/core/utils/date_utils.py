"""
توابع کمکی برای تبدیل تاریخ به شمسی (Jalali)
با پشتیبانی از fields مختلف مثل created_at, updated_at, ...
این فایل اکنون از پکیج edra_jalalidate استفاده می‌کند.
"""

import datetime
from edra_jalalidate import to_jalali as _to_jalali


def to_jalali(dt, fmt="%Y/%m/%d %H:%M"):
    """
    تبدیل datetime به رشته شمسی با فرمت دلخواه.
    اگر ورودی None باشد، None برگردانده می‌شود.
    اگر ورودی datetime یا date باشد، به جلالی تبدیل می‌شود.
    در غیر این صورت، همان ورودی به رشته تبدیل می‌شود.
    """
    if dt is None:
        return None
    # اگر datetime یا date باشد، از edra_jalalidate استفاده کن
    if isinstance(dt, (datetime.datetime, datetime.date)):
        return _to_jalali(dt, fmt)
    # برای سایر موارد (مثلاً رشته) همان را برگردان
    return str(dt)


def get_created_at_jalali(obj):
    """دریافت created_at به صورت شمسی"""
    return to_jalali(getattr(obj, 'created_at', None))


def get_updated_at_jalali(obj):
    """دریافت updated_at به صورت شمسی"""
    return to_jalali(getattr(obj, 'updated_at', None))


def get_date_joined_jalali(obj):
    """دریافت date_joined به صورت شمسی"""
    return to_jalali(getattr(obj, 'date_joined', None))


def get_scheduled_at_jalali(obj):
    """دریافت scheduled_at به صورت شمسی"""
    return to_jalali(getattr(obj, 'scheduled_at', None))


def get_expires_at_jalali(obj):
    """دریافت expires_at به صورت شمسی"""
    return to_jalali(getattr(obj, 'expires_at', None))


def get_due_date_jalali(obj):
    """دریافت due_date به صورت شمسی"""
    return to_jalali(getattr(obj, 'due_date', None))


def get_signed_at_jalali(obj):
    """دریافت signed_at به صورت شمسی"""
    return to_jalali(getattr(obj, 'signed_at', None))


def get_last_viewed_at_jalali(obj):
    """دریافت last_viewed_at به صورت شمسی"""
    return to_jalali(getattr(obj, 'last_viewed_at', None))


def get_timestamp_jalali(obj):
    """دریافت timestamp به صورت شمسی"""
    return to_jalali(getattr(obj, 'timestamp', None))


def get_resolved_at_jalali(obj):
    """دریافت resolved_at به صورت شمسی"""
    return to_jalali(getattr(obj, 'resolved_at', None))


def get_verified_at_jalali(obj):
    """دریافت verified_at به صورت شمسی"""
    return to_jalali(getattr(obj, 'verified_at', None))


def get_rejected_at_jalali(obj):
    """دریافت rejected_at به صورت شمسی"""
    return to_jalali(getattr(obj, 'rejected_at', None))


def get_bank_receipt_uploaded_at_jalali(obj):
    """دریافت bank_receipt_uploaded_at به صورت شمسی"""
    return to_jalali(getattr(obj, 'bank_receipt_uploaded_at', None))


def get_paid_at_jalali(obj):
    """دریافت paid_at به صورت شمسی"""
    return to_jalali(getattr(obj, 'paid_at', None))


def get_issue_date_jalali(obj):
    """دریافت issue_date به صورت شمسی"""
    return to_jalali(getattr(obj, 'issue_date', None))


def get_closed_at_jalali(obj):
    """دریافت closed_at به صورت شمسی"""
    return to_jalali(getattr(obj, 'closed_at', None))


def get_sent_at_jalali(obj):
    """دریافت sent_at به صورت شمسی"""
    return to_jalali(getattr(obj, 'sent_at', None))


def get_used_at_jalali(obj):
    """دریافت used_at به صورت شمسی"""
    return to_jalali(getattr(obj, 'used_at', None))


def get_last_run_at_jalali(obj):
    """دریافت last_run_at به صورت شمسی"""
    return to_jalali(getattr(obj, 'last_run_at', None))
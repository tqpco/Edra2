"""
core/utils/geo.py

محاسبه فاصله بین دو مختصات جغرافیایی (فرمول Haversine) - برای مقایسه‌ی
GPS ثبت‌شده توسط کارشناس هنگام شروع کارشناسی با آدرس ثبت‌شده‌ی پروژه
(سرویس ضدتقلب طبق سند معماری).
"""
import math


def haversine_distance_meters(lat1, lng1, lat2, lng2):
    """فاصله مستقیم بین دو نقطه روی کره زمین، بر حسب متر."""
    if None in (lat1, lng1, lat2, lng2):
        return None
    lat1, lng1, lat2, lng2 = map(float, (lat1, lng1, lat2, lng2))
    R = 6371000  # شعاع زمین به متر
    phi1, phi2 = math.radians(lat1), math.radians(lat2)
    d_phi = math.radians(lat2 - lat1)
    d_lambda = math.radians(lng2 - lng1)
    a = (math.sin(d_phi / 2) ** 2 +
         math.cos(phi1) * math.cos(phi2) * math.sin(d_lambda / 2) ** 2)
    c = 2 * math.atan2(math.sqrt(a), math.sqrt(1 - a))
    return R * c


def gps_antifraud_enabled() -> bool:
    """
    کلید روشن/خاموش ضدتقلب GPS (EDRA v34).

    مقدار از «تنظیمات سیستم» (SystemSetting) با کلید `gps_antifraud_enabled`
    خوانده می‌شود و در پنل ادمین Django بدون دیپلوی مجدد قابل‌تغییر است
    (مقدار JSON: true / false). اگر تنظیمی ثبت نشده باشد، **خاموش** است.
    خاموش یعنی: فرانت اصلاً دسترسی موقعیت مکانی از کارشناس نمی‌خواهد و
    سرور هیچ مختصاتی ذخیره یا محاسبه نمی‌کند.
    """
    try:
        from core.models import SystemSetting
        value = SystemSetting.get_value('gps_antifraud_enabled', False)
    except Exception:
        return False
    if isinstance(value, str):
        return value.strip().lower() in ('1', 'true', 'yes', 'on')
    return bool(value) and value != {}

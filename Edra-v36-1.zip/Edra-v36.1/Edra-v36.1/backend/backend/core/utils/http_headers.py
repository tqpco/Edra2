# core/utils/http_headers.py
"""
EDRA v18 — باگ #۳ (ممیزی v17): Content-Disposition استاندارد RFC 6266/5987.

قبل از فیکس، نام فارسی مستقیماً در filename= می‌آمد؛ جنگو fallback به
MIME-Encoding (RFC 2047) می‌کرد و کل هدر (از جمله کلمه‌ی `attachment`)
در یک بلوک base64 می‌پیچید → مرورگرها آن را برای Content-Disposition
تفسیر نمی‌کنند → دانلود با نام نادرست/باز شدن PDF در تب.

این helper ترکیب سازگار با هر دو نسل مرورگر می‌سازد:
- filename="..."  → fallback ASCII برای مرورگرهای قدیمی
- filename*=UTF-8''... → نام فارسی برای مرورگرهای مدرن (RFC 5987)
"""
from urllib.parse import quote


def build_content_disposition(fa_name: str, ascii_fallback: str) -> str:
    """
    مثال:
      fa_name='گزارش_IR-2026-00042.pdf'
      ascii_fallback='report_IR-2026-00042.pdf'
      → 'attachment; filename="report_IR-2026-00042.pdf";
         filename*=UTF-8\'\'%DA%AF...'
    """
    return (
        f'attachment; filename="{ascii_fallback}"; '
        f"filename*=UTF-8''{quote(fa_name)}"
    )

# core/views/audit_views.py
from rest_framework import viewsets, status
from rest_framework.decorators import action
from rest_framework.response import Response
from rest_framework.filters import SearchFilter, OrderingFilter
from django.utils import timezone

from ..models import AuditLog, ErrorLog
from ..serializers import AuditLogSerializer, ErrorLogSerializer
from core.permissions import IsAdminUserOrGroup
from .report_views import _sheet_from_rows, _xlsx_response, _parse_date_range, _apply_date_range
from edra_jalalidate import to_jalali
from openpyxl import Workbook


# ============================================================
# ErrorLogViewSet
# ============================================================
class ErrorLogViewSet(viewsets.ReadOnlyModelViewSet):
    """مشاهده لاگ‌های خطا (فقط ادمین)"""
    queryset = ErrorLog.objects.all()
    serializer_class = ErrorLogSerializer
    permission_classes = [IsAdminUserOrGroup]
    filter_backends = [SearchFilter, OrderingFilter]
    search_fields = ['error_id', 'error_type', 'error_message', 'path']
    ordering_fields = ['timestamp', 'status_code', 'severity']

    def get_queryset(self):
        queryset = super().get_queryset()
        resolved = self.request.query_params.get('resolved')
        if resolved is not None:
            if resolved.lower() == 'true':
                queryset = queryset.filter(resolved=True)
            elif resolved.lower() == 'false':
                queryset = queryset.filter(resolved=False)

        severity = self.request.query_params.get('severity')
        if severity:
            queryset = queryset.filter(severity=severity)

        return queryset

    @action(detail=True, methods=['post'], permission_classes=[IsAdminUserOrGroup])
    def resolve(self, request, pk=None):
        error = self.get_object()
        if error.resolved:
            return Response({'message': 'این خطا قبلاً برطرف شده است.'},
                            status=status.HTTP_400_BAD_REQUEST)

        error.resolved = True
        error.resolved_at = timezone.now()
        error.resolved_by = request.user
        error.resolution_note = request.data.get('resolution_note', '')
        error.save()

        return Response(
            {'message': f'خطا {error.error_id} به عنوان برطرف‌شده علامت‌گذاری شد.'})

    @action(detail=False, methods=['get'], url_path='export-xlsx')
    def export_xlsx(self, request):
        """
        EDRA v25 — خروجی اکسل لاگ‌های خطا.
        """
        queryset = self.filter_queryset(self.get_queryset())
        date_from, date_to = _parse_date_range(request)
        queryset = _apply_date_range(queryset, 'timestamp', date_from, date_to)
        queryset = queryset.select_related('user').order_by('-timestamp')[:20000]

        headers = [
            'شناسه خطا', 'زمان (شمسی)', 'شدت', 'کد وضعیت', 'متد', 'مسیر',
            'نوع خطا', 'پیام خطا', 'کاربر', 'IP', 'برطرف‌شده',
            'یادداشت رفع خطا', 'Traceback (خلاصه)',
        ]
        rows = []
        for log in queryset:
            traceback_excerpt = (log.traceback or '')[:2000]
            rows.append([
                log.error_id,
                to_jalali(log.timestamp, fmt="%Y/%m/%d - %H:%M"),
                log.get_severity_display(),
                log.status_code,
                log.method,
                log.path,
                log.error_type,
                log.error_message,
                log.user.get_full_name() if log.user else '',
                log.ip_address,
                'بله' if log.resolved else 'خیر',
                log.resolution_note,
                traceback_excerpt,
            ])

        wb = Workbook()
        wb.remove(wb.active)
        _sheet_from_rows(wb, 'لاگ خطاها', headers, rows)
        filename = f"error-logs-{timezone.now().strftime('%Y%m%d-%H%M')}.xlsx"
        return _xlsx_response(wb, filename)


# ============================================================
# AuditLogViewSet
# ============================================================
class AuditLogViewSet(viewsets.ReadOnlyModelViewSet):
    """مشاهده لاگ‌های حسابرسی (فقط ادمین)"""
    permission_classes = [IsAdminUserOrGroup]
    queryset = AuditLog.objects.all().order_by('-timestamp')
    serializer_class = AuditLogSerializer
    filter_backends = [SearchFilter, OrderingFilter]
    search_fields = ['user__username', 'action', 'object_id']
    ordering_fields = ['timestamp', 'action']
# core/views/base_views.py
# -*- coding: utf-8 -*-
"""
فایل پایه برای تمام ویوها - شامل کلاس‌های پایه و میکسین‌های مشترک
"""

from ..models import (
    AuditLog, ChecklistItem, ChecklistPhoto, ChecklistTemplate, CityMultiplier,
    CreditReservation, CreditTransaction, DiscountCode, EquipmentParameter,
    EquipmentType, ErrorLog, InspectionReport, InspectionRequest, Invoice,
    LedgerEntry, OTPCode, Organization, Payment, PaymentMethod, Project,
    Refund, ReportVerification, SequenceCounter, TaxRate, UserCredit, UserProfile
)
from ..serializers import (
    AuditLogSerializer, ChecklistItemSerializer, ChecklistTemplateSerializer,
    CityMultiplierSerializer, CreditTransactionSerializer, DiscountCodeSerializer,
    EquipmentTypeSerializer, ErrorLogSerializer, InspectionReportDetailSerializer,
    InspectionReportSerializer, InspectionRequestListSerializer,
    InspectionRequestSerializer, InspectionRequestUpdateSerializer,
    InvoiceSerializer, OTPRequestSerializer, OTPVerifySerializer,
    OrganizationSerializer, PaymentMethodSerializer, PaymentSerializer,
    ProjectSerializer, ReportVerificationSerializer, UserCreditSerializer,
    UserSerializer
)
from ..filters import (
    DiscountCodeFilter, EquipmentTypeFilter, FilterSet, InspectionReportFilter,
    InspectionRequestFilter, InvoiceFilter, NumberFilter, OrganizationFilter,
    PaymentFilter, ProjectFilter, UserFilter
)
from ..permissions import (
    IsAdminGroup, IsExpertGroup, IsAdminOrExpert, IsCustomerOrAdmin,
    ObjectPermissionForInspectionReport,
    IsAdminOrHasObjectPermissionForInspectionRequest,
    is_admin_user, is_expert_user, is_support_user
)
from ..invoice_pdf_generator import generate_invoice_pdf
from ..utils.cache_utils import get_city_multiplier
from ..tasks import generate_report_pdf_task, generate_invoice_pdf_task
from ..search import FullTextSearchMixin

from rest_framework import viewsets, status, generics
from rest_framework.decorators import action, api_view, permission_classes, throttle_classes
from rest_framework.response import Response
from rest_framework.permissions import AllowAny, IsAuthenticated, IsAdminUser
from rest_framework.filters import SearchFilter, OrderingFilter
from rest_framework.throttling import AnonRateThrottle, ScopedRateThrottle
from rest_framework.views import APIView

from django.contrib.auth import get_user_model
from django.utils import timezone
from django.core.cache import cache
from django.db import transaction
from django.core.files.storage import default_storage
from django.core.files.base import ContentFile
from django_filters.rest_framework import DjangoFilterBackend
from guardian.shortcuts import assign_perm, get_objects_for_user

from drf_spectacular.utils import extend_schema, extend_schema_view, OpenApiResponse

from notifications.models import NotificationLog
from notifications.serializers import NotificationLogSerializer
from notifications.services import send_notification

# ✅ جایگزینی توابع تاریخ با edra_jalalidate
from edra_jalalidate import to_jalali

import logging
import random
import json
import os
from decimal import Decimal

User = get_user_model()
logger = logging.getLogger(__name__)


# ============================================================
# میکسین تاریخ شمسی (برای استفاده در ویوها و سریالایزرها)
# ============================================================
class JalaliDateMixin:
    """
    میکسین برای اضافه کردن متدهای کمکی تبدیل تاریخ به شمسی.
    """

    def to_jalali(self, dt, fmt="%Y/%m/%d - %H:%M"):
        """تبدیل datetime به رشته شمسی با فرمت دلخواه."""
        if dt is None:
            return None
        return to_jalali(dt, fmt)

    def get_jalali_field(self, obj, field_name, fmt="%Y/%m/%d - %H:%M"):
        """دریافت مقدار یک فیلد datetime و تبدیل آن به شمسی."""
        value = getattr(obj, field_name, None)
        return self.to_jalali(value, fmt)


# EDRA v27 — حذف کد مرده و خطرناک (تایید ممیزی هوش مصنوعی، سپتامبر
# ۲۰۲۶): CachedListViewSet هیچ‌جای کدبیس استفاده/inherit نمی‌شد (کد
# مرده)، ولی الگویش واقعاً خطرناک بود: cache_page فقط بر اساس URL کش
# می‌کند، نه کاربر — یعنی اگر کسی در آینده از این کلاس برای یک لیست
# شخصی‌سازی‌شده استفاده می‌کرد، پاسخ کاربر A می‌توانست تا ۱ ساعت به
# کاربر B نمایش داده شود. چون هیچ‌جا استفاده نمی‌شد، حذف کامل امن‌تر از
# «تعمیر» یک الگوی خطرناک بی‌مصرف بود.


class BaseViewSet(FullTextSearchMixin, JalaliDateMixin, viewsets.ModelViewSet):
    """
    ViewSet پایه با قابلیت‌های مشترک:
    - جستجوی فول‌تکست (در صورت تنظیم search_vector_fields)
    - select_related و prefetch_related خودکار (در صورت تنظیم list_select_related)
    - متدهای کمکی برای تاریخ شمسی (از JalaliDateMixin)
    """
    list_select_related = []
    list_prefetch_related = []
    search_vector_fields = []

    def get_queryset(self):
        qs = super().get_queryset()
        if self.action == 'list':
            if self.list_select_related:
                qs = qs.select_related(*self.list_select_related)
            if self.list_prefetch_related:
                qs = qs.prefetch_related(*self.list_prefetch_related)
        return qs

    # متدهای کمکی برای نمایش تاریخ در response
    def add_jalali_dates(self, data, fields, fmt="%Y/%m/%d - %H:%M"):
        """
        اضافه کردن نسخه شمسی فیلدهای تاریخ به دیکشنری داده.
        """
        if isinstance(data, list):
            return [self.add_jalali_dates(item, fields, fmt) for item in data]
        if not isinstance(data, dict):
            return data
        result = dict(data)
        for field in fields:
            if field in result and result[field] is not None:
                result[f'{field}_jalali'] = self.to_jalali(result[field], fmt)
        return result
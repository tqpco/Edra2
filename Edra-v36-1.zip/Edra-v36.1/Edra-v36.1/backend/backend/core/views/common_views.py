# core/views/common_views.py
import secrets
import hmac
import logging
from django.conf import settings
from django.core.cache import cache
from ..models.user import hash_otp_code
from django.db import transaction
from django.utils import timezone
from django.db.models import F
from django.utils.crypto import get_random_string
from django.contrib.admin.views.decorators import staff_member_required
from django.views.decorators.http import require_POST
from django.http import JsonResponse
from django.contrib.auth import get_user_model
from rest_framework import status, generics, viewsets, serializers
from rest_framework.decorators import action
from rest_framework.response import Response
from rest_framework.views import APIView
from rest_framework.permissions import AllowAny, IsAuthenticated
from rest_framework.exceptions import APIException
from rest_framework.filters import SearchFilter, OrderingFilter
from rest_framework.throttling import ScopedRateThrottle
from django_filters.rest_framework import DjangoFilterBackend

from ..models import (
    EquipmentParameter, EquipmentType, CityMultiplier, Organization, Project,
    OTPCode, UserProfile
)
from ..serializers import (
    EquipmentTypeSerializer, EquipmentParameterSerializer,
    CityMultiplierSerializer, OrganizationSerializer, ProjectSerializer,
    UserSerializer, OTPRequestSerializer, OTPVerifySerializer
)
from ..filters import (
    EquipmentTypeFilter, OrganizationFilter, ProjectFilter
)
from ..permissions import IsAdminUserOrGroup

User = get_user_model()
logger = logging.getLogger(__name__)


# ============================================================
# EquipmentTypeViewSet
# ============================================================
class EquipmentTypeViewSet(viewsets.ModelViewSet):
    pagination_class = None
    queryset = EquipmentType.objects.all()
    serializer_class = EquipmentTypeSerializer
    filter_backends = [DjangoFilterBackend, SearchFilter, OrderingFilter]
    filterset_class = EquipmentTypeFilter
    search_fields = ['name_fa', 'code']
    ordering_fields = ['name_fa', 'code', 'order']
    ordering = ['order', 'name_fa']

    def get_permissions(self):
        if self.action in ['list', 'retrieve']:
            return [AllowAny()]
        return [IsAdminUserOrGroup()]

    def get_queryset(self):
        # EDRA v32: کاربر عادی/ناشناس فقط موارد «فعال» را می‌بیند؛ ادمین همه را.
        qs = super().get_queryset()
        user = self.request.user
        if user.is_authenticated and (user.is_staff or user.groups.filter(name='Admin').exists()):
            return qs
        return qs.filter(is_active=True)

    @action(detail=False, methods=['post'], permission_classes=[IsAdminUserOrGroup])
    def reorder(self, request):
        ids = request.data.get('ids')
        if not ids or not isinstance(ids, list):
            return Response(
                {'error': 'لیست شناسه‌ها ارسال نشده یا معتبر نیست.'},
                status=status.HTTP_400_BAD_REQUEST
            )

        existing_ids = set(EquipmentType.objects.filter(id__in=ids).values_list('id', flat=True))
        missing = set(ids) - existing_ids
        if missing:
            return Response(
                {'error': f'شناسه‌های {missing} یافت نشدند.'},
                status=status.HTTP_400_BAD_REQUEST
            )

        for index, item_id in enumerate(ids):
            EquipmentType.objects.filter(id=item_id).update(order=index)

        return Response({'success': True, 'message': 'ترتیب با موفقیت به‌روزرسانی شد.'})

    @action(detail=True, methods=['get'], permission_classes=[AllowAny])
    def parameters(self, request, pk=None):
        equipment_type = self.get_object()
        params = equipment_type.parameters.all().order_by('order')
        serializer = EquipmentParameterSerializer(params, many=True)
        return Response(serializer.data)


# ============================================================
# CityMultiplierViewSet
# ============================================================
class CityMultiplierViewSet(viewsets.ModelViewSet):
    """ضرایب شهرها (عمومی برای خواندن، مدیریت فقط ادمین)"""
    queryset = CityMultiplier.objects.all()
    serializer_class = CityMultiplierSerializer
    ordering = ['order', 'city']

    def get_permissions(self):
        if self.action in ['list', 'retrieve']:
            return [AllowAny()]
        return [IsAdminUserOrGroup()]

    def get_queryset(self):
        # EDRA v32: کاربر عادی/ناشناس فقط موارد «فعال» را می‌بیند؛ ادمین همه را.
        qs = super().get_queryset()
        user = self.request.user
        if user.is_authenticated and (user.is_staff or user.groups.filter(name='Admin').exists()):
            return qs
        return qs.filter(is_active=True)

    # EDRA v32 — تاریخچه‌ی تغییرات ضریب شهر (روی AuditLog موجود؛ بدون migration).
    # صفحه‌ی ویرایش ضریب شهر از قبل /history/ را فراخوانی می‌کرد ولی route وجود
    # نداشت و دکمه‌ی «تاریخچه» همیشه غیرفعال می‌ماند.
    _TRACKED_FIELDS = ('city', 'base_cost', 'multiplier', 'is_active')

    def perform_update(self, serializer):
        from ..models import AuditLog
        before = {f: str(getattr(serializer.instance, f, '')) for f in self._TRACKED_FIELDS}
        obj = serializer.save()
        changes = {}
        for f in self._TRACKED_FIELDS:
            new_value = str(getattr(obj, f, ''))
            if before[f] != new_value:
                changes[f] = {'old': before[f], 'new': new_value}
        if changes:
            try:
                AuditLog.objects.create(
                    user=self.request.user, action='city_multiplier_update',
                    object_id=obj.id, changes=changes)
            except Exception as log_error:
                logger.error(f"CityMultiplier audit log failed: {log_error}")

    @action(detail=True, methods=['get'], permission_classes=[IsAdminUserOrGroup])
    def history(self, request, pk=None):
        from ..models import AuditLog
        obj = self.get_object()
        logs = AuditLog.objects.filter(
            action='city_multiplier_update', object_id=obj.id
        ).select_related('user').order_by('-timestamp')[:50]
        rows = []
        for log in logs:
            for field, change in (log.changes or {}).items():
                rows.append({
                    'id': len(rows) + 1,
                    'field': field,
                    'old_value': change.get('old', ''),
                    'new_value': change.get('new', ''),
                    'changed_at': log.timestamp.isoformat(),
                    'changed_by': log.user.username if log.user else '',
                })
        return Response(rows)

    @action(detail=False, methods=['post'], permission_classes=[IsAdminUserOrGroup])
    def reorder(self, request):
        ids = request.data.get('ids')
        if not ids or not isinstance(ids, list):
            return Response(
                {'error': 'لیست شناسه‌ها ارسال نشده یا معتبر نیست.'},
                status=status.HTTP_400_BAD_REQUEST
            )

        existing_ids = set(CityMultiplier.objects.filter(id__in=ids).values_list('id', flat=True))
        missing = set(ids) - existing_ids
        if missing:
            return Response(
                {'error': f'شناسه‌های {missing} یافت نشدند.'},
                status=status.HTTP_400_BAD_REQUEST
            )

        from django.db import transaction as _tx
        with _tx.atomic():
            for index, item_id in enumerate(ids):
                CityMultiplier.objects.filter(id=item_id).update(order=index)

        return Response({'success': True, 'message': 'ترتیب ضرایب شهر با موفقیت به‌روزرسانی شد.'})


# ============================================================
# OTPRequestView
# ============================================================
class OTPRequestView(generics.GenericAPIView):
    permission_classes = [AllowAny]
    serializer_class = OTPRequestSerializer
    throttle_classes = [ScopedRateThrottle]
    throttle_scope = 'otp_request'

    def post(self, request):
        try:
            serializer = self.get_serializer(data=request.data)
            serializer.is_valid(raise_exception=True)
            phone = serializer.validated_data['phone']

            cooldown_key = f'otp_cooldown_{phone}'
            if not cache.add(cooldown_key, '1', timeout=90):
                return Response(
                    {'error': 'کد قبلی هنوز معتبر است. کمی صبر کنید.'},
                    status=status.HTTP_429_TOO_MANY_REQUESTS)

            # EDRA v32: سقف ساعتی «به‌ازای هر شماره» (جلوگیری از SMS-bombing یک
            # قربانی و هزینه‌ی پیامک)؛ throttle IP-محور به‌تنهایی کافی نیست.
            # بعد از cooldown شمرده می‌شود تا کلیک‌های پیاپیِ «ارسال مجدد» در
            # بازه‌ی انتظار سهمیه نسوزانند.
            hourly_key = f'otp_hourly_{phone}'
            cache.add(hourly_key, 0, timeout=3600)
            try:
                hourly_count = cache.incr(hourly_key)
            except ValueError:  # کلید بین add و incr منقضی شد
                cache.set(hourly_key, 1, timeout=3600)
                hourly_count = 1
            if hourly_count > 5:
                cache.delete(cooldown_key)
                return Response(
                    {'error': 'تعداد درخواست کد برای این شماره زیاد است. یک ساعت دیگر تلاش کنید.'},
                    status=status.HTTP_429_TOO_MANY_REQUESTS)

            code = ''.join(secrets.choice('0123456789') for _ in range(6))
            otp = OTPCode.objects.create(phone=phone, code=hash_otp_code(code))
            # EDRA v27 — رفع باگ امنیتی (تایید ممیزی هوش مصنوعی، سپتامبر
            # ۲۰۲۶): قبلاً کد خام (نه هش) در Redis هم cache می‌شد، درحالی‌که
            # بررسی کامل کدبیس نشان داد این مقدار هیچ‌جا خوانده نمی‌شود
            # (write-only) — یعنی صرفاً یک ریسک بدون فایده بود (اگر Redis
            # نشت کند، کد خام افشا می‌شود). حذف شد.

            try:
                from notifications.services import send_sms, format_otp_sms_body
                send_sms(phone, format_otp_sms_body(code))
            except Exception as send_error:
                cache.delete(cooldown_key)
                if settings.DEV_OTP_ENABLED:
                    logger.info(
                        f"OTP dev mode request_id={otp.id} phone={phone} "
                        f"(SMS غیرفعال)")
                else:
                    otp.is_used = True
                    otp.save(update_fields=['is_used'])
                    logger.error(
                        f"OTP send failed request_id={otp.id} phone={phone}: "
                        f"{send_error}")
                    return Response(
                        {'error': 'ارسال پیامک ناموفق بود. لطفاً دوباره تلاش کنید.'},
                        status=status.HTTP_500_INTERNAL_SERVER_ERROR)

            return Response({
                'message': 'کد تایید ارسال شد.',
            }, status=status.HTTP_200_OK)
        except serializers.ValidationError:
            raise
        except Exception as e:
            logger.error(f"OTPRequestView error: {e}")
            return Response({'error': 'خطای داخلی سرور'}, status=500)


# ============================================================
# OTPVerifyView
# ============================================================
class OTPVerifyView(generics.GenericAPIView):
    permission_classes = [AllowAny]
    serializer_class = OTPVerifySerializer
    throttle_classes = [ScopedRateThrottle]
    throttle_scope = 'otp_verify'

    MAX_ATTEMPTS = 5
    OTP_TTL_SECONDS = 120

    def post(self, request):
        try:
            serializer = self.get_serializer(data=request.data)
            serializer.is_valid(raise_exception=True)
            phone = serializer.validated_data['phone']
            code = serializer.validated_data['code']

            if (settings.DEV_OTP_ENABLED
                    and phone in settings.DEV_OTP_ALLOWED_PHONES
                    and code == settings.DEV_OTP_CODE):
                has_recent = OTPCode.objects.filter(
                    phone=phone,
                    is_used=False,
                    created_at__gte=timezone.now() - timezone.timedelta(
                        seconds=self.OTP_TTL_SECONDS)
                ).exists()
                if has_recent:
                    user, created = self._get_or_create_user(phone)
                    from ..authentication import is_account_suspended
                    if not user.is_active or is_account_suspended(user):
                        return Response(
                            {'error': 'حساب کاربری شما غیرفعال یا تعلیق شده است.'},
                            status=status.HTTP_403_FORBIDDEN)
                    try:
                        from ..models import AuditLog
                        AuditLog.objects.create(
                            user=user, action='otp_login',
                            object_id=user.id,
                            changes={'phone': phone, 'is_new_user': created,
                                     'channel': 'dev'})
                    except Exception as log_error:
                        logger.error(f"Error writing audit log: {log_error}")
                    return self._issue_tokens(user, created)
                return Response({'error': 'ابتدا کد تایید را درخواست کنید.'},
                                status=status.HTTP_400_BAD_REQUEST)

            from django.db import transaction as db_transaction
            with db_transaction.atomic():
                try:
                    otp = OTPCode.objects.select_for_update().filter(
                        phone=phone, is_used=False
                    ).latest('created_at')
                except OTPCode.DoesNotExist:
                    return Response({'error': 'کد نامعتبر است.'},
                                    status=status.HTTP_400_BAD_REQUEST)

                if otp.attempts >= self.MAX_ATTEMPTS:
                    otp.is_used = True
                    otp.save(update_fields=['is_used'])
                    return Response(
                        {'error': 'تعداد تلاش‌های مجاز به پایان رسیده است. کد جدید درخواست کنید.'},
                        status=status.HTTP_400_BAD_REQUEST)

                if (timezone.now() - otp.created_at).total_seconds() > self.OTP_TTL_SECONDS:
                    return Response({'error': 'کد منقضی شده است.'},
                                    status=status.HTTP_400_BAD_REQUEST)

                if not hmac.compare_digest(otp.code, hash_otp_code(code)):
                    OTPCode.objects.filter(pk=otp.pk).update(
                        attempts=F('attempts') + 1)
                    return Response({'error': 'کد نامعتبر است.'},
                                    status=status.HTTP_400_BAD_REQUEST)

                otp.is_used = True
                otp.save(update_fields=['is_used'])

            user, created = self._get_or_create_user(phone)
            # EDRA v36: کاربر غیرفعال (ادمین غیرفعالش کرده) قبلاً توکن می‌گرفت و
            # فقط در اولین فراخوانی بعدی خطا می‌دید؛ ورود باید همان‌جا رد شود.
            from ..authentication import is_account_suspended
            if not user.is_active or is_account_suspended(user):
                return Response(
                    {'error': 'حساب کاربری شما غیرفعال یا تعلیق شده است.'},
                    status=status.HTTP_403_FORBIDDEN)

            try:
                from ..models import AuditLog
                AuditLog.objects.create(
                    user=user,
                    action='otp_login',
                    object_id=user.id,
                    changes={'phone': phone, 'is_new_user': created})
            except Exception as log_error:
                logger.error(f"Error writing audit log: {log_error}")

            return self._issue_tokens(user, created)

        except (serializers.ValidationError, APIException):
            raise
        except Exception as e:
            logger.error(f"OTPVerifyView error: {e}")
            return Response(
                {'error': 'خطای داخلی سرور'},
                status=status.HTTP_500_INTERNAL_SERVER_ERROR
            )

    def _get_or_create_user(self, phone):
        user, created = User.objects.get_or_create(
            username=phone,
            defaults={'email': f'{phone}@temp.com'}
        )
        if created:
            random_password = get_random_string(32)
            user.set_password(random_password)
            user.save()
        try:
            from ..models import UserProfile
            UserProfile.objects.get_or_create(
                user=user, defaults={'phone': phone})
        except Exception as e:
            logger.error(f"Error creating profile for {phone}: {e}")
        return user, created

    def _issue_tokens(self, user, created):
        from rest_framework_simplejwt.tokens import RefreshToken
        from ..permissions import get_user_role
        refresh = RefreshToken.for_user(user)
        # EDRA v27 — claim سبک برای middleware فرانت‌اند (فقط جهت
        # هدایت مسیر/UX)؛ اجازه‌ی دسترسی واقعی همچنان توسط
        # permission_class های DRF روی هر endpoint enforce می‌شود.
        refresh['role'] = get_user_role(user)
        refresh.access_token['role'] = get_user_role(user)
        return Response({
            'access': str(refresh.access_token),
            'refresh': str(refresh),
            'user': UserSerializer(user).data,
            'is_new': created
        }, status=status.HTTP_200_OK)


# ============================================================
# CurrentUserView
# ============================================================
class CurrentUserView(APIView):
    permission_classes = [IsAuthenticated]

    def get(self, request):
        serializer = UserSerializer(request.user)
        return Response(serializer.data)


# ============================================================
# ChangePasswordView
# ============================================================
class ChangePasswordView(APIView):
    permission_classes = [IsAuthenticated]
    # EDRA v36: بدون throttle_classes، throttle_scope نادیده گرفته می‌شد و حدس
    # old_password فقط با سقف روزانه‌ی عمومی محدود بود.
    throttle_classes = [ScopedRateThrottle]
    throttle_scope = 'password_change'

    def post(self, request):
        user = request.user
        old_password = request.data.get('old_password')
        new_password = request.data.get('new_password')

        if not old_password or not new_password:
            return Response({'error': 'رمز فعلی و جدید را وارد کنید.'},
                            status=status.HTTP_400_BAD_REQUEST)

        if not user.check_password(old_password):
            return Response({'error': 'رمز فعلی اشتباه است.'},
                            status=status.HTTP_400_BAD_REQUEST)

        # EDRA v27 — همان رفع باگ امنیتی (سومین endpoint تقریباً یکسان
        # تغییر رمز در کدبیس — نشانه‌ی تکرار کد که ارزش یکسان‌سازی در
        # آینده را دارد).
        from django.contrib.auth.password_validation import validate_password
        from django.core.exceptions import ValidationError as DjangoValidationError
        try:
            validate_password(new_password, user=user)
        except DjangoValidationError as e:
            return Response({'error': ' '.join(e.messages)},
                            status=status.HTTP_400_BAD_REQUEST)

        user.set_password(new_password)
        user.save()
        from ..security import revoke_user_refresh_tokens
        revoke_user_refresh_tokens(user)
        return Response({'success': True,
                         'message': 'رمز عبور با موفقیت تغییر کرد.'})


# ============================================================
# DebugView
# ============================================================
import re

_PHONE_RE = re.compile(r'0?9\d{9}\b')
_EMAIL_RE = re.compile(r'[\w.+-]+@[\w-]+\.[\w.-]+')
_TOKEN_RE = re.compile(r'\b[A-Za-z0-9_\-]{32,}\b')


def _redact_pii_text(text: str) -> str:
    """
    EDRA v27 — رفع باگ واقعی (گزارش ممیزی کاربر، سپتامبر ۲۰۲۶): قبلاً
    متن خطا/context عیناً (بدون فیلتر) به سرویس خارجی DeepSeek ارسال
    می‌شد که می‌توانست شماره موبایل/ایمیل/توکن مشتریان را افشا کند.
    این یک فیلتر ساده‌ی regex-based است، نه یک راه‌حل کامل DLP —
    بهترین تلاش برای کاهش ریسک قبل از ارسال به سرویس ثالث.
    """
    if not text:
        return text
    text = _PHONE_RE.sub('[PHONE_REDACTED]', text)
    text = _EMAIL_RE.sub('[EMAIL_REDACTED]', text)
    text = _TOKEN_RE.sub('[TOKEN_REDACTED]', text)
    return text


class DebugView(APIView):
    permission_classes = [IsAdminUserOrGroup]

    def post(self, request):
        error_message = request.data.get('error')
        context = request.data.get('context', '')

        if not error_message:
            return Response({
                'success': False,
                'error': 'لطفاً پیام خطا را ارسال کنید.'
            }, status=400)

        error_message = _redact_pii_text(error_message)
        context = _redact_pii_text(context)

        try:
            from ..services.deepseek import analyze_error
            result = analyze_error(error_message, context)
        except ImportError:
            result = {
                'error': 'سرویس تحلیل خطا در دسترس نیست.',
                'message': error_message,
                'context': context
            }
        return Response(result)


# ============================================================
# OrganizationViewSet
# ============================================================
class OrganizationViewSet(viewsets.ModelViewSet):
    pagination_class = None
    queryset = Organization.objects.all()
    serializer_class = OrganizationSerializer
    permission_classes = [IsAdminUserOrGroup]
    filter_backends = [DjangoFilterBackend, SearchFilter, OrderingFilter]
    filterset_class = OrganizationFilter
    search_fields = ['name', 'code']
    ordering_fields = ['name']
    ordering = ['name']


# ============================================================
# ProjectViewSet
# ============================================================
class ProjectViewSet(viewsets.ModelViewSet):
    # EDRA v32 — IDOR: با فقط IsAuthenticated، هر مشتریِ واردشده (نه فقط
    # ادمین) می‌توانست POST بزند و یک پروژه را به هر organization دلخواه
    # (با حدس شناسه‌ی عددی) متصل کند، یا در PATCH روی پروژه‌ی خودش
    # (billing_contact)، فیلد organization را به سازمانی دیگر تغییر دهد —
    # چون نه serializer و نه این ViewSet هیچ محدودیتی روی مقدار نوشتنیِ
    # organization نداشتند. تنها مصرف‌کننده‌ی واقعی این نوشتن، پنل ادمین
    # است؛ پس نوشتن به staff/ادمین محدود شد. خواندن (برای billing_contact
    # یک سازمان) همان‌طور که بود باقی ماند.
    pagination_class = None
    serializer_class = ProjectSerializer
    filter_backends = [DjangoFilterBackend, SearchFilter, OrderingFilter]
    filterset_class = ProjectFilter
    search_fields = ['name', 'code']
    ordering_fields = ['name']
    ordering = ['name']

    def get_permissions(self):
        if self.action in ('create', 'update', 'partial_update', 'destroy'):
            return [IsAdminUserOrGroup()]
        return [IsAuthenticated()]

    def get_queryset(self):
        user = self.request.user
        # EDRA v36: is_staff به‌تنهایی ادمین‌های «گروه Admin» را از لیست کامل
        # محروم می‌کرد (و در perform_create سازمان را None می‌کرد).
        from ..permissions import is_admin_user as _is_admin_user
        if _is_admin_user(user):
            return Project.objects.all()
        try:
            org = Organization.objects.filter(billing_contact=user).first()
            if org:
                return Project.objects.filter(organization=org)
        except Exception:
            pass
        return Project.objects.none()

    def perform_create(self, serializer):
        from ..permissions import is_admin_user as _is_admin_user
        if not _is_admin_user(self.request.user):
            org = Organization.objects.filter(
                billing_contact=self.request.user).first()
            serializer.save(organization=org)
        else:
            serializer.save()


# ============================================================
# EquipmentParameterViewSet
# ============================================================
class EquipmentParameterViewSet(viewsets.ModelViewSet):
    queryset = EquipmentParameter.objects.all().order_by('equipment_type', 'order')
    serializer_class = EquipmentParameterSerializer
    permission_classes = [IsAdminUserOrGroup]
    filter_backends = [DjangoFilterBackend, SearchFilter, OrderingFilter]
    filterset_fields = ['equipment_type']
    search_fields = ['name', 'label']
    ordering_fields = ['order', 'name']
    ordering = ['equipment_type', 'order']

    # EDRA v27 — رفع باگ (گزارش کاربر، سپتامبر ۲۰۲۶): این اکشن اصلاً
    # وجود نداشت. صفحه‌ی ادمین (equipment/[id]/edit) پیام موفقیت جعلی
    # نشان می‌داد بدون اینکه واقعاً چیزی ذخیره شود؛ بعد از رفرش صفحه
    # ترتیب به حالت قبل برمی‌گشت. توجه: از .save() به‌جای .update() بالک
    # استفاده شده تا سیگنال post_save (بازسازی param_schema) درست fire شود.
    @action(detail=False, methods=['post'], permission_classes=[IsAdminUserOrGroup])
    def reorder(self, request):
        ids = request.data.get('ids')
        if not ids or not isinstance(ids, list):
            return Response(
                {'error': 'لیست شناسه‌ها ارسال نشده یا معتبر نیست.'},
                status=status.HTTP_400_BAD_REQUEST
            )

        params = list(EquipmentParameter.objects.filter(id__in=ids))
        existing_ids = {p.id for p in params}
        missing = set(ids) - existing_ids
        if missing:
            return Response(
                {'error': f'شناسه‌های {missing} یافت نشدند.'},
                status=status.HTTP_400_BAD_REQUEST
            )

        equipment_type_ids = {p.equipment_type_id for p in params}
        if len(equipment_type_ids) > 1:
            return Response(
                {'error': 'همه‌ی پارامترها باید متعلق به یک نوع تجهیزات باشند.'},
                status=status.HTTP_400_BAD_REQUEST
            )

        params_by_id = {p.id: p for p in params}
        with transaction.atomic():
            for index, item_id in enumerate(ids):
                param = params_by_id[item_id]
                param.order = index
                param.save(update_fields=['order'])  # سیگنال post_save را عمداً fire می‌کند

        return Response({'success': True, 'message': 'ترتیب پارامترها با موفقیت به‌روزرسانی شد.'})


# ============================================================
# حذف پارامتر با AJAX
# ============================================================
@staff_member_required
@require_POST
def ajax_delete_parameter(request, pk):
    try:
        param = EquipmentParameter.objects.select_related(
            'equipment_type').get(pk=pk)
        equipment = param.equipment_type
        param.delete()

        if equipment.parameters.exists():
            schema = [p.to_json_schema()
                      for p in equipment.parameters.all().order_by('order')]
            equipment.param_schema = schema
        else:
            equipment.param_schema = None
        equipment.save(update_fields=['param_schema'])

        return JsonResponse({
            'status': 'success',
            'message': 'پارامتر با موفقیت حذف شد.',
            'param_schema': equipment.param_schema
        })
    except EquipmentParameter.DoesNotExist:
        return JsonResponse({
            'status': 'error',
            'message': 'پارامتر یافت نشد.'
        }, status=404)
    except Exception as e:
        return JsonResponse({
            'status': 'error',
            'message': f'خطا در حذف پارامتر: {str(e)}'
        }, status=500)
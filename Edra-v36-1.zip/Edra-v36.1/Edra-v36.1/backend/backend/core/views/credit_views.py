# core/views/credit_views.py
import hashlib
import os
import random
import logging
from decimal import Decimal

from django.utils import timezone
from django.core.files.base import ContentFile
from django.core.files.storage import default_storage
from django.db import transaction
from django.contrib.auth import get_user_model

from rest_framework import viewsets, status
from rest_framework.decorators import api_view, permission_classes, throttle_classes
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated

from core.permissions import IsAdminUserOrGroup, is_admin_user
from core.models import (
    CityMultiplier, EquipmentType, InspectionRequest,
    Payment, PaymentMethod, UserCredit, CreditReservation, CreditTransaction
)
from core.serializers import (
    UserCreditSerializer, CreditTransactionSerializer
)
from notifications.services import send_notification, get_admin_users
from ..validators import validate_uploaded_file, MAX_RECEIPT_SIZE
from ..services.money import toman_to_rial
from ..services.credit_service import CreditService, InsufficientCreditError
from ..services.invoice_service import InvoiceSettlementService
from .payment_views import (
    PaymentInitiateThrottle, _initiate_payment_impl, _payment_callback_url)

User = get_user_model()
logger = logging.getLogger(__name__)


# ============================================================
# سخت‌سازی آپلود فیش (FILE-01 از گزارش ممیزی)
# ============================================================
def _validate_receipt_file(uploaded_file):
    """
    اعتبارسنجی فایل فیش: پسوند + حجم + magic bytes واقعی + نام فایل.
    در صورت نامعتبر بودن، پیام خطای فارسی برمی‌گرداند؛ در غیر این صورت None.
    """
    return validate_uploaded_file(uploaded_file)


def _save_receipt_file(receipt_file, user_id):
    """
    EDRA v5 — CRITICAL-04/HIGH-05:
    ذخیره فیش با hash درست.
      - bytes فقط یک بار خوانده می‌شود (قبلاً بعد از read اول، hash از
        cursor خالی گرفته می‌شد → hash اشتباه).
      - extension از نام فایل معتبر استخراج می‌شود (قبلاً متغیر `ext`
        تعریف نشده بود → NameError).
      - نام اصلی فایل به storage path منتقل نمی‌شود (فقط id+timestamp+random).

    خروجی: (storage_path, sha256_hexdigest)
    """
    content = receipt_file.read()
    name = getattr(receipt_file, 'name', '') or ''
    ext = os.path.splitext(name)[1].lower()
    # EDRA v36: random.randint (PRNG قابل پیش‌بینی، فقط ۹۰۰۰ حالت در هر ثانیه)
    # با یک توکن رمزنگاری‌شده جایگزین شد؛ مسیر فیش نباید قابل حدس باشد.
    import secrets
    path = (
        f'receipts/{user_id}_{int(timezone.now().timestamp())}_'
        f'{secrets.token_hex(8)}{ext}'
    )
    storage_path = default_storage.save(path, ContentFile(content))
    digest = hashlib.sha256(content).hexdigest()
    return storage_path, digest


# ============================================================
# UserCreditViewSet
# ============================================================
class UserCreditViewSet(viewsets.ReadOnlyModelViewSet):
    permission_classes = [IsAuthenticated]
    serializer_class = UserCreditSerializer

    def get_queryset(self):
        return UserCredit.objects.filter(user=self.request.user)

    def get_object(self):
        try:
            return UserCredit.objects.get(user=self.request.user)
        except UserCredit.DoesNotExist:
            return UserCredit.objects.create(user=self.request.user)


# ============================================================
# CreditTransactionViewSet
# ============================================================
class CreditTransactionViewSet(viewsets.ReadOnlyModelViewSet):
    permission_classes = [IsAuthenticated]
    serializer_class = CreditTransactionSerializer

    def get_queryset(self):
        return CreditTransaction.objects.filter(
            user=self.request.user
        ).order_by('-created_at')


# ============================================================
# helper: پرداخت کامل با اعتبار → در انتظار بررسی ادمین
# ============================================================
def _submit_full_credit_payment(user, request_id):
    """
    EDRA v35 — منطق واحد «پرداخت کامل با اعتبار» (قبلاً در سه جا کپی شده بود:
    request_credit_deposit دو بار و inspection_views.credit_pay؛ هر کدام با
    باگ مخصوص خود). قانون کسب‌وکار (v27): پرداخت اعتباری فوراً paid نمی‌شود؛
    Payment در وضعیت pending_verification می‌ماند و ادمین تایید/رد می‌کند.
    - ردیف درخواست قفل می‌شود (دو کلیک همزمان = دو Payment/دو رزرو نمی‌سازد).
    - مبلغ از snapshot سمت سرور (با مالیات) گرفته می‌شود.
    - رزروهای قدیمی همین درخواست آزاد و رزرو تازه ساخته می‌شود.
    خروجی: Response آماده.
    """
    with transaction.atomic():
        try:
            inspection_request = InspectionRequest.objects.select_for_update(
            ).get(id=request_id, customer=user)
        except (InspectionRequest.DoesNotExist, ValueError, TypeError):
            return Response({'error': 'درخواست یافت نشد.'}, status=404)
        if inspection_request.status != 'pending_payment':
            return Response(
                {'error': 'این درخواست در وضعیت قابل پرداخت نیست.'}, status=400)
        if inspection_request.payments.filter(
                status='pending_verification').exists():
            return Response(
                {'error': 'پرداخت قبلی این درخواست در انتظار بررسی ادمین است.'},
                status=400)

        snap = InvoiceSettlementService.payment_snapshot(inspection_request)
        if snap['amount'] <= 0:
            return Response(
                {'error': 'مبلغ قابل پرداخت صفر است؛ با پشتیبانی تماس بگیرید.'},
                status=400)

        for stale in CreditReservation.objects.filter(
                inspection_request=inspection_request, status='reserved'):
            CreditService.release(stale, reason='superseded by credit payment')
        try:
            reservation = CreditService.reserve(
                user, snap['amount'], inspection_request=inspection_request)
        except InsufficientCreditError as e:
            return Response({'error': str(e)}, status=400)

        payment_method, _ = PaymentMethod.objects.get_or_create(
            name='credit', defaults={'is_active': True})
        payment = Payment.objects.create(
            inspection_request=inspection_request,
            amount=snap['amount'],
            amount_rial=snap['amount_rial'],
            credit_amount=snap['amount'],
            online_amount=0,
            manual_amount=0,
            method=payment_method,
            status='pending_verification',
        )
        reservation.payment = payment
        reservation.save(update_fields=['payment'])
        # عمداً consume نمی‌شود تا رد/تایید ادمین تصمیم بگیرد.

    try:
        send_notification(user, 'payment_pending_review', {
            'request_id': inspection_request.id,
            'amount': str(snap['amount']),
            'method': 'credit'
        })
    except Exception as e:
        logger.error(f"Error sending notification: {e}")

    return Response({
        'success': True,
        'message': 'درخواست با اعتبار شما ثبت شد و برای بررسی نهایی ادمین ارسال شد.',
        'new_balance': UserCredit.objects.get(user=user).balance,
        'applied_credit': snap['amount'],
        'remaining_amount': 0,
        'payment_id': payment.id,
        'status': 'pending_verification',
    })


def _parse_positive_decimal(value):
    """مقدار مثبتِ متناهی یا None (ورودی نامعتبر/NaN/Infinity/منفی/صفر)."""
    try:
        d = Decimal(str(value))
    except Exception:
        return None
    if not d.is_finite() or d <= 0:
        return None
    return d


MIN_DEPOSIT_TOMAN = Decimal('10000')          # هم‌خوان با فرم افزایش اعتبار
MAX_DEPOSIT_TOMAN = Decimal('100000000000')    # زیر سقف ستون (۱۲ رقم)


# ============================================================
# request_credit_deposit
# ============================================================
@api_view(['POST'])
@permission_classes([IsAuthenticated])
@throttle_classes([PaymentInitiateThrottle])
def request_credit_deposit(request):
    """
    افزایش اعتبار یا پرداخت یک درخواست (دستی با فیش / آنلاین / اعتبار)
    پارامترها:
    - amount: مبلغ (فقط برای افزایش اعتبار؛ با request_id نادیده گرفته می‌شود)
    - method: 'manual' یا 'online' یا 'credit'
    - request_id: (اختیاری) شناسه درخواست برای پرداخت مستقیم
    - credit_amount: (اختیاری) سهم اعتبار در پرداخت ترکیبی
    - receipt_file: (برای روش manual) فایل فیش

    EDRA v35 — اصلاحات: حذف شاخه‌ی «افزایش اعتبار رایگان» (method=credit بدون
    request_id موجودی را زیاد می‌کرد وقتی موجودی کافی بود!)، اعتبارسنجی فایل
    «قبل از» رزرو اعتبار (رزرو نشت می‌کرد)، جلوگیری از فیش/پرداخت تکراری،
    مسیر آنلاین با request_id (قبلاً همیشه ۵۰۰)، و ورودی‌های نامعتبر ۴۰۰.
    """
    try:
        method = request.data.get('method', 'manual')
        request_id = request.data.get('request_id')

        if method not in ('manual', 'online', 'credit'):
            return Response({'error': 'روش پرداخت نامعتبر است.'}, status=400)

        # EDRA v32: روش‌های غیرفعال‌شده توسط ادمین باید واقعاً رد شوند.
        _inactive_methods = set(PaymentMethod.objects.filter(
            is_active=False).values_list('name', flat=True))
        if method in _inactive_methods or (
                request.data.get('credit_amount') and 'credit' in _inactive_methods):
            return Response(
                {'error': 'این روش پرداخت موقتاً غیرفعال است. روش دیگری انتخاب کنید.'},
                status=400)

        # ------------------------------------------------------------
        # الف) پرداخت یک درخواست موجود (request_id)
        # ------------------------------------------------------------
        if request_id:
            # P0-01 (v9): مبلغ فقط از snapshot سمت سرور؛ amount کلاینت نادیده.
            if method == 'credit':
                return _submit_full_credit_payment(request.user, request_id)

            if method == 'online':
                return _initiate_payment_impl(request)

            # method == 'manual' (فیش بانکی؛ با سهم اعتبار اختیاری)
            receipt_file = request.FILES.get('receipt_file')
            if not receipt_file:
                return Response(
                    {'error': 'فایل فیش ارسال نشده است.'}, status=400)
            file_error = _validate_receipt_file(receipt_file)
            if file_error:
                return Response({'error': file_error}, status=400)

            credit_requested = None
            raw_credit = request.data.get('credit_amount')
            if raw_credit not in (None, '', 0, '0'):
                credit_requested = _parse_positive_decimal(raw_credit)
                if credit_requested is None:
                    return Response(
                        {'error': 'مبلغ اعتبار باید مثبت باشد.'}, status=400)

            try:
                _pre = InspectionRequest.objects.get(
                    id=request_id, customer=request.user)
            except (InspectionRequest.DoesNotExist, ValueError, TypeError):
                return Response({'error': 'درخواست یافت نشد.'}, status=404)
            if credit_requested is not None:
                _pre_snap = InvoiceSettlementService.payment_snapshot(_pre)
                if credit_requested > _pre_snap['amount']:
                    return Response(
                        {'error': 'مبلغ اعتبار نمی‌تواند بیشتر از مبلغ درخواست باشد.'},
                        status=400)
                # اگر کل مبلغ با اعتبار پوشش داده شد، همان مسیر پرداخت اعتباری
                if credit_requested >= _pre_snap['amount']:
                    return _submit_full_credit_payment(
                        request.user, request_id)

            file_path = None
            try:
                with transaction.atomic():
                    inspection_request = InspectionRequest.objects \
                        .select_for_update().get(pk=_pre.pk)
                    if inspection_request.status != 'pending_payment':
                        return Response(
                            {'error': 'این درخواست در وضعیت قابل پرداخت نیست.'},
                            status=400)
                    if inspection_request.payments.filter(
                            status='pending_verification').exists():
                        return Response(
                            {'error': 'فیش قبلی این درخواست در انتظار بررسی '
                                      'ادمین است.'}, status=400)

                    snap = InvoiceSettlementService.payment_snapshot(
                        inspection_request, credit_amount=0)

                    for stale in CreditReservation.objects.filter(
                            inspection_request=inspection_request,
                            status='reserved'):
                        CreditService.release(
                            stale, reason='superseded by manual payment')
                    reservation = None
                    credit_part = Decimal('0')
                    if credit_requested is not None:
                        try:
                            reservation = CreditService.reserve(
                                request.user, credit_requested,
                                inspection_request=inspection_request)
                        except InsufficientCreditError as e:
                            return Response({'error': str(e)}, status=400)
                        credit_part = credit_requested

                    file_path, digest = _save_receipt_file(
                        receipt_file, request.user.id)
                    payment_method, _ = PaymentMethod.objects.get_or_create(
                        name='manual', defaults={'is_active': True})
                    payment = Payment.objects.create(
                        inspection_request=inspection_request,
                        amount=snap['amount'],
                        amount_rial=snap['amount_rial'],
                        credit_amount=credit_part,
                        online_amount=0,
                        manual_amount=snap['amount'] - credit_part,
                        method=payment_method,
                        status='pending_verification',
                        bank_receipt=file_path,
                        bank_receipt_uploaded_at=timezone.now(),
                        bank_receipt_hash=digest,
                    )
                    if reservation is not None:
                        reservation.payment = payment
                        reservation.save(update_fields=['payment'])
            except Exception:
                if file_path:
                    try:
                        default_storage.delete(file_path)
                    except Exception:
                        pass
                raise

            for admin in get_admin_users():
                try:
                    send_notification(admin, 'payment_manual_upload', {
                        'request_id': inspection_request.id,
                        'payment_id': payment.id,
                        'customer': request.user.username,
                        'amount': str(snap['amount'])
                    })
                except Exception as e:
                    logger.error(f"Error sending admin notification: {e}")

            return Response({
                'success': True,
                'message': 'فیش با موفقیت آپلود شد. پس از تأیید مدیر، درخواست شما تکمیل می‌شود.',
                'payment_id': payment.id,
                'status': 'pending_verification'
            })

        # ------------------------------------------------------------
        # ب) افزایش اعتبار (بدون request_id)
        # ------------------------------------------------------------
        if method == 'credit':
            # EDRA v35 — باگ بحرانی حذف‌شده: این شاخه اگر موجودی ≥ مبلغ بود،
            # `balance += amount` می‌کرد (هر کاربرِ دارای موجودی می‌توانست
            # اعتبارش را بی‌نهایت دو برابر کند).
            return Response(
                {'error': 'پرداخت با اعتبار فقط برای پرداخت یک درخواست مجاز است.'},
                status=400)

        amount = _parse_positive_decimal(request.data.get('amount'))
        if amount is None:
            return Response({'error': 'مبلغ را به‌درستی وارد کنید.'}, status=400)
        if amount != amount.to_integral_value():
            return Response(
                {'error': 'مبلغ باید عدد صحیح (تومان) باشد.'}, status=400)
        if amount < MIN_DEPOSIT_TOMAN:
            return Response(
                {'error': f'حداقل مبلغ افزایش اعتبار {MIN_DEPOSIT_TOMAN:,.0f} تومان است.'},
                status=400)
        if amount >= MAX_DEPOSIT_TOMAN:
            return Response({'error': 'مبلغ بیش از حد مجاز است.'}, status=400)

        equipment = EquipmentType.objects.first()
        city = CityMultiplier.objects.first()
        if not equipment or not city:
            return Response({'error': 'داده‌های پایه یافت نشد.'}, status=500)

        if method == 'manual':
            receipt_file = request.FILES.get('receipt_file')
            if not receipt_file:
                return Response(
                    {'error': 'فایل فیش ارسال نشده است.'}, status=400)
            file_error = _validate_receipt_file(receipt_file)
            if file_error:
                return Response({'error': file_error}, status=400)

            file_path = None
            try:
                with transaction.atomic():
                    file_path, digest = _save_receipt_file(
                        receipt_file, request.user.id)
                    temp_request = InspectionRequest.objects.create(
                        customer=request.user,
                        equipment_type=equipment,
                        city=city.city,
                        address='واریز اعتبار - آپلود فیش',
                        brand_model='واریز اعتبار',
                        manufacture_year=None,
                        calculated_price=amount,
                        final_price=amount,
                        status='pending_payment',
                        params={'is_deposit': True}
                    )
                    payment_method, _ = PaymentMethod.objects.get_or_create(
                        name='manual', defaults={'is_active': True})
                    payment = Payment.objects.create(
                        inspection_request=temp_request,
                        amount=amount,
                        amount_rial=toman_to_rial(amount),
                        manual_amount=amount,
                        method=payment_method,
                        status='pending_verification',
                        bank_receipt=file_path,
                        bank_receipt_uploaded_at=timezone.now(),
                        bank_receipt_hash=digest,
                    )
            except Exception:
                if file_path:
                    try:
                        default_storage.delete(file_path)
                    except Exception:
                        pass
                raise

            return Response({
                'success': True,
                'message': 'فیش با موفقیت آپلود شد. پس از تأیید مدیر، اعتبار شما افزایش می‌یابد.',
                'payment_id': payment.id,
                'status': 'pending_verification'
            })

        # method == 'online' (زرین‌پال)
        from ..services.payment_service import ZarinpalService

        with transaction.atomic():
            temp_request = InspectionRequest.objects.create(
                customer=request.user,
                equipment_type=equipment,
                city=city.city,
                address='افزایش اعتبار - آنلاین',
                brand_model='واریز اعتبار',
                manufacture_year=None,
                calculated_price=amount,
                final_price=amount,
                status='pending_payment',
                params={'is_deposit': True}
            )
            payment_method, _ = PaymentMethod.objects.get_or_create(
                name='online', defaults={'is_active': True})
            payment = Payment.objects.create(
                inspection_request=temp_request,
                amount=amount,
                amount_rial=toman_to_rial(amount),
                online_amount=amount,
                method=payment_method,
                status='pending',
            )

        callback_url = _payment_callback_url(request)
        result = ZarinpalService.create_payment(
            int(toman_to_rial(amount)),
            f'افزایش اعتبار - درخواست #{temp_request.id}',
            callback_url,
            {'mobile': request.user.username,
             'email': request.user.email or ''})
        if result['success']:
            payment.authority = result['authority']
            payment.save(update_fields=['authority'])
            return Response({
                'success': True,
                'message': 'لطفاً پرداخت را از طریق درگاه انجام دهید.',
                'payment_id': payment.id,
                'payment_url': result['payment_url'],
                'authority': result['authority'],
                'status': 'pending'
            })

        payment.status = 'failed'
        payment.save(update_fields=['status'])
        # درخواست موقتِ واریز بی‌استفاده شد؛ در لیست‌ها نماند.
        temp_request.status = 'cancelled'
        temp_request.save(update_fields=['status'])
        return Response({'error': result['error']}, status=500)

    except Exception:
        logger.exception("request_credit_deposit failed")
        return Response(
            {'error': 'خطای داخلی سرور. لطفاً دوباره تلاش کنید.'}, status=500)




# ============================================================
# upload_deposit_receipt
# ============================================================
@api_view(['POST'])
@permission_classes([IsAuthenticated])
def upload_deposit_receipt(request):
    try:
        payment_id = request.data.get('payment_id')
        if not payment_id:
            return Response(
                {'error': 'شناسه پرداخت وارد نشده است.'}, status=400)

        try:
            payment = Payment.objects.select_related(
                'inspection_request', 'method').get(id=payment_id)
        except (Payment.DoesNotExist, ValueError, TypeError):
            return Response({'error': 'پرداخت یافت نشد.'}, status=404)
        if payment.inspection_request.customer != request.user and not is_admin_user(request.user):
            return Response({'error': 'دسترسی غیرمجاز.'}, status=403)

        # EDRA v35: فقط پرداخت «دستی». قبلاً مشتری می‌توانست روی یک پرداخت
        # آنلاینِ در حال انتظار فیش بگذارد و آن را به pending_verification ببرد
        # (و ادمین را به تایید پرداختی که در درگاه انجام نشده بکشاند).
        if payment.method.name != 'manual':
            return Response(
                {'error': 'آپلود فیش فقط برای پرداخت دستی مجاز است.'}, status=400)

        if payment.status not in ['pending', 'pending_verification']:
            return Response(
                {'error': 'این پرداخت در وضعیت قابل آپلود نیست.'}, status=400)

        receipt_file = request.FILES.get('receipt_file')
        if not receipt_file:
            return Response({'error': 'فایل فیش ارسال نشده است.'}, status=400)

        file_error = _validate_receipt_file(receipt_file)
        if file_error:
            return Response({'error': file_error}, status=400)

        file_path, digest = _save_receipt_file(
            receipt_file, request.user.id)
        with transaction.atomic():
            payment = Payment.objects.select_for_update().get(pk=payment.pk)
            if payment.status not in ['pending', 'pending_verification']:
                try:
                    default_storage.delete(file_path)
                except Exception:
                    pass
                return Response(
                    {'error': 'این پرداخت در وضعیت قابل آپلود نیست.'}, status=400)
            payment.bank_receipt = file_path
            payment.bank_receipt_uploaded_at = timezone.now()
            payment.bank_receipt_hash = digest
            payment.status = 'pending_verification'
            payment.save()

        for admin in get_admin_users():
            try:
                send_notification(admin, 'payment_manual_upload', {
                    'request_id': payment.inspection_request.id,
                    'payment_id': payment.id,
                    'customer': request.user.username,
                    'amount': str(payment.amount)
                })
            except Exception as e:
                logger.error(f"Error sending admin notification: {e}")

        return Response({
            'success': True,
            'message': 'فیش با موفقیت آپلود شد. پس از تأیید مدیر، پرداخت شما تکمیل می‌شود.',
            'status': 'pending_verification'
        })
    except Exception:
        logger.exception("upload_deposit_receipt failed")
        return Response(
            {'error': 'خطای داخلی سرور. لطفاً دوباره تلاش کنید.'}, status=500)


# ============================================================
# verify_deposit_payment
# ============================================================
@api_view(['POST'])
@permission_classes([IsAdminUserOrGroup])
def verify_deposit_payment(request, payment_id):
    """
    تایید پرداخت در انتظار (فیش دستی / پرداخت اعتباری / واریز اعتبار).

    EDRA v35 — ریشه‌ای: این view منطق تسویه را کپی کرده بود و «بدون قفل» اجرا
    می‌شد؛ دو ادمین (یا دو کلیک) همزمان هر دو از بررسی وضعیت رد می‌شدند و در
    واریز اعتبار، موجودی کاربر دو بار زیاد می‌شد. اکنون تنها مسیر رسمی و
    قفل‌دار تسویه (settle_admin_payment) صدا زده می‌شود.
    """
    from ..services.payment_service import settle_admin_payment
    try:
        payment = Payment.objects.select_related(
            'inspection_request').get(id=payment_id)
    except Payment.DoesNotExist:
        return Response({'error': 'پرداخت یافت نشد.'}, status=404)

    if payment.status != 'pending_verification':
        return Response(
            {'error': 'این پرداخت در وضعیت انتظار تأیید نیست.'}, status=400)

    try:
        payment = settle_admin_payment(payment, verified_by=request.user)
    except ValueError as e:
        return Response({'error': str(e)}, status=400)
    except Exception:
        logger.exception("Error in verify_deposit_payment")
        return Response(
            {'error': 'خطای داخلی سرور در تایید پرداخت.'}, status=500)

    inspection_request = InspectionRequest.objects.get(
        pk=payment.inspection_request_id)
    params = inspection_request.params
    if isinstance(params, dict) and params.get('is_deposit'):
        balance = UserCredit.objects.get(
            user=inspection_request.customer).balance
        return Response({
            'success': True,
            'message': f'پرداخت تأیید شد و مبلغ {payment.amount:,} تومان به اعتبار کاربر اضافه شد.',
            'new_balance': balance
        })
    return Response({
        'success': True,
        'message': f'پرداخت تأیید شد. درخواست #{inspection_request.id} به وضعیت زمان‌بندی شده تغییر یافت. فاکتور در حال تولید است.',
        'request_status': inspection_request.status
    })


# ============================================================
# reject_payment
# ============================================================
@api_view(['POST'])
@permission_classes([IsAdminUserOrGroup])
def reject_payment(request, payment_id):
    """
    رد پرداخت در انتظار تایید.

    EDRA v35: (۱) با قفل ردیف؛ رد همزمان دو بار اجرا نشود. (۲) شاخه‌ی
    «اگر رزرو فعال نبود، credit_amount را به موجودی اضافه کن» حذف شد: اعتبار
    فقط هنگام «مصرف» (تایید) از موجودی کم می‌شود؛ پرداختِ در انتظار هرگز
    چیزی کم نکرده، پس برگرداندن آن = اعتبار رایگان (مثلاً وقتی رزرو قبلاً
    آزاد شده بود). فقط رزرو آزاد می‌شود.
    """
    rejection_reason = (
        request.data.get('rejection_reason') or '').strip() or 'دلیل مشخص نشده است.'
    try:
        with transaction.atomic():
            try:
                payment = Payment.objects.select_for_update().get(
                    id=payment_id)
            except Payment.DoesNotExist:
                return Response({'error': 'پرداخت یافت نشد.'}, status=404)
            if payment.status != 'pending_verification':
                return Response(
                    {'error': 'این پرداخت در وضعیت انتظار تأیید نیست.'}, status=400)

            payment.status = 'rejected'
            payment.rejected_by = request.user
            payment.rejected_at = timezone.now()
            payment.rejection_reason = rejection_reason
            payment.save()

            inspection_request = payment.inspection_request
            user = inspection_request.customer

            CreditService.release_for_payment(payment)

            # «درخواست» موقت واریز اعتبارِ ردشده در لیست‌ها نماند.
            params = inspection_request.params
            if isinstance(params, dict) and params.get('is_deposit'):
                inspection_request.status = 'cancelled'
                inspection_request.save(update_fields=['status'])

        # EDRA v33: اعلان بعد از commit و فقط یک‌بار.
        try:
            send_notification(user, 'payment_rejected', {
                'request_id': inspection_request.id,
                'reason': rejection_reason,
                'payment_id': payment.id
            })
        except Exception as e:
            logger.error(f"Error sending rejection notification: {e}")

        return Response({
            'success': True,
            'message': 'فیش با موفقیت رد شد. پیامک و نوتیفیکیشن برای مشتری ارسال شد.',
            'status': 'rejected'
        })
    except Exception:
        logger.exception("Error in reject_payment")
        return Response(
            {'error': 'خطای داخلی سرور در رد پرداخت.'}, status=500)

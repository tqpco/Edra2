# core/views/dashboard_views.py
import json
from decimal import Decimal
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated
from django.db.models import Count, Sum
from django.utils import timezone
from django.core.cache import cache
import logging

from core.permissions import IsAdminUserOrGroup
from ..models import InspectionRequest, InspectionReport, Payment, UserCredit
from ..serializers import InspectionRequestSerializer, InspectionReportSerializer
from edra_jalalidate import to_jalali

logger = logging.getLogger(__name__)


def _safe_decimal_to_float(value):
    """تبدیل ایمن Decimal به float (با حفظ دقت تا ۲ رقم اعشار)"""
    if value is None:
        return 0.0
    if isinstance(value, Decimal):
        return float(value.quantize(Decimal('0.01')))
    if isinstance(value, (int, float)):
        return float(value)
    try:
        return float(value)
    except (TypeError, ValueError):
        return 0.0


# ============================================================
# AdminDashboardStatsView با کش کردن آمار
# ============================================================
class AdminDashboardStatsView(APIView):
    permission_classes = [IsAdminUserOrGroup]

    def get(self, request):
        cache_key = 'admin_dashboard_stats'
        stats = cache.get(cache_key)

        if stats is None:
            try:
                from django.contrib.auth import get_user_model
                User = get_user_model()
                now = timezone.now()
                # EDRA v35: «این ماه» در پنل فارسی = ماه «جلالی» به وقت محلی
                # (قبلاً اول ماه میلادی به وقت UTC بود).
                try:
                    from edra_jalalidate import JalaliDateTime
                    _jn = JalaliDateTime.from_datetime(timezone.localtime(now))
                    _start = JalaliDateTime(_jn.year, _jn.month, 1).to_datetime()
                    month_start = (timezone.make_aware(_start)
                                   if timezone.is_naive(_start) else _start)
                except Exception:
                    month_start = now.replace(
                        day=1, hour=0, minute=0, second=0, microsecond=0)
                # پرداخت‌های «افزایش اعتبار» درآمد نیستند (بدهی به مشتری‌اند).
                real_payments = Payment.objects.exclude(
                    inspection_request__params__is_deposit=True)

                # EDRA v27 — رفع باگ ریشه‌ای (گزارش کاربر، سپتامبر ۲۰۲۶):
                # افزایش اعتبار آنلاین یک InspectionRequest موقت با
                # params.is_deposit=True می‌سازد (برای اتصال Payment).
                # این رکوردهای ساختگی نباید در آمار «تعداد درخواست‌ها»/
                # «فعالیت اخیر» بیایند — چون آمار پرداخت/درآمد باید همچنان
                # این پرداخت‌های واقعی را بشمارد، فقط queryset درخواست‌ها
                # فیلتر می‌شود، نه Payment.
                real_requests = InspectionRequest.objects.exclude(
                    params__is_deposit=True)

                stats = {
                    'totalRequests': real_requests.count(),
                    'totalPayments': real_payments.filter(status='paid').count(),
                    'totalUsers': User.objects.count(),
                    'totalReports': InspectionReport.objects.count(),
                    'pendingRequests': real_requests.filter(status='pending_payment').count(),
                    'completedRequests': real_requests.filter(status='completed').count(),
                    'revenueThisMonth': real_payments.filter(
                        status='paid', created_at__gte=month_start
                    ).aggregate(total=Sum('amount'))['total'] or Decimal('0'),
                    'recentActivities': [
                        {
                            'id': r.id,
                            'created_at': r.created_at.isoformat() if r.created_at else None,
                            'customer__username': r.customer.username if r.customer else None
                        }
                        for r in real_requests.select_related('customer')
                        .order_by('-created_at')[:5]
                    ],
                }

                stats['revenueThisMonth'] = _safe_decimal_to_float(stats['revenueThisMonth'])
                # EDRA v35: ۱ ساعت کش یعنی ادمین بعد از هر پرداخت تا یک ساعت
                # عدد قدیمی می‌دید؛ ۶۰ ثانیه برای ۲۰۰ کاربر همزمان کافی است.
                cache.set(cache_key, stats, 60)
            except Exception as e:
                logger.error(f"Error calculating admin dashboard stats: {e}")
                stats = {
                    'totalRequests': 0,
                    'totalPayments': 0,
                    'totalUsers': 0,
                    'totalReports': 0,
                    'pendingRequests': 0,
                    'completedRequests': 0,
                    'revenueThisMonth': 0.0,
                    'recentActivities': [],
                }

        for activity in stats.get('recentActivities', []):
            if activity.get('created_at') and not isinstance(activity['created_at'], str):
                activity['created_at'] = str(activity['created_at'])
            if activity.get('created_at'):
                activity['timestamp'] = activity['created_at']
                activity['action'] = f'درخواست جدید #{activity["id"]} توسط {activity.get("customer__username", "کاربر")}'
                activity['user'] = activity.get('customer__username', 'کاربر')

        return Response(stats)


# ============================================================
# CustomerDashboardView
# ============================================================
class CustomerDashboardView(APIView):
    permission_classes = [IsAuthenticated]

    def get(self, request):
        user = request.user
        if not user or not user.is_authenticated:
            return self._guest_response()

        try:
            # EDRA v36: «درخواست»های موقتِ افزایش اعتبار (params.is_deposit) درخواست
            # بازرسی نیستند؛ قبلاً در شمارنده‌ها و «درخواست‌های اخیر» مشتری
            # (به‌صورت «واریز اعتبار») ظاهر می‌شدند. وضعیت‌های assigned/rescheduled/
            # waiting_manual_payment هم «فعال» حساب نمی‌شدند.
            real_requests = InspectionRequest.objects.filter(
                customer=user).exclude(params__is_deposit=True)
            total_requests = real_requests.count()
            active_requests = real_requests.filter(
                status__in=['pending_payment', 'waiting_manual_payment', 'paid',
                            'assigned', 'scheduled', 'rescheduled', 'in_progress']
            ).count()
            approved_reports = InspectionReport.objects.filter(
                inspection_request__customer=user,
                pdf_file__isnull=False
            ).count()

            try:
                credit = UserCredit.objects.get(user=user)
                balance = credit.balance
            except UserCredit.DoesNotExist:
                balance = Decimal('0')

            recent_requests = real_requests.select_related(
                'equipment_type').order_by('-created_at')[:5]

            next_inspection = real_requests.filter(
                status__in=['scheduled', 'assigned', 'rescheduled'],
                scheduled_at__isnull=False,
            ).order_by('scheduled_at').first()

            return Response({
                'total_requests': total_requests,
                'active_requests': active_requests,
                'approved_reports': approved_reports,
                'credit': _safe_decimal_to_float(balance),
                'user': {
                    'id': user.id,
                    'username': user.username,
                    'full_name': user.get_full_name() or user.username,
                },
                'recent_requests': [
                    {
                        'id': r.id,
                        'request_number': r.request_number,
                        'equipment': r.equipment_type.name_fa if r.equipment_type_id else None,
                        'status': r.status,
                        'final_price': _safe_decimal_to_float(r.final_price),
                        'created_at_jalali': to_jalali(r.created_at, fmt="%Y/%m/%d - %H:%M"),
                    }
                    for r in recent_requests
                ],
                'next_inspection': {
                    'id': next_inspection.id,
                    'request_number': next_inspection.request_number,
                    'scheduled_at_jalali': to_jalali(next_inspection.scheduled_at, fmt="%Y/%m/%d - %H:%M"),
                    'address': next_inspection.address,
                } if next_inspection else None,
            })
        except Exception as e:
            logger.error(f"Error in CustomerDashboardView for user {user.id}: {e}")
            return self._guest_response(user)

    def _guest_response(self, user=None):
        return Response({
            'total_requests': 0,
            'active_requests': 0,
            'approved_reports': 0,
            'credit': 0,
            'user': {
                'id': user.id if user else None,
                'username': user.username if user else 'میهمان',
                'full_name': user.get_full_name() or user.username if user else 'میهمان',
            },
            'recent_requests': [],
            'next_inspection': None,
        })


# ============================================================
# ExpertDashboardView
# ============================================================
class ExpertDashboardView(APIView):
    permission_classes = [IsAuthenticated]

    def get(self, request):
        user = request.user
        if not user.is_staff and not user.groups.filter(name='Expert').exists():
            return Response({'error': 'دسترسی غیرمجاز'}, status=403)

        if not user or not user.is_authenticated:
            return Response({
                'total_assigned': 0,
                'pending_inspections': 0,
                'completed_reports': 0,
                'user': {
                    'id': None,
                    'username': 'میهمان',
                    'full_name': 'میهمان',
                }
            })

        own = InspectionRequest.objects.filter(
            assigned_expert=user).exclude(params__is_deposit=True)
        total_assigned = own.count()
        pending_inspections = own.filter(status='in_progress').count()
        # فقط گزارش‌های نهایی‌شده (قبلاً گزارش خالی/در حال تکمیل هم شمرده می‌شد)
        completed_reports = InspectionReport.objects.filter(
            inspection_request__assigned_expert=user
        ).exclude(overall_result='pending').count()

        # EDRA v34: مرز «امروز» به وقت محلی (Asia/Tehran)؛ قبلاً نیمه‌شب UTC
        # بود و بین ۰۰:۰۰ تا ۰۳:۳۰ تهران کارهای «دیروز» به‌عنوان «امروز» نشان
        # داده می‌شدند.
        now = timezone.localtime(timezone.now())
        today_start = now.replace(hour=0, minute=0, second=0, microsecond=0)
        today_end = today_start + timezone.timedelta(days=1)

        todays_tasks = InspectionRequest.objects.filter(
            assigned_expert=user,
            status__in=['assigned', 'scheduled', 'rescheduled', 'in_progress'],
            scheduled_at__gte=today_start,
            scheduled_at__lt=today_end,
        ).select_related('equipment_type').order_by('scheduled_at')

        upcoming_tasks = InspectionRequest.objects.filter(
            assigned_expert=user,
            status__in=['assigned', 'scheduled', 'rescheduled'],
            scheduled_at__gte=today_end,
        ).select_related('equipment_type').order_by('scheduled_at')[:5]

        def _serialize_task(r):
            return {
                'id': r.id,
                'request_number': r.request_number,
                'equipment': r.equipment_type.name_fa if r.equipment_type_id else None,
                'status': r.status,
                'scheduled_at_jalali': to_jalali(r.scheduled_at, fmt="%Y/%m/%d - %H:%M") if r.scheduled_at else None,
                'address': r.address,
                'city': r.city,
            }

        return Response({
            'total_assigned': total_assigned,
            'pending_inspections': pending_inspections,
            'completed_reports': completed_reports,
            'user': {
                'id': user.id,
                'username': user.username,
                'full_name': user.get_full_name() or user.username,
            },
            'todays_tasks': [_serialize_task(r) for r in todays_tasks],
            'upcoming_tasks': [_serialize_task(r) for r in upcoming_tasks],
        })


# ============================================================
# CustomerRequestsView
# ============================================================
class CustomerRequestsView(APIView):
    permission_classes = [IsAuthenticated]

    def get(self, request):
        from ..serializers import InspectionRequestSerializer
        requests = InspectionRequest.objects.filter(
            customer=request.user
        ).exclude(params__is_deposit=True).select_related(
            'equipment_type', 'assigned_expert', 'discount_code'
        ).order_by('-created_at')
        serializer = InspectionRequestSerializer(requests, many=True)
        return Response(serializer.data)


# ============================================================
# CustomerReportsView
# ============================================================
class CustomerReportsView(APIView):
    permission_classes = [IsAuthenticated]

    def get(self, request):
        # EDRA v34: FileField خالی در DB رشته‌ی '' است (نه NULL)، پس
        # pdf_file__isnull=False همه‌ی گزارش‌ها (حتی بدون PDF و حتی گزارش
        # خالیِ «در حال انجام») را برمی‌گرداند. حالا فقط گزارش نهایی‌شده‌ی
        # درخواست تکمیل‌شده؛ و با سریالایزر محدود مشتری (بدون GPS/هش امضا).
        from inspections.serializers import CustomerInspectionReportSerializer
        queryset = InspectionReport.objects.filter(
            inspection_request__customer=request.user,
            inspection_request__status='completed',
            overall_result__in=['pass', 'fail', 'conditional'],
        ).select_related(
            'inspection_request', 'inspection_request__equipment_type',
            'verification')

        inspection_request_id = request.query_params.get('inspection_request')
        if inspection_request_id:
            queryset = queryset.filter(inspection_request_id=inspection_request_id)

        reports = queryset.order_by('-created_at')
        serializer = CustomerInspectionReportSerializer(reports, many=True)
        return Response(serializer.data)
# core/views/discount_views.py
from decimal import Decimal
from django.utils import timezone
from django.db import models
from rest_framework import viewsets, status, filters
from rest_framework.decorators import action
from rest_framework.response import Response
from rest_framework.throttling import ScopedRateThrottle
from rest_framework.permissions import IsAuthenticated, AllowAny
from rest_framework.views import APIView
from django_filters.rest_framework import DjangoFilterBackend

from core.permissions import IsAdminUserOrGroup
from core.models import DiscountCode, InspectionRequest, EquipmentType
from core.serializers import DiscountCodeSerializer, PublicDiscountCodeSerializer
from core.filters import DiscountCodeFilter
from core.services.discount_service import compute_discount_amount, validate_discount


class DiscountCodeViewSet(viewsets.ModelViewSet):
    queryset = DiscountCode.objects.all()
    serializer_class = DiscountCodeSerializer
    permission_classes = [IsAdminUserOrGroup]
    filter_backends = [DjangoFilterBackend, filters.SearchFilter, filters.OrderingFilter]
    filterset_class = DiscountCodeFilter
    search_fields = ['code', 'description']
    ordering_fields = ['code', 'value', 'used_count']
    ordering = ['code']

    @action(detail=False, methods=['post'], permission_classes=[IsAuthenticated])
    def apply(self, request):
        code = request.data.get('code')
        request_id = request.data.get('request_id')
        amount = request.data.get('amount', 0)
        equipment_type_id = request.data.get('equipment_type_id')

        if not code:
            return Response({'error': 'کد تخفیف را وارد کنید.'}, status=status.HTTP_400_BAD_REQUEST)

        equipment_type = None
        if request_id:
            try:
                inspection_request = InspectionRequest.objects.get(id=request_id, customer=request.user)
            except InspectionRequest.DoesNotExist:
                return Response({'error': 'درخواست یافت نشد.'}, status=404)
            # EDRA v35: پایه‌ی تخفیف قیمت «قبل از تخفیف» است؛ با final_price
            # پیش‌نمایش روی درخواستِ دارای کد، تخفیف را دو بار حساب می‌کرد.
            amount = (inspection_request.calculated_price
                      or inspection_request.final_price)
            equipment_type = inspection_request.equipment_type

        from ..services.discount_service import find_discount
        discount = find_discount(code)
        if discount is None:
            return Response({'error': 'کد تخفیف نامعتبر است.'}, status=status.HTTP_400_BAD_REQUEST)

        error = validate_discount(
            discount, amount=amount, equipment_type=equipment_type,
            user=request.user,
            exclude_request=inspection_request if request_id else None)
        if error:
            return Response({'error': error}, status=400)

        discount_amount = compute_discount_amount(discount, amount)
        final_price = max(Decimal(str(amount)) - discount_amount, 0)

        return Response({
            'success': True,
            'discount_amount': discount_amount,
            'final_price': final_price,
            'code': discount.code,
            'preview': True,
        })


class CustomerDiscountCodeViewSet(viewsets.ReadOnlyModelViewSet):
    """
    مرور عمومی کدهای تخفیف — فقط کدهای `is_public=True`. EDRA v32 — SEC:
    قبلاً هر کد فعال (از جمله کدهای هدفمند/ریفرال با ظرفیت محدود) با
    سریالایزر کامل ادمین به هر کاربر واردشده نشان داده می‌شد؛ هیچ صفحه‌ای
    هم این endpoint را صدا نمی‌زد (کد مرده‌ی در معرض). رفع شد با: (۱) فیلتر
    صریح is_public، (۲) سریالایزر جدا و محدود بدون فیلدهای مدیریتی.
    """
    permission_classes = [IsAuthenticated]
    serializer_class = PublicDiscountCodeSerializer
    pagination_class = None  # لیست کوچک

    def get_queryset(self):
        now = timezone.now()
        qs = DiscountCode.objects.filter(
            is_active=True,
            is_public=True,
            expires_at__gt=now,
        ).exclude(usage_limit=0)
        # کدهایی که ظرفیت کلی‌شان تمام شده، در مرور عمومی بی‌فایده‌اند
        qs = qs.exclude(usage_limit__isnull=False, used_count__gte=models.F('usage_limit'))
        return qs.order_by('expires_at')


class ValidateDiscountCodeView(APIView):
    permission_classes = [AllowAny]
    # EDRA v27 — رفع باگ امنیتی (تایید ممیزی هوش مصنوعی، سپتامبر ۲۰۲۶):
    # این endpoint بدون rate limit بود — چون AllowAny است (لازم برای
    # اعتبارسنجی کد تخفیف قبل از ورود در ویزارد)، بدون throttle یک مهاجم
    # می‌توانست با حدس سریع، کدهای تخفیف معتبر را کشف کند (reconnaissance).
    throttle_classes = [ScopedRateThrottle]
    throttle_scope = 'discount_validate'

    def post(self, request):
        code = request.data.get('code')
        equipment_type_id = request.data.get('equipment_type_id')
        amount = request.data.get('amount', 0)

        if not code:
            return Response({'valid': False, 'message': 'کد تخفیف وارد نشده است.'}, status=400)

        from ..services.discount_service import find_discount
        discount = find_discount(code, active_only=True)
        if discount is None:
            return Response({'valid': False, 'message': 'کد تخفیف نامعتبر است.'}, status=404)

        equipment_type = None
        if equipment_type_id:
            try:
                equipment_type = EquipmentType.objects.get(id=equipment_type_id)
            except EquipmentType.DoesNotExist:
                pass

        error = validate_discount(
            discount,
            amount=amount,
            equipment_type=equipment_type,
            user=request.user if request.user.is_authenticated else None
        )
        if error:
            return Response({'valid': False, 'message': error}, status=400)

        return Response({
            'valid': True,
            'code': discount.code,
            'discount_type': discount.discount_type,
            'value': discount.value,
            'max_amount': discount.max_amount,
            'min_amount': discount.min_amount,
            'expires_at': discount.expires_at,
        })
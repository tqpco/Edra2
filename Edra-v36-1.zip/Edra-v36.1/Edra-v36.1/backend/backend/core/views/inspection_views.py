# core/views/inspection_views.py
# -*- coding: utf-8 -*-

import logging
from decimal import Decimal

from django.db import transaction
from django.utils import timezone
from django.contrib.auth import get_user_model
from guardian.shortcuts import assign_perm

from rest_framework import viewsets, status, filters, serializers
from rest_framework.decorators import action
from rest_framework.response import Response
from rest_framework.permissions import AllowAny, IsAuthenticated
from rest_framework.throttling import ScopedRateThrottle
from django_filters.rest_framework import DjangoFilterBackend

from drf_spectacular.utils import extend_schema, extend_schema_view, OpenApiResponse

from core.permissions import (
    IsAdminUserOrGroup,
    IsAdminOrHasObjectPermissionForInspectionRequest,
    is_admin_user,
    is_expert_user,
)
from core.models import (
    InspectionRequest,
    Payment,
    PaymentMethod,
    UserCredit,
)
from core.serializers import (
    InspectionRequestSerializer,
    InspectionRequestListSerializer,
    InspectionRequestUpdateSerializer,
)
from core.filters import InspectionRequestFilter
from core.state_machine import get_inspection_request_state_machine, StateMachineError
from core.services.inspection_service import (
    REASSIGNABLE_STATUSES, apply_status_change)
from core.events import Event, EventRegistry
from notifications.services import send_notification
from .base_views import BaseViewSet

User = get_user_model()
logger = logging.getLogger(__name__)


# ============================================================
# InspectionRequestViewSet با بهینه‌سازی کوئری و StateMachine
# ============================================================
@extend_schema_view(
    list=extend_schema(
        summary="لیست درخواست‌های بازرسی",
        description="دریافت لیست درخواست‌های کاربر فعلی (فقط احراز هویت‌شده)"
    ),
    create=extend_schema(
        summary="ایجاد درخواست بازرسی جدید",
        description="ایجاد درخواست بازرسی با اطلاعات دستگاه و آدرس (دسترسی عمومی برای ایجاد)",
        request=InspectionRequestSerializer,
        responses={201: InspectionRequestSerializer}
    ),
    retrieve=extend_schema(
        summary="دریافت جزئیات یک درخواست",
        description="دریافت اطلاعات کامل یک درخواست (فقط احراز هویت‌شده)"
    ),
    update=extend_schema(
        summary="بروزرسانی کامل درخواست",
        description="بروزرسانی همه فیلدهای درخواست (فقط ادمین)"
    ),
    partial_update=extend_schema(
        summary="بروزرسانی جزئی درخواست",
        description="بروزرسانی بخشی از فیلدهای درخواست (فقط ادمین)"
    ),
    destroy=extend_schema(
        summary="حذف درخواست",
        description="حذف یک درخواست (فقط ادمین)"
    ),
)
class InspectionRequestViewSet(BaseViewSet):
    """
    مدیریت درخواست‌های بازرسی
    """
    permission_classes = [IsAuthenticated]
    serializer_class = InspectionRequestSerializer
    queryset = InspectionRequest.objects.all()
    filter_backends = [DjangoFilterBackend, filters.SearchFilter, filters.OrderingFilter]
    filterset_class = InspectionRequestFilter
    search_fields = ['brand_model', 'city', 'address', 'customer__username', 'request_number']
    search_vector_fields = ['brand_model', 'city', 'address', 'customer__username']
    ordering_fields = ['created_at', 'final_price', 'status', 'scheduled_at']
    ordering = ['-created_at']
    list_select_related = ['customer', 'equipment_type', 'assigned_expert', 'project', 'discount_code']
    list_prefetch_related = ['payments', 'invoice']

    def get_serializer_class(self):
        """
        CRITICAL-01: serializer بر اساس اکشن تفکیک می‌شود:
        - list   → InspectionRequestListSerializer (سبک)
        - update/partial_update → InspectionRequestUpdateSerializer که
          فیلدهای workflow (status/assigned_expert/request_number/مبالغ/...)
          را read-only می‌کند؛ تغییر وضعیت فقط از طریق actionهای مشخص.
        - بقیه   → InspectionRequestSerializer (create/retrieve)
        """
        if self.action == 'list':
            return InspectionRequestListSerializer
        if self.action in ('update', 'partial_update'):
            return InspectionRequestUpdateSerializer
        return InspectionRequestSerializer

    def get_permissions(self):
        if self.action == 'create':
            # EDRA v32: ثبت درخواست فقط برای کاربر احراز‌هویت‌شده (مرحله ۴ ویزارد
            # ورود با OTP را اجباری می‌کند). مسیر ناشناس برای هر درخواست یک کاربر
            # guest_* می‌ساخت و به «همه‌ی ادمین‌ها» اعلان/پیامک می‌فرستاد — یعنی
            # ابزار spam و رشد بی‌پایان دیتابیس بدون هیچ استفاده‌ی مشروع.
            return [IsAuthenticated()]
        elif self.action in ['list', 'retrieve']:
            return [IsAuthenticated()]
        elif self.action in ['update', 'partial_update', 'destroy']:
            return [IsAdminOrHasObjectPermissionForInspectionRequest()]
        return super().get_permissions()

    def get_throttles(self):
        # P1-06 (EDRA v8): create عمومی (anonymous) است؛ برای کاهش سوءاستفاده
        # (رشد DB/notification/storage) throttle سخت روی create اعمال می‌شود.
        if self.action == 'create':
            return [ScopedRateThrottle()]
        return super().get_throttles()

    throttle_scope = 'inspection_create'

    def get_queryset(self):
        user = self.request.user

        # ✅ کوئری پایه با select_related و prefetch_related از BaseViewSet
        base_queryset = super().get_queryset()

        # ✅ برای لیست (اکشن list)، فقط فیلدهای ضروری را بارگذاری کن.
        if self.action == 'list':
            base_queryset = base_queryset.only(
                'id', 'status', 'city', 'final_price', 'created_at',
                'brand_model', 'install_state', 'address',
                'customer__username', 'equipment_type__name_fa',
                'assigned_expert__username',
                'project__id', 'project__name',
                'discount_code__id', 'discount_code__code',
            )
            # EDRA v27 — رفع باگ ریشه‌ای (گزارش کاربر، سپتامبر ۲۰۲۶):
            # افزایش اعتبار آنلاین (credit_views.request_credit_deposit)
            # برای اتصال Payment یک InspectionRequest موقت با
            # params={'is_deposit': True} می‌سازد (چون Payment باید به
            # چیزی متصل باشد). این رکوردهای ساختگی («افزایش اعتبار -
            # آنلاین») قبلاً در لیست درخواست‌های واقعی ادمین/کارشناس/
            # مشتری هم نمایش داده می‌شدند — دقیقاً همان «بی‌نظمی» که
            # گزارش شد. حالا از همه‌ی لیست‌ها حذف می‌شوند.
            base_queryset = base_queryset.exclude(params__is_deposit=True)

        # EDRA v6 — P1 (نقش canonical): is_staff هم مثل گروه Admin کامل
        # دیده می‌شود (قبلاً staff بدون گروه Admin queryset مدیریتی نمی‌گرفت
        # ولی در بعضی actionها دسترسی داشت → ناسازگاری).
        if user.is_authenticated:
            if is_admin_user(user):
                return base_queryset
            elif is_expert_user(user):
                return base_queryset.filter(assigned_expert=user)
            else:
                return base_queryset.filter(customer=user)
        return InspectionRequest.objects.none()

    def perform_create(self, serializer):
        try:
            # ثبت درخواست فقط برای کاربر احراز‌هویت‌شده است (get_permissions)؛
            # شاخه‌ی «مهمان» که اینجا بود هرگز اجرا نمی‌شد و حذف شد.
            user = self.request.user
            # EDRA v32 — باگ بحرانی، رفع شد: فیلد customer در سریالایزر
            # read_only است (عمداً — تا یک مشتری عادی نتواند درخواست را
            # به‌نام کاربر دیگری ثبت کند)، و اینجا هم همیشه user همان
            # request.user بود. نتیجه: صفحه‌ی ادمین «ثبت درخواست جدید»
            # (که customer را در بدنه‌ی POST می‌فرستد تا برای یک مشتری
            # انتخاب‌شده ثبت کند) همیشه بی‌صدا نادیده گرفته می‌شد و
            # درخواست به نام خودِ ادمین ثبت می‌شد — مشتری واقعی هرگز آن
            # را در داشبورد خودش نمی‌دید و فاکتور هم به نام ادمین صادر
            # می‌شد. فقط برای ادمین/استاف، اگر customer در بدنه آمده
            # باشد، همان کاربر (در صورت وجود و فعال‌بودن) جایگزین می‌شود.
            is_admin = user.is_staff or user.groups.filter(name='Admin').exists()
            target_customer_id = self.request.data.get('customer')
            if is_admin and target_customer_id:
                try:
                    target_customer = User.objects.get(
                        pk=target_customer_id, is_active=True)
                    user = target_customer
                except (User.DoesNotExist, ValueError, TypeError):
                    raise serializers.ValidationError(
                        {'customer': 'مشتری انتخاب‌شده معتبر نیست.'})
            equipment = serializer.validated_data.get('equipment_type')
            if not equipment:
                raise serializers.ValidationError(
                    {"equipment_type": "نوع تجهیزات الزامی است."}
                )

            params = serializer.validated_data.get('params', {})
            install_state = serializer.validated_data.get('install_state')
            city = serializer.validated_data.get('city')
            brand_model = serializer.validated_data.get('brand_model') or 'نامشخص'
            manufacture_year = serializer.validated_data.get('manufacture_year') or 1400
            if params is None:
                params = {}

            service_type = self.request.data.get('service_type', 'standard')
            if service_type not in ('standard', 'pro'):
                raise serializers.ValidationError(
                    {'service_type': 'سطح سرویس نامعتبر است.'})
            params['service_type'] = service_type

            try:
                from pricing.utils import calculate_price_with_rounding_info
                price_info = calculate_price_with_rounding_info(
                    equipment_type=equipment,
                    params=params,
                    install_state=install_state,
                    city_name=city,
                    service_type=service_type
                )
                final_price = price_info['rounded_total']
                exact_price = price_info['exact_total']
                rounding_discount = price_info['rounding_discount']
            except ImportError:
                # EDRA v32: رفع یک NameError نهفته (جدا از اصلاح بالا) — این مسیر
                # فقط وقتی اجرا می‌شود که ماژول pricing.utils اصلاً import نشود
                # (تقریباً هرگز در استقرار سالم). کد اصلی هم در این حالت final_price
                # را ۱ میلیون می‌گذاشت، اما چند خط پایین‌تر به price_info['components']
                # برای PriceCalculationLog نیاز دارد که در این شاخه هرگز ساخته
                # نمی‌شد — یعنی اگر این مسیر نادر فعال می‌شد، به‌جای افتادن روی
                # fallback، کل درخواست با NameError شکست می‌خورد.
                final_price = Decimal(1000000)
                exact_price = Decimal(1000000)
                rounding_discount = Decimal('0')
                price_info = {
                    'rounded_total': final_price,
                    'exact_total': exact_price,
                    'rounding_discount': rounding_discount,
                    'components': {
                        'base_price': final_price, 'param_total': Decimal(0),
                        'param_details': {}, 'city_cost': Decimal(0),
                        'city_multiplier': Decimal('1.0'),
                        'service_multiplier': Decimal('1.0'),
                        'install_cost': Decimal(0),
                    },
                }

            # EDRA v32 — اصلاحِ یک تشخیص نادرست در دور قبل: اینجا فکر کرده بودم
            # چون calculated_price/final_price به serializer.save() پاس داده
            # نمی‌شوند، همه‌ی درخواست‌ها با قیمت ثابت ۱,۰۰۰,۰۰۰ تومان ذخیره
            # می‌شوند. غلط بود: InspectionRequestSerializer._create_atomic() از قبل
            # calculated_price/final_price/price_breakdown را خودش با
            # calculate_price_with_components (و منطق تخفیف) محاسبه و در همان
            # متد، درست قبل از super().create()، در validated_data می‌نویسد —
            # یعنی هرچه اینجا در kwargs پاس داده شود override می‌شود. عمداً اینجا
            # آن‌ها را دوباره پاس نمی‌دهیم تا یک منبع محاسبه داشته باشیم (سریالایزر)
            # و این دو مسیر دچار واگرایی نشوند.
            instance = serializer.save(
                customer=user,
                status='pending_payment',
                brand_model=brand_model,
                manufacture_year=manufacture_year,
                params=params,
            )

            # ذخیره لاگ محاسبه قیمت
            try:
                from pricing.models import PriceCalculationLog
                PriceCalculationLog.objects.create(
                    inspection_request=instance,
                    rule_version=instance.equipment_type.pricing_rule if hasattr(
                        instance.equipment_type, 'pricing_rule'
                    ) else None,
                    calculated_price=instance.final_price,
                    params_used={
                        **params,
                        'exact_price': float(exact_price),
                        'rounding_discount': float(rounding_discount),
                        'rounding_method': 'nearest_100000'
                    },
                    service_type=service_type,
                    city_multiplier=price_info['components'].get(
                        'city_multiplier', Decimal('1.0')
                    ),
                    install_state=install_state,
                )
            except Exception as log_error:
                logger.error(f"PriceCalculationLog create failed: {log_error}")

            assign_perm('view_inspectionrequest', user, instance)
            assign_perm('change_inspectionrequest', user, instance)

            if instance.assigned_expert:
                assign_perm(
                    'view_inspectionrequest',
                    instance.assigned_expert,
                    instance
                )
                assign_perm(
                    'change_inspectionrequest',
                    instance.assigned_expert,
                    instance
                )

            # ارسال رویداد
            EventRegistry.dispatch(Event('inspection_request_created', {'instance': instance, 'actor': user}))

            # EDRA v32: اعلان‌ها async (Celery) — بدون بلاک‌کردن thread درخواست.
            # اگر broker (Redis) در دسترس نبود، به ارسال sync برمی‌گردیم تا
            # اعلان گم نشود.
            try:
                from core.tasks import notify_request_created_task, notify_request_created
                try:
                    notify_request_created_task.delay(instance.id, user.id)
                except Exception as broker_error:
                    logger.warning(
                        f"Celery broker unavailable, sending notifications inline: {broker_error}")
                    notify_request_created(instance.id, user.id)
            except Exception as e:
                logger.error(f"Error sending notification: {e}")

        except Exception as e:
            logger.error(f"Error in perform_create: {e}")
            raise

    def destroy(self, request, *args, **kwargs):
        # EDRA v36: حذف درخواستِ دارای پرداخت/فاکتور/عودت (FK ها PROTECT) قبلاً
        # ProtectedError و خطای ۵۰۰ می‌داد؛ پیام روشن و ۴۰۰ برگردانده می‌شود.
        from django.db.models import ProtectedError
        try:
            return super().destroy(request, *args, **kwargs)
        except ProtectedError:
            return Response(
                {'error': 'این درخواست دارای پرداخت، فاکتور یا عودت است و قابل '
                          'حذف نیست؛ در صورت نیاز آن را لغو کنید.'},
                status=status.HTTP_400_BAD_REQUEST)

    def perform_update(self, serializer):
        # EDRA v32 — باگ واقعی مشابهِ ساخت درخواست، این‌بار در ویرایش: صفحه‌ی
        # admin/requests/[id]/edit یک انتخاب‌گر کاملاً تعاملی برای «مشتری»
        # نشان می‌دهد (جست‌وجو، انتخاب، تأیید روی صفحه، دکمه‌ی ذخیره) ولی چون
        # customer در InspectionRequestUpdateSerializer.read_only_fields است،
        # تغییر همیشه بی‌صدا نادیده گرفته می‌شد — ادمین فکر می‌کرد مشتری را
        # عوض کرده، در حالی که هیچ تغییری ذخیره نشده بود. برخلاف
        # assigned_expert/discount_code (که اکشن‌های اختصاصی‌شان side effect
        # های مهمی مثل اعلان/مصرف اتمیک کد تخفیف دارند و عمداً از این مسیر
        # بسته می‌مانند)، برای customer هیچ مسیر اختصاصی دیگری در کل پروژه
        # وجود ندارد؛ پس همان الگوی perform_create اینجا هم اعمال شد.
        instance = serializer.instance
        user = self.request.user
        is_admin = user.is_staff or user.groups.filter(name='Admin').exists()
        target_customer_id = self.request.data.get('customer')
        # EDRA v34: تغییر زمان بازرسیِ یک درخواست «scheduled» → وضعیت
        # «rescheduled» (قبلاً هیچ کدی این وضعیت را نمی‌ساخت؛ تغییر زمان هم
        # برای ادمین در PROTECTED_AFTER_PAID بسته بود). سیگنال post_save
        # مشتری و کارشناس را خبر می‌کند.
        new_schedule = serializer.validated_data.get('scheduled_at', None)
        if (new_schedule is not None and instance.status == 'scheduled'
                and new_schedule != instance.scheduled_at):
            serializer.validated_data['status'] = 'rescheduled'
        if is_admin and target_customer_id and str(target_customer_id) != str(instance.customer_id):
            try:
                new_customer = User.objects.get(pk=target_customer_id, is_active=True)
            except (User.DoesNotExist, ValueError, TypeError):
                raise serializers.ValidationError(
                    {'customer': 'مشتری انتخاب‌شده معتبر نیست.'})
            old_customer = instance.customer
            updated = serializer.save(customer=new_customer)
            # انتقال مجوزهای سطح‌شیء guardian همراه با انتقال مالکیت
            try:
                from guardian.shortcuts import assign_perm, remove_perm
                if old_customer:
                    remove_perm('view_inspectionrequest', old_customer, updated)
                    remove_perm('change_inspectionrequest', old_customer, updated)
                assign_perm('view_inspectionrequest', new_customer, updated)
                assign_perm('change_inspectionrequest', new_customer, updated)
            except Exception as perm_error:
                logger.error(f"Error transferring guardian perms on customer change: {perm_error}")
        else:
            serializer.save()

    @extend_schema(summary="تخصیص کارشناس به درخواست",
                   description="تخصیص یک کارشناس به درخواست (فقط ادمین)",
                   request={'application/json': {'type': 'object',
                                                 'properties': {'expert_id': {'type': 'integer',
                                                                              'description': 'شناسه کاربر کارشناس'}},
                                                 'required': ['expert_id']}},
                   responses={200: OpenApiResponse(description='کارشناس با موفقیت تخصیص داده شد'),
                              400: OpenApiResponse(description='خطا در درخواست'),
                              404: OpenApiResponse(description='کارشناس یافت نشد')})
    @action(detail=True, methods=['post'],
            permission_classes=[IsAdminUserOrGroup])
    def assign_expert(self, request, pk=None):
        """
        تخصیص/تعویض کارشناس.

        EDRA v34: فقط در وضعیت‌هایی که هنوز بازرسی انجام نشده
        (paid/assigned/scheduled/rescheduled) و بدون گزارش؛ قبلاً برای
        درخواست لغوشده/منقضی/تکمیل‌شده/پرداخت‌نشده هم کارشناس تخصیص داده و
        اعلان ارسال می‌شد. کارشناس باید فعال باشد؛ ردیف قفل می‌شود؛ ذخیره با
        update_fields (نه save کامل)؛ کارشناس قبلی از مجوزها حذف و مطلع می‌شود.
        """
        from ..models import InspectionReport
        instance = self.get_object()
        expert_id = request.data.get('expert_id')
        if not expert_id:
            return Response({'error': 'شناسه کارشناس الزامی است.'}, status=400)
        try:
            expert_id = int(expert_id)
        except (TypeError, ValueError):
            return Response({'error': 'شناسه کارشناس نامعتبر است.'}, status=400)
        expert = User.objects.filter(
            id=expert_id, groups__name='Expert', is_active=True).first()
        if expert is None:
            return Response(
                {'error': 'کاربر انتخاب‌شده کارشناسِ فعال نیست.'}, status=400)

        with transaction.atomic():
            locked = type(instance).objects.select_for_update().get(
                pk=instance.pk)
            if locked.status not in REASSIGNABLE_STATUSES:
                label = dict(locked.STATUS_CHOICES).get(
                    locked.status, locked.status)
                return Response(
                    {'error': f'در وضعیت «{label}» امکان تخصیص کارشناس وجود '
                              f'ندارد.'}, status=400)
            if InspectionReport.objects.filter(
                    inspection_request=locked).exists():
                return Response(
                    {'error': 'برای این درخواست گزارش ثبت شده است.'},
                    status=400)
            old_expert = locked.assigned_expert
            if old_expert is not None and old_expert.pk == expert.pk:
                return Response({'message': f'کارشناس {expert.username} '
                                            f'از قبل به این درخواست تخصیص '
                                            f'داده شده است.'})
            locked.assigned_expert = expert
            fields = ['assigned_expert', 'updated_at']
            if locked.status == 'paid':
                locked.status = 'assigned'
                fields.append('status')
            from django.utils import timezone as _tz
            locked.updated_at = _tz.now()
            locked.save(update_fields=fields)

            try:
                from ..models import AuditLog
                AuditLog.objects.create(
                    user=request.user,
                    action='assign_expert',
                    object_id=locked.id,
                    changes={'expert_id': expert.id,
                             'previous_expert_id': old_expert.pk if old_expert else None,
                             'request_id': locked.id}
                )
            except Exception as log_error:
                logger.error(f"Error writing audit log: {log_error}")

            assign_perm('view_inspectionrequest', expert, locked)
            assign_perm('change_inspectionrequest', expert, locked)
            if old_expert is not None:
                try:
                    from guardian.shortcuts import remove_perm
                    remove_perm('view_inspectionrequest', old_expert, locked)
                    remove_perm('change_inspectionrequest', old_expert, locked)
                except Exception as perm_error:
                    logger.error(f'remove_perm failed: {perm_error}')

            request_id = locked.id
            request_number = locked.request_number
            customer_username = locked.customer.username
        instance.assigned_expert = expert
        instance.status = locked.status

        def _notify():
            try:
                send_notification(expert, 'assigned_to_expert', {
                    'request_id': request_id,
                    'request_number': request_number,
                    'customer': customer_username,
                })
            except Exception as e:
                logger.error(f"Error sending notification: {e}")
        transaction.on_commit(_notify)
        return Response(
            {'message': f'کارشناس {expert.username} به این درخواست تخصیص داده شد.'}
        )

    @extend_schema(
        summary="تغییر وضعیت درخواست با استفاده از StateMachine",
        description="تغییر وضعیت درخواست (فقط ادمین) - تمام transitions از ماشین حالت عبور می‌کنند.",
        request={
            'application/json': {
                'type': 'object',
                'properties': {
                    'status': {
                        'type': 'string',
                        'enum': [
                            'draft', 'pending_payment', 'waiting_manual_payment',
                            'paid', 'assigned', 'scheduled', 'rescheduled',
                            'in_progress', 'completed', 'cancelled', 'expired'
                        ],
                        'description': 'وضعیت جدید'
                    }
                },
                'required': ['status']
            }
        },
        responses={
            200: OpenApiResponse(description='وضعیت با موفقیت تغییر یافت'),
            400: OpenApiResponse(description='وضعیت نامعتبر است')
        }
    )
    @action(detail=True, methods=['post'],
            permission_classes=[IsAdminUserOrGroup])
    def change_status(self, request, pk=None):
        instance = self.get_object()
        new_status = request.data.get('status')
        if new_status not in dict(InspectionRequest.STATUS_CHOICES):
            return Response({'error': 'وضعیت نامعتبر است.'}, status=400)

        # EDRA v35: وضعیت «paid» فقط نتیجه‌ی یک پرداخت واقعی است. قبلاً ادمین
        # می‌توانست درخواست pending_payment را بدون هیچ Payment/فاکتور/ثبت دفتر
        # کل «paid» کند (دور زدن تسویه‌ی مالی). مسیر درست: تایید پرداخت.
        if new_status == 'paid' and not instance.payments.filter(
                status='paid').exists():
            return Response(
                {'error': 'بدون پرداخت تاییدشده نمی‌توان وضعیت را «پرداخت‌شده» کرد؛ '
                          'پرداخت را از بخش پرداخت‌ها تایید کنید.'}, status=400)

        state_machine = get_inspection_request_state_machine()
        old_status = instance.status
        try:
            state_machine.transition(instance, new_status, actor=request.user, old_status=old_status)
        except StateMachineError as e:
            return Response({'error': str(e)}, status=400)

        # ارسال رویداد تغییر وضعیت
        EventRegistry.dispatch(Event('status_changed', {
            'instance': instance,
            'old_status': old_status,
            'new_status': new_status,
            'actor': request.user
        }))

        return Response({'message': f'وضعیت به {new_status} تغییر یافت.'})

    @action(detail=True, methods=['post'], url_path='apply-discount',
            permission_classes=[IsAuthenticated])
    def apply_discount(self, request, pk=None):
        """
        اعمال کد تخفیف روی یک درخواست ساخته‌شده (فقط مالک، فقط pending_payment).

        POST /api/core/inspection-requests/{id}/apply-discount/  {"code": "T10"}
        - idempotent: کد تکراری → بدون تغییر و بدون شمارش دوباره.
        - تعویض کد → کد قبلی آزاد و کد جدید اعمال می‌شود.
        - مبلغ همیشه از calculated_price درخواست (server-side) محاسبه می‌شود.
        """
        from ..services.discount_service import DiscountApplyError, apply_discount_to_request

        try:
            inspection_request = InspectionRequest.objects.get(
                id=pk, customer=request.user
            )
        except InspectionRequest.DoesNotExist:
            return Response({'error': 'درخواست یافت نشد.'}, status=404)

        if inspection_request.status != 'pending_payment':
            return Response(
                {'error': 'در این وضعیت امکان تغییر تخفیف وجود ندارد.'}, status=400
            )

        code = request.data.get('code')
        if not code:
            return Response({'error': 'کد تخفیف را وارد کنید.'}, status=400)

        try:
            discount, discount_amount, new_final_price = apply_discount_to_request(
                inspection_request, code, user=request.user
            )
        except DiscountApplyError as e:
            return Response({'error': str(e)}, status=400)

        return Response({
            'success': True,
            'code': discount.code,
            'discount_amount': discount_amount,
            'final_price': new_final_price,
            'calculated_price': inspection_request.calculated_price,
            'message': f'تخفیف {discount_amount:,} تومان اعمال شد.',
        })

    @action(detail=False, methods=['post'],
            permission_classes=[IsAuthenticated])
    def credit_pay(self, request):
        """
        پرداخت با اعتبار شرکتی.

        EDRA v35: این endpoint قبلاً درخواست را «فوراً paid» می‌کرد و قانون
        کسب‌وکار (v27: پرداخت اعتباری باید منتظر بررسی ادمین بماند) را دور
        می‌زد؛ علاوه بر آن (الف) موجودی را با قیمت «بدون مالیات» می‌سنجید ولی
        مبلغ «با مالیات» رزرو می‌کرد و InsufficientCreditError گرفته نمی‌شد
        (۵۰۰)، (ب) رزرو اعتبار را در نظر نمی‌گرفت. اکنون از همان مسیر واحد
        پرداخت اعتباری (pending_verification + رزرو + قفل) استفاده می‌کند.
        """
        request_id = request.data.get('request_id')
        if not request_id:
            return Response({'error': 'شناسه درخواست الزامی است.'}, status=400)

        from .credit_views import _submit_full_credit_payment
        return _submit_full_credit_payment(request.user, request_id)

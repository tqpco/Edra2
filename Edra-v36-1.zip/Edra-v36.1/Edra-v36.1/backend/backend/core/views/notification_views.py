# core/views/notification_views.py
# -*- coding: utf-8 -*-
from rest_framework import viewsets
from rest_framework.decorators import action
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response

from notifications.models import NotificationLog
from notifications.serializers import NotificationInboxSerializer


# ============================================================
# NotificationViewSet — صندوق اعلان کاربر جاری (هر سه نقش)
# ============================================================
class NotificationViewSet(viewsets.ReadOnlyModelViewSet):
    permission_classes = [IsAuthenticated]
    # EDRA v33 — SEC: سریالایزر محدود (بدون recipient/error_message/user/template)
    serializer_class = NotificationInboxSerializer

    def get_queryset(self):
        qs = NotificationLog.objects.filter(
            user=self.request.user).order_by('-created_at')
        # فیلتر ?is_read=true|false (برای زنگوله: فقط خوانده‌نشده‌ها)
        is_read = self.request.query_params.get('is_read')
        if is_read is not None:
            qs = qs.filter(is_read=is_read.lower() in ('1', 'true', 'yes'))
        return qs

    @action(detail=True, methods=['post'])
    def mark_read(self, request, pk=None):
        # get_object از get_queryset (فقط اعلان‌های خود کاربر) می‌خواند → IDOR ندارد.
        # is_read (نه status که وضعیت تحویل است) به‌روز می‌شود.
        notification = self.get_object()
        if not notification.is_read:
            notification.is_read = True
            notification.save(update_fields=['is_read'])
        return Response({'success': True})

    @action(detail=False, methods=['post'])
    def mark_all_read(self, request):
        NotificationLog.objects.filter(
            user=request.user, is_read=False).update(is_read=True)
        return Response({'success': True})

    @action(detail=False, methods=['get'])
    def unread_count(self, request):
        return Response({'count': NotificationLog.objects.filter(
            user=request.user, is_read=False).count()})

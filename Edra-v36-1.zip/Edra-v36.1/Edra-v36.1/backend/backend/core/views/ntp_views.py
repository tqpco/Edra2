# core/views/ntp_views.py
import datetime
from django.http import JsonResponse
from django.core.cache import cache
from edra_jalalidate.ntp import get_accurate_datetime

# EDRA v27 — قابلیت تازه (گزارش کاربر، سپتامبر ۲۰۲۶): این view قبلاً
# کاملاً نوشته شده بود ولی هرگز در urls.py ثبت نشده بود — یعنی هیچ‌وقت
# در دسترس فرانت‌اند نبود و همیشه به ساعت محلی مرورگر/سیستم برمی‌گشت.
# همچنین: get_accurate_datetime() یک تماس شبکه‌ای مسدودکننده تا ۴ سرور
# NTP (هرکدام timeout=3s) است. توجه: کش‌کردن خودِ datetime مطلق باعث
# می‌شد زمان گزارش‌شده در کل بازه‌ی کش «یخ بزند» (پیش نرود)؛ به‌جایش
# فقط offset بین NTP و ساعت سرور کش می‌شود و هر بار روی ساعت لحظه‌ای
# سرور اعمال می‌گردد — هم سریع (بدون تماس شبکه در اکثر درخواست‌ها) و
# هم درست (زمان واقعاً جلو می‌رود).
def ntp_time_view(request):
    offset_seconds = cache.get('edra_ntp_offset_seconds')
    if offset_seconds is None:
        ntp_dt = get_accurate_datetime()
        offset_seconds = (
            ntp_dt - datetime.datetime.now(datetime.timezone.utc)
        ).total_seconds()
        cache.set('edra_ntp_offset_seconds', offset_seconds, timeout=300)
    accurate_now = datetime.datetime.now(
        datetime.timezone.utc) + datetime.timedelta(seconds=offset_seconds)
    return JsonResponse({'datetime': accurate_now.isoformat()})
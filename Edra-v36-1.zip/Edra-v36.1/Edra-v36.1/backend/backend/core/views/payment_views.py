# core/views/payment_views.py
from decimal import Decimal
import logging

from django.conf import settings
from django.shortcuts import redirect
from django.http import HttpResponse
from django.db import transaction
from django.utils import timezone

from rest_framework import viewsets, status, filters
from rest_framework.decorators import action, api_view, permission_classes, throttle_classes
from rest_framework.response import Response
from rest_framework.permissions import AllowAny, IsAuthenticated
from rest_framework.throttling import UserRateThrottle
from django_filters.rest_framework import DjangoFilterBackend

from core.permissions import IsAdminUserOrGroup, is_admin_user
from core.models import (
    AuditLog, CreditReservation, CreditTransaction, InspectionRequest,
    Invoice, Payment, PaymentMethod, Refund, UserCredit
)
from core.serializers import (
    InvoiceSerializer, PaymentMethodSerializer, PaymentSerializer
)
from core.filters import InvoiceFilter, PaymentFilter
from core.services.payment_service import ZarinpalService
from core.services.money import toman_to_rial
from core.services.credit_service import CreditService, InsufficientCreditError
from core.services.invoice_service import InvoiceSettlementService
from core.services.ledger_service import record_refund
from notifications.services import send_notification
from ..tasks import generate_invoice_pdf_task

logger = logging.getLogger(__name__)


def _payment_callback_url(request):
    """
    EDRA v36.1 — آدرس بازگشت از درگاه.

    باگ: قبلاً `request.build_absolute_uri('/api/core/payment/callback/')` بود.
    درخواست initiate از BFF فرانت (Next.js) به جنگو می‌رسد و Host آن
    `backend:8000` (نام داخلی docker) است؛ پس آدرس بازگشت
    `http://backend:8000/...` می‌شد: برای مرورگر مشتری غیرقابل دسترس و برای
    زرین‌پال (که دامنه‌ی بازگشت را با دامنه‌ی ثبت‌شده تطبیق می‌دهد) نامعتبر.
    تنظیم ZARINPAL_CALLBACK_URL (ساخته‌شده از SITE_URL، طبق .env.example) هم
    هرگز استفاده نمی‌شد. اکنون اگر SITE_URL یا ZARINPAL_CALLBACK_URL در محیط
    تنظیم شده باشد همان استفاده می‌شود؛ در غیر این صورت (توسعه‌ی محلی)
    رفتار قبلی.
    """
    import os
    if os.environ.get('ZARINPAL_CALLBACK_URL') or os.environ.get('SITE_URL'):
        return settings.ZARINPAL_CALLBACK_URL
    return request.build_absolute_uri('/api/core/payment/callback/')


class PaymentInitiateThrottle(UserRateThrottle):
    """
    EDRA v35 — scope='payment_initiate' (نرخ از settings.DEFAULT_THROTTLE_RATES).
    قبلاً `@throttle_classes([ScopedRateThrottle])` + `initiate_payment.
    throttle_scope = ...` استفاده می‌شد؛ ولی @api_view یک تابع تازه برمی‌گرداند
    و صفت روی آن به نمونه‌ی view نمی‌رسد؛ ScopedRateThrottle هم scope=None را
    «بدون محدودیت» می‌گیرد، یعنی throttle پرداخت اصلاً هرگز فعال نبود.
    """
    scope = 'payment_initiate'


# ============================================================
# refund_payment (فلوی عودت — Phase 2 از گزارش ممیزی)
# ============================================================
@api_view(['POST'])
@permission_classes([IsAdminUserOrGroup])
def refund_payment(request, payment_id):
    """
    عودت پرداخت توسط ادمین (idempotent) — P0-7 از گزارش V3:
    شامل: مبلغ ریالی، علت، کاربر انجام‌دهنده، زمان، reference درگاه،
    reversal ledger entry و audit.
    - فقط پرداخت با status='paid' قابل عودت است.
    - سهم اعتباری (credit_amount) بلافاصله به موجودی کاربر برمی‌گردد.
    - سهم آنلاین (online_amount) باید از طریق درگاه (دستی) عودت شود؛
      در دفتر کل به‌عنوان refund ثبت و در گزارش مالی منعکس می‌شود.
    """
    reason = (request.data.get('reason') or '').strip() or 'درخواست ادمین'
    gateway_ref = (request.data.get('gateway_ref') or '').strip()

    # ============================================================
    # EDRA v11 (P1): فراخوانی درگاه (external side-effect) هرگز داخل
    # transaction دیتابیس اجرا نمی‌شود. سه فاز:
    #   ۱) atomic: قفل + ثبت Refund(requested) + بازگشت سهم اعتبار
    #   ۲) خارج از تراکنش: فراخوانی درگاه (بدون lock دیتابیس)
    #   ۳) atomic: ثبت نتیجه درگاه + نهایی‌سازی/خطا
    # این کار ریسک «Gateway=refunded ولی DB=not» را حذف می‌کند.
    # ============================================================
    # فاز ۱ — ثبت عودت (commit می‌شود؛ Refund همیشه قابل رهگیری است)
    with transaction.atomic():
        try:
            payment = Payment.objects.select_for_update().get(id=payment_id)
        except Payment.DoesNotExist:
            return Response({'error': 'پرداخت یافت نشد.'}, status=404)

        if payment.status != 'paid':
            return Response(
                {'error': 'فقط پرداخت‌های موفق قابل عودت هستند.'}, status=400)

        # EDRA v35: «افزایش اعتبار» عودت از این مسیر ندارد. موجودی کاربر با
        # آن پرداخت زیاد شده؛ عودت پول به کارت بدون کم‌کردن موجودی = مشتری هم
        # پول را پس می‌گیرد و هم اعتبارش را نگه می‌دارد.
        _p = payment.inspection_request.params
        if isinstance(_p, dict) and _p.get('is_deposit'):
            return Response(
                {'error': 'عودت پرداخت «افزایش اعتبار» از این مسیر ممکن نیست؛ '
                          'ابتدا موجودی کاربر را اصلاح و عودت را دستی انجام دهید.'},
                status=400)

        # P0 (EDRA v10): جلوگیری از عودت تکراری
        if payment.refunds.filter(
                status__in=['requested', 'gateway_processing',
                            'gateway_refunded', 'completed']).exists():
            return Response(
                {'error': 'برای این پرداخت قبلاً عودت ثبت شده است.'}, status=400)

        user = payment.inspection_request.customer
        gateway_ref = gateway_ref or payment.ref_id or payment.authority or ''

        # EDRA v35: تلاش مجدد بعد از خطای درگاه همان Refund را ادامه می‌دهد.
        # قبلاً gateway_failed در فهرست «عودت تکراری» نبود و هر تلاش مجدد یک
        # Refund تازه می‌ساخت و سهم اعتباری را «دوباره» به موجودی اضافه می‌کرد
        # (دو برابر شدن پول).
        retry_refund = payment.refunds.filter(
            status='gateway_failed').order_by('-id').first()
        credit_already_returned = retry_refund is not None
        if retry_refund is not None:
            refund = retry_refund
            refund.status = 'requested'
            refund.failure_reason = ''
            refund.save(update_fields=['status', 'failure_reason'])
        else:
            refund = Refund.objects.create(
                payment=payment,
                inspection_request=payment.inspection_request,
                customer=user,
                invoice=payment.inspection_request.invoice if hasattr(
                    payment.inspection_request, 'invoice') else None,
                amount_toman=payment.amount,
                amount_rial=payment.amount_rial or toman_to_rial(payment.amount),
                credit_amount=payment.credit_amount or 0,
                online_amount=payment.online_amount or 0,
                reason=reason,
                requested_by=request.user,
                status='requested',
            )

        # سهم اعتباری: بازگشت واقعی به موجودی (حرکت پول واقعی)
        if (not credit_already_returned
                and payment.credit_amount and payment.credit_amount > 0):
            credit, _ = UserCredit.objects.select_for_update().get_or_create(
                user=user)
            credit.balance += payment.credit_amount
            credit.save(update_fields=['balance'])
            CreditTransaction.objects.create(
                user=user,
                amount=payment.credit_amount,
                transaction_type='refund',
                description=(
                    f'عودت سهم اعتباری پرداخت #{payment.id} بابت درخواست '
                    f'#{payment.inspection_request_id} — {reason}'),
                balance_after=credit.balance,
                reference_id=str(payment.id))

    # فاز ۲ — فراخوانی درگاه (خارج از هر transaction)
    online_refunded = False
    if payment.online_amount and payment.online_amount > 0:
        with transaction.atomic():
            refund.status = 'gateway_processing'
            refund.save(update_fields=['status'])
        result = ZarinpalService.refund_payment(
            authority=payment.authority or '',
            ref_id=payment.ref_id or '',
            amount_rial=toman_to_rial(payment.online_amount))  # تومان → ریال
        # فاز ۳ — ثبت نتیجه درگاه
        with transaction.atomic():
            if result['success']:
                refund.status = 'gateway_refunded'
                refund.gateway_reference = result.get('reference') or ''
                refund.gateway_status = result.get('gateway_status', '')
                refund.processed_at = timezone.now()
                refund.save(update_fields=[
                    'status', 'gateway_reference', 'gateway_status',
                    'processed_at'])
                online_refunded = True
            else:
                refund.status = 'gateway_failed'
                refund.failure_reason = result.get('error') or 'خطای درگاه'
                refund.processed_at = timezone.now()
                refund.save(update_fields=[
                    'status', 'failure_reason', 'processed_at'])
                # سهم اعتبار قبلاً برگشت؛ خطای درگاه نباید پنهان بماند
                return Response({
                    'error': (
                        'سهم اعتبار به موجودی مشتری برگشت، اما عودت وجه '
                        'آنلاین در درگاه ناموفق بود و باید دستی پیگیری شود.'),
                    'refund_id': refund.id,
                    'failure_reason': refund.failure_reason,
                    'payment_status': payment.status,
                }, status=502)

    # فاز ۳ — نهایی‌سازی (فقط وقتی همه سهم‌ها واقعاً برگشتند)
    if (not payment.online_amount or online_refunded):
        with transaction.atomic():
            refund.status = 'completed'
            refund.approved_by = request.user
            refund.completed_at = timezone.now()
            refund.save(update_fields=['status', 'approved_by', 'completed_at'])

            payment.status = 'refunded'
            payment.save(update_fields=['status'])

            # reversal ledger entry (immutable) با علت/انجام‌دهنده/مرجع
            record_refund(
                payment, performed_by=request.user,
                reason=reason, gateway_ref=gateway_ref,
                refund=refund)

    try:
        AuditLog.objects.create(
            user=request.user,
            action='refund_payment',
            object_id=payment.id,
            changes={
                'payment_id': payment.id,
                'amount_rial': str(
                    payment.amount_rial or toman_to_rial(payment.amount)),
                'reason': reason,
                'gateway_ref': gateway_ref,
                'request_id': payment.inspection_request_id,
            })
    except Exception as log_error:
        logger.error(f"Error writing audit log: {log_error}")

    try:
        send_notification(user, 'payment_refunded', {
            'payment_id': payment.id,
            'amount': str(payment.amount or 0),
            'request_id': payment.inspection_request_id,
            'reason': reason,
        })
    except Exception as notif_error:
        logger.error(f"Error sending refund notification: {notif_error}")

    return Response({
        'success': True,
        'message': 'پرداخت عودت داده شد. سهم اعتباری به موجودی کاربر بازگشت.',
        'refunded_credit': str(payment.credit_amount or 0),
        'refunded_rial': str(payment.amount_rial or toman_to_rial(payment.amount)),
        'reason': reason,
        'status': 'refunded',
    })


# ============================================================
# payment_receipt (محافظت از فیش بانکی — FILE-01/08)
# ============================================================
@api_view(['GET'])
@permission_classes([IsAuthenticated])
def payment_receipt(request, payment_id):
    """
    دریافت فایل فیش بانکی یک پرداخت — فقط مالک درخواست یا ادمین.
    فیش فقط از این endpoint خوانده می‌شود (فرانت از /api/download/... با
    توکن JWT استفاده می‌کند)، نه URL مستقیم media.
    """
    try:
        payment = Payment.objects.select_related(
            'inspection_request__customer').get(id=payment_id)
    except Payment.DoesNotExist:
        return Response({'error': 'پرداخت یافت نشد.'}, status=404)

    user = request.user
    is_admin = user.is_staff or user.groups.filter(name='Admin').exists()
    if not is_admin and payment.inspection_request.customer != user:
        return Response({'error': 'شما دسترسی به این فیش ندارید.'}, status=403)

    if not payment.bank_receipt:
        return Response(
            {'error': 'فیش بانکی برای این پرداخت ثبت نشده است.'}, status=404)

    try:
        from django.http import FileResponse

        # MEDIUM-15: Content-Type از magic bytes واقعی فایل تشخیص داده می‌شود،
        # نه فقط extension — قبلاً هر چیز غیر از .pdf به‌اشتباه image/jpeg
        # معرفی می‌شد (PNG/WebP/فایل نامعتبر رفتار نادرست داشت).
        # EDRA v35: فایل برای خواندن هدر باز و هرگز بسته نمی‌شد (نشت file
        # descriptor در هر دانلود فیش؛ زیر بار همزمان ۲۰۰ کاربر خطرناک).
        with payment.bank_receipt.open('rb') as _fh:
            head = _fh.read(16)
        if head.startswith(b'%PDF'):
            content_type = 'application/pdf'
        elif head.startswith(b'\x89PNG\r\n\x1a\n'):
            content_type = 'image/png'
        elif head[:3] == b'\xff\xd8\xff':
            content_type = 'image/jpeg'
        elif head[:4] == b'RIFF' and head[8:12] == b'WEBP':
            content_type = 'image/webp'
        else:
            # فرمت ناشناخته/نامعتبر — به‌جای حدس اشتباه، خطا بده
            return Response(
                {'error': 'فرمت فایل فیش نامعتبر است.'}, status=415)

        return FileResponse(
            payment.bank_receipt.open('rb'), content_type=content_type)
    except Exception as e:
        logger.error(f"Error streaming receipt {payment.id}: {e}")
        return Response({'error': 'خطا در خواندن فایل فیش.'}, status=500)


# ============================================================
# PaymentMethodViewSet
# ============================================================
class PaymentMethodViewSet(viewsets.ModelViewSet):
    """
    EDRA v32 — روش‌های پرداخت یک مجموعه‌ی ثابت سیستمی هستند (online / manual /
    credit؛ مدل `name` را به همین سه choice محدود و unique کرده و جریان‌های
    پرداخت آن‌ها را خودکار get_or_create می‌کنند). بنابراین:
      - خواندن: عمومی؛ کاربر عادی فقط روش‌های فعال را می‌بیند، ادمین همه را.
      - ویرایش (PATCH/PUT: فعال/غیرفعال + توضیحات): فقط ادمین.
      - ساخت/حذف: ممنوع (405) — حذف یک روش سیستمی جریان پرداخت را می‌شکست؛
        به‌جای آن غیرفعالش کنید.
    قبلاً این ViewSet فقط‌خواندنی بود ولی صفحه‌ی ادمین POST/PUT/DELETE می‌زد
    (همه 405) و فلگ is_active هم هیچ‌جا اعمال نمی‌شد.
    """
    pagination_class = None  # لیست کوچک/مرجع
    serializer_class = PaymentMethodSerializer
    http_method_names = ['get', 'put', 'patch', 'head', 'options']

    def get_permissions(self):
        if self.action in ('list', 'retrieve'):
            return [AllowAny()]
        return [IsAdminUserOrGroup()]

    def get_queryset(self):
        user = self.request.user
        qs = PaymentMethod.objects.all().order_by('name')
        if user.is_authenticated and (user.is_staff or user.groups.filter(name='Admin').exists()):
            return qs
        return qs.filter(is_active=True)


# ============================================================
# PaymentViewSet
# ============================================================
class PaymentViewSet(viewsets.ReadOnlyModelViewSet):
    """
    پرداخت‌ها فقط خواندنی هستند (SEC-01): تغییرات وضعیت/مبلغ صرفاً از
    طریق اکشن‌های server-side (callback، verify، reject) انجام می‌شود.
    """
    serializer_class = PaymentSerializer
    permission_classes = [IsAuthenticated]
    filter_backends = [DjangoFilterBackend, filters.SearchFilter, filters.OrderingFilter]
    filterset_class = PaymentFilter
    search_fields = ['inspection_request__id', 'authority', 'ref_id']
    ordering_fields = ['created_at', 'amount', 'status']
    ordering = ['-created_at']

    def get_queryset(self):
        user = self.request.user
        qs = Payment.objects.select_related(
            'inspection_request', 'inspection_request__customer', 'method')
        # ادمین همه را می‌بیند (مدیریت پرداخت‌ها)؛ مشتری فقط پرداخت‌های خودش
        if user.groups.filter(name='Admin').exists() or user.is_staff:
            return qs
        return qs.filter(inspection_request__customer=user)


# ============================================================
# InvoiceViewSet
# ============================================================
class InvoiceViewSet(viewsets.ReadOnlyModelViewSet):
    serializer_class = InvoiceSerializer
    permission_classes = [IsAuthenticated]
    filter_backends = [DjangoFilterBackend, filters.SearchFilter, filters.OrderingFilter]
    filterset_class = InvoiceFilter
    search_fields = ['invoice_number', 'inspection_request__id']
    ordering_fields = ['issue_date', 'final_amount', 'due_date']
    ordering = ['-issue_date']

    def get_queryset(self):
        user = self.request.user
        qs = Invoice.objects.select_related(
            'inspection_request',
            'inspection_request__customer',
            'inspection_request__equipment_type')
        # ادمین همه فاکتورها را می‌بیند؛ مشتری فقط فاکتورهای خودش (SEC-01)
        if user.groups.filter(name='Admin').exists() or user.is_staff:
            return qs
        return qs.filter(inspection_request__customer=user)

    @action(detail=True, methods=['get'])
    def pdf(self, request, pk=None):
        """
        دانلود محافظتشده PDF فاکتور (P0-8): مالک درخواست یا ادمین.
        get_object از queryset محدودشده استفاده می‌کند → 404 برای غیرمجاز.
        """
        from django.http import FileResponse
        invoice = self.get_object()
        if not invoice.pdf_file:
            return Response(
                {'error': 'PDF فاکتور هنوز تولید نشده است.'}, status=404)
        return FileResponse(
            invoice.pdf_file.open('rb'),
            content_type='application/pdf',
            filename=f'{invoice.invoice_number}.pdf')

    @action(detail=True, methods=['post'],
            permission_classes=[IsAuthenticated])
    def retry_pdf(self, request, pk=None):
        invoice = self.get_object()

        if invoice.inspection_request.customer != request.user and not is_admin_user(request.user):
            return Response(
                {'error': 'شما دسترسی به این فاکتور ندارید.'}, status=status.HTTP_403_FORBIDDEN)

        if invoice.status != 'failed' and invoice.pdf_file:
            return Response({'error': 'فاکتور قبلاً تولید شده است.'},
                            status=status.HTTP_400_BAD_REQUEST)

        if invoice.retry_count >= 3:
            return Response(
                {
                    'error': 'تعداد تلاش مجدد بیش از حد مجاز است. لطفاً با پشتیبانی تماس بگیرید.'},
                status=status.HTTP_400_BAD_REQUEST)

        try:
            generate_invoice_pdf_task.delay(invoice.id, request.user.id)
        except Exception as broker_error:
            logger.error(f"retry_pdf queue failed (invoice {invoice.id}): {broker_error}")
            return Response(
                {'error': 'سرویس صف در دسترس نیست؛ کمی بعد دوباره تلاش کنید.'},
                status=status.HTTP_503_SERVICE_UNAVAILABLE)

        return Response({
            'message': 'تولید PDF فاکتور در صف قرار گرفت. پس از اتمام به شما اطلاع داده می‌شود.',
            'invoice_id': invoice.id,
            'status': 'queued'
        }, status=status.HTTP_202_ACCEPTED)


# ============================================================
# initiate_payment
# ============================================================
def _initiate_payment_impl(request):
    """
    شروع فرآیند پرداخت برای یک درخواست (idempotent — FIN-05)

    EDRA v35: منطق به این تابع ساده منتقل شد تا هم initiate_payment و هم
    request_credit_deposit (method=online + request_id) آن را صدا بزنند؛ قبلاً
    request_credit_deposit خودِ view دکوراتورشده را با یک DRF Request صدا
    می‌زد (AssertionError: «request must be an HttpRequest») و آن مسیر
    همیشه ۵۰۰ می‌داد.

    بدنه (اختیاری):
      request_id   : شناسه درخواست بازرسی
      credit_amount: مبلغ اعتباری که کاربر می‌خواهد از اعتبار خود کم کند
                     (رزرو اتمیک؛ در شکست درگاه آزاد می‌شود — FIN-04)

    مبلغ درگاه همیشه server-side از final_price درخواست محاسبه می‌شود.
    """
    request_id = request.data.get('request_id')
    if not request_id:
        return Response({'error': 'شناسه درخواست الزامی است.'}, status=400)

    try:
        inspection_request = InspectionRequest.objects.get(
            id=request_id, customer=request.user)
    except InspectionRequest.DoesNotExist:
        return Response({'error': 'درخواست یافت نشد.'}, status=404)

    if inspection_request.status not in (
            'pending_payment', 'waiting_manual_payment'):
        return Response(
            {'error': 'این درخواست در وضعیت قابل پرداخت نیست.'}, status=400)

    from ..services.credit_service import CreditService, InsufficientCreditError
    from ..services.invoice_service import InvoiceSettlementService

    # --- مبالغ پرداخت فقط از snapshot فاکتور (تخفیف+مالیات؛ server-side) ---
    # EDRA v35: مقدار غیرعددی/NaN قبلاً InvalidOperation و خطای ۵۰۰ می‌داد.
    try:
        credit_amount = Decimal(str(request.data.get('credit_amount') or 0))
        if not credit_amount.is_finite():
            raise ValueError
    except Exception:
        return Response({'error': 'مبلغ اعتبار نامعتبر است.'}, status=400)
    snap = InvoiceSettlementService.payment_snapshot(
        inspection_request, credit_amount=credit_amount)
    amount = snap['amount']
    amount_rial = snap['amount_rial']
    credit_amount = snap['credit_amount']
    online_amount = snap['online_amount']
    online_rial = snap['online_rial']

    if amount <= 0:
        return Response(
            {'error': 'مبلغ قابل پرداخت صفر است؛ با پشتیبانی تماس بگیرید.'},
            status=400)

    # EDRA v35: پرداخت قبلی (فیش/اعتبار) هنوز در انتظار بررسی ادمین است؛
    # شروع پرداخت جدید = احتمال پرداخت دوباره‌ی همان درخواست.
    if inspection_request.payments.filter(
            status='pending_verification').exists():
        return Response(
            {'error': 'پرداخت قبلی این درخواست در انتظار بررسی ادمین است.'},
            status=400)

    # EDRA v32: روش‌های غیرفعال‌شده توسط ادمین؛ قبل از هر رزرو اعتبار چک می‌شود
    # تا چیزی برای آزادسازی باقی نماند.
    _inactive_methods = set(PaymentMethod.objects.filter(
        is_active=False).values_list('name', flat=True))
    if ((credit_amount > 0 and 'credit' in _inactive_methods)
            or (online_rial > 0 and 'online' in _inactive_methods)):
        return Response(
            {'error': 'این روش پرداخت موقتاً غیرفعال است. روش دیگری انتخاب کنید.'},
            status=400)

    # --- پرداخت ترکیبی: رزرو اتمیک اعتبار ---
    # P0-02 (EDRA v9): قبل از رزرو جدید، همه رزروهای فعال قبلی همین
    # درخواست (از initiate های همزمان/ناقص) آزاد می‌شوند تا هرگز دو
    # Reservation همزمان برای یک پرداخت وجود نداشته باشد (قبلاً چند
    # request همزمان چند رزرو می‌ساخت و consume_for_payment همه را
    # مصرف می‌کرد → debit اضافه).
    reserved = None
    if credit_amount > 0:
        # EDRA v35: آزادسازی رزرو قدیمی + رزرو جدید در «یک» تراکنش و با قفل
        # ردیف درخواست؛ دو initiate همزمان دیگر دو رزرو نمی‌سازند و اگر اعتبار
        # کافی نبود رزرو قدیمی هم سر جایش می‌ماند (rollback).
        try:
            with transaction.atomic():
                InspectionRequest.objects.select_for_update().get(
                    pk=inspection_request.pk)
                stale = CreditReservation.objects.filter(
                    inspection_request=inspection_request,
                    status='reserved')
                for r in stale:
                    CreditService.release(
                        r, reason='superseded by new payment initiate')
                reserved = CreditService.reserve(
                    request.user, credit_amount,
                    inspection_request=inspection_request)
        except InsufficientCreditError as e:
            return Response({'error': str(e)}, status=400)

    description = f'پرداخت هزینه بازرسی - درخواست #{inspection_request.id}'
    callback_url = _payment_callback_url(request)

    # EDRA v13 — P1 #9: پرداخت تمام‌اعتباری (online_amount == 0) نباید به
    # درگاه ارسال شود — درخواست ۰ ریالی به زرین‌پال خطا/رفتار غلط دارد.
    full_credit = online_rial <= 0

    if full_credit:
        # EDRA v27 — رفع باگ واقعی (تایید ممیزی هوش مصنوعی + قانون
        # کسب‌وکار کاربر، سپتامبر ۲۰۲۶): این مسیر (initiate_payment) یک
        # مسیر جداگانه از credit_views.request_credit_deposit بود که از
        # قبل برای «پرداخت اعتباری باید منتظر بررسی ادمین بماند» اصلاح
        # شده بود — این یکی از قلم افتاده بود و همچنان بلافاصله paid
        # می‌کرد. همچنین status='paid' در فیلدهای جست‌وجوی get_or_create
        # بود؛ یعنی اگر رکورد قبلی با status متفاوت (مثلاً
        # pending_verification) وجود داشت، یک Payment تکراری ساخته
        # می‌شد. حالا هم منطق و هم جست‌وجو با مسیر دیگر یکسان شد.
        method, _ = PaymentMethod.objects.get_or_create(
            name='credit', defaults={'is_active': True})
        # EDRA v35: get_or_create(request, method) بدون status، پرداخت
        # «رد شده/ناموفق» قبلی را برمی‌گرداند؛ مشتری با اعتبار هرگز نمی‌توانست
        # دوباره پرداخت کند و رزرو به یک پرداخت مرده وصل می‌شد. هر تلاش، یک
        # Payment تازه (قبلی‌های در انتظار بالاتر رد شده‌اند).
        with transaction.atomic():
            payment = Payment.objects.create(
                inspection_request=inspection_request,
                method=method,
                amount=amount,
                amount_rial=amount_rial,
                credit_amount=credit_amount,
                online_amount=0,
                status='pending_verification')
            if reserved is not None:
                reserved.payment = payment
                reserved.save(update_fields=['payment'])
        try:
            send_notification(request.user, 'payment_pending_review', {
                'request_id': inspection_request.id,
                'amount': str(inspection_request.final_price),
                'method': 'credit'
            })
        except Exception as e:
            logger.error(f"Error sending notification: {e}")
        return Response({
            'payment_url': None,
            'authority': '',
            'online_amount': '0',
            'credit_amount': str(credit_amount or 0),
            'status': 'pending_verification',
            'message': 'درخواست با اعتبار شما ثبت شد و برای بررسی نهایی ادمین ارسال شد.',
        })

    # مبلغ درگاه = فقط سهم آنلاین (به ریال)
    result = ZarinpalService.create_payment(
        int(online_rial), description, callback_url, {
            'mobile': request.user.username,
            'email': request.user.email or '',
        })

    if not result['success']:
        # آزادسازی رزرو در شکست initiation
        if reserved is not None:
            CreditService.release(
                reserved, reason='zarinpal initiation failed')
        return Response({'error': result['error']}, status=500)

    # یک Payment pending برای هر درخواست (idempotent)؛ authority جدید جایگزین می‌شود
    method, _ = PaymentMethod.objects.get_or_create(
        name='online', defaults={'is_active': True})
    # EDRA v35: get_or_create روی (request,status,method) بدون unique-constraint،
    # در دو initiate همزمان دو Payment می‌ساخت و فراخوانی بعدی
    # MultipleObjectsReturned (۵۰۰) می‌داد. اکنون با قفل ردیف درخواست
    # سریالایز می‌شود و جدیدترین pending استفاده می‌شود.
    with transaction.atomic():
        InspectionRequest.objects.select_for_update().get(
            pk=inspection_request.pk)
        payment = Payment.objects.filter(
            inspection_request=inspection_request,
            status='pending', method=method).order_by('-id').first()
        if payment is None:
            payment = Payment.objects.create(
                inspection_request=inspection_request,
                status='pending',
                method=method,
                amount=amount,
                amount_rial=amount_rial,
                credit_amount=credit_amount,
                online_amount=online_amount,
                authority=result['authority'])
        else:
            payment.authority = result['authority']
            payment.amount_rial = amount_rial
            payment.amount = amount
            payment.credit_amount = credit_amount
            payment.online_amount = online_amount
            payment.save(update_fields=[
                'authority', 'amount_rial', 'amount',
                'credit_amount', 'online_amount'])

        # اتصال رزرو به پرداخت
        if reserved is not None:
            reserved.payment = payment
            reserved.save(update_fields=['payment'])

    return Response({
        'payment_url': result['payment_url'],
        'authority': result['authority'],
        'online_amount': str(online_amount),
        'credit_amount': str(credit_amount or 0),
    })


@api_view(['POST'])
@permission_classes([IsAuthenticated])
@throttle_classes([PaymentInitiateThrottle])
def initiate_payment(request):
    return _initiate_payment_impl(request)


# ============================================================
# payment_callback
# ============================================================
@api_view(['GET'])
@permission_classes([AllowAny])
@throttle_classes([])  # EDRA v35: callback هرگز نباید 429 بگیرد (پول گرفته شده)
def payment_callback(request):
    """
    بازگشت از درگاه پرداخت (idempotent — FIN-05)

    - authority ناشناخته → 404
    - callback تکراری (قبلاً paid) → redirect success (بدون عملیات مجدد)
    - موفق → consume رزروهای اعتبار + فاکتور از طریق سیگنال/سرویس مرکزی
    - ناموفق/انصراف → release رزروهای اعتبار + redirect مربوطه
    """
    from ..services.credit_service import CreditService
    from ..services.invoice_service import InvoiceSettlementService

    authority = request.GET.get('Authority')
    status_param = request.GET.get('Status')

    if not authority:
        return HttpResponse('Authority یافت نشد.', status=400)

    try:
        payment = Payment.objects.get(authority=authority)
    except Payment.DoesNotExist:
        return HttpResponse('پرداخت یافت نشد.', status=404)

    inspection_request = payment.inspection_request

    # --- idempotent: callback تکراری ---
    if payment.status == 'paid':
        return redirect(
            f'{settings.FRONTEND_URL}/payment/success?ref_id={payment.ref_id or ""}')

    # EDRA v35: پرداختِ ردشده/عودت‌شده با callback دوباره «paid» نشود.
    if payment.status in ('rejected', 'refunded'):
        return redirect(f'{settings.FRONTEND_URL}/payment/failed')

    if status_param != 'OK':
        # انصراف کاربر از درگاه → آزادسازی اعتبار رزروشده
        first_time = payment.status == 'pending'
        if first_time:
            payment.status = 'cancelled'
            payment.save(update_fields=['status'])
        CreditService.release_for_payment(payment)
        # EDRA v33: قالب payment_failed وجود داشت ولی هیچ‌جا ارسال نمی‌شد.
        # فقط در اولین callback (تکرار callback اعلان تکراری نسازد).
        if first_time:
            try:
                send_notification(inspection_request.customer, 'payment_failed', {
                    'request_id': inspection_request.id,
                })
            except Exception as notif_error:
                logger.error(f"Error sending payment_failed notification: {notif_error}")
        return redirect(f'{settings.FRONTEND_URL}/payment/canceled')

    # مبلغ مورد انتظار درگاه = فقط سهم آنلاین (به ریال) — source of truth
    expected_amount_rial = (
        toman_to_rial(payment.online_amount)
        if payment.online_amount
        else (payment.amount_rial or toman_to_rial(payment.amount)))
    result = ZarinpalService.verify_payment(
        authority, int(expected_amount_rial))

    if not result['success'] and result.get('transient'):
        # EDRA v35: خطای شبکه/timeout در verify یعنی «نتیجه نامعلوم»؛ قبلاً
        # پرداخت قطعی failed و اعتبار آزاد می‌شد حتی اگر کاربر واقعاً پرداخت
        # کرده بود. وضعیت دست‌نخورده می‌ماند (pending) تا callback مجدد/پیگیری
        # دستی تصمیم بگیرد.
        logger.error(
            f"Zarinpal verify transient failure for payment {payment.id}: "
            f"{result.get('error')}")
        return redirect(
            f'{settings.FRONTEND_URL}/payment/failed?reason=verify_unavailable')

    if result['success']:
        # P1-01 (EDRA v8): کل settlement (paid + consume اعتبار + فاکتور +
        # ledger) داخل یک transaction واحد انجام می‌شود تا شکست هر مرحله
        # کل تسویه را rollback کند و سیستم مالی هرگز نیمه‌تسویه نماند.
        # (verify درگاه خارج از تراکنش است چون فراخوانی external است.)
        with transaction.atomic():
            # قفل ردیف برای جلوگیری از race در callback همزمان
            payment = Payment.objects.select_for_update().get(
                id=payment.id)
            if payment.status == 'paid':
                # race: callback دیگر همین پرداخت را نهایی کرده
                return redirect(
                    f'{settings.FRONTEND_URL}/payment/success?ref_id={payment.ref_id or ""}')

            payment.status = 'paid'
            payment.ref_id = result['ref_id']
            payment.verified_at = timezone.now()
            payment.save(update_fields=[
                'status', 'ref_id', 'verified_at'])

            # EDRA v34: وضعیت فقط در صورت «پرداخت‌نشده» به paid می‌رود. قبلاً
            # callback دومِ یک پرداخت (مثلاً دو تب/دو تلاش پرداخت برای یک
            # درخواست) وضعیت درخواستی را که ارجاع شده/در حال بازرسی/تکمیل است
            # به paid برمی‌گرداند و کل گردش‌کار کارشناس را به عقب می‌انداخت.
            inspection_request = type(inspection_request).objects \
                .select_for_update().get(pk=inspection_request.pk)
            _params = inspection_request.params
            is_deposit = bool(
                isinstance(_params, dict) and _params.get('is_deposit'))

            if is_deposit:
                # EDRA v35 — باگ بحرانی: «افزایش اعتبار آنلاین» (صفحه‌ی اعتبار
                # مشتری) پول واقعی را از درگاه می‌گرفت ولی این callback هیچ‌جا
                # موجودی را زیاد نمی‌کرد (فقط یک فاکتور مالیاتی ساختگی صادر
                # می‌شد). اکنون مثل تایید دستی ادمین: موجودی + تراکنش اعتباری،
                # بدون فاکتور.
                from core.models import UserCredit, CreditTransaction
                credit, _ = UserCredit.objects.select_for_update(
                ).get_or_create(user=inspection_request.customer)
                credit.balance += payment.amount
                credit.save(update_fields=['balance'])
                CreditTransaction.objects.create(
                    user=inspection_request.customer,
                    amount=payment.amount,
                    transaction_type='deposit',
                    description=(
                        f'افزایش اعتبار آنلاین به مبلغ {payment.amount:,} '
                        f'تومان - کد رهگیری {result["ref_id"]}'),
                    balance_after=credit.balance,
                    reference_id=str(payment.id))
                inspection_request.status = 'completed'
                inspection_request.save(update_fields=['status'])
            else:
                if inspection_request.status in (
                        'draft', 'pending_payment', 'waiting_manual_payment',
                        'expired'):
                    inspection_request.status = 'paid'
                    inspection_request.save(update_fields=['status'])

                # مصرف رزروهای اعتبار (همان تراکنش — شکست = rollback کل)
                if payment.credit_amount:
                    CreditService.consume_for_payment(payment)

                # فاکتور فقط از طریق سرویس مرکزی (idempotent — همان تراکنش)
                InvoiceSettlementService.settle(
                    inspection_request, payment=payment,
                    is_paid=True, paid_at=timezone.now(),
                    user=inspection_request.customer)

        try:
            send_notification(
                inspection_request.customer,
                'payment_verified' if is_deposit else 'payment_successful', {
                    'request_id': inspection_request.id,
                    'ref_id': result['ref_id'],
                    'amount': str(payment.amount),
                    'message': 'اعتبار شما با موفقیت افزایش یافت.'
                    if is_deposit else 'پرداخت شما با موفقیت انجام شد.',
                })
        except Exception as notif_error:
            logger.error(f"Error sending notification: {notif_error}")

        return redirect(
            f'{settings.FRONTEND_URL}/payment/success?ref_id={result["ref_id"]}')
    else:
        # verify ناموفق → آزادسازی اعتبار رزروشده
        first_time = payment.status == 'pending'
        if first_time:
            payment.status = 'failed'
            payment.save(update_fields=['status'])
        CreditService.release_for_payment(payment)
        if first_time:
            try:
                send_notification(inspection_request.customer, 'payment_failed', {
                    'request_id': inspection_request.id,
                })
            except Exception as notif_error:
                logger.error(f"Error sending payment_failed notification: {notif_error}")
        return redirect(f'{settings.FRONTEND_URL}/payment/failed')

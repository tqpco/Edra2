# core/views/pdf_views.py
from django.conf import settings
from django.http import HttpResponse
from django.shortcuts import get_object_or_404
from django.contrib.auth import get_user_model
from ..authentication import EdraJWTAuthentication as JWTAuthentication  # EDRA v36: اعمال تعلیق حساب
from rest_framework.exceptions import AuthenticationFailed

from ..models import InspectionReport, Invoice
from ..permissions import is_admin_user
from ..utils.http_headers import build_content_disposition

User = get_user_model()


# ============================================================
# generate_report_pdf
# ============================================================
def generate_report_pdf(request, report_id):
    # EDRA v12 — P1-01: قبول Bearer در query-string حذف شد — توکن هرگز
    # در URL قرار نمی‌گیرد (ریسک لو رفتن در log/proxy/history). فقط
    # Authorization Bearer یا کوکی پذیرفته می‌شود.
    auth = JWTAuthentication()
    try:
        user_auth = auth.authenticate(request)
        if user_auth is None:
            return HttpResponse('احراز هویت لازم است.', status=401)
        request.user = user_auth[0]
    except AuthenticationFailed:
        return HttpResponse('توکن نامعتبر یا منقضی شده است.', status=401)

    report = get_object_or_404(InspectionReport, id=report_id)
    inspection_request = report.inspection_request

    if request.user != inspection_request.customer and not is_admin_user(request.user):
        return HttpResponse(
            'دسترسی غیرمجاز. شما مالک این گزارش نیستید.',
            status=403)

    # EDRA v36: نسخه‌ی امضاشده (در صورت وجود) باید ارائه شود؛ قبلاً همیشه نسخه‌ی
    # بدون امضا می‌رفت و هش امضا با فایل دانلودی مشتری نمی‌خواند.
    report_file = report.signed_pdf_file or report.pdf_file
    if not report_file:
        return HttpResponse(
            'PDF هنوز تولید نشده است. لطفاً بعداً مراجعه کنید.',
            status=404)

    response = HttpResponse(report_file, content_type='application/pdf')
    # EDRA v18 — باگ #۳: نام فارسی با RFC 5987 (قبلاً کل هدر MIME می‌شد)
    response['Content-Disposition'] = build_content_disposition(
        f'گزارش_{report.report_number}.pdf',
        f'report_{report.report_number}.pdf')
    return response


# ============================================================
# generate_invoice_pdf
# ============================================================
def generate_invoice_pdf(request, invoice_id):
    # EDRA v12 — P1-01: فقط Authorization Bearer/کوکی — بدون توکن در query
    auth = JWTAuthentication()
    try:
        user_auth = auth.authenticate(request)
        if user_auth is None:
            return HttpResponse('احراز هویت لازم است.', status=401)
        request.user = user_auth[0]
    except AuthenticationFailed:
        return HttpResponse('توکن نامعتبر یا منقضی شده است.', status=401)

    invoice = get_object_or_404(Invoice, id=invoice_id)
    inspection_request = invoice.inspection_request

    if request.user != inspection_request.customer and not is_admin_user(request.user):
        return HttpResponse('دسترسی غیرمجاز', status=403)

    if not invoice.pdf_file:
        return HttpResponse(
            'PDF هنوز تولید نشده است. لطفاً بعداً مراجعه کنید.',
            status=404)

    response = HttpResponse(invoice.pdf_file, content_type='application/pdf')
    # EDRA v18 — باگ #۳: نام فارسی با RFC 5987
    response['Content-Disposition'] = build_content_disposition(
        f'فاکتور_{invoice.invoice_number}.pdf',
        f'invoice_{invoice.invoice_number}.pdf')
    return response
# core/views/profile_views.py
import re

from django.core.exceptions import ValidationError as DjangoValidationError
from django.core.validators import validate_email
from rest_framework import status
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated

from core.models import UserCredit, UserProfile


def _get_or_create_profile(user):
    profile, _ = UserProfile.objects.get_or_create(user=user)
    return profile


_FA_DIGITS = str.maketrans('۰۱۲۳۴۵۶۷۸۹٠١٢٣٤٥٦٧٨٩', '01234567890123456789')


def _validate_profile_input(user, data, profile):
    """
    EDRA v36 — این ویوها ورودی را بدون هیچ اعتبارسنجی روی مدل می‌نوشتند: مقدار
    طولانی/غیرمتنی (first_name>150، years_experience غیرعددی) یا شماره‌ی تکراری
    خطای ۵۰۰ (DataError/IntegrityError/ValueError) می‌داد.
    خروجی: (cleaned: dict, errors: dict)
    """
    cleaned, errors = {}, {}

    def _text(key, max_len):
        if key in data:
            value = data.get(key)
            if value is None:
                value = ''
            if not isinstance(value, (str, int, float)):
                errors[key] = 'مقدار نامعتبر است.'
                return
            value = str(value).strip()
            if len(value) > max_len:
                errors[key] = f'حداکثر {max_len} نویسه مجاز است.'
                return
            cleaned[key] = value

    _text('first_name', 150)
    _text('last_name', 150)
    _text('bio', 5000)
    _text('expertise', 255)
    _text('company_name', 200)
    _text('registration_number', 50)

    if 'email' in data:
        email = str(data.get('email') or '').strip()
        if email:
            try:
                validate_email(email)
            except DjangoValidationError:
                errors['email'] = 'ایمیل نامعتبر است.'
            else:
                if len(email) > 254:
                    errors['email'] = 'ایمیل بیش از حد طولانی است.'
        if 'email' not in errors:
            cleaned['email'] = email

    if 'phone' in data:
        phone = str(data.get('phone') or '').strip().translate(_FA_DIGITS)
        if phone:
            if not re.match(r'^09\d{9}$', phone):
                errors['phone'] = 'شماره موبایل باید با 09 شروع شود و 11 رقم باشد.'
            elif UserProfile.objects.filter(phone=phone).exclude(
                    pk=profile.pk).exists():
                errors['phone'] = 'این شماره موبایل قبلاً ثبت شده است.'
        if 'phone' not in errors:
            cleaned['phone'] = phone

    if 'years_experience' in data:
        raw = data.get('years_experience')
        if raw in (None, ''):
            cleaned['years_experience'] = None
        else:
            try:
                years = int(raw)
                if not (0 <= years <= 80):
                    raise ValueError
                cleaned['years_experience'] = years
            except (TypeError, ValueError):
                errors['years_experience'] = 'سابقه‌ی کار باید عددی بین ۰ تا ۸۰ باشد.'
    return cleaned, errors


# ============================================================
# ExpertProfileView
# ============================================================
class ExpertProfileView(APIView):
    """
    دریافت و بروزرسانی اطلاعات پروفایل کارشناس

    نکته اصلاح‌شده: قبلاً این ویو مستقیماً از user.phone / user.bio و
    مشابه می‌خواند/می‌نوشت که هیچ‌کدام روی مدل User وجود نداشتند (فقط
    روی UserProfile مرتبط) - یعنی خواندن همیشه مقدار خالی برمی‌گرداند و
    نوشتن (save) هیچ اثری در دیتابیس نداشت چون این‌ها attribute های
    موقت پایتون بودند نه فیلد واقعی مدل.
    """
    permission_classes = [IsAuthenticated]

    def get(self, request):
        user = request.user
        profile = _get_or_create_profile(user)
        return Response({
            'id': user.id,
            'username': user.username,
            'first_name': user.first_name,
            'last_name': user.last_name,
            'full_name': user.get_full_name() or user.username,
            'email': user.email,
            'phone': profile.phone,
            'bio': profile.bio,
            'expertise': profile.expertise,
            'years_experience': profile.years_experience,
        })

    def put(self, request):
        user = request.user
        profile = _get_or_create_profile(user)
        cleaned, errors = _validate_profile_input(user, request.data, profile)
        if errors:
            return Response({'errors': errors},
                            status=status.HTTP_400_BAD_REQUEST)

        for key in ('first_name', 'last_name', 'email'):
            if key in cleaned:
                setattr(user, key, cleaned[key])
        user.save()

        for key in ('phone', 'bio', 'expertise', 'years_experience'):
            if key in cleaned:
                setattr(profile, key, cleaned[key])
        profile.save()

        return Response({'success': True,
                         'message': 'اطلاعات با موفقیت بروزرسانی شد'})


# ============================================================
# CustomerProfileView
# ============================================================
class CustomerProfileView(APIView):
    """
    دریافت و بروزرسانی اطلاعات پروفایل مشتری (همان اصلاح بالا)
    """
    permission_classes = [IsAuthenticated]

    def get(self, request):
        user = request.user
        profile = _get_or_create_profile(user)
        try:
            credit = UserCredit.objects.get(user=user)
            balance = credit.balance
        except UserCredit.DoesNotExist:
            balance = 0

        return Response({
            'id': user.id,
            'username': user.username,
            'first_name': user.first_name,
            'last_name': user.last_name,
            'full_name': user.get_full_name() or user.username,
            'email': user.email,
            'phone': profile.phone,
            'company_name': profile.company_name,
            'registration_number': profile.registration_number,
            'credit': balance,
        })

    def put(self, request):
        user = request.user
        profile = _get_or_create_profile(user)
        cleaned, errors = _validate_profile_input(user, request.data, profile)
        if errors:
            return Response({'errors': errors},
                            status=status.HTTP_400_BAD_REQUEST)

        for key in ('first_name', 'last_name', 'email'):
            if key in cleaned:
                setattr(user, key, cleaned[key])
        user.save()

        for key in ('phone', 'company_name', 'registration_number'):
            if key in cleaned:
                setattr(profile, key, cleaned[key])
        profile.save()

        return Response({'success': True,
                         'message': 'اطلاعات با موفقیت بروزرسانی شد'})


# ============================================================
# CustomerCreditView
# ============================================================
class CustomerCreditView(APIView):
    """
    دریافت اعتبار مشتری
    """
    permission_classes = [IsAuthenticated]

    def get(self, request):
        try:
            credit = UserCredit.objects.get(user=request.user)
            # EDRA v36: «available_balance» = موجودی منهای رزروهای فعال (قابل
            # مصرف واقعی)؛ balance برای سازگاری با فرانت‌اند بدون تغییر ماند.
            from core.services.credit_service import get_available_balance
            return Response({
                'balance': credit.balance,
                'available_balance': max(
                    get_available_balance(request.user), 0)})
        except UserCredit.DoesNotExist:
            return Response({'balance': 0, 'available_balance': 0})
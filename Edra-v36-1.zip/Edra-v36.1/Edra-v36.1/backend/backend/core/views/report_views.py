# core/views/report_views.py
"""
ویوهای گزارش‌گیری مدیریتی که قبلاً وجود نداشتند:
1) گزارش کامل یک مشتری (از پرداخت تا تیکت تا کارشناسی)
2) گزارش تجمیعی مالی کل سیستم
3) گزارش تجمیعی کارشناسی‌های کل سیستم

هر سه فقط برای IsAdminUserOrGroup در دسترس‌اند و بازه‌ی تاریخ اختیاری
(date_from/date_to به فرمت YYYY-MM-DD میلادی) را می‌پذیرند.
"""
from django.contrib.auth import get_user_model
from django.db.models import Sum, Count, Avg, Q
from django.http import HttpResponse
from django.shortcuts import get_object_or_404
from django.utils import timezone
from django.utils.dateparse import parse_date
from rest_framework.views import APIView
from rest_framework.permissions import IsAdminUser
from core.permissions import IsAdminUserOrGroup
from rest_framework.response import Response

from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment
from openpyxl.utils import get_column_letter

from ..models import (
    InspectionRequest, Payment, Invoice, InspectionReport,
    UserCredit, CreditTransaction, EquipmentType,
)
# ✅ جایگزینی با edra_jalalidate و تعریف wrapper با فرمت یکسان
from edra_jalalidate import to_jalali as _to_jalali
from ..services.money import rial_to_toman, toman_to_rial

User = get_user_model()

# ================================================================
# کمک‌کننده مشترک برای خروجی اکسل حرفه‌ای (هدر تیره، راست‌به‌چپ، عرض خودکار)
# ================================================================
_HEADER_FILL = PatternFill(
    start_color='1F2937', end_color='1F2937', fill_type='solid')
_HEADER_FONT = Font(color='FFFFFF', bold=True, size=11)


def _sheet_from_rows(wb, title, headers, rows):
    ws = wb.create_sheet(title=title[:31])  # محدودیت اکسل: حداکثر ۳۱ کاراکتر برای نام برگه
    ws.sheet_view.rightToLeft = True
    for col_idx, header in enumerate(headers, start=1):
        cell = ws.cell(row=1, column=col_idx, value=header)
        cell.fill = _HEADER_FILL
        cell.font = _HEADER_FONT
        cell.alignment = Alignment(horizontal='center')
    for row_idx, row in enumerate(rows, start=2):
        for col_idx, value in enumerate(row, start=1):
            cell = ws.cell(row=row_idx, column=col_idx, value=value)
            # EDRA v36 — تزریق فرمول در اکسل: openpyxl هر رشته‌ی شروع‌شونده با «=»
            # را «فرمول» ذخیره می‌کند؛ نام کاربر/پیام خطا/مسیر درخواست (ورودی
            # کنترل‌شده توسط مهاجم) می‌توانست با باز کردن گزارش توسط ادمین اجرا
            # شود (مثلاً =HYPERLINK(...)). این سلول‌ها به‌اجبار «متن» می‌شوند.
            if isinstance(value, str) and value[:1] in ('=', '+', '-', '@'):
                cell.data_type = 's'
    for col_idx, header in enumerate(headers, start=1):
        col_values = [str(row[col_idx - 1]) for row in rows] if rows else []
        max_len = max([len(str(header))] + [len(v) for v in col_values])
        ws.column_dimensions[get_column_letter(col_idx)].width = min(
            max(max_len + 2, 12), 40)
    return ws


def _xlsx_response(workbook, filename):
    response = HttpResponse(
        content_type='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')
    response['Content-Disposition'] = f'attachment; filename="{filename}"'
    workbook.save(response)
    return response


def _wants_xlsx(request):
    return request.query_params.get('format') == 'xlsx'


def _parse_date_range(request):
    """بازه تاریخ اختیاری از query params - در صورت نبود، کل تاریخچه."""
    date_from = parse_date(request.query_params.get('date_from', '') or '')
    date_to = parse_date(request.query_params.get('date_to', '') or '')
    return date_from, date_to


def _request_reconciliation(payments_qs, invoices_qs):
    """
    P1 (EDRA v10): reconciliation به ازای هر درخواست —
    Invoice - پرداخت موفق + عودت = مانده
    """
    from django.db.models import Sum
    from ..models import Refund
    paid_totals = {
        r['inspection_request_id']: r['t']
        # EDRA v35: پرداختِ عودت‌شده (status='refunded') هم «پرداخت‌شده» بوده؛
        # بدون آن، مانده = فاکتور − ۰ + عودت (عودت دو بار حساب می‌شد).
        for r in payments_qs.filter(status__in=['paid', 'refunded']).values(
            'inspection_request_id').annotate(
            t=Sum('amount')) if r['t'] is not None}
    refund_totals = {
        r['inspection_request_id']: r['t']
        for r in Refund.objects.filter(status='completed').values(
            'inspection_request_id').annotate(
            t=Sum('amount_toman')) if r['t'] is not None}
    invoice_totals = {
        r['inspection_request_id']: r['t']
        for r in invoices_qs.values('inspection_request_id').annotate(
            t=Sum('final_amount')) if r['t'] is not None}
    request_ids = set(paid_totals) | set(refund_totals) | set(invoice_totals)
    from ..models import InspectionRequest
    reqs = InspectionRequest.objects.filter(
        id__in=request_ids).select_related('customer')
    rows = []
    for req in reqs:
        rows.append({
            'request_id': req.id,
            'request_number': req.request_number,
            'customer': (req.customer.get_full_name()
                         if req.customer else ''),
            'invoice_total': invoice_totals.get(req.id, 0),
            'paid_total': paid_totals.get(req.id, 0),
            'refund_total': refund_totals.get(req.id, 0),
        })
    return rows


def _apply_date_range(qs, field, date_from, date_to):
    if date_from:
        qs = qs.filter(**{f'{field}__date__gte': date_from})
    if date_to:
        qs = qs.filter(**{f'{field}__date__lte': date_to})
    return qs


# wrapper برای حفظ فرمت قبلی (با داش)
def to_jalali(dt):
    """تبدیل datetime به رشته جلالی با فرمت "%Y/%m/%d - %H:%M" (همانند قبل)"""
    if not dt:
        return None
    return _to_jalali(dt, fmt="%Y/%m/%d - %H:%M")


class AdminCustomerFullReportView(APIView):
    """
    گزارش کامل یک مشتری: مشخصات + همه درخواست‌ها + همه پرداخت‌ها +
    همه فاکتورها + همه تیکت‌ها + همه گزارش‌های کارشناسی + وضعیت اعتبار.
    GET /api/admin/customers/<id>/full-report/
    """
    permission_classes = [IsAdminUserOrGroup]

    def get(self, request, customer_id):
        customer = get_object_or_404(User, id=customer_id)

        requests_qs = InspectionRequest.objects.filter(
            customer=customer).order_by('-created_at')
        payments_qs = Payment.objects.filter(
            inspection_request__customer=customer).order_by('-created_at')
        invoices_qs = Invoice.objects.filter(
            inspection_request__customer=customer).order_by('-issue_date')
        reports_qs = InspectionReport.objects.filter(
            inspection_request__customer=customer).order_by('-created_at')

        # تیکت‌ها - در اپ support است، import محلی برای جلوگیری از وابستگی حلقوی
        try:
            from support.models import Ticket
            tickets_qs = Ticket.objects.filter(
                customer=customer).order_by('-created_at')
            tickets_data = [{
                'id': t.id,
                'title': t.title,
                'status': t.status.name if t.status_id else None,
                'status_color': t.status.color if t.status_id else None,
                'priority': t.priority.name if t.priority_id else None,
                'created_at': to_jalali(t.created_at),
            } for t in tickets_qs]
        except Exception:
            tickets_data = []

        try:
            credit = UserCredit.objects.get(user=customer)
            credit_balance = credit.balance
        except UserCredit.DoesNotExist:
            credit_balance = 0

        credit_transactions = CreditTransaction.objects.filter(
            user=customer).order_by('-created_at')[:50]

        total_paid = payments_qs.filter(status='paid').aggregate(
            total=Sum('amount'))['total'] or 0
        total_pending = payments_qs.filter(
            status__in=['pending', 'pending_verification']
        ).aggregate(total=Sum('amount'))['total'] or 0

        profile = getattr(customer, 'profile', None)

        if _wants_xlsx(request):
            wb = Workbook()
            wb.remove(wb.active)
            _sheet_from_rows(wb, 'خلاصه', ['فیلد', 'مقدار'], [
                ['نام مشتری', customer.get_full_name() or customer.username],
                ['موبایل', getattr(profile, 'phone', '') or ''],
                ['شرکت', getattr(profile, 'company_name', '') or ''],
                ['تعداد درخواست‌ها', requests_qs.count()],
                ['جمع پرداخت‌شده', float(total_paid)],
                ['جمع در انتظار', float(total_pending)],
                ['موجودی اعتبار', float(credit_balance)],
                ['تعداد تیکت‌ها', len(tickets_data)],
            ])
            _sheet_from_rows(wb, 'درخواست‌ها',
                              ['شماره', 'وضعیت', 'تجهیز', 'قیمت نهایی', 'تاریخ'],
                              [[r.request_number, r.status,
                                r.equipment_type.name_fa if r.equipment_type_id else '',
                                float(r.final_price) if r.final_price else 0,
                                to_jalali(r.created_at)] for r in requests_qs])
            _sheet_from_rows(wb, 'پرداخت‌ها',
                              ['مبلغ', 'روش', 'وضعیت', 'تاریخ'],
                              [[float(p.amount), p.method.name if p.method_id else '',
                                p.status, to_jalali(p.created_at)] for p in payments_qs])
            _sheet_from_rows(wb, 'فاکتورها',
                              ['شماره فاکتور', 'مبلغ نهایی', 'وضعیت', 'تاریخ صدور'],
                              [[i.invoice_number, float(i.final_amount), i.status,
                                to_jalali(i.issue_date)] for i in invoices_qs])
            if tickets_data:
                _sheet_from_rows(wb, 'تیکت‌ها',
                                  ['عنوان', 'وضعیت', 'تاریخ'],
                                  [[t['title'], t['status'] or '', t['created_at']]
                                   for t in tickets_data])
            _sheet_from_rows(wb, 'گزارش‌های بازرسی',
                              ['شماره گزارش', 'نتیجه', 'تاریخ'],
                              [[rep.report_number, rep.overall_result,
                                to_jalali(rep.created_at)] for rep in reports_qs])
            return _xlsx_response(wb, f"customer_report_{customer.id}.xlsx")

        return Response({
            'customer': {
                'id': customer.id,
                'username': customer.username,
                'full_name': customer.get_full_name() or customer.username,
                'email': customer.email,
                'phone': getattr(profile, 'phone', None),
                'company_name': getattr(profile, 'company_name', None),
                'date_joined': to_jalali(customer.date_joined),
            },
            'summary': {
                'total_requests': requests_qs.count(),
                'total_paid': float(total_paid),
                'total_pending': float(total_pending),
                'total_reports': reports_qs.count(),
                'total_tickets': len(tickets_data),
                'credit_balance': float(credit_balance),
            },
            'requests': [{
                'id': r.id,
                'request_number': r.request_number,
                'status': r.status,
                'equipment': r.equipment_type.name_fa if r.equipment_type_id else None,
                'final_price': float(r.final_price) if r.final_price else 0,
                'created_at': to_jalali(r.created_at),
            } for r in requests_qs],
            'payments': [{
                'id': p.id,
                'amount': float(p.amount),
                'method': p.method.name if p.method_id else None,
                'status': p.status,
                'created_at': to_jalali(p.created_at),
            } for p in payments_qs],
            'invoices': [{
                'id': i.id,
                'invoice_number': i.invoice_number,
                'final_amount': float(i.final_amount),
                'status': i.status,
                'issue_date': to_jalali(i.issue_date),
            } for i in invoices_qs],
            'reports': [{
                'id': rep.id,
                'report_number': rep.report_number,
                'overall_result': rep.overall_result,
                'created_at': to_jalali(rep.created_at),
                'pdf_available': bool(rep.pdf_file),
            } for rep in reports_qs],
            'tickets': tickets_data,
            'credit_transactions': [{
                'id': ct.id,
                'amount': float(ct.amount),
                'type': ct.transaction_type,
                'created_at': to_jalali(ct.created_at),
            } for ct in credit_transactions],
        })


class AdminFinancialReportView(APIView):
    """
    گزارش تجمیعی مالی کل سیستم (با فیلتر بازه تاریخ اختیاری).
    GET /api/admin/reports/financial/?date_from=2026-01-01&date_to=2026-12-29
    """
    permission_classes = [IsAdminUserOrGroup]

    def get(self, request):
        date_from, date_to = _parse_date_range(request)

        # منبع truth مالی: مبلغ واقعی تسویه به ریال (amount_rial) با fallback
        # برای تراکنش‌های قدیمی (amount × 10) — FIN-06
        from django.db.models import F, Value
        from django.db.models.functions import Coalesce, TruncMonth

        # EDRA v35: «افزایش اعتبار» بدهی به مشتری است نه درآمد (درآمد وقتی ثبت
        # می‌شود که اعتبار خرج شود). قبلاً هم واریز اعتبار و هم پرداخت بعدی با
        # همان اعتبار درآمد حساب می‌شد (دو برابرشماری).
        payments_qs = _apply_date_range(
            Payment.objects.exclude(
                inspection_request__params__is_deposit=True),
            'created_at', date_from, date_to)
        paid_qs = payments_qs.filter(status='paid').annotate(
            effective_rial=Coalesce(
                F('amount_rial'), F('amount') * Value(10)))

        by_method = list(
            paid_qs.values('method__name')
            .annotate(total_rial=Sum('effective_rial'), count=Count('id'))
            .order_by('-total_rial')
        )

        invoices_qs = _apply_date_range(
            Invoice.objects.all(), 'issue_date', date_from, date_to)
        # مبلغ فاکتور به ریال: final_rial (snapshot) با fallback
        invoices_qs = invoices_qs.annotate(
            effective_rial=Coalesce(
                F('final_rial'), F('final_amount') * Value(10)))

        credit_issued = CreditTransaction.objects.filter(
            transaction_type='deposit'
        )
        credit_issued = _apply_date_range(
            credit_issued, 'created_at', date_from, date_to
        ).aggregate(total=Sum('amount'))['total'] or 0

        # سری زمانی ماهانه برای نمودار (۱۲ ماه اخیر در صورت نبود بازه دستی)
        monthly = list(
            paid_qs.annotate(month=TruncMonth('created_at'))
            .values('month')
            .annotate(total_rial=Sum('effective_rial'), count=Count('id'))
            .order_by('month')
        )

        if _wants_xlsx(request):
            wb = Workbook()
            wb.remove(wb.active)
            paid_total_rial = int(
                paid_qs.aggregate(t=Sum('effective_rial'))['t'] or 0)
            pending_total_rial = int(payments_qs.filter(
                status__in=['pending', 'pending_verification']
            ).annotate(eff=Coalesce(
                F('amount_rial'), F('amount') * Value(10))).aggregate(
                t=Sum('eff'))['t'] or 0)
            invoiced_total_rial = int(
                invoices_qs.aggregate(t=Sum('effective_rial'))['t'] or 0)
            _sheet_from_rows(
                wb, 'خلاصه مالی',
                ['فیلد', 'مبلغ (ریال / IRR)', 'مبلغ (تومان)'], [
                    ['جمع درآمد (پرداخت‌شده)',
                     paid_total_rial, int(rial_to_toman(paid_total_rial))],
                    ['تعداد پرداخت موفق', paid_qs.count(), paid_qs.count()],
                    ['جمع در انتظار تایید',
                     pending_total_rial, int(rial_to_toman(pending_total_rial))],
                    ['جمع کل فاکتورشده',
                     invoiced_total_rial, int(rial_to_toman(invoiced_total_rial))],
                    ['جمع اعتبار واریزشده',
                     int(credit_issued) * 10,
                     int(credit_issued)],
                ])
            _sheet_from_rows(
                wb, 'به تفکیک روش پرداخت',
                ['روش', 'جمع مبلغ (ریال / IRR)', 'جمع مبلغ (تومان)', 'تعداد'],
                [[row['method__name'] or 'نامشخص',
                  int(row['total_rial'] or 0),
                  int(rial_to_toman(row['total_rial'] or 0)),
                  row['count']] for row in by_method])
            _sheet_from_rows(
                wb, 'روند ماهانه',
                ['ماه', 'جمع مبلغ (ریال / IRR)', 'جمع مبلغ (تومان)', 'تعداد'],
                [[row['month'].strftime('%Y-%m') if row['month'] else '',
                  int(row['total_rial'] or 0),
                  int(rial_to_toman(row['total_rial'] or 0)),
                  row['count']] for row in monthly])

            # ==========================================================
            # P1 (EDRA v10): Sheetهای کامل حسابداری/ممیزی
            # ==========================================================
            # Sheet پرداخت‌ها — ریز هر Payment
            from ..models import Refund, LedgerEntry
            _sheet_from_rows(
                wb, 'ریز پرداخت‌ها',
                ['Payment ID', 'Request ID', 'شماره درخواست', 'مشتری',
                 'شماره مشتری', 'شماره فاکتور', 'مبلغ (تومان)',
                 'مبلغ (ریال)', 'آنلاین', 'اعتبار', 'دستی', 'روش',
                 'وضعیت', 'Authority', 'RefID', 'تاریخ ایجاد',
                 'تاریخ تأیید', 'تأییدکننده'],
                [[p.id,
                  p.inspection_request_id,
                  p.inspection_request.request_number,
                  (p.inspection_request.customer.get_full_name()
                   if p.inspection_request.customer else ''),
                  p.inspection_request.customer.username
                  if p.inspection_request.customer else '',
                  p.inspection_request.invoice.invoice_number
                  if hasattr(p.inspection_request, 'invoice')
                  and p.inspection_request.invoice else '',
                  int(p.amount or 0),
                  int(p.amount_rial or 0),
                  int(p.online_amount or 0),
                  int(p.credit_amount or 0),
                  int(p.manual_amount or 0),
                  p.method.name if p.method else '',
                  p.status,
                  p.authority or '',
                  p.ref_id or '',
                  p.created_at.strftime('%Y-%m-%d %H:%M')
                  if p.created_at else '',
                  p.verified_at.strftime('%Y-%m-%d %H:%M')
                  if p.verified_at else '',
                  p.verified_by.username if p.verified_by else '']
                 for p in payments_qs.select_related(
                     'inspection_request__customer',
                     'inspection_request__invoice',
                     'method', 'verified_by')])

            # Sheet عودت‌ها — ریز هر Refund (P0/P1 v10)
            refunds_qs = Refund.objects.filter(
                payment__in=payments_qs).select_related(
                'payment', 'payment__inspection_request__customer',
                'payment__inspection_request__invoice',
                'requested_by', 'approved_by')
            _sheet_from_rows(
                wb, 'عودت‌ها',
                ['Refund ID', 'Payment ID', 'Request ID', 'شماره درخواست',
                 'مشتری', 'شماره مشتری', 'شماره فاکتور', 'مبلغ (تومان)',
                 'مبلغ (ریال)', 'سهم اعتبار', 'سهم آنلاین', 'علت',
                 'وضعیت', 'وضعیت درگاه', 'Reference درگاه', 'درخواست‌دهنده',
                 'تأییدکننده', 'زمان درخواست', 'زمان تکمیل'],
                [[r.id, r.payment_id, r.inspection_request_id,
                  r.inspection_request.request_number,
                  r.customer.get_full_name() if r.customer else '',
                  r.customer.username if r.customer else '',
                  r.invoice.invoice_number if r.invoice else '',
                  int(r.amount_toman or 0), int(r.amount_rial or 0),
                  int(r.credit_amount or 0), int(r.online_amount or 0),
                  r.reason, r.status, r.gateway_status,
                  r.gateway_reference or '',
                  r.requested_by.username if r.requested_by else '',
                  r.approved_by.username if r.approved_by else '',
                  r.requested_at.strftime('%Y-%m-%d %H:%M')
                  if r.requested_at else '',
                  r.completed_at.strftime('%Y-%m-%d %H:%M')
                  if r.completed_at else '']
                 for r in refunds_qs])

            # Sheet دفتر کل — همه LedgerEntry ها (append-only)
            ledger_qs = LedgerEntry.objects.filter(
                payment__in=payments_qs).select_related(
                'payment', 'performed_by')
            _sheet_from_rows(
                wb, 'دفتر کل',
                ['Ledger ID', 'Payment ID', 'نوع', 'مبلغ (تومان)',
                 'مبلغ (ریال)', 'Reference', 'انجام‌دهنده', 'زمان',
                 'Metadata'],
                [[e.id, e.payment_id, e.entry_type,
                  int(e.amount_toman or 0), int(e.amount_rial or 0),
                  e.reference or '',
                  e.performed_by.username if e.performed_by else '',
                  e.created_at.strftime('%Y-%m-%d %H:%M')
                  if e.created_at else '',
                  (e.metadata or {})]
                 for e in ledger_qs])

            # Sheet Reconciliation — برای هر درخواست:
            # Invoice - پرداخت موفق + عودت = مانده
            _sheet_from_rows(
                wb, 'Reconciliation',
                ['Request ID', 'شماره درخواست', 'مشتری',
                 'فاکتور (تومان)', 'پرداخت موفق (تومان)',
                 'عودت (تومان)', 'مانده (تومان)'],
                [[q['request_id'], q['request_number'],
                  q['customer'],
                  int(q['invoice_total'] or 0),
                  int(q['paid_total'] or 0),
                  int(q['refund_total'] or 0),
                  int((q['invoice_total'] or 0)
                      - (q['paid_total'] or 0)
                      + (q['refund_total'] or 0))]
                 for q in _request_reconciliation(
                     payments_qs, invoices_qs)])

            return _xlsx_response(wb, 'financial_report.xlsx')

        # --- منبع truth: دفتر کل (LedgerEntry) با fallback به Payment ---
        # (P0-15 گزارش V3) — همه مقادیر int/ریال؛ بدون float حسابداری
        from ..services.ledger_service import ledger_totals
        # EDRA v35: قبلاً ledger_totals() کل تاریخچه را جمع می‌زد و فیلتر
        # بازه‌ی تاریخ روی «درآمد کل» اثر نداشت (باقی اعداد فیلتر می‌شدند).
        ledger_settlement, ledger_refunds = ledger_totals(date_from, date_to)

        paid_rial_raw = paid_qs.aggregate(
            t=Sum('effective_rial'))['t'] or 0
        ledger_has_entries = (ledger_settlement or 0) > 0
        total_revenue_rial = int(
            ledger_settlement - ledger_refunds
            if ledger_has_entries else paid_rial_raw)
        total_pending_rial = int(payments_qs.filter(
            status__in=['pending', 'pending_verification']
        ).annotate(eff=Coalesce(
            F('amount_rial'), F('amount') * Value(10))).aggregate(
            t=Sum('eff'))['t'] or 0)
        total_invoiced_rial = int(
            invoices_qs.aggregate(t=Sum('effective_rial'))['t'] or 0)

        return Response({
            'filters': {
                'date_from': str(date_from) if date_from else None,
                'date_to': str(date_to) if date_to else None,
            },
            'summary': {
                # ریال = source of truth حسابداری؛ تومان فقط برای نمایش
                'total_revenue': int(rial_to_toman(total_revenue_rial)),
                'total_revenue_rial': total_revenue_rial,
                'total_paid_count': paid_qs.count(),
                'total_pending_amount': int(rial_to_toman(total_pending_rial)),
                'total_pending_amount_rial': total_pending_rial,
                'total_pending_count': payments_qs.filter(
                    status__in=['pending', 'pending_verification']).count(),
                'total_rejected_count': payments_qs.filter(
                    status='rejected').count(),
                'total_invoiced': int(rial_to_toman(total_invoiced_rial)),
                'total_invoiced_rial': total_invoiced_rial,
                'total_credit_issued': int(credit_issued),
                'currency': 'IRR',
                # reconciliation دفتر کل (بدون float)
                'ledger_settlement_rial': int(ledger_settlement),
                'ledger_refunds_rial': int(ledger_refunds),
                'ledger_reconciled': ledger_has_entries,
            },
            'revenue_by_method': [{
                'method': row['method__name'] or 'نامشخص',
                'total': int(rial_to_toman(row['total_rial'] or 0)),
                'total_rial': int(row['total_rial'] or 0),
                'count': row['count'],
            } for row in by_method],
            'monthly_revenue': [{
                'month': row['month'].strftime('%Y-%m') if row['month'] else None,
                'total': int(rial_to_toman(row['total_rial'] or 0)),
                'total_rial': int(row['total_rial'] or 0),
                'count': row['count'],
            } for row in monthly],
        })


class AdminInspectionReportView(APIView):
    """
    گزارش تجمیعی کارشناسی‌های کل سیستم (با فیلتر بازه تاریخ اختیاری).
    GET /api/admin/reports/inspections/?date_from=&date_to=
    """
    permission_classes = [IsAdminUserOrGroup]

    def get(self, request):
        date_from, date_to = _parse_date_range(request)

        requests_qs = _apply_date_range(
            InspectionRequest.objects.all(), 'created_at', date_from, date_to)
        reports_qs = _apply_date_range(
            InspectionReport.objects.all(), 'created_at', date_from, date_to)

        by_status = list(
            requests_qs.values('status').annotate(count=Count('id')).order_by('-count'))
        by_equipment = list(
            requests_qs.values('equipment_type__name_fa')
            .annotate(count=Count('id')).order_by('-count'))
        by_city = list(
            requests_qs.values('city').annotate(count=Count('id')).order_by('-count'))
        by_result = list(
            reports_qs.values('overall_result')
            .annotate(count=Count('id')).order_by('-count'))

        by_expert = list(
            requests_qs.filter(assigned_expert__isnull=False)
            .values('assigned_expert__id', 'assigned_expert__first_name',
                    'assigned_expert__last_name', 'assigned_expert__username')
            .annotate(
                total=Count('id'),
                completed=Count('id', filter=Q(status='completed')),
            ).order_by('-total')
        )

        # میانگین فاصله GPS برای دید کلی از سلامت داده ضدتقلب (اختیاری)
        avg_gps_distance = reports_qs.filter(
            gps_distance_meters__isnull=False
        ).aggregate(avg=Avg('gps_distance_meters'))['avg']

        if _wants_xlsx(request):
            wb = Workbook()
            wb.remove(wb.active)
            _sheet_from_rows(wb, 'خلاصه', ['فیلد', 'مقدار'], [
                ['کل درخواست‌ها', requests_qs.count()],
                ['کل گزارش‌ها', reports_qs.count()],
                ['تکمیل‌شده', requests_qs.filter(status='completed').count()],
                ['لغوشده', requests_qs.filter(status='cancelled').count()],
                ['منقضی‌شده', requests_qs.filter(status='expired').count()],
                ['میانگین فاصله GPS (متر)',
                 round(avg_gps_distance, 1) if avg_gps_distance else '—'],
            ])
            _sheet_from_rows(wb, 'به تفکیک وضعیت', ['وضعیت', 'تعداد'],
                              [[r['status'], r['count']] for r in by_status])
            _sheet_from_rows(wb, 'به تفکیک نوع تجهیز', ['نوع تجهیز', 'تعداد'],
                              [[r['equipment_type__name_fa'] or 'نامشخص', r['count']]
                               for r in by_equipment])
            _sheet_from_rows(wb, 'به تفکیک شهر', ['شهر', 'تعداد'],
                              [[r['city'] or 'نامشخص', r['count']] for r in by_city])
            _sheet_from_rows(
                wb, 'عملکرد کارشناسان',
                ['کارشناس', 'کل ارجاع‌شده', 'تکمیل‌شده', 'درصد تکمیل'],
                [[(f"{r['assigned_expert__first_name']} {r['assigned_expert__last_name']}".strip()
                   or r['assigned_expert__username']),
                  r['total'], r['completed'],
                  round((r['completed'] / r['total'] * 100), 1) if r['total'] else 0]
                 for r in by_expert])

            # ==========================================================
            # P1 (EDRA v10): Sheet «ریز کارشناسی‌ها» — منبع Audit اصلی
            # هر ردیف = یک کارشناسی: کارشناس، زمان، GPS، مشتری، درخواست،
            # گزارش، نتیجه و وضعیت مالی کنار هم (reconciliation-ready)
            # ==========================================================
            detail_rows = []
            reports_detail = reports_qs.select_related(
                'inspection_request', 'inspection_request__customer',
                'inspection_request__customer__profile',
                'inspection_request__equipment_type',
                'inspection_request__assigned_expert',
                'checklist_template_version').prefetch_related(
                'inspection_request__payments',
                'inspection_request__invoice')
            for rep in reports_detail:
                req = rep.inspection_request
                payment = req.payments.first()
                invoice = getattr(req, 'invoice', None)
                detail_rows.append([
                    req.id,
                    req.request_number,
                    rep.id,
                    rep.report_number,
                    req.customer.get_full_name() if req.customer else '',
                    req.customer.username if req.customer else '',
                    req.equipment_type.name_fa if req.equipment_type else '',
                    req.brand_model or '',
                    req.city or '',
                    req.address or '',
                    req.assigned_expert.id if req.assigned_expert else '',
                    (req.assigned_expert.get_full_name()
                     if req.assigned_expert else ''),
                    req.scheduled_at.strftime('%Y-%m-%d %H:%M')
                    if req.scheduled_at else '',
                    rep.inspection_started_at.strftime('%Y-%m-%d %H:%M')
                    if rep.inspection_started_at else '',
                    rep.inspection_ended_at.strftime('%Y-%m-%d %H:%M')
                    if rep.inspection_ended_at else '',
                    rep.inspection_ended_at and rep.inspection_started_at
                    and round((rep.inspection_ended_at
                               - rep.inspection_started_at).total_seconds()
                              / 60, 1) or '',
                    rep.gps_start_lat if rep.gps_start_lat is not None else '',
                    rep.gps_start_lng if rep.gps_start_lng is not None else '',
                    rep.gps_end_lat if rep.gps_end_lat is not None else '',
                    rep.gps_end_lng if rep.gps_end_lng is not None else '',
                    rep.gps_distance_meters
                    if rep.gps_distance_meters is not None else '',
                    rep.overall_result or '',
                    req.status,
                    rep.checklist_template_version.version
                    if rep.checklist_template_version else '',
                    rep.created_at.strftime('%Y-%m-%d %H:%M')
                    if rep.created_at else '',
                    'PDF' if rep.pdf_file else '—',
                    'امضا' if rep.signed_pdf_file else '—',
                    payment.amount if payment else '',
                    payment.status if payment else '',
                    invoice.invoice_number if invoice else '',
                    invoice.is_paid if invoice else '',
                ])
            _sheet_from_rows(
                wb, 'ریز کارشناسی‌ها',
                ['ID درخواست', 'شماره درخواست', 'ID گزارش',
                 'شماره گزارش', 'مشتری', 'شماره مشتری', 'نوع تجهیز',
                 'برند/مدل', 'شهر', 'آدرس', 'کارشناس ID', 'نام کارشناس',
                 'زمان برنامه‌ریزی', 'زمان شروع واقعی', 'زمان پایان واقعی',
                 'مدت کارشناسی (دقیقه)', 'GPS شروع Lat', 'GPS شروع Lng',
                 'GPS پایان Lat', 'GPS پایان Lng', 'فاصله GPS (متر)',
                 'نتیجه', 'وضعیت درخواست', 'نسخه چک‌لیست',
                 'تاریخ صدور گزارش', 'وضعیت PDF', 'وضعیت امضا',
                 'مبلغ پرداخت (تومان)', 'وضعیت پرداخت',
                 'شماره فاکتور', 'وضعیت فاکتور'],
                detail_rows)
            return _xlsx_response(wb, 'inspection_report.xlsx')

        return Response({
            'filters': {
                'date_from': str(date_from) if date_from else None,
                'date_to': str(date_to) if date_to else None,
            },
            'summary': {
                'total_requests': requests_qs.count(),
                'total_reports': reports_qs.count(),
                'completed_requests': requests_qs.filter(status='completed').count(),
                'cancelled_requests': requests_qs.filter(status='cancelled').count(),
                'expired_requests': requests_qs.filter(status='expired').count(),
                'avg_gps_distance_meters': round(avg_gps_distance, 1) if avg_gps_distance else None,
            },
            'by_status': [{'status': r['status'], 'count': r['count']} for r in by_status],
            'by_equipment': [{
                'equipment': r['equipment_type__name_fa'] or 'نامشخص',
                'count': r['count'],
            } for r in by_equipment],
            'by_city': [{'city': r['city'] or 'نامشخص', 'count': r['count']} for r in by_city],
            'by_result': [{'result': r['overall_result'], 'count': r['count']} for r in by_result],
            'by_expert': [{
                'expert_id': r['assigned_expert__id'],
                'expert_name': (
                    f"{r['assigned_expert__first_name']} {r['assigned_expert__last_name']}".strip()
                    or r['assigned_expert__username']
                ),
                'total_assigned': r['total'],
                'completed': r['completed'],
                'completion_rate': round(
                    (r['completed'] / r['total'] * 100), 1) if r['total'] else 0,
            } for r in by_expert],
        })
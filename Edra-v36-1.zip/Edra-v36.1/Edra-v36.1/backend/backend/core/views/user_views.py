# core/views/user_views.py
from django.contrib.auth import get_user_model
from django.contrib.auth.models import Group
from django.db import transaction
from rest_framework import viewsets, status, filters
from rest_framework.decorators import action
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated
from django_filters.rest_framework import DjangoFilterBackend

from core.permissions import IsAdminUserOrGroup
from core.serializers import UserSerializer
from core.filters import UserFilter

User = get_user_model()

VALID_ROLES = ('customer', 'expert', 'admin')
ROLE_GROUP_NAMES = {'expert': 'Expert', 'admin': 'Admin'}


# ============================================================
# UserViewSet
# ============================================================
class UserViewSet(viewsets.ModelViewSet):
    # EDRA v17 — MEDIUM-1 (ممیزی v16): رفع N+1 — قبلاً برای هر کاربر
    # ۴-۵ کوئری جدا (profile/groups/projects) زده می‌شد.
    queryset = User.objects.select_related('profile').prefetch_related(
        'groups', 'profile__projects')
    serializer_class = UserSerializer
    permission_classes = [IsAdminUserOrGroup]
    filter_backends = [DjangoFilterBackend, filters.SearchFilter, filters.OrderingFilter]
    filterset_class = UserFilter
    search_fields = ['username', 'email', 'first_name', 'last_name']
    ordering_fields = ['username', 'date_joined']
    ordering = ['username']

    def get_throttles(self):
        # L-2 (v17): throttle اختصاصی برای حدس‌زدن old_password
        if self.action == 'change_password':
            from rest_framework.throttling import ScopedRateThrottle
            self.throttle_scope = 'password_change'
            return [ScopedRateThrottle()]
        return super().get_throttles()

    # ------------------------------------------------------------
    # EDRA v32 — ساخت/ویرایش/حذف کاربر توسط ادمین (صفحات تازه‌ی
    # «مشتری/کارشناس جدید» و «ویرایش» در داشبورد)
    # ------------------------------------------------------------
    def _audit(self, request, action_name, target, changes):
        from ..models import AuditLog
        try:
            AuditLog.objects.create(
                user=request.user, action=action_name,
                object_id=target.id, changes=changes)
        except Exception as log_error:
            import logging
            logging.getLogger(__name__).error(
                f"Error writing audit log for {action_name}: {log_error}")

    def _guard_privileged_target(self, request, target):
        """فقط سوپریوزر می‌تواند کاربرِ دارای is_staff/is_superuser را تغییر دهد."""
        from rest_framework.exceptions import PermissionDenied
        if ((target.is_staff or target.is_superuser)
                and not request.user.is_superuser
                and target.id != request.user.id):
            raise PermissionDenied(
                'فقط سوپریوزر می‌تواند کاربر دارای دسترسی مدیریتی را تغییر دهد.')

    def create(self, request, *args, **kwargs):
        role = request.data.get('role') or 'customer'
        if role not in VALID_ROLES:
            return Response(
                {'role': [f"نقش باید یکی از {VALID_ROLES} باشد."]},
                status=status.HTTP_400_BAD_REQUEST)
        if role == 'admin' and not request.user.is_superuser:
            return Response(
                {'role': ['فقط سوپریوزر می‌تواند نقش «ادمین» اعطا کند.']},
                status=status.HTTP_403_FORBIDDEN)

        serializer = self.get_serializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        # ساخت کاربر + پروفایل + گروه نقش در یک تراکنش: یا همه یا هیچ
        with transaction.atomic():
            user = serializer.save()
            if role in ROLE_GROUP_NAMES:
                group, _ = Group.objects.get_or_create(name=ROLE_GROUP_NAMES[role])
                user.groups.add(group)
            self._audit(request, 'user_create', user,
                        {'target_username': user.username, 'role': role})
        user = self.get_queryset().get(pk=user.pk)
        return Response(self.get_serializer(user).data,
                        status=status.HTTP_201_CREATED)

    def perform_update(self, serializer):
        from rest_framework.exceptions import ValidationError
        target = serializer.instance
        self._guard_privileged_target(self.request, target)
        if (serializer.validated_data.get('is_active') is False
                and target.id == self.request.user.id):
            raise ValidationError(
                {'is_active': ['نمی‌توانید حساب کاربری خودتان را غیرفعال کنید.']})
        was_active = target.is_active
        user = serializer.save()
        if was_active and not user.is_active:
            from ..security import revoke_user_refresh_tokens
            revoke_user_refresh_tokens(user)
        self._audit(self.request, 'user_update', user,
                    {'target_username': user.username,
                     'fields': sorted(serializer.validated_data.keys())})

    def perform_destroy(self, instance):
        # حذف سخت کاربر به‌صورت cascade درخواست‌ها/فاکتورها/گزارش‌هایش را هم
        # پاک می‌کرد. به‌جای آن حساب غیرفعال می‌شود (برگشت‌پذیر + حفظ سوابق مالی).
        from rest_framework.exceptions import ValidationError
        self._guard_privileged_target(self.request, instance)
        if instance.id == self.request.user.id:
            raise ValidationError('نمی‌توانید حساب کاربری خودتان را حذف کنید.')
        instance.is_active = False
        instance.save(update_fields=['is_active'])
        from ..security import revoke_user_refresh_tokens
        revoke_user_refresh_tokens(instance)
        self._audit(self.request, 'user_deactivate', instance,
                    {'target_username': instance.username})

    @action(detail=False, methods=['post'],
            permission_classes=[IsAuthenticated])
    def change_password(self, request):
        user = request.user
        old_password = request.data.get('old_password')
        new_password = request.data.get('new_password')

        if not old_password or not new_password:
            return Response({'error': 'رمز فعلی و جدید را وارد کنید.'},
                            status=status.HTTP_400_BAD_REQUEST)

        if not user.check_password(old_password):
            return Response({'error': 'رمز فعلی اشتباه است.'},
                            status=status.HTTP_400_BAD_REQUEST)

        # EDRA v27 — همان رفع باگ امنیتی که در core/expert/views.py
        # ChangePasswordView اعمال شد — این هم یک endpoint موازی برای
        # تغییر رمز است که همان کمبود را داشت.
        from django.contrib.auth.password_validation import validate_password
        from django.core.exceptions import ValidationError as DjangoValidationError
        try:
            validate_password(new_password, user=user)
        except DjangoValidationError as e:
            return Response({'error': ' '.join(e.messages)},
                            status=status.HTTP_400_BAD_REQUEST)

        user.set_password(new_password)
        user.save()
        # P1-07 (EDRA v8): باطل کردن همه refresh token های قبلی — یک رمز
        # دزدیده‌شده/قدیمی نباید session باز نگه دارد.
        from ..security import revoke_user_refresh_tokens
        revoke_user_refresh_tokens(user)
        return Response({'success': True,
                         'message': 'رمز عبور با موفقیت تغییر کرد.'})

    # EDRA v27 — قابلیت تازه (گزارش کاربر، سپتامبر ۲۰۲۶): «تخصیص نقش
    # گیج‌کننده و پرخطر». قبلاً تنها راه تغییر نقش، دستکاری مستقیم
    # چک‌باکس‌های is_staff/is_superuser یا لیست گروه‌ها در پنل خام جنگو
    # بود — بدون هیچ محدودیت یا تاییدیه‌ای. این اکشن یک مسیر امن و محدود
    # جایگزین آن می‌کند:
    #   - فقط سه مقدار دقیق مجاز است (customer/expert/admin)
    #   - هرگز is_staff/is_superuser را دست نمی‌زند؛ فقط عضویت گروه را
    #     تغییر می‌دهد (کمترین دسترسی لازم، مطابق همان الگویی که
    #     IsAdminUserOrGroup از قبل برایش طراحی شده بود)
    #   - کاربرانی که از قبل is_staff/is_superuser دارند از این مسیر رد
    #     می‌شوند (تغییر گروه برایشان بی‌اثر و گمراه‌کننده است)؛ باید
    #     مستقیماً در پنل جنگو مدیریت شوند
    #   - ادمین نمی‌تواند نقش خودش را از همین‌جا تغییر بدهد (جلوگیری از
    #     قفل‌شدن تصادفی)
    #   - اعطای نقش «ادمین» فقط توسط superuser مجاز است (یک ادمین معمولی
    #     نمی‌تواند ادمین دیگری بسازد)
    #   - هر تغییر در AuditLog ثبت می‌شود
    @action(detail=True, methods=['post'],
            permission_classes=[IsAdminUserOrGroup], url_path='set-role')
    def set_role(self, request, pk=None):
        target_user = self.get_object()
        new_role = request.data.get('role')

        if new_role not in VALID_ROLES:
            return Response(
                {'error': f"نقش باید یکی از {VALID_ROLES} باشد."},
                status=status.HTTP_400_BAD_REQUEST
            )

        if target_user.is_staff or target_user.is_superuser:
            return Response(
                {'error': 'این کاربر دارای دسترسی is_staff/is_superuser است؛ '
                          'نقش او باید مستقیماً در پنل مدیریت جنگو تغییر کند، '
                          'نه از این مسیر (تغییر گروه در وضعیت او اثری ندارد).'},
                status=status.HTTP_400_BAD_REQUEST
            )

        if target_user.id == request.user.id:
            return Response(
                {'error': 'نمی‌توانید نقش خودتان را از همین‌جا تغییر دهید.'},
                status=status.HTTP_400_BAD_REQUEST
            )

        if new_role == 'admin' and not request.user.is_superuser:
            return Response(
                {'error': 'فقط سوپریوزر می‌تواند نقش «ادمین» اعطا کند.'},
                status=status.HTTP_403_FORBIDDEN
            )

        old_role_groups = list(
            target_user.groups.filter(
                name__in=ROLE_GROUP_NAMES.values()).values_list(
                'name', flat=True))

        with transaction.atomic():
            target_user.groups.remove(
                *Group.objects.filter(name__in=ROLE_GROUP_NAMES.values()))
            if new_role in ROLE_GROUP_NAMES:
                group, _ = Group.objects.get_or_create(
                    name=ROLE_GROUP_NAMES[new_role])
                target_user.groups.add(group)

            from ..models import AuditLog
            try:
                AuditLog.objects.create(
                    user=request.user, action='role_change',
                    object_id=target_user.id,
                    changes={
                        'target_username': target_user.username,
                        'old_groups': old_role_groups,
                        'new_role': new_role,
                    })
            except Exception as log_error:
                import logging
                logging.getLogger(__name__).error(
                    f"Error writing audit log for role_change: {log_error}")

        return Response({
            'success': True,
            'message': f'نقش کاربر به «{new_role}» تغییر یافت.',
            'role': new_role,
        })
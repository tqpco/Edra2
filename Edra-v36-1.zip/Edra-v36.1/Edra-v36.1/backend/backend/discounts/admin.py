# discounts/admin.py
from django.contrib import admin
from django import forms
from django.urls import reverse
from django.utils.html import format_html
from django.contrib import messages
from django.core.exceptions import PermissionDenied

# ✅ اصلاح ایمپورت‌ها — جایگزینی core.admin.jalali_widgets با edra_jalalidate
from edra_jalalidate.admin import EdraJalaliAdminMixin, make_jalali_date_filter
from edra_jalalidate import to_jalali

from .models import DiscountCampaign, DiscountCodeUsage
from .tasks import process_campaign_task


class DiscountCampaignForm(forms.ModelForm):
    class Meta:
        model = DiscountCampaign
        fields = '__all__'

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        # اگر شرط "کاربر جدید" نباشد، فیلد تعداد روز را مخفی می‌کنیم
        if self.instance and self.instance.condition_type != 'new_user':
            self.fields['new_user_days_threshold'].widget = forms.HiddenInput()


@admin.register(DiscountCampaign)
class DiscountCampaignAdmin(EdraJalaliAdminMixin, admin.ModelAdmin):
    form = DiscountCampaignForm
    list_display = (
        'name',
        'condition_type',
        'condition_value',
        'new_user_days_threshold',
        'discount_code_template',
        'is_active',
        'last_run_at_display',
        'created_at_display')
    list_filter = (
        'is_active', 'condition_type',
        make_jalali_date_filter('created_at', 'تاریخ ایجاد'))
    search_fields = ('name',)
    readonly_fields = (
        'last_run_at_display', 'created_at_display', 'updated_at_display')
    actions = ['run_campaign']
    fieldsets = (
        ('اطلاعات کمپین', {
            'fields': ('name', 'is_active')
        }),
        ('شرط اجرا', {
            'fields': ('condition_type', 'condition_value', 'new_user_days_threshold'),
            'description': 'کاربرانی که این شرط را داشته باشند، به‌صورت خودکار کد تخفیف دریافت می‌کنند.'
        }),
        ('قالب کد تخفیف', {
            'fields': ('discount_code_template',),
            'description': 'سیستم یک کد جدید با همین تنظیمات برای هر کاربر تولید می‌کند.'
        }),
        ('اطلاعات سیستمی', {
            'fields': ('last_run_at_display', 'created_at_display', 'updated_at_display'),
            'classes': ('collapse',)
        }),
    )

    class Media:
        js = ('admin/js/discount_campaign_admin.js',)

    def last_run_at_display(self, obj):
        return to_jalali(obj.last_run_at)
    last_run_at_display.short_description = "آخرین اجرا"

    def created_at_display(self, obj):
        return to_jalali(obj.created_at)
    created_at_display.short_description = "تاریخ ایجاد"
    created_at_display.admin_order_field = 'created_at'

    def updated_at_display(self, obj):
        return to_jalali(obj.updated_at)
    updated_at_display.short_description = "تاریخ بروزرسانی"

    def run_campaign(self, request, queryset):
        if not request.user.has_perm('discounts.change_discountcampaign'):
            raise PermissionDenied
        for campaign in queryset:
            process_campaign_task.delay(campaign.id)
        self.message_user(
            request,
            f'کمپین‌های انتخاب‌شده در پس‌زمینه پردازش می‌شوند.',
            messages.SUCCESS)
    run_campaign.short_description = 'اجرای کمپین انتخاب‌شده'


@admin.register(DiscountCodeUsage)
class DiscountCodeUsageAdmin(EdraJalaliAdminMixin, admin.ModelAdmin):
    list_display = ('user', 'discount_code', 'campaign', 'sent_at', 'used_at')
    list_filter = ('campaign', 'used_at')
    search_fields = ('user__username', 'discount_code__code')
    date_hierarchy = 'sent_at'  # ✅ فیلد `DateTimeField` استاندارد است
    autocomplete_fields = ['user']
    readonly_fields = ('sent_at',)
    fieldsets = (
        ('ثبت استفاده', {
            'fields': ('user', 'discount_code', 'campaign'),
            'description': 'برای جستجوی کاربر، نام کاربری، ایمیل یا شماره موبایل را تایپ کنید.'
        }),
        ('زمان‌ها', {
            'fields': ('sent_at', 'used_at'),
            'classes': ('collapse',)
        }),
    )
# discounts/models.py
from django.db import models
from django.contrib.auth import get_user_model
from core.models import DiscountCode

User = get_user_model()


class DiscountCampaign(models.Model):
    CONDITION_TYPES = [
        ('purchase_count', 'تعداد خرید'),
        ('completed_requests', 'تعداد درخواست‌های تکمیل‌شده'),
        ('total_spent', 'مبلغ کل خرید'),
        ('new_user', 'کاربر جدید (ثبت‌نام اخیر)'),
    ]

    name = models.CharField(max_length=200, verbose_name='نام کمپین')
    condition_type = models.CharField(
        max_length=20,
        choices=CONDITION_TYPES,
        default='completed_requests',
        verbose_name='شرط'
    )
    condition_value = models.PositiveIntegerField(
        default=1,
        verbose_name='مقدار شرط (تعداد یا مبلغ)',
        help_text='برای شرط "کاربر جدید"، این مقدار استفاده نمی‌شود.'
    )
    new_user_days_threshold = models.PositiveIntegerField(
        default=7,
        verbose_name='تعداد روزهای ثبت‌نام (برای کاربر جدید)',
        help_text='کاربرانی که در این تعداد روز اخیر ثبت‌نام کرده‌اند، واجد شرط هستند.')
    discount_code_template = models.ForeignKey(
        DiscountCode,
        on_delete=models.PROTECT,
        verbose_name='قالب کد تخفیف',
        help_text='یک کد تخفیف موجود به‌عنوان الگو انتخاب کنید. سیستم برای هر کاربر یک کد جدید با همان تنظیمات تولید می‌کند.'
    )
    is_active = models.BooleanField(default=True, verbose_name='فعال')
    last_run_at = models.DateTimeField(
        null=True, blank=True, verbose_name='آخرین اجرا')
    created_at = models.DateTimeField(
        auto_now_add=True, verbose_name='تاریخ ایجاد')
    updated_at = models.DateTimeField(
        auto_now=True, verbose_name='تاریخ بروزرسانی')

    class Meta:
        verbose_name = 'کمپین تخفیف'
        verbose_name_plural = 'کمپین‌های تخفیف'

    def __str__(self):
        return self.name


class DiscountCodeUsage(models.Model):
    user = models.ForeignKey(
        User,
        on_delete=models.CASCADE,
        related_name='discount_usages',
        verbose_name='کاربر'
    )
    discount_code = models.ForeignKey(
        DiscountCode,
        on_delete=models.CASCADE,
        related_name='usages',
        verbose_name='کد تخفیف'
    )
    campaign = models.ForeignKey(
        DiscountCampaign,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name='usages',
        verbose_name='کمپین'
    )
    sent_at = models.DateTimeField(
        auto_now_add=True,
        verbose_name='تاریخ ارسال')
    used_at = models.DateTimeField(
        null=True, blank=True, verbose_name='تاریخ استفاده')

    class Meta:
        verbose_name = 'استفاده از کد تخفیف'
        verbose_name_plural = 'استفاده‌های کد تخفیف'
        constraints = [
            models.UniqueConstraint(
                fields=['user', 'discount_code'],
                name='uniq_user_discount_code'),
            models.UniqueConstraint(
                fields=['user', 'campaign'],
                name='uniq_user_campaign'),
        ]

    def __str__(self):
        return f"{self.user.username} - {self.discount_code.code}"
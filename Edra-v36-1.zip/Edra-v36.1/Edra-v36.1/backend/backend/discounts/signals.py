# discounts/signals.py
from django.db.models.signals import post_save, pre_save
from django.dispatch import receiver
from django.contrib.auth import get_user_model
from django.utils import timezone
from django.db import transaction
import logging

from core.models import InspectionRequest, Payment
from .models import DiscountCampaign, DiscountCodeUsage, DiscountCode
from .tasks import check_user_campaigns_task

logger = logging.getLogger(__name__)
User = get_user_model()


# ============================================================
# P1 (EDRA v9): باگ «post_save → query old_instance» —
# بعد از save، کوئری دوباره همان state جدید را برمی‌گرداند و شرط
# تغییر وضعیت همیشه false می‌شد (campaign ها هرگز trigger نمی‌شدند).
# حالا state قبلی در pre_save روی instance ذخیره می‌شود.
# ============================================================
@receiver(pre_save, sender=InspectionRequest)
def _capture_request_old_status(sender, instance, **kwargs):
    instance._old_status = None
    if instance.pk:
        try:
            instance._old_status = InspectionRequest.objects.filter(
                pk=instance.pk).values_list('status', flat=True).first()
        except Exception:
            instance._old_status = None


@receiver(pre_save, sender=Payment)
def _capture_payment_old_status(sender, instance, **kwargs):
    instance._old_status = None
    if instance.pk:
        try:
            instance._old_status = Payment.objects.filter(
                pk=instance.pk).values_list('status', flat=True).first()
        except Exception:
            instance._old_status = None


def _queue_campaign_check(user_id):
    """
    EDRA v36 — باگ مقاومت: `.delay()` مستقیم داخل post_save (و اغلب داخل
    transaction.atomic ی تسویه‌ی پرداخت) بود؛ با قطعی Redis/Celery استثنا از
    save() بیرون می‌زد و کل تسویه‌ی پرداخت (callback/تایید ادمین) rollback و ۵۰۰
    می‌شد، در حالی که پول از درگاه کسر شده بود. اکنون (۱) بعد از commit صف
    می‌شود (تسک پرداختِ commit-نشده را نمی‌دید) و (۲) خطا فقط لاگ می‌شود.
    """
    def _send():
        try:
            check_user_campaigns_task.delay(user_id)
        except Exception as e:
            logger.error(f"Campaign check queue failed (user {user_id}): {e}")
    transaction.on_commit(_send)


def _get_user_from_inspection_request(instance):
    """استخراج کاربر از یک درخواست بازرسی"""
    return instance.customer


def _get_user_from_payment(instance):
    """استخراج کاربر از یک پرداخت"""
    return instance.inspection_request.customer


def _get_user_from_instance(instance):
    """
    تعیین کاربر بر اساس نوع نمونه (InspectionRequest یا Payment)
    """
    if isinstance(instance, InspectionRequest):
        return _get_user_from_inspection_request(instance)
    elif isinstance(instance, Payment):
        return _get_user_from_payment(instance)
    else:
        return None


@receiver(post_save, sender=InspectionRequest)
def check_campaigns_on_request_completed(sender, instance, created, **kwargs):
    """
    سیگنال: پس از ذخیره‌سازی یک درخواست بازرسی، اگر وضعیت آن به 'completed' تغییر کرده باشد،
    کمپین‌های تخفیف فعال را برای کاربر بررسی می‌کند.
    """
    # فقط زمانی که وضعیت به 'completed' تغییر کرده است (نه ایجاد اولیه)
    if created:
        return

    old_status = getattr(instance, '_old_status', None)

    if old_status != 'completed' and instance.status == 'completed':
        user = _get_user_from_inspection_request(instance)
        if user:
            # فراخوانی تسک برای بررسی کمپین‌ها در پس‌زمینه
            _queue_campaign_check(user.id)
            logger.info(
                f"User {user.username} completed request #{instance.id}. Checking campaigns.")


@receiver(post_save, sender=Payment)
def check_campaigns_on_payment_paid(sender, instance, created, **kwargs):
    """
    سیگنال: پس از ذخیره‌سازی یک پرداخت، اگر وضعیت آن به 'paid' تغییر کرده باشد،
    کمپین‌های تخفیف فعال را برای کاربر بررسی می‌کند.
    """
    if created:
        return

    old_status = getattr(instance, '_old_status', None)

    if old_status != 'paid' and instance.status == 'paid':
        user = _get_user_from_payment(instance)
        if user:
            _queue_campaign_check(user.id)
            logger.info(
                f"User {user.username} made a successful payment #{instance.id}. Checking campaigns.")
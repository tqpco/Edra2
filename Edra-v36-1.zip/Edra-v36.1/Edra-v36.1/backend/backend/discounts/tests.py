# discounts/tests.py — EDRA v17 (MEDIUM-3): حفاظت رگرسیون موتور تخفیف
"""
مستند VERSION: موتور تخفیف در v14 فیکس race (ارسال تکراری کد) خورده —
این تست‌ها مطمئن می‌شوند همان باگ برنگردد.
"""
import pytest
from django.contrib.auth import get_user_model

from core.models import DiscountCode
from discounts.models import DiscountCodeUsage, DiscountCampaign

User = get_user_model()
pytestmark = pytest.mark.django_db


@pytest.fixture
def campaign_user():
    u = User.objects.create_user(username='camp_test', password='x' * 8)
    return u


@pytest.fixture
def discount():
    return DiscountCode.objects.create(
        code='TST17', discount_type='percent', value=10,
        usage_limit=1, per_user_limit=1, is_active=True)


class TestUsageDedup:
    def test_unique_user_discount_code(self, campaign_user, discount):
        DiscountCodeUsage.objects.create(
            user=campaign_user, discount_code=discount)
        # constraint سطح DB — دومی باید IntegrityError بدهد
        from django.db import IntegrityError
        with pytest.raises(IntegrityError):
            DiscountCodeUsage.objects.create(
                user=campaign_user, discount_code=discount)

    def test_unique_user_campaign(self, campaign_user, discount):
        campaign = DiscountCampaign.objects.create(
            name='کمپین تست',
            discount_code_template=discount,
            is_active=True)
        DiscountCodeUsage.objects.create(
            user=campaign_user, discount_code=discount,
            campaign=campaign)
        from django.db import IntegrityError
        with pytest.raises(IntegrityError):
            DiscountCodeUsage.objects.create(
                user=campaign_user, discount_code=discount,
                campaign=campaign)

    def test_generate_uses_csprng_style_codes(self, campaign_user, discount):
        """کدهای تولیدشده باید طول/کاراکتر استاندارد داشته باشند."""
        from discounts.tasks import _generate_and_send_discount_for_user
        campaign = DiscountCampaign.objects.create(
            name='کمپین CSPRNG',
            discount_code_template=discount,
            is_active=True)
        # فلوی صحیح v17: کد تولید می‌شود سپس usage با همان کد ثبت می‌شود
        new_code = _generate_and_send_discount_for_user(
            campaign_user, campaign)
        assert new_code is not None
        DiscountCodeUsage.objects.create(
            user=campaign_user, campaign=campaign,
            discount_code=new_code)
        usage = DiscountCodeUsage.objects.get(
            user=campaign_user, campaign=campaign)
        assert len(usage.discount_code.code) == 8
        assert usage.discount_code.code.isalnum()
        # کاربر دوم کد متفاوت می‌گیرد
        user2 = User.objects.create_user(
            username='camp_test2', password='x' * 8)
        code2 = _generate_and_send_discount_for_user(user2, campaign)
        assert code2 is not None
        DiscountCodeUsage.objects.create(
            user=user2, campaign=campaign, discount_code=code2)
        usage2 = DiscountCodeUsage.objects.get(user=user2, campaign=campaign)
        assert usage2.discount_code.code != usage.discount_code.code


class TestOrphanCodeDeactivation:
    """EDRA v18 — باگ #۲: کد یتیم race نباید قابل‌استفاده بماند."""

    def test_orphaned_code_deactivated(self, campaign_user, discount):
        from discounts.tasks import _deactivate_orphaned_code
        _deactivate_orphaned_code(discount)
        discount.refresh_from_db()
        assert discount.is_active is False

    def test_deactivation_idempotent(self, campaign_user, discount):
        from discounts.tasks import _deactivate_orphaned_code
        _deactivate_orphaned_code(discount)
        _deactivate_orphaned_code(discount)  # دوباره — بدون خطا
        discount.refresh_from_db()
        assert discount.is_active is False


class TestContentDisposition:
    """EDRA v18 — باگ #۳: هدر دانلود باید ASCII-only (RFC 5987) باشد."""

    def test_header_is_ascii_encodable(self):
        from core.utils.http_headers import build_content_disposition
        header = build_content_disposition(
            'گزارش_IR-2026-00042.pdf', 'report_IR-2026-00042.pdf')
        # کل هدر باید قابل encode با latin-1 باشد (استاندارد HTTP)
        header.encode('latin-1')
        assert 'filename="report_IR-2026-00042.pdf"' in header
        assert "filename*=UTF-8''" in header
        assert '%' in header  # نام فارسی percent-encoded شده
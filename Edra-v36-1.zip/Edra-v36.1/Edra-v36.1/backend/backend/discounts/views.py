from rest_framework import generics, permissions, status
from core.permissions import IsAdminUserOrGroup
from rest_framework.response import Response
from rest_framework.views import APIView
from django.contrib.auth import get_user_model
from django.db import models
from .serializers import UserSearchSerializer
from .tasks import send_discount_to_user, send_discount_to_all_users
from core.models import DiscountCode
import logging

User = get_user_model()
logger = logging.getLogger(__name__)


class UserSearchView(generics.ListAPIView):
    """
    API برای جستجوی کاربران (AJAX) بر اساس نام کاربری، ایمیل یا شماره موبایل.
    """
    serializer_class = UserSearchSerializer
    permission_classes = [IsAdminUserOrGroup]

    def get_queryset(self):
        query = self.request.query_params.get('q', '')
        if not query:
            return User.objects.none()
        return User.objects.filter(
            models.Q(username__icontains=query) |
            models.Q(email__icontains=query) |
            models.Q(profile__phone__icontains=query)
        ).distinct()[:20]


class SendDiscountToUserView(APIView):
    """
    API برای ارسال کد تخفیف به یک کاربر خاص (با شناسه کاربری).
    فقط برای ادمین.
    """
    permission_classes = [IsAdminUserOrGroup]

    def post(self, request):
        user_id = request.data.get('user_id')
        discount_id = request.data.get('discount_id')
        if not user_id or not discount_id:
            return Response({'error': 'user_id و discount_id الزامی هستند.'},
                            status=status.HTTP_400_BAD_REQUEST)
        try:
            user = User.objects.get(id=user_id)
        except User.DoesNotExist:
            return Response({'error': 'کاربر یافت نشد.'},
                            status=status.HTTP_404_NOT_FOUND)
        try:
            discount = DiscountCode.objects.get(id=discount_id)
        except DiscountCode.DoesNotExist:
            return Response({'error': 'کد تخفیف یافت نشد.'},
                            status=status.HTTP_404_NOT_FOUND)
        # EDRA v14 — LOW 3.1.5: اعتبار کد قبل از ارسال (فعال + منقضی‌نشده)
        from django.utils import timezone as _tz
        if not discount.is_active:
            return Response(
                {'error': 'کد تخفیف غیرفعال است.'},
                status=status.HTTP_400_BAD_REQUEST)
        if discount.expires_at and discount.expires_at < _tz.now():
            return Response(
                {'error': 'کد تخفیف منقضی شده است.'},
                status=status.HTTP_400_BAD_REQUEST)
        try:
            send_discount_to_user.delay(user.id, discount.id)
        except Exception as broker_error:
            logger.error(f"send_discount_to_user queue failed: {broker_error}")
            return Response(
                {'error': 'سرویس صف پیام در دسترس نیست؛ کمی بعد دوباره تلاش کنید.'},
                status=status.HTTP_503_SERVICE_UNAVAILABLE)
        return Response({'success': True,
                         'message': 'کد تخفیف در حال ارسال است.'})


# ✅ API جدید: ارسال کد تخفیف به همه کاربران
class SendDiscountToAllUsersView(APIView):
    """
    API برای ارسال کد تخفیف به همه کاربران فعال.
    فقط برای ادمین.
    """
    permission_classes = [IsAdminUserOrGroup]

    def post(self, request):
        discount_id = request.data.get('discount_id')
        if not discount_id:
            return Response({'error': 'discount_id الزامی است.'},
                            status=status.HTTP_400_BAD_REQUEST)
        try:
            discount = DiscountCode.objects.get(id=discount_id)
        except DiscountCode.DoesNotExist:
            return Response({'error': 'کد تخفیف یافت نشد.'},
                            status=status.HTTP_404_NOT_FOUND)
        try:
            send_discount_to_all_users.delay(discount.id)
        except Exception as broker_error:
            logger.error(f"send_discount_to_all_users queue failed: {broker_error}")
            return Response(
                {'error': 'سرویس صف پیام در دسترس نیست؛ کمی بعد دوباره تلاش کنید.'},
                status=status.HTTP_503_SERVICE_UNAVAILABLE)
        return Response(
            {'success': True, 'message': 'کد تخفیف در حال ارسال به همه کاربران است.'})

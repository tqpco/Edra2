# edra/asgi.py
# -*- coding: utf-8 -*-

import os
from django.core.asgi import get_asgi_application

# ✅ اصلاح: استفاده از settings_production در Production
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'edra.settings_production')

django_asgi_app = get_asgi_application()

from channels.routing import ProtocolTypeRouter, URLRouter
from django.urls import path

from notifications.consumers import NotificationConsumer
from support.consumers import TicketConsumer
from edra.ws_auth import WsTicketAuthMiddleware

application = ProtocolTypeRouter({
    'http': django_asgi_app,
    'websocket': WsTicketAuthMiddleware(
        URLRouter([
            path('ws/notifications/', NotificationConsumer.as_asgi()),
            path('ws/tickets/', TicketConsumer.as_asgi()),
        ])
    ),
})
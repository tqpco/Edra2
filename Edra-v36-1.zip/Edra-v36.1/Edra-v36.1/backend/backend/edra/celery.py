from celery.schedules import crontab
from celery import Celery
import os
import logging

logger = logging.getLogger(__name__)

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'edra.settings')

app = Celery('edra')
app.config_from_object('django.conf:settings', namespace='CELERY')
app.autodiscover_tasks()

# ✅ تنظیم تسک‌های دوره‌ای (Beat Schedule)
app.conf.beat_schedule = {
    # تسک‌های موجود
    'check-expiring-discount-codes': {
        'task': 'core.tasks.check_expiring_discount_codes',
        'schedule': crontab(hour=8, minute=0),
    },
    'manage-unpaid-request-lifecycle': {
        'task': 'core.tasks.manage_unpaid_request_lifecycle',
        'schedule': crontab(minute=0),  # هر ساعت — یادآوری ۲۴/۴۸ ساعته + بستن خودکار ۷۲ ساعته
    },
    'process-pending-notifications': {
        'task': 'notifications.tasks.process_pending_notifications',
        'schedule': crontab(minute='*/5'),
    },
    'auto-close-inactive-tickets': {
        'task': 'support.tasks.auto_close_inactive_tickets',
        'schedule': crontab(minute=0),  # هر ساعت
    },

    # ✅ تسک‌های جدید برای سیستم تیکتینگ
    'send-due-date-reminders': {
        'task': 'support.tasks.send_due_date_reminders',
        'schedule': crontab(hour=8, minute=0),  # هر روز ساعت ۸ صبح
    },
    'deactivate-expired-accounts': {
        'task': 'support.tasks.deactivate_expired_accounts',
        'schedule': crontab(hour=2, minute=0),  # هر روز ساعت ۲ بامداد
    },
    'check-sla-escalation': {
        'task': 'support.tasks.check_sla_escalation',
        'schedule': crontab(minute='*/30'),  # هر ۳۰ دقیقه
    },
}


@app.task(bind=True)
def debug_task(self):
    logger.info(f'Request: {self.request!r}')
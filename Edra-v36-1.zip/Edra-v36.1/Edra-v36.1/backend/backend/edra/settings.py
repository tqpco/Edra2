# edra/settings.py
# -*- coding: utf-8 -*-

"""
تنظیمات پروژه ادرو (EDRA)
سازگار با Django 6.0.8 و Python 3.14+
"""

import os
import sys
import logging
from pathlib import Path
from datetime import timedelta
from typing import List, Dict, Any

from dotenv import load_dotenv

# ================================================================
# مسیرهای پایه
# ================================================================
BASE_DIR = Path(__file__).resolve().parent.parent

# بارگذاری متغیرهای محیطی
# EDRA v27 — رفع باگ بحرانی (تایید در گزارش ممیزی کاربر، سپتامبر
# ۲۰۲۶): قبلاً فقط BASE_DIR/.env چک می‌شد. BASE_DIR اینجا برابر
# backend/backend است، ولی فایل .env واقعی معمولاً در ریشه‌ی پروژه
# (یک پوشه بالاتر) نگه‌داری می‌شد — یعنی load_dotenv به‌صورت کاملاً
# بی‌صدا هیچ متغیری لود نمی‌کرد (python-dotenv در نبود فایل خطا
# نمی‌دهد) و کل سیستم با مقادیر پیش‌فرض ناامن اجرا می‌شد. حالا هر دو
# مسیر محتمل چک می‌شوند؛ backend/backend/.env (مطابق انتظار
# docker-compose.yml) اولویت دارد.
_env_backend_local = BASE_DIR / '.env'
_env_project_root = BASE_DIR.parent / '.env'
if _env_backend_local.exists():
    load_dotenv(_env_backend_local)
elif _env_project_root.exists():
    load_dotenv(_env_project_root)
else:
    load_dotenv(_env_backend_local)

# ================================================================
# متغیرهای محیطی با اعتبارسنجی
# ================================================================
def get_env_bool(key: str, default: str = 'False') -> bool:
    """دریافت متغیر محیطی به‌صورت boolean"""
    return os.environ.get(key, default).lower() in ('1', 'true', 'yes', 'on')

def get_env_list(key: str, default: str = '') -> List[str]:
    """دریافت متغیر محیطی به‌صورت لیست"""
    value = os.environ.get(key, default)
    return [item.strip() for item in value.split(',') if item.strip()]

# ================================================================
# تنظیمات امنیتی و محیطی
# ================================================================
SECRET_KEY = os.environ.get('SECRET_KEY')
if not SECRET_KEY:
    if os.environ.get('DJANGO_ENV') == 'production':
        raise ValueError("SECRET_KEY در محیط production نباید خالی باشد.")
    SECRET_KEY = 'django-insecure-dev-key-do-not-use-in-production'

DEBUG = get_env_bool('DEBUG', 'False')
DJANGO_ENV = os.environ.get('DJANGO_ENV', 'development')
IS_PRODUCTION = DJANGO_ENV == 'production'
IS_STAGING = DJANGO_ENV == 'staging'
IS_DEVELOPMENT = not IS_PRODUCTION and not IS_STAGING

# EDRA v32 — کلید لو‌رفته: SECRET_KEY قبلیِ نمونه‌ی env در zip/گیت منتشر شده بود و
# چون امضای JWT را هم تعیین می‌کند، هر کس آن را داشته باشد می‌تواند توکن ادمین
# جعل کند. فقط hash آن اینجاست (نه خود کلید). در حالت DEBUG=False اجازه‌ی بالا
# آمدن نمی‌دهیم تا با کپی ساده‌ی نمونه‌ی قدیمی استقرار انجام نشود.
import hashlib as _hashlib
_COMPROMISED_SECRET_KEY_SHA256 = {
    'a9f62dc861d6cccbed464920af1afe9a3e8ba42840c03041afcf1293cce8c596',
}
if (not DEBUG
        and _hashlib.sha256(SECRET_KEY.encode()).hexdigest() in _COMPROMISED_SECRET_KEY_SHA256):
    raise ValueError(
        "SECRET_KEY شما همان کلید نمونه‌ی منتشرشده است و لو رفته. یک کلید جدید بسازید: "
        "python -c \"from django.core.management.utils import get_random_secret_key as g; print(g())\"")
if (IS_PRODUCTION or IS_STAGING) and (
        SECRET_KEY.startswith('django-insecure') or SECRET_KEY.startswith('REPLACE')):
    raise ValueError("SECRET_KEY در production/staging نباید پیش‌فرض یا placeholder باشد.")

ALLOWED_HOSTS = get_env_list('ALLOWED_HOSTS', 'localhost,127.0.0.1')
if IS_PRODUCTION and not ALLOWED_HOSTS:
    raise ValueError("ALLOWED_HOSTS در محیط production نباید خالی باشد.")

CSRF_TRUSTED_ORIGINS = get_env_list('CSRF_TRUSTED_ORIGINS', 'http://localhost:8000')

# ================================================================
# API Keys و تنظیمات سرویس‌ها
# ================================================================
DEEPSEEK_API_KEY = os.environ.get('DEEPSEEK_API_KEY', '')
ZARINPAL_MERCHANT_ID = os.environ.get('ZARINPAL_MERCHANT_ID', '')
ZARINPAL_SANDBOX = get_env_bool('ZARINPAL_SANDBOX', 'True')
ZARINPAL_CALLBACK_URL = os.environ.get(
    'ZARINPAL_CALLBACK_URL',
    f'{os.environ.get("SITE_URL", "http://localhost:8000")}/api/core/payment/callback/'
)

# ================================================================
# OTP (تایید دو مرحله‌ای)
# ================================================================
DEV_OTP_ENABLED = get_env_bool('DEV_OTP_ENABLED', 'False')
DEV_OTP_CODE = os.environ.get('DEV_OTP_CODE', '246810')
DEV_OTP_ALLOWED_PHONES = get_env_list('DEV_OTP_ALLOWED_PHONES', '')

if DEV_OTP_ENABLED and IS_PRODUCTION:
    raise ValueError("DEV_OTP_ENABLED=True در محیط production مجاز نیست.")

OTP_MAX_ATTEMPTS = 5
OTP_TTL_SECONDS = 120
OTP_COOLDOWN_SECONDS = 90

# ================================================================
# اپلیکیشن‌های نصب‌شده
# ================================================================
DJANGO_APPS = [
    'django.contrib.admin',
    'django.contrib.auth',
    'django.contrib.contenttypes',
    'django.contrib.sessions',
    'django.contrib.messages',
    'django.contrib.staticfiles',
    'django.contrib.sites',
    'django.contrib.postgres',
]

THIRD_PARTY_APPS = [
    'edra_jalalidate',
    'corsheaders',
    'rest_framework',
    'rest_framework_simplejwt',
    'rest_framework_simplejwt.token_blacklist',
    'drf_spectacular',
    'django_filters',
    'guardian',
    'channels',
    'django_celery_beat',
    'django_prometheus',
]

LOCAL_APPS = [
    'core.apps.CoreConfig',
    'pricing.apps.PricingConfig',
    'inspections.apps.InspectionsConfig',
    'public.apps.PublicConfig',
    'notifications.apps.NotificationsConfig',
    'support.apps.SupportConfig',
    'discounts.apps.DiscountsConfig',
]

INSTALLED_APPS = DJANGO_APPS + THIRD_PARTY_APPS + LOCAL_APPS

# ================================================================
# تنظیمات تقویم جلالی (edra_jalalidate)
# ================================================================
JALALI_SETTINGS = {
    'USE_PERSIAN_DIGITS': False,
    'DATE_FORMAT': '%Y/%m/%d',
    'DATETIME_FORMAT': '%Y/%m/%d %H:%M',
    'STATIC_URL_PREFIX': 'edra_jalalidate/',
}

# ================================================================
# Middleware
# ================================================================
MIDDLEWARE = [
    'django_prometheus.middleware.PrometheusBeforeMiddleware',
    'django.middleware.security.SecurityMiddleware',
    'whitenoise.middleware.WhiteNoiseMiddleware',
    'corsheaders.middleware.CorsMiddleware',
    'django.contrib.sessions.middleware.SessionMiddleware',
    'django.middleware.common.CommonMiddleware',
    'core.middleware.RequestIdMiddleware',
    'django.middleware.csrf.CsrfViewMiddleware',
    'django.contrib.auth.middleware.AuthenticationMiddleware',
    'django.contrib.messages.middleware.MessageMiddleware',
    'django.middleware.clickjacking.XFrameOptionsMiddleware',
    'core.middleware.ErrorLoggingMiddleware',  # EDRA v27 — رفع باگ بحرانی (گزارش کاربر): دوباره فعال شد؛ کد بازبینی شد و مشکلی در آن یافت نشد
    # 'support.middlewares.BlockedIPMiddleware',  # ✅ کامنت شد (در صورت نیاز فعال کنید)
    'django_prometheus.middleware.PrometheusAfterMiddleware',
]

ROOT_URLCONF = 'edra.urls'

# ================================================================
# قالب‌ها (Templates)
# ================================================================
TEMPLATES = [
    {
        'BACKEND': 'django.template.backends.django.DjangoTemplates',
        'DIRS': [BASE_DIR / 'templates'],
        'APP_DIRS': True,
        'OPTIONS': {
            'context_processors': [
                'django.template.context_processors.debug',
                'django.template.context_processors.request',
                'django.contrib.auth.context_processors.auth',
                'django.contrib.messages.context_processors.messages',
            ],
            'debug': DEBUG,
        },
    },
]

WSGI_APPLICATION = 'edra.wsgi.application'
ASGI_APPLICATION = 'edra.asgi.application'

# ================================================================
# دیتابیس
# ================================================================
DATABASES = {
    'default': {
        'ENGINE': os.environ.get('DB_ENGINE', 'django.db.backends.sqlite3'),
        'NAME': os.environ.get('DB_NAME', str(BASE_DIR / 'db.sqlite3')),
        'USER': os.environ.get('DB_USER', ''),
        'PASSWORD': os.environ.get('DB_PASSWORD', ''),
        'HOST': os.environ.get('DB_HOST', ''),
        'PORT': os.environ.get('DB_PORT', ''),
        'CONN_MAX_AGE': int(os.environ.get('DB_CONN_MAX_AGE', 300)),
        # EDRA v32: اتصال مرده (ری‌استارت دیتابیس/PgBouncer) قبل از استفاده
        # شناسایی و دوباره ساخته می‌شود؛ وگرنه تا پایان عمر اتصال خطای 500 می‌دهد.
        'CONN_HEALTH_CHECKS': True,
        'OPTIONS': {},
    }
}

if DATABASES['default']['ENGINE'] == 'django.db.backends.postgresql':
    DATABASES['default']['OPTIONS'] = {
        'connect_timeout': 10,
        'options': '-c statement_timeout=30s',
    }
    if not IS_DEVELOPMENT:
        # EDRA v36: sslmode=require برای هر محیط غیر-توسعه، اتصال به Postgres
        # داخلی docker-compose (که SSL ندارد) را می‌شکست («server does not
        # support SSL»). حالا با DB_SSLMODE قابل کنترل است؛ پیش‌فرض: روی
        # هاست‌های داخلی شبکه‌ی docker/لوکال «prefer»، برای دیتابیس خارجی/مدیریت‌شده
        # «require».
        _db_host = DATABASES['default']['HOST'] or ''
        _internal_hosts = {'', 'localhost', '127.0.0.1', 'db', 'postgres',
                           'postgresql', 'edra-db', 'edra_db'}
        DATABASES['default']['OPTIONS']['sslmode'] = os.environ.get(
            'DB_SSLMODE',
            'prefer' if _db_host in _internal_hosts else 'require')

# ================================================================
# اعتبارسنجی رمز عبور
# ================================================================
AUTH_PASSWORD_VALIDATORS = [
    {
        'NAME': 'django.contrib.auth.password_validation.UserAttributeSimilarityValidator',
        'OPTIONS': {'max_similarity': 0.7},
    },
    {
        'NAME': 'django.contrib.auth.password_validation.MinimumLengthValidator',
        'OPTIONS': {'min_length': 12},
    },
    {
        'NAME': 'django.contrib.auth.password_validation.CommonPasswordValidator',
    },
    {
        'NAME': 'django.contrib.auth.password_validation.NumericPasswordValidator',
    },
]

# ================================================================
# زبان و زمان
# ================================================================
LANGUAGE_CODE = 'fa'
TIME_ZONE = 'Asia/Tehran'
USE_I18N = True
USE_TZ = True
LOCALE_PATHS = [BASE_DIR / 'locale']

# ================================================================
# فایل‌های استاتیک و رسانه
# ================================================================
STATIC_URL = 'static/'
STATIC_ROOT = BASE_DIR / 'staticfiles'
STATICFILES_DIRS = [BASE_DIR / 'static']

MEDIA_URL = '/media/'
MEDIA_ROOT = BASE_DIR / 'media'

DEFAULT_AUTO_FIELD = 'django.db.models.BigAutoField'
APPEND_SLASH = False

# ================================================================
# CORS
# ================================================================
CORS_ALLOW_ALL_ORIGINS = get_env_bool('CORS_ALLOW_ALL_ORIGINS', 'False')
CORS_ALLOWED_ORIGINS = get_env_list(
    'CORS_ALLOWED_ORIGINS',
    'http://localhost:3000,http://localhost:5173'
)
CORS_ALLOW_CREDENTIALS = True
CORS_ALLOW_METHODS = ['DELETE', 'GET', 'OPTIONS', 'PATCH', 'POST', 'PUT']
CORS_ALLOW_HEADERS = [
    'accept', 'accept-encoding', 'authorization', 'content-type',
    'dnt', 'origin', 'user-agent', 'x-csrftoken', 'x-requested-with',
    'x-request-id',
]

if IS_PRODUCTION and CORS_ALLOW_ALL_ORIGINS:
    import warnings
    warnings.warn("CORS_ALLOW_ALL_ORIGINS=True در محیط production توصیه نمی‌شود.", RuntimeWarning)

# ================================================================
# سرویس پیامک و امضای PDF
# ================================================================
SMS_PROVIDER = os.environ.get('SMS_PROVIDER', '')
SMS_API_KEY = os.environ.get('SMS_API_KEY', '')
SMS_SENDER = os.environ.get('SMS_SENDER', '')
SMS_FAIL_CLOSED = get_env_bool('SMS_FAIL_CLOSED', 'False')
SMS_MAX_RETRIES = int(os.environ.get('SMS_MAX_RETRIES', 3))

PDF_GENERATION_ASYNC = get_env_bool('PDF_GENERATION_ASYNC', 'False')
PDF_SIGN_CERT_PATH = os.environ.get('PDF_SIGN_CERT_PATH', '')
PDF_SIGN_KEY_PATH = os.environ.get('PDF_SIGN_KEY_PATH', '')
PDF_SIGN_KEY_PASSWORD = os.environ.get('PDF_SIGN_KEY_PASSWORD', '')

# ================================================================
# Object Storage (S3/MinIO)
# ================================================================
AWS_STORAGE_BUCKET_NAME = os.environ.get('AWS_STORAGE_BUCKET_NAME', '')
AWS_S3_ENDPOINT_URL = os.environ.get('AWS_S3_ENDPOINT_URL', '')
AWS_ACCESS_KEY_ID = os.environ.get('AWS_ACCESS_KEY_ID', '')
AWS_SECRET_ACCESS_KEY = os.environ.get('AWS_SECRET_ACCESS_KEY', '')
AWS_S3_REGION_NAME = os.environ.get('AWS_S3_REGION_NAME', 'us-east-1')
AWS_S3_CUSTOM_DOMAIN = os.environ.get('AWS_S3_CUSTOM_DOMAIN', '')
AWS_S3_USE_SSL = get_env_bool('AWS_S3_USE_SSL', 'True')
AWS_S3_SIGNATURE_VERSION = os.environ.get('AWS_S3_SIGNATURE_VERSION', 's3v4')

if AWS_STORAGE_BUCKET_NAME and AWS_ACCESS_KEY_ID:
    INSTALLED_APPS += ('storages',)
    # EDRA v36 — باگ: DEFAULT_FILE_STORAGE از Django 5.1 حذف شده است (در Django 6
    # بی‌صدا نادیده گرفته می‌شود)؛ یعنی با تنظیم S3 هم فایل‌ها (فیش‌ها/فاکتورها/
    # گزارش‌ها) روی دیسک محلی کانتینر ذخیره می‌شدند و با هر دیپلوی از بین
    # می‌رفتند. تنها راه معتبر: STORAGES.
    STORAGES = {
        'default': {'BACKEND': 'storages.backends.s3.S3Storage'},
        'staticfiles': {
            'BACKEND': 'django.contrib.staticfiles.storage.StaticFilesStorage'},
    }
    AWS_QUERYSTRING_AUTH = True
    AWS_QUERYSTRING_EXPIRE = 3600
    AWS_S3_FILE_OVERWRITE = False
    AWS_S3_OBJECT_PARAMETERS = {'CacheControl': 'max-age=86400'}

# ================================================================
# Sentry (مانیتورینگ خطا)
# ================================================================
SENTRY_DSN = os.environ.get('SENTRY_DSN', '')
SENTRY_TRACES_SAMPLE_RATE = float(os.environ.get('SENTRY_TRACES_SAMPLE_RATE', '0.1'))
SENTRY_ENVIRONMENT = os.environ.get('ENVIRONMENT', DJANGO_ENV)

if SENTRY_DSN:
    try:
        import sentry_sdk
        from sentry_sdk.integrations.django import DjangoIntegration
        from sentry_sdk.integrations.celery import CeleryIntegration
        from sentry_sdk.integrations.redis import RedisIntegration
        sentry_sdk.init(
            dsn=SENTRY_DSN,
            integrations=[DjangoIntegration(), CeleryIntegration(), RedisIntegration()],
            traces_sample_rate=SENTRY_TRACES_SAMPLE_RATE,
            profiles_sample_rate=0.1 if IS_PRODUCTION else 0.0,
            send_default_pii=False,
            release=os.environ.get('GIT_SHA', None),
            environment=SENTRY_ENVIRONMENT,
            server_name=os.environ.get('HOSTNAME', None),
        )
    except Exception as _sentry_err:
        print(f"⚠️ Sentry init failed (continuing): {_sentry_err}")

# ================================================================
# Django REST Framework
# ================================================================
REST_FRAMEWORK = {
    'DEFAULT_AUTHENTICATION_CLASSES': (
        'core.authentication.EdraJWTAuthentication',
    ),
    'DEFAULT_PERMISSION_CLASSES': (
        'rest_framework.permissions.IsAuthenticated',
    ),
    'DEFAULT_PAGINATION_CLASS': 'core.pagination.EdraPageNumberPagination',
    'PAGE_SIZE': 25,
    'DEFAULT_FILTER_BACKENDS': (
        'django_filters.rest_framework.DjangoFilterBackend',
        'rest_framework.filters.SearchFilter',
        'rest_framework.filters.OrderingFilter',
    ),
    'EXCEPTION_HANDLER': 'core.exceptions.api_exception_handler',
    'DEFAULT_SCHEMA_CLASS': 'drf_spectacular.openapi.AutoSchema',
    'DEFAULT_THROTTLE_CLASSES': [
        'rest_framework.throttling.AnonRateThrottle',
        'rest_framework.throttling.UserRateThrottle',
    ],
    # EDRA v32 — نرخ‌های IP-محور برای شبکه‌های واقعی ایران بازنگری شد: اپراتورهای
    # موبایل (CGNAT) و شبکه‌های سازمانی هزاران کاربر را پشت یک IP می‌گذارند؛
    # عددهای قبلی (مثلاً otp_request=5/hour) کاربران واقعی را مرتب با 429 قفل
    # می‌کرد. محافظت اصلی OTP روی «شماره موبایل» است (cooldown ۹۰ثانیه + سقف
    # ساعتی هر شماره در OTPRequestView + حداکثر ۵ تلاش برای هر کد)، نه IP.
    # همه‌ی مقادیر با متغیر محیطی THROTTLE_<SCOPE> (مثل THROTTLE_OTP_REQUEST=60/hour)
    # قابل تغییر هستند.
    'DEFAULT_THROTTLE_RATES': {
        'anon': os.environ.get('THROTTLE_ANON', '20000/day'),
        'user': os.environ.get('THROTTLE_USER', '20000/day'),
        'otp_request': os.environ.get('THROTTLE_OTP_REQUEST', '60/hour'),
        'otp_verify': os.environ.get('THROTTLE_OTP_VERIFY', '120/hour'),
        'contact_message': os.environ.get('THROTTLE_CONTACT_MESSAGE', '10/hour'),
        'login': os.environ.get('THROTTLE_LOGIN', '60/hour'),
        'refresh': os.environ.get('THROTTLE_REFRESH', '600/hour'),
        'payment_initiate': os.environ.get('THROTTLE_PAYMENT_INITIATE', '30/hour'),
        'payment_callback': os.environ.get('THROTTLE_PAYMENT_CALLBACK', '300/hour'),
        'public_verify': os.environ.get('THROTTLE_PUBLIC_VERIFY', '300/hour'),
        'ticket_create': os.environ.get('THROTTLE_TICKET_CREATE', '20/hour'),
        'inspection_create': os.environ.get('THROTTLE_INSPECTION_CREATE', '20/hour'),
        'password_change': os.environ.get('THROTTLE_PASSWORD_CHANGE', '10/hour'),
        'discount_validate': os.environ.get('THROTTLE_DISCOUNT_VALIDATE', '120/hour'),
    },
    # EDRA v32: تعداد پروکسی مورد اعتماد بین کلاینت و جنگو (Nginx → Next BFF
    # فقط یک آدرس «IP کلاینت» در X-Forwarded-For می‌فرستد). بدون این، همه‌ی
    # کاربران پشت BFF یک IP می‌شدند و throttleها سطل مشترک سایت بودند.
    'NUM_PROXIES': int(os.environ.get('NUM_PROXIES', '1')),
    'DEFAULT_VERSIONING_CLASS': 'rest_framework.versioning.AcceptHeaderVersioning',
    'DEFAULT_VERSION': '1.0',
    'ALLOWED_VERSIONS': ['1.0', '1.1'],
    'VERSION_PARAMETER': 'version',
}

# ================================================================
# JWT (JSON Web Token)
# ================================================================
SIMPLE_JWT = {
    'ACCESS_TOKEN_LIFETIME': timedelta(minutes=30),
    'REFRESH_TOKEN_LIFETIME': timedelta(days=7),
    'ROTATE_REFRESH_TOKENS': True,
    'BLACKLIST_AFTER_ROTATION': True,
    'UPDATE_LAST_LOGIN': True,
    'ALGORITHM': 'HS256',
    'SIGNING_KEY': SECRET_KEY,
    'AUDIENCE': os.environ.get('JWT_AUDIENCE', 'edra-api'),
    'ISSUER': os.environ.get('JWT_ISSUER', 'edra'),
    'AUTH_HEADER_TYPES': ('Bearer',),
    'AUTH_HEADER_NAME': 'HTTP_AUTHORIZATION',
    'USER_ID_FIELD': 'id',
    'USER_ID_CLAIM': 'user_id',
    'AUTH_TOKEN_CLASSES': ('rest_framework_simplejwt.tokens.AccessToken',),
    'TOKEN_TYPE_CLAIM': 'token_type',
    'JTI_CLAIM': 'jti',
    'SLIDING_TOKEN_LIFETIME': timedelta(minutes=5),
    'SLIDING_TOKEN_REFRESH_LIFETIME': timedelta(days=1),
}

# ================================================================
# Swagger / Spectacular
# ================================================================
SPECTACULAR_SETTINGS = {
    'TITLE': 'API ادرو - سیستم مدیریت بازرسی',
    'DESCRIPTION': 'مستندات کامل API پروژه ادرو',
    'VERSION': '1.0.0',
    'SERVE_INCLUDE_SCHEMA': False,
    'COMPONENT_SPLIT_REQUEST': True,
    'SCHEMA_PATH_PREFIX': '/api/',
    'TAGS': [
        {'name': 'core', 'description': 'عملیات اصلی سیستم'},
        {'name': 'pricing', 'description': 'قیمت‌گذاری و محاسبات'},
        {'name': 'inspections', 'description': 'بازرسی و گزارش‌ها'},
        {'name': 'notifications', 'description': 'اعلان‌ها'},
        {'name': 'support', 'description': 'پشتیبانی و تیکت‌ها'},
        {'name': 'auth', 'description': 'احراز هویت و OTP'},
    ],
    'SWAGGER_UI_SETTINGS': {
        'deepLinking': True,
        'persistAuthorization': True,
        'displayOperationId': True,
    },
}

# ================================================================
# کش (Cache)
# ================================================================
REDIS_URL = os.environ.get('REDIS_URL')

if REDIS_URL:
    CACHES = {
        'default': {
            'BACKEND': 'django_redis.cache.RedisCache',
            'LOCATION': REDIS_URL,
            'OPTIONS': {
                'CLIENT_CLASS': 'django_redis.client.DefaultClient',
                'MAX_CONNECTIONS': 100,
                'PICKLE_VERSION': -1,
                'SOCKET_TIMEOUT': 5,
                'RETRY_ON_TIMEOUT': True,
                'KEY_PREFIX': 'edra',
                'COMPRESSOR': 'django_redis.compressors.zlib.ZlibCompressor',
            },
            'TIMEOUT': 3600,
            'KEY_PREFIX': 'edra_cache',
        }
    }
else:
    CACHES = {
        'default': {
            'BACKEND': 'django.core.cache.backends.locmem.LocMemCache',
            'LOCATION': 'edra-cache',
            'TIMEOUT': 300,
        }
    }

# ================================================================
# احراز هویت (Guardian)
# ================================================================
AUTHENTICATION_BACKENDS = [
    'django.contrib.auth.backends.ModelBackend',
    'guardian.backends.ObjectPermissionBackend',
]

SITE_ID = 1
LOGIN_REDIRECT_URL = '/'
LOGOUT_REDIRECT_URL = '/'
LOGIN_URL = '/admin/login/'
LOGOUT_URL = '/admin/logout/'

GUARDIAN_RAISE_403 = True
ANONYMOUS_USER_NAME = None

# ================================================================
# ایمیل
# ================================================================
EMAIL_BACKEND = os.environ.get('EMAIL_BACKEND', 'django.core.mail.backends.console.EmailBackend')
EMAIL_HOST = os.environ.get('EMAIL_HOST', 'localhost')
EMAIL_PORT = int(os.environ.get('EMAIL_PORT', 587))
EMAIL_HOST_USER = os.environ.get('EMAIL_HOST_USER', '')
EMAIL_HOST_PASSWORD = os.environ.get('EMAIL_HOST_PASSWORD', '')
EMAIL_USE_TLS = get_env_bool('EMAIL_USE_TLS', 'True')
EMAIL_USE_SSL = get_env_bool('EMAIL_USE_SSL', 'False')
EMAIL_TIMEOUT = int(os.environ.get('EMAIL_TIMEOUT', 10))
DEFAULT_FROM_EMAIL = os.environ.get('DEFAULT_FROM_EMAIL', 'noreply@edra.ir')
SERVER_EMAIL = os.environ.get('SERVER_EMAIL', DEFAULT_FROM_EMAIL)

SITE_URL = os.environ.get('SITE_URL', 'http://localhost:8000')
FRONTEND_URL = os.environ.get('FRONTEND_URL', 'http://localhost:3000')

# ================================================================
# Celery
# ================================================================
CELERY_BROKER_URL = os.environ.get('CELERY_BROKER_URL', 'memory://')
CELERY_RESULT_BACKEND = os.environ.get('CELERY_RESULT_BACKEND', 'cache+memory://')

if REDIS_URL and CELERY_BROKER_URL == 'memory://':
    CELERY_BROKER_URL = REDIS_URL
    CELERY_RESULT_BACKEND = REDIS_URL

CELERY_ACCEPT_CONTENT = ['application/json']
CELERY_TASK_SERIALIZER = 'json'
CELERY_RESULT_SERIALIZER = 'json'
CELERY_TIMEZONE = TIME_ZONE
CELERY_TASK_TRACK_STARTED = True
CELERY_TASK_TIME_LIMIT = 30 * 60
CELERY_TASK_SOFT_TIME_LIMIT = 20 * 60
CELERY_TASK_MAX_RETRIES = 3
CELERY_TASK_DEFAULT_RETRY_DELAY = 60
CELERY_TASK_ACKS_LATE = True
CELERY_TASK_REJECT_ON_WORKER_LOST = True
CELERY_WORKER_PREFETCH_MULTIPLIER = 1
CELERY_WORKER_MAX_TASKS_PER_CHILD = 100
CELERY_BEAT_SCHEDULER = 'django_celery_beat.schedulers:DatabaseScheduler'

# ================================================================
# Channels (WebSocket)
# ================================================================
CHANNEL_REDIS_URL = os.environ.get('CHANNEL_REDIS_URL') or os.environ.get('REDIS_URL')

if CHANNEL_REDIS_URL:
    CHANNEL_LAYERS = {
        'default': {
            'BACKEND': 'channels_redis.core.RedisChannelLayer',
            'CONFIG': {
                'hosts': [CHANNEL_REDIS_URL],
                'capacity': 1500,
                'expiry': 60,
                'group_expiry': 86400,
            },
        },
    }
else:
    CHANNEL_LAYERS = {
        'default': {
            'BACKEND': 'channels.layers.InMemoryChannelLayer',
        },
    }

# ================================================================
# تنظیمات UNFOLD (پنل ادمین)
# ================================================================
UNFOLD = {
    "SITE_TITLE": "ادرو - مدیریت",
    "SITE_HEADER": "ادرو",
    "SITE_URL": "/",
    "SITE_ICON": None,
    "ENVIRONMENT": "production" if IS_PRODUCTION else "development",
    "LOGIN": {
        "image": None,
        "redirect_after_login": "/admin/",
    },
    "STYLES": [],
    "SCRIPTS": [],
    "SIDEBAR": {
        "show_search": True,
        "show_all_applications": False,
        "navigation": [
            {
                "title": "داشبورد",
                "items": [{"title": "داشبورد اصلی", "icon": "home", "link": "/admin/"}]
            },
            {
                "title": "مدیریت کاربران",
                "icon": "users",
                "items": [
                    {"title": "کاربران", "icon": "user", "link": "/admin/auth/user/"},
                    {"title": "گروه‌ها", "icon": "users", "link": "/admin/auth/group/"},
                ]
            },
            {
                "title": "درخواست‌ها و بازرسی",
                "icon": "clipboard",
                "items": [
                    {"title": "درخواست‌های بازرسی", "icon": "file-text", "link": "/admin/core/inspectionrequest/"},
                    {"title": "گزارش‌های بازرسی", "icon": "file-check", "link": "/admin/core/inspectionreport/"},
                    {"title": "قالب‌های چک‌لیست", "icon": "list-check", "link": "/admin/core/checklisttemplate/"},
                    {"title": "آیتم‌های چک‌لیست", "icon": "square", "link": "/admin/core/checklistitem/"},
                    {"title": "دسته‌بندی‌های چک‌لیست", "icon": "tag", "link": "/admin/core/checklistcategory/"},
                ]
            },
            {
                "title": "پرداخت‌ها و مالی",
                "icon": "credit-card",
                "items": [
                    {"title": "پرداخت‌ها", "icon": "dollar-sign", "link": "/admin/core/payment/"},
                    {"title": "فاکتورها", "icon": "file-invoice", "link": "/admin/core/invoice/"},
                    {"title": "اعتبار کاربران", "icon": "coins", "link": "/admin/core/usercredit/"},
                    {"title": "تراکنش‌های اعتباری", "icon": "exchange", "link": "/admin/core/credittransaction/"},
                    {"title": "عودت‌ها", "icon": "rotate-ccw", "link": "/admin/core/refund/"},
                ]
            },
            {
                "title": "قیمت‌گذاری",
                "icon": "calculator",
                "items": [
                    {"title": "قوانین قیمت‌گذاری", "icon": "ruler", "link": "/admin/pricing/pricingrule/"},
                    {"title": "تاریخچه تغییرات قیمت", "icon": "history", "link": "/admin/pricing/pricingrulechangelog/"},
                    {"title": "لاگ محاسبه قیمت", "icon": "bar-chart", "link": "/admin/pricing/pricecalculationlog/"},
                ]
            },
            {
                "title": "تنظیمات پایه",
                "icon": "settings",
                "items": [
                    {"title": "انواع تجهیزات", "icon": "package", "link": "/admin/core/equipmenttype/"},
                    {"title": "پارامترهای تجهیزات", "icon": "sliders", "link": "/admin/core/equipmentparameter/"},
                    {"title": "ضرایب شهرها", "icon": "map-pin", "link": "/admin/core/citymultiplier/"},
                    {"title": "سازمان‌ها", "icon": "building", "link": "/admin/core/organization/"},
                    {"title": "پروژه‌ها", "icon": "folder", "link": "/admin/core/project/"},
                    {"title": "تنظیمات سیستم", "icon": "settings", "link": "/admin/core/systemsetting/"},
                ]
            },
            {
                "title": "پشتیبانی",
                "icon": "headphones",
                "items": [
                    {"title": "تیکت‌ها", "icon": "ticket", "link": "/admin/support/ticket/"},
                    {"title": "نظرات تیکت‌ها", "icon": "message-circle", "link": "/admin/support/ticketcomment/"},
                    {"title": "SLAها", "icon": "clock", "link": "/admin/support/sla/"},
                    {"title": "قوانین تیکت", "icon": "settings", "link": "/admin/support/ticketrule/"},
                    {"title": "وب‌هوک‌ها", "icon": "webhook", "link": "/admin/support/webhook/"},
                ]
            },
            {
                "title": "اعلان‌ها",
                "icon": "bell",
                "items": [
                    {"title": "لاگ اعلان‌ها", "icon": "bell-ring", "link": "/admin/notifications/notificationlog/"},
                    {"title": "قالب‌های اعلان", "icon": "mail", "link": "/admin/notifications/notificationtemplate/"},
                ]
            },
            {
                "title": "گزارش‌ها و لاگ‌ها",
                "icon": "activity",
                "items": [
                    {"title": "لاگ خطاها", "icon": "alert-octagon", "link": "/admin/core/errorlog/"},
                    {"title": "لاگ حسابرسی", "icon": "eye", "link": "/admin/core/auditlog/"},
                ]
            },
            {
                "title": "تخفیف‌ها",
                "icon": "gift",
                "items": [
                    {"title": "کدهای تخفیف", "icon": "ticket", "link": "/admin/core/discountcode/"},
                    {"title": "کمپین‌های تخفیف", "icon": "settings", "link": "/admin/discounts/discountcampaign/"},
                    {"title": "استفاده از کدها", "icon": "list", "link": "/admin/discounts/discountcodeusage/"},
                ]
            },
            {
                "title": "بخش عمومی",
                "icon": "globe",
                "items": [
                    {"title": "مقالات وبلاگ", "icon": "file-text", "link": "/admin/public/blogpost/"},
                    {"title": "سوالات متداول", "icon": "help-circle", "link": "/admin/public/faq/"},
                    {"title": "پیام‌های تماس", "icon": "mail", "link": "/admin/public/contactmessage/"},
                ]
            },
            {
                "title": "مدیریت منو",
                "icon": "menu",
                "items": [
                    {"title": "منوها", "icon": "list", "link": "/admin/core/menu/"},
                    {"title": "آیتم‌های منو", "icon": "square", "link": "/admin/core/menuitem/"},
                ]
            },
        ],
    },
    "COLORS": {
        "primary": {
            "50": "250 245 255",
            "100": "243 232 255",
            "200": "233 213 255",
            "300": "216 180 254",
            "400": "192 132 252",
            "500": "168 85 247",
            "600": "147 51 234",
            "700": "126 34 206",
            "800": "107 33 168",
            "900": "88 28 135",
            "950": "59 7 100",
        },
    },
}

# ================================================================
# تنظیمات امنیتی Production
# ================================================================
SECURE_SSL_REDIRECT = get_env_bool('SECURE_SSL_REDIRECT', 'False')
SESSION_COOKIE_SECURE = get_env_bool('SESSION_COOKIE_SECURE', 'False')
CSRF_COOKIE_SECURE = get_env_bool('CSRF_COOKIE_SECURE', 'False')
SECURE_HSTS_SECONDS = int(os.environ.get('SECURE_HSTS_SECONDS', 0))
SECURE_HSTS_INCLUDE_SUBDOMAINS = get_env_bool('SECURE_HSTS_INCLUDE_SUBDOMAINS', 'False')
SECURE_HSTS_PRELOAD = get_env_bool('SECURE_HSTS_PRELOAD', 'False')
SECURE_CONTENT_TYPE_NOSNIFF = True
SECURE_BROWSER_XSS_FILTER = True
X_FRAME_OPTIONS = 'DENY'
SESSION_COOKIE_HTTPONLY = True
CSRF_COOKIE_HTTPONLY = True

if IS_PRODUCTION:
    SECURE_SSL_REDIRECT = True
    SESSION_COOKIE_SECURE = True
    CSRF_COOKIE_SECURE = True
    SECURE_HSTS_SECONDS = 31536000
    SECURE_HSTS_INCLUDE_SUBDOMAINS = True
    SECURE_HSTS_PRELOAD = True
    SECURE_PROXY_SSL_HEADER = ('HTTP_X_FORWARDED_PROTO', 'https')
    USE_X_FORWARDED_HOST = True
    USE_X_FORWARDED_PORT = True

# ================================================================
# تنظیمات اختصاصی پروژه
# ================================================================
INVOICE_TAX_RATE = float(os.environ.get('INVOICE_TAX_RATE', '0.09'))
INVOICE_DUE_DAYS = int(os.environ.get('INVOICE_DUE_DAYS', 30))
PRICING_VERSION = os.environ.get('PRICING_VERSION', '1.0')
MAX_UPLOAD_SIZE = int(os.environ.get('MAX_UPLOAD_SIZE', 5 * 1024 * 1024))

PROMETHEUS_EXPORT_MIGRATIONS = False

# ================================================================
# لاگینگ (Logging)
# ================================================================
_LOG_DIR = BASE_DIR / 'logs'
_LOG_DIR.mkdir(parents=True, exist_ok=True)

LOGGING = {
    'version': 1,
    'disable_existing_loggers': False,
    'formatters': {
        'verbose': {
            'format': '[{asctime}] {levelname} {name} {module} {process:d} {thread:d} {message}',
            'style': '{',
        },
        'simple': {
            'format': '[{asctime}] {levelname} {message}',
            'style': '{',
        },
        'json': {
            'format': '{"time": "%(asctime)s", "level": "%(levelname)s", "name": "%(name)s", "message": "%(message)s"}',
        },
    },
    'filters': {
        'require_debug_true': {'()': 'django.utils.log.RequireDebugTrue'},
        'require_debug_false': {'()': 'django.utils.log.RequireDebugFalse'},
    },
    'handlers': {
        'console': {
            'class': 'logging.StreamHandler',
            'formatter': 'simple' if IS_DEVELOPMENT else 'json',
            'filters': ['require_debug_true'],
        },
        'file': {
            'class': 'logging.handlers.RotatingFileHandler',
            'filename': _LOG_DIR / 'django.log',
            'maxBytes': 10 * 1024 * 1024,
            'backupCount': 10,
            'formatter': 'verbose',
        },
        'error_file': {
            'class': 'logging.handlers.RotatingFileHandler',
            'filename': _LOG_DIR / 'errors.log',
            'maxBytes': 10 * 1024 * 1024,
            'backupCount': 10,
            'formatter': 'verbose',
            'level': 'ERROR',
        },
        'mail_admins': {
            'class': 'django.utils.log.AdminEmailHandler',
            'formatter': 'verbose',
            'level': 'ERROR',
            'include_html': True,
        },
    },
    'root': {
        'handlers': ['console', 'file'],
        'level': 'INFO',
    },
    'loggers': {
        'django': {
            'handlers': ['console', 'file', 'error_file'],
            'level': os.environ.get('DJANGO_LOG_LEVEL', 'INFO'),
            'propagate': False,
        },
        'django.db.backends': {
            'handlers': ['console'],
            'level': 'ERROR' if IS_PRODUCTION else 'DEBUG',
            'propagate': False,
        },
        'django.security': {
            'handlers': ['console', 'file', 'mail_admins'],
            'level': 'WARNING',
            'propagate': False,
        },
        'core': {
            'handlers': ['console', 'file'],
            'level': 'DEBUG' if IS_DEVELOPMENT else 'INFO',
            'propagate': False,
        },
        'celery': {
            'handlers': ['console', 'file'],
            'level': 'INFO',
            'propagate': False,
        },
        'channels': {
            'handlers': ['console', 'file'],
            'level': 'INFO',
            'propagate': False,
        },
    },
}

# ================================================================
# ✅ پیام‌های راه‌اندازی (بدون ایموجی برای سازگاری با کنسول ویندوز)
# ================================================================
print(f"\n{'='*60}")
print(f"  EDRA Project - Settings Loaded")
print(f"  Environment: {DJANGO_ENV.upper()}")
print(f"  Debug: {DEBUG}")
print(f"  Database: {DATABASES['default']['ENGINE'].split('.')[-1]}")
print(f"  Redis: {'Enabled' if REDIS_URL else 'Disabled'}")
# EDRA v36: آدرس broker می‌تواند رمز Redis را داشته باشد (redis://:pass@host)؛
# رمز هرگز در لاگ چاپ نمی‌شود.
import re as _re
print(f"  Celery Broker: {_re.sub(r'://[^@/]*@', '://***@', CELERY_BROKER_URL)}")
print(f"{'='*60}\n")
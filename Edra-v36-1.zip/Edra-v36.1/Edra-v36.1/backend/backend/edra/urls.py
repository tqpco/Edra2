# edra/urls.py
# -*- coding: utf-8 -*-

from django.contrib import admin
from django.urls import path, include
from django.conf import settings
from django.conf.urls.static import static
from django.contrib.staticfiles.urls import staticfiles_urlpatterns
from django.contrib.auth import views as auth_views
from django.shortcuts import redirect
from django.http import HttpResponse, JsonResponse
from django.contrib.auth import logout
from django.views.decorators.http import require_POST
from django.db import connections
from rest_framework.permissions import AllowAny
from core.permissions import IsAdminUserOrGroup, is_admin_user
from rest_framework.throttling import ScopedRateThrottle
from rest_framework_simplejwt.views import (
    TokenObtainPairView, TokenRefreshView, TokenBlacklistView
)
from rest_framework_simplejwt.serializers import TokenObtainPairSerializer
from drf_spectacular.views import SpectacularAPIView, SpectacularSwaggerView


class RoleAwareTokenObtainPairSerializer(TokenObtainPairSerializer):
    """EDRA v27 — همان claim نقش که برای ورود OTP مشتری اضافه شد، اینجا
    هم برای ورود staff/ادمین با رمز عبور اضافه می‌شود تا middleware
    فرانت‌اند برای هر دو مسیر ورود یکسان رفتار کند."""
    @classmethod
    def get_token(cls, user):
        token = super().get_token(user)
        from core.permissions import get_user_role
        token['role'] = get_user_role(user)
        return token


class TokenObtainPairThrottledView(TokenObtainPairView):
    serializer_class = RoleAwareTokenObtainPairSerializer
    throttle_classes = [ScopedRateThrottle]
    throttle_scope = 'login'


class TokenRefreshThrottledView(TokenRefreshView):
    throttle_classes = [ScopedRateThrottle]
    throttle_scope = 'refresh'


class TokenBlacklistAllowAnyView(TokenBlacklistView):
    permission_classes = [AllowAny]


def favicon(request):
    return HttpResponse(status=204)


def health_live(request):
    return JsonResponse({'status': 'ok'})


def health_ready(request):
    try:
        connections['default'].cursor().execute('SELECT 1')
    except Exception:
        return JsonResponse({'status': 'unavailable'}, status=503)
    try:
        from django.core.cache import cache
        cache.set('health_check', '1', 5)
        cache.get('health_check')
    except Exception:
        return JsonResponse({'status': 'degraded'}, status=503)
    return JsonResponse({'status': 'ok'})


def metrics_view(request):
    if not (request.user.is_authenticated
            and (request.user.is_staff or request.user.groups.filter(name='Admin').exists())):
        return JsonResponse({'error': 'دسترسی غیرمجاز'}, status=403)
    from django_prometheus.exports import ExportToDjangoView
    return ExportToDjangoView(request)


def home(request):
    return redirect('/admin/')


@require_POST
def logout_view(request):
    logout(request)
    return redirect('/admin/')


urlpatterns = [
    path('', home, name='home'),
    path('admin/logout/', logout_view, name='custom_logout'),

    path('admin/password_reset/',
         auth_views.PasswordResetView.as_view(
             template_name='admin/password_reset_form.html',
             email_template_name='admin/password_reset_email.html',
             subject_template_name='admin/password_reset_subject.txt',
             success_url='/admin/password_reset/done/'
         ),
         name='admin_password_reset'),
    path('admin/password_reset/done/',
         auth_views.PasswordResetDoneView.as_view(
             template_name='admin/password_reset_done.html'
         ),
         name='password_reset_done'),
    path('admin/reset/<uidb64>/<token>/',
         auth_views.PasswordResetConfirmView.as_view(
             template_name='admin/password_reset_confirm.html',
             success_url='/admin/reset/done/'
         ),
         name='password_reset_confirm'),
    path('admin/reset/done/',
         auth_views.PasswordResetCompleteView.as_view(
             template_name='admin/password_reset_complete.html'
         ),
         name='password_reset_complete'),

    path('admin/', admin.site.urls),

    path('favicon.ico', favicon),
    path('health/live/', health_live, name='health_live'),
    path('health/ready/', health_ready, name='health_ready'),
    path('metrics/', metrics_view, name='prometheus_metrics'),

    path('api/token/', TokenObtainPairThrottledView.as_view(), name='token_obtain_pair'),
    path('api/token/refresh/', TokenRefreshThrottledView.as_view(), name='token_refresh'),
    path('api/token/blacklist/', TokenBlacklistAllowAnyView.as_view(), name='token_blacklist'),

    path('api/schema/',
         SpectacularAPIView.as_view(
             permission_classes=([AllowAny] if getattr(settings, 'SWAGGER_PUBLIC', False) else [IsAdminUserOrGroup]),
             urlconf=settings.ROOT_URLCONF
         ),
         name='schema'),
    path('api/docs/', SpectacularSwaggerView.as_view(url_name='schema'), name='swagger-ui'),

    # ============================================================
    # EDRA v27 — حذف مسیر تکراری (گزارش ممیزی کاربر، سپتامبر ۲۰۲۶):
    # این مسیر عیناً همان ViewSet را در همان آدرس نهایی
    # (api/core/discount-codes/validate/) دوباره ثبت می‌کرد که از قبل
    # از طریق core/urls.py (که هم زیر api/core/ و هم api/v1/core/
    # include می‌شود) پوشش داده شده بود.
    # ============================================================

    # ============================================================
    # مسیرهای API (نسخه v1 و قدیمی)
    # ============================================================
    path('api/v1/core/', include(('core.urls', 'core'), namespace='core_v1')),
    path('api/v1/expert/', include(('core.expert.urls', 'expert'), namespace='expert_v1')),
    path('api/v1/pricing/', include(('pricing.urls', 'pricing'), namespace='pricing_v1')),
    path('api/v1/inspections/', include(('inspections.urls', 'inspections'), namespace='inspections_v1')),
    path('api/v1/notifications/', include(('notifications.urls', 'notifications'), namespace='notifications_v1')),
    path('api/v1/public/', include(('public.urls', 'public'), namespace='public_v1')),
    path('api/v1/support/', include(('support.urls', 'support'), namespace='support_v1')),
    path('api/v1/discounts/', include(('discounts.urls', 'discounts'), namespace='discounts_v1')),

    path('api/core/', include(('core.urls', 'core'), namespace='core_legacy')),
    path('api/expert/', include(('core.expert.urls', 'expert'), namespace='expert_legacy')),
    path('api/pricing/', include(('pricing.urls', 'pricing'), namespace='pricing_legacy')),
    path('api/inspections/', include(('inspections.urls', 'inspections'), namespace='inspections_legacy')),
    path('api/notifications/', include(('notifications.urls', 'notifications'), namespace='notifications_legacy')),
    path('api/public/', include(('public.urls', 'public'), namespace='public_legacy')),
    path('api/support/', include(('support.urls', 'support'), namespace='support_legacy')),
    path('api/discounts/', include(('discounts.urls', 'discounts'), namespace='discounts_legacy')),
]

if settings.DEBUG:
    urlpatterns += static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
    urlpatterns += staticfiles_urlpatterns()
else:
    from django.views.static import serve
    from django.http import HttpResponseForbidden
    from core.authentication import EdraJWTAuthentication as JWTAuthentication
    from rest_framework_simplejwt.exceptions import InvalidToken, TokenError
    from rest_framework.exceptions import AuthenticationFailed

    # EDRA v27 — رفع باگ بحرانی (گزارش ممیزی کاربر، سپتامبر ۲۰۲۶): قبلاً
    # فایل‌های مدیا (فیش بانکی، پیوست تیکت) در production بدون هیچ چک
    # احراز هویتی از طریق /media/<path>/ در دسترس عموم بودند. این wrapper
    # حداقل نیاز به یک JWT معتبر (از همان کوکی httpOnly که بقیه‌ی سیستم
    # استفاده می‌کند) را الزامی می‌کند — دسترسی ناشناس کاملاً مسدود
    # می‌شود. توجه: این هنوز چک مالکیت فایل به‌ازای هر کاربر را ندارد
    # (نیازمند نگاشت کامل مسیر فایل به مدل مالک آن در یک تغییر جداگانه)
    # ولی نسبت به وضعیت قبلی (کاملاً باز برای هرکسی) پیشرفت واقعی و
    # کم‌ریسک است.
    # EDRA v27 — رفع باگ امنیتی (تایید ممیزی هوش مصنوعی، سپتامبر ۲۰۲۶):
    # نسخه‌ی قبلی این fix فقط «یک JWT معتبر» را الزامی می‌کرد — یعنی هر
    # کاربر واردشده می‌توانست فایل هر کاربر دیگری را هم ببیند (فقط با
    # حدس‌زدن/دیدن مسیر). حالا برای دو نوع فایل حساس شناخته‌شده (پیوست
    # تیکت، فیش بانکی) مالکیت واقعی چک می‌شود؛ برای هر مسیر دیگری،
    # دسترسی فقط به ادمین محدود می‌ماند (fail-closed).
    def _user_can_access_media(user, path):
        if is_admin_user(user):
            return True
        from support.models import TicketAttachment
        from core.models import Payment
        attachment = TicketAttachment.objects.filter(
            file=path).select_related('ticket', 'comment').first()
        if attachment:
            # EDRA v36: کارکنان پشتیبانی (نه فقط ادمین) باید پیوست تیکت را ببینند؛
            # و پیوستِ کامنت «داخلی» هرگز برای مشتری باز نیست.
            from core.permissions import is_support_or_admin
            if is_support_or_admin(user):
                return True
            if attachment.comment_id and attachment.comment.is_internal:
                return False
            return user.id in (
                attachment.ticket.customer_id, attachment.ticket.assigned_to_id)
        payment = Payment.objects.filter(bank_receipt=path).select_related(
            'inspection_request').first()
        if payment:
            return payment.inspection_request.customer_id == user.id
        return False

    def authenticated_media_serve(request, path, document_root=None):
        access_token = request.COOKIES.get('edra_access')
        if not access_token:
            return HttpResponseForbidden('دسترسی نیازمند ورود است.')
        try:
            validated = JWTAuthentication().get_validated_token(access_token)
            user = JWTAuthentication().get_user(validated)
        except (InvalidToken, TokenError, AuthenticationFailed):
            # EDRA v36: AuthenticationFailed (کاربر غیرفعال/حذف‌شده) قبلاً
            # گرفته نمی‌شد و ۵۰۰ می‌داد.
            return HttpResponseForbidden('نشست نامعتبر یا منقضی‌شده است.')
        if not _user_can_access_media(user, path):
            return HttpResponseForbidden('اجازه‌ی دسترسی به این فایل را ندارید.')
        return serve(request, path, document_root=document_root)

    urlpatterns += [
        path('media/<path:path>', authenticated_media_serve,
             {'document_root': settings.MEDIA_ROOT}),
    ]
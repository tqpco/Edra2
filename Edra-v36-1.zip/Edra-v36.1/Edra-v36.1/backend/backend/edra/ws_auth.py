"""
edra/ws_auth.py

احراز هویت WebSocket — P0-08/HIGH-06.

معماری قبلی: access JWT از httpOnly cookie خارج و به جاوااسکریپت داده
می‌شد و سپس در query string (?token=...) ارسال می‌شد. ریسک‌ها:
  - JWT در URL/log/proxy history ثبت می‌شود
  - در صورت XSS، access token اصلی قابل برداشت است

معماری جدید: کلاینت ابتدا POST /api/notifications/ws-ticket/ می‌زند و یک
ticket تصادفی یکبارمصرف با TTL کوتاه (۶۰ ثانیه) می‌گیرد؛ سپس با
?ticket=... به WebSocket وصل می‌شود. این middleware ticket را در cache
اعتبارسنجی کرده، بلافاصله حذف می‌کند (single-use) و کاربر را در
scope['user'] قرار می‌دهد.
"""
import re
from urllib.parse import parse_qs

from channels.db import database_sync_to_async
from django.contrib.auth import get_user_model
from django.contrib.auth.models import AnonymousUser
from django.core.cache import cache

User = get_user_model()


_TICKET_RE = re.compile(r'^[0-9a-f]{64}$')


def _consume_ticket(ticket: str):
    """
    مصرف اتمیک ticket: شناسه‌ی کاربر را برمی‌گرداند و ticket را حذف می‌کند.

    EDRA v33 — رفع باگ بحرانی: نسخه‌ی قبلی روی Redis مستقیماً GETDEL را با
    کلید خام `ws_ticket_…` صدا می‌زد، در حالی که django-redis کلید را با
    پیشوند/نسخه (KEY_PREFIX) ذخیره می‌کند و مقدار هم pickle است؛ در نتیجه
    ticket هرگز پیدا نمی‌شد و تمام اتصال‌های WebSocket (اعلان‌ها و تیکت‌ها) در
    محیط docker/Redis رد می‌شدند. حالا فقط از API کش Django استفاده می‌شود
    (کلید/سریال‌سازی درست) و یک‌بارمصرف‌بودن با نتیجه‌ی delete تضمین می‌شود:
    در رقابت دو اتصال، فقط یکی delete موفق (True) می‌گیرد.
    اگر ticket وجود نداشته یا منقضی شده باشد → None.
    """
    if not ticket or not _TICKET_RE.match(ticket):
        return None
    key = f'ws_ticket_{ticket}'
    user_id = cache.get(key)
    if user_id is None:
        return None
    if not cache.delete(key):
        return None  # اتصال همزمان دیگری همین ticket را مصرف کرد
    return user_id


class WsTicketAuthMiddleware:
    """خواندن ticket از query string، مصرف و ست کردن scope['user']."""

    def __init__(self, inner):
        self.inner = inner

    async def __call__(self, scope, receive, send):
        query = parse_qs((scope.get('query_string') or b'').decode('utf-8'))
        ticket = (query.get('ticket') or [None])[0]
        user_id = await database_sync_to_async(_consume_ticket)(ticket)
        if user_id:
            scope['user'] = await self.get_user(user_id)
        else:
            scope['user'] = AnonymousUser()
        return await self.inner(scope, receive, send)

    @database_sync_to_async
    def get_user(self, user_id):
        try:
            user = User.objects.get(id=user_id)
            return user if user.is_active else AnonymousUser()
        except (User.DoesNotExist, ValueError, TypeError):
            return AnonymousUser()

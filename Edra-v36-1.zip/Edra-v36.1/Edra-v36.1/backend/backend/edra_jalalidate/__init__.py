# edra_jalalidate/__init__.py
# -*- coding: utf-8 -*-

__version__ = '3.8.0'

from .jalali import JalaliDate, JalaliDateTime, to_jalali, get_jalali_today, get_jalali_now
from .fields import jDateField, jDateTimeField
from .widgets import AdminjDateWidget, AdminjDateTimeWidget, AdminjDateTimeSeparateWidget
from .jalali_widgets import JalaliDateWidget, JalaliDateTimeWidget
from .forms import JalaliDateFormField, JalaliDateTimeFormField
from .admin import EdraJalaliAdminMixin, make_jalali_date_filter
from .serializers import JDateField, JDateTimeField
from .manager import JalaliManager
from .utils import *
from .ntp import get_accurate_datetime
from .settings import JALALI_SETTINGS

default_app_config = 'edra_jalalidate.apps.EdraJalaliConfig'
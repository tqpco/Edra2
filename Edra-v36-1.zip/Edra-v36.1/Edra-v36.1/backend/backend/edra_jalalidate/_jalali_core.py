# edra_jalalidate/_jalali_core.py
# -*- coding: utf-8 -*-
"""
هسته اصلی تبدیل تاریخ جلالی به میلادی و برعکس
با استفاده از مرجع ثابت 1400/01/01 = 2021-03-21
نسخه ۴.۱ - نهایی و بدون خطا
"""

from datetime import date, timedelta
from typing import Tuple

# ============================================================
# ثابت‌های مرجع
# ============================================================
REF_JALALI_YEAR = 1400
REF_JALALI_MONTH = 1
REF_JALALI_DAY = 1
REF_GREGORIAN_DATE = date(2021, 3, 21)  # نوروز ۱۴۰۰

# استثناهای کبیسه‌گیری (بر اساس درخواست کاربر)
LEAP_EXCEPTIONS = {1408, 1412, 1416}
COMMON_EXCEPTIONS = {1407}


def is_jalali_leap_year(year: int) -> bool:
    """
    تعیین کبیسه بودن سال جلالی بر اساس الگوریتم ۳۳ ساله + استثناها
    """
    if year in COMMON_EXCEPTIONS:
        return False
    rem = year % 33
    standard_leap = rem in (1, 5, 9, 13, 17, 21, 26, 30)
    if year in LEAP_EXCEPTIONS:
        return True
    return standard_leap


def jalali_month_days(year: int, month: int) -> int:
    """
    تعداد روزهای یک ماه جلالی
    """
    if month < 1 or month > 12:
        raise ValueError("ماه باید بین ۱ تا ۱۲ باشد")
    if month <= 6:
        return 31
    if month <= 11:
        return 30
    return 30 if is_jalali_leap_year(year) else 29


def _jalali_to_days_since_ref(year: int, month: int, day: int) -> int:
    """
    محاسبه‌ی تعداد روزهای گذشته از مرجع (1400/01/01) تا تاریخ ورودی
    """
    days = 0
    # جمع روزهای سال‌های کامل از مرجع تا سال قبل
    for y in range(REF_JALALI_YEAR, year):
        days += 365 + (1 if is_jalali_leap_year(y) else 0)
    # جمع روزهای ماه‌های کامل سال جاری تا ماه قبل
    for m in range(1, month):
        days += jalali_month_days(year, m)
    # اضافه کردن روزهای ماه جاری (منهای یک چون روز اول = 0)
    days += day - 1
    return days


def jalali_to_gregorian(year: int, month: int, day: int) -> Tuple[int, int, int]:
    """
    تبدیل تاریخ جلالی به میلادی
    """
    days_offset = _jalali_to_days_since_ref(year, month, day)
    target_date = REF_GREGORIAN_DATE + timedelta(days=days_offset)
    return target_date.year, target_date.month, target_date.day


def gregorian_to_jalali(year: int, month: int, day: int) -> Tuple[int, int, int]:
    """
    تبدیل تاریخ میلادی به جلالی
    با جستجوی دودویی برای یافتن سال و ماه مناسب
    """
    target_date = date(year, month, day)
    # محاسبه‌ی اختلاف روز با مرجع
    delta_days = (target_date - REF_GREGORIAN_DATE).days
    if delta_days < 0:
        raise ValueError("تاریخ میلادی قبل از مرجع (۱۴۰۰/۰۱/۰۱) است")

    # پیدا کردن سال
    year_guess = REF_JALALI_YEAR
    while True:
        days_in_year = 365 + (1 if is_jalali_leap_year(year_guess) else 0)
        if delta_days < days_in_year:
            break
        delta_days -= days_in_year
        year_guess += 1

    # پیدا کردن ماه
    month_guess = 1
    while month_guess <= 12:
        days_in_month = jalali_month_days(year_guess, month_guess)
        if delta_days < days_in_month:
            break
        delta_days -= days_in_month
        month_guess += 1

    day_guess = delta_days + 1  # چون روزها از صفر شروع شده‌اند

    return year_guess, month_guess, day_guess


# ============================================================
# توابع سازگاری با نسخه‌های قبلی (برای استفاده در jalali.py)
# ============================================================

def jalali_to_jd(year: int, month: int, day: int) -> float:
    """
    (سازگاری) تبدیل جلالی به روز ژولیوسی
    """
    greg = jalali_to_gregorian(year, month, day)
    from math import floor
    a = (14 - greg[1]) // 12
    y = greg[0] + 4800 - a
    m = greg[1] + 12 * a - 3
    jdn = greg[2] + (153 * m + 2) // 5 + 365 * y + y // 4 - y // 100 + y // 400 - 32045
    return jdn + 0.5


def jd_to_jalali(jd: float) -> Tuple[int, int, int]:
    """
    (سازگاری) تبدیل روز ژولیوسی به جلالی
    """
    from math import floor
    jd_int = floor(jd)
    z = jd_int + 0.5
    a = floor(z)
    if a < 2299161:
        a = z
    else:
        alpha = floor((z - 1867216.25) / 36524.25)
        a = z + 1 + alpha - floor(alpha / 4)
    b = a + 1524
    c = floor((b - 122.1) / 365.25)
    d = floor(365.25 * c)
    e = floor((b - d) / 30.6001)
    day = b - d - floor(30.6001 * e)
    month = e - 1 if e < 14 else e - 13
    year = c - 4715 if month > 2 else c - 4716
    return gregorian_to_jalali(year, month, day)


def gregorian_to_jd(year: int, month: int, day: int) -> float:
    """
    (سازگاری) تبدیل میلادی به روز ژولیوسی
    """
    from math import floor
    a = (14 - month) // 12
    y = year + 4800 - a
    m = month + 12 * a - 3
    jdn = day + (153 * m + 2) // 5 + 365 * y + y // 4 - y // 100 + y // 400 - 32045
    return jdn + 0.5


def jd_to_gregorian(jd: float) -> Tuple[int, int, int]:
    """
    (سازگاری) تبدیل روز ژولیوسی به میلادی
    """
    from math import floor
    jd_int = floor(jd) + 0.5
    z = floor(jd_int)
    f = jd_int - z
    if z < 2299161:
        a = z
    else:
        alpha = floor((z - 1867216.25) / 36524.25)
        a = z + 1 + alpha - floor(alpha / 4)
    b = a + 1524
    c = floor((b - 122.1) / 365.25)
    d = floor(365.25 * c)
    e = floor((b - d) / 30.6001)
    day = b - d - floor(30.6001 * e) + f
    month = e - 1 if e < 14 else e - 13
    year = c - 4715 if month > 2 else c - 4716
    return year, month, floor(day)


# ============================================================
# توابع راحتی برای تبدیل JDN (روز ژولیوسی)
# ============================================================

def gregorian_to_jdn(year: int, month: int, day: int) -> int:
    """تبدیل تاریخ میلادی به روز ژولیوسی (عدد صحیح)"""
    return int(gregorian_to_jd(year, month, day))


def jalali_to_jdn(year: int, month: int, day: int) -> int:
    """تبدیل تاریخ جلالی به روز ژولیوسی (عدد صحیح)"""
    return int(jalali_to_jd(year, month, day))


def jdn_to_jalali(jdn: int) -> Tuple[int, int, int]:
    """تبدیل روز ژولیوسی (عدد صحیح) به تاریخ جلالی"""
    return jd_to_jalali(jdn)


def jdn_to_gregorian(jdn: int) -> Tuple[int, int, int]:
    """تبدیل روز ژولیوسی (عدد صحیح) به تاریخ میلادی"""
    return jd_to_gregorian(jdn)
# edra_jalalidate/admin.py
# -*- coding: utf-8 -*-
"""
ابزارهای ادمین جنگو برای نمایش و فیلتر تاریخ جلالی.
"""

from django.contrib.admin import SimpleListFilter
from django.utils import timezone
from django.utils.translation import gettext_lazy as _

from .jalali import JalaliDate, JalaliDateTime, to_jalali
from .forms import JalaliDateFormField, JalaliDateTimeFormField
from .jalali_widgets import JalaliDateWidget, JalaliDateTimeWidget
from django.db import models
import datetime


class EdraJalaliAdminMixin:
    """میکسین برای ModelAdmin که فیلدهای تاریخ را به جلالی تبدیل می‌کند."""

    def formfield_for_dbfield(self, db_field, request, **kwargs):
        if isinstance(db_field, models.DateField):
            kwargs['form_class'] = JalaliDateFormField
            kwargs['widget'] = JalaliDateWidget()
        elif isinstance(db_field, models.DateTimeField):
            kwargs['form_class'] = JalaliDateTimeFormField
            kwargs['widget'] = JalaliDateTimeWidget()
        return super().formfield_for_dbfield(db_field, request, **kwargs)

    def get_jalali_display(self, obj, field_name, fmt="%Y/%m/%d %H:%M"):
        value = getattr(obj, field_name, None)
        if value is None:
            return "—"
        return to_jalali(value, fmt)

    def jalali_created_at(self, obj):
        return self.get_jalali_display(obj, 'created_at', '%Y/%m/%d %H:%M')
    jalali_created_at.short_description = "تاریخ ایجاد (جلالی)"
    jalali_created_at.admin_order_field = 'created_at'

    def jalali_updated_at(self, obj):
        return self.get_jalali_display(obj, 'updated_at', '%Y/%m/%d %H:%M')
    jalali_updated_at.short_description = "تاریخ بروزرسانی (جلالی)"
    jalali_updated_at.admin_order_field = 'updated_at'


def make_jalali_date_filter(field_name: str, title_label: str):
    """ساخت فیلتر تاریخ جلالی برای list_filter ادمین."""

    class JalaliDateFilter(SimpleListFilter):
        parameter_name = field_name
        title = title_label

        def lookups(self, request, model_admin):
            return (
                ('today', 'امروز'),
                ('7days', '۷ روز اخیر'),
                ('30days', '۳۰ روز اخیر'),
                ('this_month', 'این ماه شمسی'),
                ('this_year', 'امسال شمسی'),
            )

        def queryset(self, request, queryset):
            value = self.value()
            if not value:
                return queryset

            now = timezone.localtime(timezone.now())
            start = None
            end = None

            if value == 'today':
                start = now.replace(hour=0, minute=0, second=0, microsecond=0)
                end = start + datetime.timedelta(days=1)

            elif value == '7days':
                start = now - datetime.timedelta(days=7)

            elif value == '30days':
                start = now - datetime.timedelta(days=30)

            elif value == 'this_month':
                jnow = JalaliDateTime.from_datetime(now)
                jstart = JalaliDate(jnow.year, jnow.month, 1)
                # ✅ استفاده از to_datetime() به جای to_date() برای دریافت datetime
                greg_start = jstart.to_datetime()
                start = timezone.make_aware(greg_start) if timezone.is_naive(greg_start) else greg_start

                if jnow.month == 12:
                    jend = JalaliDate(jnow.year + 1, 1, 1)
                else:
                    jend = JalaliDate(jnow.year, jnow.month + 1, 1)
                # ✅ استفاده از to_datetime() به جای to_date()
                greg_end = jend.to_datetime()
                end = timezone.make_aware(greg_end) if timezone.is_naive(greg_end) else greg_end

            elif value == 'this_year':
                jnow = JalaliDateTime.from_datetime(now)
                jstart = JalaliDate(jnow.year, 1, 1)
                greg_start = jstart.to_datetime()
                start = timezone.make_aware(greg_start) if timezone.is_naive(greg_start) else greg_start

                jend = JalaliDate(jnow.year + 1, 1, 1)
                greg_end = jend.to_datetime()
                end = timezone.make_aware(greg_end) if timezone.is_naive(greg_end) else greg_end

            if start is None:
                return queryset

            filter_kwargs = {f'{field_name}__gte': start}
            if end is not None:
                filter_kwargs[f'{field_name}__lt'] = end

            return queryset.filter(**filter_kwargs)

    return JalaliDateFilter
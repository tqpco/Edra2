# edra_jalalidate/apps.py
# -*- coding: utf-8 -*-
from django.apps import AppConfig
from django.utils.translation import gettext_lazy as _


class EdraJalaliConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'edra_jalalidate'
    verbose_name = _('تقویم جلالی ادرو')

    def ready(self):
        # بارگذاری تنظیمات (اختیاری)
        from . import settings  # noqa
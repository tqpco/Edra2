# edra_jalalidate/date_utils.py
# -*- coding: utf-8 -*-
"""
توابع کمکی برای استخراج تاریخ جلالی از فیلدهای رایج مدل‌ها.
هر تابع یک شیء مدل دریافت کرده و رشتهٔ جلالی را برمی‌گرداند.
"""

from .jalali import to_jalali


def _get_field_jalali(obj, field_name, fmt="%Y/%m/%d %H:%M"):
    value = getattr(obj, field_name, None)
    if value is None:
        return "—"
    return to_jalali(value, fmt)


def get_created_at_jalali(obj, fmt="%Y/%m/%d %H:%M"):
    return _get_field_jalali(obj, 'created_at', fmt)


def get_updated_at_jalali(obj, fmt="%Y/%m/%d %H:%M"):
    return _get_field_jalali(obj, 'updated_at', fmt)


def get_date_joined_jalali(obj, fmt="%Y/%m/%d %H:%M"):
    return _get_field_jalali(obj, 'date_joined', fmt)


def get_scheduled_at_jalali(obj, fmt="%Y/%m/%d %H:%M"):
    return _get_field_jalali(obj, 'scheduled_at', fmt)


def get_expires_at_jalali(obj, fmt="%Y/%m/%d %H:%M"):
    return _get_field_jalali(obj, 'expires_at', fmt)


def get_due_date_jalali(obj, fmt="%Y/%m/%d"):
    return _get_field_jalali(obj, 'due_date', fmt)


def get_signed_at_jalali(obj, fmt="%Y/%m/%d %H:%M"):
    return _get_field_jalali(obj, 'signed_at', fmt)


def get_last_viewed_at_jalali(obj, fmt="%Y/%m/%d %H:%M"):
    return _get_field_jalali(obj, 'last_viewed_at', fmt)


def get_timestamp_jalali(obj, fmt="%Y/%m/%d %H:%M"):
    return _get_field_jalali(obj, 'timestamp', fmt)


def get_resolved_at_jalali(obj, fmt="%Y/%m/%d %H:%M"):
    return _get_field_jalali(obj, 'resolved_at', fmt)


def get_verified_at_jalali(obj, fmt="%Y/%m/%d %H:%M"):
    return _get_field_jalali(obj, 'verified_at', fmt)


def get_rejected_at_jalali(obj, fmt="%Y/%m/%d %H:%M"):
    return _get_field_jalali(obj, 'rejected_at', fmt)


def get_bank_receipt_uploaded_at_jalali(obj, fmt="%Y/%m/%d %H:%M"):
    return _get_field_jalali(obj, 'bank_receipt_uploaded_at', fmt)


def get_paid_at_jalali(obj, fmt="%Y/%m/%d %H:%M"):
    return _get_field_jalali(obj, 'paid_at', fmt)


def get_issue_date_jalali(obj, fmt="%Y/%m/%d"):
    return _get_field_jalali(obj, 'issue_date', fmt)


def get_closed_at_jalali(obj, fmt="%Y/%m/%d %H:%M"):
    return _get_field_jalali(obj, 'closed_at', fmt)


def get_sent_at_jalali(obj, fmt="%Y/%m/%d %H:%M"):
    return _get_field_jalali(obj, 'sent_at', fmt)


def get_used_at_jalali(obj, fmt="%Y/%m/%d %H:%M"):
    return _get_field_jalali(obj, 'used_at', fmt)


def get_last_run_at_jalali(obj, fmt="%Y/%m/%d %H:%M"):
    return _get_field_jalali(obj, 'last_run_at', fmt)
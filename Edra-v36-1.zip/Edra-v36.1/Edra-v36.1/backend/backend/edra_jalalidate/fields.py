# edra_jalalidate/fields.py
# -*- coding: utf-8 -*-
"""
فیلدهای مدل جنگو برای تاریخ جلالی.
این فیلدها در واقع همان DateField و DateTimeField هستند اما ویجت پیش‌فرض آن‌ها به جلالی تنظیم شده است.
همهٔ مقادیر در دیتابیس به صورت میلادی ذخیره می‌شوند.
"""

from django.db import models

# ویجت‌ها را در زمان نیاز ایمپورت می‌کنیم تا از وابستگی دایره‌ای جلوگیری شود


class jDateField(models.DateField):
    """
    فیلد تاریخ جلالی – معادل DateField با ویجت جلالی.
    مقدار دریافتی/خروجی در مدل به صورت datetime.date (میلادی) است.
    """

    def formfield(self, **kwargs):
        from .widgets import AdminjDateWidget
        kwargs['widget'] = AdminjDateWidget()
        return super().formfield(**kwargs)


class jDateTimeField(models.DateTimeField):
    """
    فیلد تاریخ و زمان جلالی – معادل DateTimeField با ویجت جلالی.
    مقدار دریافتی/خروجی در مدل به صورت datetime.datetime (میلادی) است.
    """

    def formfield(self, **kwargs):
        from .widgets import AdminjDateTimeWidget
        kwargs['widget'] = AdminjDateTimeWidget()
        return super().formfield(**kwargs)
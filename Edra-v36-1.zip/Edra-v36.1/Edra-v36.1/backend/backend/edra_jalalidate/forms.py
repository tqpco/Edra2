# edra_jalalidate/forms.py
# -*- coding: utf-8 -*-
"""
فیلدهای فرم جنگو برای تاریخ جلالی.
"""

from django import forms
from django.core.exceptions import ValidationError

from .jalali import JalaliDate, JalaliDateTime
from .jalali_widgets import JalaliDateWidget, JalaliDateTimeWidget
import datetime


class JalaliDateFormField(forms.DateField):
    widget = JalaliDateWidget

    def to_python(self, value):
        if value in self.empty_values:
            return None
        if isinstance(value, datetime.date):
            return value
        if isinstance(value, str):
            try:
                jd = JalaliDate.from_string(value.strip())
                return jd.to_date()
            except ValueError as e:
                raise ValidationError(f"فرمت تاریخ نامعتبر است: {e}")
        raise ValidationError("مقدار ورودی باید رشته یا تاریخ باشد.")


class JalaliDateTimeFormField(forms.DateTimeField):
    widget = JalaliDateTimeWidget

    def to_python(self, value):
        if value in self.empty_values:
            return None
        if isinstance(value, datetime.datetime):
            return value
        if isinstance(value, str):
            try:
                jdt = JalaliDateTime.from_string(value.strip())
                return jdt.to_datetime()
            except ValueError as e:
                raise ValidationError(f"فرمت تاریخ و ساعت نامعتبر است: {e}")
        raise ValidationError("مقدار ورودی باید رشته یا datetime باشد.")
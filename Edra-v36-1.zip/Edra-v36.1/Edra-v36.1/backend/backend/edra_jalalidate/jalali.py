# edra_jalalidate/jalali.py
# -*- coding: utf-8 -*-
"""
کلاس‌های اصلی برای کار با تاریخ و زمان جلالی - نسخه ۳.۴
"""

import datetime
import re
from typing import Optional, Tuple, Union
from . import _jalali_core as core

# ============================================================
# توابع کمکی برای تبدیل اعداد
# ============================================================
def _to_english_digits(value: str) -> str:
    if not value:
        return value
    persian_digits = '۰۱۲۳۴۵۶۷۸۹'
    arabic_digits = '٠١٢٣٤٥٦٧٨٩'
    english_digits = '0123456789'
    trans = str.maketrans(persian_digits + arabic_digits, english_digits + english_digits)
    return value.translate(trans)

def _is_integer_string(value: str) -> bool:
    return value.isdigit()

# ============================================================
# کلاس JalaliDate
# ============================================================
class JalaliDate:
    __slots__ = ('_year', '_month', '_day')

    def __init__(self, year: int, month: int, day: int):
        self._year = int(year)
        self._month = int(month)
        self._day = int(day)
        self._validate()

    def _validate(self) -> None:
        if not (1 <= self._month <= 12):
            raise ValueError("ماه باید بین ۱ تا ۱۲ باشد")
        max_day = core.jalali_month_days(self._year, self._month)
        if not (1 <= self._day <= max_day):
            raise ValueError(f"روز باید بین ۱ تا {max_day} باشد")

    @property
    def year(self) -> int: return self._year
    @property
    def month(self) -> int: return self._month
    @property
    def day(self) -> int: return self._day

    @classmethod
    def from_gregorian(cls, year: int, month: int, day: int) -> 'JalaliDate':
        y, m, d = core.gregorian_to_jalali(year, month, day)
        return cls(int(y), int(m), int(d))

    @classmethod
    def from_datetime(cls, dt: datetime.datetime) -> 'JalaliDate':
        return cls.from_gregorian(dt.year, dt.month, dt.day)

    @classmethod
    def from_date(cls, dt: datetime.date) -> 'JalaliDate':
        return cls.from_gregorian(dt.year, dt.month, dt.day)

    @classmethod
    def from_string(cls, value: str, fmt: str = "%Y/%m/%d") -> 'JalaliDate':
        value = value.strip()
        if not value:
            raise ValueError("رشته تاریخ خالی است")
        value = _to_english_digits(value)
        parts = None
        if '/' in value:
            parts = value.split('/')
        elif '-' in value:
            parts = value.split('-')
        elif len(value) == 8 and value.isdigit():
            parts = [value[:4], value[4:6], value[6:8]]
        else:
            raise ValueError(f"فرمت '{value}' نامعتبر است")
        if len(parts) != 3:
            raise ValueError("باید شامل سال، ماه و روز باشد")
        for part in parts:
            if not _is_integer_string(part):
                raise ValueError("فقط اعداد مجازند")
        year, month, day = map(int, parts)
        if year < 1:
            raise ValueError("سال باید بزرگتر از ۰ باشد")
        return cls(year, month, day)

    def to_gregorian(self) -> Tuple[int, int, int]:
        y, m, d = core.jalali_to_gregorian(self._year, self._month, self._day)
        return int(y), int(m), int(d)

    def to_date(self) -> datetime.date:
        y, m, d = self.to_gregorian()
        return datetime.date(int(y), int(m), int(d))

    def to_datetime(self) -> datetime.datetime:
        y, m, d = self.to_gregorian()
        return datetime.datetime(int(y), int(m), int(d))

    def days_in_month(self) -> int:
        return core.jalali_month_days(self._year, self._month)

    def is_leap_year(self) -> bool:
        return core.is_jalali_leap_year(self._year)

    def day_of_year(self) -> int:
        days = 0
        for m in range(1, self._month):
            days += core.jalali_month_days(self._year, m)
        return days + self._day

    def weekday(self) -> int:
        jdn = core.jalali_to_jdn(self._year, self._month, self._day)
        return int((jdn + 2) % 7)

    def month_name(self, lang: str = 'fa') -> str:
        months_fa = ['فروردین', 'اردیبهشت', 'خرداد', 'تیر', 'مرداد', 'شهریور',
                     'مهر', 'آبان', 'آذر', 'دی', 'بهمن', 'اسفند']
        months_en = ['Farvardin', 'Ordibehesht', 'Khordad', 'Tir', 'Mordad', 'Shahrivar',
                     'Mehr', 'Aban', 'Azar', 'Dey', 'Bahman', 'Esfand']
        return months_fa[self._month - 1] if lang == 'fa' else months_en[self._month - 1]

    def day_name(self, lang: str = 'fa') -> str:
        days_fa = ['شنبه', 'یکشنبه', 'دوشنبه', 'سه‌شنبه', 'چهارشنبه', 'پنجشنبه', 'جمعه']
        days_en = ['Saturday', 'Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday']
        return days_fa[self.weekday()] if lang == 'fa' else days_en[self.weekday()]

    def add_days(self, days: int) -> 'JalaliDate':
        jdn = core.jalali_to_jdn(self._year, self._month, self._day)
        jdn += days
        y, m, d = core.jdn_to_jalali(jdn)
        return JalaliDate(int(y), int(m), int(d))

    def add_months(self, months: int) -> 'JalaliDate':
        total_months = self._year * 12 + (self._month - 1) + months
        new_year = total_months // 12
        new_month = (total_months % 12) + 1
        max_day = core.jalali_month_days(new_year, new_month)
        new_day = min(self._day, max_day)
        return JalaliDate(int(new_year), int(new_month), int(new_day))

    def strftime(self, fmt: str) -> str:
        replacements = {
            '%Y': f'{self._year:04d}',
            '%y': f'{self._year % 100:02d}',
            '%m': f'{self._month:02d}',
            '%d': f'{self._day:02d}',
            '%B': self.month_name('fa'),
            '%b': self.month_name('fa'),
            '%A': self.day_name('fa'),
            '%a': self.day_name('fa'),
        }
        result = fmt
        for key, val in replacements.items():
            result = result.replace(key, val)
        return result

    def __str__(self) -> str:
        return f"{self._year:04d}/{self._month:02d}/{self._day:02d}"
    def __repr__(self) -> str:
        return f"JalaliDate({self._year}, {self._month}, {self._day})"
    def __eq__(self, other) -> bool:
        if not isinstance(other, JalaliDate): return False
        return (self._year, self._month, self._day) == (other._year, other._month, other._day)
    def __lt__(self, other) -> bool:
        if not isinstance(other, JalaliDate):
            raise TypeError(f"نمی‌توان با {type(other)} مقایسه کرد")
        return (self._year, self._month, self._day) < (other._year, other._month, other._day)
    def __le__(self, other) -> bool: return self < other or self == other
    def __gt__(self, other) -> bool: return not (self <= other)
    def __ge__(self, other) -> bool: return not (self < other)
    def __hash__(self) -> int: return hash((self._year, self._month, self._day))


# ============================================================
# کلاس JalaliDateTime
# ============================================================
class JalaliDateTime:
    __slots__ = ('_date', '_hour', '_minute', '_second', '_microsecond', '_tzinfo')

    def __init__(self, year: int, month: int, day: int,
                 hour: int = 0, minute: int = 0, second: int = 0,
                 microsecond: int = 0, tzinfo: Optional[datetime.tzinfo] = None):
        self._date = JalaliDate(int(year), int(month), int(day))
        self._hour = int(hour)
        self._minute = int(minute)
        self._second = int(second)
        self._microsecond = int(microsecond)
        self._tzinfo = tzinfo
        self._validate_time()

    def _validate_time(self) -> None:
        if not (0 <= self._hour < 24):
            raise ValueError("ساعت باید بین ۰ تا ۲۳ باشد")
        if not (0 <= self._minute < 60):
            raise ValueError("دقیقه باید بین ۰ تا ۵۹ باشد")
        if not (0 <= self._second < 60):
            raise ValueError("ثانیه باید بین ۰ تا ۵۹ باشد")
        if not (0 <= self._microsecond < 1_000_000):
            raise ValueError("میکروثانیه باید بین ۰ تا ۹۹۹۹۹۹ باشد")

    @property
    def date(self) -> JalaliDate: return self._date
    @property
    def year(self) -> int: return self._date.year
    @property
    def month(self) -> int: return self._date.month
    @property
    def day(self) -> int: return self._date.day
    @property
    def hour(self) -> int: return self._hour
    @property
    def minute(self) -> int: return self._minute
    @property
    def second(self) -> int: return self._second
    @property
    def microsecond(self) -> int: return self._microsecond
    @property
    def tzinfo(self) -> Optional[datetime.tzinfo]: return self._tzinfo

    @classmethod
    def from_gregorian(cls, year: int, month: int, day: int,
                       hour: int = 0, minute: int = 0, second: int = 0,
                       microsecond: int = 0, tzinfo: Optional[datetime.tzinfo] = None) -> 'JalaliDateTime':
        y, m, d = core.gregorian_to_jalali(int(year), int(month), int(day))
        return cls(int(y), int(m), int(d), int(hour), int(minute), int(second), int(microsecond), tzinfo)

    @classmethod
    def from_datetime(cls, dt: datetime.datetime) -> 'JalaliDateTime':
        return cls.from_gregorian(dt.year, dt.month, dt.day,
                                  dt.hour, dt.minute, dt.second, dt.microsecond, dt.tzinfo)

    @classmethod
    def from_string(cls, value: str, fmt: str = "%Y/%m/%d %H:%M") -> 'JalaliDateTime':
        value = value.strip()
        if not value:
            raise ValueError("رشته تاریخ خالی است")
        value = _to_english_digits(value)
        parts = value.split()
        if len(parts) < 2:
            raise ValueError("باید شامل تاریخ و ساعت باشد")
        date_part, time_part = parts[0], parts[1]
        date_obj = JalaliDate.from_string(date_part)
        time_parts = time_part.split(':')
        if len(time_parts) < 2:
            raise ValueError("فرمت زمان نامعتبر است")
        for part in time_parts[:2]:
            if not _is_integer_string(part):
                raise ValueError("فقط اعداد مجازند")
        hour = int(time_parts[0])
        minute = int(time_parts[1])
        second = int(time_parts[2]) if len(time_parts) > 2 else 0
        return cls(date_obj.year, date_obj.month, date_obj.day, hour, minute, second)

    def to_datetime(self) -> datetime.datetime:
        y, m, d = self._date.to_gregorian()
        return datetime.datetime(int(y), int(m), int(d),
                                 self._hour, self._minute, self._second, self._microsecond,
                                 tzinfo=self._tzinfo)

    def strftime(self, fmt: str) -> str:
        date_part = self._date.strftime(fmt)
        replacements = {
            '%H': f'{self._hour:02d}',
            '%M': f'{self._minute:02d}',
            '%S': f'{self._second:02d}',
            '%f': f'{self._microsecond:06d}',
        }
        result = date_part
        for key, val in replacements.items():
            result = result.replace(key, val)
        return result

    def __str__(self) -> str:
        return f"{self._date} {self._hour:02d}:{self._minute:02d}:{self._second:02d}"
    def __repr__(self) -> str:
        return (f"JalaliDateTime({self.year}, {self.month}, {self.day}, "
                f"{self.hour}, {self.minute}, {self.second}, {self.microsecond}, "
                f"tzinfo={self.tzinfo})")


# ============================================================
# توابع کمکی سطح بالا
# ============================================================
def to_jalali(dt: Union[datetime.datetime, datetime.date, None], fmt: str = "%Y/%m/%d %H:%M") -> str:
    if dt is None:
        return ""
    try:
        if isinstance(dt, datetime.datetime):
            return JalaliDateTime.from_datetime(dt).strftime(fmt)
        elif isinstance(dt, datetime.date):
            return JalaliDate.from_date(dt).strftime(fmt)
        else:
            raise TypeError("ورودی باید datetime یا date باشد")
    except ValueError:
        return ""

def get_jalali_today() -> JalaliDate:
    return JalaliDate.from_datetime(datetime.datetime.now())

def get_jalali_now() -> JalaliDateTime:
    return JalaliDateTime.from_datetime(datetime.datetime.now())
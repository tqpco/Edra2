# edra_jalalidate/jalali_widgets.py
# -*- coding: utf-8 -*-
"""
ویجت‌های تاریخ جلالی برای پنل ادمین جنگو
با استفاده از پکیج edra_jalalidate و فیلدهای استاندارد جنگو
"""

import datetime
import re
import logging

from django import forms
from django.contrib import admin
from django.db import models
from django.utils import timezone
from django.utils.safestring import mark_safe

from .jalali import JalaliDate, JalaliDateTime, to_jalali

logger = logging.getLogger(__name__)


# ============================================================
# توابع کمکی
# ============================================================
def _to_jalali_display(value, with_time=False):
    """تبدیل datetime گریگوری به رشته جلالی برای نمایش در input."""
    if value is None:
        return ''
    if isinstance(value, datetime.datetime):
        jdt = JalaliDateTime.from_datetime(value)
        return jdt.strftime('%Y/%m/%d %H:%M' if with_time else '%Y/%m/%d')
    if isinstance(value, datetime.date):
        jd = JalaliDate.from_date(value)
        return jd.strftime('%Y/%m/%d')
    return str(value)


def _parse_jalali_string(value, with_time=False):
    """تبدیل رشته جلالی به datetime.date یا datetime.datetime میلادی."""
    if not value:
        return None
    value = value.strip()
    if with_time:
        for fmt in ('%Y/%m/%d %H:%M', '%Y-%m-%d %H:%M', '%Y/%m/%d %H:%M:%S', '%Y-%m-%d %H:%M:%S'):
            try:
                jdt = JalaliDateTime.from_string(value, fmt)
                return jdt.to_datetime()
            except Exception:
                continue
        raise forms.ValidationError('فرمت تاریخ و ساعت نامعتبر است. نمونه: ۱۴۰۴/۰۵/۱۲ ۱۴:۳۰')
    else:
        for fmt in ('%Y/%m/%d', '%Y-%m-%d', '%Y%m%d'):
            try:
                jd = JalaliDate.from_string(value, fmt)
                return jd.to_datetime()
            except Exception:
                continue
        raise forms.ValidationError('فرمت تاریخ نامعتبر است. نمونه: ۱۴۰۴/۰۵/۱۲')


# ============================================================
# ویجت‌های اصلی (موجود در فایل قبلی)
# ============================================================
class JalaliDateWidget(forms.TextInput):
    class Media:
        css = {'all': ('edra_jalalidate/css/jalali-datepicker.css',)}
        js = ('edra_jalalidate/js/jalali-datepicker.js',)

    def __init__(self, attrs=None, theme='light'):
        default_attrs = {
            'class': 'edra-jalali-date-input',
            'autocomplete': 'off',
            'dir': 'ltr',
            'placeholder': '۱۴۰۴/۰۵/۱۲',
            'data-jalali': 'true',
            'data-theme': theme,
            'style': 'width: 130px;',
            'size': '12',
        }
        if attrs:
            default_attrs.update(attrs)
        super().__init__(attrs=default_attrs)

    def format_value(self, value):
        return _to_jalali_display(value, with_time=False)

    def value_from_datadict(self, data, files, name):
        value = data.get(name)
        if not value:
            return None
        value = value.strip()
        if not re.match(r'^\d{1,4}[/\-]\d{1,2}[/\-]\d{1,2}$', value):
            return value
        try:
            jd = JalaliDate.from_string(value)
            return jd.to_date()
        except Exception as e:
            logger.error(f"Error in value_from_datadict: {e}")
            return value


class JalaliDateTimeWidget(forms.TextInput):
    class Media:
        css = {'all': ('edra_jalalidate/css/jalali-datepicker.css',)}
        js = ('edra_jalalidate/js/jalali-datepicker.js',)

    def __init__(self, attrs=None, theme='light'):
        default_attrs = {
            'class': 'edra-jalali-datetime-input',
            'autocomplete': 'off',
            'dir': 'ltr',
            'placeholder': '۱۴۰۴/۰۵/۱۲ ۱۴:۳۰',
            'data-jalali': 'true',
            'data-datetime': 'true',
            'data-theme': theme,
            'style': 'width: 200px;',
            'size': '18',
        }
        if attrs:
            default_attrs.update(attrs)
        super().__init__(attrs=default_attrs)

    def format_value(self, value):
        return _to_jalali_display(value, with_time=True)

    def value_from_datadict(self, data, files, name):
        value = data.get(name)
        if not value:
            return None
        value = value.strip()
        if not re.match(r'^\d{1,4}[/\-]\d{1,2}[/\-]\d{1,2}\s+\d{1,2}:\d{1,2}(:\d{1,2})?$', value):
            return value
        try:
            jdt = JalaliDateTime.from_string(value)
            return jdt.to_datetime()
        except Exception as e:
            logger.error(f"Error in value_from_datadict: {e}")
            return value


class JalaliDateSeparateWidget(forms.MultiWidget):
    class Media:
        css = {'all': ('edra_jalalidate/css/jalali-datepicker.css',)}
        js = ('edra_jalalidate/js/jalali-datepicker.js',)

    def __init__(self, attrs=None, theme='light'):
        self.date_attrs = {
            'class': 'edra-jalali-date-input',
            'autocomplete': 'off',
            'dir': 'ltr',
            'data-jalali': 'true',
            'data-theme': theme,
            'placeholder': '۱۴۰۴/۰۵/۱۲',
            'style': 'width:120px; padding-left:28px;',
        }
        self.time_attrs = {
            'class': 'edra-jalali-time-input',
            'autocomplete': 'off',
            'dir': 'ltr',
            'type': 'time',
            'placeholder': '۱۴:۳۰',
            'style': 'width:80px; padding-left:28px;',
        }
        if attrs:
            self.date_attrs.update(attrs)
            self.time_attrs.update(attrs)
        widgets = (
            forms.TextInput(attrs=self.date_attrs),
            forms.TimeInput(attrs=self.time_attrs, format='%H:%M'),
        )
        super().__init__(widgets, attrs)

    def decompress(self, value):
        if value:
            if isinstance(value, datetime.datetime):
                jd = JalaliDate.from_datetime(value)
                return [jd.strftime('%Y/%m/%d'), value.strftime('%H:%M')]
            elif isinstance(value, str):
                try:
                    parts = value.split(' ')
                    if len(parts) == 2:
                        return [parts[0], parts[1]]
                    return [value, '']
                except:
                    return [value, '']
        return [None, None]

    def value_from_datadict(self, data, files, name):
        date_value = data.get(f'{name}_0')
        time_value = data.get(f'{name}_1')
        
        if not date_value and not time_value:
            return None
        
        if date_value and not time_value:
            time_value = '00:00'
        if time_value and not date_value:
            from .jalali import get_jalali_today
            today = get_jalali_today()
            date_value = str(today)
        
        try:
            jd = JalaliDate.from_string(date_value.strip())
            greg_date = jd.to_date()
            time_parts = time_value.strip().split(':')
            hour = int(time_parts[0]) if len(time_parts) > 0 else 0
            minute = int(time_parts[1]) if len(time_parts) > 1 else 0
            return datetime.datetime(greg_date.year, greg_date.month, greg_date.day, hour, minute)
        except Exception as e:
            logger.error(f"Error in value_from_datadict (separate): {e}")
            return f"{date_value} {time_value}"

    def render(self, name, value, attrs=None, renderer=None):
        if value is not None:
            values = self.decompress(value)
        else:
            values = [None, None]
        
        date_html = f'''
        <div style="display:inline-block; position:relative; margin-right:5px;">
            <span style="position:absolute; left:5px; top:50%; transform:translateY(-50%); font-size:16px; pointer-events:none; z-index:1;">📅</span>
            <input type="text" name="{name}_0" value="{values[0] or ''}" class="{self.date_attrs.get('class', '')}" 
                   style="{self.date_attrs.get('style', '')}" 
                   placeholder="{self.date_attrs.get('placeholder', '')}" 
                   autocomplete="off" dir="ltr" data-jalali="true" data-theme="{self.date_attrs.get('data-theme', 'light')}">
        </div>
        '''
        
        time_html = f'''
        <div style="display:inline-block; position:relative;">
            <span style="position:absolute; left:5px; top:50%; transform:translateY(-50%); font-size:16px; pointer-events:none; z-index:1;">🕐</span>
            <input type="time" name="{name}_1" value="{values[1] or ''}" class="{self.time_attrs.get('class', '')}" 
                   style="{self.time_attrs.get('style', '')}" 
                   placeholder="{self.time_attrs.get('placeholder', '')}" 
                   autocomplete="off" dir="ltr">
        </div>
        '''
        
        return mark_safe(f'<div style="display:flex; gap:8px; align-items:center; flex-wrap:wrap;">{date_html}{time_html}</div>')


# ============================================================
# ✅ بخش جدید: میکسین ادمین و فیلترهای مورد نیاز
# ============================================================
class EdraJalaliAdminMixin:
    """
    میکسین برای ModelAdmin که فیلدهای تاریخ را به جلالی تبدیل می‌کند.
    با override متد `formfield_for_dbfield` فیلدهای فرم را جایگزین می‌کند.
    """
    def formfield_for_dbfield(self, db_field, request, **kwargs):
        if isinstance(db_field, models.DateField):
            kwargs['widget'] = JalaliDateWidget()
        elif isinstance(db_field, models.DateTimeField):
            kwargs['widget'] = JalaliDateTimeWidget()
        return super().formfield_for_dbfield(db_field, request, **kwargs)

    # متدهای کمکی برای نمایش جلالی در list_display
    def get_jalali_display(self, obj, field_name, fmt="%Y/%m/%d %H:%M"):
        value = getattr(obj, field_name, None)
        if value is None:
            return "—"
        return to_jalali(value, fmt)

    def jalali_created_at(self, obj):
        return self.get_jalali_display(obj, 'created_at', '%Y/%m/%d %H:%M')
    jalali_created_at.short_description = "تاریخ ایجاد (جلالی)"
    jalali_created_at.admin_order_field = 'created_at'

    def jalali_updated_at(self, obj):
        return self.get_jalali_display(obj, 'updated_at', '%Y/%m/%d %H:%M')
    jalali_updated_at.short_description = "تاریخ بروزرسانی (جلالی)"
    jalali_updated_at.admin_order_field = 'updated_at'


def make_jalali_date_filter(field_name, title_label):
    """
    ساخت فیلتر تاریخ شمسی برای list_filter ادمین.
    """
    class JalaliDateFilter(admin.SimpleListFilter):
        parameter_name = field_name
        title = title_label

        def lookups(self, request, model_admin):
            return (
                ('today', 'امروز'),
                ('7days', '۷ روز اخیر'),
                ('30days', '۳۰ روز اخیر'),
                ('this_month', 'این ماه شمسی'),
                ('this_year', 'امسال شمسی'),
            )

        def queryset(self, request, queryset):
            value = self.value()
            if not value:
                return queryset
            now = timezone.localtime(timezone.now())
            start = None
            end = None

            if value == 'today':
                start = now.replace(hour=0, minute=0, second=0, microsecond=0)
                end = start + datetime.timedelta(days=1)
            elif value == '7days':
                start = now - datetime.timedelta(days=7)
            elif value == '30days':
                start = now - datetime.timedelta(days=30)
            elif value == 'this_month':
                jnow = JalaliDateTime.from_datetime(now)
                jstart = JalaliDate(jnow.date.year, jnow.date.month, 1)
                greg_start = jstart.to_datetime()
                start = timezone.make_aware(greg_start) if timezone.is_naive(greg_start) else greg_start
                if jnow.date.month == 12:
                    jend = JalaliDate(jnow.date.year + 1, 1, 1)
                else:
                    jend = JalaliDate(jnow.date.year, jnow.date.month + 1, 1)
                greg_end = jend.to_datetime()
                end = timezone.make_aware(greg_end) if timezone.is_naive(greg_end) else greg_end
            elif value == 'this_year':
                jnow = JalaliDateTime.from_datetime(now)
                jstart = JalaliDate(jnow.date.year, 1, 1)
                greg_start = jstart.to_datetime()
                start = timezone.make_aware(greg_start) if timezone.is_naive(greg_start) else greg_start
                jend = JalaliDate(jnow.date.year + 1, 1, 1)
                greg_end = jend.to_datetime()
                end = timezone.make_aware(greg_end) if timezone.is_naive(greg_end) else greg_end

            if start is None:
                return queryset
            if end is not None:
                return queryset.filter(**{
                    f'{field_name}__gte': start,
                    f'{field_name}__lt': end
                })
            return queryset.filter(**{f'{field_name}__gte': start})

    return JalaliDateFilter
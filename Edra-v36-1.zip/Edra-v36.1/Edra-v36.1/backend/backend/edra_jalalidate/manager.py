# edra_jalalidate/manager.py
# -*- coding: utf-8 -*-
"""
مدیر سفارشی برای مدل‌هایی که فیلد تاریخ جلالی دارند.
امکان فیلتر کردن مستقیم با رشته‌های جلالی را فراهم می‌کند (مثلاً created_at='۱۴۰۴/۰۵/۱۲').
"""

from django.db import models
from .jalali import JalaliDate, JalaliDateTime
import datetime
import re


class JalaliManager(models.Manager):
    """
    مدیری که در متدهای filter، exclude و get رشته‌های جلالی را تشخیص داده و به میلادی تبدیل می‌کند.
    """

    _jalali_pattern = re.compile(r'^\d{4}[-/]\d{1,2}[-/]\d{1,2}(?:\s+\d{1,2}:\d{1,2}(?::\d{1,2})?)?$')

    def _is_jalali_string(self, value):
        if not isinstance(value, str):
            return False
        return bool(self._jalali_pattern.match(value.strip()))

    def _parse_jalali_string(self, value):
        value = value.strip()
        if ':' in value:
            return JalaliDateTime.from_string(value).to_datetime()
        else:
            return JalaliDate.from_string(value).to_date()

    def _convert_kwargs(self, kwargs):
        """تبدیل مقادیر جلالی در kwargs به میلادی."""
        new_kwargs = {}
        for key, val in kwargs.items():
            if isinstance(val, str) and self._is_jalali_string(val):
                try:
                    new_kwargs[key] = self._parse_jalali_string(val)
                except ValueError:
                    # اگر نتوانست تبدیل کند، همان رشته را نگه می‌داریم (احتمالاً lookup دیگریست)
                    new_kwargs[key] = val
            else:
                new_kwargs[key] = val
        return new_kwargs

    def filter(self, *args, **kwargs):
        return super().filter(*args, **self._convert_kwargs(kwargs))

    def exclude(self, *args, **kwargs):
        return super().exclude(*args, **self._convert_kwargs(kwargs))

    def get(self, *args, **kwargs):
        return super().get(*args, **self._convert_kwargs(kwargs))
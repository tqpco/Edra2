# edra_jalalidate/ntp.py
# -*- coding: utf-8 -*-
"""
دریافت زمان دقیق از سرورهای NTP با fallback به زمان سیستم.
"""

import socket
import struct
import datetime
from typing import Optional

NTP_SERVERS = [
    'time.google.com',
    'time.windows.com',
    'pool.ntp.org',
    'time.ir',
]


def get_ntp_time(server: str = 'time.google.com', timeout: int = 3) -> Optional[datetime.datetime]:
    """
    دریافت زمان از یک سرور NTP.
    در صورت موفقیت، datetime.timezone.utc برگردانده می‌شود.
    """
    try:
        request = b'\x1b' + 47 * b'\0'
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        sock.settimeout(timeout)
        sock.sendto(request, (server, 123))
        data, _ = sock.recvfrom(1024)
        sock.close()
        seconds = struct.unpack('!I', data[40:44])[0]
        return datetime.datetime(1900, 1, 1, tzinfo=datetime.timezone.utc) + datetime.timedelta(seconds=seconds)
    except Exception:
        return None


def get_accurate_datetime(use_system_fallback: bool = True) -> datetime.datetime:
    """
    دریافت زمان دقیق با امتحان چند سرور NTP.
    در صورت عدم موفقیت و فعال بودن fallback، زمان سیستم برگردانده می‌شود.
    """
    for server in NTP_SERVERS:
        dt = get_ntp_time(server)
        if dt is not None:
            return dt
    if use_system_fallback:
        return datetime.datetime.now(datetime.timezone.utc)
    raise RuntimeError("هیچ سرور NTP در دسترس نیست و fallback غیرفعال است.")
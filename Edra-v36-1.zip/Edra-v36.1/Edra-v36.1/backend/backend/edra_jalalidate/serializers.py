# edra_jalalidate/serializers.py
# -*- coding: utf-8 -*-
"""
فیلدهای سریالایزر Django REST Framework برای تاریخ جلالی.
ورودی/خروجی به صورت رشتهٔ جلالی انجام می‌شود و مقدار داخلی میلادی است.
"""

from rest_framework import serializers
from .jalali import JalaliDate, JalaliDateTime
import datetime


class JDateField(serializers.Field):
    """
    فیلد سریالایزر برای تاریخ جلالی (فقط تاریخ).
    """

    def to_representation(self, value):
        if value is None:
            return None
        if isinstance(value, datetime.date):
            return JalaliDate.from_date(value).strftime('%Y/%m/%d')
        return str(value)

    def to_internal_value(self, data):
        if data is None or data == '':
            return None
        if isinstance(data, datetime.date):
            return data
        if isinstance(data, str):
            try:
                return JalaliDate.from_string(data.strip()).to_date()
            except ValueError as e:
                raise serializers.ValidationError(f"فرمت تاریخ نامعتبر است: {e}")
        raise serializers.ValidationError("مقدار ورودی باید رشته یا تاریخ باشد.")


class JDateTimeField(serializers.Field):
    """
    فیلد سریالایزر برای تاریخ و ساعت جلالی.
    """

    def to_representation(self, value):
        if value is None:
            return None
        if isinstance(value, datetime.datetime):
            return JalaliDateTime.from_datetime(value).strftime('%Y/%m/%d %H:%M')
        return str(value)

    def to_internal_value(self, data):
        if data is None or data == '':
            return None
        if isinstance(data, datetime.datetime):
            return data
        if isinstance(data, str):
            try:
                return JalaliDateTime.from_string(data.strip()).to_datetime()
            except ValueError as e:
                raise serializers.ValidationError(f"فرمت تاریخ و ساعت نامعتبر است: {e}")
        raise serializers.ValidationError("مقدار ورودی باید رشته یا datetime باشد.")
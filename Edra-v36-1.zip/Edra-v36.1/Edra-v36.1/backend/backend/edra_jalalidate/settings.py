# edra_jalalidate/settings.py
# -*- coding: utf-8 -*-
"""
تنظیمات کتابخانه edra_jalalidate.
مقادیر پیش‌فرض را از settings.JALALI_SETTINGS دریافت می‌کند.
"""

from django.conf import settings
from django.core.exceptions import ImproperlyConfigured

DEFAULT_SETTINGS = {
    'USE_PERSIAN_DIGITS': False,          # آیا اعداد فارسی نمایش داده شوند؟
    'DATE_FORMAT': '%Y/%m/%d',            # فرمت پیش‌فرض تاریخ
    'DATETIME_FORMAT': '%Y/%m/%d %H:%M',  # فرمت پیش‌فرض تاریخ و ساعت
    'STATIC_URL_PREFIX': 'edra_jalalidate/',  # آدرس پیشوند فایل‌های استاتیک
    'WEEK_START': 0,                      # ۰=شنبه، ۱=یکشنبه (فعلاً فقط ۰ پشتیبانی می‌شود)
}

JALALI_SETTINGS = getattr(settings, 'JALALI_SETTINGS', {})

# تکمیل تنظیمات با مقادیر پیش‌فرض
for key, value in DEFAULT_SETTINGS.items():
    if key not in JALALI_SETTINGS:
        JALALI_SETTINGS[key] = value

# اعتبارسنجی
if not isinstance(JALALI_SETTINGS.get('USE_PERSIAN_DIGITS'), bool):
    raise ImproperlyConfigured("JALALI_SETTINGS['USE_PERSIAN_DIGITS'] باید boolean باشد.")
// edra_jalalidate/static/edra_jalalidate/js/jalali-datepicker.js
// نسخه ۴.۲ - کامل با تمام متدها، رفع خطای _setValueFromInput

(function(global) {
    'use strict';

    // ============================================================
    // 1. تبدیل اعداد
    // ============================================================
    var toEnglishDigits = function(str) {
        if (!str) return str;
        var persianDigits = '۰۱۲۳۴۵۶۷۸۹';
        var arabicDigits = '٠١٢٣٤٥٦٧٨٩';
        var englishDigits = '0123456789';
        var map = {};
        for (var i = 0; i < 10; i++) {
            map[persianDigits[i]] = englishDigits[i];
            map[arabicDigits[i]] = englishDigits[i];
        }
        return str.replace(/[۰-۹٠-٩]/g, function(ch) {
            return map[ch] || ch;
        });
    };

    var toPersianDigits = function(str) {
        if (!str) return str;
        var persianDigits = '۰۱۲۳۴۵۶۷۸۹';
        return String(str).replace(/\d/g, function(d) {
            return persianDigits[+d];
        });
    };

    // ============================================================
    // 2. الگوریتم جلالی با مرجع ثابت
    // ============================================================
    var REF_JALALI_YEAR = 1400;
    var REF_JALALI_MONTH = 1;
    var REF_JALALI_DAY = 1;
    var REF_GREGORIAN = new Date(Date.UTC(2021, 2, 21, 12, 0, 0));

    var LEAP_EXCEPTIONS = { 1408: true, 1412: true, 1416: true };
    var COMMON_EXCEPTIONS = { 1407: true };

    function isJalaliLeapYear(year) {
        if (COMMON_EXCEPTIONS[year]) return false;
        var rem = year % 33;
        var standardLeap = rem === 1 || rem === 5 || rem === 9 || rem === 13 ||
                           rem === 17 || rem === 21 || rem === 26 || rem === 30;
        if (LEAP_EXCEPTIONS[year]) return true;
        return standardLeap;
    }

    function jalaliMonthDays(year, month) {
        if (month < 1 || month > 12) return 0;
        if (month <= 6) return 31;
        if (month <= 11) return 30;
        return isJalaliLeapYear(year) ? 30 : 29;
    }

    function jalaliToDaysSinceRef(year, month, day) {
        var days = 0;
        for (var y = REF_JALALI_YEAR; y < year; y++) {
            days += 365 + (isJalaliLeapYear(y) ? 1 : 0);
        }
        for (var m = 1; m < month; m++) {
            days += jalaliMonthDays(year, m);
        }
        days += day - 1;
        return days;
    }

    function toGregorian(jy, jm, jd) {
        var daysOffset = jalaliToDaysSinceRef(jy, jm, jd);
        var target = new Date(REF_GREGORIAN.getTime() + daysOffset * 86400000);
        return {
            year: target.getUTCFullYear(),
            month: target.getUTCMonth() + 1,
            day: target.getUTCDate()
        };
    }

    function toJalaali(gy, gm, gd) {
        var target = new Date(Date.UTC(gy, gm - 1, gd, 12, 0, 0));
        var deltaDays = Math.round((target - REF_GREGORIAN) / 86400000);
        if (deltaDays < 0) {
            return { year: REF_JALALI_YEAR, month: REF_JALALI_MONTH, day: REF_JALALI_DAY };
        }
        var year = REF_JALALI_YEAR;
        var remaining = deltaDays;
        while (true) {
            var daysInYear = 365 + (isJalaliLeapYear(year) ? 1 : 0);
            if (remaining < daysInYear) break;
            remaining -= daysInYear;
            year++;
        }
        var month = 1;
        while (month <= 12) {
            var daysInMonth = jalaliMonthDays(year, month);
            if (remaining < daysInMonth) break;
            remaining -= daysInMonth;
            month++;
        }
        var day = remaining + 1;
        return { year: year, month: month, day: day };
    }

    // ============================================================
    // 3. دریافت تاریخ امروز
    // ============================================================
    function getTodayGregorian() {
        try {
            var formatter = new Intl.DateTimeFormat('en-US', {
                timeZone: 'Asia/Tehran',
                year: 'numeric', month: '2-digit', day: '2-digit',
                hour: '2-digit', minute: '2-digit', second: '2-digit',
                hour12: false
            });
            var parts = formatter.formatToParts(new Date());
            var result = {};
            for (var i = 0; i < parts.length; i++) {
                var p = parts[i];
                if (p.type === 'year') result.year = parseInt(p.value, 10);
                else if (p.type === 'month') result.month = parseInt(p.value, 10);
                else if (p.type === 'day') result.day = parseInt(p.value, 10);
                else if (p.type === 'hour') result.hour = parseInt(p.value, 10);
                else if (p.type === 'minute') result.minute = parseInt(p.value, 10);
                else if (p.type === 'second') result.second = parseInt(p.value, 10);
            }
            if (!isNaN(result.year) && !isNaN(result.month) && !isNaN(result.day)) {
                return result;
            }
        } catch (_) { /* fallback */ }
        var now = new Date();
        var utc = now.getTime() + (now.getTimezoneOffset() * 60000);
        var tehranOffset = 3.5 * 3600000;
        var tehranTime = new Date(utc + tehranOffset);
        return {
            year: tehranTime.getUTCFullYear(),
            month: tehranTime.getUTCMonth() + 1,
            day: tehranTime.getUTCDate(),
            hour: tehranTime.getUTCHours(),
            minute: tehranTime.getUTCMinutes(),
            second: tehranTime.getUTCSeconds()
        };
    }

    // ============================================================
    // 4. کلاس اصلی JalaliDatePicker
    // ============================================================
    function JalaliDatePicker(input, options) {
        this.input = input;
        this.options = {
            format: '%Y/%m/%d',
            withTime: false,
            closeOnSelect: true,
            showTodayButton: true,
            showClearButton: true,
            rtl: true,
            theme: 'light',
            position: 'auto'
        };
        for (var key in options) {
            if (options.hasOwnProperty(key)) {
                this.options[key] = options[key];
            }
        }

        this.isOpen = false;
        this.selectedDate = null;
        this.viewYear = null;
        this.viewMonth = null;
        this._pickerElement = null;
        this._titleSpan = null;
        this._daysGrid = null;
        this.hourInput = null;
        this.minuteInput = null;

        try {
            this._initPicker();
            this._bindEvents();
            this._setValueFromInput();
        } catch (e) {
            console.error('JalaliDatePicker init error:', e);
        }
    }

    // -------- متدهای کلاس --------

    JalaliDatePicker.prototype._initPicker = function() {
        var container = document.createElement('div');
        container.className = 'jalali-datepicker-popup ' + this.options.theme;
        container.style.display = 'none';
        container.style.position = 'fixed';
        container.style.zIndex = '10000';
        container.style.minWidth = '320px';
        container.style.maxWidth = '560px';
        container.style.direction = this.options.rtl ? 'rtl' : 'ltr';
        container.style.background = this.options.theme === 'dark' ? '#1e293b' : '#ffffff';
        container.style.border = '1px solid ' + (this.options.theme === 'dark' ? '#334155' : '#e5e7eb');
        container.style.borderRadius = '12px';
        container.style.boxShadow = '0 12px 40px rgba(0,0,0,0.12)';
        container.style.padding = '14px';

        var self = this;

        var mainWrapper = document.createElement('div');
        mainWrapper.style.display = 'flex';
        mainWrapper.style.flexWrap = 'wrap';
        mainWrapper.style.gap = '10px';

        // ستون تقویم
        var calendarColumn = document.createElement('div');
        calendarColumn.style.flex = '1 1 260px';
        calendarColumn.style.minWidth = '240px';

        var header = document.createElement('div');
        header.style.display = 'flex';
        header.style.justifyContent = 'space-between';
        header.style.alignItems = 'center';
        header.style.marginBottom = '10px';
        header.style.paddingBottom = '6px';
        header.style.borderBottom = '1px solid ' + (this.options.theme === 'dark' ? '#334155' : '#f1f5f9');

        var prevBtn = document.createElement('button');
        prevBtn.type = 'button';
        prevBtn.style.background = 'transparent';
        prevBtn.style.border = 'none';
        prevBtn.style.cursor = 'pointer';
        prevBtn.style.fontSize = '18px';
        prevBtn.style.color = this.options.theme === 'dark' ? '#cbd5e1' : '#64748b';
        prevBtn.style.padding = '2px 10px';
        prevBtn.style.borderRadius = '6px';
        prevBtn.textContent = this.options.rtl ? '›' : '‹';
        prevBtn.addEventListener('click', function(e) {
            e.stopPropagation();
            self._changeMonth(-1);
        });

        var titleSpan = document.createElement('span');
        titleSpan.style.fontSize = '15px';
        titleSpan.style.fontWeight = '500';
        titleSpan.style.color = this.options.theme === 'dark' ? '#f1f5f9' : '#1e293b';

        var nextBtn = document.createElement('button');
        nextBtn.type = 'button';
        nextBtn.style.background = 'transparent';
        nextBtn.style.border = 'none';
        nextBtn.style.cursor = 'pointer';
        nextBtn.style.fontSize = '18px';
        nextBtn.style.color = this.options.theme === 'dark' ? '#cbd5e1' : '#64748b';
        nextBtn.style.padding = '2px 10px';
        nextBtn.style.borderRadius = '6px';
        nextBtn.textContent = this.options.rtl ? '‹' : '›';
        nextBtn.addEventListener('click', function(e) {
            e.stopPropagation();
            self._changeMonth(1);
        });

        header.appendChild(prevBtn);
        header.appendChild(titleSpan);
        header.appendChild(nextBtn);
        calendarColumn.appendChild(header);

        var weekdaysRow = document.createElement('div');
        weekdaysRow.style.display = 'grid';
        weekdaysRow.style.gridTemplateColumns = 'repeat(7, 1fr)';
        weekdaysRow.style.textAlign = 'center';
        weekdaysRow.style.marginBottom = '4px';
        weekdaysRow.style.fontSize = '12px';
        weekdaysRow.style.color = this.options.theme === 'dark' ? '#94a3b8' : '#94a3b8';
        weekdaysRow.style.fontWeight = '500';
        var weekdays = this.options.rtl ? ['ش', 'ی', 'د', 'س', 'چ', 'پ', 'ج'] : ['Sa', 'Su', 'Mo', 'Tu', 'We', 'Th', 'Fr'];
        for (var wd = 0; wd < weekdays.length; wd++) {
            var span = document.createElement('span');
            span.textContent = weekdays[wd];
            span.style.padding = '4px 0';
            weekdaysRow.appendChild(span);
        }
        calendarColumn.appendChild(weekdaysRow);

        var daysGrid = document.createElement('div');
        daysGrid.style.display = 'grid';
        daysGrid.style.gridTemplateColumns = 'repeat(7, 1fr)';
        daysGrid.style.gap = '2px';
        calendarColumn.appendChild(daysGrid);
        this._daysGrid = daysGrid;

        mainWrapper.appendChild(calendarColumn);

        // ستون ساعت
        var timeColumn = null;
        if (this.options.withTime) {
            timeColumn = document.createElement('div');
            timeColumn.style.flex = '0 0 110px';
            timeColumn.style.display = 'flex';
            timeColumn.style.flexDirection = 'column';
            timeColumn.style.justifyContent = 'center';
            timeColumn.style.alignItems = 'center';
            timeColumn.style.gap = '6px';
            timeColumn.style.padding = '0 10px';
            timeColumn.style.borderRight = this.options.rtl ? 'none' : '1px solid ' + (this.options.theme === 'dark' ? '#334155' : '#e5e7eb');
            timeColumn.style.borderLeft = this.options.rtl ? '1px solid ' + (this.options.theme === 'dark' ? '#334155' : '#e5e7eb') : 'none';

            var timeLabel = document.createElement('div');
            timeLabel.textContent = '⏱ زمان';
            timeLabel.style.fontSize = '12px';
            timeLabel.style.color = this.options.theme === 'dark' ? '#94a3b8' : '#94a3b8';
            timeLabel.style.fontWeight = '500';
            timeLabel.style.marginBottom = '2px';
            timeColumn.appendChild(timeLabel);

            // ساعت
            var hourContainer = document.createElement('div');
            hourContainer.style.display = 'flex';
            hourContainer.style.alignItems = 'center';
            hourContainer.style.gap = '4px';

            var hourLabel = document.createElement('span');
            hourLabel.textContent = 'ساعت:';
            hourLabel.style.fontSize = '12px';
            hourLabel.style.color = this.options.theme === 'dark' ? '#94a3b8' : '#64748b';

            var hourInput = document.createElement('input');
            hourInput.type = 'number';
            hourInput.min = 0;
            hourInput.max = 23;
            hourInput.value = '0';
            hourInput.style.width = '50px';
            hourInput.style.padding = '4px';
            hourInput.style.border = '1px solid ' + (this.options.theme === 'dark' ? '#475569' : '#d1d5db');
            hourInput.style.borderRadius = '4px';
            hourInput.style.textAlign = 'center';
            hourInput.style.fontSize = '14px';
            hourInput.style.background = this.options.theme === 'dark' ? '#334155' : '#ffffff';
            hourInput.style.color = this.options.theme === 'dark' ? '#e2e8f0' : '#1e293b';
            hourInput.className = 'jalali-time-input';

            var hourStepper = document.createElement('div');
            hourStepper.style.display = 'flex';
            hourStepper.style.flexDirection = 'column';
            hourStepper.style.marginLeft = '2px';
            var hourUp = document.createElement('button');
            hourUp.type = 'button';
            hourUp.textContent = '▲';
            hourUp.style.fontSize = '8px';
            hourUp.style.padding = '0 4px';
            hourUp.style.border = 'none';
            hourUp.style.background = 'transparent';
            hourUp.style.cursor = 'pointer';
            hourUp.style.color = this.options.theme === 'dark' ? '#94a3b8' : '#64748b';
            hourUp.addEventListener('click', function(e) {
                e.preventDefault();
                var val = parseInt(hourInput.value, 10) || 0;
                hourInput.value = Math.min(23, val + 1);
                self._updateSelectedTime();
            });
            var hourDown = document.createElement('button');
            hourDown.type = 'button';
            hourDown.textContent = '▼';
            hourDown.style.fontSize = '8px';
            hourDown.style.padding = '0 4px';
            hourDown.style.border = 'none';
            hourDown.style.background = 'transparent';
            hourDown.style.cursor = 'pointer';
            hourDown.style.color = this.options.theme === 'dark' ? '#94a3b8' : '#64748b';
            hourDown.addEventListener('click', function(e) {
                e.preventDefault();
                var val = parseInt(hourInput.value, 10) || 0;
                hourInput.value = Math.max(0, val - 1);
                self._updateSelectedTime();
            });
            hourStepper.appendChild(hourUp);
            hourStepper.appendChild(hourDown);

            hourContainer.appendChild(hourLabel);
            hourContainer.appendChild(hourInput);
            hourContainer.appendChild(hourStepper);
            timeColumn.appendChild(hourContainer);

            // دقیقه
            var minuteContainer = document.createElement('div');
            minuteContainer.style.display = 'flex';
            minuteContainer.style.alignItems = 'center';
            minuteContainer.style.gap = '4px';

            var minuteLabel = document.createElement('span');
            minuteLabel.textContent = 'دقیقه:';
            minuteLabel.style.fontSize = '12px';
            minuteLabel.style.color = this.options.theme === 'dark' ? '#94a3b8' : '#64748b';

            var minuteInput = document.createElement('input');
            minuteInput.type = 'number';
            minuteInput.min = 0;
            minuteInput.max = 59;
            minuteInput.value = '0';
            minuteInput.style.width = '50px';
            minuteInput.style.padding = '4px';
            minuteInput.style.border = '1px solid ' + (this.options.theme === 'dark' ? '#475569' : '#d1d5db');
            minuteInput.style.borderRadius = '4px';
            minuteInput.style.textAlign = 'center';
            minuteInput.style.fontSize = '14px';
            minuteInput.style.background = this.options.theme === 'dark' ? '#334155' : '#ffffff';
            minuteInput.style.color = this.options.theme === 'dark' ? '#e2e8f0' : '#1e293b';
            minuteInput.className = 'jalali-time-input';

            var minuteStepper = document.createElement('div');
            minuteStepper.style.display = 'flex';
            minuteStepper.style.flexDirection = 'column';
            minuteStepper.style.marginLeft = '2px';
            var minuteUp = document.createElement('button');
            minuteUp.type = 'button';
            minuteUp.textContent = '▲';
            minuteUp.style.fontSize = '8px';
            minuteUp.style.padding = '0 4px';
            minuteUp.style.border = 'none';
            minuteUp.style.background = 'transparent';
            minuteUp.style.cursor = 'pointer';
            minuteUp.style.color = this.options.theme === 'dark' ? '#94a3b8' : '#64748b';
            minuteUp.addEventListener('click', function(e) {
                e.preventDefault();
                var val = parseInt(minuteInput.value, 10) || 0;
                minuteInput.value = Math.min(59, val + 1);
                self._updateSelectedTime();
            });
            var minuteDown = document.createElement('button');
            minuteDown.type = 'button';
            minuteDown.textContent = '▼';
            minuteDown.style.fontSize = '8px';
            minuteDown.style.padding = '0 4px';
            minuteDown.style.border = 'none';
            minuteDown.style.background = 'transparent';
            minuteDown.style.cursor = 'pointer';
            minuteDown.style.color = this.options.theme === 'dark' ? '#94a3b8' : '#64748b';
            minuteDown.addEventListener('click', function(e) {
                e.preventDefault();
                var val = parseInt(minuteInput.value, 10) || 0;
                minuteInput.value = Math.max(0, val - 1);
                self._updateSelectedTime();
            });
            minuteStepper.appendChild(minuteUp);
            minuteStepper.appendChild(minuteDown);

            minuteContainer.appendChild(minuteLabel);
            minuteContainer.appendChild(minuteInput);
            minuteContainer.appendChild(minuteStepper);
            timeColumn.appendChild(minuteContainer);

            mainWrapper.appendChild(timeColumn);
            this.hourInput = hourInput;
            this.minuteInput = minuteInput;
        }

        container.appendChild(mainWrapper);

        var footer = document.createElement('div');
        footer.style.display = 'flex';
        footer.style.justifyContent = 'space-between';
        footer.style.marginTop = '10px';
        footer.style.paddingTop = '10px';
        footer.style.borderTop = '1px solid ' + (this.options.theme === 'dark' ? '#334155' : '#f1f5f9');
        footer.style.gap = '6px';

        var todayBtn = document.createElement('button');
        todayBtn.type = 'button';
        todayBtn.textContent = 'امروز';
        todayBtn.style.flex = '1';
        todayBtn.style.padding = '4px 14px';
        todayBtn.style.border = '1px solid ' + (this.options.theme === 'dark' ? '#475569' : '#e5e7eb');
        todayBtn.style.borderRadius = '6px';
        todayBtn.style.cursor = 'pointer';
        todayBtn.style.fontSize = '12px';
        todayBtn.style.fontFamily = 'inherit';
        todayBtn.style.background = '#4f46e5';
        todayBtn.style.color = '#ffffff';
        todayBtn.style.borderColor = '#4f46e5';
        todayBtn.addEventListener('click', function(e) {
            e.stopPropagation();
            self._selectToday();
        });

        var clearBtn = document.createElement('button');
        clearBtn.type = 'button';
        clearBtn.textContent = 'پاک کردن';
        clearBtn.style.flex = '1';
        clearBtn.style.padding = '4px 14px';
        clearBtn.style.border = '1px solid ' + (this.options.theme === 'dark' ? '#475569' : '#e5e7eb');
        clearBtn.style.borderRadius = '6px';
        clearBtn.style.cursor = 'pointer';
        clearBtn.style.fontSize = '12px';
        clearBtn.style.fontFamily = 'inherit';
        clearBtn.style.background = 'transparent';
        clearBtn.style.color = this.options.theme === 'dark' ? '#e2e8f0' : '#475569';
        clearBtn.addEventListener('click', function(e) {
            e.stopPropagation();
            self._clearDate();
        });

        var closeBtn = document.createElement('button');
        closeBtn.type = 'button';
        closeBtn.textContent = 'بستن';
        closeBtn.style.flex = '1';
        closeBtn.style.padding = '4px 14px';
        closeBtn.style.border = '1px solid ' + (this.options.theme === 'dark' ? '#475569' : '#e5e7eb');
        closeBtn.style.borderRadius = '6px';
        closeBtn.style.cursor = 'pointer';
        closeBtn.style.fontSize = '12px';
        closeBtn.style.fontFamily = 'inherit';
        closeBtn.style.background = 'transparent';
        closeBtn.style.color = this.options.theme === 'dark' ? '#94a3b8' : '#64748b';
        closeBtn.addEventListener('click', function(e) {
            e.stopPropagation();
            self.close();
        });

        footer.appendChild(todayBtn);
        footer.appendChild(clearBtn);
        footer.appendChild(closeBtn);
        container.appendChild(footer);

        document.body.appendChild(container);
        this._pickerElement = container;
        this._titleSpan = titleSpan;

        if (!this.options.showTodayButton) todayBtn.style.display = 'none';
        if (!this.options.showClearButton) clearBtn.style.display = 'none';

        var mediaQuery = window.matchMedia('(max-width: 520px)');
        function handleResponsive(e) {
            if (e.matches) {
                mainWrapper.style.flexDirection = 'column';
                if (timeColumn) {
                    timeColumn.style.flex = '1 1 auto';
                    timeColumn.style.flexDirection = 'row';
                    timeColumn.style.flexWrap = 'wrap';
                    timeColumn.style.justifyContent = 'center';
                    timeColumn.style.borderRight = 'none';
                    timeColumn.style.borderLeft = 'none';
                    timeColumn.style.borderTop = '1px solid ' + (self.options.theme === 'dark' ? '#334155' : '#e5e7eb');
                    timeColumn.style.paddingTop = '10px';
                    timeColumn.style.paddingBottom = '4px';
                }
            } else {
                mainWrapper.style.flexDirection = 'row';
                if (timeColumn) {
                    timeColumn.style.flex = '0 0 110px';
                    timeColumn.style.flexDirection = 'column';
                    timeColumn.style.flexWrap = 'nowrap';
                    timeColumn.style.justifyContent = 'center';
                    timeColumn.style.borderRight = self.options.rtl ? 'none' : '1px solid ' + (self.options.theme === 'dark' ? '#334155' : '#e5e7eb');
                    timeColumn.style.borderLeft = self.options.rtl ? '1px solid ' + (self.options.theme === 'dark' ? '#334155' : '#e5e7eb') : 'none';
                    timeColumn.style.borderTop = 'none';
                    timeColumn.style.paddingTop = '0';
                    timeColumn.style.paddingBottom = '0';
                }
            }
        }
        if (mediaQuery.addEventListener) {
            mediaQuery.addEventListener('change', handleResponsive);
        } else {
            mediaQuery.addListener(handleResponsive);
        }
        handleResponsive(mediaQuery);
    };

    JalaliDatePicker.prototype._bindEvents = function() {
        var self = this;
        this.input.addEventListener('click', function(e) {
            e.stopPropagation();
            self.toggle();
        });

        this._pickerElement.addEventListener('mousedown', function(e) { e.preventDefault(); });
        this._pickerElement.addEventListener('click', function(e) { e.stopPropagation(); });

        document.addEventListener('click', function(e) {
            if (self.isOpen && !self._pickerElement.contains(e.target) && e.target !== self.input) {
                self.close();
            }
        });

        document.addEventListener('keydown', function(e) {
            if (e.key === 'Escape' && self.isOpen) self.close();
        });

        var reposition = function() {
            if (self.isOpen) self._positionPicker();
        };
        window.addEventListener('resize', reposition);
        window.addEventListener('scroll', reposition);

        if (this.options.withTime) {
            var timeChange = function() { self._updateSelectedTime(); };
            this.hourInput.addEventListener('change', timeChange);
            this.minuteInput.addEventListener('change', timeChange);
        }
    };

    JalaliDatePicker.prototype._positionPicker = function() {
        var rect = this.input.getBoundingClientRect();
        var picker = this._pickerElement;
        var pickerHeight = picker.offsetHeight || 350;
        var pickerWidth = picker.offsetWidth || 380;
        var spaceBelow = window.innerHeight - rect.bottom;
        var spaceAbove = rect.top;

        var left = rect.left;
        if (left + pickerWidth > window.innerWidth) left = window.innerWidth - pickerWidth - 10;
        if (left < 10) left = 10;

        var top;
        if (this.options.position === 'top') {
            top = rect.top - pickerHeight - 5;
        } else if (this.options.position === 'bottom') {
            top = rect.bottom + 5;
        } else {
            if (spaceBelow >= pickerHeight) {
                top = rect.bottom + 5;
            } else if (spaceAbove >= pickerHeight) {
                top = rect.top - pickerHeight - 5;
            } else {
                top = (window.innerHeight - pickerHeight) / 2;
            }
        }

        picker.style.left = left + 'px';
        picker.style.top = top + 'px';
    };

    JalaliDatePicker.prototype.toggle = function() {
        this.isOpen ? this.close() : this.open();
    };

    JalaliDatePicker.prototype.open = function() {
        if (this.isOpen) return;
        this.isOpen = true;
        this._pickerElement.style.display = 'block';
        this._positionPicker();

        if (this.selectedDate) {
            this.viewYear = this.selectedDate.year;
            this.viewMonth = this.selectedDate.month;
            if (this.options.withTime) {
                this.hourInput.value = this.selectedDate.hour || 0;
                this.minuteInput.value = this.selectedDate.minute || 0;
            }
        } else {
            var today = getTodayGregorian();
            var jToday = toJalaali(today.year, today.month, today.day);
            this.viewYear = jToday.year;
            this.viewMonth = jToday.month;
            if (this.options.withTime) {
                this.hourInput.value = today.hour || 0;
                this.minuteInput.value = today.minute || 0;
            }
        }
        this._render();
    };

    JalaliDatePicker.prototype.close = function() {
        if (!this.isOpen) return;
        this.isOpen = false;
        this._pickerElement.style.display = 'none';
    };

    JalaliDatePicker.prototype._changeMonth = function(delta) {
        this.viewMonth += delta;
        if (this.viewMonth > 12) {
            this.viewMonth = 1;
            this.viewYear++;
        } else if (this.viewMonth < 1) {
            this.viewMonth = 12;
            this.viewYear--;
        }
        this._render();
    };

    JalaliDatePicker.prototype._setValueFromInput = function() {
        var val = this.input.value;
        if (!val) {
            this.selectedDate = null;
            return;
        }
        var cleaned = toEnglishDigits(val);
        try {
            var parts = cleaned.split(' ');
            var datePart = parts[0];
            var timePart = parts.length > 1 ? parts[1] : null;
            var dateParts = datePart.split('/');
            if (dateParts.length === 3) {
                var year = parseInt(dateParts[0], 10);
                var month = parseInt(dateParts[1], 10);
                var day = parseInt(dateParts[2], 10);
                if (!isNaN(year) && !isNaN(month) && !isNaN(day) && year > 0 && month >= 1 && month <= 12 && day >= 1) {
                    var selected = { year: year, month: month, day: day };
                    if (timePart && this.options.withTime) {
                        var timeParts = timePart.split(':');
                        if (timeParts.length >= 2) {
                            var hour = parseInt(timeParts[0], 10);
                            var minute = parseInt(timeParts[1], 10);
                            if (!isNaN(hour) && !isNaN(minute)) {
                                selected.hour = hour;
                                selected.minute = minute;
                            }
                        }
                    }
                    this.selectedDate = selected;
                }
            }
        } catch (_) {
            this.selectedDate = null;
        }
    };

    JalaliDatePicker.prototype._updateSelectedTime = function() {
        if (!this.selectedDate) return;
        var hour = parseInt(this.hourInput.value, 10);
        var minute = parseInt(this.minuteInput.value, 10);
        if (!isNaN(hour) && !isNaN(minute) && hour >= 0 && hour < 24 && minute >= 0 && minute < 60) {
            this.selectedDate.hour = hour;
            this.selectedDate.minute = minute;
            this._updateInputValue();
        }
    };

    JalaliDatePicker.prototype._selectDate = function(year, month, day, hour, minute) {
        year = parseInt(year, 10);
        month = parseInt(month, 10);
        day = parseInt(day, 10);
        this.selectedDate = { year: year, month: month, day: day };
        if (this.options.withTime) {
            if (hour !== undefined && minute !== undefined) {
                this.selectedDate.hour = parseInt(hour, 10);
                this.selectedDate.minute = parseInt(minute, 10);
            } else {
                this.selectedDate.hour = parseInt(this.hourInput.value, 10) || 0;
                this.selectedDate.minute = parseInt(this.minuteInput.value, 10) || 0;
            }
            this.hourInput.value = this.selectedDate.hour;
            this.minuteInput.value = this.selectedDate.minute;
        }
        this._updateInputValue();
        if (this.options.closeOnSelect !== false) {
            this.close();
        }
    };

    JalaliDatePicker.prototype._updateInputValue = function() {
        if (!this.selectedDate) return;
        var d = this.selectedDate;
        var formatted = String(d.year).padStart(4, '0') + '/' +
                        String(d.month).padStart(2, '0') + '/' +
                        String(d.day).padStart(2, '0');
        if (this.options.withTime && d.hour !== undefined && d.minute !== undefined) {
            formatted += ' ' + String(d.hour).padStart(2, '0') + ':' + String(d.minute).padStart(2, '0');
        }
        this.input.value = formatted;
        var event = new Event('change', { bubbles: true });
        this.input.dispatchEvent(event);
    };

    JalaliDatePicker.prototype._selectToday = function() {
        var today = getTodayGregorian();
        var jToday = toJalaali(today.year, today.month, today.day);
        if (this.options.withTime) {
            this._selectDate(jToday.year, jToday.month, jToday.day, today.hour, today.minute);
        } else {
            this._selectDate(jToday.year, jToday.month, jToday.day);
        }
    };

    JalaliDatePicker.prototype._clearDate = function() {
        this.selectedDate = null;
        this.input.value = '';
        var event = new Event('change', { bubbles: true });
        this.input.dispatchEvent(event);
        this.close();
    };

    JalaliDatePicker.prototype._render = function() {
        var year = this.viewYear;
        var month = this.viewMonth;
        var monthNames = ['فروردین', 'اردیبهشت', 'خرداد', 'تیر', 'مرداد', 'شهریور',
                            'مهر', 'آبان', 'آذر', 'دی', 'بهمن', 'اسفند'];
        this._titleSpan.textContent = monthNames[month - 1] + ' ' + toPersianDigits(year);

        var daysInMonth = jalaliMonthDays(year, month);
        var firstDayGreg = toGregorian(year, month, 1);
        var firstDayDate = new Date(Date.UTC(firstDayGreg.year, firstDayGreg.month - 1, firstDayGreg.day));
        var weekday = firstDayDate.getUTCDay();
        var jWeekday = (weekday + 1) % 7;

        var grid = this._daysGrid;
        grid.innerHTML = '';

        for (var i = 0; i < jWeekday; i++) {
            var empty = document.createElement('div');
            empty.style.visibility = 'hidden';
            grid.appendChild(empty);
        }

        var today = getTodayGregorian();
        var jToday = toJalaali(today.year, today.month, today.day);
        var self = this;

        for (var d = 1; d <= daysInMonth; d++) {
            var cell = document.createElement('div');
            cell.style.textAlign = 'center';
            cell.style.padding = '4px 0';
            cell.style.borderRadius = '6px';
            cell.style.cursor = 'pointer';
            cell.style.fontSize = '14px';
            cell.style.color = this.options.theme === 'dark' ? '#e2e8f0' : '#1e293b';
            cell.style.transition = 'background 0.12s, transform 0.08s';
            cell.textContent = toPersianDigits(d);

            if (year === jToday.year && month === jToday.month && d === jToday.day) {
                cell.style.background = this.options.theme === 'dark' ? '#475569' : '#eef2ff';
                cell.style.color = this.options.theme === 'dark' ? '#ffffff' : '#4f46e5';
                cell.style.fontWeight = '600';
            }

            if (this.selectedDate &&
                this.selectedDate.year === year &&
                this.selectedDate.month === month &&
                this.selectedDate.day === d) {
                cell.style.background = '#4f46e5';
                cell.style.color = '#ffffff';
                cell.style.fontWeight = '600';
                cell.style.boxShadow = '0 2px 8px rgba(79,70,229,0.25)';
            }

            cell.addEventListener('mouseenter', function() {
                if (this.style.background !== '#4f46e5' && !this.classList.contains('selected')) {
                    this.style.background = self.options.theme === 'dark' ? '#334155' : '#f1f5f9';
                    this.style.transform = 'scale(1.05)';
                }
            });
            cell.addEventListener('mouseleave', function() {
                if (this.style.background !== '#4f46e5' && !this.classList.contains('selected')) {
                    this.style.background = '';
                    this.style.transform = 'scale(1)';
                }
            });

            (function(y, m, d) {
                cell.addEventListener('click', function(e) {
                    e.stopPropagation();
                    self._selectDate(y, m, d);
                });
            })(year, month, d);

            grid.appendChild(cell);
        }
    };

    JalaliDatePicker.prototype.destroy = function() {
        this.close();
        if (this._pickerElement && this._pickerElement.parentNode) {
            this._pickerElement.parentNode.removeChild(this._pickerElement);
        }
    };

    // ============================================================
    // 5. فعال‌سازی خودکار
    // ============================================================
    function initPickers() {
        try {
            var inputs = document.querySelectorAll('.edra-jalali-date-input, .edra-jalali-datetime-input, input[data-jalali="true"]');
            for (var i = 0; i < inputs.length; i++) {
                var input = inputs[i];
                if (!input._jalaliPicker) {
                    var options = {
                        withTime: input.dataset.datetime === 'true' || input.classList.contains('edra-jalali-datetime-input'),
                        closeOnSelect: true,
                        theme: input.dataset.theme || 'light',
                    };
                    var picker = new JalaliDatePicker(input, options);
                    input._jalaliPicker = picker;
                }
            }
        } catch (e) {
            console.error('JalaliDatePicker init error:', e);
        }
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', initPickers);
    } else {
        initPickers();
    }

    global.JalaliDatePicker = JalaliDatePicker;
    global.JalaliDateUtils = {
        toEnglishDigits: toEnglishDigits,
        toPersianDigits: toPersianDigits,
        isJalaliLeapYear: isJalaliLeapYear,
        jalaliMonthDays: jalaliMonthDays,
        toJalaali: toJalaali,
        toGregorian: toGregorian,
        getTodayGregorian: getTodayGregorian
    };

})(window);
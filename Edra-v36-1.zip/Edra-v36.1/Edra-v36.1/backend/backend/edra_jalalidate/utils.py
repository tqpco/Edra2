# edra_jalalidate/utils.py
# -*- coding: utf-8 -*-
"""
توابع کمکی برای کار با تاریخ جلالی در بک‌اند.
شامل تبدیل‌ها، محاسبه اختلاف، افزودن روز/ماه و ...
"""

import datetime
from typing import Optional, Union, List

from .jalali import JalaliDate, JalaliDateTime, to_jalali, get_jalali_today, get_jalali_now
from .ntp import get_accurate_datetime
from . import _jalali_core as core  # <-- ایمپورت core برای دسترسی به jalali_month_days


def to_gregorian_date(jalali_str: str, fmt: str = "%Y/%m/%d") -> datetime.date:
    """تبدیل رشته جلالی به تاریخ میلادی."""
    jd = JalaliDate.from_string(jalali_str, fmt)
    return jd.to_date()


def to_gregorian_datetime(jalali_str: str, fmt: str = "%Y/%m/%d %H:%M") -> datetime.datetime:
    """تبدیل رشته جلالی به datetime میلادی."""
    jdt = JalaliDateTime.from_string(jalali_str, fmt)
    return jdt.to_datetime()


def diff_days(date1: Union[JalaliDate, datetime.date], date2: Union[JalaliDate, datetime.date]) -> int:
    """
    اختلاف دو تاریخ به روز (مطلق).
    هر دو ورودی می‌توانند JalaliDate یا datetime.date باشند.
    """
    if isinstance(date1, datetime.date):
        date1 = JalaliDate.from_date(date1)
    if isinstance(date2, datetime.date):
        date2 = JalaliDate.from_date(date2)
    # تبدیل به تاریخ میلادی برای محاسبه اختلاف
    d1 = date1.to_date()
    d2 = date2.to_date()
    return abs((d1 - d2).days)


def add_days_to_jalali(date: JalaliDate, days: int) -> JalaliDate:
    """افزودن تعداد روز به تاریخ جلالی."""
    return date.add_days(days)


def add_months_to_jalali(date: JalaliDate, months: int) -> JalaliDate:
    """افزودن تعداد ماه به تاریخ جلالی (با تنظیم خودکار روز معتبر)."""
    return date.add_months(months)


def get_first_day_of_month(year: int, month: int) -> JalaliDate:
    """اولین روز ماه جلالی."""
    return JalaliDate(year, month, 1)


def get_last_day_of_month(year: int, month: int) -> JalaliDate:
    """
    آخرین روز ماه جلالی با احتساب کبیسه بودن سال.
    از تابع core.jalali_month_days برای محاسبه تعداد روز استفاده می‌کند.
    """
    max_day = core.jalali_month_days(year, month)
    return JalaliDate(year, month, max_day)


def get_jalali_date_range(start: JalaliDate, end: JalaliDate) -> List[JalaliDate]:
    """
    بازگرداندن لیست تمام تاریخ‌های جلالی بین دو تاریخ (شامل هر دو).
    اگر start > end باشد، به‌طور خودکار جابه‌جا می‌شوند.
    """
    if start > end:
        start, end = end, start
    current = start
    result = []
    while current <= end:
        result.append(current)
        current = current.add_days(1)
    return result


def is_valid_jalali_date(year: int, month: int, day: int) -> bool:
    """
    بررسی اعتبار یک تاریخ جلالی (سال، ماه، روز).
    در صورت معتبر بودن True و در غیر این‌صورت False برمی‌گرداند.
    """
    try:
        JalaliDate(year, month, day)
        return True
    except ValueError:
        return False


# ---------- توابع اضافی برای راحتی کار ----------
def to_jalali_str(dt: Union[datetime.datetime, datetime.date, None], fmt: str = "%Y/%m/%d") -> str:
    """تبدیل datetime/date میلادی به رشته جلالی (همان to_jalali ولی با مقدار پیش‌فرض)."""
    return to_jalali(dt, fmt)


def get_jalali_today_str(fmt: str = "%Y/%m/%d") -> str:
    """برگرداندن تاریخ امروز به صورت رشته جلالی."""
    return get_jalali_today().strftime(fmt)


def get_jalali_now_str(fmt: str = "%Y/%m/%d %H:%M") -> str:
    """برگرداندن زمان فعلی به صورت رشته جلالی."""
    return get_jalali_now().strftime(fmt)


def get_jalali_date_from_gregorian(year: int, month: int, day: int) -> JalaliDate:
    """ساخت تاریخ جلالی از سال/ماه/روز میلادی."""
    return JalaliDate.from_gregorian(year, month, day)


def get_jalali_datetime_from_gregorian(
    year: int,
    month: int,
    day: int,
    hour: int = 0,
    minute: int = 0,
    second: int = 0,
    microsecond: int = 0,
    tzinfo: Optional[datetime.tzinfo] = None
) -> JalaliDateTime:
    """ساخت تاریخ‌زمان جلالی از اجزای میلادی."""
    return JalaliDateTime.from_gregorian(year, month, day, hour, minute, second, microsecond, tzinfo)
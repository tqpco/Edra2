# edra_jalalidate/widgets.py
# -*- coding: utf-8 -*-

from django import forms
from django.utils import timezone
from django.utils.safestring import mark_safe

from .jalali import JalaliDate, JalaliDateTime
import datetime
import logging

logger = logging.getLogger(__name__)


class AdminjDateWidget(forms.DateInput):
    class Media:
        css = {'all': ('edra_jalalidate/css/jalali-datepicker.css',)}
        js = ('edra_jalalidate/js/jalali-datepicker.js',)

    def __init__(self, attrs=None, format=None):
        default_attrs = {
            'class': 'vDateField edra-jalali-date-input',
            'autocomplete': 'off',
            'dir': 'ltr',
            'data-jalali': 'true',
            'placeholder': '۱۴۰۴/۰۵/۱۲',
        }
        if attrs:
            default_attrs.update(attrs)
        super().__init__(attrs=default_attrs, format=format)

    def format_value(self, value):
        if value is None:
            return ''
        if isinstance(value, datetime.datetime):
            if timezone.is_naive(value):
                value = timezone.make_aware(value, datetime.timezone.utc)
            value = timezone.localtime(value)
        if isinstance(value, (datetime.datetime, datetime.date)):
            jd = JalaliDate.from_datetime(value)
            return jd.strftime('%Y/%m/%d')
        if isinstance(value, str):
            return value
        return str(value)

    def value_from_datadict(self, data, files, name):
        value = data.get(name)
        if not value:
            return None
        try:
            jd = JalaliDate.from_string(value.strip())
            return jd.to_date()
        except ValueError as e:
            logger.error(f"AdminjDateWidget parse error: {e}")
            return value


class AdminjDateTimeWidget(forms.DateTimeInput):
    class Media:
        css = {'all': ('edra_jalalidate/css/jalali-datepicker.css',)}
        js = ('edra_jalalidate/js/jalali-datepicker.js',)

    def __init__(self, attrs=None, format=None):
        default_attrs = {
            'class': 'vDateTimeField edra-jalali-datetime-input',
            'autocomplete': 'off',
            'dir': 'ltr',
            'data-jalali': 'true',
            'data-datetime': 'true',
            'placeholder': '۱۴۰۴/۰۵/۱۲ ۱۴:۳۰',
        }
        if attrs:
            default_attrs.update(attrs)
        super().__init__(attrs=default_attrs, format=format)

    def format_value(self, value):
        if value is None:
            return ''
        if isinstance(value, datetime.datetime):
            if timezone.is_naive(value):
                value = timezone.make_aware(value, datetime.timezone.utc)
            value = timezone.localtime(value)
            jdt = JalaliDateTime.from_datetime(value)
            return jdt.strftime('%Y/%m/%d %H:%M')
        if isinstance(value, str):
            return value
        return str(value)

    def value_from_datadict(self, data, files, name):
        value = data.get(name)
        if not value:
            return None
        try:
            jdt = JalaliDateTime.from_string(value.strip())
            dt = jdt.to_datetime()
            # ✅ اضافه کردن منطقه زمانی تهران
            dt = timezone.make_aware(dt, timezone.get_current_timezone())
            return dt
        except ValueError as e:
            logger.error(f"AdminjDateTimeWidget parse error: {e}")
            return value


class AdminjDateTimeSeparateWidget(forms.MultiWidget):
    """
    ویجت تاریخ و ساعت جلالی با دو بخش کاملاً مجزا
    ✅ اصلاح شده با پشتیبانی از منطقه زمانی Tehran
    """
    class Media:
        css = {'all': ('edra_jalalidate/css/jalali-datepicker.css',)}
        js = ('edra_jalalidate/js/jalali-datepicker.js',)

    def __init__(self, attrs=None):
        self.date_attrs = {
            'class': 'vDateField edra-jalali-date-input',
            'autocomplete': 'off',
            'dir': 'ltr',
            'data-jalali': 'true',
            'placeholder': '۱۴۰۴/۰۵/۱۲',
            'style': 'width:120px; padding-left:28px;',
        }
        self.time_attrs = {
            'class': 'vTimeField edra-jalali-time-input',
            'autocomplete': 'off',
            'dir': 'ltr',
            'type': 'time',
            'placeholder': '۱۴:۳۰',
            'style': 'width:80px; padding-left:28px;',
        }
        if attrs:
            self.date_attrs.update(attrs)
            self.time_attrs.update(attrs)
        
        widgets = (
            forms.TextInput(attrs=self.date_attrs),
            forms.TimeInput(attrs=self.time_attrs, format='%H:%M'),
        )
        super().__init__(widgets, attrs)

    def decompress(self, value):
        """
        تبدیل مقدار میلادی ذخیره‌شده به دو بخش تاریخ و ساعت جلالی
        """
        if value:
            if isinstance(value, datetime.datetime):
                # اگر timezone-aware نباشد، آن را UTC در نظر بگیر
                if timezone.is_naive(value):
                    value = timezone.make_aware(value, datetime.timezone.utc)
                # تبدیل به منطقه زمانی محلی (تهران)
                value = timezone.localtime(value)
                jd = JalaliDate.from_datetime(value)
                return [jd.strftime('%Y/%m/%d'), value.strftime('%H:%M')]
            elif isinstance(value, str):
                try:
                    parts = value.split(' ')
                    if len(parts) == 2:
                        return [parts[0], parts[1]]
                    return [value, '']
                except:
                    return [value, '']
        return [None, None]

    def format_value(self, value):
        if value is None:
            return [None, None]
        return self.decompress(value)

    def value_from_datadict(self, data, files, name):
        date_value = data.get(f'{name}_0')
        time_value = data.get(f'{name}_1')
        
        # اگر هر دو خالی باشند، None برگردان
        if not date_value and not time_value:
            return None
        
        # اگر فقط تاریخ وارد شده، ساعت را 00:00 در نظر بگیر
        if date_value and not time_value:
            time_value = '00:00'
        
        # اگر فقط ساعت وارد شده، تاریخ امروز را در نظر بگیر
        if time_value and not date_value:
            from .jalali import get_jalali_today
            today = get_jalali_today()
            date_value = str(today)
        
        try:
            # تبدیل تاریخ جلالی به میلادی
            jd = JalaliDate.from_string(date_value.strip())
            greg_date = jd.to_date()
            
            # تجزیه ساعت و دقیقه
            time_parts = time_value.strip().split(':')
            hour = int(time_parts[0]) if len(time_parts) > 0 else 0
            minute = int(time_parts[1]) if len(time_parts) > 1 else 0
            
            # ساخت datetime (naive)
            dt = datetime.datetime(
                greg_date.year,
                greg_date.month,
                greg_date.day,
                hour,
                minute
            )
            
            # ✅ اضافه کردن منطقه زمانی تهران قبل از بازگشت
            dt = timezone.make_aware(dt, timezone.get_current_timezone())
            return dt
            
        except Exception as e:
            logger.error(f"AdminjDateTimeSeparateWidget parse error: {e}")
            return None

    def render(self, name, value, attrs=None, renderer=None):
        if value is not None:
            values = self.decompress(value)
        else:
            values = [None, None]
        
        date_html = f'''
        <div style="display:inline-block; position:relative; margin-right:5px;">
            <span style="position:absolute; left:5px; top:50%; transform:translateY(-50%); font-size:16px; pointer-events:none; z-index:1;">📅</span>
            <input type="text" name="{name}_0" value="{values[0] or ''}" class="{self.date_attrs.get('class', '')}" 
                   style="{self.date_attrs.get('style', '')}" 
                   placeholder="{self.date_attrs.get('placeholder', '')}" 
                   autocomplete="off" dir="ltr" data-jalali="true">
        </div>
        '''
        
        time_html = f'''
        <div style="display:inline-block; position:relative;">
            <span style="position:absolute; left:5px; top:50%; transform:translateY(-50%); font-size:16px; pointer-events:none; z-index:1;">🕐</span>
            <input type="time" name="{name}_1" value="{values[1] or ''}" class="{self.time_attrs.get('class', '')}" 
                   style="{self.time_attrs.get('style', '')}" 
                   placeholder="{self.time_attrs.get('placeholder', '')}" 
                   autocomplete="off" dir="ltr">
        </div>
        '''
        
        return mark_safe(f'<div style="display:flex; gap:8px; align-items:center; flex-wrap:wrap;">{date_html}{time_html}</div>')
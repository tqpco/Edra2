# gunicorn.conf.py  (EDRA v32)
#
# سرویس HTTP/REST (WSGI) با worker از نوع gthread.
# چرا نه uvicorn/ASGI برای HTTP؟ view های DRF این پروژه sync هستند و زیر
# ASGI جنگو آن‌ها را با sync_to_async(thread_sensitive=True) اجرا می‌کند؛ یعنی
# در هر پروسه فقط «یک» درخواست sync در لحظه اجرا می‌شود (۵ worker = ۵
# درخواست همزمان؛ یک PDF/اکسل ۳ ثانیه‌ای یک worker را کامل قفل می‌کند).
# با gthread هر worker چند thread دارد: ظرفیت = workers × threads.
#
# WebSocket اعلان‌ها روی سرویس جدا (backend-ws، uvicorn) می‌ماند.
import os

bind = os.environ.get("GUNICORN_BIND", "0.0.0.0:8000")
worker_class = "gthread"
workers = int(os.environ.get("GUNICORN_WORKERS", "4"))
threads = int(os.environ.get("GUNICORN_THREADS", "8"))

# هر thread یک اتصال دیتابیس نگه می‌دارد (CONN_MAX_AGE):
# اتصال‌ها ≈ workers × threads (پیش‌فرض ۳۲) — باید از max_connections
# پستگرس (در compose روی ۲۰۰) خیلی کمتر بماند.
timeout = int(os.environ.get("GUNICORN_TIMEOUT", "60"))
graceful_timeout = 30
keepalive = 30
max_requests = 2000
max_requests_jitter = 200

# heartbeat روی RAM (در کانتینر، دیسک کند/overlay باعث timeout کاذب می‌شود)
worker_tmp_dir = "/dev/shm"

# لاگ‌ها روی stdout/stderr تا `docker logs` کار کند
accesslog = "-"
errorlog = "-"
loglevel = os.environ.get("GUNICORN_LOG_LEVEL", "info")

# inspections/models.py
"""
مدل‌های اپلیکیشن inspections

توجه: تمام مدل‌های مربوط به چک‌لیست، گزارش بازرسی، عکس‌ها و تأییدیه‌ها در
core/models/checklist.py قرار دارند. این فایل فقط به‌عنوان placeholder برای
ساختار اپلیکیشن inspections نگهداری می‌شود تا مهاجرت‌ها و تنظیمات به‌درستی
کار کنند.
"""

from django.db import models
from django.contrib.auth import get_user_model

User = get_user_model()

# ============================================================
# تمام مدل‌های اصلی بازرسی در core/models.py تعریف شده‌اند
# ============================================================
# مدل‌های زیر در core/models/checklist.py قرار دارند:
#   - ChecklistTemplate
#   - ChecklistItem
#   - InspectionReport
#   - ChecklistPhoto
#   - ReportVerification
#
# این فایل فقط برای یکپارچگی اپلیکیشن inspections نگهداری می‌شود.
# ============================================================
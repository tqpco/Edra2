# backend/inspections/serializers.py
from rest_framework import serializers
from django.utils import timezone
from core.models import (
    InspectionRequest, ChecklistTemplate, ChecklistItem,
    InspectionReport, ReportVerification, EquipmentType
)
# ✅ استفاده از to_jalali از پکیج edra_jalalidate
from edra_jalalidate import to_jalali


class EquipmentTypeSerializer(serializers.ModelSerializer):
    class Meta:
        model = EquipmentType
        fields = ('id', 'code', 'name_fa', 'param_schema')


class InspectionRequestSerializer(serializers.ModelSerializer):
    equipment_type_detail = EquipmentTypeSerializer(
        source='equipment_type', read_only=True)

    class Meta:
        model = InspectionRequest
        fields = '__all__'
        read_only_fields = (
            'customer',
            'calculated_price',
            'final_price',
            'status',
            'created_at',
            'updated_at')


class CategoryNameField(serializers.Field):
    """
    EDRA v34 — ChecklistItem.category در دیتابیس FK به ChecklistCategory است
    ولی قرارداد API/فرانت‌اند «نام دسته‌بندی» (رشته) است. قبلاً ModelSerializer
    شناسه‌ی عددی برمی‌گرداند (فرانت دسته را «۳» نشان می‌داد) و هنگام نوشتن رشته
    را به PrimaryKeyRelatedField می‌داد (خطای ۴۰۰؛ و در validate_category
    AttributeError/۵۰۰).
    خواندن: name؛ نوشتن: get_or_create بر اساس نام (حداکثر ۱۰۰ کاراکتر).
    """
    default_error_messages = {
        'required': 'دسته‌بندی الزامی است.',
        'blank': 'دسته‌بندی الزامی است.',
        'null': 'دسته‌بندی الزامی است.',
        'too_long': 'دسته‌بندی نباید بیشتر از ۱۰۰ کاراکتر باشد.',
        'invalid': 'دسته‌بندی نامعتبر است.',
    }

    def to_representation(self, value):
        return value.name if value is not None else ''

    def get_attribute(self, instance):
        return getattr(instance, 'category', None)

    def to_internal_value(self, data):
        import unicodedata
        if not isinstance(data, str):
            self.fail('invalid')
        name = unicodedata.normalize('NFC', data).strip()
        if not name:
            self.fail('blank')
        if len(name) > 100:
            self.fail('too_long')
        from core.models import ChecklistCategory
        category, _ = ChecklistCategory.objects.get_or_create(name=name)
        return category


class ChecklistItemSerializer(serializers.ModelSerializer):
    """EDRA v5 (MEDIUM-34): فیلدهای صریح (نه __all__)."""
    category = CategoryNameField(read_only=True)

    class Meta:
        model = ChecklistItem
        fields = (
            'id', 'category', 'title', 'description', 'order',
            'requires_photo', 'requires_note', 'is_critical', 'is_active')


class ChecklistItemWriteSerializer(serializers.ModelSerializer):
    """
    EDRA v25: نسخه‌ی قابل‌نوشتن سریالایزر آیتم چک‌لیست — برای CRUD کامل
    تک‌آیتمی (افزودن/ویرایش/حذف یک آیتم) در بخش «مدیریت آیتم‌های چک‌لیست»،
    برخلاف ChecklistItemSerializer بالا که فقط برای نمایش تودرتو
    (read_only) داخل ChecklistTemplateSerializer و اکشن import/preview
    استفاده می‌شود.

    checklist_template این‌جا قابل‌نوشتن است تا بشود یک آیتم مستقیماً برای
    یک قالب مشخص ساخت.
    """
    category = CategoryNameField()

    class Meta:
        model = ChecklistItem
        fields = (
            'id', 'checklist_template', 'category', 'title', 'description',
            'order', 'requires_photo', 'requires_note', 'is_critical',
            'is_active')

    def validate_title(self, value):
        value = (value or '').strip()
        if not value:
            raise serializers.ValidationError('عنوان الزامی است.')
        return value

    def validate(self, attrs):
        # UniqueConstraint(template, category, title) — پیام فارسی به‌جای ۵۰۰
        template = attrs.get(
            'checklist_template',
            getattr(self.instance, 'checklist_template', None))
        category = attrs.get(
            'category', getattr(self.instance, 'category', None))
        title = attrs.get('title', getattr(self.instance, 'title', None))
        if template is not None and title is not None:
            qs = ChecklistItem.objects.filter(
                checklist_template=template, category=category, title=title)
            if self.instance is not None:
                qs = qs.exclude(pk=self.instance.pk)
            if qs.exists():
                raise serializers.ValidationError(
                    {'title': 'آیتمی با همین عنوان در همین دسته‌بندی وجود دارد.'})
        return attrs


class ChecklistTemplateSerializer(serializers.ModelSerializer):
    """
    EDRA v5 (MEDIUM-26): فیلدهای صریح + items_count برای جلوگیری از N+1
    در صفحه ادمین (لیست قالب‌ها بدون دریافت nested items).
    """
    items = ChecklistItemSerializer(many=True, read_only=True)
    items_count = serializers.SerializerMethodField()
    created_at_jalali = serializers.SerializerMethodField()
    updated_at_jalali = serializers.SerializerMethodField()

    class Meta:
        model = ChecklistTemplate
        fields = (
            'id', 'name', 'description', 'version', 'equipment_type',
            'is_active', 'items', 'items_count',
            'created_at_jalali', 'updated_at_jalali')

    def get_items_count(self, obj):
        return obj.items.filter(is_active=True).count()

    def get_created_at_jalali(self, obj):
        return to_jalali(obj.created_at)

    def get_updated_at_jalali(self, obj):
        return to_jalali(obj.updated_at)


class InspectionReportSerializer(serializers.ModelSerializer):
    """
    EDRA v5 — CRITICAL-09: فیلدهای صریح (نه __all__). برای خواندن/لیست.
    تغییرات فقط از طریق submit_results / sign_report انجام می‌شود، نه PATCH عمومی.
    """
    inspection_request_detail = InspectionRequestSerializer(
        source='inspection_request', read_only=True)
    overall_result_display = serializers.SerializerMethodField()
    created_at_jalali = serializers.SerializerMethodField()
    updated_at_jalali = serializers.SerializerMethodField()
    signed_at_jalali = serializers.SerializerMethodField()

    class Meta:
        model = InspectionReport
        fields = (
            'id', 'inspection_request', 'inspection_request_detail',
            'report_number', 'checklist_template_version', 'results',
            'overall_result', 'overall_result_display', 'inspector_notes',
            'gps_start_lat', 'gps_start_lng', 'gps_end_lat', 'gps_end_lng',
            'gps_distance_meters', 'inspection_started_at',
            'inspection_ended_at', 'pdf_file', 'signed_pdf_file',
            'signature_hash', 'signed_by', 'signed_at', 'signed_at_jalali',
            'created_at', 'created_at_jalali', 'updated_at',
            'updated_at_jalali')
        read_only_fields = fields

    def get_overall_result_display(self, obj):
        return obj.get_overall_result_display() if obj.overall_result else None

    def get_created_at_jalali(self, obj):
        return to_jalali(obj.created_at)

    def get_updated_at_jalali(self, obj):
        return to_jalali(obj.updated_at)

    def get_signed_at_jalali(self, obj):
        return to_jalali(obj.signed_at)


class CustomerInspectionReportSerializer(serializers.ModelSerializer):
    """
    EDRA v34 — نمای مشتری از گزارش. قبلاً مشتری (از طریق
    core.serializers.InspectionReportSerializer با fields='__all__') مختصات GPS
    کارشناس، هش امضا، شناسه‌ی کاربران و کل درخواست تو در تو را می‌گرفت.
    """
    request_number = serializers.CharField(
        source='inspection_request.request_number', read_only=True)
    equipment_name = serializers.CharField(
        source='inspection_request.equipment_type.name_fa', read_only=True)
    overall_result_display = serializers.SerializerMethodField()
    created_at_jalali = serializers.SerializerMethodField()
    signed_at_jalali = serializers.SerializerMethodField()
    pdf_ready = serializers.SerializerMethodField()
    pdf_file = serializers.SerializerMethodField()
    verification_code = serializers.SerializerMethodField()

    class Meta:
        model = InspectionReport
        fields = (
            'id', 'inspection_request', 'request_number', 'equipment_name',
            'report_number', 'overall_result', 'overall_result_display',
            'results', 'inspector_notes', 'pdf_ready', 'pdf_file',
            'signed_at', 'signed_at_jalali', 'verification_code',
            'created_at', 'created_at_jalali')
        read_only_fields = fields

    def get_overall_result_display(self, obj):
        return obj.get_overall_result_display() if obj.overall_result else None

    def get_created_at_jalali(self, obj):
        return to_jalali(obj.created_at)

    def get_signed_at_jalali(self, obj):
        return to_jalali(obj.signed_at) if obj.signed_at else None

    def get_pdf_ready(self, obj):
        return bool(obj.signed_pdf_file or obj.pdf_file)

    def get_pdf_file(self, obj):
        # مسیر خام storage لو نمی‌رود؛ فقط نشانه‌ی وجود فایل (دانلود از
        # endpoint محافظت‌شده‌ی /pdf/ انجام می‌شود).
        f = obj.signed_pdf_file or obj.pdf_file
        return f.name if f else None

    def get_verification_code(self, obj):
        v = getattr(obj, 'verification', None)
        return v.verification_code if v else None


class InspectionReportUpdateSerializer(serializers.ModelSerializer):
    """
    EDRA v5 — CRITICAL-09: serializer محدود برای update/partial_update.
    فقط یادداشت کارشناس قابل ویرایش است؛ بقیه فقط از سرویس/اکشن‌ها.
    """
    class Meta:
        model = InspectionReport
        fields = ('inspector_notes',)


class ReportVerificationSerializer(serializers.ModelSerializer):
    report_number = serializers.CharField(
        source='report.report_number', read_only=True)
    inspection_request_id = serializers.IntegerField(
        source='report.inspection_request.id', read_only=True)
    equipment_name = serializers.CharField(
        source='report.inspection_request.equipment_type.name_fa',
        read_only=True)
    overall_result = serializers.CharField(
        source='report.overall_result', read_only=True)
    signed_at = serializers.DateTimeField(
        source='report.signed_at', read_only=True)
    created_at_jalali = serializers.SerializerMethodField()
    last_viewed_at_jalali = serializers.SerializerMethodField()

    class Meta:
        model = ReportVerification
        fields = (
            'verification_code',
            'report_number',
            'inspection_request_id',
            'equipment_name',
            'overall_result',
            'signed_at',
            'view_count',
            'last_viewed_at',
            'created_at_jalali',
            'last_viewed_at_jalali')

    def get_created_at_jalali(self, obj):
        return to_jalali(obj.created_at)

    def get_last_viewed_at_jalali(self, obj):
        return to_jalali(obj.last_viewed_at)
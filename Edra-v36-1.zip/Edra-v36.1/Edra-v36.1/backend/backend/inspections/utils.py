import hashlib
import secrets
import string
from django.db import transaction
from django.utils import timezone
from django.core.files.base import ContentFile
from django.conf import settings
from core.models import SequenceCounter, ReportVerification
import logging

# ✅ ایمپورت با alias برای جلوگیری از تداخل نام
from edra_jalalidate import to_jalali as _to_jalali

logger = logging.getLogger(__name__)


def generate_report_number(equipment_code=None):
    """
    EDRA v34: شماره‌گذاری واحد (REP-سال-شمارنده) — قبلاً این تابع قالب
    <کد تجهیز>-سال-NNN می‌ساخت و مسیر دیگر REP-… (دو قالب برای یک موجودیت).
    پارامتر equipment_code فقط برای سازگاری حفظ شده است.
    """
    from core.services.report_service import next_report_number
    with transaction.atomic():
        return next_report_number()


def generate_verification_code(report_number):
    chars = string.ascii_uppercase + string.digits
    code = ''.join(secrets.choice(chars) for _ in range(12))
    while ReportVerification.objects.filter(verification_code=code).exists():
        code = ''.join(secrets.choice(chars) for _ in range(12))
    return code


def to_jalali(date):
    """
    تبدیل datetime به رشته جلالی با فرمت پیش‌فرض.
    اگر ورودی None باشد، None برگردانده می‌شود (سازگار با کدهای قبلی).
    """
    if not date:
        return None
    # فراخوانی تابع اصلی از edra_jalalidate
    return _to_jalali(date)


def generate_pdf_report(report, request=None):
    try:
        from core.report_pdf_generator import generate_report_pdf as core_generate_pdf
        from core.models import InspectionReport

        inspection_request = report.inspection_request
        customer = inspection_request.customer
        equipment = inspection_request.equipment_type
        checklist_items = report.results if report.results else []

        pdf_content = core_generate_pdf(
            report=report,
            inspection_request=inspection_request,
            customer=customer,
            equipment=equipment,
            checklist_items=checklist_items
        )

        filename = f"report_{report.report_number}.pdf"
        report.pdf_file.save(filename, ContentFile(pdf_content), save=True)
        report.save()
        logger.info(f"PDF generated for report {report.report_number}")
        return True
    except Exception as e:
        logger.error(f"Error generating PDF for report {report.id}: {e}")
        raise


def sign_pdf_with_pyhanko(pdf_content, cert_path=None, key_path=None, key_password=None):
    cert_path = cert_path or getattr(settings, 'PDF_SIGN_CERT_PATH', None)
    key_path = key_path or getattr(settings, 'PDF_SIGN_KEY_PATH', None)
    key_password = key_password or getattr(
        settings, 'PDF_SIGN_KEY_PASSWORD', None) or None

    if not (cert_path and key_path):
        logger.warning(
            "PDF digital signature NOT applied: certificate/key not configured "
            "(set PDF_SIGN_CERT_PATH and PDF_SIGN_KEY_PATH in settings). "
            "Returning unsigned content; signature_hash covers integrity only.")
        return pdf_content

    try:
        import io

        from pyhanko.pdf_utils.incremental_writer import IncrementalPdfFileWriter
        from pyhanko.sign import sign_pdf, signers
        from pyhanko.sign.fields import SigFieldSpec

        signer = signers.SimpleSigner.load(
            key_file=key_path,
            cert_file=cert_path,
            key_passphrase=key_password,
        )
        writer = IncrementalPdfFileWriter(io.BytesIO(pdf_content))
        out = io.BytesIO()
        sign_pdf(
            writer,
            signature_meta=signers.PdfSignatureMetadata(
                field_name='EDRA_Signature',
                name='EDRA Inspection Platform',
                reason='تأیید رسمی گزارش بازرسی',
            ),
            signer=signer,
            output=out,
            new_field_spec=SigFieldSpec(
                'EDRA_Signature',
                box=(430, 40, 570, 90),
            ),
        )
        signed_content = out.getvalue()
        logger.info(
            "PDF digitally signed (PAdES) with certificate %s", cert_path)
        return signed_content
    except Exception as e:
        logger.error(f"PDF digital signature failed: {e}")
        raise
# ============================================================
# inspections/views.py (اصلاح شده نهایی)
# ============================================================
from rest_framework import viewsets, status, generics, serializers
from rest_framework.decorators import action
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated, AllowAny
from rest_framework.throttling import ScopedRateThrottle
from core.permissions import (
    IsAdminOrExpert, IsAdminUserOrGroup, is_admin_user, is_expert_user)
from core.services.inspection_service import EXPERT_EXECUTABLE_STATUSES
from django.db import models, transaction
from django.utils import timezone
from django.shortcuts import get_object_or_404
from django.core.exceptions import PermissionDenied
from django.conf import settings
from core.validators import validate_excel_file

from django.http import HttpResponse
from core.models import (
    InspectionRequest, ChecklistTemplate, ChecklistItem,
    InspectionReport, SequenceCounter, ReportVerification
)
from core.tasks import generate_report_pdf_task
from .utils import generate_verification_code
# ✅ حذف to_jalali از utils و استفاده از edra_jalalidate
from edra_jalalidate import to_jalali
from .serializers import (
    InspectionReportSerializer,
    InspectionReportUpdateSerializer,
    CustomerInspectionReportSerializer,
    ChecklistTemplateSerializer,
    ChecklistItemSerializer,
    ChecklistItemWriteSerializer,
    EquipmentTypeSerializer,
    ReportVerificationSerializer,
    InspectionRequestSerializer as InspectionsRequestSerializer,
)
import logging

logger = logging.getLogger(__name__)

# ============================================================
# ویوهای کارشناس
# ============================================================


class ExpertQueueViewSet(viewsets.ReadOnlyModelViewSet):
    """صف بازرسی‌های تخصیص‌یافته به کارشناس"""
    serializer_class = InspectionsRequestSerializer
    permission_classes = [IsAuthenticated]

    def get_queryset(self):
        # فقط درخواست‌هایی که به این کارشناس تخصیص داده شده‌اند
        return InspectionRequest.objects.filter(
            assigned_expert=self.request.user,
            status__in=EXPERT_EXECUTABLE_STATUSES
        ).select_related('equipment_type', 'customer').order_by('scheduled_at')


class ChecklistTemplateViewSet(viewsets.ModelViewSet):
    """
    مدیریت قالب‌های چک‌لیست (مشاهده برای ادمین/کارشناس؛ ایجاد/ویرایش/حذف
    فقط ادمین).

    EDRA v25 — root-cause: قبلاً ReadOnlyModelViewSet بود، یعنی هیچ راهی
    برای ساخت/ویرایش/حذف قالب از طریق API وجود نداشت (فقط از طریق پنل
    ادمین جنگو). این خودِ یکی از دلایل اصلی درخواست «بازنویسی کامل بخش
    آیتم‌های چک‌لیست» بود.
    """
    serializer_class = ChecklistTemplateSerializer
    permission_classes = [IsAdminOrExpert]

    def get_queryset(self):
        base = ChecklistTemplate.objects.select_related(
            'equipment_type').prefetch_related(
            models.Prefetch(
                'items',
                queryset=ChecklistItem.objects.select_related(
                    'category').order_by('category__order', 'order', 'id')))
        user = self.request.user
        is_admin = user.is_authenticated and is_admin_user(user)
        # کارشناس فقط قالب‌های فعال را می‌بیند (برای انجام بازرسی)؛ ادمین
        # برای مدیریت باید غیرفعال‌ها را هم ببیند و بتواند دوباره فعال کند.
        if is_admin:
            return base.order_by('-is_active', 'name')
        return base.filter(is_active=True).order_by('name')

    def get_permissions(self):
        # نوشتن (ساخت/ویرایش/حذف قالب یا آیتم‌هایش) فقط برای ادمین
        if self.action in (
                'create', 'update', 'partial_update', 'destroy',
                'reorder_items'):
            return [IsAdminUserOrGroup()]
        return super().get_permissions()

    def perform_destroy(self, instance):
        # حذف نرم: قالب‌هایی که قبلاً در بازرسی واقعی استفاده شده‌اند نباید
        # کامل از دیتابیس پاک شوند (گزارش‌های قبلی به آن‌ها ارجاع دارند)،
        # پس destroy فقط غیرفعال می‌کند.
        instance.is_active = False
        instance.save(update_fields=['is_active'])

    @action(detail=True, methods=['get'])
    def items(self, request, pk=None):
        """دریافت آیتم‌های یک چک‌لیست"""
        template = self.get_object()
        items = template.items.filter(is_active=True).select_related(
            'category').order_by('category__order', 'order', 'id')
        serializer = ChecklistItemSerializer(items, many=True)
        return Response(serializer.data)

    @action(detail=True, methods=['post'],
            permission_classes=[IsAdminUserOrGroup],
            url_path='reorder-items')
    def reorder_items(self, request, pk=None):
        """
        EDRA v25: تغییر ترتیب آیتم‌ها (دکمه‌های بالا/پایین در UI مدیریت).
        POST body: {"order": [{"id": 1, "order": 0}, {"id": 2, "order": 1}, ...]}
        فقط آیتم‌های متعلق به همین قالب مجازند (جلوگیری از دستکاری قالب دیگر).
        """
        template = self.get_object()
        order_list = request.data.get('order')
        if not isinstance(order_list, list) or not order_list:
            return Response(
                {'error': 'فیلد order باید لیستی از {id, order} باشد.'},
                status=400)

        valid_ids = set(template.items.values_list('id', flat=True))
        updates = []
        for entry in order_list:
            try:
                item_id = int(entry.get('id'))
                new_order = int(entry.get('order'))
            except (TypeError, ValueError, AttributeError):
                return Response(
                    {'error': 'هر ورودی order باید شامل id و order عددی باشد.'},
                    status=400)
            if item_id not in valid_ids:
                return Response(
                    {'error': f'آیتم {item_id} متعلق به این قالب نیست.'},
                    status=400)
            updates.append((item_id, new_order))

        with transaction.atomic():
            for item_id, new_order in updates:
                ChecklistItem.objects.filter(id=item_id).update(order=new_order)

        items = template.items.filter(is_active=True).select_related(
            'category').order_by('category__order', 'order', 'id')
        return Response(ChecklistItemSerializer(items, many=True).data)

    # ============================================================
    # FEATURE: ایمپورت آیتم‌های چک‌لیست از فایل Excel
    # ============================================================
    # ستون‌های موردانتظار فایل Excel (ردیف اول = هدرها)
    EXCEL_COLUMNS = {
        'category': 'دسته‌بندی',
        'title': 'عنوان',
        'description': 'توضیحات',
        'order': 'ترتیب',
        'requires_photo': 'نیاز به عکس',
        'requires_note': 'نیاز به یادداشت',
        'is_critical': 'نیاز حیاتی',   # اختیاری (HIGH-46)
    }
    MAX_IMPORT_ROWS = 500

    @action(detail=True, methods=['get'],
            permission_classes=[IsAdminUserOrGroup],
            url_path='import-template')
    def import_template(self, request, pk=None):
        """
        دانلود قالب Excel نمونه برای ایمپورت آیتم‌های چک‌لیست.
        GET /api/inspections/checklist-templates/{id}/import-template/
        """
        template = self.get_object()
        from openpyxl import Workbook
        from openpyxl.styles import Font, PatternFill, Alignment

        wb = Workbook()
        ws = wb.active
        ws.title = 'آیتم‌های چک‌لیست'
        ws.sheet_view.rightToLeft = True

        header_fill = PatternFill(
            start_color='1F2937', end_color='1F2937', fill_type='solid')
        header_font = Font(color='FFFFFF', bold=True, size=11)

        headers = list(self.EXCEL_COLUMNS.values())
        for col_idx, header in enumerate(headers, start=1):
            cell = ws.cell(row=1, column=col_idx, value=header)
            cell.fill = header_fill
            cell.font = header_font
            cell.alignment = Alignment(horizontal='center')

        # ردیف نمونه برای راهنمایی کاربر (ستون «نیاز حیاتی» اختیاری است)
        sample_row = [
            'سازه فلزی', 'بررسی سلامت جوش‌های اتصال', 'تست بصری جوش‌ها',
            1, 'بله', 'خیر', 'بله',
        ]
        for col_idx, value in enumerate(sample_row, start=1):
            ws.cell(row=2, column=col_idx, value=value)

        # عرض ستون‌ها
        for col_idx, header in enumerate(headers, start=1):
            ws.column_dimensions[
                chr(64 + col_idx)].width = max(len(header) + 4, 18)

        response = HttpResponse(
            content_type='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')
        filename = f'checklist_items_template_{template.id}.xlsx'
        response['Content-Disposition'] = f'attachment; filename="{filename}"'
        wb.save(response)
        return response

    @action(detail=True, methods=['post'],
            permission_classes=[IsAdminUserOrGroup],
            url_path='import-items')
    def import_items(self, request, pk=None):
        """
        ایمپورت آیتم‌های چک‌لیست از فایل Excel.
        POST /api/inspections/checklist-templates/{id}/import-items/
          (multipart/form-data با فیلد file)
        POST .../import-items/?preview=true  → فقط پیش‌نمایش، بدون ذخیره

        ستون‌ها (ردیف اول): دسته‌بندی | عنوان | توضیحات | ترتیب |
        نیاز به عکس | نیاز به یادداشت
        """
        template = self.get_object()
        preview = request.query_params.get('preview') in ('1', 'true', 'True')
        # EDRA v5 — HIGH-19: mode=replace آیتم‌های فعال قبلی را در همان
        # transaction حذف می‌کند (جلوگیری از duplicate با ایمپورت دوباره).
        mode = request.query_params.get('mode', 'append')
        if mode not in ('append', 'replace'):
            return Response({'error': 'mode باید append یا replace باشد.'},
                            status=400)

        uploaded = request.FILES.get('file')
        if not uploaded:
            return Response({'error': 'فایل Excel ارسال نشده است.'}, status=400)

        file_error = validate_excel_file(uploaded)
        if file_error:
            return Response({'error': file_error}, status=400)

        try:
            from openpyxl import load_workbook
            wb = load_workbook(uploaded, data_only=True)
        except Exception:
            return Response(
                {'error': 'فایل Excel قابل خواندن نیست.'}, status=400)

        ws = wb.active
        rows = list(ws.iter_rows(values_only=True))
        if len(rows) < 2:
            return Response(
                {'error': 'فایل حداقل باید یک ردیف هدر و یک ردیف داده داشته باشد.'},
                status=400)

        # نرمال‌سازی هدرها (پشتیبانی از نام‌های فارسی و انگلیسی)
        header_row = rows[0]
        col_map = {}  # index → normalized key
        for idx, raw in enumerate(header_row):
            if raw is None:
                continue
            normalized = str(raw).strip().replace(' ', '').lower()
            for key, fa_name in self.EXCEL_COLUMNS.items():
                fa_norm = fa_name.replace(' ', '').lower()
                if (normalized == fa_name or normalized == fa_norm
                        or normalized == key
                        or normalized == key.replace('_', '')):
                    col_map[idx] = key
                    break

        required = {'category', 'title'}
        missing = required - set(col_map.values())
        if missing:
            fa_missing = [self.EXCEL_COLUMNS[m] for m in sorted(missing)]
            return Response({
                'error': f'ستون‌های الزامی در فایل یافت نشد: '
                         f'{", ".join(fa_missing)}. لطفاً از فایل قالب '
                         f'نمونه (import-template) استفاده کنید.'
            }, status=400)

        parsed_items = []
        row_errors = []
        auto_order = 0
        seen_keys = set()
        seen_orders = set()

        _TRUE_VALUES = {'بله', 'true', '1', 'yes', 'y', 'checked'}
        _FALSE_VALUES = {'خیر', 'false', '0', 'no', 'n', 'unchecked', ''}

        def _to_bool(value, row_idx):
            """EDRA v5 — HIGH-20: مقدار نامعتبر boolean → خطای ردیف (نه silent False)."""
            if value is None:
                return False
            if isinstance(value, bool):
                return value
            s = str(value).strip().lower()
            if s in _TRUE_VALUES:
                return True
            if s in _FALSE_VALUES:
                return False
            raise ValueError(f'مقدار boolean نامعتبر: «{value}»')

        def _to_int(value):
            if value is None or str(value).strip() == '':
                return None
            try:
                return int(float(value))
            except (TypeError, ValueError):
                return None

        def _norm(s):
            # نرمال‌سازی Unicode (NFC) برای تشخیص یکسان تکراری‌ها
            import unicodedata
            return unicodedata.normalize('NFC', s)

        for row_idx, row in enumerate(rows[1:], start=2):
            # ردیف کاملاً خالی → رد شود
            if all(cell is None or str(cell).strip() == '' for cell in row):
                continue
            if len(parsed_items) + len(row_errors) >= self.MAX_IMPORT_ROWS:
                row_errors.append(
                    {'row': row_idx,
                     'error': f'تعداد ردیف‌ها بیشتر از حداکثر مجاز '
                              f'({self.MAX_IMPORT_ROWS}) است.'})
                break

            item = {}
            for idx, key in col_map.items():
                value = row[idx] if idx < len(row) else None
                item[key] = value

            category = _norm(str(item.get('category') or '').strip())
            title = _norm(str(item.get('title') or '').strip())

            if not category:
                row_errors.append(
                    {'row': row_idx, 'error': 'دسته‌بندی الزامی است.'})
                continue
            if not title:
                row_errors.append(
                    {'row': row_idx, 'error': 'عنوان الزامی است.'})
                continue
            if len(title) > 200:
                row_errors.append(
                    {'row': row_idx, 'error': 'عنوان نباید بیشتر از ۲۰۰ کاراکتر باشد.'})
                continue
            if len(category) > 100:
                row_errors.append(
                    {'row': row_idx, 'error': 'دسته‌بندی نباید بیشتر از ۱۰۰ کاراکتر باشد.'})
                continue
            description = _norm(str(item.get('description') or '').strip())
            if len(description) > 1000:
                row_errors.append(
                    {'row': row_idx, 'error': 'توضیحات نباید بیشتر از ۱۰۰۰ کاراکتر باشد.'})
                continue

            # HIGH-19: duplicate درون فایل (category+title)
            dup_key = (category, title)
            if dup_key in seen_keys:
                row_errors.append(
                    {'row': row_idx,
                     'error': f'آیتم تکراری با همین عنوان قبلاً در فایل آمده: {title}'})
                continue
            seen_keys.add(dup_key)

            order = _to_int(item.get('order'))
            if order is None:
                auto_order += 1
                order = auto_order
            else:
                if order < 0:
                    row_errors.append(
                        {'row': row_idx, 'error': 'ترتیب نمی‌تواند منفی باشد.'})
                    continue
                if order in seen_orders:
                    row_errors.append(
                        {'row': row_idx, 'error': f'ترتیب تکراری: {order}.'})
                    continue
                seen_orders.add(order)

            try:
                requires_photo = _to_bool(item.get('requires_photo'), row_idx)
                requires_note = _to_bool(item.get('requires_note'), row_idx)
                is_critical = _to_bool(item.get('is_critical'), row_idx)
            except ValueError as e:
                row_errors.append({'row': row_idx, 'error': str(e)})
                continue

            parsed_items.append({
                'category': category,
                'title': title,
                'description': description,
                'order': order,
                'requires_photo': requires_photo,
                'requires_note': requires_note,
                'is_critical': is_critical,
            })

        if not parsed_items:
            return Response({
                'error': 'هیچ ردیف معتبری در فایل یافت نشد.',
                'errors': row_errors,
            }, status=400)

        # HIGH-19: آمار مقایسه با آیتم‌های موجود (جلوگیری از duplicate ناخواسته)
        existing_titles = set()
        if template.items.exists():
            existing_titles = {
                (i.category.name if i.category_id else '', i.title)
                for i in template.items.filter(
                    is_active=True).select_related('category')}
        duplicate_existing = sum(
            1 for it in parsed_items
            if (it['category'], it['title']) in existing_titles)

        if preview:
            return Response({
                'preview': True,
                'template_id': template.id,
                'template_name': template.name,
                'mode': mode,
                'items': parsed_items,
                'errors': row_errors,
                'total': len(parsed_items),
                'existing_count': template.items.filter(is_active=True).count(),
                'duplicate_with_existing': duplicate_existing,
            })

        # ذخیره اتمیک
        # P1-03 (EDRA v8): در حالت replace، وجود هر row error یعنی آیتم‌های
        # قبلی غیرفعال می‌شوند و فقط ردیف‌های valid جایگزین می‌شوند → از
        # دست رفتن داده. بنابراین replace با خطا از سمت Backend مسدود است.
        if mode == 'replace' and row_errors:
            return Response({
                'error': (
                    'در حالت جایگزینی (Replace) خطاهای سطر وجود دارد و '
                    'ایمپورت مسدود است. ابتدا فایل را اصلاح کنید تا همه '
                    'سطرها معتبر شوند.'),
                'errors': row_errors,
                'items': parsed_items,
            }, status=400)

        from core.models import ChecklistCategory
        with transaction.atomic():
            # ChecklistItem.category یک FK است؛ نام‌ها به رکورد دسته‌بندی
            # (get_or_create) تبدیل می‌شوند. قبلاً رشته مستقیم به FK داده
            # می‌شد و ایمپورت همیشه ValueError می‌داد.
            category_cache = {}

            def _category(name):
                if name not in category_cache:
                    category_cache[name], _ = (
                        ChecklistCategory.objects.get_or_create(name=name))
                return category_cache[name]

            if mode == 'replace':
                # حذف آیتم‌های فعال قبلی (snapshot‌های گزارش‌شده دست‌نخورده‌اند
                # چون گزارش‌ها به template_version اشاره دارند، نه خود آیتم‌ها)
                template.items.filter(is_active=True).update(is_active=False)
            created = []
            skipped = 0
            for item in parsed_items:
                category = _category(item['category'])
                fields = dict(
                    description=item['description'],
                    order=item['order'],
                    requires_photo=item['requires_photo'],
                    requires_note=item['requires_note'],
                    is_critical=item['is_critical'],
                )
                # UniqueConstraint(template, category, title) رکوردهای
                # غیرفعال را هم شامل می‌شود؛ بدون upsert، ایمپورت «replace»
                # با عنوان‌های تکراری (یا حتی «append» روی آیتم حذف‌نرم‌شده)
                # IntegrityError/۵۰۰ می‌داد.
                existing = ChecklistItem.objects.filter(
                    checklist_template=template, category=category,
                    title=item['title']).first()
                if existing is None:
                    obj = ChecklistItem.objects.create(
                        checklist_template=template, category=category,
                        title=item['title'], **fields)
                    created.append(obj.id)
                elif not existing.is_active:
                    for k, v in fields.items():
                        setattr(existing, k, v)
                    existing.is_active = True
                    existing.save()
                    created.append(existing.id)
                else:
                    skipped += 1

        return Response({
            'success': True,
            'message': f'{len(created)} آیتم با موفقیت به چک‌لیست '
                       f'«{template.name}» اضافه شد.',
            'template_id': template.id,
            'created_count': len(created),
            'skipped_duplicates': skipped,
            'errors': row_errors,
        })


class ChecklistItemViewSet(viewsets.ModelViewSet):
    """
    EDRA v25 — جدید: CRUD کامل تک‌آیتمی برای «مدیریت آیتم‌های چک‌لیست».
    قبلاً تنها راه افزودن/ویرایش آیتم، ایمپورت گروهی از اکسل بود؛ حالا
    می‌شود یک آیتم را مستقیم افزود/ویرایش/حذف کرد.

    GET    /api/inspections/checklist-items/?checklist_template=<id>
    POST   /api/inspections/checklist-items/           (body: checklist_template + فیلدها)
    PATCH  /api/inspections/checklist-items/{id}/
    DELETE /api/inspections/checklist-items/{id}/       (حذف نرم → is_active=False)

    فقط ادمین (نه کارشناس) — کارشناس فقط از طریق endpoint فقط‌خواندنی
    /checklist-templates/{id}/items/ به آیتم‌ها دسترسی دارد.
    """
    serializer_class = ChecklistItemWriteSerializer
    permission_classes = [IsAdminUserOrGroup]

    def get_queryset(self):
        qs = ChecklistItem.objects.select_related('checklist_template')
        template_id = self.request.query_params.get('checklist_template')
        if template_id:
            qs = qs.filter(checklist_template_id=template_id)
        return qs.order_by('checklist_template_id', 'order')

    def perform_create(self, serializer):
        # اگر ترتیب مشخص نشده، آخرین ترتیب موجود برای همان قالب + ۱
        if serializer.validated_data.get('order') in (None, 0):
            template = serializer.validated_data['checklist_template']
            last = ChecklistItem.objects.filter(
                checklist_template=template).order_by('-order').first()
            serializer.save(order=(last.order + 1) if last else 1)
        else:
            serializer.save()

    def perform_destroy(self, instance):
        # حذف نرم — گزارش‌های قبلی که به این آیتم اشاره می‌کنند (از طریق
        # snapshot در InspectionReport) نباید با حذف واقعی خراب شوند.
        instance.is_active = False
        instance.save(update_fields=['is_active'])


class InspectionReportViewSet(viewsets.ModelViewSet):
    """
    مدیریت گزارش‌های بازرسی.

    EDRA v34 — دسترسی:
      • ادمین: همه‌ی گزارش‌ها (is_admin_user؛ قبلاً فقط is_staff)
      • کارشناس: گزارش درخواست‌های تخصیص‌یافته به خودش
      • مشتری: فقط گزارش‌های «نهایی‌شده»ی درخواست‌های خودش، فقط خواندنی +
        دانلود PDF. (قبلاً کوئری‌ست مشتری را اصلاً شامل نمی‌شد، پس دکمه‌ی
        «دانلود PDF» صفحات مشتری همیشه ۴۰۴ می‌گرفت — با اینکه docstring همین
        اکشن «مالک درخواست» را مجاز می‌دانست.)
    """
    serializer_class = InspectionReportSerializer
    permission_classes = [IsAuthenticated]

    CUSTOMER_ACTIONS = ('list', 'retrieve', 'pdf')

    def _is_customer_view(self):
        user = self.request.user
        return not (is_admin_user(user) or is_expert_user(user))

    def initial(self, request, *args, **kwargs):
        super().initial(request, *args, **kwargs)
        if (getattr(self, 'action', None) not in self.CUSTOMER_ACTIONS
                and self._is_customer_view()):
            raise PermissionDenied('شما اجازه‌ی این عملیات را ندارید.')

    def get_queryset(self):
        user = self.request.user
        base = InspectionReport.objects.select_related(
            'inspection_request', 'inspection_request__equipment_type',
            'inspection_request__customer', 'verification')
        if is_admin_user(user):
            return base
        if is_expert_user(user):
            return base.filter(inspection_request__assigned_expert=user)
        # مشتری: فقط گزارش نهایی‌شده (نه گزارش خالی/در حال تکمیل)
        return base.filter(
            inspection_request__customer=user,
            inspection_request__status='completed',
            overall_result__in=['pass', 'fail', 'conditional'])

    def get_serializer_class(self):
        # EDRA v5 — CRITICAL-09: update عمومی فقط یادداشت را اجازه می‌دهد
        if self.action in ('update', 'partial_update'):
            return InspectionReportUpdateSerializer
        if self._is_customer_view():
            return CustomerInspectionReportSerializer
        return InspectionReportSerializer

    def perform_update(self, serializer):
        # CRITICAL-09: گزارش امضاشده/نهایی قابل تغییر نیست
        report = self.get_object()
        if report.signed_at is not None or report.signed_pdf_file:
            raise PermissionDenied(
                'گزارش امضا/نهایی شده و دیگر قابل ویرایش نیست.')
        if report.inspection_request.status == 'completed':
            raise PermissionDenied(
                'گزارش نهایی شده است و دیگر قابل ویرایش نیست.')
        super().perform_update(serializer)

    def destroy(self, request, *args, **kwargs):
        # حذف گزارش بازرسی از طریق API مجاز نیست (سند حقوقی/مالی)؛
        # ادمین از Django admin استفاده کند.
        raise PermissionDenied('حذف گزارش بازرسی از طریق API مجاز نیست.')

    @action(detail=True, methods=['get'])
    def pdf(self, request, pk=None):
        """
        دانلود محافظت‌شده‌ی PDF گزارش: مشتریِ مالکِ درخواست (فقط گزارش
        نهایی‌شده)، کارشناس تعیین‌شده یا ادمین. اگر نسخه‌ی امضاشده باشد همان،
        وگرنه PDF تولیدشده.
        """
        from django.http import FileResponse
        report = self.get_object()
        file_field = report.signed_pdf_file or report.pdf_file
        if not file_field:
            return Response(
                {'error': 'PDF گزارش هنوز تولید نشده است. لطفاً چند دقیقه '
                          'دیگر دوباره تلاش کنید.'}, status=404)
        try:
            handle = file_field.open('rb')
        except (FileNotFoundError, OSError):
            logger.error(f'Report PDF file missing on disk: {report.pk}')
            return Response(
                {'error': 'فایل PDF گزارش در دسترس نیست؛ با پشتیبانی تماس '
                          'بگیرید.'}, status=404)
        from core.utils.http_headers import build_content_disposition
        response = FileResponse(handle, content_type='application/pdf')
        response['Content-Disposition'] = build_content_disposition(
            f'گزارش_{report.report_number}.pdf',
            f'report_{report.report_number}.pdf')
        return response

    @transaction.atomic
    def perform_create(self, serializer):
        """
        ایجاد گزارش جدید (شروع بازرسی) برای درخواست تخصیص‌یافته.

        EDRA v34: وضعیت درخواست بررسی می‌شود (قبلاً حتی برای لغوشده/تکمیل‌شده
        هم گزارش ساخته می‌شد)، ردیف قفل می‌شود (race → ۵۰۰)، شماره‌گذاری با
        سرویس واحد انجام می‌شود، قالب snapshot می‌شود و تغییر وضعیت از
        apply_status_change می‌گذرد. فقط کارشناس تخصیص‌یافته (و ادمین).
        """
        from core.models import InspectionRequest as _IR
        from core.services.inspection_service import (
            EXPERT_EXECUTABLE_STATUSES, apply_status_change)
        from core.services.report_service import (
            next_report_number, resolve_active_template)

        request = self.request
        try:
            inspection_request_id = int(request.data.get('inspection_request'))
        except (TypeError, ValueError):
            raise serializers.ValidationError(
                {'inspection_request': 'شناسه‌ی درخواست نامعتبر است.'})

        lookup = {'id': inspection_request_id}
        if not is_admin_user(request.user):
            lookup['assigned_expert'] = request.user
        inspection_request = get_object_or_404(
            _IR.objects.select_for_update().select_related('equipment_type'),
            **lookup)

        if inspection_request.status not in EXPERT_EXECUTABLE_STATUSES:
            raise serializers.ValidationError(
                'وضعیت درخواست اجازه‌ی شروع بازرسی را نمی‌دهد.')
        if InspectionReport.objects.filter(
                inspection_request=inspection_request).exists():
            raise serializers.ValidationError("این درخواست قبلاً گزارش دارد.")

        template = resolve_active_template(inspection_request.equipment_type)
        report = serializer.save(
            inspection_request=inspection_request,
            report_number=next_report_number(),
            checklist_template_version=template,
            overall_result='pending',
            inspection_started_at=timezone.now(),
        )

        apply_status_change(
            inspection_request, 'in_progress', actor=request.user, force=True,
            reason='شروع بازرسی (ایجاد گزارش)')

        ReportVerification.objects.create(
            report=report,
            verification_code=generate_verification_code(report.report_number))
        return report

    @action(detail=True, methods=['post'])
    def submit_results(self, request, pk=None):
        """
        ثبت نتایج چک‌لیست و نهایی‌سازی گزارش.

        همین سرویس یکپارچه‌ی ExpertSubmitChecklistView (report_service) استفاده
        می‌شود تا قوانین یکسان باشند. تولید PDF بعد از commit در صف قرار
        می‌گیرد؛ اگر broker در دسترس نباشد، گزارش ثبت‌شده می‌ماند (به‌جای ۵۰۰
        بعد از نهایی‌شدن دیتابیس) و PDF با باز کردن مسیر دانلود کارشناس/ادمین ساخته و ذخیره می‌شود.
        """
        from core.services.report_service import (
            validate_and_finalize_existing, ChecklistSubmissionError)

        report = self.get_object()
        try:
            validate_and_finalize_existing(
                report,
                user=request.user,
                results=request.data.get('results', []),
                overall_result=request.data.get('overall_result'),
                inspector_notes=request.data.get('inspector_notes', ''),
                request=request,
            )
        except ChecklistSubmissionError as e:
            return Response({'error': str(e)}, status=e.status_code)

        report_id, user_id = report.id, request.user.id

        def _queue():
            try:
                generate_report_pdf_task.delay(report_id, user_id)
            except Exception as queue_error:
                logger.error(
                    f'Report PDF queue failed (report {report_id}): '
                    f'{queue_error}')
        transaction.on_commit(_queue)

        return Response({
            'message': 'نتایج ثبت شد و تولید گزارش در صف قرار گرفت.',
            'report_id': report.id,
            'report_number': report.report_number
        })

    @action(detail=True, methods=['post'])
    def sign_report(self, request, pk=None):
        """
        تأیید صحت گزارش (PDF-02):
        - اگر گواهی امضا تنظیم شده باشد (PDF_SIGN_CERT_PATH/PDF_SIGN_KEY_PATH)
          امضای واقعی PAdES با pyHanko اعمال می‌شود.
        - در غیر این صورت مهر یکپارچگی (SHA-256) ثبت می‌شود.
        EDRA v34: ادمین (is_admin_user) هم مجاز است؛ ذخیره‌ی فایل و فیلدهای
        امضا در یک تراکنش با قفل ردیف (امضای دوبار همزمان)؛ متن خام استثنا به
        کلاینت نمی‌رود.
        """
        from django.core.files.base import ContentFile
        import hashlib
        from .utils import sign_pdf_with_pyhanko

        report = self.get_object()

        if not report.pdf_file:
            return Response(
                {'error': 'فایل PDF گزارش هنوز تولید نشده است.'}, status=400)
        if report.signed_at is not None or report.signed_pdf_file:
            return Response(
                {'error': 'این گزارش قبلاً امضا شده است.'}, status=400)
        if report.overall_result not in ('pass', 'fail', 'conditional'):
            return Response(
                {'error': 'نتیجه نهایی گزارش هنوز تعیین نشده است (pending).'},
                status=400)
        if report.inspection_request.status != 'completed':
            return Response(
                {'error': 'درخواست بازرسی هنوز تکمیل نشده است؛ امکان امضا نیست.'},
                status=400)
        if not report.results:
            return Response(
                {'error': 'نتایج چک‌لیست خالی است؛ امکان امضا نیست.'}, status=400)
        if (report.inspection_request.assigned_expert_id != request.user.id
                and not is_admin_user(request.user)):
            raise PermissionDenied("شما دسترسی به امضای این گزارش ندارید.")

        try:
            with transaction.atomic():
                locked = InspectionReport.objects.select_for_update().get(
                    pk=report.pk)
                if locked.signed_at is not None or locked.signed_pdf_file:
                    return Response(
                        {'error': 'این گزارش قبلاً امضا شده است.'}, status=400)
                with locked.pdf_file.open('rb') as fh:
                    pdf_content = fh.read()
                signed_content = sign_pdf_with_pyhanko(pdf_content)

                filename = f"report_{locked.report_number}_signed.pdf"
                locked.signed_pdf_file.save(
                    filename, ContentFile(signed_content), save=False)
                locked.signature_hash = hashlib.sha256(
                    signed_content).hexdigest()
                locked.signed_at = timezone.now()
                locked.signed_by = request.user
                locked.save()

                try:
                    from core.models import AuditLog
                    AuditLog.objects.create(
                        user=request.user,
                        action='sign_report',
                        object_id=locked.id,
                        changes={'report_number': locked.report_number,
                                 'signature_hash': locked.signature_hash[:16],
                                 'pades': signed_content != pdf_content},
                    )
                except Exception as log_error:
                    logger.error(f"Error writing audit log: {log_error}")
        except Exception as e:
            logger.error(f"Error signing PDF (report {report.pk}): {e}",
                         exc_info=True)
            return Response(
                {'error': 'خطا در امضای PDF. لطفاً دوباره تلاش کنید یا به '
                          'پشتیبانی اطلاع دهید.'}, status=500)

        pades = signed_content != pdf_content
        message = (
            'گزارش با موفقیت امضای دیجیتال (PAdES) گرفت و مهر یکپارچگی ثبت شد.'
            if pades else
            'گزارش تأیید شد و مهر یکپارچگی ثبت گردید. '
            '(امضای PKI فعال نیست؛ PDF_SIGN_CERT_PATH تنظیم نشده است.)')
        return Response({'message': message, 'signed': pades})


# ============================================================
# ویوهای عمومی (استعلام گزارش)
# ============================================================

class ReportVerificationView(generics.RetrieveAPIView):
    """استعلام عمومی گزارش با کد استعلام (P1 بند ۲۷: ضد enumeration)"""
    permission_classes = [AllowAny]
    serializer_class = ReportVerificationSerializer
    throttle_classes = [ScopedRateThrottle]
    throttle_scope = 'public_verify'

    def get_object(self):
        verification_code = self.kwargs.get('code')
        verification = get_object_or_404(
            ReportVerification,
            verification_code=verification_code)
        # EDRA v7 — PERF-01/P1-16: افزایش اتمیک (F()) به‌جای
        # read-modify-write که در ترافیک بالا Write Hotspot می‌شد.
        ReportVerification.objects.filter(pk=verification.pk).update(
            view_count=models.F('view_count') + 1,
            last_viewed_at=timezone.now())
        verification.view_count += 1
        verification.last_viewed_at = timezone.now()
        return verification
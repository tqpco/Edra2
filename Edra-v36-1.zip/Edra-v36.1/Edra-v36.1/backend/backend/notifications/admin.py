# notifications/admin.py
# -*- coding: utf-8 -*-

from django.contrib import admin

# ✅ اصلاح: ایمپورت مستقیم از پکیج edra_jalalidate به‌جای core.admin.jalali_widgets و core.utils.date_utils
from edra_jalalidate.admin import EdraJalaliAdminMixin
from edra_jalalidate import to_jalali

from .models import NotificationTemplate, NotificationLog


class JalaliDateDisplayMixin:
    """نمایش تاریخ‌های خام به‌صورت جلالی در ستون‌های لیست ادمین"""

    def created_at_display(self, obj):
        return to_jalali(obj.created_at, fmt="%Y/%m/%d - %H:%M")
    created_at_display.short_description = "تاریخ ایجاد"

    def updated_at_display(self, obj):
        return to_jalali(obj.updated_at, fmt="%Y/%m/%d - %H:%M")
    updated_at_display.short_description = "تاریخ بروزرسانی"

    def sent_at_display(self, obj):
        return to_jalali(obj.sent_at, fmt="%Y/%m/%d - %H:%M")
    sent_at_display.short_description = "تاریخ ارسال"


@admin.register(NotificationTemplate)
class NotificationTemplateAdmin(
        JalaliDateDisplayMixin, EdraJalaliAdminMixin, admin.ModelAdmin):
    list_display = ('code', 'channel', 'subject', 'is_active',
                    'updated_at_display')
    list_filter = ('channel', 'is_active')
    search_fields = ('code', 'subject')
    ordering = ('code',)
    readonly_fields = ('created_at_display', 'updated_at_display')


@admin.register(NotificationLog)
class NotificationLogAdmin(
        JalaliDateDisplayMixin, EdraJalaliAdminMixin, admin.ModelAdmin):
    list_display = (
        'id', 'user', 'template', 'type', 'channel',
        'status', 'is_read', 'created_at_display',
    )
    list_filter = ('status', 'channel', 'type', 'is_read')
    search_fields = ('user__username', 'template__code', 'recipient', 'subject')
    readonly_fields = (
        'user', 'template', 'channel', 'type', 'subject', 'content',
        'recipient', 'error_message', 'sent_at_display', 'created_at_display',
    )
    ordering = ('-created_at',)

    def has_add_permission(self, request):
        # این لاگ‌ها فقط به‌صورت خودکار توسط سیستم ساخته می‌شوند، نه دستی
        return False
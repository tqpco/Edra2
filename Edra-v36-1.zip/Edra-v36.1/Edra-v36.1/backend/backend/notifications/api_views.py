import secrets

from django.core.cache import cache
from django.db.models import ProtectedError
from rest_framework import status as http_status
from rest_framework import viewsets
from rest_framework.permissions import IsAdminUser, IsAuthenticated
from rest_framework.response import Response
from core.permissions import IsAdminUserOrGroup
from .models import NotificationTemplate, NotificationLog
from .serializers import NotificationTemplateSerializer, NotificationLogSerializer

# عمر ticket اتصال WebSocket (ثانیه) — P0-08/HIGH-06
WS_TICKET_TTL_SECONDS = 60

# اصلاح NOT-01 از گزارش ممیزی: مدیریت Template/Log فقط برای Admin است.
# مشتریان فقط از طریق /api/core/notifications/ (user-scoped) اعلان خود را
# می‌بینند؛ این ViewSet ها نباید در معرض کاربر عادی قرار گیرند.


class NotificationTemplateViewSet(viewsets.ModelViewSet):
    """
    مدیریت کامل قالب‌های اعلان از پنل ادمین.
    EDRA v27 — قابلیت تازه (گزارش کاربر، سپتامبر ۲۰۲۶): قبلاً ReadOnly
    بود و کامنت صریحاً می‌گفت «تغییر فقط در پنل جنگو» — یکی از چند مورد
    باقی‌مانده‌ای که ادمین را مجبور به رفتن به پنل خام جنگو می‌کرد.
    """
    queryset = NotificationTemplate.objects.all().order_by('code')
    serializer_class = NotificationTemplateSerializer
    permission_classes = [IsAdminUserOrGroup]

    def destroy(self, request, *args, **kwargs):
        # EDRA v33: قالبی که لاگ دارد (FK=PROTECT) قبلاً ۵۰۰ می‌داد.
        try:
            return super().destroy(request, *args, **kwargs)
        except ProtectedError:
            return Response(
                {'error': 'این قالب لاگ ارسال دارد و حذف‌شدنی نیست؛ '
                          'به‌جای حذف آن را غیرفعال کنید.'},
                status=http_status.HTTP_409_CONFLICT)


class NotificationLogViewSet(viewsets.ReadOnlyModelViewSet):
    """لاگ ارسال نوتیفیکیشن — فقط ادمین."""
    queryset = NotificationLog.objects.select_related(
        'user', 'template').order_by('-created_at')
    serializer_class = NotificationLogSerializer
    permission_classes = [IsAdminUserOrGroup]

    def get_queryset(self):
        qs = super().get_queryset()
        params = self.request.query_params
        for field in ('status', 'channel', 'type'):
            value = params.get(field)
            if value:
                qs = qs.filter(**{field: value})
        return qs


class WsTicketView(viewsets.ViewSet):
    """
    P0-08/HIGH-06: صدور ticket یکبارمصرف برای اتصال WebSocket.

    معماری امن:
      1. access JWT هرگز به جاوااسکریپت تحویل داده نمی‌شود (httpOnly cookie).
      2. برای WebSocket، کلاینت یک ticket تصادفی با عمر ۶۰ ثانیه می‌گیرد.
      3. ticket فقط یک بار قابل مصرف است (در اولین اتصال از cache حذف می‌شود)
         و در query string قرار می‌گیرد؛ افشای آن فقط یک اتصال کوتاه و
         محدود به همان کاربر می‌دهد، نه توکن اصلی.
    """

    permission_classes = [IsAuthenticated]

    def create(self, request):
        ticket = secrets.token_hex(32)
        cache.set(
            f'ws_ticket_{ticket}',
            request.user.id,
            timeout=WS_TICKET_TTL_SECONDS)
        return Response({
            'ticket': ticket,
            'expires_in': WS_TICKET_TTL_SECONDS,
        })

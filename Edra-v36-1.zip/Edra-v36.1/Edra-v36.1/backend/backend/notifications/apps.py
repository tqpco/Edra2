from django.apps import AppConfig


class NotificationsConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'notifications'

    def ready(self):
        # EDRA v33: ثبت سیگنال push لحظه‌ای (قبلاً هرگز import نمی‌شد).
        from . import signals  # noqa: F401

# notifications/consumers.py
# -*- coding: utf-8 -*-
import json

from channels.db import database_sync_to_async
from channels.generic.websocket import AsyncWebsocketConsumer

from .models import NotificationLog
from .payloads import notification_payload


class NotificationConsumer(AsyncWebsocketConsumer):
    async def connect(self):
        self.user = self.scope['user']
        if not self.user.is_authenticated or not self.user.is_active:
            await self.close()
            return

        self.room_group_name = f'user_{self.user.id}'
        await self.channel_layer.group_add(
            self.room_group_name, self.channel_name)
        await self.accept()

        # اعلان‌های خوانده‌نشده هنگام اتصال (اولین پیام همیشه همین است)
        await self.send_unread_notifications()

    async def disconnect(self, close_code):
        if hasattr(self, 'room_group_name'):
            await self.channel_layer.group_discard(
                self.room_group_name, self.channel_name)

    async def receive(self, text_data=None, bytes_data=None):
        # EDRA v33: JSON خراب/غیرمنتظره قبلاً exception می‌داد و اتصال را می‌بست.
        try:
            data = json.loads(text_data or '')
        except (TypeError, ValueError):
            return
        if not isinstance(data, dict):
            return
        action = data.get('action')

        if action == 'ping':  # heartbeat کلاینت (جلوگیری از قطع شدن idle)
            await self.send(text_data=json.dumps({'type': 'pong'}))
        elif action == 'mark_read':
            try:
                notification_id = int(data.get('notification_id'))
            except (TypeError, ValueError):
                return
            await self.mark_notification_read(notification_id)
        elif action == 'mark_all_read':
            await self.mark_all_notifications_read()

    async def send_notification(self, event):
        """push لحظه‌ای از channel layer."""
        await self.send(text_data=json.dumps({
            'type': 'notification',
            'data': event['data'],
        }))

    async def send_unread_notifications(self):
        notifications, count = await self.get_unread_notifications()
        if notifications:
            await self.send(text_data=json.dumps({
                'type': 'unread_notifications',
                'data': notifications,
                'count': count,
            }))

    @database_sync_to_async
    def get_unread_notifications(self):
        # «خوانده‌نشده» = is_read (نه status که وضعیت ارسال است). حداکثر ۵۰ مورد
        # اخیر برای payload سبک؛ count واقعی جداگانه برگردانده می‌شود.
        qs = NotificationLog.objects.filter(user=self.user, is_read=False)
        count = qs.count()
        rows = qs.order_by('-created_at')[:50]
        return [notification_payload(r) for r in rows], count

    @database_sync_to_async
    def mark_notification_read(self, notification_id):
        NotificationLog.objects.filter(
            id=notification_id, user=self.user, is_read=False
        ).update(is_read=True)

    @database_sync_to_async
    def mark_all_notifications_read(self):
        NotificationLog.objects.filter(
            user=self.user, is_read=False).update(is_read=True)

# notifications/defaults.py
# -*- coding: utf-8 -*-
"""
EDRA v33 — منبع واحد قالب‌های پیش‌فرض اعلان.

چرا این فایل وجود دارد (ریشه‌ی مشکل «اعلان‌ها کار نمی‌کند»):
  تا v32 قالب‌ها فقط با دستور دستی `seed_notification_templates` ساخته
  می‌شدند (و فقط ۴ قالب در migration بود). اگر آن دستور اجرا نمی‌شد، تقریباً
  همه‌ی اعلان‌ها بی‌صدا دور ریخته می‌شدند (send_notification فقط یک خط خطا
  لاگ می‌کرد و برمی‌گشت). چند کد (ticket_created, ticket_assigned,
  payment_refunded, request_reminder) هم اصلاً در هیچ seed نبودند.

  حالا:
    ۱) migration 0004 همه‌ی این قالب‌ها را (idempotent، بدون بازنویسی ویرایش‌های
       ادمین) می‌سازد؛
    ۲) دستور seed_notification_templates از همین لیست می‌خواند؛
    ۳) send_notification اگر قالبی در دیتابیس نبود ولی کدش اینجا تعریف شده
       بود، همان لحظه آن را می‌سازد (خودترمیم).

قرارداد context هر قالب در کامنت جلوی آن آمده است. متن‌ها با سینتکس
Django Template ({{ var }}) نوشته می‌شوند.
"""

# هر آیتم: code / channel (email|sms|both|in_app) / subject / body_template
DEFAULT_TEMPLATES = [
    # ---------------- درخواست بازرسی (مشتری) ----------------
    {   # ctx: request_id, status
        'code': 'request_created', 'channel': 'both',
        'subject': 'درخواست شما ثبت شد',
        'body_template': (
            'مشتری گرامی، درخواست بازرسی شما با شماره {{ request_id }} '
            'ثبت شد. اِدرا'),
    },
    {   # ctx: request_id, customer
        'code': 'new_request_admin', 'channel': 'both',
        'subject': 'درخواست جدید برای بررسی',
        'body_template': (
            'یک درخواست جدید با شماره {{ request_id }} از کاربر '
            '{{ customer }} ثبت شده است.'),
    },
    {   # ctx: request_id, request_number, new_status (برچسب فارسی), old_status
        'code': 'status_changed', 'channel': 'both',
        'subject': 'تغییر وضعیت درخواست',
        'body_template': (
            'مشتری گرامی، وضعیت درخواست {{ request_number|default:request_id }} '
            'به «{{ new_status }}» تغییر یافت. اِدرا'),
    },
    {   # ctx: request_id, customer
        'code': 'assigned_to_expert', 'channel': 'both',
        'subject': 'درخواست جدید به شما ارجاع شد',
        'body_template': (
            'شما به‌عنوان کارشناس برای درخواست {{ request_id }} '
            'تعیین شده‌اید.'),
    },
    {   # ctx: request_id, request_number, new_status, customer
        'code': 'expert_request_updated', 'channel': 'both',
        'subject': 'به‌روزرسانی درخواست شما',
        'body_template': (
            'وضعیت درخواست {{ request_number|default:request_id }} '
            'به «{{ new_status }}» تغییر یافت.'),
    },
    {   # ctx: request_id, request_number, message
        'code': 'request_reminder', 'channel': 'both',
        'subject': 'یادآوری درخواست',
        'body_template': '{{ message }}',
    },
    {   # ctx: request_id
        'code': 'inspection_scheduled', 'channel': 'both',
        'subject': 'زمان کارشناسی ثبت شد',
        'body_template': 'زمان کارشناسی درخواست {{ request_id }} ثبت شد.',
    },
    # ---------------- پرداخت ----------------
    {   # ctx: request_id, amount, ref_id?, method?
        'code': 'payment_successful', 'channel': 'both',
        'subject': 'پرداخت موفق',
        'body_template': (
            'پرداخت شما به مبلغ {{ amount }} تومان با موفقیت انجام شد. اِدرا'),
    },
    {   # ctx: request_id
        'code': 'payment_failed', 'channel': 'both',
        'subject': 'پرداخت ناموفق',
        'body_template': (
            'پرداخت شما برای درخواست {{ request_id }} ناموفق بود یا لغو شد. '
            'لطفاً دوباره تلاش کنید.'),
    },
    {   # ctx: request_id, amount, method
        'code': 'payment_pending_review', 'channel': 'sms',
        'subject': 'پرداخت شما در حال بررسی است',
        'body_template': (
            'مشتری گرامی، پرداخت شما بابت درخواست شماره {{ request_id }} '
            'ثبت شد و در حال بررسی نهایی توسط تیم پشتیبانی است. نتیجه به '
            'زودی اطلاع‌رسانی می‌شود. اِدرا'),
    },
    {   # ctx: message
        'code': 'payment_verified', 'channel': 'both',
        'subject': 'تایید پرداخت و افزایش اعتبار',
        'body_template': '{{ message }}',
    },
    {   # ctx: message
        'code': 'payment_verified_request', 'channel': 'both',
        'subject': 'تایید پرداخت و زمان‌بندی درخواست',
        'body_template': '{{ message }}',
    },
    {   # ctx: request_id, reason
        'code': 'payment_rejected', 'channel': 'both',
        'subject': 'رد فیش پرداخت',
        'body_template': (
            'فیش پرداخت شما بابت درخواست #{{ request_id }} تایید نشد. '
            'دلیل: {{ reason }}'),
    },
    {   # ctx: customer, amount, request_id   (ادمین‌ها)
        'code': 'payment_manual_upload', 'channel': 'both',
        'subject': 'آپلود فیش جدید',
        'body_template': (
            'کاربر {{ customer }} یک فیش به مبلغ {{ amount }} تومان برای '
            'درخواست #{{ request_id }} آپلود کرده است.'),
    },
    {   # ctx: payment_id, amount (سهم اعتبار), request_id, reason
        'code': 'payment_refunded', 'channel': 'both',
        'subject': 'عودت پرداخت',
        'body_template': (
            'پرداخت شماره {{ payment_id }} شما بابت درخواست {{ request_id }} '
            'عودت داده شد. مبلغ بازگشتی به اعتبار: {{ amount }} تومان. '
            'علت: {{ reason }}'),
    },
    # ---------------- فاکتور / گزارش ----------------
    {   # ctx: invoice_number, invoice_id
        'code': 'invoice_pdf_ready', 'channel': 'both',
        'subject': 'فاکتور PDF آماده شد',
        'body_template': 'فاکتور شماره {{ invoice_number }} آماده دانلود است.',
    },
    {
        'code': 'invoice_pdf_failed', 'channel': 'in_app',
        'subject': 'خطا در تولید فاکتور',
        'body_template': (
            'در تولید فایل PDF فاکتور شما خطایی رخ داد. تیم پشتیبانی در '
            'حال بررسی است.'),
    },
    {   # ctx: invoice_number, invoice_id, error, customer   (ادمین‌ها)
        'code': 'invoice_pdf_failed_admin', 'channel': 'in_app',
        'subject': '[ادمین] خطا در تولید فاکتور',
        'body_template': (
            'تولید PDF فاکتور {{ invoice_number|default:invoice_id }} با خطا '
            'مواجه شد: {{ error }}'),
    },
    {   # ctx: report_number, report_id
        'code': 'report_pdf_ready', 'channel': 'both',
        'subject': 'گزارش PDF آماده شد',
        'body_template': 'گزارش شماره {{ report_number }} آماده دانلود است.',
    },
    {
        'code': 'report_pdf_failed', 'channel': 'in_app',
        'subject': 'خطا در تولید گزارش',
        'body_template': (
            'در تولید فایل PDF گزارش {{ report_id }} خطایی رخ داد. '
            'سیستم دوباره تلاش می‌کند؛ در صورت تکرار تیم فنی بررسی می‌کند.'),
    },
    # ---------------- کد تخفیف ----------------
    {   # ctx: code, discount_value?, discount_type?, expires_at?
        'code': 'new_discount_code', 'channel': 'both',
        'subject': 'کد تخفیف جدید',
        'body_template': 'یک کد تخفیف جدید برای شما فعال شد: {{ code }}',
    },
    {   # ctx: code, days_left, expires_at
        'code': 'discount_code_expiring', 'channel': 'both',
        'subject': 'کد تخفیف شما رو به اتمام است',
        'body_template': (
            'کد تخفیف {{ code }} شما تا {{ days_left }} روز دیگر منقضی '
            'می‌شود.'),
    },
    # ---------------- یادآوری/لغو خودکار پرداخت‌نشده ----------------
    {   # ctx: request_id, request_number
        'code': 'request_payment_reminder_24h', 'channel': 'sms',
        'subject': 'یادآوری پرداخت',
        'body_template': (
            'مشتری گرامی، درخواست بازرسی شماره {{ request_number }} شما '
            'هنوز پرداخت نشده است. لطفاً ظرف ۴۸ ساعت آینده نسبت به پرداخت '
            'اقدام کنید، در غیر این صورت درخواست به‌صورت خودکار لغو خواهد '
            'شد. اِدرا'),
    },
    {
        'code': 'request_payment_reminder_48h', 'channel': 'sms',
        'subject': 'یادآوری پرداخت (نهایی)',
        'body_template': (
            'مشتری گرامی، درخواست بازرسی شماره {{ request_number }} شما '
            'همچنان پرداخت نشده است. در صورت عدم پرداخت ظرف ۲۴ ساعت آینده، '
            'این درخواست به‌صورت خودکار بسته خواهد شد. اِدرا'),
    },
    {
        'code': 'request_auto_cancelled_72h', 'channel': 'sms',
        'subject': 'لغو خودکار درخواست',
        'body_template': (
            'مشتری گرامی، درخواست بازرسی شماره {{ request_number }} شما به '
            'دلیل عدم پرداخت طی ۷۲ ساعت، به‌صورت خودکار بسته شد. در صورت '
            'تمایل می‌توانید درخواست جدیدی ثبت کنید. اِدرا'),
    },
    # ---------------- تیکت پشتیبانی ----------------
    {   # ctx: ticket_id, title                        (مشتری)
        'code': 'ticket_created', 'channel': 'in_app',
        'subject': 'تیکت شما ثبت شد',
        'body_template': (
            'تیکت #{{ ticket_id }} با عنوان «{{ title }}» ثبت شد. '
            'پشتیبانی به‌زودی پاسخ می‌دهد.'),
    },
    {   # ctx: ticket_id, title, assigned_by           (کارشناس/پشتیبان)
        'code': 'ticket_assigned', 'channel': 'in_app',
        'subject': 'تیکت به شما اختصاص داده شد',
        'body_template': (
            'تیکت #{{ ticket_id }} «{{ title }}» توسط {{ assigned_by }} '
            'به شما اختصاص داده شد.'),
    },
    {   # ctx: ticket_id, title                        (مشتری)
        'code': 'ticket_reply', 'channel': 'sms',
        'subject': 'پاسخ جدید به تیکت شما',
        'body_template': (
            'مشتری گرامی، پشتیبانی به تیکت #{{ ticket_id }} «{{ title }}» '
            'شما پاسخ داد. اِدرا'),
    },
    {   # ctx: ticket_id, title                        (پشتیبان/ادمین)
        'code': 'ticket_customer_reply', 'channel': 'in_app',
        'subject': 'پاسخ مشتری در تیکت',
        'body_template': (
            'مشتری در تیکت #{{ ticket_id }} «{{ title }}» پاسخ جدیدی '
            'ثبت کرد.'),
    },
    {   # ctx: ticket_id, title, new_status            (مشتری)
        'code': 'ticket_status_changed', 'channel': 'in_app',
        'subject': 'تغییر وضعیت تیکت',
        'body_template': (
            'وضعیت تیکت #{{ ticket_id }} «{{ title }}» به «{{ new_status }}» '
            'تغییر یافت.'),
    },
]

DEFAULT_TEMPLATES_BY_CODE = {t['code']: t for t in DEFAULT_TEMPLATES}

# برچسب فارسی «نوع اعلان» برای نمایش در داشبورد (به‌جای کد خام انگلیسی)
TYPE_LABELS = {
    'request_created': 'درخواست جدید',
    'new_request_admin': 'درخواست جدید (مدیر)',
    'status_changed': 'تغییر وضعیت',
    'assigned_to_expert': 'ارجاع به کارشناس',
    'expert_request_updated': 'به‌روزرسانی درخواست',
    'request_reminder': 'یادآوری درخواست',
    'inspection_scheduled': 'زمان بازرسی',
    'inspection_completed': 'تکمیل بازرسی',
    'payment_successful': 'پرداخت موفق',
    'payment_failed': 'پرداخت ناموفق',
    'payment_pending_review': 'پرداخت در حال بررسی',
    'payment_verified': 'تایید پرداخت',
    'payment_verified_request': 'تایید پرداخت و زمان‌بندی',
    'payment_rejected': 'رد فیش پرداخت',
    'payment_manual_upload': 'آپلود فیش جدید',
    'payment_refunded': 'عودت پرداخت',
    'invoice_pdf_ready': 'فاکتور آماده',
    'invoice_pdf_failed': 'خطا در فاکتور',
    'invoice_pdf_failed_admin': 'خطا در فاکتور (مدیر)',
    'report_pdf_ready': 'گزارش آماده',
    'report_pdf_failed': 'خطا در گزارش',
    'new_discount_code': 'کد تخفیف جدید',
    'discount_code_expiring': 'انقضای کد تخفیف',
    'request_payment_reminder_24h': 'یادآوری پرداخت',
    'request_payment_reminder_48h': 'یادآوری پرداخت (نهایی)',
    'request_auto_cancelled_72h': 'لغو خودکار درخواست',
    'ticket_created': 'تیکت جدید',
    'ticket_assigned': 'ارجاع تیکت',
    'ticket_reply': 'پاسخ تیکت',
    'ticket_customer_reply': 'پاسخ مشتری در تیکت',
    'ticket_status_changed': 'وضعیت تیکت',
}

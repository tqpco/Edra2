# EDRA v27 — قابلیت تازه: قالب‌های پیامکی یادآوری/بستن خودکار درخواست
# پرداخت‌نشده (۲۴/۴۸/۷۲ ساعت). بدون این قالب‌ها، send_notification فقط
# یک خطا لاگ می‌کند و پیامکی ارسال نمی‌شود (fail-safe، نه crash) — پس
# این seed برای فعال‌شدن واقعی قابلیت لازم است. ادمین می‌تواند این
# قالب‌ها را بعداً از پنل مدیریت (قالب‌های اعلان) ویرایش کند.
from django.db import migrations


TEMPLATES = [
    {
        'code': 'request_payment_reminder_24h',
        'channel': 'sms',
        'subject': 'یادآوری پرداخت',
        'body_template': (
            'مشتری گرامی، درخواست بازرسی شماره {{ request_number }} شما '
            'هنوز پرداخت نشده است. لطفاً ظرف ۴۸ ساعت آینده نسبت به پرداخت '
            'اقدام کنید، در غیر این صورت درخواست به‌صورت خودکار لغو خواهد شد. اِدرا'
        ),
    },
    {
        'code': 'request_payment_reminder_48h',
        'channel': 'sms',
        'subject': 'یادآوری پرداخت (نهایی)',
        'body_template': (
            'مشتری گرامی، درخواست بازرسی شماره {{ request_number }} شما '
            'همچنان پرداخت نشده است. در صورت عدم پرداخت ظرف ۲۴ ساعت آینده، '
            'این درخواست به‌صورت خودکار بسته خواهد شد. اِدرا'
        ),
    },
    {
        'code': 'request_auto_cancelled_72h',
        'channel': 'sms',
        'subject': 'لغو خودکار درخواست',
        'body_template': (
            'مشتری گرامی، درخواست بازرسی شماره {{ request_number }} شما به '
            'دلیل عدم پرداخت طی ۷۲ ساعت، به‌صورت خودکار بسته شد. در صورت تمایل '
            'می‌توانید درخواست جدیدی ثبت کنید. اِدرا'
        ),
    },
    {
        # EDRA v27 — قابلیت تازه: پرداخت اعتباری/آفلاین دیگر بلافاصله
        # paid نمی‌شود، بلکه منتظر تایید دستی ادمین می‌ماند.
        'code': 'payment_pending_review',
        'channel': 'sms',
        'subject': 'پرداخت شما در حال بررسی است',
        'body_template': (
            'مشتری گرامی، پرداخت شما بابت درخواست شماره {{ request_id }} '
            'ثبت شد و در حال بررسی نهایی توسط تیم پشتیبانی است. نتیجه به '
            'زودی اطلاع‌رسانی می‌شود. اِدرا'
        ),
    },
]


def seed_templates(apps, schema_editor):
    NotificationTemplate = apps.get_model('notifications', 'NotificationTemplate')
    for t in TEMPLATES:
        NotificationTemplate.objects.get_or_create(
            code=t['code'],
            defaults={
                'channel': t['channel'],
                'subject': t['subject'],
                'body_template': t['body_template'],
                'is_active': True,
            },
        )


def remove_templates(apps, schema_editor):
    NotificationTemplate = apps.get_model('notifications', 'NotificationTemplate')
    NotificationTemplate.objects.filter(
        code__in=[t['code'] for t in TEMPLATES]
    ).delete()


class Migration(migrations.Migration):

    dependencies = [
        ('notifications', '0001_initial'),
    ]

    operations = [
        migrations.RunPython(seed_templates, remove_templates),
    ]

# EDRA v33 — افزودن کانال «درون‌برنامه‌ای» (فقط تغییر choices؛ بدون تغییر ساختار جدول)
from django.db import migrations, models

CHANNEL_CHOICES = [
    ('email', 'ایمیل'),
    ('sms', 'پیامک'),
    ('both', 'هر دو'),
    ('in_app', 'درون‌برنامه‌ای'),
]


class Migration(migrations.Migration):

    dependencies = [
        ('notifications', '0002_seed_reminder_templates'),
    ]

    operations = [
        migrations.AlterField(
            model_name='notificationtemplate',
            name='channel',
            field=models.CharField(
                choices=CHANNEL_CHOICES, default='both', max_length=10,
                verbose_name='کانال'),
        ),
        migrations.AlterField(
            model_name='notificationlog',
            name='channel',
            field=models.CharField(
                choices=CHANNEL_CHOICES, max_length=10,
                verbose_name='کانال'),
        ),
    ]

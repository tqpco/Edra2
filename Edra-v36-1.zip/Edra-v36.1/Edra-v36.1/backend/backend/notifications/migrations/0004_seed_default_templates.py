# EDRA v33 — seed خودکار «همه‌ی» قالب‌های اعلان.
#
# ریشه‌ی مشکل «اعلان‌ها کار نمی‌کند»: قالب‌ها فقط با دستور دستی
# seed_notification_templates ساخته می‌شدند؛ بدون آن، send_notification
# برای تقریباً همه‌ی رویدادها بی‌صدا هیچ کاری نمی‌کرد. get_or_create تضمین
# می‌کند قالب‌های ویرایش‌شده‌ی ادمین دست نخورند.
from django.db import migrations

from notifications.defaults import DEFAULT_TEMPLATES


def seed(apps, schema_editor):
    NotificationTemplate = apps.get_model('notifications', 'NotificationTemplate')
    for t in DEFAULT_TEMPLATES:
        NotificationTemplate.objects.get_or_create(
            code=t['code'],
            defaults={
                'channel': t['channel'],
                'subject': t['subject'],
                'body_template': t['body_template'],
                'is_active': True,
            },
        )


class Migration(migrations.Migration):

    dependencies = [
        ('notifications', '0003_channel_in_app'),
    ]

    operations = [
        # برگشت‌ناپذیر عمداً: حذف قالب‌ها ممکن است به لاگ‌های موجود (PROTECT) برخورد کند.
        migrations.RunPython(seed, migrations.RunPython.noop),
    ]

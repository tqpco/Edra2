# notifications/models.py
from django.db import models
from django.conf import settings


class NotificationTemplate(models.Model):
    CHANNEL_CHOICES = [
        ('email', 'ایمیل'),
        ('sms', 'پیامک'),
        ('both', 'هر دو'),
        # EDRA v33: فقط اعلان داخل داشبورد (بدون پیامک/ایمیل). قبلاً برای
        # اعلان‌هایی که ذاتاً کانال خارجی ندارند (مثلاً تیکت) مجبور بودیم
        # کانال 'email' بگذاریم و کاربران OTP (بدون ایمیل) هرگز اعلان نمی‌دیدند.
        ('in_app', 'درون‌برنامه‌ای'),
    ]

    code = models.CharField(max_length=50, unique=True, verbose_name='کد')
    channel = models.CharField(
        max_length=10,
        choices=CHANNEL_CHOICES,
        default='both',
        verbose_name='کانال')
    subject = models.CharField(
        max_length=200,
        blank=True,
        verbose_name='موضوع')
    body_template = models.TextField(verbose_name='قالب متن')
    is_active = models.BooleanField(default=True, verbose_name='فعال')
    created_at = models.DateTimeField(
        auto_now_add=True, verbose_name='تاریخ ایجاد')
    updated_at = models.DateTimeField(
        auto_now=True, verbose_name='تاریخ بروزرسانی')

    def __str__(self):
        return f"{self.code} ({self.get_channel_display()})"

    class Meta:
        verbose_name = 'قالب اعلان'
        verbose_name_plural = 'قالب‌های اعلان'


class NotificationLog(models.Model):
    STATUS_CHOICES = [
        ('pending', 'در انتظار'),
        ('sent', 'ارسال‌شده'),
        ('failed', 'ناموفق'),
    ]

    TYPE_CHOICES = [
        ('request_created', 'درخواست جدید'),
        ('status_changed', 'تغییر وضعیت'),
        ('assigned_to_expert', 'تخصیص کارشناس'),
        ('payment_verified', 'تایید پرداخت'),
        ('payment_failed', 'پرداخت ناموفق'),
        ('report_pdf_ready', 'گزارش PDF آماده'),
        ('invoice_pdf_ready', 'فاکتور PDF آماده'),
        ('invoice_pdf_failed', 'خطا در تولید فاکتور'),
        ('new_discount_code', 'کد تخفیف جدید'),
        ('discount_code_expiring', 'کد تخفیف در حال انقضا'),
        ('ticket_reply', 'پاسخ تیکت'),
        ('inspection_scheduled', 'زمان بازرسی'),
        ('inspection_completed', 'تکمیل بازرسی'),
        ('payment_verified_request', 'تایید پرداخت و زمان‌بندی درخواست'),
        ('payment_rejected', 'رد فیش پرداخت'),
        ('payment_manual_upload', 'آپلود فیش جدید'),
    ]

    user = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.CASCADE,
        related_name='notifications',
        verbose_name='کاربر')
    template = models.ForeignKey(
        NotificationTemplate,
        on_delete=models.PROTECT,
        verbose_name='قالب')
    channel = models.CharField(
        max_length=10,
        choices=NotificationTemplate.CHANNEL_CHOICES,
        verbose_name='کانال')
    type = models.CharField(
        max_length=50,
        choices=TYPE_CHOICES,
        blank=True,
        verbose_name='نوع اعلان',
        help_text='دسته‌بندی اعلان، برای فیلتر/آیکون در فرانت‌اند استفاده می‌شود')
    subject = models.CharField(
        max_length=200,
        blank=True,
        verbose_name='موضوع')
    content = models.TextField(verbose_name='محتوا')
    recipient = models.CharField(
        max_length=255,
        blank=True,
        verbose_name='گیرنده',
        help_text='شماره موبایل یا ایمیلی که اعلان به آن ارسال شده (برای پیگیری/رفع اشکال)')
    status = models.CharField(
        max_length=20,
        choices=STATUS_CHOICES,
        default='pending',
        verbose_name='وضعیت ارسال')
    is_read = models.BooleanField(
        default=False,
        verbose_name='خوانده‌شده',
        help_text='وضعیت خوانده‌شدن توسط کاربر - مستقل از وضعیت ارسال (status)')
    error_message = models.TextField(blank=True, verbose_name='پیام خطا')
    sent_at = models.DateTimeField(
        null=True, blank=True, verbose_name='تاریخ ارسال')
    created_at = models.DateTimeField(
        auto_now_add=True, verbose_name='تاریخ ایجاد')

    def __str__(self):
        return f"{self.user.username} - {self.template.code} - {self.status}"

    class Meta:
        verbose_name = 'لاگ اعلان'
        verbose_name_plural = 'لاگ‌های اعلان'
        ordering = ['-created_at']
        indexes = [
            models.Index(fields=['user', 'is_read']),
            models.Index(fields=['status']),
        ]
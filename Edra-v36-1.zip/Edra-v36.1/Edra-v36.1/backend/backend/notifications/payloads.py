# notifications/payloads.py
# -*- coding: utf-8 -*-
"""قالب واحد payload اعلان برای WebSocket (هم push لحظه‌ای هم لیست خوانده‌نشده)."""
from .defaults import TYPE_LABELS


def notification_payload(log):
    created = log.created_at.isoformat() if log.created_at else None
    return {
        'id': log.id,
        # فرانت‌اند title/message می‌خواند؛ تست‌ها/کلاینت‌های قدیمی subject/content.
        'title': log.subject,
        'message': log.content,
        'subject': log.subject,
        'content': log.content,
        'created_at': created,
        'type': log.type,
        'type_label': TYPE_LABELS.get(log.type, ''),
        'status': log.status,
        'is_read': bool(log.is_read),
    }

# backend/notifications/serializers.py
from rest_framework import serializers
from django.utils import timezone
from .models import NotificationTemplate, NotificationLog
from .defaults import TYPE_LABELS
# ✅ استفاده از edra_jalalidate به‌جای jdatetime
from edra_jalalidate import to_jalali as _to_jalali


def to_jalali(dt):
    """
    تبدیل datetime به رشته جلالی با فرمت "%Y/%m/%d - %H:%M"
    اگر ورودی None باشد، None برگردانده می‌شود.
    """
    if not dt:
        return None
    # استفاده از تابع edra_jalalidate با فرمت مورد نظر
    return _to_jalali(dt, fmt="%Y/%m/%d - %H:%M")


class NotificationTemplateSerializer(serializers.ModelSerializer):
    created_at_jalali = serializers.SerializerMethodField()
    updated_at_jalali = serializers.SerializerMethodField()

    class Meta:
        model = NotificationTemplate
        fields = '__all__'

    def get_created_at_jalali(self, obj):
        return to_jalali(obj.created_at)

    def get_updated_at_jalali(self, obj):
        return to_jalali(obj.updated_at)


class NotificationLogSerializer(serializers.ModelSerializer):
    """نسخه‌ی کامل — فقط برای ادمین (شامل گیرنده و خطای ارسال)."""
    created_at_jalali = serializers.SerializerMethodField()
    sent_at_jalali = serializers.SerializerMethodField()
    user_username = serializers.CharField(source='user.username', read_only=True)
    type_label = serializers.SerializerMethodField()
    template_code = serializers.CharField(source='template.code', read_only=True)

    class Meta:
        model = NotificationLog
        fields = '__all__'

    def get_type_label(self, obj):
        return TYPE_LABELS.get(obj.type, obj.type)

    def to_representation(self, instance):
        data = super().to_representation(instance)
        # لاگ‌های قدیمی ممکن است کلید API را در متن خطا داشته باشند.
        from .services import _redact
        data['error_message'] = _redact(data.get('error_message'))
        return data

    def get_created_at_jalali(self, obj):
        return to_jalali(obj.created_at)

    def get_sent_at_jalali(self, obj):
        return to_jalali(obj.sent_at)


class NotificationInboxSerializer(serializers.ModelSerializer):
    """
    EDRA v33 — SEC: نسخه‌ی مخصوص صاحب اعلان (مشتری/کارشناس/مدیر).
    قبلاً /api/core/notifications/ از NotificationLogSerializer با fields='__all__'
    استفاده می‌کرد و به هر کاربر recipient، error_message (که می‌توانست شامل URL
    و کلید API پیامک باشد)، شناسه‌ی کاربر و قالب را می‌داد.
    """
    created_at_jalali = serializers.SerializerMethodField()
    type_label = serializers.SerializerMethodField()

    class Meta:
        model = NotificationLog
        fields = ('id', 'type', 'type_label', 'subject', 'content',
                  'is_read', 'created_at', 'created_at_jalali')
        read_only_fields = fields

    def get_created_at_jalali(self, obj):
        return to_jalali(obj.created_at)

    def get_type_label(self, obj):
        return TYPE_LABELS.get(obj.type, '')
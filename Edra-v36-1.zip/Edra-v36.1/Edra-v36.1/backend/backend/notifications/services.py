# notifications/services.py
# -*- coding: utf-8 -*-
"""
EDRA v33 — هسته‌ی ارسال اعلان (بازنویسی کامل).

اصلاحات ریشه‌ای نسبت به v32:
  • اعلان درون‌برنامه‌ای (داشبورد/زنگوله) *همیشه* ساخته می‌شود؛ قبلاً اگر کاربر
    ایمیل/موبایل معتبر نداشت (مشتری OTP برای قالب ایمیلی، یا مدیر/کارشناسی که
    username‌اش موبایل نیست) هیچ لاگی ساخته نمی‌شد و اعلان کاملاً گم می‌شد.
  • هر کانال خارجی گیرنده‌ی مخصوص خودش را دارد: قبلاً در کانال «both» شماره
    موبایل به send_mail داده می‌شد، ایمیل شکست می‌خورد و پیامک هرگز ارسال نمی‌شد.
  • قالب‌های پیش‌فرض خودترمیم‌اند (defaults.py) — نبود seed دیگر اعلان را حذف نمی‌کند.
  • ارسال خارجی در یک تابع واحد (deliver_log) با قفل سطری انجام می‌شود تا مسیر
    sync و تسک Celery هرگز یک پیام را دوبار نفرستند.
  • کلید API پیامک هرگز در error_message / لاگ ثبت نمی‌شود.
  • قالب‌ها با autoescape خاموش رندر می‌شوند (پیامک متن ساده است؛ قبلاً & و < و '
    در پیامک به‌صورت &amp; و &#x27; می‌رفت).
"""
import logging
import re
from urllib.parse import urlparse

from django.conf import settings
from django.core.mail import send_mail
from django.db import transaction
from django.template import Context, Template
from django.utils import timezone

from .defaults import DEFAULT_TEMPLATES_BY_CODE
from .models import NotificationLog, NotificationTemplate

logger = logging.getLogger(__name__)


class SMSProviderNotConfiguredError(Exception):
    """در Production بدون provider پیامک، ارسال SMS مجاز نیست."""


# ----------------------------------------------------------------------
# ابزار شماره موبایل / ایمیل
# ----------------------------------------------------------------------
_DIGITS = str.maketrans('۰۱۲۳۴۵۶۷۸۹٠١٢٣٤٥٦٧٨٩', '01234567890123456789')
_MOBILE_RE = re.compile(r'^09\d{9}$')
_EMAIL_RE = re.compile(r'^[^@\s]+@[^@\s]+\.[^@\s]+$')


def normalize_phone(value):
    """
    ۰۹۱۲… / +98912… / 0098912… / 98912… / 912… → «0912…».
    اگر موبایل ایرانی معتبر نباشد رشته‌ی خالی برمی‌گردد.
    """
    if not value:
        return ''
    s = str(value).strip().translate(_DIGITS)
    s = re.sub(r'[\s\-()]', '', s)
    if s.startswith('+'):
        s = s[1:]
    if s.startswith('0098'):
        s = s[4:]
    elif s.startswith('98') and len(s) == 12:
        s = s[2:]
    if len(s) == 10 and s.startswith('9'):
        s = '0' + s
    return s if _MOBILE_RE.match(s) else ''


def resolve_phone(user):
    """موبایل معتبر کاربر: ابتدا profile.phone، سپس username (کاربران OTP)."""
    profile = getattr(user, 'profile', None)
    for candidate in (getattr(profile, 'phone', None),
                      getattr(user, 'username', None)):
        phone = normalize_phone(candidate)
        if phone:
            return phone
    return ''


def resolve_email(user):
    email = (getattr(user, 'email', '') or '').strip()
    return email if _EMAIL_RE.match(email) else ''


def _split_recipient(recipient):
    """رشته‌ی گیرنده‌ی ذخیره‌شده در لاگ ('0912…, a@b.com') → (phone, email)."""
    phone = email = ''
    for token in re.split(r'[,\s|]+', recipient or ''):
        if not token:
            continue
        if '@' in token and _EMAIL_RE.match(token):
            email = token
        else:
            p = normalize_phone(token)
            if p:
                phone = p
    return phone, email


# ----------------------------------------------------------------------
# امنیت: مخفی‌کردن کلید API از پیام‌های خطا
# ----------------------------------------------------------------------
def _redact(text):
    text = str(text or '')
    key = getattr(settings, 'SMS_API_KEY', '') or ''
    if key:
        text = text.replace(key, '***')
    # الگوی URL کاوه‌نگار (اگر کلید دیگری بود)
    text = re.sub(r'(api\.kavenegar\.com/v1/)[^/\s]+', r'\1***', text)
    return text[:500]


def format_otp_sms_body(code, prefix="کد تایید ادرو"):
    """
    متن پیامک OTP برای تکمیل خودکار (WebOTP API): آخرین خط باید دقیقاً
    «@دامنه #کد» باشد. دامنه از FRONTEND_URL استخراج می‌شود.
    """
    frontend_host = urlparse(settings.FRONTEND_URL).netloc or 'localhost:3000'
    return f"{prefix}: {code}\n@{frontend_host} #{code}"


# ----------------------------------------------------------------------
# ارسال پیامک
# ----------------------------------------------------------------------
def _send_sms_via_provider(recipient, text):
    """
    ارسال SMS از طریق Kavenegar (SMS_PROVIDER=kavenegar, SMS_API_KEY=...).
    محتوای پیام (ممکن است OTP باشد) هرگز لاگ نمی‌شود؛ کلید API هم هرگز در
    خطاها نمی‌آید. خروجی: (success: bool, error_message: str|None)
    """
    provider = getattr(settings, 'SMS_PROVIDER', None)
    api_key = getattr(settings, 'SMS_API_KEY', '')
    fail_closed = getattr(settings, 'SMS_FAIL_CLOSED', False)

    if not provider or not api_key:
        if fail_closed:
            return False, 'SMS_PROVIDER/SMS_API_KEY تنظیم نشده است.'
        logger.info(f"[SMS MOCK] to={recipient} (بدون ارسال واقعی)")
        return True, None

    if provider == 'kavenegar':
        receptor = normalize_phone(recipient) or str(recipient)
        try:
            import requests
            url = f'https://api.kavenegar.com/v1/{api_key}/sms/send.json'
            data = {'receptor': receptor, 'message': text}
            sender = getattr(settings, 'SMS_SENDER', '')
            if sender:
                data['sender'] = sender
            resp = requests.post(url, data=data, timeout=10)
            try:
                resp.raise_for_status()
            except Exception as http_error:
                detail = ''
                try:
                    detail = (resp.json().get('return') or {}).get('message', '')
                except Exception:
                    pass
                msg = _redact(detail or http_error)
                logger.error(f"Kavenegar HTTP error for {receptor}: {msg}")
                return False, msg
            result = resp.json()
            status = (result.get('return') or {}).get('status')
            if status != 200:
                message = (result.get('return') or {}).get('message', 'نامشخص')
                logger.error(f"Kavenegar returned status {status}: {message}")
                return False, _redact(message)
            return True, None
        except Exception as e:
            msg = _redact(e)
            logger.error(f"Kavenegar SMS failed for {receptor}: {msg}")
            return False, msg

    logger.error(f"Unknown SMS_PROVIDER: {provider}")
    return False, f'SMS_PROVIDER نامعتبر است: {provider}'


def send_sms(phone, message):
    """
    ارسال مستقیم SMS (مثلاً OTP) با fail-closed. در Production بدون provider →
    SMSProviderNotConfiguredError؛ هر شکست دیگر → RuntimeError (بدون کلید API).
    """
    provider = getattr(settings, 'SMS_PROVIDER', None)
    api_key = getattr(settings, 'SMS_API_KEY', '')
    fail_closed = getattr(settings, 'SMS_FAIL_CLOSED', False)
    if fail_closed and (not provider or not api_key):
        raise SMSProviderNotConfiguredError(
            'SMS_PROVIDER/SMS_API_KEY تنظیم نشده است و SMS fail-closed است.')
    ok, error = _send_sms_via_provider(phone, message)
    if not ok:
        raise RuntimeError(error or 'ارسال SMS ناموفق بود.')
    return True


# ----------------------------------------------------------------------
# قالب‌ها
# ----------------------------------------------------------------------
def get_template(template_code):
    """
    قالب فعال با این کد. اگر در دیتابیس نبود ولی در defaults.py تعریف شده بود،
    ساخته می‌شود (خودترمیم). قالب غیرفعال‌شده‌ی عمدی ادمین احترام می‌شود.
    """
    template = NotificationTemplate.objects.filter(code=template_code).first()
    if template is not None:
        return template if template.is_active else None
    default = DEFAULT_TEMPLATES_BY_CODE.get(template_code)
    if default is None:
        return None
    template, _ = NotificationTemplate.objects.get_or_create(
        code=template_code,
        defaults={
            'channel': default['channel'],
            'subject': default['subject'],
            'body_template': default['body_template'],
            'is_active': True,
        })
    logger.warning(f"Notification template '{template_code}' was missing; "
                   f"created from defaults.")
    return template if template.is_active else None


def _render(source, context):
    """رندر Django Template بدون autoescape؛ با قالب خراب، متن خام برمی‌گردد."""
    try:
        return Template(source or '').render(Context(context, autoescape=False))
    except Exception as e:
        logger.error(f"Notification template render failed: {e}")
        return source or ''


def get_admin_users():
    """همه‌ی مدیران فعال (staff / superuser / گروه Admin) — یک تعریف برای کل پروژه."""
    from django.contrib.auth import get_user_model
    from django.db.models import Q
    return get_user_model().objects.filter(
        Q(is_staff=True) | Q(is_superuser=True) | Q(groups__name='Admin'),
        is_active=True).distinct()


# ----------------------------------------------------------------------
# تحویل خارجی (ایمیل / پیامک) برای یک لاگ
# ----------------------------------------------------------------------
def deliver_log(log):
    """
    ارسال خارجی یک NotificationLog در وضعیت pending و به‌روزرسانی وضعیت آن.
    هرگز exception نمی‌دهد و لاگ نهایی را برمی‌گرداند.

    نتیجه:
      • حداقل یک کانال خارجی موفق → sent
      • کانال خارجی تلاش شد و همه شکست خوردند → failed (error_message بدون کلید API)
      • هیچ کانال خارجی قابل‌اجرا نبود (in_app یا گیرنده‌ی معتبر نبود) → sent
        (اعلان درون‌برنامه‌ای تحویل شده؛ توضیح در error_message)
    قفل سطری تضمین می‌کند مسیر sync و تسک دوره‌ای یک پیام را دوبار نفرستند.
    """
    try:
        with transaction.atomic():
            locked = (NotificationLog.objects.select_for_update()
                      .select_related('user').filter(pk=log.pk).first())
            if locked is None:
                return log
            if locked.status != 'pending':
                return locked

            user = locked.user
            body, subject = locked.content, locked.subject
            phone, email = _split_recipient(locked.recipient)
            channel = locked.channel
            errors, ok_channels, attempted = [], 0, 0

            if channel in ('email', 'both'):
                email = email or resolve_email(user)
                if email:
                    attempted += 1
                    try:
                        send_mail(
                            subject=subject, message=body,
                            from_email=settings.DEFAULT_FROM_EMAIL,
                            recipient_list=[email], fail_silently=False)
                        ok_channels += 1
                    except Exception as e:
                        errors.append(f'email: {_redact(e)}')
            if channel in ('sms', 'both'):
                phone = phone or resolve_phone(user)
                if phone:
                    attempted += 1
                    ok, err = _send_sms_via_provider(phone, body)
                    if ok:
                        ok_channels += 1
                    else:
                        errors.append(f'SMS provider error: {_redact(err)}')

            targets = ', '.join(x for x in (phone, email) if x)
            if targets:
                locked.recipient = targets[:255]

            if attempted == 0:
                locked.status = 'sent'
                locked.error_message = (
                    '' if channel == 'in_app' else
                    'گیرنده‌ی پیامک/ایمیل معتبر یافت نشد؛ فقط درون‌برنامه‌ای.')
            elif ok_channels > 0:
                locked.status = 'sent'
                locked.error_message = '; '.join(errors)
            else:
                locked.status = 'failed'
                locked.error_message = '; '.join(errors) or 'ارسال ناموفق بود.'
            if locked.status == 'sent':
                locked.sent_at = timezone.now()
            locked.save(update_fields=[
                'status', 'error_message', 'sent_at', 'recipient'])
            if locked.status == 'failed':
                logger.error(f"Notification {locked.pk} failed: "
                             f"{locked.error_message}")
            return locked
    except Exception as e:  # هرگز جریان اصلی کسب‌وکار را نشکن
        logger.error(f"deliver_log crashed for {getattr(log, 'pk', None)}: "
                     f"{_redact(e)}")
        return log


# ----------------------------------------------------------------------
# API اصلی
# ----------------------------------------------------------------------
def send_notification(user, template_code, context=None, extra_recipient=None,
                      deliver=True):
    """
    ساخت اعلان (همیشه درون‌برنامه‌ای) و ارسال خارجی بر اساس کانال قالب.

    user: دریافت‌کننده | template_code: کد قالب | context: متغیرهای قالب
    extra_recipient: ایمیل/موبایل دلخواه به‌جای مقادیر کاربر
    deliver=False: فقط در صف (pending) قرار می‌گیرد (تسک دوره‌ای می‌فرستد)
    خروجی: NotificationLog یا None (کاربر/قالب نامعتبر). هرگز برای نبود
    گیرنده‌ی خارجی exception نمی‌دهد.
    """
    if user is None:
        return None
    template = get_template(template_code)
    if template is None:
        logger.error(f"Template {template_code} not found or inactive.")
        return None

    ctx = dict(context or {})
    ctx['user'] = user
    ctx['site_url'] = getattr(settings, 'SITE_URL', 'http://localhost:8000')
    body = _render(template.body_template, ctx)
    subject = _render(template.subject, ctx)[:200]

    phone = email = ''
    if extra_recipient:
        phone, email = _split_recipient(str(extra_recipient))
    channel = template.channel
    if channel in ('sms', 'both'):
        phone = phone or resolve_phone(user)
    if channel in ('email', 'both'):
        email = email or resolve_email(user)
    recipient = ', '.join(x for x in (
        phone if channel in ('sms', 'both') else '',
        email if channel in ('email', 'both') else '') if x)

    log = NotificationLog.objects.create(
        user=user, template=template, channel=channel, type=template_code,
        recipient=recipient[:255], subject=subject, content=body,
        status='pending')
    if deliver:
        log = deliver_log(log)
    return log


def queue_notification(user, template_code, context=None):
    """ساخت اعلان در صف (برای حلقه‌های بزرگ)؛ ارسال خارجی با process_pending."""
    return send_notification(user, template_code, context, deliver=False)

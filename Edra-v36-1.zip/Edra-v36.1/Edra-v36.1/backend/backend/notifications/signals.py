# notifications/signals.py
# -*- coding: utf-8 -*-
import logging

from asgiref.sync import async_to_sync
from channels.layers import get_channel_layer
from django.db import transaction
from django.db.models.signals import post_save
from django.dispatch import receiver

from .models import NotificationLog
from .payloads import notification_payload

logger = logging.getLogger(__name__)


@receiver(post_save, sender=NotificationLog)
def notification_created(sender, instance, created, **kwargs):
    """
    push لحظه‌ای اعلان جدید به WebSocket کاربر.

    EDRA v33: (۱) این سیگنال تا v32 هرگز ثبت نمی‌شد (apps.ready وجود نداشت)؛
    (۲) push بعد از commit انجام می‌شود تا اگر تراکنش بیرونی rollback شد،
    کاربر اعلانی نبیند که در دیتابیس وجود ندارد.
    """
    if not created:
        return
    user_id = instance.user_id
    payload = notification_payload(instance)

    def _push():
        try:
            layer = get_channel_layer()
            if layer is None:
                return
            async_to_sync(layer.group_send)(
                f'user_{user_id}',
                {'type': 'send_notification', 'data': payload})
        except Exception as e:  # ارسال لحظه‌ای best-effort است
            logger.warning(f"WebSocket push failed for user {user_id}: {e}")

    transaction.on_commit(_push)

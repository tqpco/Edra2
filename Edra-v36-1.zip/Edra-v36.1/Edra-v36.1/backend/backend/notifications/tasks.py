# notifications/tasks.py
# -*- coding: utf-8 -*-
import logging
from datetime import timedelta

from celery import shared_task
from django.utils import timezone

from .models import NotificationLog
from .services import deliver_log

logger = logging.getLogger(__name__)

# سقف پردازش هر اجرا (هر ۵ دقیقه) و حداکثر عمر مجاز در صف
BATCH_SIZE = 200
MAX_PENDING_AGE = timedelta(hours=24)


@shared_task
def process_pending_notifications():
    """
    ارسال واقعی اعلان‌های صف‌شده (status='pending') — مثلاً کد تخفیف، هشدار
    انقضا و broadcast ها.

    EDRA v33 — باگ‌های v32 که اینجا رفع شد:
      • پیامک اصلاً ارسال نمی‌شد: فقط logger.info می‌زد و لاگ را «sent» می‌کرد
        (و متن پیام — حتی OTP — را در لاگ می‌نوشت).
      • برای کاربران بدون profile.phone (مشتریان OTP) گیرنده «یافت نشد» می‌شد.
    حالا از همان deliver_log مسیر sync استفاده می‌شود (قفل سطری → بدون
    ارسال دوباره) و لاگ‌های خیلی قدیمی به‌جای ارسال دیرهنگام منقضی می‌شوند.
    """
    now = timezone.now()
    expired = NotificationLog.objects.filter(
        status='pending', created_at__lt=now - MAX_PENDING_AGE
    ).update(status='failed',
             error_message='منقضی شد: بیش از ۲۴ ساعت در صف ارسال ماند.')

    ids = list(
        NotificationLog.objects.filter(status='pending')
        .order_by('created_at').values_list('id', flat=True)[:BATCH_SIZE])
    sent = failed = 0
    for pk in ids:
        log = NotificationLog.objects.filter(pk=pk).first()
        if log is None:
            continue
        result = deliver_log(log)
        if result.status == 'sent':
            sent += 1
        elif result.status == 'failed':
            failed += 1

    if ids or expired:
        logger.info(
            f"process_pending_notifications: {sent} sent, {failed} failed, "
            f"{expired} expired (batch={len(ids)}).")
    return {'sent': sent, 'failed': failed, 'expired': expired}

# pricing/admin.py
# -*- coding: utf-8 -*-

from django.contrib import admin
from django import forms
from django.utils.html import format_html
from django.urls import reverse

# ✅ اصلاح: ایمپورت مستقیم از پکیج edra_jalalidate
from edra_jalalidate.admin import EdraJalaliAdminMixin
from edra_jalalidate import to_jalali

from .models import PricingRule, PricingRuleChangeLog, PriceCalculationLog, ParameterPrice
from core.models import EquipmentParameter


class JalaliDateDisplayMixin:
    """نمایش تاریخ‌های خام به‌صورت جلالی در ستون‌های لیست ادمین"""

    def created_at_display(self, obj):
        return to_jalali(obj.created_at, fmt="%Y/%m/%d - %H:%M")
    created_at_display.short_description = "تاریخ ایجاد"

    def updated_at_display(self, obj):
        return to_jalali(obj.updated_at, fmt="%Y/%m/%d - %H:%M")
    updated_at_display.short_description = "تاریخ بروزرسانی"


class ParameterPriceForm(forms.ModelForm):
    class Meta:
        model = ParameterPrice
        fields = '__all__'

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        # اگر در حالت ویرایش هستیم و pricing_rule وجود دارد، لیست کشویی را
        # فیلتر می‌کنیم
        if self.instance and self.instance.pk and self.instance.pricing_rule:
            self.fields['parameter'].queryset = EquipmentParameter.objects.filter(
                equipment_type=self.instance.pricing_rule.equipment_type)
        # اگر فرم در حالت افزودن است و نوع تجهیزات در POST انتخاب شده، فیلتر
        # می‌کنیم
        elif 'pricing_rule' in self.data:
            try:
                rule_id = self.data.get('pricing_rule')
                if rule_id:
                    rule = PricingRule.objects.get(pk=rule_id)
                    self.fields['parameter'].queryset = EquipmentParameter.objects.filter(
                        equipment_type=rule.equipment_type)
            except (PricingRule.DoesNotExist, ValueError):
                pass


class ParameterPriceInline(admin.TabularInline):
    model = ParameterPrice
    form = ParameterPriceForm
    extra = 1
    fields = ('parameter', 'rate_type', 'rate')
    ordering = ('parameter__order',)


@admin.register(PricingRule)
class PricingRuleAdmin(JalaliDateDisplayMixin, EdraJalaliAdminMixin, admin.ModelAdmin):
    inlines = [ParameterPriceInline]
    list_display = (
        'equipment_type',
        'base_price_display',
        'install_price_display',
        'dismantle_price_display',
        'standard_multiplier_display',
        'pro_multiplier_display',
        'updated_at_display'
    )
    list_filter = ('equipment_type',)
    search_fields = ('equipment_type__name_fa', 'equipment_type__code')
    readonly_fields = ('updated_at_display', 'created_at_display', 'updated_by')
    list_display_links = ('equipment_type',)

    fieldsets = (
        ('اطلاعات پایه', {
            'fields': ('equipment_type',)
        }),
        ('روش ۱: قیمت پایه و پارامترها', {
            'fields': ('base_price',),
            'description': 'پارامترها در بخش پایین مدیریت می‌شوند.'
        }),
        ('روش ۲: قیمت نصب و دمونتاژ', {'fields': ('install_price', 'dismantle_price')}),
        ('روش ۴: ضریب خدمات', {'fields': ('standard_multiplier', 'pro_multiplier')}),
        ('تنظیمات پیشرفته', {'fields': ('custom_formula',), 'classes': ('collapse',)}),
        ('اطلاعات سیستمی', {'fields': ('updated_by', 'updated_at_display', 'created_at_display'), 'classes': ('collapse',)}),
    )

    def base_price_display(self, obj):
        return f"{obj.base_price:,} تومان"
    base_price_display.short_description = "قیمت پایه"

    def install_price_display(self, obj):
        return f"{obj.install_price:,} تومان"
    install_price_display.short_description = "هزینه نصب"

    def dismantle_price_display(self, obj):
        return f"{obj.dismantle_price:,} تومان"
    dismantle_price_display.short_description = "هزینه دمونتاژ"

    def standard_multiplier_display(self, obj):
        return f"{obj.standard_multiplier:.2f}"
    standard_multiplier_display.short_description = "ضریب استاندارد"

    def pro_multiplier_display(self, obj):
        return f"{obj.pro_multiplier:.2f}"
    pro_multiplier_display.short_description = "ضریب حرفه‌ای"

    def updated_at_display(self, obj):
        return to_jalali(obj.updated_at, fmt="%Y/%m/%d - %H:%M")
    updated_at_display.short_description = "آخرین بروزرسانی"

    def save_model(self, request, obj, form, change):
        obj.updated_by = request.user
        super().save_model(request, obj, form, change)


@admin.register(PricingRuleChangeLog)
class PricingRuleChangeLogAdmin(
        JalaliDateDisplayMixin, EdraJalaliAdminMixin, admin.ModelAdmin):
    list_display = (
        'pricing_rule',
        'changed_by',
        'baseline_check_passed',
        'created_at_display')
    list_filter = ('baseline_check_passed',)
    search_fields = (
        'pricing_rule__equipment_type__name_fa',
        'changed_by__username')
    readonly_fields = ('before', 'after', 'created_at_display')


@admin.register(PriceCalculationLog)
class PriceCalculationLogAdmin(
        JalaliDateDisplayMixin, EdraJalaliAdminMixin, admin.ModelAdmin):
    list_display = (
        'inspection_request',
        'calculated_price_display',
        'service_type',
        'city_multiplier',
        'install_state',
        'created_at_display'
    )
    list_filter = ('service_type', 'install_state')
    search_fields = ('inspection_request__id',)

    def calculated_price_display(self, obj):
        return f"{obj.calculated_price:,} تومان"
    calculated_price_display.short_description = "قیمت محاسبه‌شده"
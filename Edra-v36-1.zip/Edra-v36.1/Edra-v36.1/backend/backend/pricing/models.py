# pricing/models.py
from django.db import models
from django.contrib.auth import get_user_model
from core.models import EquipmentType, CityMultiplier, EquipmentParameter

User = get_user_model()


class PricingRule(models.Model):
    class ServiceType(models.TextChoices):
        STANDARD = 'standard', 'استاندارد'
        PRO = 'pro', 'حرفه‌ای'

    equipment_type = models.OneToOneField(
        EquipmentType,
        on_delete=models.CASCADE,
        related_name='pricing_rule',
        verbose_name='نوع تجهیزات'
    )

    base_price = models.DecimalField(
        max_digits=15, decimal_places=0,
        verbose_name='قیمت پایه (تومان)'
    )

    install_price = models.DecimalField(
        max_digits=15, decimal_places=0,
        default=0,
        verbose_name='هزینه نصب (تومان)'
    )
    dismantle_price = models.DecimalField(
        max_digits=15, decimal_places=0,
        default=0,
        verbose_name='هزینه دمونتاژ (تومان)'
    )

    standard_multiplier = models.DecimalField(
        max_digits=5, decimal_places=2,
        default=1.00,
        verbose_name='ضریب خدمات استاندارد'
    )
    pro_multiplier = models.DecimalField(
        max_digits=5, decimal_places=2,
        default=1.50,
        verbose_name='ضریب خدمات حرفه‌ای'
    )

    custom_formula = models.TextField(
        blank=True,
        verbose_name='فرمول سفارشی',
        help_text='در صورت نیاز، فرمول محاسبه قیمت به صورت عبارت Python'
    )

    updated_by = models.ForeignKey(
        User,
        on_delete=models.PROTECT,
        null=True,
        blank=True,
        verbose_name='بروزرسانی‌شده توسط'
    )
    updated_at = models.DateTimeField(
        auto_now=True, verbose_name='تاریخ بروزرسانی')
    created_at = models.DateTimeField(
        auto_now_add=True, verbose_name='تاریخ ایجاد')

    class Meta:
        verbose_name = 'قانون قیمت‌گذاری'
        verbose_name_plural = 'قوانین قیمت‌گذاری'
        ordering = ['equipment_type__name_fa']

    def __str__(self):
        return f"قیمت {self.equipment_type.name_fa}"

    def save(self, *args, **kwargs):
        if self.pk:
            try:
                old = PricingRule.objects.get(pk=self.pk)
                if (old.base_price != self.base_price or
                    old.install_price != self.install_price or
                    old.dismantle_price != self.dismantle_price or
                    old.standard_multiplier != self.standard_multiplier or
                        old.pro_multiplier != self.pro_multiplier):
                    PricingRuleChangeLog.objects.create(
                        pricing_rule=self,
                        changed_by=self.updated_by,
                        before={
                            'base_price': str(old.base_price),
                            'install_price': str(old.install_price),
                            'dismantle_price': str(old.dismantle_price),
                            'standard_multiplier': str(old.standard_multiplier),
                            'pro_multiplier': str(old.pro_multiplier),
                        },
                        after={
                            'base_price': str(self.base_price),
                            'install_price': str(self.install_price),
                            'dismantle_price': str(self.dismantle_price),
                            'standard_multiplier': str(self.standard_multiplier),
                            'pro_multiplier': str(self.pro_multiplier),
                        }
                    )
            except PricingRule.DoesNotExist:
                pass
        super().save(*args, **kwargs)


class ParameterPrice(models.Model):
    RATE_TYPE_CHOICES = [
        ('fixed', 'ثابت'),
        ('per_unit', 'ضریب در مقدار'),
    ]

    pricing_rule = models.ForeignKey(
        PricingRule,
        on_delete=models.CASCADE,
        related_name='parameter_prices',
        verbose_name='قانون قیمت‌گذاری'
    )

    parameter = models.ForeignKey(
        EquipmentParameter,
        on_delete=models.CASCADE,
        null=True,
        blank=True,
        verbose_name='پارامتر'
    )

    rate_type = models.CharField(
        max_length=20,
        choices=RATE_TYPE_CHOICES,
        default='fixed',
        verbose_name='نوع محاسبه'
    )

    rate = models.DecimalField(
        max_digits=15, decimal_places=0,
        default=0,
        verbose_name='نرخ (تومان)'
    )

    class Meta:
        unique_together = ('pricing_rule', 'parameter')
        verbose_name = 'نرخ پارامتر'
        verbose_name_plural = 'نرخ‌های پارامترها'

    def __str__(self):
        return f"{self.pricing_rule.equipment_type.name_fa} - {self.parameter.label if self.parameter else 'نامشخص'}: {self.rate} ({self.get_rate_type_display()})"


class PricingRuleChangeLog(models.Model):
    pricing_rule = models.ForeignKey(
        PricingRule,
        on_delete=models.CASCADE,
        related_name='changelog',
        verbose_name='قانون قیمت'
    )
    changed_by = models.ForeignKey(
        User,
        on_delete=models.PROTECT,
        verbose_name='تغییردهنده'
    )
    before = models.JSONField(verbose_name='مقدار قبلی')
    after = models.JSONField(verbose_name='مقدار جدید')
    baseline_check_passed = models.BooleanField(
        default=True,
        verbose_name='تأیید خط مبنا'
    )
    created_at = models.DateTimeField(
        auto_now_add=True, verbose_name='تاریخ ایجاد')

    class Meta:
        verbose_name = 'تاریخچه تغییرات قیمت'
        verbose_name_plural = 'تاریخچه تغییرات قیمت‌ها'
        ordering = ['-created_at']

    def __str__(self):
        return f"{self.pricing_rule} - {self.created_at.strftime('%Y/%m/%d %H:%M')}"


class PriceCalculationLog(models.Model):
    inspection_request = models.ForeignKey(
        'core.InspectionRequest',
        on_delete=models.CASCADE,
        null=True,
        blank=True,
        related_name='price_logs',
        verbose_name='درخواست بازرسی'
    )
    rule_version = models.ForeignKey(
        PricingRule,
        on_delete=models.SET_NULL,
        null=True,
        verbose_name='قانون استفاده‌شده'
    )
    calculated_price = models.DecimalField(
        max_digits=15, decimal_places=0,
        verbose_name='قیمت محاسبه‌شده'
    )
    params_used = models.JSONField(verbose_name='پارامترهای استفاده‌شده')
    service_type = models.CharField(
        max_length=20,
        choices=PricingRule.ServiceType.choices,
        verbose_name='نوع سرویس'
    )
    city_multiplier = models.DecimalField(
        max_digits=5, decimal_places=2,
        verbose_name='ضریب شهر'
    )
    install_state = models.CharField(
        max_length=20,
        null=True,
        blank=True,
        verbose_name='وضعیت نصب'
    )
    created_at = models.DateTimeField(
        auto_now_add=True, verbose_name='تاریخ ایجاد')

    class Meta:
        verbose_name = 'لاگ محاسبه قیمت'
        verbose_name_plural = 'لاگ‌های محاسبه قیمت'
        ordering = ['-created_at']

    def __str__(self):
        return f"قیمت {self.calculated_price:,} - {self.service_type}"
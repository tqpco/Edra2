from rest_framework import serializers
from django.utils import timezone
from .models import PricingRule, PricingRuleChangeLog, PriceCalculationLog, ParameterPrice
from core.models import EquipmentType
# ✅ استفاده از edra_jalalidate به‌جای jdatetime
from edra_jalalidate import to_jalali as _to_jalali


def to_jalali(dt):
    """
    تبدیل datetime به رشته جلالی با فرمت "%Y/%m/%d - %H:%M"
    اگر ورودی None باشد، None برگردانده می‌شود.
    """
    if not dt:
        return None
    # استفاده از تابع edra_jalalidate با فرمت مورد نظر
    return _to_jalali(dt, fmt="%Y/%m/%d - %H:%M")


class ParameterPriceSerializer(serializers.ModelSerializer):
    parameter_name = serializers.CharField(source='parameter.name', read_only=True)
    parameter_label = serializers.CharField(source='parameter.label', read_only=True)
    parameter_field_type = serializers.CharField(source='parameter.field_type', read_only=True)
    parameter_options = serializers.CharField(source='parameter.options', read_only=True)

    class Meta:
        model = ParameterPrice
        fields = [
            'id', 'pricing_rule', 'parameter', 'parameter_name',
            'parameter_label', 'parameter_field_type', 'parameter_options',
            'rate_type', 'rate'
        ]
        read_only_fields = ('id',)

    def validate_rate(self, value):
        # EDRA v36: نرخ منفی هزینه‌ی پارامتر را «کم» می‌کند و قیمت نهایی را
        # می‌شکند؛ قبلاً هیچ اعتبارسنجی نداشت.
        if value is not None and value < 0:
            raise serializers.ValidationError('نرخ نمی‌تواند منفی باشد.')
        return value

    def validate(self, attrs):
        # پارامتر باید متعلق به همان تجهیزِ قانون قیمت‌گذاری باشد؛ در غیر این صورت
        # (فقط با تطبیق «نام») قیمت پارامتر تجهیز دیگر اشتباه اعمال می‌شود.
        rule = attrs.get('pricing_rule') or getattr(self.instance, 'pricing_rule', None)
        param = attrs.get('parameter') or getattr(self.instance, 'parameter', None)
        if rule is not None and param is not None and (
                param.equipment_type_id != rule.equipment_type_id):
            raise serializers.ValidationError(
                {'parameter': 'این پارامتر متعلق به همین نوع تجهیز نیست.'})
        return attrs


class PricingRuleSerializer(serializers.ModelSerializer):
    equipment_type_name = serializers.CharField(
        source='equipment_type.name_fa', read_only=True)
    equipment_type_code = serializers.CharField(
        source='equipment_type.code', read_only=True)
    created_at_jalali = serializers.SerializerMethodField()
    updated_at_jalali = serializers.SerializerMethodField()

    class Meta:
        model = PricingRule
        fields = '__all__'
        read_only_fields = ('id', 'created_at', 'updated_at')

    def get_created_at_jalali(self, obj):
        return to_jalali(obj.created_at)

    def get_updated_at_jalali(self, obj):
        return to_jalali(obj.updated_at)

    def validate(self, data):
        # EDRA v36: در PATCH (partial) فیلدِ ارسال‌نشده نباید «۰» فرض شود؛ قبلاً
        # هر PATCH ناقص (مثلاً فقط base_price) با «ضریب باید بزرگتر از صفر باشد»
        # رد می‌شد. مقدار پیشینِ نمونه جایگزین می‌شود.
        inst = getattr(self, 'instance', None)

        def _cur(key, default=0):
            if key in data:
                return data[key]
            return getattr(inst, key, default) if inst is not None else default

        standard_multiplier = _cur('standard_multiplier')
        pro_multiplier = _cur('pro_multiplier')

        if standard_multiplier <= 0:
            raise serializers.ValidationError(
                {"standard_multiplier": "ضریب خدمات استاندارد باید بزرگتر از صفر باشد."}
            )

        if pro_multiplier <= 0:
            raise serializers.ValidationError(
                {"pro_multiplier": "ضریب خدمات حرفه‌ای باید بزرگتر از صفر باشد."}
            )

        if pro_multiplier < standard_multiplier:
            raise serializers.ValidationError(
                {"pro_multiplier": "ضریب خدمات حرفه‌ای باید از ضریب استاندارد بیشتر باشد."}
            )

        base_price = _cur('base_price')
        if base_price <= 0:
            raise serializers.ValidationError(
                {"base_price": "قیمت پایه باید بیشتر از صفر باشد."}
            )

        install_price = _cur('install_price')
        dismantle_price = _cur('dismantle_price')

        if install_price < 0:
            raise serializers.ValidationError(
                {"install_price": "هزینه نصب نمی‌تواند منفی باشد."}
            )

        if dismantle_price < 0:
            raise serializers.ValidationError(
                {"dismantle_price": "هزینه دمونتاژ نمی‌تواند منفی باشد."}
            )

        return data


class PricingRuleChangeLogSerializer(serializers.ModelSerializer):
    pricing_rule_name = serializers.CharField(
        source='pricing_rule.equipment_type.name_fa', read_only=True)
    changed_by_name = serializers.CharField(
        source='changed_by.username', read_only=True)
    created_at_jalali = serializers.SerializerMethodField()

    class Meta:
        model = PricingRuleChangeLog
        fields = '__all__'
        read_only_fields = ('id', 'created_at')

    def get_created_at_jalali(self, obj):
        return to_jalali(obj.created_at)


class PriceCalculationLogSerializer(serializers.ModelSerializer):
    inspection_request_id = serializers.IntegerField(
        source='inspection_request.id', read_only=True)
    rule_version_name = serializers.CharField(
        source='rule_version.equipment_type.name_fa', read_only=True)
    created_at_jalali = serializers.SerializerMethodField()

    class Meta:
        model = PriceCalculationLog
        fields = '__all__'
        read_only_fields = ('id', 'created_at')

    def get_created_at_jalali(self, obj):
        return to_jalali(obj.created_at)


class PricePreviewSerializer(serializers.Serializer):
    equipment_type_id = serializers.IntegerField(required=True)
    params = serializers.JSONField(required=False, default=dict)
    install_state = serializers.CharField(
        required=False, allow_null=True, allow_blank=True)
    city = serializers.CharField(required=True)
    service_type = serializers.ChoiceField(
        choices=PricingRule.ServiceType.choices,
        default='standard'
    )

    def validate(self, data):
        try:
            equipment = EquipmentType.objects.get(id=data['equipment_type_id'])
            data['equipment_type'] = equipment
        except EquipmentType.DoesNotExist:
            raise serializers.ValidationError(
                {"equipment_type_id": "نوع تجهیزات یافت نشد."}
            )

        if not hasattr(equipment, 'pricing_rule'):
            raise serializers.ValidationError(
                {"equipment_type_id": "قانون قیمت‌گذاری برای این تجهیز تعریف نشده است."}
            )

        from core.models import CityMultiplier
        if not CityMultiplier.objects.filter(city=data['city']).exists():
            raise serializers.ValidationError(
                {"city": "شهر وارد شده در سیستم وجود ندارد."}
            )

        return data
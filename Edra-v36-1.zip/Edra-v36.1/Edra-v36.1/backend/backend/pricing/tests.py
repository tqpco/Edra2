# pricing/tests.py — EDRA v17 (MEDIUM-3): پوشش تست اپ pricing
"""
قیمت‌گذاری مستقیماً روی درآمد اثر دارد؛ این فایل حداقل حفاظت رگرسیون
را فراهم می‌کند. CI با `pytest -q` (بدون محدودیت به core/) اجرا می‌شود.
"""
import pytest
from decimal import Decimal

from core.models import EquipmentType, CityMultiplier
from pricing.utils import calculate_price_with_components

pytestmark = pytest.mark.django_db


@pytest.fixture
def equipment():
    eq = EquipmentType.objects.create(
        code='test-crane', name_fa='جرثقیل تست',
        param_schema={'weight_ton': {'type': 'int', 'min': 1, 'max': 100}},
    )
    from pricing.models import PricingRule
    PricingRule.objects.create(
        equipment_type=eq,
        base_price=Decimal('1000000'),
        standard_multiplier=Decimal('1.0'),
        pro_multiplier=Decimal('1.5'),
        install_price=Decimal('500000'),
        dismantle_price=Decimal('300000'),
    )
    return eq


class TestPriceCalculation:
    def test_base_price_positive(self, equipment):
        comps = calculate_price_with_components(
            equipment, {'weight_ton': 10}, None, None, 'standard')
        assert comps['total'] > 0
        assert comps['base_price'] > 0

    def test_city_multiplier_applies(self, equipment):
        CityMultiplier.objects.create(city='تهران', multiplier=1.5)
        comps = calculate_price_with_components(
            equipment, {'weight_ton': 10}, None, 'تهران', 'standard')
        assert float(comps['city_multiplier']) == 1.5
        assert float(comps['city_cost']) >= 0

    def test_unknown_city_default_multiplier(self, equipment):
        comps = calculate_price_with_components(
            equipment, {'weight_ton': 10}, None, 'شهرناموجود', 'standard')
        # شهر ناشناخته → ضریب پیش‌فرض (بدون خطا)
        assert float(comps.get('city_multiplier', 1)) >= 1.0

    def test_total_is_sum_of_components(self, equipment):
        comps = calculate_price_with_components(
            equipment, {'weight_ton': 10}, None, None, 'standard')
        total = (comps['base_price'] + comps['city_cost']
                 + comps.get('install_cost', Decimal('0')))
        assert comps['total'] == total

# pricing/utils.py
from decimal import Decimal, DecimalException, ROUND_HALF_UP, getcontext
from core.models import EquipmentType, CityMultiplier
from .models import PricingRule, ParameterPrice
import ast
import operator
import logging

# تنظیم دقت محاسبات اعشاری
getcontext().prec = 28

logger = logging.getLogger(__name__)

# ============================================================
# توابع کمکی برای رند کردن
# ============================================================


def round_price(price, step=100000):
    """
    رند کردن یک عدد اعشاری به نزدیک‌ترین مضرب step.
    مثال: round_price(22416333.333, 100000) -> 22400000
    """
    if not isinstance(price, Decimal):
        price = Decimal(str(price))
    if step <= 0:
        return price
    # تبدیل به مضرب step
    step = Decimal(str(step))
    # تقسیم بر step، رند کردن، ضرب در step
    rounded = (price / step).quantize(Decimal('1'),
                                      rounding=ROUND_HALF_UP) * step
    return rounded


# ============================================================
# توابع مجاز برای استفاده در فرمول سفارشی
# ============================================================

def calculate_price_with_components(
        equipment_type,
        params,
        install_state=None,
        city_name=None,
        service_type='standard'):
    try:
        rule = PricingRule.objects.get(equipment_type=equipment_type)
    except PricingRule.DoesNotExist:
        logger.error(
            f"PricingRule یافت نشد برای equipment_type={equipment_type.id} "
            f"({getattr(equipment_type, 'name_fa', '')}) — fallback "
            "۱,۰۰۰,۰۰۰ تومان اعمال شد.")
        return {
            'total': Decimal(1000000),
            'base_price': Decimal(1000000),
            'param_total': Decimal(0),
            'param_factor': Decimal('1'),
            'city_cost': Decimal('0'),
            'service_multiplier': Decimal('1.0'),
            'install_cost': Decimal('0'),
            'service_type': service_type,
            'install_state': install_state,
        }

    base = Decimal(str(rule.base_price))
    param_total = Decimal(0)
    param_details = {}

    param_prices = ParameterPrice.objects.filter(
        pricing_rule=rule).select_related('parameter')
    for param_price in param_prices:
        if param_price.parameter is None:
            continue
        param_value = params.get(param_price.parameter.name)
        if param_value is None:
            continue
        try:
            value = Decimal(str(param_value))
        except (ValueError, TypeError, DecimalException):
            continue

        rate_type = param_price.rate_type
        rate = param_price.rate

        if rate_type == 'per_unit':
            cost = rate * value
        else:
            cost = rate
        param_total += cost
        param_details[param_price.parameter.name] = {
            'rate': float(rate),
            'value': float(value),
            'total': float(cost),
            'type': rate_type
        }

    # اعمال ضریب کاهش پارامترها در حالت دمونتاژ (۱/۳)
    param_factor = Decimal('1')
    if install_state == 'dismantle':
        param_factor = Decimal('1') / Decimal('3')

    param_total = param_total * param_factor

    # محاسبه هزینه شهر (base_cost × multiplier)
    city_cost = Decimal('0')
    city_multiplier = Decimal('1.0')
    if city_name:
        try:
            city_obj = CityMultiplier.objects.get(city=city_name)
            city_multiplier = city_obj.multiplier
            city_cost = city_obj.base_cost * city_obj.multiplier
        except CityMultiplier.DoesNotExist:
            pass

    price = base + param_total + city_cost

    # ضریب سرویس
    if service_type == 'pro':
        service_multiplier = Decimal(str(rule.pro_multiplier))
    else:
        service_multiplier = Decimal(str(rule.standard_multiplier))

    price = price * service_multiplier

    install_cost = Decimal(0)
    if install_state == 'installed':
        install_cost = Decimal(str(rule.install_price))
        price += install_cost
    elif install_state == 'dismantle':
        install_cost = Decimal(str(rule.dismantle_price))
        price += install_cost

    # رند کردن قیمت نهایی به نزدیک‌ترین مضرب ۱۰۰,۰۰۰ تومان
    price = round_price(price, step=100000)

    return {
        'base_price': base,
        'param_total': param_total,
        'param_factor': param_factor,
        'param_details': param_details,
        'city_cost': city_cost,
        'city_multiplier': city_multiplier,
        'service_multiplier': service_multiplier,
        'install_cost': install_cost,
        'total': price,
        'service_type': service_type,
        'install_state': install_state,
        'equipment_name': equipment_type.name_fa,
        'rule_id': rule.id,
    }


def calculate_price_with_rounding_info(
        equipment_type,
        params=None,
        install_state=None,
        city_name=None,
        service_type='standard'):
    """
    محاسبه قیمت با جزئیات رندینگ — رابطی که core/views/inspection_views.py
    به آن نیاز دارد (قبلاً وجود نداشت و ImportError باعث fallback به
    ۱٬۰۰۰٬۰۰۰ تومان ثابت برای همه درخواست‌ها می‌شد).

    خروجی:
      rounded_total      = قیمت نهایی رندشده (مضرب ۱۰۰,۰۰۰) — مبلغ نمایش/فاکتور
      exact_total        = قیمت دقیق پیش از رند (برای محاسبات داخلی)
      rounding_discount  = exact − rounded (≥ 0؛ تخفیف ناشی از رند)
      components         = اجزای محاسبه (برای گزارش/لاگ قیمت)
    """
    params = params or {}
    components = calculate_price_with_components(
        equipment_type, params, install_state, city_name, service_type)
    exact_total = (
        (components['base_price']
         + components['param_total']
         + components['city_cost'])
        * components['service_multiplier']
        + components['install_cost']
    ).quantize(Decimal(1), rounding=ROUND_HALF_UP)
    rounded_total = components['total']
    rounding_discount = max(
        exact_total - rounded_total, Decimal('0'))
    return {
        'rounded_total': rounded_total,
        'exact_total': exact_total,
        'rounding_discount': rounding_discount,
        'components': components,
    }


# ===== Baseline Cases برای تست =====
BASELINE_CASES = [
    {
        'equipment_code': 'tower_crane',
        'params': {'tonnage': 12, 'height': 50, 'jib_length': 40},
        'install_state': None,
        'expected': 5000000,
    },
    {
        'equipment_code': 'tower_crane',
        'params': {'tonnage': 12, 'height': 50, 'jib_length': 40},
        'install_state': 'installed',
        'expected': 6000000,
    },
]


def check_baselines(rule):
    errors = []
    for case in BASELINE_CASES:
        if case['equipment_code'] != rule.equipment_type.code:
            continue
        try:
            comps = calculate_price_with_components(
                rule.equipment_type,
                case['params'],
                case['install_state'],
                city_name=None,
                service_type='standard'
            )
            price = comps['total']
            expected = Decimal(str(case['expected']))
            if abs(price - expected) > Decimal(1000):
                errors.append({
                    'case': case,
                    'calculated': float(price),
                    'expected': float(expected),
                })
        except Exception as e:
            errors.append({
                'case': case,
                'error': str(e)
            })
    return errors


def debug_price(
        equipment_type,
        params,
        install_state=None,
        city_name=None,
        service_type='standard'):
    try:
        rule = PricingRule.objects.get(equipment_type=equipment_type)
    except PricingRule.DoesNotExist:
        return {
            'error': 'قانون قیمت‌گذاری برای این تجهیز یافت نشد.',
            'base_price': 0,
            'param_total': 0,
            'param_factor': 1.0,
            'param_details': {},
            'city_cost': 0,
            'service_multiplier': 1.0,
            'install_cost': 0,
            'total': 0,
            'equipment_name': equipment_type.name_fa,
            'service_type': service_type,
            'install_state': install_state,
        }

    base = Decimal(str(rule.base_price))
    param_total = Decimal(0)
    param_details = {}

    param_prices = ParameterPrice.objects.filter(
        pricing_rule=rule).select_related('parameter')
    for param_price in param_prices:
        if param_price.parameter is None:
            continue
        param_value = params.get(param_price.parameter.name)
        if param_value is None:
            continue
        try:
            value = Decimal(str(param_value))
        except (ValueError, TypeError, DecimalException):
            continue

        rate_type = param_price.rate_type
        rate = param_price.rate

        if rate_type == 'per_unit':
            cost = rate * value
        else:
            cost = rate
        param_total += cost
        param_details[param_price.parameter.name] = {
            'rate': float(rate),
            'value': float(value),
            'total': float(cost),
            'type': rate_type
        }

    param_factor = Decimal('1')
    if install_state == 'dismantle':
        param_factor = Decimal('1') / Decimal('3')
    param_total = param_total * param_factor

    city_cost = Decimal('0')
    if city_name:
        try:
            city_obj = CityMultiplier.objects.get(city=city_name)
            city_cost = city_obj.base_cost * city_obj.multiplier
        except CityMultiplier.DoesNotExist:
            pass

    price = base + param_total + city_cost

    if service_type == 'pro':
        service_multiplier = Decimal(str(rule.pro_multiplier))
    else:
        service_multiplier = Decimal(str(rule.standard_multiplier))

    price = price * service_multiplier

    install_cost = Decimal(0)
    if install_state == 'installed':
        install_cost = Decimal(str(rule.install_price))
        price += install_cost
    elif install_state == 'dismantle':
        install_cost = Decimal(str(rule.dismantle_price))
        price += install_cost

    # رند کردن برای دیباگ نیز
    price = round_price(price, step=100000)

    return {
        'base_price': float(base),
        'param_total': float(param_total),
        'param_factor': float(param_factor),
        'param_details': param_details,
        'city_cost': float(city_cost),
        'service_multiplier': float(service_multiplier),
        'install_cost': float(install_cost),
        'total': float(price),
        'rule_id': rule.id,
        'equipment_name': rule.equipment_type.name_fa,
        'service_type': service_type,
        'install_state': install_state,
    }
# pricing/views.py
from decimal import Decimal, ROUND_HALF_UP
from rest_framework import viewsets, status, generics, filters
from rest_framework.decorators import action
from rest_framework.response import Response
from rest_framework.permissions import AllowAny, IsAuthenticated
from core.permissions import IsAdminUserOrGroup
from django.db import transaction
from django.core.cache import cache
from django.http import JsonResponse
from core.models import EquipmentType, CityMultiplier, DiscountCode, UserCredit
from core.serializers import EquipmentTypeSerializer, CityMultiplierSerializer
from .models import PricingRule, PricingRuleChangeLog, PriceCalculationLog, ParameterPrice
from .serializers import (
    PricingRuleSerializer, PricingRuleChangeLogSerializer,
    PriceCalculationLogSerializer, PricePreviewSerializer,
    ParameterPriceSerializer,
)
from .utils import calculate_price_with_components, check_baselines, debug_price
from core.services.discount_service import validate_discount, compute_discount_amount
from django_filters.rest_framework import DjangoFilterBackend
import logging

logger = logging.getLogger(__name__)


def get_equipment_params(request, equipment_id):
    try:
        equipment = EquipmentType.objects.get(pk=equipment_id)
        schema = equipment.param_schema
        return JsonResponse({'schema': schema})
    except EquipmentType.DoesNotExist:
        return JsonResponse({'schema': None}, status=404)


class PricingRuleViewSet(viewsets.ModelViewSet):
    queryset = PricingRule.objects.select_related(
        'equipment_type', 'updated_by'
    ).order_by('equipment_type__name_fa')
    serializer_class = PricingRuleSerializer
    permission_classes = [IsAdminUserOrGroup]
    filter_backends = [DjangoFilterBackend, filters.SearchFilter, filters.OrderingFilter]
    search_fields = ['equipment_type__name_fa', 'equipment_type__code']
    ordering_fields = ['base_price', 'updated_at', 'equipment_type__name_fa']
    ordering = ['equipment_type__name_fa']

    @transaction.atomic
    def perform_create(self, serializer):
        rule = serializer.save(updated_by=self.request.user)
        after = {
            'base_price': str(rule.base_price),
            'install_price': str(rule.install_price),
            'dismantle_price': str(rule.dismantle_price),
            'standard_multiplier': str(rule.standard_multiplier),
            'pro_multiplier': str(rule.pro_multiplier),
            'custom_formula': rule.custom_formula,
        }
        PricingRuleChangeLog.objects.create(
            pricing_rule=rule,
            changed_by=self.request.user,
            before={},
            after=after,
            baseline_check_passed=True
        )
        cache_key = f'pricing_rule_{rule.equipment_type.id}'
        cache.delete(cache_key)
        logger.info(
            f"Pricing rule created for {rule.equipment_type.name_fa} by {self.request.user.username}")

    @transaction.atomic
    def perform_update(self, serializer):
        instance = self.get_object()
        before = {
            'base_price': str(instance.base_price),
            'install_price': str(instance.install_price),
            'dismantle_price': str(instance.dismantle_price),
            'standard_multiplier': str(instance.standard_multiplier),
            'pro_multiplier': str(instance.pro_multiplier),
            'custom_formula': instance.custom_formula,
        }
        logs_before = PricingRuleChangeLog.objects.filter(
            pricing_rule=instance).count()
        updated = serializer.save(updated_by=self.request.user)
        after = {
            'base_price': str(updated.base_price),
            'install_price': str(updated.install_price),
            'dismantle_price': str(updated.dismantle_price),
            'standard_multiplier': str(updated.standard_multiplier),
            'pro_multiplier': str(updated.pro_multiplier),
            'custom_formula': updated.custom_formula,
        }
        errors = check_baselines(updated)
        baseline_passed = len(errors) == 0
        # EDRA v36: PricingRule.save() خودش برای تغییر قیمت/ضرایب یک
        # PricingRuleChangeLog می‌سازد؛ این view هم یکی می‌ساخت → «دو» ردیف
        # تاریخچه برای هر ویرایش. اگر مدل لاگ ساخته بود همان را کامل می‌کنیم.
        logs_after = PricingRuleChangeLog.objects.filter(
            pricing_rule=updated).count()
        if logs_after > logs_before:
            last = PricingRuleChangeLog.objects.filter(
                pricing_rule=updated).order_by('-id').first()
            last.changed_by = self.request.user
            last.before = before
            last.after = after
            last.baseline_check_passed = baseline_passed
            last.save(update_fields=[
                'changed_by', 'before', 'after', 'baseline_check_passed'])
        else:
            PricingRuleChangeLog.objects.create(
                pricing_rule=updated,
                changed_by=self.request.user,
                before=before,
                after=after,
                baseline_check_passed=baseline_passed
            )
        cache_key = f'pricing_rule_{updated.equipment_type.id}'
        cache.delete(cache_key)
        if not baseline_passed:
            logger.warning(f"Baseline Guard failed for rule {updated.id}: {repr(errors)}")
        else:
            logger.info(
                f"Pricing rule updated for {updated.equipment_type.name_fa} by {self.request.user.username}")

    @action(detail=False, methods=['post'], permission_classes=[AllowAny])
    def preview(self, request):
        serializer = PricePreviewSerializer(data=request.data)
        if not serializer.is_valid():
            return Response(
                serializer.errors,
                status=status.HTTP_400_BAD_REQUEST)

        data = serializer.validated_data

        try:
            equipment = EquipmentType.objects.get(id=data['equipment_type_id'])
        except EquipmentType.DoesNotExist:
            return Response({'error': 'نوع تجهیز یافت نشد.'},
                            status=status.HTTP_404_NOT_FOUND)

        try:
            rule = PricingRule.objects.get(equipment_type=equipment)
        except PricingRule.DoesNotExist:
            return Response({
                'error': 'قانون قیمت‌گذاری برای این تجهیز تعریف نشده است.',
                'suggestion': 'ابتدا یک قانون قیمت‌گذاری ایجاد کنید.'
            }, status=status.HTTP_404_NOT_FOUND)

        city_name = data.get('city')
        # EDRA v36: همان پاک‌سازی سمت سرور (مقدار منفی/NaN قیمت نمایشی را خراب
        # می‌کرد)؛ این preview قدیمی AllowAny است.
        from core.params_validation import clean_request_params
        clean_params = clean_request_params(
            equipment, data.get('params', {}), strict=False)
        components = calculate_price_with_components(
            equipment,
            clean_params,
            data.get('install_state'),
            city_name=city_name,
            service_type=data.get('service_type', 'standard')
        )

        return Response({
            'equipment': {
                'id': equipment.id,
                'name': equipment.name_fa,
                'code': equipment.code,
            },
            'params': clean_params,
            'install_state': data.get('install_state'),
            'city': city_name,
            'city_cost': float(components.get('city_cost', 0)),
            'service_type': data.get('service_type', 'standard'),
            'components': {
                'base_price': float(components['base_price']),
                'param_total': float(components['param_total']),
                'param_details': components.get('param_details', {}),
                'city_cost': float(components.get('city_cost', 0)),
                'service_multiplier': float(components['service_multiplier']),
                'install_cost': float(components['install_cost']),
            },
            'total_price': float(components['total']),
            'rule_id': rule.id,
        })

    @action(detail=True, methods=['get'])
    def changelog(self, request, pk=None):
        rule = self.get_object()
        logs = PricingRuleChangeLog.objects.filter(
            pricing_rule=rule).order_by('-created_at')
        serializer = PricingRuleChangeLogSerializer(logs, many=True)
        return Response(serializer.data)


class PricingRuleChangeLogViewSet(viewsets.ReadOnlyModelViewSet):
    queryset = PricingRuleChangeLog.objects.select_related(
        'pricing_rule', 'changed_by'
    ).order_by('-created_at')
    serializer_class = PricingRuleChangeLogSerializer
    permission_classes = [IsAdminUserOrGroup]
    filter_backends = [DjangoFilterBackend, filters.OrderingFilter]
    ordering = ['-created_at']


class ParameterPriceViewSet(viewsets.ModelViewSet):
    queryset = ParameterPrice.objects.select_related(
        'pricing_rule', 'parameter'
    )
    serializer_class = ParameterPriceSerializer
    permission_classes = [IsAdminUserOrGroup]
    filter_backends = [DjangoFilterBackend, filters.OrderingFilter]
    filterset_fields = ['pricing_rule']
    ordering_fields = ['id', 'parameter__order', 'rate']
    ordering = ['parameter__order', 'id']

    def get_queryset(self):
        queryset = super().get_queryset()
        return queryset.order_by('parameter__order', 'id')

    def perform_create(self, serializer):
        serializer.save()

    def perform_update(self, serializer):
        serializer.save()

    def perform_destroy(self, instance):
        instance.delete()


class EquipmentTypeViewSet(viewsets.ReadOnlyModelViewSet):
    queryset = EquipmentType.objects.all().order_by('name_fa')
    serializer_class = EquipmentTypeSerializer
    permission_classes = [AllowAny]
    def get_queryset(self):
        # EDRA v32: فقط موارد فعال برای عموم
        return super().get_queryset().filter(is_active=True)

    filter_backends = [DjangoFilterBackend, filters.SearchFilter, filters.OrderingFilter]
    search_fields = ['name_fa', 'code']
    ordering_fields = ['name_fa', 'code']
    ordering = ['name_fa']


class CityMultiplierViewSet(viewsets.ReadOnlyModelViewSet):
    queryset = CityMultiplier.objects.all().order_by('city')
    serializer_class = CityMultiplierSerializer
    permission_classes = [AllowAny]
    def get_queryset(self):
        # EDRA v32: فقط موارد فعال برای عموم
        return super().get_queryset().filter(is_active=True)

    filter_backends = [DjangoFilterBackend, filters.SearchFilter, filters.OrderingFilter]
    search_fields = ['city']
    ordering_fields = ['city', 'multiplier']
    ordering = ['city']


# ============================================================
# ✅ ویو اصلی محاسبه قیمت (اصلاح‌شده برای پشتیبانی از تخفیف و اعتبار)
# ============================================================
class PriceCalculateView(generics.GenericAPIView):
    permission_classes = [AllowAny]
    serializer_class = PricePreviewSerializer

    def post(self, request):
        try:
            return self._handle_post(request)
        except Exception as exc:
            logger.error('PriceCalculateView crashed: %s', exc, exc_info=True)
            return Response(
                {'error': 'خطای داخلی سرور در محاسبه قیمت'},
                status=status.HTTP_500_INTERNAL_SERVER_ERROR)

    def _handle_post(self, request):
        serializer = self.get_serializer(data=request.data)
        if not serializer.is_valid():
            return Response(
                serializer.errors,
                status=status.HTTP_400_BAD_REQUEST)

        data = serializer.validated_data
        equipment = data['equipment_type']
        # EDRA v36: همان پاک‌سازی سمت‌سرورِ ثبت درخواست (مقدار منفی/NaN دیگر
        # قیمت نمایشی را ارزان نشان نمی‌دهد)؛ در پیش‌نمایش غیر strict است.
        from core.params_validation import clean_request_params
        params = clean_request_params(
            equipment, data.get('params', {}), strict=False)
        install_state = data.get('install_state')
        city_name = data.get('city')
        service_type = data.get('service_type', 'standard')
        discount_code = request.data.get('discount_code')
        try:
            credit_amount = Decimal(str(request.data.get('credit_amount') or 0))
            if not credit_amount.is_finite() or credit_amount < 0:
                credit_amount = Decimal(0)
        except Exception:
            credit_amount = Decimal(0)

        # ============================================================
        # ۱. محاسبه قیمت پایه با جزئیات کامل (ضریب شهر، هزینه شهر، ...)
        # ============================================================
        components = calculate_price_with_components(
            equipment,
            params,
            install_state,
            city_name=city_name,
            service_type=service_type
        )
        base_price = components['total']  # قیمت نهایی قبل از تخفیف و مالیات
        city_multiplier = components['city_multiplier']
        city_base_cost = components['city_cost']

        # ============================================================
        # ۲. محاسبه تخفیف (در صورت وجود)
        # ============================================================
        discount_amount = Decimal(0)
        discount_error = None
        discount_obj = None

        if discount_code:
            try:
                from core.services.discount_service import find_discount
                discount_obj = find_discount(discount_code, active_only=True)
                if discount_obj is None:
                    raise DiscountCode.DoesNotExist
                error = validate_discount(
                    discount_obj,
                    amount=base_price,
                    equipment_type=equipment,
                    user=request.user if request.user.is_authenticated else None
                )
                if error:
                    discount_error = error
                else:
                    discount_amount = compute_discount_amount(discount_obj, base_price)
            except DiscountCode.DoesNotExist:
                discount_error = 'کد تخفیف نامعتبر است.'

        price_after_discount = base_price - discount_amount

        # ============================================================
        # ۳. محاسبه مالیات (با نرخ فعلی از مدل TaxRate)
        # ============================================================
        # EDRA v32 — رفع باگ خاموش: `timezone` در این فایل import نشده بود و
        # `except: pass` خطای NameError را می‌بلعید؛ در نتیجه نرخ همیشه ۱۰٪ ثابت
        # می‌ماند (فاکتور نهایی از TaxRate و fallback ۹٪ استفاده می‌کند). حالا
        # پیش‌نمایش و فاکتور از «یک تابع واحد» نرخ را می‌گیرند.
        from core.services.invoice_service import resolve_tax_rate_percent
        tax_rate = resolve_tax_rate_percent() / Decimal('100')

        # EDRA v27 — تغییر قانونی/کسب‌وکاری (تایید صریح کاربر، سپتامبر
        # ۲۰۲۶): مالیات از این پس روی قیمت اصلی (قبل از تخفیف) محاسبه
        # می‌شود، نه روی مبلغ بعد از تخفیف. این فرمول باید دقیقاً همینجا
        # و در core/services/invoice_service.py (محاسبه‌ی نهایی فاکتور)
        # یکسان بماند تا پیش‌نمایش و فاکتور نهایی هماهنگ باشند.
        # گرد کردن به تومان دقیقاً مثل فاکتور (ROUND_HALF_UP) تا عدد نمایش‌داده‌شده
        # با عدد فاکتور یکی باشد.
        tax_amount = (base_price * tax_rate).quantize(Decimal(1), rounding=ROUND_HALF_UP)
        final_amount = price_after_discount + tax_amount

        # ============================================================
        # ۴. محاسبه اعتبار کاربر (در صورت احراز هویت)
        # ============================================================
        credit_balance = Decimal(0)
        max_usable_credit = Decimal(0)
        credit_used = Decimal(0)
        final_payable = final_amount

        if request.user.is_authenticated:
            try:
                credit = UserCredit.objects.get(user=request.user)
                # EDRA v35: موجودی «قابل مصرف» = balance − رزروهای فعال؛ قبلاً
                # اعتبار قفل‌شده‌ی پرداخت‌های در حال بررسی هم پیشنهاد می‌شد و
                # ثبت بعدی با «اعتبار کافی نیست» رد می‌شد.
                from core.services.credit_service import get_available_balance
                credit_balance = max(get_available_balance(request.user),
                                     Decimal(0))
                max_usable_credit = min(credit_balance, final_amount)
                if credit_amount > 0:
                    credit_used = min(credit_amount, max_usable_credit)
                final_payable = final_amount - credit_used
            except UserCredit.DoesNotExist:
                pass

        # ============================================================
        # ۵. ساخت پاسخ کامل
        # ============================================================
        response_data = {
            'total_price': float(base_price),
            'city_multiplier': float(city_multiplier),
            'city_base_cost': float(city_base_cost),
            'discount_amount': float(discount_amount),
            'discount_error': discount_error,
            'tax_rate_percent': float(tax_rate * 100),
            'tax_amount': float(tax_amount),
            'final_amount': float(final_amount),
            'credit_balance': float(credit_balance),
            'max_usable_credit': float(max_usable_credit),
            'credit_used': float(credit_used),
            'final_payable': float(final_payable),
            'has_discount': discount_obj is not None and not discount_error,
        }

        # EDRA v35: لاگ پیش‌نمایش حذف شد — این endpoint عمومی (AllowAny) است و
        # ویزارد با هر تغییر ورودی آن را صدا می‌زند؛ یک ردیف دیتابیس به ازای
        # هر پیش‌نمایش = رشد بی‌پایان جدول توسط هر کاربر ناشناس. لاگ واقعی
        # قیمت هنگام «ثبت درخواست» (perform_create) نوشته می‌شود.
        return Response(response_data)


# ============================================================
# سایر ویوهای قیمت‌گذاری (بدون تغییر)
# ============================================================

class PriceDebugView(generics.GenericAPIView):
    permission_classes = [IsAdminUserOrGroup]

    def post(self, request):
        data = request.data

        try:
            equipment = EquipmentType.objects.get(
                id=data.get('equipment_type_id'))
        except EquipmentType.DoesNotExist:
            return Response({'error': 'نوع تجهیز یافت نشد.'},
                            status=status.HTTP_404_NOT_FOUND)

        result = debug_price(
            equipment,
            data.get('params', {}),
            data.get('install_state'),
            city_name=data.get('city'),
            service_type=data.get('service_type', 'standard')
        )

        if 'error' in result:
            return Response(result, status=status.HTTP_404_NOT_FOUND)

        return Response({
            'success': True,
            'debug_info': result,
            'equipment': {
                'id': equipment.id,
                'name': equipment.name_fa,
                'code': equipment.code,
            },
            'params_used': data.get('params', {}),
            'city': data.get('city'),
            'service_type': data.get('service_type', 'standard'),
            'install_state': data.get('install_state'),
        })


class PriceComponentsView(generics.GenericAPIView):
    permission_classes = [AllowAny]

    def post(self, request):
        serializer = PricePreviewSerializer(data=request.data)
        if not serializer.is_valid():
            return Response(
                serializer.errors,
                status=status.HTTP_400_BAD_REQUEST)

        data = serializer.validated_data

        try:
            equipment = EquipmentType.objects.get(id=data['equipment_type_id'])
        except EquipmentType.DoesNotExist:
            return Response({'error': 'نوع تجهیز یافت نشد.'},
                            status=status.HTTP_404_NOT_FOUND)

        # EDRA v36: پاک‌سازی سمت‌سرور params (مقدار منفی/NaN) — endpoint عمومی.
        from core.params_validation import clean_request_params
        components = calculate_price_with_components(
            equipment,
            clean_request_params(equipment, data.get('params', {}), strict=False),
            data.get('install_state'),
            city_name=data.get('city'),
            service_type=data.get('service_type', 'standard')
        )

        return Response({
            'success': True,
            'equipment': {
                'id': equipment.id,
                'name': equipment.name_fa,
            },
            'components': {
                'base_price': float(components['base_price']),
                'param_total': float(components['param_total']),
                'param_details': components.get('param_details', {}),
                'city_cost': float(components.get('city_cost', 0)),
                'service_multiplier': float(components['service_multiplier']),
                'install_cost': float(components['install_cost']),
            },
            'total_price': float(components['total']),
            'service_type': data.get('service_type', 'standard'),
            'install_state': data.get('install_state'),
        })
# public/admin.py
# -*- coding: utf-8 -*-

from django.contrib import admin
from django.utils.html import format_html

# ✅ اصلاح: ایمپورت مستقیم از پکیج edra_jalalidate
from edra_jalalidate.admin import EdraJalaliAdminMixin, make_jalali_date_filter
from edra_jalalidate import to_jalali

from .models import BlogPost, FAQ, ContactMessage


class JalaliDateDisplayMixin:
    """نمایش تاریخ‌های خام به‌صورت جلالی در ستون‌های لیست ادمین"""

    def created_at_display(self, obj):
        return to_jalali(obj.created_at, fmt="%Y/%m/%d - %H:%M")
    created_at_display.short_description = "تاریخ ایجاد"

    def updated_at_display(self, obj):
        return to_jalali(obj.updated_at, fmt="%Y/%m/%d - %H:%M")
    updated_at_display.short_description = "تاریخ بروزرسانی"


@admin.register(BlogPost)
class BlogPostAdmin(JalaliDateDisplayMixin, EdraJalaliAdminMixin, admin.ModelAdmin):
    list_display = (
        'title',
        'category',
        'is_published',
        'author',
        'created_at_display')
    list_filter = (
        'category', 'is_published', 'author',
        make_jalali_date_filter('created_at', 'تاریخ ایجاد'))
    search_fields = ('title', 'summary', 'content', 'tags')
    prepopulated_fields = {'slug': ('title',)}
    readonly_fields = ('created_at_display', 'updated_at_display')

    fieldsets = (
        ('اطلاعات اصلی', {
            'fields': ('title', 'slug', 'summary', 'content', 'featured_image')
        }),
        ('دسته‌بندی و انتشار', {
            'fields': ('category', 'tags', 'is_published', 'published_at', 'author')
        }),
        ('اطلاعات سیستمی', {
            'fields': ('created_at_display', 'updated_at_display'),
            'classes': ('collapse',)
        }),
    )


@admin.register(FAQ)
class FAQAdmin(admin.ModelAdmin):
    list_display = ('question', 'category', 'order', 'is_active')
    list_filter = ('category', 'is_active')
    search_fields = ('question', 'answer')
    ordering = ('order',)


@admin.register(ContactMessage)
class ContactMessageAdmin(JalaliDateDisplayMixin, EdraJalaliAdminMixin, admin.ModelAdmin):
    list_display = ('name', 'email', 'phone', 'created_at_display')
    list_filter = (make_jalali_date_filter('created_at', 'تاریخ ایجاد'),)
    search_fields = ('name', 'email', 'phone', 'message')
    readonly_fields = ('created_at_display',)
# public/models.py
from django.db import models
from django.contrib.auth import get_user_model

User = get_user_model()


class BlogPost(models.Model):
    CATEGORY_CHOICES = [
        ('news', 'اخبار'),
        ('article', 'مقالات'),
        ('tutorial', 'آموزش‌ها'),
        ('case_study', 'مطالعات موردی'),
        ('announcement', 'اعلان‌ها'),
    ]

    title = models.CharField(max_length=200, verbose_name='عنوان')
    slug = models.SlugField(max_length=50, unique=True, verbose_name='اسلاگ')
    summary = models.TextField(verbose_name='خلاصه')
    content = models.TextField(verbose_name='محتوا')
    featured_image = models.ImageField(
        upload_to='blog/',
        blank=True,
        null=True,
        verbose_name='تصویر شاخص')
    category = models.CharField(
        max_length=50,
        choices=CATEGORY_CHOICES,
        default='article',
        verbose_name='دسته‌بندی')
    tags = models.TextField(blank=True, verbose_name='برچسب‌ها')
    is_published = models.BooleanField(default=False, verbose_name='منتشر شده')
    published_at = models.DateTimeField(
        null=True, blank=True, verbose_name='تاریخ انتشار')
    author = models.ForeignKey(
        User,
        on_delete=models.PROTECT,
        related_name='blog_posts',
        verbose_name='نویسنده')
    created_at = models.DateTimeField(
        auto_now_add=True, verbose_name='تاریخ ایجاد')
    updated_at = models.DateTimeField(
        auto_now=True, verbose_name='تاریخ بروزرسانی')

    def __str__(self):
        return self.title

    class Meta:
        verbose_name = 'مقاله وبلاگ'
        verbose_name_plural = 'مقالات وبلاگ'
        ordering = ['-published_at', '-created_at']


class FAQ(models.Model):
    CATEGORY_CHOICES = [
        ('general', 'عمومی'),
        ('technical', 'فنی'),
        ('billing', 'مالی'),
        ('support', 'پشتیبانی'),
        ('inspection', 'بازرسی'),
    ]

    question = models.CharField(max_length=255, verbose_name='سوال')
    answer = models.TextField(verbose_name='پاسخ')
    category = models.CharField(
        max_length=50,
        choices=CATEGORY_CHOICES,
        default='general',
        verbose_name='دسته‌بندی')
    order = models.PositiveSmallIntegerField(default=0, verbose_name='ترتیب')
    is_active = models.BooleanField(default=True, verbose_name='فعال')

    def __str__(self):
        return self.question

    class Meta:
        verbose_name = 'سوال متداول'
        verbose_name_plural = 'سوالات متداول'
        ordering = ['order', 'category']


class ContactMessage(models.Model):
    name = models.CharField(max_length=100, verbose_name='نام')
    email = models.EmailField(verbose_name='ایمیل')
    phone = models.CharField(max_length=20, verbose_name='تلفن')
    message = models.TextField(verbose_name='پیام')
    created_at = models.DateTimeField(
        auto_now_add=True, verbose_name='تاریخ ایجاد')

    def __str__(self):
        return f"{self.name} - {self.email}"

    class Meta:
        verbose_name = 'پیام تماس'
        verbose_name_plural = 'پیام‌های تماس'
        ordering = ['-created_at']
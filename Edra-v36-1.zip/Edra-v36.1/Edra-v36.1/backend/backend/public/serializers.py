# public/serializers.py
# -*- coding: utf-8 -*-

from rest_framework import serializers

# ✅ استفاده از edra_jalalidate به‌جای core.utils.date_utils
from edra_jalalidate import to_jalali as _to_jalali

from .models import BlogPost, FAQ, ContactMessage


def to_jalali(dt):
    """
    تبدیل datetime به رشته جلالی با فرمت "%Y/%m/%d - %H:%M"
    اگر ورودی None باشد، None برگردانده می‌شود.
    """
    if not dt:
        return None
    return _to_jalali(dt, fmt="%Y/%m/%d - %H:%M")


class BlogPostSerializer(serializers.ModelSerializer):
    author_name = serializers.CharField(
        source='author.get_full_name', read_only=True)
    created_at_jalali = serializers.SerializerMethodField()
    updated_at_jalali = serializers.SerializerMethodField()
    published_at_jalali = serializers.SerializerMethodField()

    class Meta:
        model = BlogPost
        fields = '__all__'
        read_only_fields = ('created_at', 'updated_at', 'author')

    def get_created_at_jalali(self, obj):
        return to_jalali(obj.created_at)

    def get_updated_at_jalali(self, obj):
        return to_jalali(obj.updated_at)

    def get_published_at_jalali(self, obj):
        return to_jalali(obj.published_at)


class FAQSerializer(serializers.ModelSerializer):
    class Meta:
        model = FAQ
        fields = '__all__'


class ContactMessageSerializer(serializers.ModelSerializer):
    created_at_jalali = serializers.SerializerMethodField()

    class Meta:
        model = ContactMessage
        fields = '__all__'
        read_only_fields = ('created_at',)
        # EDRA v36: این endpoint برای ناشناس‌ها باز است و TextField بدون سقف،
        # ذخیره‌ی پیام‌های چند-مگابایتی (اسپم/پر کردن دیسک) را ممکن می‌کرد.
        extra_kwargs = {'message': {'max_length': 5000}}

    def get_created_at_jalali(self, obj):
        return to_jalali(obj.created_at)
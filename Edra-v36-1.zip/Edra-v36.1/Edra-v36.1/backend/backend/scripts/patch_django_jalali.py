#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
پچ کردن django_jalali برای سازگاری با Django 6.x

⚠️ توجه مهم: از نسخه‌ی EDRA v25 به بعد، پروژه از django-jalali استفاده نمی‌کند
و به‌طور کامل با پکیج اختصاصی edra_jalalidate جایگزین شده است.

این اسکریپت فقط برای پروژه‌های قدیمی که هنوز از django-jalali استفاده می‌کنند
کاربرد دارد. در پروژه‌ی جدید، نیازی به اجرای آن نیست.

در صورت وجود django-jalali، این اسکریپت به‌صورت خودکار پچ را اعمال می‌کند.
"""

import importlib
import os
import sys


def find_django_jalali_path():
    """مسیر نصب django_jalali را پیدا می‌کند."""
    try:
        import django_jalali
        return os.path.dirname(django_jalali.__file__)
    except ImportError:
        return None


def patch_file(filepath):
    """
    جایگزینی gettext به gettext_lazy در یک فایل پایتون.
    فقط import line‌ها را تغییر می‌دهد (نه function calls به gettext).
    """
    with open(filepath, 'r', encoding='utf-8') as f:
        content = f.read()

    original = content

    # فقط import line‌ها را پچ کن — نه فراخوانی‌های ()_
    content = content.replace(
        'from django.utils.translation import gettext as _',
        'from django.utils.translation import gettext_lazy as _',
    )

    if content != original:
        with open(filepath, 'w', encoding='utf-8') as f:
            f.write(content)
        return True
    return False


def main():
    print("=" * 60)
    print("  اسکریپت پچ django-jalali")
    print("=" * 60)

    jalali_path = find_django_jalali_path()

    if jalali_path is None:
        print("ℹ️  django-jalali نصب نیست.")
        print("ℹ️  پروژه‌ی جدید از edra_jalalidate استفاده می‌کند.")
        print("ℹ️  نیازی به اجرای این اسکریپت نیست.")
        print("=" * 60)
        return

    print(f"📂 مسیر django_jalali: {jalali_path}")
    print("⚠️  توجه: پروژه از django-jalali استفاده می‌کند.")
    print("⚠️  توصیه می‌شود به edra_jalalidate مهاجرت کنید.")

    # فایل‌هایی که باید پچ شوند
    files_to_patch = []
    for root, dirs, files in os.walk(jalali_path):
        for f in files:
            if f.endswith('.py'):
                filepath = os.path.join(root, f)
                try:
                    with open(filepath, 'r', encoding='utf-8') as fh:
                        if 'from django.utils.translation import gettext as _' in fh.read():
                            files_to_patch.append(filepath)
                except Exception:
                    continue

    if not files_to_patch:
        print("✅ همه فایل‌ها قبلاً پچ شده‌اند یا نیازی به پچ نیست.")
        print("=" * 60)
        return

    for filepath in files_to_patch:
        rel = os.path.relpath(filepath, jalali_path)
        patched = patch_file(filepath)
        if patched:
            print(f"  🔧 پچ شد: {rel}")
        else:
            print(f"  ✅ قبلاً پچ شده: {rel}")

    print(f"\n✅ {len(files_to_patch)} فایل با موفقیت پچ شد.")
    print("=" * 60)
    print("ℹ️  برای مهاجرت به edra_jalalidate، مستندات پروژه را مطالعه کنید.")


if __name__ == '__main__':
    main()
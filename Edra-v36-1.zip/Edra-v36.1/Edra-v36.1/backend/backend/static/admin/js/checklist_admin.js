// static/admin/js/checklist_admin.js
// مدیریت یکپارچه چک‌لیست با AJAX و Drag & Drop

(function($) {
    'use strict';

    $(document).ready(function() {

        // ============================================================
        // ۱. نمایش/مخفی کردن آیتم‌های هر قالب
        // ============================================================
        $(document).on('click', '.toggle-items-btn', function() {
            var templateId = $(this).data('template-id');
            var container = $('#items-' + templateId);
            var btn = $(this);

            if (container.hasClass('visible')) {
                container.removeClass('visible');
                btn.text('📋 نمایش آیتم‌ها').removeClass('active');
            } else {
                container.addClass('visible');
                btn.text('📋 مخفی کردن آیتم‌ها').addClass('active');
                loadItems(templateId);
            }
        });

        // ============================================================
        // ۲. بارگذاری آیتم‌ها با AJAX
        // ============================================================
        function loadItems(templateId) {
            var container = $('#items-' + templateId);
            var body = $('#items-body-' + templateId);
            var categoryId = container.find('.cat-btn.active').data('category-id') || '';
            var search = container.find('.items-search-input').val() || '';

            body.html('<tr><td colspan="7" style="text-align:center; color:#94a3b8; padding:20px;">⏳ در حال بارگذاری...</td></tr>');

            $.ajax({
                url: '/admin/core/checklisttemplate/get-items/',
                method: 'GET',
                data: {
                    template_id: templateId,
                    category_id: categoryId,
                    search: search
                },
                success: function(response) {
                    if (response.items && response.items.length > 0) {
                        var html = '';
                        $.each(response.items, function(index, item) {
                            html += '<tr data-id="' + item.id + '">';
                            html += '<td><span class="drag-handle">⠿</span></td>';
                            html += '<td><strong>' + escapeHtml(item.title) + '</strong>';
                            if (item.description) {
                                html += '<br><span style="color:#94a3b8; font-size:12px;">' + escapeHtml(item.description) + '</span>';
                            }
                            html += '</td>';
                            html += '<td><span class="category-badge" style="background:' + item.category_color + ';">' + escapeHtml(item.category || 'بدون دسته') + '</span></td>';
                            html += '<td class="icon-cell">' + (item.requires_photo ? '✅' : '⬜') + '</td>';
                            html += '<td class="icon-cell">' + (item.requires_note ? '✅' : '⬜') + '</td>';
                            html += '<td class="icon-cell">' + (item.is_critical ? '🔴' : '⚪') + '</td>';
                            html += '<td class="actions-cell">';
                            html += '<a href="' + item.edit_url + '" title="ویرایش">✏️</a>';
                            html += '<span class="delete-btn" data-id="' + item.id + '" data-template="' + templateId + '" title="حذف">🗑️</span>';
                            html += '</td>';
                            html += '</tr>';
                        });
                        body.html(html);
                        enableSorting(templateId);
                    } else {
                        body.html('<tr class="empty-row"><td colspan="7">هیچ آیتمی یافت نشد</td></tr>');
                    }
                },
                error: function(xhr) {
                    console.error('Error loading items:', xhr);
                    body.html('<tr><td colspan="7" style="text-align:center; color:#ef4444; padding:20px;">❌ خطا در بارگذاری آیتم‌ها</td></tr>');
                }
            });
        }

        // ============================================================
        // ۳. فعال‌سازی Sortable (Drag & Drop)
        // ============================================================
        function enableSorting(templateId) {
            var tableBody = $('#items-table-' + templateId + ' tbody');
            
            if (typeof $.fn.sortable === 'undefined') {
                console.warn('jQuery UI Sortable not available.');
                return;
            }

            if (tableBody.length && tableBody.find('tr').length > 1 && !tableBody.hasClass('ui-sortable')) {
                tableBody.sortable({
                    handle: '.drag-handle',
                    axis: 'y',
                    cursor: 'grab',
                    placeholder: 'ui-sortable-placeholder',
                    forcePlaceholderSize: true,
                    update: function(event, ui) {
                        var ids = [];
                        tableBody.find('tr').each(function() {
                            var id = $(this).data('id');
                            if (id) ids.push(parseInt(id, 10));
                        });
                        if (ids.length > 1) {
                            $.ajax({
                                url: '/admin/core/checklisttemplate/reorder-items/',
                                method: 'POST',
                                data: JSON.stringify({ ids: ids, template_id: templateId }),
                                contentType: 'application/json',
                                headers: { 'X-CSRFToken': getCookie('csrftoken') },
                                success: function(response) {
                                    if (response.success) {
                                        showNotification('✅ ' + response.message, 'success');
                                    } else {
                                        showNotification('❌ ' + response.error, 'error');
                                        loadItems(templateId);
                                    }
                                },
                                error: function(xhr) {
                                    console.error('Reorder error:', xhr);
                                    showNotification('❌ خطا در برقراری ارتباط با سرور.', 'error');
                                    loadItems(templateId);
                                }
                            });
                        }
                    }
                });
                tableBody.disableSelection();
            }
        }

        // ============================================================
        // ۴. فیلتر بر اساس دسته‌بندی
        // ============================================================
        $(document).on('click', '.category-filters .cat-btn', function() {
            var templateId = $(this).data('template');
            var container = $(this).closest('.category-filters');
            container.find('.cat-btn').removeClass('active');
            $(this).addClass('active');
            loadItems(templateId);
        });

        // ============================================================
        // ۵. جستجو
        // ============================================================
        $(document).on('click', '.search-btn', function() {
            var templateId = $(this).data('template');
            loadItems(templateId);
        });
        $(document).on('keypress', '.items-search-input', function(e) {
            if (e.which === 13) {
                var templateId = $(this).data('template');
                loadItems(templateId);
            }
        });

        // ============================================================
        // ۶. افزودن آیتم با AJAX
        // ============================================================
        $(document).on('submit', '.quick-add-form-ajax', function(e) {
            e.preventDefault();
            var form = $(this);
            var templateId = form.data('template');
            var formData = new FormData(this);
            formData.append('template_id', templateId);

            var submitBtn = form.find('.btn-add');
            submitBtn.prop('disabled', true).text('در حال افزودن...');

            $.ajax({
                url: '/admin/core/checklisttemplate/add-item/',
                method: 'POST',
                data: formData,
                processData: false,
                contentType: false,
                headers: { 'X-CSRFToken': getCookie('csrftoken') },
                success: function(response) {
                    if (response.success) {
                        showNotification('✅ ' + response.message, 'success');
                        form.find('input[name="title"]').val('');
                        form.find('input[name="description"]').val('');
                        form.find('input[type="checkbox"]').prop('checked', false);
                        loadItems(templateId);
                    } else {
                        showNotification('❌ ' + response.error, 'error');
                    }
                },
                error: function(xhr) {
                    console.error('Add item error:', xhr);
                    showNotification('❌ خطا در افزودن آیتم.', 'error');
                },
                complete: function() {
                    submitBtn.prop('disabled', false).text('➕ افزودن');
                }
            });
        });

        // ============================================================
        // ۷. حذف آیتم با AJAX
        // ============================================================
        $(document).on('click', '.delete-btn', function() {
            var itemId = $(this).data('id');
            var templateId = $(this).data('template');
            if (!confirm('آیا از حذف این آیتم مطمئن هستید؟')) return;

            var btn = $(this);
            btn.text('⏳');

            $.ajax({
                url: '/admin/core/checklisttemplate/delete-item/' + itemId + '/',
                method: 'POST',
                headers: { 'X-CSRFToken': getCookie('csrftoken') },
                success: function(response) {
                    if (response.success) {
                        showNotification('✅ ' + response.message, 'success');
                        loadItems(templateId);
                    } else {
                        showNotification('❌ ' + response.error, 'error');
                        btn.text('🗑️');
                    }
                },
                error: function(xhr) {
                    console.error('Delete item error:', xhr);
                    showNotification('❌ خطا در حذف آیتم.', 'error');
                    btn.text('🗑️');
                }
            });
        });

        // ============================================================
        // ۸. مدیریت دسته‌بندی جدید در فرم افزودن سریع
        // ============================================================
        $(document).on('change', '.category-select', function() {
            var container = $(this).closest('.quick-add-form');
            if ($(this).val() === '__new__') {
                if (container.find('.new-category-input').length === 0) {
                    var input = $('<input type="text" name="new_category" class="new-category-input" placeholder="نام دسته‌بندی جدید..." style="padding:5px 10px; border:1px solid #d1d5db; border-radius:6px; font-size:13px; min-width:150px;">');
                    $(this).after(input);
                }
            } else {
                container.find('.new-category-input').remove();
            }
        });

        // ============================================================
        // ۹. بارگذاری خودکار برای قالب‌های باز
        // ============================================================
        $('.items-container.visible').each(function() {
            var templateId = $(this).attr('id').replace('items-', '');
            loadItems(templateId);
        });

        // ============================================================
        // ۱۰. توابع کمکی
        // ============================================================
        function getCookie(name) {
            var cookieValue = null;
            if (document.cookie && document.cookie !== '') {
                var cookies = document.cookie.split(';');
                for (var i = 0; i < cookies.length; i++) {
                    var cookie = cookies[i].trim();
                    if (cookie.substring(0, name.length + 1) === (name + '=')) {
                        cookieValue = decodeURIComponent(cookie.substring(name.length + 1));
                        break;
                    }
                }
            }
            return cookieValue;
        }

        function showNotification(message, type) {
            var container = document.querySelector('.content') || document.body;
            var existing = container.querySelector('.custom-notification');
            if (existing) existing.remove();

            var div = document.createElement('div');
            div.className = 'custom-notification ' + type;
            div.textContent = message;
            container.insertBefore(div, container.firstChild);

            setTimeout(function() {
                if (div.parentNode) {
                    div.style.opacity = '0';
                    div.style.transition = 'opacity 0.5s';
                    setTimeout(function() {
                        if (div.parentNode) div.remove();
                    }, 500);
                }
            }, 5000);
        }

        function escapeHtml(text) {
            if (!text) return '';
            var div = document.createElement('div');
            div.textContent = text;
            return div.innerHTML;
        }

    });

})(django.jQuery);
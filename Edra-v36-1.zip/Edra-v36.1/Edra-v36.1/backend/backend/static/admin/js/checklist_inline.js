// static/admin/js/checklist_inline.js
// Drag & Drop برای آیتم‌های چک‌لیست در صفحه تغییر قالب (اینلاین)

(function($) {
    'use strict';

    $(document).ready(function() {

        // ============================================================
        // فعال‌سازی Sortable روی جدول اینلاین
        // ============================================================
        function enableInlineSorting() {
            // ✅ اصلاح: selector ساده‌تر و دقیق‌تر
            var table = $('.inline-related tbody');

            if (table.length === 0) {
                return;
            }

            if (typeof $.fn.sortable === 'undefined') {
                console.warn('jQuery UI Sortable not available.');
                return;
            }

            if (table.hasClass('ui-sortable')) {
                table.sortable('destroy');
            }

            table.sortable({
                handle: '.field-order_handle',
                axis: 'y',
                cursor: 'grab',
                placeholder: 'ui-sortable-placeholder',
                forcePlaceholderSize: true,
                update: function(event, ui) {
                    var rows = table.find('tr');
                    var ids = [];
                    var templateId = $('#id').val();

                    rows.each(function() {
                        var id = $(this).find('input[name$="-id"]').val();
                        if (id) ids.push(parseInt(id, 10));
                    });

                    if (ids.length > 1 && templateId) {
                        $.ajax({
                            url: '/admin/core/checklisttemplate/reorder-items/',
                            method: 'POST',
                            data: JSON.stringify({ ids: ids, template_id: templateId }),
                            contentType: 'application/json',
                            headers: { 'X-CSRFToken': getCookie('csrftoken') },
                            success: function(response) {
                                if (response.success) {
                                    showNotification('✅ ' + response.message, 'success');
                                    rows.each(function(index) {
                                        var orderInput = $(this).find('input[name$="-order"]');
                                        if (orderInput.length) {
                                            orderInput.val(index + 1);
                                        }
                                    });
                                } else {
                                    showNotification('❌ ' + response.error, 'error');
                                }
                            },
                            error: function(xhr) {
                                console.error('Reorder error:', xhr);
                                showNotification('❌ خطا در تغییر ترتیب.', 'error');
                            }
                        });
                    }
                }
            });

            table.disableSelection();
        }

        // ============================================================
        // نظارت بر تغییرات DOM (برای اینلاین‌های پویا)
        // ============================================================
        $(document).on('click', '.add-row', function() {
            setTimeout(enableInlineSorting, 200);
        });

        $(document).on('click', '.delete-row', function() {
            setTimeout(enableInlineSorting, 200);
        });

        // ============================================================
        // اجرا با تاخیر مناسب
        // ============================================================
        $(window).on('load', function() {
            setTimeout(enableInlineSorting, 300);
        });

        setTimeout(enableInlineSorting, 100);

        // ============================================================
        // توابع کمکی
        // ============================================================
        function getCookie(name) {
            var cookieValue = null;
            if (document.cookie && document.cookie !== '') {
                var cookies = document.cookie.split(';');
                for (var i = 0; i < cookies.length; i++) {
                    var cookie = cookies[i].trim();
                    if (cookie.substring(0, name.length + 1) === (name + '=')) {
                        cookieValue = decodeURIComponent(cookie.substring(name.length + 1));
                        break;
                    }
                }
            }
            return cookieValue;
        }

        function showNotification(message, type) {
            var container = document.querySelector('.content') || document.body;
            var existing = container.querySelector('.custom-notification');
            if (existing) existing.remove();

            var div = document.createElement('div');
            div.className = 'custom-notification ' + type;
            div.textContent = message;
            container.insertBefore(div, container.firstChild);

            setTimeout(function() {
                if (div.parentNode) {
                    div.style.opacity = '0';
                    div.style.transition = 'opacity 0.5s';
                    setTimeout(function() {
                        if (div.parentNode) div.remove();
                    }, 500);
                }
            }, 5000);
        }

    });

})(django.jQuery);
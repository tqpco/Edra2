// static/admin/js/menu_manager.js
// مدیریت منوها با Drag & Drop و AJAX

(function($) {
    'use strict';

    $(document).ready(function() {

        // ============================================================
        // ۱. فعال‌سازی Sortable برای جدول آیتم‌های منو
        // ============================================================
        var tableBody = $('#result_list tbody');

        if (tableBody.length && tableBody.find('tr').length > 1) {
            // ذخیره menu_id برای استفاده در AJAX
            var menuId = getMenuId();

            tableBody.sortable({
                handle: '.drag-handle',
                axis: 'y',
                cursor: 'grab',
                placeholder: 'ui-sortable-placeholder',
                forcePlaceholderSize: true,
                update: function(event, ui) {
                    // جمع‌آوری IDهای جدید
                    var ids = [];
                    tableBody.find('tr').each(function() {
                        var checkbox = $(this).find('input[type="checkbox"]');
                        if (checkbox.length) {
                            var id = checkbox.val();
                            if (id) ids.push(parseInt(id, 10));
                        }
                    });

                    if (ids.length > 1) {
                        // ارسال درخواست AJAX برای ذخیره ترتیب جدید
                        $.ajax({
                            url: '/admin/core/menuitem/reorder/',
                            method: 'POST',
                            data: JSON.stringify({
                                ids: ids,
                                menu_id: menuId
                            }),
                            contentType: 'application/json',
                            headers: {
                                'X-CSRFToken': getCookie('csrftoken')
                            },
                            success: function(response) {
                                if (response.success) {
                                    showNotification('✅ ' + response.message, 'success');
                                    // به‌روزرسانی اعداد ترتیب در ستون
                                    updateOrderNumbers(tableBody);
                                } else {
                                    showNotification('❌ ' + response.error, 'error');
                                    // در صورت خطا، صفحه را رفرش کن
                                    location.reload();
                                }
                            },
                            error: function(xhr) {
                                var errorMsg = '❌ خطا در برقراری ارتباط با سرور.';
                                try {
                                    var resp = JSON.parse(xhr.responseText);
                                    if (resp.error) errorMsg = '❌ ' + resp.error;
                                } catch(e) {}
                                showNotification(errorMsg, 'error');
                                location.reload();
                            }
                        });
                    }
                }
            });

            // غیرفعال کردن انتخاب متن هنگام کشیدن
            tableBody.disableSelection();
            tableBody.addClass('sortable-table');
        }

        // ============================================================
        // ۲. توابع کمکی
        // ============================================================

        function getMenuId() {
            // دریافت شناسه منو از URL یا از پارامترهای صفحه
            var urlParams = new URLSearchParams(window.location.search);
            var menuId = urlParams.get('menu');
            if (!menuId) {
                // اگر در صفحه ادمین منو هستیم، از URL استفاده کن
                var pathParts = window.location.pathname.split('/');
                for (var i = 0; i < pathParts.length; i++) {
                    if (pathParts[i] === 'menuitem') {
                        if (i + 1 < pathParts.length && pathParts[i + 1].match(/^\d+$/)) {
                            menuId = pathParts[i + 1];
                        }
                        break;
                    }
                }
            }
            return menuId || '';
        }

        function getCookie(name) {
            var cookieValue = null;
            if (document.cookie && document.cookie !== '') {
                var cookies = document.cookie.split(';');
                for (var i = 0; i < cookies.length; i++) {
                    var cookie = cookies[i].trim();
                    if (cookie.substring(0, name.length + 1) === (name + '=')) {
                        cookieValue = decodeURIComponent(cookie.substring(name.length + 1));
                        break;
                    }
                }
            }
            return cookieValue;
        }

        function showNotification(message, type) {
            var container = document.querySelector('.content') || document.body;
            var existing = container.querySelector('.menu-notification');
            if (existing) existing.remove();

            var div = document.createElement('div');
            div.className = 'menu-notification ' + type;
            div.textContent = message;
            container.insertBefore(div, container.firstChild);

            setTimeout(function() {
                if (div.parentNode) {
                    div.style.opacity = '0';
                    div.style.transition = 'opacity 0.5s';
                    setTimeout(function() {
                        if (div.parentNode) div.remove();
                    }, 500);
                }
            }, 5000);
        }

        function updateOrderNumbers(tableBody) {
            tableBody.find('tr').each(function(index) {
                var orderCell = $(this).find('.field-order');
                if (orderCell.length) {
                    orderCell.text(index + 1);
                }
            });
        }

        // ============================================================
        // ۳. بارگذاری خودکار برای صفحات با جداول منو
        // ============================================================

        // اگر جدول منوها در صفحه وجود دارد، ارتفاع placeholder را تنظیم کن
        if ($('#result_list tbody').length) {
            var placeholderHeight = $('#result_list tbody tr:first').outerHeight() || 45;
            $('<style>')
                .prop('type', 'text/css')
                .html('.ui-sortable-placeholder { height: ' + placeholderHeight + 'px !important; }')
                .appendTo('head');
        }

        console.log('📋 منو منیجر فعال شد. برای جابه‌جایی آیتم‌ها، دستگیره ⠿ را بکشید.');
    });

})(django.jQuery);
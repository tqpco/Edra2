# support/admin.py
# -*- coding: utf-8 -*-

from django.contrib import admin
from django.utils.html import format_html
from django.urls import reverse
from django.utils import timezone
from django.contrib import messages

from core.models import InspectionRequest

# ✅ اصلاح: ایمپورت مستقیم از پکیج edra_jalalidate
from edra_jalalidate.admin import EdraJalaliAdminMixin, make_jalali_date_filter
from edra_jalalidate import to_jalali
from core.admin.common import get_customer_info

from .models import (
    TicketSystemSettings, TicketCategory, TicketPriority, TicketStatus,
    TicketDepartment, TicketLabel, Ticket, TicketComment, TicketAttachment,
    TicketActivityLog, SavedReply, KnowledgeBaseCategory, KnowledgeBaseArticle,
    Announcement, TicketNotification, UserAccountSettings, SLA, TicketRule,
    Webhook, TicketDuplicate
)


# ============================================================
# تنظیمات سیستم
# ============================================================
@admin.register(TicketSystemSettings)
class TicketSystemSettingsAdmin(admin.ModelAdmin):
    list_display = ('system_title', 'is_active')
    fieldsets = (
        ('اطلاعات عمومی', {
            'fields': ('system_title', 'logo', 'is_active')
        }),
        ('تنظیمات', {
            'fields': ('items_per_page', 'max_upload_size')
        }),
        ('پیام‌ها', {
            'fields': ('maintenance_message', 'blocked_ips')
        }),
    )


# ============================================================
# موارد پایه تیکت
# ============================================================
@admin.register(TicketCategory)
class TicketCategoryAdmin(admin.ModelAdmin):
    list_display = ('name', 'is_active')
    list_filter = ('is_active',)
    search_fields = ('name',)


@admin.register(TicketPriority)
class TicketPriorityAdmin(admin.ModelAdmin):
    list_display = ('name', 'color', 'weight', 'is_active')
    list_filter = ('is_active',)
    search_fields = ('name',)


@admin.register(TicketStatus)
class TicketStatusAdmin(admin.ModelAdmin):
    list_display = ('name', 'color', 'is_closed', 'is_active')
    list_filter = ('is_closed', 'is_active')
    search_fields = ('name',)


@admin.register(TicketDepartment)
class TicketDepartmentAdmin(admin.ModelAdmin):
    list_display = ('name', 'member_count', 'is_active')
    list_filter = ('is_active',)
    search_fields = ('name',)

    def member_count(self, obj):
        return obj.members.count()
    member_count.short_description = "تعداد اعضا"


@admin.register(TicketLabel)
class TicketLabelAdmin(admin.ModelAdmin):
    list_display = ('name', 'color')
    search_fields = ('name',)


@admin.register(SLA)
class SLAAdmin(admin.ModelAdmin):
    list_display = ('name', 'priority', 'response_time_hours', 'resolution_time_hours', 'is_active')
    list_filter = ('is_active', 'priority')
    search_fields = ('name',)


@admin.register(TicketRule)
class TicketRuleAdmin(admin.ModelAdmin):
    list_display = ('name', 'condition_type', 'condition_value', 'action_type', 'is_active', 'order')
    list_filter = ('is_active', 'condition_type', 'action_type')
    search_fields = ('name',)
    ordering = ('order',)


@admin.register(Webhook)
class WebhookAdmin(admin.ModelAdmin):
    list_display = ('name', 'url', 'events', 'is_active')
    list_filter = ('is_active', 'events')
    search_fields = ('name', 'url')


# ============================================================
# تیکت‌ها و بخش‌های مرتبط (با ویجت جلالی و نمایش تاریخ + ساعت)
# ============================================================
class TicketAttachmentInline(EdraJalaliAdminMixin, admin.TabularInline):
    model = TicketAttachment
    extra = 0
    fields = ('filename', 'file_size', 'uploaded_by', 'uploaded_at_display')
    readonly_fields = ('uploaded_at_display',)

    def uploaded_at_display(self, obj):
        return to_jalali(obj.uploaded_at, "%Y/%m/%d %H:%M")
    uploaded_at_display.short_description = "تاریخ آپلود (جلالی)"


class TicketCommentInline(EdraJalaliAdminMixin, admin.TabularInline):
    model = TicketComment
    extra = 0
    fields = ('user', 'content_preview', 'is_internal', 'created_at_display')
    readonly_fields = ('content_preview', 'created_at_display')
    can_delete = True

    def content_preview(self, obj):
        return (obj.content[:50] + '...') if len(obj.content) > 50 else obj.content
    content_preview.short_description = "محتوا"

    def created_at_display(self, obj):
        return to_jalali(obj.created_at, "%Y/%m/%d %H:%M")
    created_at_display.short_description = "تاریخ ایجاد (جلالی)"


@admin.register(Ticket)
class TicketAdmin(EdraJalaliAdminMixin, admin.ModelAdmin):
    """
    ادمین تیکت با ویجت جلالی و نمایش تاریخ + ساعت
    """
    list_display = (
        'id',
        'title',
        'customer_link',
        'assigned_to_link',
        'status_display',
        'priority_display',
        'created_at_display',
        'is_pinned'
    )
    list_filter = (
        'status', 'priority', 'category', 'department',
        'is_pinned', 'is_confidential',
        make_jalali_date_filter('created_at', 'تاریخ ایجاد')
    )
    search_fields = (
        'title', 'description', 'customer__username', 'customer__email',
        'customer__profile__phone', 'assigned_to__username'
    )
    readonly_fields = (
        'created_at_display',
        'updated_at_display',
        'closed_at_display',
        'first_response_at_display',
        'resolved_at_display',
        'view_count',
        'escalation_level'
    )
    inlines = [TicketCommentInline, TicketAttachmentInline]
    actions = ['assign_to_me', 'mark_as_resolved', 'pin_ticket', 'unpin_ticket']

    fieldsets = (
        ('اطلاعات اصلی', {
            'fields': ('title', 'description', 'inspection_request')
        }),
        ('مشتری و تخصیص', {
            'fields': ('customer', 'assigned_to', 'department')
        }),
        ('دسته‌بندی و اولویت', {
            'fields': ('category', 'priority', 'status', 'labels')
        }),
        ('SLA و زمان‌بندی', {
            'fields': ('sla', 'due_date')
        }),
        ('تنظیمات', {
            'fields': ('is_pinned', 'is_confidential')
        }),
        ('اطلاعات سیستمی', {
            'fields': (
                'created_at_display', 'updated_at_display', 'closed_at_display',
                'first_response_at_display', 'resolved_at_display',
                'view_count', 'escalation_level'
            ),
            'classes': ('collapse',)
        }),
    )

    def get_queryset(self, request):
        qs = super().get_queryset(request)
        return qs.select_related(
            'customer', 'assigned_to', 'status', 'priority', 'category', 'department', 'sla'
        )

    def customer_link(self, obj):
        if obj.customer:
            url = reverse('admin:auth_user_change', args=[obj.customer.id])
            return format_html('<a href="{}">{}</a>', url, obj.customer.get_full_name() or obj.customer.username)
        return "—"
    customer_link.short_description = "مشتری"

    def assigned_to_link(self, obj):
        if obj.assigned_to:
            url = reverse('admin:auth_user_change', args=[obj.assigned_to.id])
            return format_html('<a href="{}">{}</a>', url, obj.assigned_to.get_full_name() or obj.assigned_to.username)
        return "—"
    assigned_to_link.short_description = "اختصاص داده شده به"

    def status_display(self, obj):
        color = obj.status.color if obj.status else '#6B7280'
        return format_html(
            '<span style="background-color: {}; color: white; padding: 2px 8px; border-radius: 12px;">{}</span>',
            color,
            obj.status.name if obj.status else "نامشخص"
        )
    status_display.short_description = "وضعیت"

    def priority_display(self, obj):
        color = obj.priority.color if obj.priority else '#6B7280'
        return format_html(
            '<span style="background-color: {}; color: white; padding: 2px 8px; border-radius: 12px;">{}</span>',
            color,
            obj.priority.name if obj.priority else "نامشخص"
        )
    priority_display.short_description = "اولویت"

    def created_at_display(self, obj):
        return to_jalali(obj.created_at, "%Y/%m/%d %H:%M")
    created_at_display.short_description = "تاریخ ایجاد (جلالی)"
    created_at_display.admin_order_field = 'created_at'

    def updated_at_display(self, obj):
        return to_jalali(obj.updated_at, "%Y/%m/%d %H:%M")
    updated_at_display.short_description = "تاریخ بروزرسانی (جلالی)"

    def closed_at_display(self, obj):
        return to_jalali(obj.closed_at, "%Y/%m/%d %H:%M")
    closed_at_display.short_description = "تاریخ بسته شدن (جلالی)"

    def first_response_at_display(self, obj):
        return to_jalali(obj.first_response_at, "%Y/%m/%d %H:%M")
    first_response_at_display.short_description = "زمان اولین پاسخ (جلالی)"

    def resolved_at_display(self, obj):
        return to_jalali(obj.resolved_at, "%Y/%m/%d %H:%M")
    resolved_at_display.short_description = "زمان حل (جلالی)"

    @admin.action(description='اختصاص به من')
    def assign_to_me(self, request, queryset):
        updated = 0
        for ticket in queryset:
            if not ticket.assigned_to:
                ticket.assigned_to = request.user
                ticket.save()
                updated += 1
        self.message_user(request, f'{updated} تیکت به شما اختصاص داده شد.', messages.SUCCESS)

    @admin.action(description='علامت‌گذاری به عنوان حل‌شده')
    def mark_as_resolved(self, request, queryset):
        resolved_status = TicketStatus.objects.filter(is_closed=True).first()
        if not resolved_status:
            self.message_user(request, 'وضعیت بسته‌شده‌ای یافت نشد.', messages.ERROR)
            return
        updated = queryset.update(
            status=resolved_status,
            resolved_at=timezone.now()
        )
        self.message_user(request, f'{updated} تیکت به عنوان حل‌شده علامت‌گذاری شد.', messages.SUCCESS)

    @admin.action(description='سنجاق کردن')
    def pin_ticket(self, request, queryset):
        updated = queryset.update(is_pinned=True)
        self.message_user(request, f'{updated} تیکت سنجاق شد.', messages.SUCCESS)

    @admin.action(description='برداشتن سنجاق')
    def unpin_ticket(self, request, queryset):
        updated = queryset.update(is_pinned=False)
        self.message_user(request, f'{updated} تیکت از سنجاق خارج شد.', messages.SUCCESS)


@admin.register(TicketComment)
class TicketCommentAdmin(EdraJalaliAdminMixin, admin.ModelAdmin):
    list_display = ('id', 'ticket_link', 'user', 'content_preview', 'is_internal', 'created_at_display')
    list_filter = ('is_internal',)
    search_fields = ('content', 'user__username', 'ticket__title')
    readonly_fields = ('created_at_display', 'updated_at_display')

    def ticket_link(self, obj):
        url = reverse('admin:support_ticket_change', args=[obj.ticket.id])
        return format_html('<a href="{}">تیکت #{}</a>', url, obj.ticket.id)
    ticket_link.short_description = "تیکت"

    def content_preview(self, obj):
        return (obj.content[:50] + '...') if len(obj.content) > 50 else obj.content
    content_preview.short_description = "محتوا"

    def created_at_display(self, obj):
        return to_jalali(obj.created_at, "%Y/%m/%d %H:%M")
    created_at_display.short_description = "تاریخ ایجاد (جلالی)"

    def updated_at_display(self, obj):
        return to_jalali(obj.updated_at, "%Y/%m/%d %H:%M")
    updated_at_display.short_description = "تاریخ بروزرسانی (جلالی)"


@admin.register(TicketAttachment)
class TicketAttachmentAdmin(EdraJalaliAdminMixin, admin.ModelAdmin):
    list_display = ('filename', 'ticket_link', 'uploaded_by', 'file_size', 'uploaded_at_display')
    search_fields = ('filename', 'ticket__title', 'uploaded_by__username')
    readonly_fields = ('uploaded_at_display',)

    def ticket_link(self, obj):
        url = reverse('admin:support_ticket_change', args=[obj.ticket.id])
        return format_html('<a href="{}">تیکت #{}</a>', url, obj.ticket.id)
    ticket_link.short_description = "تیکت"

    def uploaded_at_display(self, obj):
        return to_jalali(obj.uploaded_at, "%Y/%m/%d %H:%M")
    uploaded_at_display.short_description = "تاریخ آپلود (جلالی)"


@admin.register(TicketActivityLog)
class TicketActivityLogAdmin(admin.ModelAdmin):
    list_display = ('ticket_link', 'user', 'action_display', 'created_at_display')
    list_filter = ('action',)
    search_fields = ('ticket__title', 'user__username')
    readonly_fields = ('created_at_display',)

    def ticket_link(self, obj):
        url = reverse('admin:support_ticket_change', args=[obj.ticket.id])
        return format_html('<a href="{}">تیکت #{}</a>', url, obj.ticket.id)
    ticket_link.short_description = "تیکت"

    def action_display(self, obj):
        return obj.get_action_display()
    action_display.short_description = "عملیات"

    def created_at_display(self, obj):
        return to_jalali(obj.created_at, "%Y/%m/%d %H:%M")
    created_at_display.short_description = "تاریخ ایجاد (جلالی)"


# ============================================================
# پاسخ‌های ذخیره‌شده و دانش
# ============================================================
@admin.register(SavedReply)
class SavedReplyAdmin(admin.ModelAdmin):
    list_display = ('title', 'category', 'is_active', 'created_by', 'created_at_display')
    list_filter = ('is_active', 'category')
    search_fields = ('title', 'content')
    readonly_fields = ('created_at_display',)

    def created_at_display(self, obj):
        return to_jalali(obj.created_at, "%Y/%m/%d %H:%M")
    created_at_display.short_description = "تاریخ ایجاد (جلالی)"


@admin.register(KnowledgeBaseCategory)
class KnowledgeBaseCategoryAdmin(admin.ModelAdmin):
    list_display = ('name', 'parent', 'is_active', 'order')
    list_filter = ('is_active',)
    search_fields = ('name',)
    ordering = ('order',)


@admin.register(KnowledgeBaseArticle)
class KnowledgeBaseArticleAdmin(EdraJalaliAdminMixin, admin.ModelAdmin):
    list_display = ('title', 'category', 'is_published', 'view_count', 'created_at_display')
    list_filter = ('is_published', 'category')
    search_fields = ('title', 'content', 'tags')
    readonly_fields = (
        'view_count', 'helpful_count', 'unhelpful_count',
        'created_at_display', 'updated_at_display'
    )

    def created_at_display(self, obj):
        return to_jalali(obj.created_at, "%Y/%m/%d %H:%M")
    created_at_display.short_description = "تاریخ ایجاد (جلالی)"

    def updated_at_display(self, obj):
        return to_jalali(obj.updated_at, "%Y/%m/%d %H:%M")
    updated_at_display.short_description = "تاریخ بروزرسانی (جلالی)"


# ============================================================
# اعلان‌ها (با ویجت جلالی و نمایش تاریخ + ساعت)
# ============================================================
@admin.register(Announcement)
class AnnouncementAdmin(EdraJalaliAdminMixin, admin.ModelAdmin):
    """
    ادمین اعلان‌ها با ویجت جلالی و نمایش تاریخ + ساعت
    """
    list_display = (
        'title',
        'audience',
        'is_active',
        'created_by_link',
        'created_at_display',
        'expires_at_display'
    )
    list_filter = (
        'is_active',
        'audience',
        make_jalali_date_filter('created_at', 'تاریخ ایجاد')
    )
    search_fields = ('title', 'content')
    readonly_fields = (
        'created_at_display',
        'expires_at_display',
        'created_by_link'
    )

    fieldsets = (
        ('اطلاعات اعلان', {
            'fields': ('title', 'content', 'audience', 'is_active')
        }),
        ('زمان‌بندی', {
            'fields': ('expires_at', 'expires_at_display')
        }),
        ('اطلاعات سیستمی', {
            'fields': ('created_by_link', 'created_at_display'),
            'classes': ('collapse',)
        }),
    )

    def save_model(self, request, obj, form, change):
        if not obj.created_by_id:
            obj.created_by = request.user
        super().save_model(request, obj, form, change)

    def created_by_link(self, obj):
        if obj.created_by:
            url = reverse('admin:auth_user_change', args=[obj.created_by.id])
            return format_html('<a href="{}">{}</a>', url, obj.created_by.get_full_name() or obj.created_by.username)
        return "—"
    created_by_link.short_description = "ایجادکننده"

    def created_at_display(self, obj):
        return to_jalali(obj.created_at, "%Y/%m/%d %H:%M")
    created_at_display.short_description = "تاریخ ایجاد (جلالی)"
    created_at_display.admin_order_field = 'created_at'

    def expires_at_display(self, obj):
        return to_jalali(obj.expires_at, "%Y/%m/%d %H:%M") if obj.expires_at else "—"
    expires_at_display.short_description = "تاریخ انقضا (جلالی)"
    expires_at_display.admin_order_field = 'expires_at'


# ============================================================
# اعلان‌های تیکت و تنظیمات کاربر (با ویجت جلالی و نمایش تاریخ + ساعت)
# ============================================================
@admin.register(TicketNotification)
class TicketNotificationAdmin(EdraJalaliAdminMixin, admin.ModelAdmin):
    list_display = ('user', 'ticket_link', 'type_display', 'is_read', 'created_at_display')
    list_filter = ('type', 'is_read')
    search_fields = ('user__username', 'ticket__title')
    readonly_fields = ('created_at_display',)

    def ticket_link(self, obj):
        url = reverse('admin:support_ticket_change', args=[obj.ticket.id])
        return format_html('<a href="{}">تیکت #{}</a>', url, obj.ticket.id)
    ticket_link.short_description = "تیکت"

    def type_display(self, obj):
        return obj.get_type_display()
    type_display.short_description = "نوع"

    def created_at_display(self, obj):
        return to_jalali(obj.created_at, "%Y/%m/%d %H:%M")
    created_at_display.short_description = "تاریخ ایجاد (جلالی)"


# ============================================================
# ✅ تنظیمات حساب کاربری (UserAccountSettings) با نمایش تاریخ + ساعت
# ============================================================
@admin.register(UserAccountSettings)
class UserAccountSettingsAdmin(EdraJalaliAdminMixin, admin.ModelAdmin):
    """
    ادمین تنظیمات حساب کاربری با ویجت جلالی و نمایش تاریخ + ساعت
    """
    list_display = ('user', 'is_suspended', 'account_expiry_display')
    list_filter = ('is_suspended',)
    search_fields = ('user__username',)
    readonly_fields = (
        'account_expiry_display',
        'created_at_display',
        'updated_at_display'
    )

    fieldsets = (
        ('اطلاعات کاربر', {
            'fields': ('user', 'is_suspended', 'suspension_reason')
        }),
        ('انقضا', {
            'fields': ('account_expiry', 'account_expiry_display')
        }),
        ('اطلاعات سیستمی', {
            'fields': ('created_at_display', 'updated_at_display'),
            'classes': ('collapse',)
        }),
    )

    # ✅ نمایش تاریخ انقضا با فرمت شامل ساعت
    def account_expiry_display(self, obj):
        if obj.account_expiry:
            return to_jalali(obj.account_expiry, "%Y/%m/%d %H:%M")
        return "—"
    account_expiry_display.short_description = "تاریخ انقضا (جلالی)"
    account_expiry_display.admin_order_field = 'account_expiry'

    # ✅ نمایش تاریخ ایجاد با فرمت شامل ساعت
    def created_at_display(self, obj):
        return to_jalali(obj.created_at, "%Y/%m/%d %H:%M")
    created_at_display.short_description = "تاریخ ایجاد (جلالی)"

    # ✅ نمایش تاریخ بروزرسانی با فرمت شامل ساعت
    def updated_at_display(self, obj):
        return to_jalali(obj.updated_at, "%Y/%m/%d %H:%M")
    updated_at_display.short_description = "تاریخ بروزرسانی (جلالی)"


@admin.register(TicketDuplicate)
class TicketDuplicateAdmin(admin.ModelAdmin):
    list_display = ('ticket_link', 'duplicate_ticket_link', 'similarity_score', 'created_at_display')
    search_fields = ('ticket__title', 'duplicate_ticket__title')
    readonly_fields = ('created_at_display',)

    def ticket_link(self, obj):
        url = reverse('admin:support_ticket_change', args=[obj.ticket.id])
        return format_html('<a href="{}">تیکت اصلی #{}</a>', url, obj.ticket.id)
    ticket_link.short_description = "تیکت اصلی"

    def duplicate_ticket_link(self, obj):
        url = reverse('admin:support_ticket_change', args=[obj.duplicate_ticket.id])
        return format_html('<a href="{}">تیکت تکراری #{}</a>', url, obj.duplicate_ticket.id)
    duplicate_ticket_link.short_description = "تیکت تکراری"

    def created_at_display(self, obj):
        return to_jalali(obj.created_at, "%Y/%m/%d %H:%M")
    created_at_display.short_description = "تاریخ تشخیص (جلالی)"
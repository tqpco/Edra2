# support/consumers.py
# -*- coding: utf-8 -*-

import json
from channels.generic.websocket import AsyncWebsocketConsumer
from channels.db import database_sync_to_async
from django.contrib.auth import get_user_model
from .models import Ticket, TicketComment

User = get_user_model()


class TicketConsumer(AsyncWebsocketConsumer):
    async def connect(self):
        self.user = self.scope['user']
        if not self.user.is_authenticated:
            await self.close()
            return

        # گروه‌های عمومی برای همه کاربران (برای اعلان‌های عمومی)
        self.groups = ['ticket_public']

        # اگر کاربر پشتیبانی یا ادمین است، به گروه اختصاصی کارکنان می‌پیوندد
        from core.permissions import is_support_or_admin
        if is_support_or_admin(self.user):
            self.groups.append('ticket_staff')

        # گروه اختصاصی برای تیکت‌های خاص (اختیاری)
        self.ticket_group = None

        for group in self.groups:
            await self.channel_layer.group_add(group, self.channel_name)

        await self.accept()

    async def disconnect(self, close_code):
        for group in self.groups:
            await self.channel_layer.group_discard(group, self.channel_name)
        if self.ticket_group:
            await self.channel_layer.group_discard(self.ticket_group, self.channel_name)

    async def receive(self, text_data):
        data = json.loads(text_data)
        action = data.get('action')

        if action == 'subscribe_ticket':
            ticket_id = data.get('ticket_id')
            if ticket_id:
                # EDRA v33 — SEC: هر کاربر واردشده می‌توانست با هر ticket_id
                # عنوان/وضعیت/ارجاع تیکت دیگران را بگیرد و عضو گروه آن شود.
                # حالا فقط مشتریِ همان تیکت، کارشناس ارجاع‌شده یا کارکنان.
                ticket_data = await self.get_ticket_data(ticket_id)
                if ticket_data is None:
                    return
                if self.ticket_group:
                    await self.channel_layer.group_discard(
                        self.ticket_group, self.channel_name)
                self.ticket_group = f'ticket_{ticket_id}'
                await self.channel_layer.group_add(self.ticket_group, self.channel_name)
                await self.send(text_data=json.dumps({
                    'type': 'ticket_data',
                    'data': ticket_data
                }))

        elif action == 'unsubscribe_ticket':
            if self.ticket_group:
                await self.channel_layer.group_discard(self.ticket_group, self.channel_name)
                self.ticket_group = None

    async def ticket_notification(self, event):
        """ارسال نوتیفیکیشن تیکت به کاربر."""
        await self.send(text_data=json.dumps({
            'type': 'notification',
            'data': event['data']
        }))

    @database_sync_to_async
    def get_ticket_data(self, ticket_id):
        try:
            ticket = Ticket.objects.select_related('status', 'priority', 'category', 'assigned_to').get(id=ticket_id)
            from core.permissions import is_support_or_admin
            if not (ticket.customer_id == self.user.id
                    or ticket.assigned_to_id == self.user.id
                    or is_support_or_admin(self.user)):
                return None
            return {
                'id': ticket.id,
                'title': ticket.title,
                'status': ticket.status.name if ticket.status else None,
                'priority': ticket.priority.name if ticket.priority else None,
                'assigned_to': ticket.assigned_to.get_full_name() if ticket.assigned_to else None,
                'comments_count': ticket.comments.count(),
                'created_at': ticket.created_at.isoformat()
            }
        except (Ticket.DoesNotExist, ValueError, TypeError):
            return None
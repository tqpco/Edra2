# support/middlewares.py
from django.http import HttpResponseForbidden
from .models import TicketSystemSettings


class BlockedIPMiddleware:
    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        settings = TicketSystemSettings.objects.first()
        if settings and settings.blocked_ips:
            blocked = [ip.strip() for ip in settings.blocked_ips.split(',') if ip.strip()]
            # بررسی IP واقعی (در صورت استفاده از پروکسی)
            ip = request.META.get('HTTP_X_FORWARDED_FOR')
            if ip:
                ip = ip.split(',')[0].strip()
            else:
                ip = request.META.get('REMOTE_ADDR')
            if ip in blocked:
                return HttpResponseForbidden("دسترسی شما به دلیل IP مسدود شده امکان‌پذیر نیست.")
        return self.get_response(request)
# support/models.py
from django.db import models
from django.contrib.auth import get_user_model
from core.utils.upload_paths import ticket_attachment_upload_path
from django.core.validators import MinValueValidator, MaxValueValidator

User = get_user_model()


class TicketSystemSettings(models.Model):
    system_title = models.CharField(max_length=200, default='سیستم پشتیبانی', verbose_name='عنوان سیستم')
    logo = models.ImageField(upload_to='ticket_logo/', blank=True, null=True, verbose_name='لوگو')
    items_per_page = models.PositiveIntegerField(default=20, verbose_name='تعداد آیتم در هر صفحه')
    max_upload_size = models.PositiveIntegerField(default=5242880, verbose_name='حداکثر حجم آپلود (بایت)')
    is_active = models.BooleanField(default=True, verbose_name='فعال')
    maintenance_message = models.TextField(blank=True, verbose_name='پیام تعمیرات')
    blocked_ips = models.TextField(blank=True, verbose_name='IPهای مسدود شده')

    def __str__(self):
        return self.system_title

    class Meta:
        verbose_name = 'تنظیمات سیستم تیکت'
        verbose_name_plural = 'تنظیمات سیستم تیکت'


class TicketCategory(models.Model):
    name = models.CharField(max_length=100, verbose_name='نام')
    description = models.TextField(blank=True, verbose_name='توضیحات')
    is_active = models.BooleanField(default=True, verbose_name='فعال')
    created_at = models.DateTimeField(auto_now_add=True, verbose_name='تاریخ ایجاد')

    def __str__(self):
        return self.name

    class Meta:
        verbose_name = 'دسته‌بندی تیکت'
        verbose_name_plural = 'دسته‌بندی تیکت‌ها'


class TicketPriority(models.Model):
    name = models.CharField(max_length=50, verbose_name='نام')
    color = models.CharField(max_length=7, default='#6B7280', verbose_name='رنگ')
    weight = models.PositiveIntegerField(default=0, verbose_name='وزن')
    is_active = models.BooleanField(default=True, verbose_name='فعال')

    def __str__(self):
        return self.name

    class Meta:
        verbose_name = 'اولویت تیکت'
        verbose_name_plural = 'اولویت‌های تیکت'


class TicketStatus(models.Model):
    name = models.CharField(max_length=50, verbose_name='نام')
    color = models.CharField(max_length=7, default='#6B7280', verbose_name='رنگ')
    is_closed = models.BooleanField(default=False, verbose_name='بسته شده')
    is_active = models.BooleanField(default=True, verbose_name='فعال')

    def __str__(self):
        return self.name

    class Meta:
        verbose_name = 'وضعیت تیکت'
        verbose_name_plural = 'وضعیت‌های تیکت'


class TicketDepartment(models.Model):
    name = models.CharField(max_length=100, verbose_name='نام')
    description = models.TextField(blank=True, verbose_name='توضیحات')
    members = models.ManyToManyField(User, related_name='ticket_departments', blank=True, verbose_name='اعضا')
    is_active = models.BooleanField(default=True, verbose_name='فعال')

    def __str__(self):
        return self.name

    class Meta:
        verbose_name = 'دپارتمان تیکت'
        verbose_name_plural = 'دپارتمان‌های تیکت'


class TicketLabel(models.Model):
    name = models.CharField(max_length=50, verbose_name='نام')
    color = models.CharField(max_length=7, default='#6B7280', verbose_name='رنگ')

    def __str__(self):
        return self.name

    class Meta:
        verbose_name = 'برچسب تیکت'
        verbose_name_plural = 'برچسب‌های تیکت'


class SLA(models.Model):
    name = models.CharField(max_length=100, verbose_name='نام')
    priority = models.ForeignKey(TicketPriority, on_delete=models.CASCADE, verbose_name='اولویت مرتبط')
    response_time_hours = models.PositiveIntegerField(verbose_name='زمان پاسخ (ساعت)')
    resolution_time_hours = models.PositiveIntegerField(verbose_name='زمان حل (ساعت)')
    escalation_time_hours = models.PositiveIntegerField(default=24, verbose_name='زمان ارتقا (ساعت)')
    is_active = models.BooleanField(default=True, verbose_name='فعال')

    def __str__(self):
        return f"{self.name} ({self.priority})"

    class Meta:
        verbose_name = 'SLA'
        verbose_name_plural = 'SLAها'


class TicketRule(models.Model):
    CONDITION_CHOICES = [
        ('category', 'دسته‌بندی'),
        ('priority', 'اولویت'),
        ('status', 'وضعیت'),
        ('department', 'دپارتمان'),
        ('keyword', 'کلیدواژه در عنوان/توضیحات'),
    ]
    ACTION_CHOICES = [
        ('assign_user', 'اختصاص به کاربر مشخص'),
        ('assign_department', 'اختصاص به دپارتمان مشخص'),
        ('set_priority', 'تنظیم اولویت'),
        ('set_status', 'تنظیم وضعیت'),
        ('add_label', 'افزودن برچسب'),
    ]
    name = models.CharField(max_length=100, verbose_name='نام')
    condition_type = models.CharField(max_length=20, choices=CONDITION_CHOICES, verbose_name='نوع شرط')
    condition_value = models.CharField(max_length=200, verbose_name='مقدار شرط')
    action_type = models.CharField(max_length=20, choices=ACTION_CHOICES, verbose_name='نوع اقدام')
    action_value = models.CharField(max_length=200, verbose_name='مقدار اقدام')
    is_active = models.BooleanField(default=True, verbose_name='فعال')
    order = models.PositiveIntegerField(default=0, verbose_name='ترتیب اجرا')

    def __str__(self):
        return self.name

    class Meta:
        verbose_name = 'قانون تیکت'
        verbose_name_plural = 'قوانین تیکت'
        ordering = ['order']


class Ticket(models.Model):
    title = models.CharField(max_length=200, verbose_name='عنوان')
    description = models.TextField(verbose_name='توضیحات')
    inspection_request = models.ForeignKey(
        'core.InspectionRequest', null=True, blank=True,
        on_delete=models.SET_NULL, related_name='tickets', verbose_name='درخواست کارشناسی مرتبط'
    )
    customer = models.ForeignKey(User, on_delete=models.PROTECT, related_name='tickets', verbose_name='مشتری')
    assigned_to = models.ForeignKey(
        User, on_delete=models.SET_NULL, null=True, blank=True,
        related_name='assigned_tickets', verbose_name='اختصاص داده شده به'
    )
    category = models.ForeignKey(TicketCategory, on_delete=models.SET_NULL, null=True, verbose_name='دسته‌بندی')
    priority = models.ForeignKey(TicketPriority, on_delete=models.SET_NULL, null=True, verbose_name='اولویت')
    status = models.ForeignKey(TicketStatus, on_delete=models.SET_NULL, null=True, verbose_name='وضعیت')
    department = models.ForeignKey(TicketDepartment, on_delete=models.SET_NULL, null=True, verbose_name='دپارتمان')
    labels = models.ManyToManyField(TicketLabel, blank=True, verbose_name='برچسب‌ها')
    due_date = models.DateTimeField(null=True, blank=True, verbose_name='تاریخ سررسید')
    closed_at = models.DateTimeField(null=True, blank=True, verbose_name='تاریخ بسته شدن')
    is_pinned = models.BooleanField(default=False, verbose_name='سنجاق شده')
    is_confidential = models.BooleanField(default=False, verbose_name='محرمانه')
    view_count = models.PositiveIntegerField(default=0, verbose_name='تعداد بازدید')
    created_at = models.DateTimeField(auto_now_add=True, verbose_name='تاریخ ایجاد')
    updated_at = models.DateTimeField(auto_now=True, verbose_name='تاریخ بروزرسانی')

    # فیلدهای مرتبط با SLA
    sla = models.ForeignKey(SLA, null=True, blank=True, on_delete=models.SET_NULL, verbose_name='SLA')
    first_response_at = models.DateTimeField(null=True, blank=True, verbose_name='زمان اولین پاسخ')
    resolved_at = models.DateTimeField(null=True, blank=True, verbose_name='زمان حل')
    escalation_level = models.PositiveIntegerField(default=0, verbose_name='سطح ارتقا')

    def __str__(self):
        return f"{self.id} - {self.title}"

    class Meta:
        verbose_name = 'تیکت'
        verbose_name_plural = 'تیکت‌ها'
        ordering = ['-is_pinned', '-created_at']


class TicketComment(models.Model):
    ticket = models.ForeignKey(Ticket, on_delete=models.CASCADE, related_name='comments', verbose_name='تیکت')
    user = models.ForeignKey(User, on_delete=models.PROTECT, related_name='ticket_comments', verbose_name='کاربر')
    content = models.TextField(verbose_name='محتوا')
    is_internal = models.BooleanField(default=False, verbose_name='داخلی')
    created_at = models.DateTimeField(auto_now_add=True, verbose_name='تاریخ ایجاد')
    updated_at = models.DateTimeField(auto_now=True, verbose_name='تاریخ بروزرسانی')

    def __str__(self):
        return f"نظر {self.user.username} در تیکت {self.ticket.id}"

    class Meta:
        verbose_name = 'نظر تیکت'
        verbose_name_plural = 'نظرات تیکت'
        ordering = ['created_at']


class TicketAttachment(models.Model):
    ticket = models.ForeignKey(Ticket, on_delete=models.CASCADE, related_name='attachments', verbose_name='تیکت')
    comment = models.ForeignKey(TicketComment, on_delete=models.CASCADE, null=True, blank=True, related_name='attachments', verbose_name='نظر')
    file = models.FileField(upload_to=ticket_attachment_upload_path, verbose_name='فایل')
    filename = models.CharField(max_length=255, verbose_name='نام فایل')
    file_size = models.PositiveIntegerField(verbose_name='حجم فایل (بایت)')
    uploaded_by = models.ForeignKey(User, on_delete=models.PROTECT, related_name='ticket_attachments', verbose_name='آپلود کننده')
    uploaded_at = models.DateTimeField(auto_now_add=True, verbose_name='تاریخ آپلود')

    def __str__(self):
        return self.filename

    class Meta:
        verbose_name = 'پیوست تیکت'
        verbose_name_plural = 'پیوست‌های تیکت'


class TicketActivityLog(models.Model):
    ACTION_CHOICES = [
        ('create', 'ایجاد'),
        ('comment', 'نظر'),
        ('assign', 'اختصاص'),
        ('change_status', 'تغییر وضعیت'),
        ('change_priority', 'تغییر اولویت'),
        ('toggle_pin', 'تغییر سنجاق'),
        ('refer', 'ارجاع'),
        ('escalate', 'ارتقا'),
        ('auto_close', 'بسته شدن خودکار'),
    ]
    ticket = models.ForeignKey(Ticket, on_delete=models.CASCADE, related_name='activity_logs', verbose_name='تیکت')
    user = models.ForeignKey(User, on_delete=models.PROTECT, related_name='ticket_activities', verbose_name='کاربر')
    action = models.CharField(max_length=20, choices=ACTION_CHOICES, verbose_name='عملیات')
    details = models.JSONField(default=dict, verbose_name='جزئیات')
    created_at = models.DateTimeField(auto_now_add=True, verbose_name='تاریخ ایجاد')

    def __str__(self):
        return f"{self.get_action_display()} - {self.ticket.id}"

    class Meta:
        verbose_name = 'لاگ فعالیت تیکت'
        verbose_name_plural = 'لاگ فعالیت‌های تیکت'
        ordering = ['-created_at']


class SavedReply(models.Model):
    title = models.CharField(max_length=100, verbose_name='عنوان')
    content = models.TextField(verbose_name='محتوا')
    category = models.CharField(max_length=50, blank=True, verbose_name='دسته‌بندی')
    is_active = models.BooleanField(default=True, verbose_name='فعال')
    created_by = models.ForeignKey(User, on_delete=models.PROTECT, related_name='saved_replies', verbose_name='ایجاد کننده')
    created_at = models.DateTimeField(auto_now_add=True, verbose_name='تاریخ ایجاد')

    def __str__(self):
        return self.title

    class Meta:
        verbose_name = 'پاسخ ذخیره‌شده'
        verbose_name_plural = 'پاسخ‌های ذخیره‌شده'


class KnowledgeBaseCategory(models.Model):
    name = models.CharField(max_length=100, verbose_name='نام')
    description = models.TextField(blank=True, verbose_name='توضیحات')
    icon = models.CharField(max_length=50, blank=True, verbose_name='آیکون')
    parent = models.ForeignKey('self', on_delete=models.CASCADE, null=True, blank=True, related_name='children', verbose_name='والد')
    is_active = models.BooleanField(default=True, verbose_name='فعال')
    order = models.PositiveIntegerField(default=0, verbose_name='ترتیب')

    def __str__(self):
        return self.name

    class Meta:
        verbose_name = 'دسته‌بندی دانش'
        verbose_name_plural = 'دسته‌بندی دانش'
        ordering = ['order', 'name']


class KnowledgeBaseArticle(models.Model):
    category = models.ForeignKey(KnowledgeBaseCategory, on_delete=models.CASCADE, related_name='articles', verbose_name='دسته‌بندی')
    title = models.CharField(max_length=200, verbose_name='عنوان')
    content = models.TextField(verbose_name='محتوا')
    summary = models.TextField(blank=True, verbose_name='خلاصه')
    tags = models.CharField(max_length=200, blank=True, verbose_name='برچسب‌ها')
    view_count = models.PositiveIntegerField(default=0, verbose_name='تعداد بازدید')
    helpful_count = models.PositiveIntegerField(default=0, verbose_name='تعداد مفید')
    unhelpful_count = models.PositiveIntegerField(default=0, verbose_name='تعداد غیرمفید')
    is_published = models.BooleanField(default=False, verbose_name='منتشر شده')
    created_by = models.ForeignKey(User, on_delete=models.PROTECT, related_name='knowledge_articles', verbose_name='ایجاد کننده')
    created_at = models.DateTimeField(auto_now_add=True, verbose_name='تاریخ ایجاد')
    updated_at = models.DateTimeField(auto_now=True, verbose_name='تاریخ بروزرسانی')

    def __str__(self):
        return self.title

    class Meta:
        verbose_name = 'مقاله دانش'
        verbose_name_plural = 'مقالات دانش'


class Announcement(models.Model):
    AUDIENCE_CHOICES = [
        ('all', 'همه'),
        ('customers', 'مشتریان'),
        ('staff', 'کارکنان'),
        ('admins', 'مدیران'),
    ]
    title = models.CharField(max_length=200, verbose_name='عنوان')
    content = models.TextField(verbose_name='محتوا')
    audience = models.CharField(max_length=20, choices=AUDIENCE_CHOICES, default='all', verbose_name='مخاطب')
    is_active = models.BooleanField(default=True, verbose_name='فعال')
    created_by = models.ForeignKey(User, on_delete=models.PROTECT, related_name='announcements', verbose_name='ایجاد کننده')
    created_at = models.DateTimeField(auto_now_add=True, verbose_name='تاریخ ایجاد')
    expires_at = models.DateTimeField(null=True, blank=True, verbose_name='تاریخ انقضا')

    def __str__(self):
        return self.title

    class Meta:
        verbose_name = 'اعلان'
        verbose_name_plural = 'اعلان‌ها'
        ordering = ['-created_at']


class TicketNotification(models.Model):
    NOTIFICATION_TYPES = [
        ('assigned', 'اختصاص داده شد'),
        ('replied', 'پاسخ داده شد'),
        ('status_changed', 'وضعیت تغییر کرد'),
        ('priority_changed', 'اولویت تغییر کرد'),
        ('mentioned', 'اشاره شد'),
        ('due_date_reminder', 'یادآوری سررسید'),
        ('escalated', 'ارتقا یافت'),
    ]
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='ticket_notifications', verbose_name='کاربر')
    ticket = models.ForeignKey(Ticket, on_delete=models.CASCADE, related_name='notifications', verbose_name='تیکت')
    type = models.CharField(max_length=30, choices=NOTIFICATION_TYPES, verbose_name='نوع')
    message = models.TextField(verbose_name='پیام')
    is_read = models.BooleanField(default=False, verbose_name='خوانده شده')
    created_at = models.DateTimeField(auto_now_add=True, verbose_name='تاریخ ایجاد')

    def __str__(self):
        return f"{self.get_type_display()} - {self.ticket.id}"

    class Meta:
        verbose_name = 'اعلان تیکت'
        verbose_name_plural = 'اعلان‌های تیکت'
        ordering = ['-created_at']


class UserAccountSettings(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE, related_name='ticket_settings', verbose_name='کاربر')
    is_suspended = models.BooleanField(default=False, verbose_name='معلق')
    suspension_reason = models.TextField(blank=True, verbose_name='دلیل تعلیق')
    account_expiry = models.DateTimeField(null=True, blank=True, verbose_name='تاریخ انقضا')
    created_at = models.DateTimeField(auto_now_add=True, verbose_name='تاریخ ایجاد')
    updated_at = models.DateTimeField(auto_now=True, verbose_name='تاریخ بروزرسانی')

    def __str__(self):
        return f"تنظیمات {self.user.username}"

    class Meta:
        verbose_name = 'تنظیمات حساب کاربری'
        verbose_name_plural = 'تنظیمات حساب کاربری'


class Webhook(models.Model):
    EVENT_CHOICES = [
        ('ticket_created', 'تیکت ایجاد شد'),
        ('ticket_updated', 'تیکت به‌روز شد'),
        ('ticket_closed', 'تیکت بسته شد'),
        ('comment_added', 'کامنت اضافه شد'),
    ]
    name = models.CharField(max_length=100, verbose_name='نام')
    url = models.URLField(verbose_name='آدرس')
    events = models.CharField(max_length=200, choices=EVENT_CHOICES, verbose_name='رویداد')
    is_active = models.BooleanField(default=True, verbose_name='فعال')
    secret = models.CharField(max_length=100, blank=True, verbose_name='کلید امنیتی')
    created_at = models.DateTimeField(auto_now_add=True, verbose_name='تاریخ ایجاد')

    def __str__(self):
        return self.name

    class Meta:
        verbose_name = 'وب‌هوک'
        verbose_name_plural = 'وب‌هوک‌ها'


class TicketDuplicate(models.Model):
    ticket = models.ForeignKey(Ticket, on_delete=models.CASCADE, related_name='duplicates', verbose_name='تیکت اصلی')
    duplicate_ticket = models.ForeignKey(Ticket, on_delete=models.CASCADE, related_name='duplicated_by', verbose_name='تیکت تکراری')
    similarity_score = models.FloatField(validators=[MinValueValidator(0), MaxValueValidator(1)], verbose_name='امتیاز شباهت')
    created_at = models.DateTimeField(auto_now_add=True, verbose_name='تاریخ تشخیص')

    class Meta:
        unique_together = ('ticket', 'duplicate_ticket')
        verbose_name = 'تیکت تکراری'
        verbose_name_plural = 'تیکت‌های تکراری'
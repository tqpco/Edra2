# support/routing.py
# -*- coding: utf-8 -*-

from django.urls import re_path
from .consumers import TicketConsumer

websocket_urlpatterns = [
    re_path(r'ws/tickets/$', TicketConsumer.as_asgi()),
]
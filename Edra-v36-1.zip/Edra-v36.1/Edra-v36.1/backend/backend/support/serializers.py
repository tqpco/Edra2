# support/serializers.py
from rest_framework import serializers
from core.models import InspectionRequest
from .models import (
    TicketSystemSettings, TicketCategory, TicketPriority, TicketStatus,
    TicketDepartment, TicketLabel, Ticket, TicketComment, TicketAttachment,
    TicketActivityLog, SavedReply, KnowledgeBaseCategory, KnowledgeBaseArticle,
    Announcement, TicketNotification, UserAccountSettings, SLA, TicketRule,
    Webhook, TicketDuplicate
)
# ✅ استفاده از edra_jalalidate به‌جای jdatetime
from edra_jalalidate import to_jalali as _to_jalali


def to_jalali(dt):
    """
    تبدیل datetime به رشته جلالی با فرمت "%Y/%m/%d - %H:%M"
    اگر ورودی None باشد، None برگردانده می‌شود.
    """
    if not dt:
        return None
    # استفاده از تابع edra_jalalidate با فرمت مورد نظر
    return _to_jalali(dt, fmt="%Y/%m/%d - %H:%M")


class TicketSystemSettingsSerializer(serializers.ModelSerializer):
    class Meta:
        model = TicketSystemSettings
        fields = '__all__'


class TicketCategorySerializer(serializers.ModelSerializer):
    class Meta:
        model = TicketCategory
        fields = '__all__'


class TicketPrioritySerializer(serializers.ModelSerializer):
    class Meta:
        model = TicketPriority
        fields = '__all__'


class TicketStatusSerializer(serializers.ModelSerializer):
    class Meta:
        model = TicketStatus
        fields = '__all__'


class TicketDepartmentSerializer(serializers.ModelSerializer):
    members_count = serializers.IntegerField(source='members.count', read_only=True)

    class Meta:
        model = TicketDepartment
        fields = '__all__'


class TicketLabelSerializer(serializers.ModelSerializer):
    class Meta:
        model = TicketLabel
        fields = '__all__'


class SLASerializer(serializers.ModelSerializer):
    class Meta:
        model = SLA
        fields = '__all__'


class TicketRuleSerializer(serializers.ModelSerializer):
    class Meta:
        model = TicketRule
        fields = '__all__'


class TicketAttachmentSerializer(serializers.ModelSerializer):
    uploaded_at_jalali = serializers.SerializerMethodField()
    file_url = serializers.SerializerMethodField()

    class Meta:
        model = TicketAttachment
        fields = '__all__'
        read_only_fields = ('uploaded_at', 'uploaded_by')

    def get_uploaded_at_jalali(self, obj):
        return to_jalali(obj.uploaded_at)

    def get_file_url(self, obj):
        request = self.context.get('request')
        if obj.file and request:
            return request.build_absolute_uri(obj.file.url)
        return obj.file.url if obj.file else None


class TicketCommentSerializer(serializers.ModelSerializer):
    user_name = serializers.CharField(source='user.get_full_name', read_only=True)
    created_at_jalali = serializers.SerializerMethodField()
    updated_at_jalali = serializers.SerializerMethodField()
    attachments = serializers.SerializerMethodField()

    class Meta:
        model = TicketComment
        fields = (
            'id',
            'ticket',
            'user',
            'user_name',
            'content',
            'is_internal',
            'created_at',
            'created_at_jalali',
            'updated_at',
            'updated_at_jalali',
            'attachments',
        )
        read_only_fields = ('created_at', 'updated_at', 'user')

    def get_created_at_jalali(self, obj):
        return to_jalali(obj.created_at)

    def get_updated_at_jalali(self, obj):
        return to_jalali(obj.updated_at)

    def get_attachments(self, obj):
        """دریافت پیوست‌های این کامنت با context حاوی request"""
        request = self.context.get('request')
        qs = obj.attachments.all().order_by('-uploaded_at')
        return TicketAttachmentSerializer(qs, many=True, context={'request': request}).data


class TicketUpdateSerializer(serializers.ModelSerializer):
    # فیلدهایی که فقط پشتیبانی/ادمین می‌تواند عوض کند.
    STAFF_ONLY_FIELDS = ('status', 'priority', 'sla', 'department',
                         'is_pinned', 'due_date', 'labels', 'category')

    def validate(self, attrs):
        # EDRA v36: مشتریِ مالک تیکت می‌توانست با PATCH وضعیت (بستن/باز کردن)،
        # اولویت، SLA، سنجاق و ... را عوض کند و مسیر state/ممیزی را دور بزند.
        request = self.context.get('request')
        user = getattr(request, 'user', None)
        is_staff_user = bool(
            user and user.is_authenticated
            and (user.is_staff or user.groups.filter(
                name__in=['Support', 'Admin']).exists()))
        if not is_staff_user:
            for field in self.STAFF_ONLY_FIELDS:
                attrs.pop(field, None)
        return attrs

    class Meta:
        model = Ticket
        fields = (
            'id',
            'title',
            'description',
            'category',
            'priority',
            'status',
            'department',
            'sla',
            'labels',
            'due_date',
            'is_confidential',
            'is_pinned',
        )
        extra_kwargs = {
            'title': {'required': False},
            'description': {'required': False},
            'category': {'required': False},
            'priority': {'required': False},
            'status': {'required': False},
            'department': {'required': False},
            'sla': {'required': False},
            'labels': {'required': False},
            'due_date': {'required': False},
            'is_confidential': {'required': False},
            'is_pinned': {'required': False},
        }


class TicketActivityLogSerializer(serializers.ModelSerializer):
    user_name = serializers.CharField(source='user.get_full_name', read_only=True)
    created_at_jalali = serializers.SerializerMethodField()

    class Meta:
        model = TicketActivityLog
        fields = '__all__'
        read_only_fields = ('created_at',)

    def get_created_at_jalali(self, obj):
        return to_jalali(obj.created_at)


class TicketListSerializer(serializers.ModelSerializer):
    customer_name = serializers.CharField(source='customer.get_full_name', read_only=True)
    assigned_to_name = serializers.CharField(source='assigned_to.get_full_name', read_only=True)
    status_name = serializers.CharField(source='status.name', read_only=True)
    priority_name = serializers.CharField(source='priority.name', read_only=True)
    sla_name = serializers.CharField(source='sla.name', read_only=True, default=None)
    first_response_at_jalali = serializers.SerializerMethodField()
    resolved_at_jalali = serializers.SerializerMethodField()
    escalation_level = serializers.IntegerField(read_only=True)
    comments_count = serializers.SerializerMethodField()
    created_at_jalali = serializers.SerializerMethodField()
    updated_at_jalali = serializers.SerializerMethodField()

    class Meta:
        model = Ticket
        fields = (
            'id',
            'title',
            'customer_name',
            'assigned_to_name',
            'status_name',
            'priority_name',
            'sla_name',
            'first_response_at_jalali',
            'resolved_at_jalali',
            'escalation_level',
            'created_at',
            'updated_at',
            'comments_count',
            'is_pinned',
            'created_at_jalali',
            'updated_at_jalali',
        )
        read_only_fields = ('created_at', 'updated_at')

    def get_comments_count(self, obj):
        annotated = getattr(obj, '_comments_count', None)
        return annotated if annotated is not None else obj.comments.count()

    def get_created_at_jalali(self, obj):
        return to_jalali(obj.created_at)

    def get_updated_at_jalali(self, obj):
        return to_jalali(obj.updated_at)

    def get_first_response_at_jalali(self, obj):
        return to_jalali(obj.first_response_at)

    def get_resolved_at_jalali(self, obj):
        return to_jalali(obj.resolved_at)


class TicketCreateSerializer(serializers.ModelSerializer):
    category = serializers.PrimaryKeyRelatedField(
        queryset=TicketCategory.objects.all(), required=False, allow_null=True
    )
    priority = serializers.PrimaryKeyRelatedField(
        queryset=TicketPriority.objects.all(), required=False, allow_null=True
    )
    inspection_request = serializers.PrimaryKeyRelatedField(
        queryset=InspectionRequest.objects.all(), required=False, allow_null=True
    )
    sla = serializers.PrimaryKeyRelatedField(
        queryset=SLA.objects.all(), required=False, allow_null=True
    )

    class Meta:
        model = Ticket
        fields = (
            'id',
            'title',
            'description',
            'category',
            'priority',
            'inspection_request',
            'department',
            'sla',
            'due_date',
            'is_confidential',
            'labels',
        )
        extra_kwargs = {
            'title': {
                'required': True,
                'error_messages': {'required': 'عنوان تیکت الزامی است.'}
            },
            'description': {
                'required': True,
                'error_messages': {'required': 'توضیحات تیکت الزامی است.'}
            },
            'department': {'required': False},
            'sla': {'required': False},
            'due_date': {'required': False},
            'is_confidential': {'required': False},
            'labels': {'required': False},
        }

    def validate(self, attrs):
        # EDRA v36: مشتری می‌توانست sla، due_date و برچسب‌های داخلی تیکت خودش را
        # تعیین کند (مثلاً SLA سریع‌تر برای جلو افتادن در صف). این‌ها فقط برای
        # پشتیبانی/ادمین‌اند.
        request = self.context.get('request')
        user = getattr(request, 'user', None)
        is_staff_user = bool(
            user and user.is_authenticated
            and (user.is_staff or user.groups.filter(
                name__in=['Support', 'Admin']).exists()))
        if not is_staff_user:
            for field in ('sla', 'due_date', 'labels'):
                attrs.pop(field, None)
        return attrs

    def create(self, validated_data):
        request = self.context.get('request')
        if not request or not request.user.is_authenticated:
            raise serializers.ValidationError("کاربر احراز هویت نشده است.")

        if not validated_data.get('category'):
            category = TicketCategory.objects.filter(is_active=True).first()
            if not category:
                category = TicketCategory.objects.create(
                    name='عمومی', description='پیش‌فرض', is_active=True
                )
            validated_data['category'] = category

        if not validated_data.get('priority'):
            priority = TicketPriority.objects.filter(is_active=True).first()
            if not priority:
                priority = TicketPriority.objects.create(
                    name='متوسط', color='#6B7280', weight=1, is_active=True
                )
            validated_data['priority'] = priority

        validated_data['customer'] = request.user

        if not validated_data.get('sla'):
            sla = SLA.objects.filter(priority=validated_data['priority'], is_active=True).first()
            if sla:
                validated_data['sla'] = sla

        return super().create(validated_data)

    def validate_title(self, value):
        if len(value.strip()) < 3:
            raise serializers.ValidationError("عنوان تیکت باید حداقل ۳ کاراکتر باشد.")
        return value.strip()

    def validate_description(self, value):
        if len(value.strip()) < 10:
            raise serializers.ValidationError("توضیحات تیکت باید حداقل ۱۰ کاراکتر باشد.")
        return value.strip()

    def validate_inspection_request(self, value):
        if not value:
            return value
        request = self.context.get('request')
        user = getattr(request, 'user', None)
        if not user or not user.is_authenticated:
            raise serializers.ValidationError("کاربر احراز هویت نشده است.")
        if user.is_staff or user.groups.filter(name__in=['Support', 'Admin']).exists():
            return value
        if value.customer_id != user.id:
            raise serializers.ValidationError("این درخواست متعلق به شما نیست.")
        return value


class TicketDetailSerializer(serializers.ModelSerializer):
    customer_name = serializers.CharField(source='customer.get_full_name', read_only=True)
    assigned_to_name = serializers.CharField(source='assigned_to.get_full_name', read_only=True)
    status_name = serializers.CharField(source='status.name', read_only=True)
    priority_name = serializers.CharField(source='priority.name', read_only=True)
    category_name = serializers.CharField(source='category.name', read_only=True)
    department_name = serializers.CharField(source='department.name', read_only=True)
    sla_name = serializers.CharField(source='sla.name', read_only=True)
    comments = serializers.SerializerMethodField()
    # EDRA v36: این دو فیلد قبلاً بدون فیلتر به مشتری هم می‌رسیدند:
    #  • attachments شامل پیوست‌های «کامنت داخلی» کارکنان هم بود (لینک فایل)؛
    #  • activity_logs (ارجاع/اختصاص/تغییر اولویت و ... با details) کاملاً داخلی است.
    attachments = serializers.SerializerMethodField()
    activity_logs = serializers.SerializerMethodField()
    comments_count = serializers.SerializerMethodField()
    created_at_jalali = serializers.SerializerMethodField()
    updated_at_jalali = serializers.SerializerMethodField()
    closed_at_jalali = serializers.SerializerMethodField()
    due_date_jalali = serializers.SerializerMethodField()
    first_response_at_jalali = serializers.SerializerMethodField()
    resolved_at_jalali = serializers.SerializerMethodField()

    class Meta:
        model = Ticket
        fields = (
            'id',
            'title',
            'description',
            'customer',
            'customer_name',
            'assigned_to',
            'assigned_to_name',
            'status',
            'status_name',
            'priority',
            'priority_name',
            'category',
            'category_name',
            'department',
            'department_name',
            'sla',
            'sla_name',
            'comments',
            'attachments',
            'activity_logs',
            'comments_count',
            'is_pinned',
            'is_confidential',
            'due_date',
            'due_date_jalali',
            'closed_at',
            'closed_at_jalali',
            'first_response_at',
            'first_response_at_jalali',
            'resolved_at',
            'resolved_at_jalali',
            'escalation_level',
            'view_count',
            'created_at',
            'created_at_jalali',
            'updated_at',
            'updated_at_jalali',
        )
        read_only_fields = (
            'created_at',
            'updated_at',
            'closed_at',
            'view_count',
            'first_response_at',
            'resolved_at',
            'escalation_level',
        )

    def get_comments(self, obj):
        request = self.context.get('request')
        user = getattr(request, 'user', None)
        can_see_internal = bool(
            user
            and user.is_authenticated
            and (user.is_staff or user.groups.filter(name__in=['Support', 'Admin']).exists())
        )
        qs = obj.comments.all()
        if not can_see_internal:
            qs = qs.filter(is_internal=False)
        return TicketCommentSerializer(qs, many=True, context={'request': request}).data

    def _can_see_internal(self):
        request = self.context.get('request')
        user = getattr(request, 'user', None)
        return bool(
            user and user.is_authenticated
            and (user.is_staff or user.groups.filter(
                name__in=['Support', 'Admin']).exists()))

    def get_attachments(self, obj):
        request = self.context.get('request')
        qs = obj.attachments.all()
        if not self._can_see_internal():
            qs = [a for a in qs
                  if a.comment_id is None or not a.comment.is_internal]
        return TicketAttachmentSerializer(
            qs, many=True, context={'request': request}).data

    def get_activity_logs(self, obj):
        if not self._can_see_internal():
            return []
        return TicketActivityLogSerializer(
            obj.activity_logs.all(), many=True,
            context=self.context).data

    def get_comments_count(self, obj):
        annotated = getattr(obj, '_comments_count', None)
        return annotated if annotated is not None else obj.comments.count()

    def get_created_at_jalali(self, obj):
        return to_jalali(obj.created_at)

    def get_updated_at_jalali(self, obj):
        return to_jalali(obj.updated_at)

    def get_closed_at_jalali(self, obj):
        return to_jalali(obj.closed_at)

    def get_due_date_jalali(self, obj):
        return to_jalali(obj.due_date)

    def get_first_response_at_jalali(self, obj):
        return to_jalali(obj.first_response_at)

    def get_resolved_at_jalali(self, obj):
        return to_jalali(obj.resolved_at)


class SavedReplySerializer(serializers.ModelSerializer):
    class Meta:
        model = SavedReply
        fields = '__all__'
        read_only_fields = ('created_at', 'created_by')


class KnowledgeBaseCategorySerializer(serializers.ModelSerializer):
    class Meta:
        model = KnowledgeBaseCategory
        fields = '__all__'


class KnowledgeBaseArticleSerializer(serializers.ModelSerializer):
    category_name = serializers.CharField(source='category.name', read_only=True)

    class Meta:
        model = KnowledgeBaseArticle
        fields = '__all__'
        read_only_fields = (
            'created_at',
            'updated_at',
            'created_by',
            'view_count',
            'helpful_count',
            'unhelpful_count',
        )


class AnnouncementSerializer(serializers.ModelSerializer):
    created_by_name = serializers.CharField(source='created_by.get_full_name', read_only=True)
    created_at_jalali = serializers.SerializerMethodField()
    expires_at_jalali = serializers.SerializerMethodField()

    class Meta:
        model = Announcement
        fields = '__all__'
        read_only_fields = ('created_at', 'created_by')

    def get_created_at_jalali(self, obj):
        return to_jalali(obj.created_at)

    def get_expires_at_jalali(self, obj):
        return to_jalali(obj.expires_at)


class TicketNotificationSerializer(serializers.ModelSerializer):
    created_at_jalali = serializers.SerializerMethodField()

    class Meta:
        model = TicketNotification
        fields = '__all__'
        read_only_fields = ('created_at',)

    def get_created_at_jalali(self, obj):
        return to_jalali(obj.created_at)


class UserAccountSettingsSerializer(serializers.ModelSerializer):
    created_at_jalali = serializers.SerializerMethodField()
    updated_at_jalali = serializers.SerializerMethodField()

    class Meta:
        model = UserAccountSettings
        fields = '__all__'
        read_only_fields = ('created_at', 'updated_at')

    def get_created_at_jalali(self, obj):
        return to_jalali(obj.created_at)

    def get_updated_at_jalali(self, obj):
        return to_jalali(obj.updated_at)


class WebhookSerializer(serializers.ModelSerializer):
    class Meta:
        model = Webhook
        fields = '__all__'


class TicketDuplicateSerializer(serializers.ModelSerializer):
    class Meta:
        model = TicketDuplicate
        fields = '__all__'
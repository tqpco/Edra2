# support/signals.py
from django.db.models.signals import post_save, pre_save
from django.dispatch import receiver
from django.utils import timezone
from django.contrib.auth import get_user_model
import logging
from .models import Ticket, TicketComment

User = get_user_model()
logger = logging.getLogger(__name__)

@receiver(post_save, sender=Ticket)
def ticket_created_or_updated(sender, instance, created, **kwargs):
    if created:
        logger.info(f"New ticket created: #{instance.id} - {instance.title}")
    else:
        logger.info(f"Ticket #{instance.id} updated: status={instance.status}, priority={instance.priority}")

@receiver(post_save, sender=TicketComment)
def ticket_comment_created(sender, instance, created, **kwargs):
    if created:
        logger.info(f"New comment on ticket #{instance.ticket.id} by {instance.user.username}")
        # اگر کامنت از پشتیبانی است و داخلی نیست و تیکت هنوز پاسخ اولیه ندارد
        if instance.user.is_staff or instance.user.groups.filter(name__in=['Support', 'Admin']).exists():
            if not instance.is_internal and not instance.ticket.first_response_at:
                instance.ticket.first_response_at = timezone.now()
                instance.ticket.save(update_fields=['first_response_at'])

@receiver(pre_save, sender=Ticket)
def set_closed_at_on_status_change(sender, instance, **kwargs):
    if instance.pk:
        old = Ticket.objects.get(pk=instance.pk)
        if old.status != instance.status and instance.status and instance.status.is_closed:
            if not instance.closed_at:
                instance.closed_at = timezone.now()
                instance.resolved_at = timezone.now()
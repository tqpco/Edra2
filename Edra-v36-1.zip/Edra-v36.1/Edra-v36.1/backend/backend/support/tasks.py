# support/tasks.py
from celery import shared_task
import logging
from django.core.mail import send_mail
from django.conf import settings
from django.utils import timezone
from django.db.models import Q, Max
from django.contrib.auth import get_user_model  # ✅ import صحیح
from .models import (
    Ticket, TicketNotification, TicketComment, TicketStatus,
    UserAccountSettings, TicketActivityLog
)

User = get_user_model()  # ✅ تعریف User
logger = logging.getLogger(__name__)


@shared_task
def send_ticket_assignment_notification(ticket_id, assigned_to_id, assigned_by_id):
    try:
        ticket = Ticket.objects.get(id=ticket_id)
        assigned_to = User.objects.get(id=assigned_to_id)
        assigned_by = User.objects.get(id=assigned_by_id)

        subject = f"تیکت #{ticket.id} به شما اختصاص داده شد"
        message = f"""
سلام {assigned_to.get_full_name() or assigned_to.username}

تیکت "{ticket.title}" توسط {assigned_by.get_full_name() or assigned_by.username} به شما اختصاص داده شد.

لطفاً برای مشاهده تیکت به سامانه مراجعه کنید.
"""
        send_mail(subject, message, settings.DEFAULT_FROM_EMAIL, [assigned_to.email], fail_silently=True)

        TicketNotification.objects.create(
            user=assigned_to,
            ticket=ticket,
            type='assigned',
            message=f'تیکت #{ticket.id} به شما اختصاص داده شد.'
        )
        logger.info(f"Ticket assignment notification sent for ticket {ticket.id}")
        return True
    except Exception as e:
        logger.error(f"Error sending assignment notification: {e}")
        return False


@shared_task
def auto_close_inactive_tickets():
    """
    بستن خودکار تیکت‌هایی که ۷۲ ساعت از آخرین پاسخ پشتیبانی گذشته باشد.
    """
    closed_status = TicketStatus.objects.filter(is_closed=True).order_by('id').first()
    if not closed_status:
        logger.warning("No closed status found, auto_close skipped.")
        return 0

    cutoff = timezone.now() - timezone.timedelta(hours=72)
    # EDRA v36: همه‌ی وضعیت‌های «بسته» کنار گذاشته می‌شوند (نه فقط اولین)؛ قبلاً
    # تیکتِ بسته با وضعیت بسته‌ی دیگر دوباره «بسته» و کامنت داخلی تکراری می‌خورد.
    tickets = Ticket.objects.filter(
        closed_at__isnull=True
    ).exclude(status__is_closed=True).annotate(
        last_comment_at=Max('comments__created_at')
    )

    closed_count = 0
    for ticket in tickets:
        last_activity = ticket.last_comment_at or ticket.created_at
        if last_activity > cutoff:
            continue

        last_comment = ticket.comments.order_by('-created_at').first()
        if last_comment is None or last_comment.user_id == ticket.customer_id:
            continue

        # بستن تیکت
        ticket.status = closed_status
        ticket.closed_at = timezone.now()
        ticket.resolved_at = timezone.now()
        ticket.save(update_fields=['status', 'closed_at', 'resolved_at'])

        # ثبت کامنت داخلی
        TicketComment.objects.create(
            ticket=ticket,
            user=ticket.assigned_to or last_comment.user,
            content='این تیکت به دلیل عدم پاسخ طی ۷۲ ساعت به‌صورت خودکار بسته شد.',
            is_internal=True,
        )

        TicketActivityLog.objects.create(
            ticket=ticket,
            user=ticket.assigned_to or last_comment.user,
            action='auto_close',
            details={'reason': 'inactivity'}
        )
        closed_count += 1

    logger.info(f"Auto-closed {closed_count} inactive tickets.")
    return closed_count


@shared_task
def send_due_date_reminders():
    """
    ارسال یادآوری برای تیکت‌هایی که سررسید آن‌ها تا ۲۴ ساعت آینده است.
    """
    now = timezone.now()
    threshold = now + timezone.timedelta(hours=24)
    tickets = Ticket.objects.filter(
        due_date__isnull=False,
        due_date__gte=now,
        due_date__lte=threshold,
        status__is_closed=False
    )

    count = 0
    for ticket in tickets:
        users = set(User.objects.filter(is_staff=True))  # ✅ User معتبر است
        if ticket.assigned_to:
            users.add(ticket.assigned_to)
        for user in users:
            if user:
                TicketNotification.objects.create(
                    user=user,
                    ticket=ticket,
                    type='due_date_reminder',
                    message=f'سررسید تیکت #{ticket.id} در ۲۴ ساعت آینده است.'
                )
        count += 1

    logger.info(f"Sent due date reminders for {count} tickets.")
    return count


@shared_task
def deactivate_expired_accounts():
    """
    غیرفعال‌سازی خودکار حساب‌های منقضی شده.
    """
    expired = UserAccountSettings.objects.filter(
        account_expiry__lte=timezone.now(),
        is_suspended=False
    )
    count = expired.update(is_suspended=True, suspension_reason='انقضای حساب')
    logger.info(f"Deactivated {count} expired accounts.")
    return count


@shared_task
def check_sla_escalation():
    """
    ارتقا (Escalation) تیکت‌هایی که از زمان پاسخ یا حل آن‌ها گذشته است.
    EDRA v27/v31 — رفع باگ خاموش بحرانی: F() نمی‌تواند به timedelta()
    پاس شود (TypeError واقعی) — این تسک هرگز کار نمی‌کرد.
    """
    from datetime import timedelta as _td
    now = timezone.now()
    candidates = Ticket.objects.filter(
        sla__isnull=False,
        status__is_closed=False,
        first_response_at__isnull=True,
    ).select_related('sla')

    escalated_count = 0
    for ticket in candidates:
        if not ticket.sla or not ticket.sla.response_time_hours:
            continue
        sla_delta = _td(hours=ticket.sla.response_time_hours)
        if now < ticket.created_at + sla_delta:
            continue
        # EDRA v36: این تسک هر ۳۰ دقیقه اجرا می‌شود و قبلاً هر اجرا سطح را +۱ و
        # برای همه‌ی ادمین‌ها اعلان می‌ساخت (۴۸ ارتقا و هزاران اعلان در روز برای
        # یک تیکت بی‌پاسخ). سطح از «تعداد دوره‌های SLA سپری‌شده» محاسبه می‌شود
        # (حداکثر ۳) و فقط وقتی بالاتر از سطح فعلی باشد ارتقا و اعلان داده می‌شود.
        periods = int((now - ticket.created_at) / sla_delta)
        target_level = min(max(periods, 1), 3)
        if target_level <= ticket.escalation_level:
            continue
        ticket.escalation_level = target_level
        admins = User.objects.filter(is_staff=True)  # ✅ User معتبر است
        for admin in admins:
            TicketNotification.objects.create(
                user=admin,
                ticket=ticket,
                type='escalated',
                message=f'تیکت #{ticket.id} به دلیل عدم پاسخ در زمان SLA ارتقا یافت (سطح {ticket.escalation_level}).'
            )
        ticket.save(update_fields=['escalation_level'])
        escalated_count += 1

    logger.info(f"Escalated {escalated_count} tickets due to SLA response time.")
    return escalated_count

@shared_task(bind=True, max_retries=2, default_retry_delay=10)
def dispatch_ticket_webhook_task(self, ticket_id, event):
    """EDRA v27/v31 — وب‌هوک تیکت async شد (قبلاً synchronous بود، تا ۵ ثانیه در درخواست HTTP)."""
    import requests
    from .models import Ticket, Webhook
    from .serializers import TicketDetailSerializer
    try:
        ticket = Ticket.objects.get(id=ticket_id)
    except Ticket.DoesNotExist:
        return
    webhooks = Webhook.objects.filter(events__contains=event, is_active=True)
    payload = {'ticket_id': ticket.id, 'event': event, 'data': TicketDetailSerializer(ticket).data}
    for wh in webhooks:
        headers = {'X-Webhook-Secret': wh.secret} if wh.secret else {}
        try:
            requests.post(wh.url, json=payload, headers=headers, timeout=5)
        except Exception as e:
            logger.error(f"Webhook {wh.id} failed: {e}")

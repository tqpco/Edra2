# support/tests.py
import pytest
from django.contrib.auth import get_user_model
from rest_framework.test import APIClient
from django.utils import timezone
from core.models import EquipmentType, InspectionRequest
from support.models import (
    Ticket, TicketStatus, TicketPriority, TicketCategory,
    TicketDepartment, TicketComment, TicketActivityLog,
    SLA, TicketRule, TicketDuplicate
)

User = get_user_model()
pytestmark = pytest.mark.django_db


# ---------- Fixtures ----------
@pytest.fixture
def user_customer():
    return User.objects.create_user(username='customer', password='pass123')


@pytest.fixture
def user_support():
    from django.contrib.auth.models import Group
    g, _ = Group.objects.get_or_create(name='Support')
    u = User.objects.create_user(username='support', password='pass123')
    u.groups.add(g)
    return u


@pytest.fixture
def user_admin():
    return User.objects.create_superuser(username='admin', password='pass123')


@pytest.fixture
def basic_ticket(user_customer):
    status = TicketStatus.objects.create(name='باز', color='green', is_closed=False)
    priority = TicketPriority.objects.create(name='متوسط', weight=1)
    category = TicketCategory.objects.create(name='عمومی')
    return Ticket.objects.create(
        title='تیکت تست',
        description='توضیحات تست',
        customer=user_customer,
        status=status,
        priority=priority,
        category=category
    )


# ---------- تست‌های دسترسی ----------
def test_customer_can_create_ticket(user_customer, client):
    client.force_authenticate(user=user_customer)
    resp = client.post('/api/support/tickets/', {'title': 'تیکت جدید', 'description': 'توضیحات'})
    assert resp.status_code == 201
    assert Ticket.objects.count() == 1


def test_customer_can_only_see_own_tickets(user_customer, client, basic_ticket):
    client.force_authenticate(user=user_customer)
    resp = client.get('/api/support/tickets/')
    assert len(resp.data['results']) == 1


def test_support_can_see_all_tickets(user_support, client, basic_ticket):
    client.force_authenticate(user=user_support)
    resp = client.get('/api/support/tickets/')
    assert len(resp.data['results']) == 1


def test_customer_cannot_see_internal_comments(user_customer, client, basic_ticket):
    TicketComment.objects.create(ticket=basic_ticket, user=user_customer, content='داخلی', is_internal=True)
    client.force_authenticate(user=user_customer)
    resp = client.get(f'/api/support/tickets/{basic_ticket.id}/')
    assert len(resp.data['comments']) == 0


def test_support_can_see_internal_comments(user_support, client, basic_ticket):
    TicketComment.objects.create(ticket=basic_ticket, user=user_support, content='داخلی', is_internal=True)
    client.force_authenticate(user=user_support)
    resp = client.get(f'/api/support/tickets/{basic_ticket.id}/')
    assert len(resp.data['comments']) == 1


# ---------- تست‌های مالکیت و امنیت ----------
def test_customer_cannot_change_status(user_customer, client, basic_ticket):
    client.force_authenticate(user=user_customer)
    resp = client.post(f'/api/support/tickets/{basic_ticket.id}/change_status/', {'status_id': 1})
    assert resp.status_code == 403


def test_support_can_change_status(user_support, client, basic_ticket):
    client.force_authenticate(user=user_support)
    status = TicketStatus.objects.create(name='در حال بررسی', color='blue', is_closed=False)
    resp = client.post(f'/api/support/tickets/{basic_ticket.id}/change_status/', {'status_id': status.id})
    assert resp.status_code == 200
    basic_ticket.refresh_from_db()
    assert basic_ticket.status == status


def test_customer_cannot_add_internal_comment(user_customer, client, basic_ticket):
    client.force_authenticate(user=user_customer)
    resp = client.post(f'/api/support/tickets/{basic_ticket.id}/add_comment/', {
        'content': 'داخلی',
        'is_internal': True
    })
    assert resp.status_code == 403


def test_support_can_add_internal_comment(user_support, client, basic_ticket):
    client.force_authenticate(user=user_support)
    resp = client.post(f'/api/support/tickets/{basic_ticket.id}/add_comment/', {
        'content': 'داخلی',
        'is_internal': True
    })
    assert resp.status_code == 201
    assert TicketComment.objects.filter(is_internal=True).exists()


# ---------- تست‌های قوانین اتوماتیک ----------
def test_auto_rule_assign_department(user_customer, client):
    dept = TicketDepartment.objects.create(name='فنی')
    rule = TicketRule.objects.create(
        name='تخصیص به فنی',
        condition_type='keyword',
        condition_value='فنی',
        action_type='assign_department',
        action_value='فنی',
        is_active=True
    )
    client.force_authenticate(user=user_customer)
    resp = client.post('/api/support/tickets/', {'title': 'مشکل فنی', 'description': 'توضیحات'})
    assert resp.status_code == 201
    ticket = Ticket.objects.last()
    assert ticket.department == dept


# ---------- تست‌های SLA ----------
def test_sla_assigned_on_create(user_customer, client):
    priority = TicketPriority.objects.create(name='بالا', weight=10)
    sla = SLA.objects.create(name='SLA بالا', priority=priority, response_time_hours=2, resolution_time_hours=24)
    client.force_authenticate(user=user_customer)
    resp = client.post('/api/support/tickets/', {
        'title': 'مهم',
        'description': 'توضیحات',
        'priority': priority.id
    })
    assert resp.status_code == 201
    ticket = Ticket.objects.last()
    assert ticket.sla == sla


# ---------- تست‌های بسته‌سازی خودکار ----------
def test_auto_close_inactive(user_customer, user_support):
    ticket = Ticket.objects.create(title='بسته شود', description='...', customer=user_customer)
    TicketComment.objects.create(ticket=ticket, user=user_support, content='پاسخ پشتیبانی', is_internal=False)
    ticket.created_at = timezone.now() - timezone.timedelta(hours=73)
    ticket.save()
    from support.tasks import auto_close_inactive_tickets
    result = auto_close_inactive_tickets()
    assert result == 1
    ticket.refresh_from_db()
    assert ticket.status.is_closed is True


# ---------- تست‌های وب‌هوک ----------
def test_webhook_trigger(user_customer, client, mocker):
    from support.models import Webhook
    wh = Webhook.objects.create(
        name='test',
        url='https://httpbin.org/post',
        events='ticket_created',
        is_active=True
    )
    mock_post = mocker.patch('requests.post')
    client.force_authenticate(user=user_customer)
    client.post('/api/support/tickets/', {'title': 'با وب‌هوک', 'description': 'تست'})
    assert mock_post.called
    assert mock_post.call_args[0][0] == wh.url


# ---------- تست‌های گزارش ----------
def test_statistics_endpoint(user_support, client, basic_ticket):
    client.force_authenticate(user=user_support)
    resp = client.get('/api/support/tickets/statistics/')
    assert resp.status_code == 200
    assert resp.data['total'] >= 1
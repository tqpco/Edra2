# support/urls.py
from django.urls import path, include
from rest_framework.routers import DefaultRouter
from .views import (
    TicketViewSet,
    TicketCategoryViewSet,
    TicketPriorityViewSet,
    TicketStatusViewSet,
    TicketDepartmentViewSet,
    TicketLabelViewSet,
    SavedReplyViewSet,
    KnowledgeBaseCategoryViewSet,
    KnowledgeBaseArticleViewSet,
    AnnouncementViewSet,
    TicketNotificationViewSet,
    TicketActivityLogViewSet,
    UserAccountSettingsViewSet,
    TicketSystemSettingsView,
    # EDRA v27 — رفع باگ ریشه‌ای (گزارش کاربر، سپتامبر ۲۰۲۶): این سه
    # ViewSet در support/views.py کامل پیاده‌سازی شده بودند (queryset،
    # serializer، permission) ولی هرگز اینجا import/register نشده بودند.
    # نتیجه: صفحات تنظیمات تیکت (SLA، قوانین/rules، وب‌هوک) در ادمین
    # همیشه ۴۰۴ می‌گرفتند — این دقیقاً همان چیزی است که «سیستم تیکت به
    # شکل واقعی کار نمی‌کند» حس می‌شد.
    SLAViewSet,
    TicketRuleViewSet,
    WebhookViewSet,
)

app_name = "support"

router = DefaultRouter()
router.register(r'tickets', TicketViewSet, basename='tickets')
router.register(
    r'categories',
    TicketCategoryViewSet,
    basename='ticket_categories')
router.register(
    r'priorities',
    TicketPriorityViewSet,
    basename='ticket_priorities')
router.register(r'statuses', TicketStatusViewSet, basename='ticket_statuses')
router.register(
    r'departments',
    TicketDepartmentViewSet,
    basename='ticket_departments')
router.register(r'labels', TicketLabelViewSet, basename='ticket_labels')
router.register(r'saved-replies', SavedReplyViewSet, basename='saved_replies')
router.register(
    r'knowledge-categories',
    KnowledgeBaseCategoryViewSet,
    basename='knowledge_categories')
router.register(
    r'knowledge-articles',
    KnowledgeBaseArticleViewSet,
    basename='knowledge_articles')
router.register(
    r'announcements',
    AnnouncementViewSet,
    basename='announcements')
router.register(
    r'notifications',
    TicketNotificationViewSet,
    basename='ticket_notifications')
router.register(
    r'activity-logs',
    TicketActivityLogViewSet,
    basename='ticket_activity_logs')
router.register(
    r'user-settings',
    UserAccountSettingsViewSet,
    basename='user_settings')
router.register(r'slas', SLAViewSet, basename='ticket_slas')
router.register(r'rules', TicketRuleViewSet, basename='ticket_rules')
router.register(r'webhooks', WebhookViewSet, basename='ticket_webhooks')

urlpatterns = [
    path('', include(router.urls)),
    # تنظیمات سیستم (یک View عمومی، نه ViewSet)
    path(
        'settings/',
        TicketSystemSettingsView.as_view(),
        name='ticket_settings'),
]

# support/views.py
# -*- coding: utf-8 -*-

from rest_framework import viewsets, generics, status
from rest_framework.decorators import action
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated, AllowAny
from core.permissions import (
    IsAdminUserOrGroup, IsAdminOrReadOnly,
    IsAdminOrSupportOrReadOnly, IsAdminOrAuthenticatedReadOnly
)
from rest_framework.filters import SearchFilter, OrderingFilter
from django.db.models import Q, Count, Avg, F, Max
from django.db.models.functions import ExtractHour
from django.utils import timezone
from django.core.mail import send_mail
from django.conf import settings
from django.contrib.auth import get_user_model
from core.state_machine import get_ticket_state_machine, StateMachineError
from core.events import Event, EventRegistry
from notifications.services import send_notification as notify_user

from .models import (
    Announcement, KnowledgeBaseArticle, KnowledgeBaseCategory, SavedReply,
    Ticket, TicketActivityLog, TicketAttachment, TicketCategory, TicketComment,
    TicketDepartment, TicketLabel, TicketNotification, TicketPriority,
    TicketStatus, TicketSystemSettings, UserAccountSettings,
    SLA, TicketRule, Webhook, TicketDuplicate
)
from .serializers import (
    AnnouncementSerializer, KnowledgeBaseArticleSerializer,
    KnowledgeBaseCategorySerializer, SavedReplySerializer,
    TicketActivityLogSerializer, TicketAttachmentSerializer,
    TicketCategorySerializer, TicketCommentSerializer,
    TicketCreateSerializer, TicketDepartmentSerializer,
    TicketDetailSerializer, TicketLabelSerializer,
    TicketListSerializer, TicketNotificationSerializer,
    TicketPrioritySerializer, TicketStatusSerializer,
    TicketSystemSettingsSerializer, TicketUpdateSerializer,
    UserAccountSettingsSerializer, SLASerializer, TicketRuleSerializer,
    WebhookSerializer, TicketDuplicateSerializer
)
import requests
import logging

User = get_user_model()
logger = logging.getLogger(__name__)

try:
    from django_filters.rest_framework import DjangoFilterBackend
    HAS_FILTER = True
except ImportError:
    HAS_FILTER = False
    class DjangoFilterBackend:
        pass


# ============================================================
# توابع کمکی
# ============================================================

def is_support_or_admin(user):
    from core.permissions import is_support_or_admin as _impl
    return _impl(user)


def send_notification(ticket, type, message, users=None):
    if users is None:
        users = User.objects.filter(is_staff=True)
    for user in users:
        TicketNotification.objects.create(
            user=user, ticket=ticket, type=type, message=message
        )
    try:
        send_mail(
            f'نوتیفیکیشن تیکت #{ticket.id}',
            message,
            settings.DEFAULT_FROM_EMAIL,
            [u.email for u in users if u.email],
            fail_silently=True
        )
    except Exception as e:
        logger.error(f"Error sending email notification: {e}")


def log_activity(ticket, user, action, details=None):
    TicketActivityLog.objects.create(
        ticket=ticket, user=user, action=action, details=details or {}
    )


def trigger_webhook(ticket, event, request=None):
    # EDRA v27/v31: async (نگاه کنید به tasks.dispatch_ticket_webhook_task)
    # EDRA v36: قطعی broker (Redis) نباید ساخت/پاسخ/تغییر وضعیت تیکت را با ۵۰۰
    # بشکند (کار اصلی قبلاً commit شده)؛ فقط webhook از دست می‌رود.
    try:
        from .tasks import dispatch_ticket_webhook_task
        dispatch_ticket_webhook_task.delay(ticket.id, event)
    except Exception as webhook_error:
        logger.error(f"Webhook dispatch failed (ticket {ticket.id}, {event}): "
                     f"{webhook_error}")


def apply_rules(ticket):
    """اعمال قوانین فعال بر روی تیکت"""
    rules = TicketRule.objects.filter(is_active=True).order_by('order')
    for rule in rules:
        match = False
        if rule.condition_type == 'category' and ticket.category:
            if ticket.category.name == rule.condition_value:
                match = True
        elif rule.condition_type == 'priority' and ticket.priority:
            if ticket.priority.name == rule.condition_value:
                match = True
        elif rule.condition_type == 'status' and ticket.status:
            if ticket.status.name == rule.condition_value:
                match = True
        elif rule.condition_type == 'department' and ticket.department:
            if ticket.department.name == rule.condition_value:
                match = True
        elif rule.condition_type == 'keyword':
            if (rule.condition_value.lower() in ticket.title.lower() or
                rule.condition_value.lower() in ticket.description.lower()):
                match = True
        if match:
            apply_rule_action(ticket, rule)


def apply_rule_action(ticket, rule):
    if rule.action_type == 'assign_user':
        try:
            user = User.objects.get(username=rule.action_value)
            ticket.assigned_to = user
            ticket.save()
        except User.DoesNotExist:
            pass
    elif rule.action_type == 'assign_department':
        try:
            dept = TicketDepartment.objects.get(name=rule.action_value)
            ticket.department = dept
            ticket.save()
        except TicketDepartment.DoesNotExist:
            pass
    elif rule.action_type == 'set_priority':
        try:
            priority = TicketPriority.objects.get(name=rule.action_value)
            ticket.priority = priority
            ticket.save()
        except TicketPriority.DoesNotExist:
            pass
    elif rule.action_type == 'set_status':
        try:
            status = TicketStatus.objects.get(name=rule.action_value)
            ticket.status = status
            ticket.save()
        except TicketStatus.DoesNotExist:
            pass
    elif rule.action_type == 'add_label':
        try:
            label = TicketLabel.objects.get(name=rule.action_value)
            ticket.labels.add(label)
        except TicketLabel.DoesNotExist:
            pass


# ============================================================
# ViewSet اصلی تیکت با StateMachine و رویدادها
# ============================================================

class TicketViewSet(viewsets.ModelViewSet):
    permission_classes = [IsAuthenticated]

    def get_permissions(self):
        # EDRA v36: حذف تیکت (و سوابق پشتیبانی/پیوست‌ها) قبلاً برای هر مشتریِ
        # مالک باز بود؛ فقط ادمین.
        if self.action == 'destroy':
            return [IsAdminUserOrGroup()]
        return super().get_permissions()

    filter_backends = [SearchFilter, OrderingFilter]
    if HAS_FILTER:
        filter_backends.insert(0, DjangoFilterBackend)
        filterset_fields = [
            'status', 'priority', 'category', 'department',
            'assigned_to', 'customer', 'is_pinned'
        ]
    search_fields = ['title', 'description', 'customer__username', 'customer__email']
    ordering_fields = ['created_at', 'due_date', 'priority__weight', 'is_pinned']

    def get_serializer_class(self):
        if self.action == 'create':
            return TicketCreateSerializer
        if self.action == 'retrieve':
            return TicketDetailSerializer
        if self.action in ('update', 'partial_update'):
            return TicketUpdateSerializer
        return TicketListSerializer

    def get_queryset(self):
        user = self.request.user
        qs = Ticket.objects.prefetch_related('labels')
        if self.action == 'list':
            # EDRA v32: رفع N+1 — سریالایزر لیست برای هر ردیف customer/assigned_to/
            # status/priority/sla را لمس می‌کند و comments_count را جدا می‌شمرد
            # (≈۶ کوئری × ۲۵ ردیف در هر صفحه).
            qs = qs.select_related(
                'customer', 'assigned_to', 'status', 'priority', 'sla'
            ).annotate(_comments_count=Count('comments', distinct=True))
        if self.action == 'retrieve':
            qs = qs.prefetch_related(
                'comments', 'attachments', 'comments__user', 'comments__attachments'
            )
        if is_support_or_admin(user):
            return qs
        return qs.filter(customer=user)

    def perform_create(self, serializer):
        # EDRA v36: اعتبارسنجی پیوست‌ها «قبل از» ساخت تیکت. قبلاً تیکت ساخته می‌شد
        # و بعد با پیوست نامعتبر ۴۰۰ برمی‌گشت؛ تیکت در دیتابیس می‌ماند و تلاش
        # مجدد کاربر تیکت تکراری می‌ساخت.
        from rest_framework.exceptions import ValidationError as _VE
        from core.validators import (
            validate_uploaded_file as _vuf, ALLOWED_IMAGE_EXTENSIONS as _AIE)
        _files = self.request.FILES.getlist('attachments')
        if len(_files) > 10:
            raise _VE({'attachments': 'حداکثر ۱۰ فایل پیوست مجاز است.'})
        for _f in _files:
            _err = _vuf(
                _f,
                allowed_extensions=_AIE | {
                    '.pdf', '.zip', '.doc', '.docx', '.xls', '.xlsx'},
                max_size=10 * 1024 * 1024)
            if _err:
                raise _VE({'attachments': f'پیوست {_f.name}: {_err}'})

        ticket = serializer.save(customer=self.request.user)

        # EDRA v32 — باگ واقعی (از‌دست‌رفتن داده): صفحه‌ی «تیکت جدید» فایل‌های
        # پیوست را در همان FormData ساخت تیکت می‌فرستد (کلید attachments،
        # دقیقاً مثل add_comment)، ولی اینجا هرگز request.FILES خوانده
        # نمی‌شد — فایل‌هایی که کاربر با دقت انتخاب و آپلود می‌کرد، بی‌صدا
        # گم می‌شدند؛ نه خطایی، نه اثری در تیکت. همان اعتبارسنجی add_comment
        # (نوع/حجم/تعداد فایل) اینجا هم تکرار شد.
        from rest_framework.exceptions import ValidationError
        from core.validators import validate_uploaded_file, ALLOWED_IMAGE_EXTENSIONS
        files = self.request.FILES.getlist('attachments')
        if files:
            if len(files) > 10:
                raise ValidationError(
                    {'attachments': 'حداکثر ۱۰ فایل پیوست مجاز است.'})
            for file in files:
                error = validate_uploaded_file(
                    file,
                    allowed_extensions=ALLOWED_IMAGE_EXTENSIONS | {
                        '.pdf', '.zip', '.doc', '.docx', '.xls', '.xlsx'},
                    max_size=10 * 1024 * 1024
                )
                if error:
                    raise ValidationError(
                        {'attachments': f'پیوست {file.name}: {error}'})
            for file in files:
                TicketAttachment.objects.create(
                    ticket=ticket,
                    comment=None,
                    file=file,
                    filename=file.name,
                    file_size=file.size,
                    uploaded_by=self.request.user,
                )

        default_status = TicketStatus.objects.filter(is_active=True).first()
        if default_status:
            ticket.status = default_status
            ticket.save()

        apply_rules(ticket)

        log_activity(ticket, self.request.user, 'create', {'title': ticket.title})

        send_notification(ticket, 'ticket_created', f'تیکت جدید توسط {self.request.user.username} ایجاد شد.')

        trigger_webhook(ticket, 'ticket_created', self.request)

        # ارسال رویداد
        EventRegistry.dispatch(Event('ticket_created', {'instance': ticket, 'actor': self.request.user}))

    # ---------- اکشن‌های موجود ----------

    @action(detail=True, methods=['post'])
    def assign(self, request, pk=None):
        ticket = self.get_object()
        user_id = request.data.get('user_id')
        if not user_id:
            return Response({'error': 'شناسه کاربر الزامی است.'}, status=400)
        try:
            user = User.objects.get(id=user_id)
        except User.DoesNotExist:
            return Response({'error': 'کاربر یافت نشد.'}, status=404)
        if not is_support_or_admin(request.user):
            return Response({'error': 'شما مجاز به اختصاص تیکت نیستید.'}, status=403)
        ticket.assigned_to = user
        ticket.save()
        log_activity(ticket, request.user, 'assign', {'assigned_to': user.username})
        send_notification(ticket, 'ticket_assigned', f'تیکت #{ticket.id} به {user.username} اختصاص یافت.')
        if user.id != request.user.id:
            notify_user(user, 'ticket_assigned', {
                'ticket_id': ticket.id, 'title': ticket.title,
                'assigned_by': request.user.get_full_name() or request.user.username})
        return Response({'message': f'تیکت به {user.username} اختصاص یافت.'})

    @action(detail=True, methods=['post'])
    def change_status(self, request, pk=None):
        if not is_support_or_admin(request.user):
            return Response({'error': 'شما مجاز به تغییر وضعیت نیستید.'}, status=403)
        ticket = self.get_object()
        status_id = request.data.get('status_id')
        if not status_id:
            return Response({'error': 'شناسه وضعیت الزامی است.'}, status=400)
        try:
            status = TicketStatus.objects.get(id=status_id)
        except TicketStatus.DoesNotExist:
            return Response({'error': 'وضعیت یافت نشد.'}, status=404)

        # EDRA v33 — رفع باگ: این view قبلاً از state machine با «نام فارسی
        # وضعیت» (مثلاً 'باز') استفاده می‌کرد؛ ماشین حالت transition هایش را
        # با نام‌های انگلیسی (open/in_progress/…) تعریف کرده و obj.status هم
        # یک FK است نه رشته → *هر* تغییر وضعیت تیکت با خطای ۴۰۰ رد می‌شد (و هیچ
        # اعلان تغییر وضعیتی ممکن نبود). وضعیت‌ها داده‌ی قابل‌ویرایش ادمین‌اند،
        # پس مستقیماً FK ست می‌شود و فیلدهای بسته‌شدن به‌روز می‌شوند.
        old_status = ticket.status
        ticket.status = status
        if status.is_closed:
            ticket.closed_at = timezone.now()
            ticket.resolved_at = ticket.resolved_at or timezone.now()
        else:
            ticket.closed_at = None
        ticket.save()

        log_activity(ticket, request.user, 'change_status', {
            'old_status': old_status.name if old_status else None,
            'new_status': status.name
        })
        send_notification(ticket, 'status_changed', f'وضعیت تیکت #{ticket.id} به {status.name} تغییر یافت.')
        if ticket.customer_id != request.user.id:
            notify_user(ticket.customer, 'ticket_status_changed', {
                'ticket_id': ticket.id, 'title': ticket.title,
                'new_status': status.name})
        trigger_webhook(ticket, 'ticket_updated', request)

        # ارسال رویداد
        EventRegistry.dispatch(Event('status_changed', {
            'instance': ticket,
            'old_status': old_status.name if old_status else None,
            'new_status': status.name,
            'actor': request.user
        }))

        return Response({'message': f'وضعیت به {status.name} تغییر یافت.'})

    @action(detail=True, methods=['post'])
    def change_priority(self, request, pk=None):
        if not is_support_or_admin(request.user):
            return Response({'error': 'شما مجاز به تغییر اولویت نیستید.'}, status=403)
        ticket = self.get_object()
        priority_id = request.data.get('priority_id')
        if not priority_id:
            return Response({'error': 'شناسه اولویت الزامی است.'}, status=400)
        try:
            priority = TicketPriority.objects.get(id=priority_id)
        except TicketPriority.DoesNotExist:
            return Response({'error': 'اولویت یافت نشد.'}, status=404)
        old_priority = ticket.priority
        ticket.priority = priority
        sla = SLA.objects.filter(priority=priority, is_active=True).first()
        if sla:
            ticket.sla = sla
        ticket.save()
        log_activity(ticket, request.user, 'change_priority', {
            'old_priority': old_priority.name if old_priority else None,
            'new_priority': priority.name
        })
        return Response({'message': f'اولویت به {priority.name} تغییر یافت.'})

    @action(detail=True, methods=['post'])
    def add_comment(self, request, pk=None):
        can_internal = is_support_or_admin(request.user)
        # EDRA v36: bool('false') در فرم‌های multipart (که پیوست دارند) True است؛
        # کامنت عمومی پشتیبانی «داخلی» ذخیره می‌شد و مشتری آن را نمی‌دید.
        is_internal = str(request.data.get('is_internal', False)).strip().lower() in (
            '1', 'true', 'yes', 'on')
        if is_internal and not can_internal:
            return Response({'error': 'فقط پشتیبانی می‌تواند کامنت داخلی ثبت کند.'}, status=403)

        ticket = self.get_object()
        content = request.data.get('content')
        if not content:
            return Response({'error': 'متن کامنت الزامی است.'}, status=400)

        # EDRA v36: اعتبارسنجی پیوست‌ها «قبل از» ساخت کامنت؛ قبلاً با پیوست
        # نامعتبر، کامنت ساخته می‌شد و خطای ۴۰۰ می‌آمد (تلاش مجدد = کامنت تکراری).
        from core.validators import validate_uploaded_file, ALLOWED_IMAGE_EXTENSIONS
        _files = request.FILES.getlist('attachments')
        if len(_files) > 10:
            return Response({'error': 'حداکثر ۱۰ فایل پیوست مجاز است.'}, status=400)
        for _f in _files:
            _err = validate_uploaded_file(
                _f,
                allowed_extensions=ALLOWED_IMAGE_EXTENSIONS | {'.pdf', '.zip', '.doc', '.docx', '.xls', '.xlsx'},
                max_size=10 * 1024 * 1024)
            if _err:
                return Response({'error': f'پیوست {_f.name}: {_err}'}, status=400)

        saved_reply_id = request.data.get('saved_reply_id')
        # EDRA v36: پاسخ‌های آماده داخلی‌اند؛ مشتری با حدس شناسه می‌توانست متن
        # آن‌ها را در کامنت خودش بخواند.
        if saved_reply_id and can_internal:
            try:
                saved = SavedReply.objects.get(id=saved_reply_id, is_active=True)
                content = saved.content
            except SavedReply.DoesNotExist:
                pass

        comment = TicketComment.objects.create(
            ticket=ticket,
            user=request.user,
            content=content,
            is_internal=is_internal
        )

        from core.validators import validate_uploaded_file, ALLOWED_IMAGE_EXTENSIONS
        files = request.FILES.getlist('attachments')
        if len(files) > 10:
            return Response({'error': 'حداکثر ۱۰ فایل پیوست مجاز است.'}, status=400)
        for file in files:
            error = validate_uploaded_file(
                file,
                allowed_extensions=ALLOWED_IMAGE_EXTENSIONS | {'.pdf', '.zip', '.doc', '.docx', '.xls', '.xlsx'},
                max_size=10 * 1024 * 1024
            )
            if error:
                return Response({'error': f'پیوست {file.name}: {error}'}, status=400)
        for file in files:
            TicketAttachment.objects.create(
                ticket=ticket,
                comment=comment,
                file=file,
                filename=file.name,
                file_size=file.size,
                uploaded_by=request.user
            )

        log_activity(ticket, request.user, 'comment', {'comment_id': comment.id})
        send_notification(ticket, 'ticket_comment', f'کامنت جدید در تیکت #{ticket.id} توسط {request.user.username}')
        # EDRA v33: مشتری هرگز از پاسخ پشتیبانی باخبر نمی‌شد (اعلان فقط برای
        # کارکنان بود). پاسخ داخلی (is_internal) هرگز به مشتری اعلام نمی‌شود.
        try:
            if not is_internal:
                ctx = {'ticket_id': ticket.id, 'title': ticket.title}
                if request.user.id != ticket.customer_id:
                    notify_user(ticket.customer, 'ticket_reply', ctx)
                elif ticket.assigned_to_id:
                    notify_user(ticket.assigned_to, 'ticket_customer_reply', ctx)
        except Exception as notif_error:
            logger.error(f"Error sending ticket reply notification: {notif_error}")

        if not ticket.first_response_at and can_internal and not is_internal:
            ticket.first_response_at = timezone.now()
            ticket.save()

        trigger_webhook(ticket, 'comment_added', request)
        serializer = TicketCommentSerializer(comment, context={'request': request})
        return Response(serializer.data, status=201)

    @action(detail=True, methods=['post'])
    def toggle_pin(self, request, pk=None):
        if not is_support_or_admin(request.user):
            return Response({'error': 'شما مجاز به پین کردن تیکت نیستید.'}, status=403)
        ticket = self.get_object()
        ticket.is_pinned = not ticket.is_pinned
        ticket.save()
        action_type = 'pinned' if ticket.is_pinned else 'unpinned'
        log_activity(ticket, request.user, action_type, {})
        return Response({'message': 'پین تیکت با موفقیت تغییر یافت.'})

    @action(detail=True, methods=['post'])
    def refer(self, request, pk=None):
        if not is_support_or_admin(request.user):
            return Response({'error': 'شما مجاز به ارجاع تیکت نیستید.'}, status=403)
        ticket = self.get_object()
        department_id = request.data.get('department_id')
        user_id = request.data.get('user_id')
        if department_id:
            try:
                dept = TicketDepartment.objects.get(id=department_id)
                ticket.department = dept
            except TicketDepartment.DoesNotExist:
                return Response({'error': 'دپارتمان یافت نشد.'}, status=404)
        if user_id:
            try:
                user = User.objects.get(id=user_id)
                ticket.assigned_to = user
            except User.DoesNotExist:
                return Response({'error': 'کاربر یافت نشد.'}, status=404)
        ticket.save()
        log_activity(ticket, request.user, 'refer', {'department': department_id, 'user': user_id})
        send_notification(ticket, 'ticket_referred', f'تیکت #{ticket.id} ارجاع شد.')
        return Response({'message': 'تیکت با موفقیت ارجاع شد.'})

    # ---------- اکشن‌های جدید ----------

    @action(detail=False, methods=['get'])
    def statistics(self, request):
        if not is_support_or_admin(request.user):
            return Response({'error': 'دسترسی محدود'}, status=403)

        total = Ticket.objects.count()
        open_tickets = Ticket.objects.filter(status__is_closed=False).count()
        closed_tickets = Ticket.objects.filter(status__is_closed=True).count()

        # EDRA v36: ExtractHour روی یک «بازه‌ی زمانی» فقط «مولفه‌ی ساعت» (۰ تا ۲۳)
        # را برمی‌گرداند نه کل ساعت‌ها؛ میانگین پاسخ/حل بیش از ۲۴ ساعت اشتباه
        # گزارش می‌شد (مثلاً ۵۱ ساعت → ۳). میانگین مدت واقعی گرفته می‌شود.
        from django.db.models import ExpressionWrapper, DurationField

        def _avg_hours(field):
            avg = Ticket.objects.exclude(**{field: None}).aggregate(
                avg=Avg(ExpressionWrapper(
                    F(field) - F('created_at'),
                    output_field=DurationField())))['avg']
            return round(avg.total_seconds() / 3600, 2) if avg else 0

        avg_response = _avg_hours('first_response_at')
        avg_resolution = _avg_hours('resolved_at')

        by_status = Ticket.objects.values('status__name').annotate(count=Count('id'))
        by_priority = Ticket.objects.values('priority__name').annotate(count=Count('id'))

        data = {
            'total': total,
            'open': open_tickets,
            'closed': closed_tickets,
            'avg_response_hours': avg_response or 0,
            'avg_resolution_hours': avg_resolution or 0,
            'by_status': by_status,
            'by_priority': by_priority,
        }
        return Response(data)

    @action(detail=True, methods=['post'])
    def detect_duplicate(self, request, pk=None):
        if not is_support_or_admin(request.user):
            return Response({'error': 'دسترسی محدود'}, status=403)

        ticket = self.get_object()
        try:
            threshold = float(request.data.get('threshold', 0.7))
        except (TypeError, ValueError):
            return Response({'error': 'threshold نامعتبر است.'}, status=400)
        if not (0 <= threshold <= 1):
            return Response({'error': 'threshold باید بین ۰ و ۱ باشد.'}, status=400)
        similar = Ticket.objects.filter(
            customer=ticket.customer,
            status__is_closed=False
        ).exclude(id=ticket.id)

        from difflib import SequenceMatcher
        duplicates = []
        for other in similar:
            ratio = SequenceMatcher(
                None,
                ticket.title + ticket.description,
                other.title + other.description
            ).ratio()
            if ratio >= threshold:
                dup, created = TicketDuplicate.objects.get_or_create(
                    ticket=ticket,
                    duplicate_ticket=other,
                    defaults={'similarity_score': ratio}
                )
                if created:
                    duplicates.append(other.id)

        return Response({'duplicates': duplicates, 'count': len(duplicates)})

    @action(detail=False, methods=['get'])
    def my_tickets(self, request):
        qs = Ticket.objects.filter(customer=request.user).order_by('-created_at')
        page = self.paginate_queryset(qs)
        if page is not None:
            serializer = TicketListSerializer(page, many=True)
            return self.get_paginated_response(serializer.data)
        return Response(TicketListSerializer(qs, many=True).data)

    @action(detail=False, methods=['get'])
    def assigned_to_me(self, request):
        if not request.user.is_authenticated:
            return Response({'error': 'احراز هویت نشده'}, status=401)
        qs = Ticket.objects.filter(assigned_to=request.user).order_by('-created_at')
        page = self.paginate_queryset(qs)
        if page is not None:
            serializer = TicketListSerializer(page, many=True)
            return self.get_paginated_response(serializer.data)
        return Response(TicketListSerializer(qs, many=True).data)


# ============================================================
# سایر ViewSet‌ها (بدون تغییر)
# ============================================================

class _LookupReadForAuthenticatedMixin:
    """
    EDRA v36 — باگ عملکردی: فرم «تیکت جدید» مشتری (new-ticket-form.tsx) فهرست
    دسته‌بندی/اولویت/دپارتمان را از این endpoint ها می‌خواند، ولی همه‌ی آن‌ها
    IsAdminUserOrGroup بودند؛ مشتری و کارشناس پشتیبانی ۴۰۳ می‌گرفتند و لیست‌های
    انتخاب خالی می‌ماند. اکنون خواندن برای هر کاربر واردشده (فقط موارد فعال) و
    نوشتن فقط برای ادمین است.
    """
    permission_classes = [IsAdminOrAuthenticatedReadOnly]

    def get_queryset(self):
        qs = super().get_queryset()
        if not is_support_or_admin(self.request.user):
            qs = qs.filter(is_active=True)
        return qs


class TicketCategoryViewSet(_LookupReadForAuthenticatedMixin, viewsets.ModelViewSet):
    pagination_class = None
    queryset = TicketCategory.objects.all()
    serializer_class = TicketCategorySerializer


class TicketPriorityViewSet(_LookupReadForAuthenticatedMixin, viewsets.ModelViewSet):
    pagination_class = None
    queryset = TicketPriority.objects.all()
    serializer_class = TicketPrioritySerializer


class TicketStatusViewSet(_LookupReadForAuthenticatedMixin, viewsets.ModelViewSet):
    queryset = TicketStatus.objects.all()
    serializer_class = TicketStatusSerializer


class TicketDepartmentViewSet(_LookupReadForAuthenticatedMixin, viewsets.ModelViewSet):
    queryset = TicketDepartment.objects.all()
    serializer_class = TicketDepartmentSerializer


class TicketLabelViewSet(viewsets.ModelViewSet):
    queryset = TicketLabel.objects.all()
    serializer_class = TicketLabelSerializer
    permission_classes = [IsAdminUserOrGroup]


class SavedReplyViewSet(viewsets.ModelViewSet):
    # EDRA v32 — همان الگوی باگ (سومین نمونه‌ی همین اپ: Announcement،
    # KnowledgeBaseCategory، حالا این یکی): بدون get_queryset، هر پاسخ
    # آماده‌ای که غیرفعال می‌شد از لیست مدیریتی خودِ ادمین/پشتیبانی هم
    # برای همیشه حذف می‌شد.
    queryset = SavedReply.objects.filter(is_active=True)
    serializer_class = SavedReplySerializer
    # EDRA v36: «پاسخ‌های آماده» ابزار داخلی پشتیبانی‌اند؛ قبلاً هر کاربر
    # واردشده (از جمله مشتری) می‌توانست همه‌ی آن‌ها را بخواند.
    permission_classes = [IsAdminUserOrGroup]

    def get_permissions(self):
        from rest_framework.permissions import BasePermission

        class _SupportOrAdmin(BasePermission):
            def has_permission(self, request, view):
                return is_support_or_admin(request.user)
        return [_SupportOrAdmin()]

    def get_queryset(self):
        if is_support_or_admin(self.request.user):
            return SavedReply.objects.all()
        return SavedReply.objects.none()

    def perform_create(self, serializer):
        serializer.save(created_by=self.request.user)


class KnowledgeBaseCategoryViewSet(viewsets.ModelViewSet):
    # EDRA v32 — همان باگ AnnouncementViewSet/دسته‌ی قبلی: اینجا حتی یک
    # get_queryset ناقص هم نبود — queryset کلاس (فیلترشده به is_active=True)
    # بدون هیچ استثنایی برای همه اعمال می‌شد. اگر دسته‌ای (مثلاً از پنل جنگو)
    # غیرفعال می‌شد، حتی ادمین هم دیگر در این لیست نمی‌دیدش. الگوی درست را از
    # KnowledgeBaseArticleViewSet کنارش (که درست نوشته شده) کپی کردم.
    queryset = KnowledgeBaseCategory.objects.filter(is_active=True)
    serializer_class = KnowledgeBaseCategorySerializer
    permission_classes = [IsAdminOrReadOnly]
    filter_backends = [SearchFilter]
    search_fields = ['name', 'description']

    def get_queryset(self):
        if is_support_or_admin(self.request.user):
            return KnowledgeBaseCategory.objects.all()
        return KnowledgeBaseCategory.objects.filter(is_active=True)


class KnowledgeBaseArticleViewSet(viewsets.ModelViewSet):
    queryset = KnowledgeBaseArticle.objects.filter(is_published=True)
    serializer_class = KnowledgeBaseArticleSerializer
    permission_classes = [IsAdminOrReadOnly]
    filter_backends = [SearchFilter]
    if HAS_FILTER:
        filter_backends.insert(0, DjangoFilterBackend)
        filterset_fields = ['category', 'is_published']
    search_fields = ['title', 'content', 'tags', 'summary']

    def get_queryset(self):
        if is_support_or_admin(self.request.user):
            return KnowledgeBaseArticle.objects.all()
        return KnowledgeBaseArticle.objects.filter(is_published=True)

    # EDRA v27 — رفع باگ واقعی (گزارش کاربر، سپتامبر ۲۰۲۶): همان الگوی
    # پیدا‌شده در AnnouncementViewSet — created_by اجباری است ولی
    # هیچ‌جا مقداردهی نمی‌شد.
    def perform_create(self, serializer):
        serializer.save(created_by=self.request.user)

    def retrieve(self, request, *args, **kwargs):
        # EDRA v36: افزایش اتمیک (F) به‌جای read-modify-write (از دست رفتن شمارش
        # در بازدید همزمان) و بدون دوبار واکشی شیء.
        instance = self.get_object()
        KnowledgeBaseArticle.objects.filter(pk=instance.pk).update(
            view_count=F('view_count') + 1)
        instance.view_count += 1
        return Response(self.get_serializer(instance).data)

    # EDRA v36: این دو اکشن POST هستند و permission کلاس (IsAdminOrReadOnly)
    # POST را فقط برای ادمین باز می‌کرد؛ یعنی «مفید بود؟» برای مشتری همیشه ۴۰۳
    # بود. فقط به کاربر واردشده نیاز دارد.
    @action(detail=True, methods=['post'], permission_classes=[IsAuthenticated])
    def helpful(self, request, pk=None):
        article = self.get_object()
        KnowledgeBaseArticle.objects.filter(pk=article.pk).update(
            helpful_count=F('helpful_count') + 1)
        return Response({'message': 'امتیاز مفید ثبت شد.'})

    @action(detail=True, methods=['post'], permission_classes=[IsAuthenticated])
    def unhelpful(self, request, pk=None):
        article = self.get_object()
        KnowledgeBaseArticle.objects.filter(pk=article.pk).update(
            unhelpful_count=F('unhelpful_count') + 1)
        return Response({'message': 'امتیاز غیرمفید ثبت شد.'})


class AnnouncementViewSet(viewsets.ModelViewSet):
    # EDRA v32 — باگ واقعی: queryset کلاس همیشه is_active=True را از قبل
    # فیلتر می‌کرد، پس حتی شاخه‌ی ادمین در get_queryset (که قصدش دیدن «همه»
    # بود) هم هرگز اعلانیه‌ی غیرفعال را نمی‌دید. نتیجه: هر اعلانیه‌ای که
    # غیرفعال می‌شد، از لیست مدیریتی خودِ ادمین هم برای همیشه ناپدید می‌شد —
    # بدون هیچ راهی برای ویرایش/فعال‌سازی دوباره‌اش از همین پنل.
    queryset = Announcement.objects.all()
    serializer_class = AnnouncementSerializer
    permission_classes = [IsAdminOrAuthenticatedReadOnly]
    if HAS_FILTER:
        filter_backends = [DjangoFilterBackend]
        filterset_fields = ['audience']

    def get_queryset(self):
        user = self.request.user
        qs = super().get_queryset()
        if is_support_or_admin(user):
            return qs
        # EDRA v32 — پیگیری گزارش قبلی: expires_at در مدل تعریف شده بود ولی
        # هیچ‌جا اعمال نمی‌شد؛ اعلانیه‌ی منقضی‌شده همچنان برای مشتری نمایش
        # داده می‌شد. Q(expires_at__isnull=True) یعنی «بدون تاریخ انقضا» هم
        # همچنان دائمی نمایش داده شود.
        from django.utils import timezone
        return (
            qs.filter(is_active=True)
            .filter(Q(expires_at__isnull=True) | Q(expires_at__gt=timezone.now()))
            .filter(Q(audience='customers') | Q(audience='all'))
        )

    # EDRA v27 — رفع باگ واقعی (گزارش کاربر، سپتامبر ۲۰۲۶): created_by
    # یک فیلد اجباری است ولی read_only در سریالایزر بود و هیچ‌جا مقداردهی
    # نمی‌شد — یعنی ساخت هر اعلانیه‌ی جدید از طریق API با خطای پایگاه‌داده
    # (NOT NULL) شکست می‌خورد، صرف‌نظر از این‌که فرانت‌اند برایش وجود
    # داشت یا نه.
    def perform_create(self, serializer):
        serializer.save(created_by=self.request.user)


class TicketNotificationViewSet(viewsets.ReadOnlyModelViewSet):
    serializer_class = TicketNotificationSerializer
    permission_classes = [IsAuthenticated]

    def get_queryset(self):
        return TicketNotification.objects.filter(user=self.request.user).order_by('-created_at')

    @action(detail=True, methods=['post'])
    def mark_read(self, request, pk=None):
        notification = self.get_object()
        if notification.user != request.user:
            return Response({'error': 'دسترسی غیرمجاز'}, status=403)
        notification.is_read = True
        notification.save()
        return Response({'message': 'نوتیفیکیشن خوانده شد.'})

    @action(detail=False, methods=['post'])
    def mark_all_read(self, request):
        TicketNotification.objects.filter(user=request.user, is_read=False).update(is_read=True)
        return Response({'message': 'همه نوتیفیکیشن‌ها خوانده شدند.'})


class TicketActivityLogViewSet(viewsets.ReadOnlyModelViewSet):
    queryset = TicketActivityLog.objects.all()
    serializer_class = TicketActivityLogSerializer
    permission_classes = [IsAdminUserOrGroup]
    filter_backends = [SearchFilter, OrderingFilter]
    search_fields = ['ticket__title', 'user__username', 'action']
    ordering_fields = ['created_at']


class UserAccountSettingsViewSet(viewsets.ModelViewSet):
    queryset = UserAccountSettings.objects.all()
    serializer_class = UserAccountSettingsSerializer
    permission_classes = [IsAdminUserOrGroup]
    filter_backends = [SearchFilter]
    search_fields = ['user__username', 'user__email']


class TicketSystemSettingsView(generics.RetrieveUpdateAPIView):
    queryset = TicketSystemSettings.objects.all()
    serializer_class = TicketSystemSettingsSerializer
    permission_classes = [IsAdminUserOrGroup]

    def get_object(self):
        return TicketSystemSettings.objects.first() or TicketSystemSettings.objects.create()


class SLAViewSet(viewsets.ModelViewSet):
    queryset = SLA.objects.all()
    serializer_class = SLASerializer
    permission_classes = [IsAdminUserOrGroup]


class TicketRuleViewSet(viewsets.ModelViewSet):
    queryset = TicketRule.objects.all()
    serializer_class = TicketRuleSerializer
    permission_classes = [IsAdminUserOrGroup]


class WebhookViewSet(viewsets.ModelViewSet):
    queryset = Webhook.objects.all()
    serializer_class = WebhookSerializer
    permission_classes = [IsAdminUserOrGroup]
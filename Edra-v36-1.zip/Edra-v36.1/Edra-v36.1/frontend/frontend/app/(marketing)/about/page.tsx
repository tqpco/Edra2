import type { Metadata } from "next";
import { Target, Eye, ShieldCheck, Users, Award, Zap, ArrowLeft, ArrowUpLeft } from "lucide-react";
import Link from "next/link";
import { Button } from "@/components/ui/button";

export const metadata: Metadata = { title: "درباره ما" };

/* EDRA v26 — بازطراحی مینیمال: پالت سبز رولکسی / خاکستری / کاکی */

const VALUES = [
  {
    icon: ShieldCheck,
    title: "دقت و استانداردسازی",
    desc: "چک‌لیست‌های بازرسی متناسب با هر نوع تجهیز، طراحی‌شده توسط کارشناسان مجرب",
  },
  {
    icon: Zap,
    title: "سرعت در ارائه خدمات",
    desc: "از ثبت درخواست تا دریافت گزارش نهایی، با کمترین زمان انتظار",
  },
  {
    icon: Users,
    title: "شبکه کارشناسان مجرب",
    desc: "تیمی از کارشناسان بازرسی با سال‌ها تجربه در صنعت تجهیزات سنگین",
  },
  {
    icon: Award,
    title: "شفافیت کامل",
    desc: "قیمت‌گذاری شفاف، پیگیری آنلاین وضعیت درخواست در هر لحظه",
  },
];

export default function AboutPage() {
  return (
    <>
      {/* Hero */}
      <section className="relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-b from-primary/[0.03] via-background to-background" />
        <div className="absolute -top-24 left-1/2 h-80 w-80 -translate-x-1/2 rounded-full bg-primary/[0.04] blur-3xl" />

        <div className="relative mx-auto max-w-4xl px-4 pt-16 pb-12 md:pt-24">
          <div className="text-center">
            <span className="mb-6 inline-flex items-center gap-2 rounded-full border border-primary/20 bg-primary/5 px-4 py-1.5 text-xs font-medium text-primary">
              درباره ادرو
            </span>
            <h1 className="text-3xl font-bold tracking-tight text-foreground sm:text-4xl lg:text-5xl">
              استاندارد دیجیتال بازرسی
              <br />
              <span className="text-primary">تجهیزات صنعتی</span>
            </h1>
            <p className="mx-auto mt-6 max-w-2xl text-base leading-relaxed text-muted-foreground sm:text-lg">
              ادرو با هدف دیجیتالی‌کردن و استانداردسازی فرآیند بازرسی تجهیزات
              سنگین صنعتی راه‌اندازی شده است. ما مسیر رزرو، انجام بازرسی و صدور
              گواهی را از یک فرآیند کاغذی و پراکنده، به تجربه‌ای سریع، شفاف و
              کاملاً آنلاین تبدیل کرده‌ایم.
            </p>
          </div>
        </div>
      </section>

      {/* Mission / Vision */}
      <section className="mx-auto max-w-4xl px-4 py-16">
        <div className="grid gap-5 sm:grid-cols-2">
          <div className="rounded-2xl border border-border/60 bg-card p-7 transition-all hover:border-primary/30 hover:shadow-sm">
            <div className="mb-4 flex size-12 items-center justify-center rounded-2xl bg-primary/10 text-primary">
              <Target className="size-6" strokeWidth={1.5} />
            </div>
            <h2 className="text-lg font-semibold text-foreground">ماموریت ما</h2>
            <p className="mt-2.5 text-sm leading-relaxed text-muted-foreground">
              تضمین ایمنی محیط‌های کاری صنعتی از طریق ارائه‌ی خدمات بازرسی
              سریع، استاندارد و قابل‌استناد برای تمام تجهیزات سنگین.
            </p>
          </div>
          <div className="rounded-2xl border border-border/60 bg-card p-7 transition-all hover:border-primary/30 hover:shadow-sm">
            <div className="mb-4 flex size-12 items-center justify-center rounded-2xl bg-primary/10 text-primary">
              <Eye className="size-6" strokeWidth={1.5} />
            </div>
            <h2 className="text-lg font-semibold text-foreground">چشم‌انداز ما</h2>
            <p className="mt-2.5 text-sm leading-relaxed text-muted-foreground">
              تبدیل‌شدن به مرجع اصلی بازرسی و صدور گواهی تجهیزات صنعتی در
              ایران، با پوشش کامل انواع تجهیزات و شهرها.
            </p>
          </div>
        </div>
      </section>

      {/* Values */}
      <section className="border-y border-border/50 bg-secondary/30 py-16">
        <div className="mx-auto max-w-4xl px-4">
          <div className="mb-10 text-center">
            <span className="mb-3 inline-block text-xs font-medium uppercase tracking-wider text-primary">
              ارزش‌ها
            </span>
            <h2 className="text-2xl font-bold tracking-tight text-foreground sm:text-3xl">
              ارزش‌های ما
            </h2>
          </div>
          <div className="grid gap-5 sm:grid-cols-2">
            {VALUES.map((v) => (
              <div
                key={v.title}
                className="flex items-start gap-4 rounded-2xl border border-border/60 bg-card p-5 transition-all hover:border-primary/30 hover:shadow-sm"
              >
                <span className="flex size-11 shrink-0 items-center justify-center rounded-2xl bg-primary/10 text-primary">
                  <v.icon className="size-5" strokeWidth={1.5} />
                </span>
                <div>
                  <p className="font-semibold text-foreground">{v.title}</p>
                  <p className="mt-1 text-sm leading-relaxed text-muted-foreground">
                    {v.desc}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="mx-auto max-w-4xl px-4 py-16">
        <div className="text-center">
          <p className="mb-5 text-sm text-muted-foreground">
            آماده‌اید تجهیز خود را استاندارد بازرسی کنید؟
          </p>
          <Button
            size="lg"
            className="h-12 rounded-xl px-7 text-sm"
            asChild
          >
            <Link href="/booking?fresh=1">
              شروع رزرو بازرسی
              <ArrowUpLeft className="size-4" />
            </Link>
          </Button>
        </div>
      </section>
    </>
  );
}

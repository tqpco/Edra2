import type { Metadata } from "next";
import { Phone, Mail, MapPin, Clock } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { ContactForm } from "./contact-form";

export const metadata: Metadata = { title: "تماس با ما" };

/* EDRA v26 — صفحه تماس با ما: پالت سبز رولکسی / خاکستری / کاکی */

const INFO = [
  { icon: Phone, label: "تلفن پشتیبانی", value: "021-XXXXXXXX", dir: "ltr" as const },
  { icon: Mail, label: "ایمیل", value: "info@edra-inspect.ir", dir: "ltr" as const },
  { icon: MapPin, label: "آدرس", value: "تهران، ایران" },
  { icon: Clock, label: "ساعات پاسخ‌گویی", value: "شنبه تا چهارشنبه، ۸ تا ۱۶" },
];

export default function ContactPage() {
  return (
    <>
      {/* Hero */}
      <section className="relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-b from-primary/[0.03] via-background to-background" />
        <div className="absolute -top-24 left-1/2 h-80 w-80 -translate-x-1/2 rounded-full bg-primary/[0.04] blur-3xl" />

        <div className="relative mx-auto max-w-5xl px-4 pt-16 pb-12 md:pt-24">
          <div className="text-center">
            <span className="mb-6 inline-flex items-center gap-2 rounded-full border border-primary/20 bg-primary/5 px-4 py-1.5 text-xs font-medium text-primary">
              تماس با ما
            </span>
            <h1 className="text-3xl font-bold tracking-tight text-foreground sm:text-4xl">
              با ما در ارتباط باشید
            </h1>
            <p className="mx-auto mt-4 max-w-lg text-sm text-muted-foreground sm:text-base">
              سوالی دارید؟ خوشحال می‌شویم کمکتان کنیم
            </p>
          </div>
        </div>
      </section>

      {/* Content */}
      <section className="mx-auto max-w-5xl px-4 pb-20">
        <div className="grid gap-8 lg:grid-cols-5">
          {/* Contact Info */}
          <div className="flex flex-col gap-4 lg:col-span-2">
            {INFO.map((item) => (
              <div
                key={item.label}
                className="flex items-center gap-4 rounded-2xl border border-border/60 bg-card px-5 py-4 transition-all hover:border-primary/30 hover:shadow-sm"
              >
                <span className="bg-primary/10 text-primary flex size-11 shrink-0 items-center justify-center rounded-xl">
                  <item.icon className="size-5" strokeWidth={1.5} />
                </span>
                <div>
                  <p className="text-xs text-muted-foreground">{item.label}</p>
                  <p className="mt-0.5 text-sm font-medium text-foreground" dir={item.dir}>
                    {item.value}
                  </p>
                </div>
              </div>
            ))}
          </div>

          {/* Contact Form */}
          <div className="rounded-2xl border border-border/60 bg-card p-6 lg:col-span-3">
            <h2 className="mb-5 text-lg font-semibold text-foreground">
              ارسال پیام
            </h2>
            <ContactForm />
          </div>
        </div>
      </section>
    </>
  );
}

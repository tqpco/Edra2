import { HelpCircle, ChevronDown } from "lucide-react";
import { apiServerFetch } from "@/lib/api-server";

export const metadata = { title: "سوالات متداول | ادرو" };

/* EDRA v26 — صفحه سوالات متداول: پالت سبز رولکسی / خاکستری / کاکی */

interface FaqItem {
  id: number;
  question: string;
  answer: string;
  category: string;
}

const CATEGORY_LABEL: Record<string, string> = {
  general: "عمومی",
  technical: "فنی",
  billing: "مالی",
  support: "پشتیبانی",
  inspection: "بازرسی",
};

async function fetchFaqs(): Promise<FaqItem[]> {
  try {
    const data = await apiServerFetch<{ results: FaqItem[] } | FaqItem[]>(
      "/api/public/faqs/",
      { authenticated: false, cache: "no-store" }
    );
    return Array.isArray(data) ? data : data.results ?? [];
  } catch {
    return [];
  }
}

export default async function FaqPage() {
  const faqs = await fetchFaqs();

  const grouped = faqs.reduce<Record<string, FaqItem[]>>((acc, faq) => {
    const key = faq.category || "general";
    (acc[key] ||= []).push(faq);
    return acc;
  }, {});

  return (
    <>
      {/* Hero */}
      <section className="relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-b from-primary/[0.03] via-background to-background" />
        <div className="absolute -top-24 left-1/2 h-80 w-80 -translate-x-1/2 rounded-full bg-primary/[0.04] blur-3xl" />

        <div className="relative mx-auto max-w-3xl px-4 pt-16 pb-12 md:pt-24">
          <div className="text-center">
            <div className="mx-auto mb-5 flex size-14 items-center justify-center rounded-2xl bg-primary/10 text-primary">
              <HelpCircle className="size-7" strokeWidth={1.5} />
            </div>
            <h1 className="text-3xl font-bold tracking-tight text-foreground sm:text-4xl">
              سوالات متداول
            </h1>
            <p className="mx-auto mt-4 max-w-lg text-sm text-muted-foreground sm:text-base">
              پاسخ سوالات پرتکرار شما درباره بازرسی ماشین‌آلات و فرایند دریافت گزارش
            </p>
          </div>
        </div>
      </section>

      {/* FAQ Content */}
      <section className="mx-auto max-w-3xl px-4 pb-20">
        {Object.keys(grouped).length === 0 && (
          <div className="rounded-2xl border border-dashed border-border/60 py-16 text-center">
            <p className="text-sm text-muted-foreground">سوالی ثبت نشده است.</p>
          </div>
        )}

        <div className="flex flex-col gap-6">
          {Object.entries(grouped).map(([category, items]) => (
            <div key={category}>
              <h2 className="mb-3 flex items-center gap-2 text-base font-semibold text-foreground">
                <span className="bg-primary/10 text-primary flex size-7 items-center justify-center rounded-lg text-xs">
                  {CATEGORY_LABEL[category] ? CATEGORY_LABEL[category][0] : "?"}
                </span>
                {CATEGORY_LABEL[category] ?? category}
              </h2>
              <div className="flex flex-col gap-2">
                {items.map((faq) => (
                  <details
                    key={faq.id}
                    className="group rounded-2xl border border-border/60 bg-card px-5 py-0 transition-all open:border-primary/30 open:shadow-sm"
                  >
                    <summary className="flex cursor-pointer items-center justify-between gap-3 py-4 text-sm font-medium text-foreground [&::-webkit-details-marker]:hidden">
                      {faq.question}
                      <ChevronDown className="size-4 shrink-0 text-muted-foreground transition-transform group-open:rotate-180 group-open:text-primary" />
                    </summary>
                    <p className="pb-4 text-sm leading-7 text-muted-foreground">
                      {faq.answer}
                    </p>
                  </details>
                ))}
              </div>
            </div>
          ))}
        </div>
      </section>
    </>
  );
}

import Link from "next/link";
import {
  ArrowLeft,
  ArrowUpLeft,
  ShieldCheck,
  Calendar,
  FileCheck2,
  Wrench,
  Construction,
  Forklift,
  Container,
  Building2,
  Gauge,
  ClipboardCheck,
  Smartphone,
  BadgeCheck,
  CheckCircle2,
  Star,
} from "lucide-react";

import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { TrustStats } from "@/components/marketing/trust-stats";

/* EDRA v26 — بازطراحی مینیمال: پالت سبز رولکسی / خاکستری / کاکی */

const EQUIPMENT = [
  { icon: Construction, name: "جرثقیل برجی" },
  { icon: Building2, name: "جرثقیل سیار" },
  { icon: Forklift, name: "لیفتراک" },
  { icon: Container, name: "بالابر" },
  { icon: Gauge, name: "جرثقیل سقفی" },
  { icon: Wrench, name: "سایر تجهیزات" },
];

const STEPS = [
  {
    icon: ClipboardCheck,
    title: "ثبت درخواست",
    desc: "نوع تجهیز، مشخصات فنی و شهر خود را در چند دقیقه وارد کنید",
  },
  {
    icon: Calendar,
    title: "زمان‌بندی",
    desc: "زمان مناسب برای بازرسی را از تقویم انتخاب کنید",
  },
  {
    icon: Smartphone,
    title: "بازرسی تخصصی",
    desc: "کارشناس مجرب در محل، چک‌لیست استاندارد را تکمیل می‌کند",
  },
  {
    icon: BadgeCheck,
    title: "دریافت گواهی",
    desc: "گزارش رسمی و قابل‌استناد را به‌صورت دیجیتال دریافت کنید",
  },
];

const FEATURES = [
  {
    icon: ShieldCheck,
    title: "استاندارد ملی",
    desc: "بازرسی بر اساس آخرین استانداردهای ملی و بین‌المللی",
  },
  {
    icon: FileCheck2,
    title: "گزارش دیجیتال",
    desc: "دریافت آنی گزارش با قابلیت استعلام و پیگیری",
  },
  {
    icon: CheckCircle2,
    title: "تیم مجرب",
    desc: "کارشناسان بازرسی با سال‌ها تجربه در صنعت تجهیزات سنگین",
  },
  {
    icon: Star,
    title: "رضایت ۱۰۰٪",
    desc: "تضمین کیفیت خدمات و پشتیبانی مداوم پس از بازرسی",
  },
];

export default function HomePage() {
  return (
    <>
      {/* ═══════════════════ HERO ═══════════════════ */}
      <section className="relative overflow-hidden">
        {/* Gradient background */}
        <div className="absolute inset-0 bg-gradient-to-b from-primary/[0.03] via-background to-background" />
        <div className="absolute -top-24 left-1/2 h-96 w-96 -translate-x-1/2 rounded-full bg-primary/[0.04] blur-3xl" />

        <div className="relative mx-auto max-w-6xl px-4 pt-16 pb-20 md:pt-24 md:pb-28">
          <div className="mx-auto max-w-3xl text-center">
            {/* Badge */}
            <span className="mx-auto mb-8 inline-flex items-center gap-2 rounded-full border border-primary/20 bg-primary/5 px-4 py-1.5 text-xs font-medium text-primary">
              <ShieldCheck className="size-3.5" />
              گواهی رسمی و قابل‌استناد بازرسی
            </span>

            {/* Heading */}
            <h1 className="text-3xl leading-tight font-bold tracking-tight text-foreground sm:text-5xl lg:text-6xl">
              بازرسی تخصصی تجهیزات سنگین صنعتی
              <br />
              <span className="text-primary">کاملاً آنلاین</span>
            </h1>

            {/* Description */}
            <p className="mx-auto mt-6 max-w-xl text-base leading-relaxed text-muted-foreground sm:text-lg">
              جرثقیل، لیفتراک و سایر تجهیزات صنعتی خود را رزرو کنید؛ کارشناس
              مجرب ما در محل حضور می‌یابد و گزارش استاندارد را دیجیتال دریافت
              می‌کنید.
            </p>

            {/* CTAs */}
            <div className="mt-10 flex flex-col items-center justify-center gap-3 sm:flex-row">
              <Button
                size="lg"
                className="h-12 rounded-xl px-7 text-sm shadow-sm"
                asChild
              >
                <Link href="/booking?fresh=1">
                  شروع رزرو بازرسی
                  <ArrowLeft className="size-4" />
                </Link>
              </Button>
              <Button
                size="lg"
                variant="outline"
                className="h-12 rounded-xl px-7 text-sm"
                asChild
              >
                <Link href="/about">آشنایی با ادرو</Link>
              </Button>
            </div>
          </div>

          {/* Trust Stats */}
          <div className="mt-16">
            <TrustStats />
          </div>
        </div>
      </section>

      {/* ═══════════════════ EQUIPMENT ═══════════════════ */}
      <section className="mx-auto max-w-6xl px-4 py-20">
        <div className="mb-12 text-center">
          <span className="mb-3 inline-block text-xs font-medium uppercase tracking-wider text-primary">
            تجهیزات
          </span>
          <h2 className="text-2xl font-bold tracking-tight text-foreground sm:text-3xl">
            تجهیزات تحت پوشش
          </h2>
          <p className="mt-2 text-sm text-muted-foreground">
            بازرسی استاندارد برای طیف گسترده‌ای از تجهیزات صنعتی
          </p>
        </div>
        <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-6">
          {EQUIPMENT.map((eq) => (
            <div
              key={eq.name}
              className="group flex flex-col items-center gap-3 rounded-2xl border border-border/60 bg-card px-4 py-7 text-center transition-all hover:border-primary/30 hover:shadow-sm"
            >
              <span className="flex size-14 items-center justify-center rounded-2xl bg-secondary text-primary transition-all group-hover:bg-primary group-hover:text-primary-foreground">
                <eq.icon className="size-6" strokeWidth={1.5} />
              </span>
              <span className="text-sm font-medium text-foreground">{eq.name}</span>
            </div>
          ))}
        </div>
      </section>

      {/* ═══════════════════ PROCESS ═══════════════════ */}
      <section className="border-y border-border/50 bg-secondary/30 py-20">
        <div className="mx-auto max-w-6xl px-4">
          <div className="mb-12 text-center">
            <span className="mb-3 inline-block text-xs font-medium uppercase tracking-wider text-primary">
              فرآیند
            </span>
            <h2 className="text-2xl font-bold tracking-tight text-foreground sm:text-3xl">
              از درخواست تا گواهی
            </h2>
            <p className="mt-2 text-sm text-muted-foreground">
              فقط ۴ گام ساده تا دریافت گواهی رسمی بازرسی
            </p>
          </div>
          <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
            {STEPS.map((step, i) => (
              <div
                key={step.title}
                className="relative rounded-2xl border border-border/60 bg-card p-6 transition-all hover:border-primary/30 hover:shadow-sm"
              >
                {/* Step number */}
                <div className="mb-4 flex items-center gap-3">
                  <span className="flex size-9 items-center justify-center rounded-xl bg-primary text-sm font-bold text-primary-foreground">
                    {["۱", "۲", "۳", "۴"][i]}
                  </span>
                  <step.icon className="size-5 text-primary/60" strokeWidth={1.5} />
                </div>
                <p className="font-semibold text-foreground">{step.title}</p>
                <p className="mt-1.5 text-sm leading-relaxed text-muted-foreground">
                  {step.desc}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ═══════════════════ FEATURES ═══════════════════ */}
      <section className="mx-auto max-w-6xl px-4 py-20">
        <div className="mb-12 text-center">
          <span className="mb-3 inline-block text-xs font-medium uppercase tracking-wider text-primary">
            مزایا
          </span>
          <h2 className="text-2xl font-bold tracking-tight text-foreground sm:text-3xl">
            چرا ادرو؟
          </h2>
          <p className="mt-2 text-sm text-muted-foreground">
            تجربه‌ای متفاوت از بازرسی تجهیزات صنعتی
          </p>
        </div>
        <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
          {FEATURES.map((f) => (
            <div
              key={f.title}
              className="rounded-2xl border border-border/60 bg-card p-6 transition-all hover:border-primary/30 hover:shadow-sm"
            >
              <div className="mb-4 flex size-11 items-center justify-center rounded-2xl bg-primary/10 text-primary">
                <f.icon className="size-5" strokeWidth={1.5} />
              </div>
              <p className="font-semibold text-foreground">{f.title}</p>
              <p className="mt-1.5 text-sm leading-relaxed text-muted-foreground">
                {f.desc}
              </p>
            </div>
          ))}
        </div>
      </section>

      {/* ═══════════════════ CTA ═══════════════════ */}
      <section className="mx-auto max-w-6xl px-4 pb-20">
        <div className="relative overflow-hidden rounded-3xl bg-primary">
          {/* Decorative elements */}
          <div className="absolute -top-20 -left-20 h-64 w-64 rounded-full bg-white/5 blur-2xl" />
          <div className="absolute -bottom-20 -right-20 h-64 w-64 rounded-full bg-white/5 blur-2xl" />

          <div className="relative flex flex-col items-center gap-6 px-6 py-16 text-center sm:px-12">
            <div className="flex size-14 items-center justify-center rounded-2xl bg-white/15">
              <FileCheck2 className="size-7 text-white" strokeWidth={1.5} />
            </div>
            <h2 className="text-2xl font-bold tracking-tight text-white sm:text-3xl">
              همین حالا بازرسی تجهیز خود را رزرو کنید
            </h2>
            <p className="max-w-lg text-sm leading-relaxed text-white/70">
              ثبت درخواست کمتر از ۵ دقیقه زمان می‌برد و می‌توانید بلافاصله
              قیمت دقیق را مشاهده کنید.
            </p>
            <Button
              size="lg"
              className="h-12 rounded-xl bg-white px-7 text-sm font-medium text-primary shadow-sm hover:bg-white/90"
              asChild
            >
              <Link href="/booking?fresh=1">
                شروع رزرو
                <ArrowUpLeft className="size-4" />
              </Link>
            </Button>
          </div>
        </div>
      </section>
    </>
  );
}

import type { Metadata } from "next";
import { FolderKanban } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { formatJalali } from "@/lib/jalali";

export const metadata: Metadata = { title: "پروژه‌های ما" };

/* EDRA v26 — صفحه پروژه‌ها: پالت سبز رولکسی / خاکستری / کاکی */

interface CaseStudy {
  id: number;
  title: string;
  slug: string;
  summary: string;
  published_at: string | null;
}

async function fetchCaseStudies(): Promise<CaseStudy[]> {
  try {
    const apiUrl = process.env.NEXT_PUBLIC_API_URL || "http://localhost:8000";
    const res = await fetch(
      `${apiUrl}/api/public/blog-posts/?category=case_study`,
      { next: { revalidate: 300 } }
    );
    if (!res.ok) return [];
    const data = await res.json();
    return data.results ?? data;
  } catch {
    return [];
  }
}

export default async function ProjectsPage() {
  const projects = await fetchCaseStudies();

  return (
    <>
      {/* Hero */}
      <section className="relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-b from-primary/[0.03] via-background to-background" />
        <div className="absolute -top-24 left-1/2 h-80 w-80 -translate-x-1/2 rounded-full bg-primary/[0.04] blur-3xl" />

        <div className="relative mx-auto max-w-5xl px-4 pt-16 pb-12 md:pt-24">
          <div className="text-center">
            <span className="mb-6 inline-flex items-center gap-2 rounded-full border border-primary/20 bg-primary/5 px-4 py-1.5 text-xs font-medium text-primary">
              پروژه‌ها
            </span>
            <h1 className="text-3xl font-bold tracking-tight text-foreground sm:text-4xl">
              پروژه‌های ما
            </h1>
            <p className="mx-auto mt-4 max-w-lg text-sm text-muted-foreground sm:text-base">
              نمونه‌ای از پروژه‌های بازرسی انجام‌شده توسط تیم ادرو
            </p>
          </div>
        </div>
      </section>

      {/* Content */}
      <section className="mx-auto max-w-5xl px-4 pb-20">
        {projects.length === 0 ? (
          <div className="rounded-2xl border border-dashed border-border/60 py-20 text-center">
            <div className="mx-auto mb-4 flex size-14 items-center justify-center rounded-2xl bg-secondary text-muted-foreground/40">
              <FolderKanban className="size-7" />
            </div>
            <p className="text-sm text-muted-foreground">
              به‌زودی نمونه‌کارهای بیشتری اینجا منتشر می‌شود
            </p>
          </div>
        ) : (
          <div className="grid gap-5 sm:grid-cols-2">
            {projects.map((p) => (
              <div
                key={p.id}
                className="group rounded-2xl border border-border/60 bg-card p-6 transition-all hover:border-primary/30 hover:shadow-sm"
              >
                <div className="mb-4 flex size-11 items-center justify-center rounded-2xl bg-primary/10 text-primary transition-all group-hover:bg-primary group-hover:text-primary-foreground">
                  <FolderKanban className="size-5" strokeWidth={1.5} />
                </div>
                <h2 className="font-semibold text-foreground">{p.title}</h2>
                <p className="mt-2 line-clamp-3 text-sm leading-relaxed text-muted-foreground">
                  {p.summary}
                </p>
                {p.published_at && (
                  <span className="mt-3 inline-block text-xs text-muted-foreground">
                    {formatJalali(new Date(p.published_at))}
                  </span>
                )}
              </div>
            ))}
          </div>
        )}
      </section>
    </>
  );
}

// app/api/auth/login/route.ts
import { NextRequest, NextResponse } from "next/server";
import { setSessionTokens } from "@/lib/session";
import { getClientIpHeaders } from "@/lib/client-ip";

const API_BASE_URL = process.env.NEXT_PUBLIC_API_URL || "http://localhost:8000";

/**
 * POST /api/auth/login
 * ورودی: { phone, code } (تایید نهایی کد OTP)
 * بک‌اند جنگو access/refresh را برمی‌گرداند؛ اینجا آن‌ها را در کوکی
 * httpOnly ذخیره می‌کنیم و فقط اطلاعات کاربر (بدون خود توکن‌ها) را به
 * کلاینت برمی‌گردانیم.
 *
 * EDRA v27 — رفع باگ ریشه‌ای (گزارش کاربر، سپتامبر ۲۰۲۶):
 * شاخه‌ی قبلی «حالت توسعه» اینجا هرگز به بک‌اند وصل نمی‌شد؛ توکن‌های
 * access/refresh ساختگی (رشته‌ی متنی، نه JWT واقعی) در کوکی می‌گذاشت و
 * همیشه یک کاربر ثابت با is_staff=false/is_superuser=false برمی‌گرداند.
 * نتیجه در عمل: هر صفحه‌ی داشبورد که به بک‌اند واقعی fetch می‌زد با ۴۰۱
 * مواجه می‌شد (چون توکن جعلی بود) و کاربر هرگز با نقش واقعی خودش
 * (ادمین/کارشناس) وارد نمی‌شد — این دقیقاً همان چیزی است که به‌صورت
 * «ورود موفق ولی ریدایرکت نمی‌شود» و «تقریباً همه صفحات خراب‌اند» حس
 * می‌شد. کد ثابت ۲۴۶۸۱۰ حذف نشده — دقیقاً طبق خواسته‌ی شما فعال می‌ماند،
 * ولی حالا فقط در بک‌اند (که از قبل امن و قفل‌شده است) بررسی می‌شود، پس
 * توکن واقعی و نقش واقعی برمی‌گردد.
 */
export async function POST(request: NextRequest) {
  const body = await request.json();

  let res: Response;
  try {
    res = await fetch(`${API_BASE_URL}/api/core/otp/verify/`, {
      method: "POST",
      headers: { "Content-Type": "application/json", ...(await getClientIpHeaders()) },
      body: JSON.stringify(body),
      cache: "no-store",
    });
  } catch {
    return NextResponse.json(
      { detail: "ارتباط با سرور برقرار نشد. لطفاً دوباره تلاش کنید." },
      { status: 502 }
    );
  }

  let data: any;
  try {
    data = await res.json();
  } catch {
    return NextResponse.json(
      { detail: "پاسخ نامعتبر از سرور. لطفاً دوباره تلاش کنید یا با پشتیبانی تماس بگیرید." },
      { status: 502 }
    );
  }

  if (!res.ok) {
    return NextResponse.json(data, { status: res.status });
  }

  const { access, refresh, user, is_new } = data;
  if (!access || !refresh) {
    return NextResponse.json(
      { detail: "پاسخ نامعتبر از سرور احراز هویت" },
      { status: 502 }
    );
  }

  await setSessionTokens(access, refresh);

  return NextResponse.json({ user, is_new });
}
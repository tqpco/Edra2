// app/api/auth/otp-request/route.ts
import { NextRequest, NextResponse } from "next/server";
import { getClientIpHeaders } from "@/lib/client-ip";

const API_BASE_URL = process.env.NEXT_PUBLIC_API_URL || "http://localhost:8000";

// EDRA v27 — رفع باگ ریشه‌ای (گزارش کاربر، سپتامبر ۲۰۲۶):
// این مسیر قبلاً وقتی NODE_ENV==="development" بود، اصلاً به بک‌اند وصل
// نمی‌شد و مستقیم پاسخ ساختگی برمی‌گرداند. نتیجه: هیچ رکورد OTPCode
// واقعی ساخته نمی‌شد، پس مرحله‌ی verify (که به رکورد اخیر نیاز دارد)
// همیشه شکست می‌خورد یا کاربر ساختگی/بدون نقش واقعی برمی‌گشت. کد ثابت
// تست (۲۴۶۸۱۰) از قبل به‌صورت امن در خودِ بک‌اند پیاده‌سازی و قفل شده
// (DEV_OTP_ENABLED + DEV_OTP_ALLOWED_PHONES + کرش در production) —
// نیازی به این کپی‌ی ناامن‌تر در فرانت‌اند نبوده و حذف شد. رفتار «تایپ
// ۲۴۶۸۱۰ برای ورود آسان» دقیقاً همان‌طور که خواسته‌اید کار می‌کند، فقط
// حالا واقعاً از طریق بک‌اند و با نقش/کاربر واقعی.
export async function POST(request: NextRequest) {
  const body = await request.json();

  let res: Response;
  try {
    res = await fetch(`${API_BASE_URL}/api/core/otp/request/`, {
      method: "POST",
      headers: { "Content-Type": "application/json", ...(await getClientIpHeaders()) },
      body: JSON.stringify(body),
      cache: "no-store",
    });
  } catch {
    return NextResponse.json(
      { detail: "ارتباط با سرور برقرار نشد. لطفاً دوباره تلاش کنید." },
      { status: 502 }
    );
  }

  try {
    const data = await res.json();
    return NextResponse.json(data, { status: res.status });
  } catch {
    return NextResponse.json(
      { detail: "پاسخ نامعتبر از سرور. لطفاً دوباره تلاش کنید یا با پشتیبانی تماس بگیرید." },
      { status: 502 }
    );
  }
}
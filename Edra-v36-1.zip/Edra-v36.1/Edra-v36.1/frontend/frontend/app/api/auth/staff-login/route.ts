import { NextRequest, NextResponse } from "next/server";
import { setSessionTokens, clearSessionTokens } from "@/lib/session";
import { apiServerFetch } from "@/lib/api-server";
import type { User } from "@/types/user";
import { getClientIpHeaders } from "@/lib/client-ip";

const API_BASE_URL = process.env.NEXT_PUBLIC_API_URL || "http://localhost:8000";

/**
 * POST /api/auth/staff-login
 * ورودی: { username, password } - برای ادمین و کارشناس (حساب‌هایی که
 * از قبل توسط مدیر ساخته شده‌اند، بدون ثبت‌نام آزاد).
 */
export async function POST(request: NextRequest) {
  const body = await request.json();

  // EDRA v25 — root-cause فیکس «ارتباط با سرور برقرار نشد»: قبلاً res.json()
  // قبل از چک res.ok صدا زده می‌شد و کل fetch بدون try/catch بود. اگر
  // بک‌اند در دسترس نبود (fetch خودش throw می‌کند) یا پاسخ غیر-JSON برمی‌گرداند
  // (مثلاً صفحه‌ی خطای HTML جنگو) — res.json() یک SyntaxError می‌داد که هیچ‌جا
  // catch نمی‌شد؛ نتیجه یک 500 کلی از خودِ Next.js بود که در کلاینت به‌صورت
  // «ارتباط با سرور برقرار نشد، دوباره تلاش کنید» دیده می‌شد و ریشه‌ی واقعی
  // (که همیشه هم مشکل شبکه نبود) را مخفی می‌کرد.
  let res: Response;
  try {
    res = await fetch(`${API_BASE_URL}/api/token/`, {
      method: "POST",
      headers: { "Content-Type": "application/json", ...(await getClientIpHeaders()) },
      body: JSON.stringify(body),
      cache: "no-store",
    });
  } catch {
    return NextResponse.json(
      { detail: "ارتباط با سرور برقرار نشد. لطفاً دوباره تلاش کنید." },
      { status: 502 }
    );
  }

  let data: any;
  try {
    data = await res.json();
  } catch {
    // پاسخ سرور JSON معتبر نبود (مثلاً صفحه‌ی خطای HTML/۵۰۰ خودِ جنگو)
    return NextResponse.json(
      { detail: "پاسخ نامعتبر از سرور. لطفاً دوباره تلاش کنید یا با پشتیبانی تماس بگیرید." },
      { status: 502 }
    );
  }

  if (!res.ok) {
    return NextResponse.json(
      { detail: "نام کاربری یا رمز عبور اشتباه است." },
      { status: res.status }
    );
  }

  const { access, refresh } = data;

  // توکن‌ها را ذخیره می‌کنیم تا /api/core/users/me/ بتواند احراز هویت کند؛
  // اگر دسترسی نامعتبر بود، بلافاصله پاک می‌شوند.
  await setSessionTokens(access, refresh);
  try {
    const user = await apiServerFetch<User>("/api/core/users/me/");
    if (!user.is_staff && !user.groups?.includes("Expert")) {
      // دسترسی غیرمجاز: توکن‌هایی که همین الان ست شدند را پاک کن تا
      // کوکی‌های بی‌استفاده/نیمه‌معتبر روی مرورگر باقی نمانند
      await clearSessionTokens();
      return NextResponse.json(
        { detail: "این حساب دسترسی به پنل مدیریت/کارشناسی ندارد." },
        { status: 403 }
      );
    }
    return NextResponse.json({ user });
  } catch {
    await clearSessionTokens();
    return NextResponse.json(
      { detail: "خطا در دریافت اطلاعات کاربر" },
      { status: 502 }
    );
  }
}

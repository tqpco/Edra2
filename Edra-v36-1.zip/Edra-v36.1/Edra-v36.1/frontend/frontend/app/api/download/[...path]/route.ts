/**
 * app/api/download/[...path]/route.ts
 * برای دانلود فایل‌های باینری (خروجی اکسل گزارش‌ها، PDF و ...) - برخلاف
 * /api/proxy که پاسخ را JSON فرض می‌کند، این مسیر بدنه‌ی پاسخ را عیناً
 * (باینری) پاس می‌دهد.
 */
import { NextRequest, NextResponse } from "next/server";
import {
  getAccessToken,
  refreshAccessToken,
} from "@/lib/session";
import { getClientIpHeaders } from "@/lib/client-ip";

const API_BASE_URL = process.env.NEXT_PUBLIC_API_URL || "http://localhost:8000";

export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ path: string[] }> }
) {
  const { path } = await params;
  // EDRA v6 — P0: trailing slash حفظ می‌شود (جلوگیری از 301 در دانلودها)
  const joined = path.join("/");
  const trailing = request.nextUrl.pathname.endsWith("/") ? "/" : "";
  const targetPath = `/api/${joined}${trailing}${request.nextUrl.search}`;
  const token = await getAccessToken();
  const clientIpHeaders = await getClientIpHeaders();

  // EDRA v25 — root-cause فیکس: مثل auth routes، اگر بک‌اند در دسترس نبود
  // fetch خودش throw می‌کرد و هیچ‌جا catch نمی‌شد (۵۰۰ کلی Next.js به‌جای
  // پیام روشن «دانلود ناموفق بود»). این مسیر برای دانلود فایل‌های واقعی
  // (خروجی اکسل، فاکتور PDF، فیش واریزی) استفاده می‌شود، پس این ریسک را
  // هم مثل auth routes می‌بندیم.
  async function safeFetch(url: string, init?: RequestInit) {
    try {
      return await fetch(url, init);
    } catch {
      return null;
    }
  }

  // EDRA v8 — P1-12: دانلود هم مثل proxy باید refresh داشته باشد؛ اگر
  // access token منقضی شده باشد، یک‌بار refresh و retry می‌شود — در غیر
  // این صورت دانلود PDF/فیش برای کاربر بی‌دلیل با 401 شکست می‌خورد.
  let res = await safeFetch(`${API_BASE_URL}${targetPath}`, {
    headers: {
      ...clientIpHeaders,
      ...(token ? { Authorization: `Bearer ${token}` } : {}),
    },
  });

  if (!res) {
    return NextResponse.json(
      { detail: "ارتباط با سرور برقرار نشد. لطفاً دوباره تلاش کنید." },
      { status: 502 }
    );
  }

  if (res.status === 401 && token) {
    // P1 (EDRA v9): refresh single-flight مشترک
    const newAccess = await refreshAccessToken();
    if (newAccess) {
      res = await safeFetch(`${API_BASE_URL}${targetPath}`, {
        headers: { ...clientIpHeaders, Authorization: `Bearer ${newAccess}` },
      });
      if (!res) {
        return NextResponse.json(
          { detail: "ارتباط با سرور برقرار نشد. لطفاً دوباره تلاش کنید." },
          { status: 502 }
        );
      }
    }
  }

  if (!res.ok) {
    return NextResponse.json(
      { detail: "دانلود فایل ناموفق بود" },
      { status: res.status }
    );
  }

  const blob = await res.blob();
  return new NextResponse(blob, {
    headers: {
      "Content-Type":
        res.headers.get("content-type") || "application/octet-stream",
      "Content-Disposition": res.headers.get("content-disposition") || "attachment",
    },
  });
}

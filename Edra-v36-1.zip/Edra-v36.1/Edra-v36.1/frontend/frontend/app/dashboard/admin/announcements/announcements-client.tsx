"use client";

// EDRA v27 — قابلیت تازه (گزارش کاربر، سپتامبر ۲۰۲۶): اعلانیه‌های
// سیستمی در بک‌اند بود ولی رابط مدیریتی نداشت (و حین بررسی، یک باگ
// واقعی هم در ساختش پیدا و رفع شد — created_by هیچ‌وقت مقداردهی نمی‌شد).

import * as React from "react";
import { useRouter } from "next/navigation";
import { toast } from "sonner";
import { Plus, Pencil, Trash2, Megaphone } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import { apiClientFetch, ClientApiError } from "@/lib/api-client";

interface AnnouncementItem {
  id: number;
  title: string;
  content: string;
  audience: "all" | "customers" | "staff" | "admins";
  is_active?: boolean;
  expires_at_jalali?: string | null;
  created_at_jalali?: string;
}

const AUDIENCE_LABEL: Record<string, string> = {
  all: "همه",
  customers: "مشتریان",
  staff: "کارکنان",
  admins: "مدیران",
};

const EMPTY = { title: "", content: "", audience: "all" as const, is_active: true };

export function AnnouncementsClient({ announcements }: { announcements: AnnouncementItem[] }) {
  const router = useRouter();
  const [dialogOpen, setDialogOpen] = React.useState(false);
  const [editing, setEditing] = React.useState<AnnouncementItem | null>(null);
  const [form, setForm] = React.useState(EMPTY);
  const [saving, setSaving] = React.useState(false);
  const [deleteTarget, setDeleteTarget] = React.useState<AnnouncementItem | null>(null);
  const [deleting, setDeleting] = React.useState(false);

  function openCreate() {
    setEditing(null);
    setForm(EMPTY);
    setDialogOpen(true);
  }

  function openEdit(a: AnnouncementItem) {
    setEditing(a);
    setForm({ title: a.title, content: a.content, audience: a.audience, is_active: a.is_active ?? true });
    setDialogOpen(true);
  }

  async function submit() {
    if (!form.title.trim() || !form.content.trim()) {
      toast.error("عنوان و متن اعلانیه الزامی است.");
      return;
    }
    setSaving(true);
    try {
      const path = editing
        ? `/api/support/announcements/${editing.id}/`
        : `/api/support/announcements/`;
      await apiClientFetch(path, { method: editing ? "PATCH" : "POST", body: form });
      toast.success(editing ? "اعلانیه ویرایش شد." : "اعلانیه جدید منتشر شد.");
      setDialogOpen(false);
      router.refresh();
    } catch (err) {
      toast.error(err instanceof ClientApiError ? err.message : "خطا در ذخیره‌سازی.");
    } finally {
      setSaving(false);
    }
  }

  async function confirmDelete() {
    if (!deleteTarget) return;
    setDeleting(true);
    try {
      await apiClientFetch(`/api/support/announcements/${deleteTarget.id}/`, { method: "DELETE" });
      toast.success("اعلانیه حذف شد.");
      setDeleteTarget(null);
      router.refresh();
    } catch (err) {
      toast.error(err instanceof ClientApiError ? err.message : "خطا در حذف.");
    } finally {
      setDeleting(false);
    }
  }

  return (
    <>
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="text-2xl font-semibold">اعلانیه‌های سیستمی</h1>
          <p className="text-muted-foreground text-sm">پیام‌های عمومی برای مشتریان/کارکنان</p>
        </div>
        <Button onClick={openCreate}>
          <Plus className="size-4" />
          اعلانیه جدید
        </Button>
      </div>

      <Card>
        <CardContent className="px-0 py-2">
          {announcements.length === 0 ? (
            <p className="text-muted-foreground py-10 text-center text-sm">
              <Megaphone className="mx-auto mb-2 size-8 opacity-40" />
              اعلانیه‌ای ثبت نشده است
            </p>
          ) : (
            <div className="flex flex-col divide-y">
              {announcements.map((a) => (
                <div key={a.id} className="flex items-start justify-between gap-3 px-5 py-4">
                  <div className="min-w-0">
                    <div className="flex items-center gap-2">
      <span className="text-sm font-medium">{a.title}</span>
                      <Badge variant="outline">{AUDIENCE_LABEL[a.audience]}</Badge>
                      {a.is_active === false && (
                        <Badge variant="secondary" className="text-muted-foreground">
                          غیرفعال
                        </Badge>
                      )}
                    </div>
                    <p className="text-muted-foreground mt-1 line-clamp-2 text-xs">{a.content}</p>
                  </div>
                  <div className="flex shrink-0 items-center gap-1">
                    <Button variant="ghost" size="icon" className="size-8" onClick={() => openEdit(a)}>
                      <Pencil className="size-3.5" />
                    </Button>
                    <Button
                      variant="ghost"
                      size="icon"
                      className="text-destructive size-8"
                      onClick={() => setDeleteTarget(a)}
                    >
                      <Trash2 className="size-3.5" />
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>{editing ? "ویرایش اعلانیه" : "اعلانیه جدید"}</DialogTitle>
          </DialogHeader>
          <div className="flex flex-col gap-4">
            <div className="grid gap-1.5">
              <Label htmlFor="ann-title">عنوان</Label>
              <Input
                id="ann-title"
                value={form.title}
                onChange={(e) => setForm({ ...form, title: e.target.value })}
              />
            </div>
            <div className="grid gap-1.5">
              <Label>مخاطب</Label>
              <Select
                value={form.audience}
                onValueChange={(v) => setForm({ ...form, audience: v as AnnouncementItem["audience"] })}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">همه</SelectItem>
                  <SelectItem value="customers">مشتریان</SelectItem>
                  <SelectItem value="staff">کارکنان</SelectItem>
                  <SelectItem value="admins">مدیران</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="grid gap-1.5">
              <Label htmlFor="ann-content">متن</Label>
              <Textarea
                id="ann-content"
                rows={4}
                value={form.content}
                onChange={(e) => setForm({ ...form, content: e.target.value })}
              />
            </div>
            {/* EDRA v32: قبلاً هیچ کنترلی برای فعال/غیرفعال‌کردن در این فرم
                نبود؛ همراه با رفع باگ بک‌اند (که اعلانیه‌ی غیرفعال را از
                دید خودِ ادمین هم برای همیشه پنهان می‌کرد) اضافه شد. */}
            <div className="flex items-center justify-between gap-4 pt-1">
              <Label htmlFor="ann-active">فعال (در لیست عمومی نمایش داده شود)</Label>
              <Switch
                id="ann-active"
                checked={form.is_active}
                onCheckedChange={(v) => setForm({ ...form, is_active: v })}
              />
            </div>
          </div>
          <div className="flex justify-end gap-2">
            <Button variant="outline" onClick={() => setDialogOpen(false)}>
              انصراف
            </Button>
            <Button onClick={submit} disabled={saving}>
              {saving ? "در حال ذخیره..." : "ذخیره"}
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      <Dialog open={Boolean(deleteTarget)} onOpenChange={(o) => !o && setDeleteTarget(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>حذف «{deleteTarget?.title}»</DialogTitle>
            <DialogDescription>این عملیات قابل بازگشت نیست.</DialogDescription>
          </DialogHeader>
          <div className="flex justify-end gap-2">
            <Button variant="outline" onClick={() => setDeleteTarget(null)}>
              انصراف
            </Button>
            <Button variant="destructive" onClick={confirmDelete} disabled={deleting}>
              {deleting ? "در حال حذف..." : "حذف"}
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
}

import { apiServerFetch } from "@/lib/api-server";
import { AnnouncementsClient } from "./announcements-client";

export const metadata = { title: "اعلانیه‌ها" };

interface AnnouncementItem {
  id: number;
  title: string;
  content: string;
  audience: "all" | "customers" | "staff" | "admins";
  is_active?: boolean;
}

export default async function AdminAnnouncementsPage() {
  const data = await apiServerFetch<{ results: AnnouncementItem[] } | AnnouncementItem[]>(
    `/api/support/announcements/?page_size=200`
  );
  const announcements = Array.isArray(data) ? data : data.results ?? [];

  return (
    <div className="flex flex-col gap-6">
      <AnnouncementsClient announcements={announcements} />
    </div>
  );
}

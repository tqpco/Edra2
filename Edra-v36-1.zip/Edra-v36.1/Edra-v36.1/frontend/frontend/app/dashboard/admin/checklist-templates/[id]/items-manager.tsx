"use client";

import * as React from "react";
import {
  Plus, Pencil, Trash2, ChevronUp, ChevronDown, Loader2,
  Camera, FileText, AlertTriangle, ListChecks,
} from "lucide-react";
import { toast } from "sonner";
import { apiClientFetch, ClientApiError } from "@/lib/api-client";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { ChecklistExcelImport } from "../checklist-excel-import";

export interface AdminChecklistItem {
  id: number;
  checklist_template: number;
  category: string;
  title: string;
  description: string;
  order: number;
  requires_photo: boolean;
  requires_note: boolean;
  is_critical: boolean;
  is_active: boolean;
}

interface ItemFormState {
  id: number | null;
  category: string;
  title: string;
  description: string;
  requires_photo: boolean;
  requires_note: boolean;
  is_critical: boolean;
}

const EMPTY_FORM: ItemFormState = {
  id: null,
  category: "",
  title: "",
  description: "",
  requires_photo: false,
  requires_note: false,
  is_critical: false,
};

/**
 * EDRA v25 — جدید: بازنویسی کامل بخش «آیتم‌های چک‌لیست».
 *
 * قبلاً هیچ رابط کاربری برای افزودن/ویرایش/حذف/تغییرِ ترتیب یک آیتم به‌صورت
 * تکی وجود نداشت — تنها راه، ایمپورت گروهی اکسل بود (که خودش هم به‌خاطر
 * مخفی‌بودن پشت یک شرط، در حالت «بدون قالب» اصلاً دیده نمی‌شد). این
 * کامپوننت یک مدیریت کامل می‌سازد: گروه‌بندی بر اساس دسته (آکاردئون با
 * <details> بومی — بدون وابستگی جدید)، افزودن/ویرایش/حذف تکی، و
 * جابه‌جایی ترتیب با دکمه‌های بالا/پایین (به‌جای drag-and-drop، چون در
 * این محیط امکان افزودن و تستِ یک کتابخانه‌ی DnD جدید نبود — این نسخه
 * بدون هیچ وابستگی جدید و کاملاً قابل‌اعتماد کار می‌کند).
 */
export function ChecklistItemsManager({
  templateId,
  templateName,
  initialItems,
}: {
  templateId: number;
  templateName: string;
  initialItems: AdminChecklistItem[];
}) {
  const [items, setItems] = React.useState<AdminChecklistItem[]>(
    [...initialItems].sort((a, b) => a.order - b.order)
  );
  const [dialogOpen, setDialogOpen] = React.useState(false);
  const [form, setForm] = React.useState<ItemFormState>(EMPTY_FORM);
  const [saving, setSaving] = React.useState(false);
  const [busyId, setBusyId] = React.useState<number | null>(null);

  const categories = React.useMemo(() => {
    const map = new Map<string, AdminChecklistItem[]>();
    for (const item of items) {
      if (!map.has(item.category)) map.set(item.category, []);
      map.get(item.category)!.push(item);
    }
    return Array.from(map.entries());
  }, [items]);

  const existingCategories = React.useMemo(
    () => Array.from(new Set(items.map((i) => i.category))).sort(),
    [items]
  );

  const sortedForIndex = React.useMemo(
    () => [...items].sort((a, b) => a.order - b.order),
    [items]
  );

  function openCreate(presetCategory?: string) {
    setForm({ ...EMPTY_FORM, category: presetCategory ?? "" });
    setDialogOpen(true);
  }

  function openEdit(item: AdminChecklistItem) {
    setForm({
      id: item.id,
      category: item.category,
      title: item.title,
      description: item.description,
      requires_photo: item.requires_photo,
      requires_note: item.requires_note,
      is_critical: item.is_critical,
    });
    setDialogOpen(true);
  }

  function errorMessage(err: unknown, fallback: string): string {
    if (err instanceof ClientApiError) {
      const data = err.data as
        | { detail?: string; title?: string[]; category?: string[] }
        | undefined;
      return data?.detail || data?.title?.[0] || data?.category?.[0] || fallback;
    }
    return fallback;
  }

  async function handleSave() {
    const category = form.category.trim();
    const title = form.title.trim();
    if (!category) {
      toast.warning("دسته‌بندی الزامی است");
      return;
    }
    if (!title) {
      toast.warning("عنوان الزامی است");
      return;
    }

    setSaving(true);
    try {
      if (form.id) {
        const updated = await apiClientFetch<AdminChecklistItem>(
          `/api/inspections/checklist-items/${form.id}/`,
          {
            method: "PATCH",
            body: {
              category,
              title,
              description: form.description.trim(),
              requires_photo: form.requires_photo,
              requires_note: form.requires_note,
              is_critical: form.is_critical,
            },
          }
        );
        setItems((prev) => prev.map((i) => (i.id === updated.id ? updated : i)));
        toast.success("آیتم بروزرسانی شد");
      } else {
        const created = await apiClientFetch<AdminChecklistItem>(
          `/api/inspections/checklist-items/`,
          {
            method: "POST",
            body: {
              checklist_template: templateId,
              category,
              title,
              description: form.description.trim(),
              requires_photo: form.requires_photo,
              requires_note: form.requires_note,
              is_critical: form.is_critical,
            },
          }
        );
        setItems((prev) => [...prev, created].sort((a, b) => a.order - b.order));
        toast.success("آیتم اضافه شد");
      }
      setDialogOpen(false);
    } catch (err) {
      toast.error(errorMessage(err, "ذخیره ناموفق بود"));
    } finally {
      setSaving(false);
    }
  }

  async function handleDelete(item: AdminChecklistItem) {
    if (!window.confirm(`آیتم «${item.title}» حذف شود؟`)) return;
    setBusyId(item.id);
    try {
      await apiClientFetch(`/api/inspections/checklist-items/${item.id}/`, {
        method: "DELETE",
      });
      setItems((prev) => prev.filter((i) => i.id !== item.id));
      toast.success("آیتم حذف شد");
    } catch (err) {
      toast.error(errorMessage(err, "حذف ناموفق بود"));
    } finally {
      setBusyId(null);
    }
  }

  async function handleMove(item: AdminChecklistItem, direction: "up" | "down") {
    const idx = sortedForIndex.findIndex((i) => i.id === item.id);
    const swapIdx = direction === "up" ? idx - 1 : idx + 1;
    if (swapIdx < 0 || swapIdx >= sortedForIndex.length) return;
    const neighbor = sortedForIndex[swapIdx];
    // اگر neighbor وجود نداشت، از تابع خارج شو
    if (!neighbor) return;

    setBusyId(item.id);
    const newOrderForItem = neighbor.order;
    const newOrderForNeighbor = item.order;
    // به‌روزرسانی خوش‌بینانه (optimistic) برای حس فوری بودن در UI
    setItems((prev) =>
      prev.map((i) => {
        if (i.id === item.id) return { ...i, order: newOrderForItem };
        if (i.id === neighbor.id) return { ...i, order: newOrderForNeighbor };
        return i;
      })
    );
    try {
      await apiClientFetch(
        `/api/inspections/checklist-templates/${templateId}/reorder-items/`,
        {
          method: "POST",
          body: {
            order: [
              { id: item.id, order: newOrderForItem },
              { id: neighbor.id, order: newOrderForNeighbor },
            ],
          },
        }
      );
    } catch (err) {
      // برگرداندن تغییر محلی چون سرور آن را نپذیرفت
      setItems((prev) =>
        prev.map((i) => {
          if (i.id === item.id) return { ...i, order: item.order };
          if (i.id === neighbor.id) return { ...i, order: neighbor.order };
          return i;
        })
      );
      toast.error(errorMessage(err, "تغییر ترتیب ذخیره نشد"));
    } finally {
      setBusyId(null);
    }
  }

  return (
    <div className="flex flex-col gap-6">
      <ChecklistExcelImport templates={[{ id: templateId, name: templateName }]} />

      <div className="flex items-center justify-between">
        <h2 className="text-lg font-semibold">آیتم‌های چک‌لیست ({items.length})</h2>
        <Button type="button" onClick={() => openCreate()}>
          <Plus className="size-4" />
          افزودن آیتم جدید
        </Button>
      </div>

      {categories.length === 0 && (
        <Card>
          <CardContent className="text-muted-foreground flex flex-col items-center gap-2 py-12 text-center text-sm">
            <ListChecks className="size-8 opacity-40" />
            هنوز هیچ آیتمی در این قالب ثبت نشده است.
            <Button
              type="button"
              size="sm"
              variant="outline"
              onClick={() => openCreate()}
              className="mt-2"
            >
              <Plus className="size-4" />
              افزودن اولین آیتم
            </Button>
          </CardContent>
        </Card>
      )}

      {categories.map(([category, categoryItems]) => (
        <details key={category} open className="group rounded-xl border bg-card">
          <summary className="flex cursor-pointer list-none items-center justify-between gap-3 px-5 py-3.5 select-none">
            <div className="flex items-center gap-2.5">
              <ChevronDown className="text-muted-foreground size-4 shrink-0 transition-transform group-open:rotate-180" />
              <span className="font-medium">{category}</span>
              <Badge variant="muted">{categoryItems.length} آیتم</Badge>
            </div>
            <span
              role="button"
              tabIndex={0}
              onClick={(e) => {
                e.preventDefault();
                e.stopPropagation();
                openCreate(category);
              }}
              className="text-muted-foreground hover:text-foreground inline-flex items-center gap-1 text-xs"
            >
              <Plus className="size-3.5" />
              آیتم در این دسته
            </span>
          </summary>
          <div className="flex flex-col divide-y border-t">
            {categoryItems
              .sort((a, b) => a.order - b.order)
              .map((item) => {
                const globalIdx = sortedForIndex.findIndex((i) => i.id === item.id);
                return (
                  <div key={item.id} className="flex items-start gap-3 px-5 py-3.5">
                    <div className="flex flex-col gap-0.5 pt-0.5">
                      <button
                        type="button"
                        disabled={globalIdx === 0 || busyId === item.id}
                        onClick={() => handleMove(item, "up")}
                        className="text-muted-foreground hover:text-foreground disabled:opacity-25"
                        aria-label="جابه‌جایی به بالا"
                      >
                        <ChevronUp className="size-4" />
                      </button>
                      <button
                        type="button"
                        disabled={globalIdx === sortedForIndex.length - 1 || busyId === item.id}
                        onClick={() => handleMove(item, "down")}
                        className="text-muted-foreground hover:text-foreground disabled:opacity-25"
                        aria-label="جابه‌جایی به پایین"
                      >
                        <ChevronDown className="size-4" />
                      </button>
                    </div>
                    <div className="min-w-0 flex-1">
                      <div className="flex flex-wrap items-center gap-1.5">
                        <p className="font-medium">{item.title}</p>
                        {item.is_critical && (
                          <Badge className="bg-destructive/10 text-destructive gap-1 hover:bg-destructive/10">
                            <AlertTriangle className="size-3" />
                            حیاتی
                          </Badge>
                        )}
                        {item.requires_photo && (
                          <Badge variant="outline" className="gap-1">
                            <Camera className="size-3" />
                            عکس
                          </Badge>
                        )}
                        {item.requires_note && (
                          <Badge variant="outline" className="gap-1">
                            <FileText className="size-3" />
                            یادداشت
                          </Badge>
                        )}
                      </div>
                      {item.description && (
                        <p className="text-muted-foreground mt-0.5 text-xs">
                          {item.description}
                        </p>
                      )}
                    </div>
                    <div className="flex shrink-0 items-center gap-1">
                      <Button
                        type="button"
                        variant="ghost"
                        size="icon"
                        onClick={() => openEdit(item)}
                        aria-label="ویرایش"
                      >
                        <Pencil className="size-4" />
                      </Button>
                      <Button
                        type="button"
                        variant="ghost"
                        size="icon"
                        disabled={busyId === item.id}
                        onClick={() => handleDelete(item)}
                        className="text-destructive hover:text-destructive"
                        aria-label="حذف"
                      >
                        {busyId === item.id ? (
                          <Loader2 className="size-4 animate-spin" />
                        ) : (
                          <Trash2 className="size-4" />
                        )}
                      </Button>
                    </div>
                  </div>
                );
              })}
          </div>
        </details>
      ))}

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle>{form.id ? "ویرایش آیتم" : "آیتم جدید"}</DialogTitle>
            <DialogDescription>
              این آیتم در چک‌لیست «{templateName}» نمایش داده می‌شود.
            </DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-2">
            <div className="grid gap-1.5">
              <Label htmlFor="item-category">دسته‌بندی</Label>
              <Input
                id="item-category"
                list="existing-categories"
                value={form.category}
                onChange={(e) => setForm((f) => ({ ...f, category: e.target.value }))}
                placeholder="مثلاً: سازه فلزی"
              />
              <datalist id="existing-categories">
                {existingCategories.map((c) => (
                  <option key={c} value={c} />
                ))}
              </datalist>
            </div>
            <div className="grid gap-1.5">
              <Label htmlFor="item-title">عنوان</Label>
              <Input
                id="item-title"
                value={form.title}
                onChange={(e) => setForm((f) => ({ ...f, title: e.target.value }))}
                placeholder="مثلاً: بررسی سلامت جوش‌های اتصال"
              />
            </div>
            <div className="grid gap-1.5">
              <Label htmlFor="item-description">توضیحات (اختیاری)</Label>
              <Textarea
                id="item-description"
                value={form.description}
                onChange={(e) => setForm((f) => ({ ...f, description: e.target.value }))}
                rows={3}
              />
            </div>
            <div className="flex flex-col gap-2.5">
              <label className="flex items-center gap-2 text-sm">
                <input
                  type="checkbox"
                  className="accent-primary size-4"
                  checked={form.requires_photo}
                  onChange={(e) =>
                    setForm((f) => ({ ...f, requires_photo: e.target.checked }))
                  }
                />
                نیاز به عکس دارد
              </label>
              <label className="flex items-center gap-2 text-sm">
                <input
                  type="checkbox"
                  className="accent-primary size-4"
                  checked={form.requires_note}
                  onChange={(e) =>
                    setForm((f) => ({ ...f, requires_note: e.target.checked }))
                  }
                />
                نیاز به یادداشت دارد
              </label>
              <label className="flex items-center gap-2 text-sm">
                <input
                  type="checkbox"
                  className="accent-destructive size-4"
                  checked={form.is_critical}
                  onChange={(e) =>
                    setForm((f) => ({ ...f, is_critical: e.target.checked }))
                  }
                />
                آیتم حیاتی (رد‌شدن یعنی رد کل بازرسی)
              </label>
            </div>
          </div>
          <div className="flex justify-end gap-2">
            <Button type="button" variant="outline" onClick={() => setDialogOpen(false)}>
              انصراف
            </Button>
            <Button type="button" onClick={handleSave} disabled={saving}>
              {saving && <Loader2 className="size-4 animate-spin" />}
              ذخیره
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
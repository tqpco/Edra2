import Link from "next/link";
import { notFound } from "next/navigation";
import { ArrowRight, ListChecks } from "lucide-react";
import { apiServerFetch } from "@/lib/api-server";
import { Badge } from "@/components/ui/badge";
import { ChecklistItemsManager, type AdminChecklistItem } from "./items-manager";

interface ChecklistTemplateDetail {
  id: number;
  name: string;
  description?: string;
  version?: string | number;
  is_active: boolean;
  equipment_type?: { id: number; name_fa: string } | number | null;
  items?: AdminChecklistItem[];
}

async function fetchTemplate(id: string): Promise<ChecklistTemplateDetail | null> {
  try {
    return await apiServerFetch<ChecklistTemplateDetail>(
      `/api/inspections/checklist-templates/${id}/`
    );
  } catch {
    return null;
  }
}

export async function generateMetadata({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = await params;
  const template = await fetchTemplate(id);
  return { title: template ? `مدیریت آیتم‌ها — ${template.name}` : "قالب چک‌لیست" };
}

export default async function ChecklistTemplateDetailPage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = await params;
  const template = await fetchTemplate(id);

  if (!template) {
    notFound();
  }

  const equipmentTypeName =
    typeof template.equipment_type === "object" && template.equipment_type
      ? template.equipment_type.name_fa
      : "همه تجهیزات";

  return (
    <div className="flex flex-col gap-6">
      <div>
        <Link
          href="/dashboard/admin/checklist-templates"
          className="text-muted-foreground hover:text-foreground mb-3 inline-flex items-center gap-1 text-sm"
        >
          <ArrowRight className="size-3.5" />
          بازگشت به قالب‌های چک‌لیست
        </Link>
        <div className="flex flex-wrap items-center gap-3">
          <span className="bg-primary/10 text-primary flex size-10 items-center justify-center rounded-lg">
            <ListChecks className="size-5" />
          </span>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-2xl font-semibold">{template.name}</h1>
              <Badge variant={template.is_active ? "success" : "muted"}>
                {template.is_active ? "فعال" : "غیرفعال"}
              </Badge>
            </div>
            <p className="text-muted-foreground text-sm">
              {equipmentTypeName}
              {template.version ? ` • نسخه ${template.version}` : ""}
            </p>
          </div>
        </div>
        {template.description && (
          <p className="text-muted-foreground mt-3 text-sm">{template.description}</p>
        )}
      </div>

      <ChecklistItemsManager
        templateId={template.id}
        templateName={template.name}
        initialItems={template.items ?? []}
      />
    </div>
  );
}

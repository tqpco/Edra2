"use client";

import * as React from "react";
import { useRouter } from "next/navigation";
import { Plus, Loader2 } from "lucide-react";
import { toast } from "sonner";
import { apiClientFetch, ClientApiError } from "@/lib/api-client";
import { Button } from "@/components/ui/button";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";

interface EquipmentTypeOption {
  id: number;
  name_fa: string;
}

/**
 * EDRA v25 — جدید: قبلاً هیچ راهی برای ساخت قالب چک‌لیست جز پنل ادمین جنگو
 * وجود نداشت (endpoint فقط GET بود). حالا با ModelViewSet کامل، از همین‌جا
 * هم می‌شود قالب ساخت.
 */
export function NewTemplateDialog() {
  const router = useRouter();
  const [open, setOpen] = React.useState(false);
  const [loadingTypes, setLoadingTypes] = React.useState(false);
  const [equipmentTypes, setEquipmentTypes] = React.useState<EquipmentTypeOption[]>([]);
  const [name, setName] = React.useState("");
  const [description, setDescription] = React.useState("");
  const [equipmentTypeId, setEquipmentTypeId] = React.useState<string>("");
  const [saving, setSaving] = React.useState(false);

  React.useEffect(() => {
    if (!open || equipmentTypes.length > 0) return;
    setLoadingTypes(true);
    apiClientFetch<{ results?: EquipmentTypeOption[] } | EquipmentTypeOption[]>(
      "/api/core/equipment-types/"
    )
      .then((data) => {
        const list = Array.isArray(data) ? data : data.results || [];
        setEquipmentTypes(list);
      })
      .catch(() => toast.error("دریافت لیست انواع تجهیزات ناموفق بود"))
      .finally(() => setLoadingTypes(false));
  }, [open, equipmentTypes.length]);

  async function handleCreate() {
    const trimmedName = name.trim();
    if (!trimmedName) {
      toast.warning("نام قالب الزامی است");
      return;
    }
    if (!equipmentTypeId) {
      toast.warning("نوع تجهیزات را انتخاب کنید");
      return;
    }
    setSaving(true);
    try {
      const created = await apiClientFetch<{ id: number }>(
        "/api/inspections/checklist-templates/",
        {
          method: "POST",
          body: {
            name: trimmedName,
            description: description.trim(),
            equipment_type: Number(equipmentTypeId),
            is_active: true,
          },
        }
      );
      toast.success("قالب ساخته شد");
      setOpen(false);
      setName("");
      setDescription("");
      setEquipmentTypeId("");
      router.push(`/dashboard/admin/checklist-templates/${created.id}`);
      router.refresh();
    } catch (err) {
      const data = err instanceof ClientApiError ? (err.data as Record<string, string[]>) : undefined;
      const firstError = data ? Object.values(data)[0]?.[0] : undefined;
      toast.error(firstError || "ساخت قالب ناموفق بود");
    } finally {
      setSaving(false);
    }
  }

  return (
    <>
      <Button type="button" onClick={() => setOpen(true)}>
        <Plus className="size-4" />
        قالب جدید
      </Button>

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>قالب چک‌لیست جدید</DialogTitle>
            <DialogDescription>
              بعد از ساخت، به صفحه‌ی مدیریت آیتم‌های همین قالب منتقل می‌شوید.
            </DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-2">
            <div className="grid gap-1.5">
              <Label htmlFor="template-name">نام قالب</Label>
              <Input
                id="template-name"
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="مثلاً: بازرسی جرثقیل برجی"
              />
            </div>
            <div className="grid gap-1.5">
              <Label htmlFor="template-equipment">نوع تجهیزات</Label>
              <Select value={equipmentTypeId} onValueChange={setEquipmentTypeId}>
                <SelectTrigger id="template-equipment">
                  <SelectValue
                    placeholder={loadingTypes ? "در حال بارگذاری..." : "انتخاب کنید"}
                  />
                </SelectTrigger>
                <SelectContent>
                  {equipmentTypes.map((et) => (
                    <SelectItem key={et.id} value={String(et.id)}>
                      {et.name_fa}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="grid gap-1.5">
              <Label htmlFor="template-description">توضیحات (اختیاری)</Label>
              <Textarea
                id="template-description"
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                rows={3}
              />
            </div>
          </div>
          <div className="flex justify-end gap-2">
            <Button type="button" variant="outline" onClick={() => setOpen(false)}>
              انصراف
            </Button>
            <Button type="button" onClick={handleCreate} disabled={saving}>
              {saving && <Loader2 className="size-4 animate-spin" />}
              ساخت قالب
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
}

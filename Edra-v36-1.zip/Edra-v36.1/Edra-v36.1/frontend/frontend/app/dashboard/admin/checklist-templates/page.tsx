// app/dashboard/admin/checklist-templates/page.tsx
import Link from "next/link";
import { ClipboardCheck, ListChecks, ChevronLeft } from "lucide-react";
import { fetchPaginated } from "@/lib/paginated-fetch";
import { Pagination } from "@/components/ui/pagination";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ChecklistExcelImport } from "./checklist-excel-import";
import { NewTemplateDialog } from "./new-template-dialog";

export const metadata = { title: "قالب‌های چک‌لیست" };

interface ChecklistTemplateItem {
  id: number;
  name: string;
  description?: string;
  version?: string;
  is_active: boolean;
  equipment_type?: { id: number; name_fa: string } | number | null;
  // EDRA v5 — MEDIUM-26: items_count از backend (بدون N+1)
  items_count?: number;
}

async function fetchTemplates(page: number) {
  return fetchPaginated<ChecklistTemplateItem>(`/api/inspections/checklist-templates/`, page);
}

export default async function AdminChecklistTemplatesPage({ searchParams }: { searchParams: Promise<{ page?: string }> }) {
  const _page = Math.max(1, Number((await searchParams).page) || 1);
  const { items: templates, count } = await fetchTemplates(_page);

  return (
    <div className="flex flex-col gap-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="text-2xl font-semibold">قالب‌های چک‌لیست بازرسی</h1>
          <p className="text-muted-foreground text-sm">
            قالب‌های استاندارد بازرسی به تفکیک نوع تجهیزات
          </p>
        </div>
        <NewTemplateDialog />
      </div>

      {/* FEATURE: ایمپورت آیتم‌ها از فایل Excel
          EDRA v25 — root-cause فیکس: قبلاً این کارت پشت شرط
          templates.length > 0 مخفی بود، یعنی در یک نصب تازه یا وقتی همه‌ی
          قالب‌ها پاک شده بودند، کاربر اصلاً نمی‌دانست این قابلیت وجود دارد
          (و از نگاه او، انگار «وجود ندارد»). حالا همیشه نمایش داده می‌شود؛
          اگر قالبی نباشد، خودِ کامپوننت راهنمایی روشن می‌دهد. */}
      <ChecklistExcelImport
        templates={templates.map((t) => ({ id: t.id, name: t.name }))}
      />

      <div className="grid gap-4">
        {templates.length === 0 && (
          <Card>
            <CardContent className="text-muted-foreground py-10 text-center text-sm">
              <ClipboardCheck className="mx-auto mb-2 size-8 opacity-40" />
              هنوز قالبی ثبت نشده — از دکمه «قالب جدید» بالا شروع کنید
            </CardContent>
          </Card>
        )}

        {templates.map((t) => (
          <Link key={t.id} href={`/dashboard/admin/checklist-templates/${t.id}`}>
            <Card className="hover:border-primary/40 hover:bg-accent/30 transition-colors">
              <CardContent className="flex items-center justify-between gap-3 px-5 py-4">
                <div className="flex items-center gap-3">
                  <span className="bg-primary/10 text-primary flex size-9 items-center justify-center rounded-lg">
                    <ListChecks className="size-4" />
                  </span>
                  <div>
                    <div className="flex items-center gap-2">
                      <p className="font-medium">{t.name}</p>
                      {/* ✅ اصلاح: استفاده از variant="outline" + className */}
                      <Badge
                        variant="outline"
                        className={
                          t.is_active
                            ? "border-green-500 text-green-700 bg-green-50"
                            : "border-gray-300 text-gray-500 bg-gray-50"
                        }
                      >
                        {t.is_active ? "فعال" : "غیرفعال"}
                      </Badge>
                    </div>
                    <p className="text-muted-foreground text-xs">
                      {typeof t.equipment_type === "object" && t.equipment_type
                        ? (t.equipment_type as { name_fa: string }).name_fa
                        : "همه تجهیزات"}
                      {t.version ? ` • نسخه ${t.version}` : ""} •{" "}
                      {t.items_count ?? 0} آیتم
                    </p>
                  </div>
                </div>
                <ChevronLeft className="text-muted-foreground size-4 shrink-0" />
              </CardContent>
            </Card>
          </Link>
        ))}
      </div>
          <Pagination current={_page} totalItems={count} basePath="/dashboard/admin/checklist-templates" />
</div>
  );
}
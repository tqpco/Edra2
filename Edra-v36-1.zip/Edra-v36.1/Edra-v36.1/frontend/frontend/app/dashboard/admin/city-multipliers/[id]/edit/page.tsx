// app/dashboard/admin/city-multipliers/[id]/edit/page.tsx
"use client";

import { useState, useEffect } from "react";
import { useRouter, useParams } from "next/navigation";
import { Save, X, Trash2, History, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { toast } from "sonner";
import { parseApiError } from "@/lib/form-errors";
import { toPersianDigits, formatPrice } from "@/lib/utils";

interface CityMultiplier {
  id: number;
  city: string;
  base_cost: number;
  multiplier: number;
  is_active: boolean;
  order: number;
}

interface HistoryItem {
  id: number;
  field: string;
  old_value: string;
  new_value: string;
  changed_at: string;
  changed_by: string;
}

export default function EditCityMultiplierPage() {
  const router = useRouter();
  const params = useParams();
  const id = params.id as string;

  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [item, setItem] = useState<CityMultiplier | null>(null);
  const [formData, setFormData] = useState({
    city: "",
    base_cost: "",
    multiplier: "1.00",
    is_active: true,
  });
  const [history, setHistory] = useState<HistoryItem[]>([]);
  const [historyDialogOpen, setHistoryDialogOpen] = useState(false);

  useEffect(() => {
    const fetchItem = async () => {
      try {
        setLoading(true);
        const res = await fetch(`/api/proxy/core/city-multipliers/${id}/`);
        if (!res.ok) throw new Error("خطا در دریافت اطلاعات");
        const data = await res.json();
        setItem(data);
        setFormData({
          city: data.city,
          base_cost: String(data.base_cost || 900000),
          multiplier: String(data.multiplier),
          is_active: data.is_active,
        });

        try {
          const historyRes = await fetch(`/api/proxy/core/city-multipliers/${id}/history/`);
          if (historyRes.ok) {
            const historyData = await historyRes.json();
            setHistory(Array.isArray(historyData) ? historyData : []);
          }
        } catch {
          // سکوت
        }
      } catch (error) {
        toast.error("خطا در دریافت اطلاعات ضریب شهر");
        router.push("/dashboard/admin/city-multipliers");
      } finally {
        setLoading(false);
      }
    };

    if (id) fetchItem();
  }, [id, router]);

  const baseCost = parseFloat(formData.base_cost) || 0;
  const multiplier = parseFloat(formData.multiplier) || 0;
  const finalCost = baseCost * multiplier;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    try {
      const payload = {
        city: formData.city.trim(),
        base_cost: baseCost,
        multiplier: multiplier,
        is_active: formData.is_active,
      };

      const res = await fetch(`/api/proxy/core/city-multipliers/${id}/`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });

      if (!res.ok) {
        const errData = await res.json().catch(() => ({}));
        throw new Error(parseApiError(errData, "خطا در ویرایش").message);
      }

      toast.success("ضریب شهر ویرایش شد");
      router.push("/dashboard/admin/city-multipliers");
      router.refresh();
    } catch (error: any) {
      toast.error(error.message || "خطا در ویرایش ضریب شهر");
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async () => {
    if (!confirm("آیا از حذف این ضریب شهر مطمئن هستید؟")) return;
    try {
      const res = await fetch(`/api/proxy/core/city-multipliers/${id}/`, {
        method: "DELETE",
      });
      if (!res.ok) throw new Error("خطا در حذف");
      toast.success("ضریب شهر حذف شد");
      router.push("/dashboard/admin/city-multipliers");
      router.refresh();
    } catch (error) {
      toast.error("خطا در حذف ضریب شهر");
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center p-12">
        <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
      </div>
    );
  }

  if (!item) {
    return (
      <div className="flex items-center justify-center p-12 text-muted-foreground">
        ضریب شهر یافت نشد.
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold">تغییر ضریب شهر</h1>
          <p className="text-muted-foreground text-sm">{item.city}</p>
        </div>
        <div className="flex gap-2">
          <Button
            variant="outline"
            onClick={() => setHistoryDialogOpen(true)}
            disabled={history.length === 0}
          >
            <History className="ml-2 h-4 w-4" />
            تاریخچه
          </Button>
          <Button variant="outline" onClick={() => router.back()}>
            <X className="ml-2 h-4 w-4" />
            انصراف
          </Button>
        </div>
      </div>

      <form onSubmit={handleSubmit}>
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2 space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>اطلاعات شهر</CardTitle>
                <CardDescription>مشخصات شهر و ضرایب مربوطه</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="city">نام شهر</Label>
                  <Input
                    id="city"
                    value={formData.city}
                    onChange={(e) =>
                      setFormData({ ...formData, city: e.target.value })
                    }
                    placeholder="مثلاً تهران"
                    required
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="base_cost">هزینه پایه شهر (تومان)</Label>
                  <Input
                    id="base_cost"
                    type="number"
                    step="1000"
                    min="0"
                    value={formData.base_cost}
                    onChange={(e) =>
                      setFormData({ ...formData, base_cost: e.target.value })
                    }
                    placeholder="مثلاً 900000"
                    required
                  />
                  <p className="text-xs text-muted-foreground">
                    این مقدار در ضریب ضرب شده و به‌صورت هزینه ثابت به قیمت اضافه می‌شود.
                  </p>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="multiplier">ضریب</Label>
                  <Input
                    id="multiplier"
                    type="number"
                    step="0.01"
                    min="0"
                    value={formData.multiplier}
                    onChange={(e) =>
                      setFormData({ ...formData, multiplier: e.target.value })
                    }
                    placeholder="مثلاً 1.2"
                    required
                  />
                </div>

                <div className="flex items-center justify-between pt-2">
                  <Label htmlFor="is_active">فعال</Label>
                  <Switch
                    id="is_active"
                    checked={formData.is_active === true}
                    onCheckedChange={(checked) =>
                      setFormData({ ...formData, is_active: checked })
                    }
                  />
                </div>
              </CardContent>
            </Card>

            <Card className="border-red-200">
              <CardContent className="pt-6">
                <Button
                  type="button"
                  variant="destructive"
                  onClick={handleDelete}
                  className="w-full"
                >
                  <Trash2 className="ml-2 h-4 w-4" />
                  حذف ضریب شهر
                </Button>
                <p className="text-xs text-muted-foreground mt-2 text-center">
                  با حذف این ضریب، تمام داده‌های مرتبط با آن نیز حذف می‌شوند.
                </p>
              </CardContent>
            </Card>
          </div>

          <div className="lg:col-span-1 space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>محاسبه هزینه شهر</CardTitle>
                <CardDescription>
                  هزینه نهایی شهر = base_cost × multiplier
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="rounded-lg bg-muted p-4 space-y-2">
                  <div className="flex justify-between">
                    <span className="text-sm text-muted-foreground">هزینه پایه شهر (تومان):</span>
                    <span className="font-medium">
                      {toPersianDigits(formatPrice(baseCost))}
                    </span>
                  </div>
                  <div className="flex justify-between border-t pt-2">
                    <span className="text-sm text-muted-foreground">ضریب:</span>
                    <span className="font-medium">
                      {toPersianDigits(multiplier.toFixed(2))}
                    </span>
                  </div>
                  <div className="flex justify-between border-t pt-2 text-lg font-bold">
                    <span>هزینه نهایی (تومان):</span>
                    <span className="text-primary">
                      {toPersianDigits(formatPrice(finalCost))}
                    </span>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Button type="submit" className="w-full" disabled={saving}>
              <Save className="ml-2 h-4 w-4" />
              {saving ? "در حال ذخیره..." : "ذخیره تغییرات"}
            </Button>
          </div>
        </div>
      </form>

      <Dialog open={historyDialogOpen} onOpenChange={setHistoryDialogOpen}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>تاریخچه تغییرات</DialogTitle>
            <DialogDescription>
              تغییرات اعمال‌شده روی ضریب شهر {item.city}
            </DialogDescription>
          </DialogHeader>
          {history.length === 0 ? (
            <p className="text-muted-foreground text-center py-4">
              هیچ تغییری ثبت نشده است.
            </p>
          ) : (
            <div className="space-y-4 max-h-96 overflow-y-auto">
              {history.map((h) => (
                <div key={h.id} className="border-b pb-3">
                  <div className="flex justify-between text-sm">
                    <span className="font-medium">{h.field}</span>
                    <span className="text-muted-foreground">
                      {new Date(h.changed_at).toLocaleString("fa-IR")}
                    </span>
                  </div>
                  <div className="flex justify-between text-sm mt-1">
                    <span className="text-red-600">از: {h.old_value}</span>
                    <span className="text-green-600">به: {h.new_value}</span>
                  </div>
                  <div className="text-xs text-muted-foreground mt-1">
                    توسط: {h.changed_by}
                  </div>
                </div>
              ))}
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
// app/dashboard/admin/city-multipliers/new/page.tsx
"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { Save, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { toast } from "sonner";
import { parseApiError } from "@/lib/form-errors";
import { toPersianDigits, formatPrice } from "@/lib/utils";

const DEFAULT_BASE_COST = 900000;

export default function NewCityMultiplierPage() {
  const router = useRouter();
  const [loading, setLoading] = useState(false);
  const [formData, setFormData] = useState({
    city: "",
    base_cost: String(DEFAULT_BASE_COST),
    multiplier: "1.00",
    is_active: true,
  });

  const baseCost = parseFloat(formData.base_cost) || 0;
  const multiplier = parseFloat(formData.multiplier) || 0;
  const finalCost = baseCost * multiplier;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      const payload = {
        city: formData.city.trim(),
        base_cost: baseCost,
        multiplier: multiplier,
        is_active: formData.is_active,
      };

      const res = await fetch("/api/proxy/core/city-multipliers/", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });

      if (!res.ok) {
        const errData = await res.json().catch(() => ({}));
        throw new Error(parseApiError(errData, "خطا در ذخیره‌سازی").message);
      }

      toast.success("ضریب شهر جدید افزوده شد");
      router.push("/dashboard/admin/city-multipliers");
      router.refresh();
    } catch (error: any) {
      toast.error(error.message || "خطا در ذخیره‌سازی ضریب شهر");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold">افزودن ضریب شهر جدید</h1>
          <p className="text-muted-foreground text-sm">
            اطلاعات ضریب شهر جدید را وارد کنید
          </p>
        </div>
        <Button variant="outline" onClick={() => router.back()}>
          <X className="ml-2 h-4 w-4" />
          انصراف
        </Button>
      </div>

      <form onSubmit={handleSubmit}>
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2 space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>اطلاعات شهر</CardTitle>
                <CardDescription>مشخصات شهر و ضرایب مربوطه</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="city">نام شهر</Label>
                  <Input
                    id="city"
                    value={formData.city}
                    onChange={(e) =>
                      setFormData({ ...formData, city: e.target.value })
                    }
                    placeholder="مثلاً تهران"
                    required
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="base_cost">هزینه پایه شهر (تومان)</Label>
                  <Input
                    id="base_cost"
                    type="number"
                    step="1000"
                    min="0"
                    value={formData.base_cost}
                    onChange={(e) =>
                      setFormData({ ...formData, base_cost: e.target.value })
                    }
                    placeholder="مثلاً 900000"
                    required
                  />
                  <p className="text-xs text-muted-foreground">
                    این مقدار در ضریب ضرب شده و به‌صورت هزینه ثابت به قیمت اضافه می‌شود.
                  </p>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="multiplier">ضریب</Label>
                  <Input
                    id="multiplier"
                    type="number"
                    step="0.01"
                    min="0"
                    value={formData.multiplier}
                    onChange={(e) =>
                      setFormData({ ...formData, multiplier: e.target.value })
                    }
                    placeholder="مثلاً 1.2"
                    required
                  />
                </div>

                <div className="flex items-center justify-between pt-2">
                  <Label htmlFor="is_active">فعال</Label>
                  <Switch
                    id="is_active"
                    checked={formData.is_active === true}
                    onCheckedChange={(checked) =>
                      setFormData({ ...formData, is_active: checked })
                    }
                  />
                </div>
              </CardContent>
            </Card>
          </div>

          <div className="lg:col-span-1 space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>محاسبه هزینه شهر</CardTitle>
                <CardDescription>
                  هزینه نهایی شهر = base_cost × multiplier
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="rounded-lg bg-muted p-4 space-y-2">
                  <div className="flex justify-between">
                    <span className="text-sm text-muted-foreground">هزینه پایه شهر (تومان):</span>
                    <span className="font-medium">
                      {toPersianDigits(formatPrice(baseCost))}
                    </span>
                  </div>
                  <div className="flex justify-between border-t pt-2">
                    <span className="text-sm text-muted-foreground">ضریب:</span>
                    <span className="font-medium">
                      {toPersianDigits(multiplier.toFixed(2))}
                    </span>
                  </div>
                  <div className="flex justify-between border-t pt-2 text-lg font-bold">
                    <span>هزینه نهایی (تومان):</span>
                    <span className="text-primary">
                      {toPersianDigits(formatPrice(finalCost))}
                    </span>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Button type="submit" className="w-full" disabled={loading}>
              <Save className="ml-2 h-4 w-4" />
              {loading ? "در حال ذخیره..." : "ذخیره ضریب"}
            </Button>
          </div>
        </div>
      </form>
    </div>
  );
}
// app/dashboard/admin/city-multipliers/page.tsx
"use client";

import { useState, useEffect } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { Plus, Pencil, Trash2, Loader2, GripVertical, Power, PowerOff } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { toast } from "sonner";
import { toPersianDigits, formatPrice } from "@/lib/utils";

// DnD Kit imports
import {
  DndContext,
  closestCenter,
  KeyboardSensor,
  PointerSensor,
  useSensor,
  useSensors,
  DragEndEvent,
} from "@dnd-kit/core";
import {
  arrayMove,
  SortableContext,
  sortableKeyboardCoordinates,
  verticalListSortingStrategy,
} from "@dnd-kit/sortable";
import { useSortable } from "@dnd-kit/sortable";
import { CSS } from "@dnd-kit/utilities";

interface CityMultiplier {
  id: number;
  city: string;
  base_cost: number;
  multiplier: number;
  is_active: boolean;
  order: number;
}

// کامپوننت ردیف قابل جابجایی
function SortableRow({ 
  item, 
  onToggleActive, 
  onEdit, 
  onDelete 
}: { 
  item: CityMultiplier;
  onToggleActive: (item: CityMultiplier) => void;
  onEdit: (id: number) => void;
  onDelete: (id: number) => void;
}) {
  const {
    attributes,
    listeners,
    setNodeRef,
    transform,
    transition,
    isDragging,
  } = useSortable({ id: item.id });

  const style = {
    transform: CSS.Transform.toString(transform),
    transition,
    opacity: isDragging ? 0.5 : 1,
  };

  const finalCost = item.base_cost * item.multiplier;

  return (
    <TableRow ref={setNodeRef} style={style} {...attributes}>
      <TableCell className="w-10">
        <div {...listeners} className="cursor-grab hover:text-primary">
          <GripVertical className="h-4 w-4 text-muted-foreground" />
        </div>
      </TableCell>
      <TableCell>{toPersianDigits(item.id)}</TableCell>
      <TableCell className="font-medium">{item.city}</TableCell>
      <TableCell className="text-left font-medium">
        {toPersianDigits(item.multiplier)}
      </TableCell>
      <TableCell className="text-left">
        {toPersianDigits(formatPrice(item.base_cost))}
      </TableCell>
      <TableCell className="text-left font-bold">
        {toPersianDigits(formatPrice(finalCost))}
      </TableCell>
      <TableCell>
        <span
          className={`inline-flex rounded-full px-2 py-0.5 text-xs font-medium border ${
            item.is_active
              ? "border-green-500 text-green-700 bg-green-50"
              : "border-gray-300 text-gray-500 bg-gray-50"
          }`}
        >
          {item.is_active ? "فعال" : "غیرفعال"}
        </span>
      </TableCell>
      <TableCell className="text-left space-x-1">
        <Button
          variant="ghost"
          size="sm"
          onClick={() => onToggleActive(item)}
          title={item.is_active ? "غیرفعال کردن" : "فعال کردن"}
        >
          {item.is_active ? (
            <Power className="h-4 w-4 text-green-600" />
          ) : (
            <PowerOff className="h-4 w-4 text-gray-400" />
          )}
        </Button>
        <Button variant="ghost" size="sm" onClick={() => onEdit(item.id)}>
          <Pencil className="h-4 w-4" />
        </Button>
        <Button
          variant="ghost"
          size="sm"
          onClick={() => onDelete(item.id)}
          className="text-red-500 hover:text-red-700"
        >
          <Trash2 className="h-4 w-4" />
        </Button>
      </TableCell>
    </TableRow>
  );
}

export default function AdminCityMultipliersPage() {
  const router = useRouter();
  const [items, setItems] = useState<CityMultiplier[]>([]);
  const [loading, setLoading] = useState(true);
  const [reordering, setReordering] = useState(false);

  const sensors = useSensors(
    useSensor(PointerSensor),
    useSensor(KeyboardSensor, {
      coordinateGetter: sortableKeyboardCoordinates,
    })
  );

  const fetchItems = async () => {
    try {
      setLoading(true);
      const res = await fetch("/api/proxy/core/city-multipliers/");
      if (!res.ok) throw new Error("خطا در دریافت اطلاعات");
      const data = await res.json();
      setItems(Array.isArray(data) ? data : data.results || []);
    } catch (error) {
      toast.error("خطا در دریافت لیست ضرایب شهر");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchItems();
  }, []);

  const toggleActive = async (item: CityMultiplier) => {
    try {
      const res = await fetch(`/api/proxy/core/city-multipliers/${item.id}/`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ is_active: !item.is_active }),
      });
      if (!res.ok) throw new Error("خطا در تغییر وضعیت");
      toast.success("وضعیت با موفقیت تغییر کرد");
      fetchItems();
    } catch (error) {
      toast.error("خطا در تغییر وضعیت");
    }
  };

  const handleDelete = async (id: number) => {
    if (!confirm("آیا از حذف این ضریب شهر مطمئن هستید؟")) return;
    try {
      const res = await fetch(`/api/proxy/core/city-multipliers/${id}/`, {
        method: "DELETE",
      });
      if (!res.ok) throw new Error("خطا در حذف");
      toast.success("ضریب شهر حذف شد");
      fetchItems();
    } catch (error) {
      toast.error("خطا در حذف ضریب شهر");
    }
  };

  const handleDragEnd = async (event: DragEndEvent) => {
    const { active, over } = event;
    if (!over || active.id === over.id) return;

    setReordering(true);
    try {
      const oldIndex = items.findIndex((item) => item.id === active.id);
      const newIndex = items.findIndex((item) => item.id === over.id);
      const newItems = arrayMove(items, oldIndex, newIndex);
      setItems(newItems);

      // ارسال ترتیب جدید به بک‌اند
      const orderedIds = newItems.map((item) => item.id);
      const res = await fetch("/api/proxy/core/city-multipliers/reorder/", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ ids: orderedIds }),
      });

      if (!res.ok) {
        throw new Error("خطا در ذخیره‌سازی ترتیب جدید");
      }

      toast.success("ترتیب با موفقیت ذخیره شد");
    } catch (error) {
      toast.error("خطا در ذخیره‌سازی ترتیب");
      fetchItems(); // بازگردانی به ترتیب قبلی
    } finally {
      setReordering(false);
    }
  };

  if (loading && items.length === 0) {
    return (
      <div className="flex items-center justify-center p-12">
        <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold">ضرایب شهر</h1>
          <p className="text-muted-foreground text-sm">
            مدیریت ضرایب هزینه بر اساس شهر
          </p>
          {reordering && (
            <p className="text-xs text-muted-foreground mt-1">
              در حال ذخیره‌سازی ترتیب جدید...
            </p>
          )}
        </div>
        <Link href="/dashboard/admin/city-multipliers/new">
          <Button>
            <Plus className="ml-2 h-4 w-4" />
            ضریب جدید
          </Button>
        </Link>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>لیست ضرایب شهر</CardTitle>
          <CardDescription>
            برای جابجایی، آیکون ≡ را بکشید و رها کنید
          </CardDescription>
        </CardHeader>
        <CardContent>
          <DndContext
            sensors={sensors}
            collisionDetection={closestCenter}
            onDragEnd={handleDragEnd}
          >
            <SortableContext
              items={items.map((item) => item.id)}
              strategy={verticalListSortingStrategy}
            >
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="w-10"></TableHead>
                    <TableHead>#</TableHead>
                    <TableHead>شهر</TableHead>
                    <TableHead className="text-left">ضریب</TableHead>
                    <TableHead className="text-left">هزینه‌ی پایه (تومان)</TableHead>
                    <TableHead className="text-left">هزینه‌ی نهایی (تومان)</TableHead>
                    <TableHead>وضعیت</TableHead>
                    <TableHead className="text-left">عملیات</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {items.length === 0 ? (
                    <TableRow>
                      <TableCell colSpan={8} className="text-center text-muted-foreground">
                        هیچ ضریبی ثبت نشده است.
                      </TableCell>
                    </TableRow>
                  ) : (
                    items.map((item) => (
                      <SortableRow
                        key={item.id}
                        item={item}
                        onToggleActive={toggleActive}
                        onEdit={(id) =>
                          router.push(`/dashboard/admin/city-multipliers/${id}/edit`)
                        }
                        onDelete={handleDelete}
                      />
                    ))
                  )}
                </TableBody>
              </Table>
            </SortableContext>
          </DndContext>
        </CardContent>
      </Card>
    </div>
  );
}
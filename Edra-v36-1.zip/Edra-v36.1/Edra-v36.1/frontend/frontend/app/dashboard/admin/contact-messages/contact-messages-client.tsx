"use client";

// EDRA v27 — قابلیت تازه (گزارش کاربر، سپتامبر ۲۰۲۶): پیام‌های فرم تماس
// سایت از قبل در بک‌اند ذخیره می‌شدند (ContactMessageViewSet کامل بود)
// ولی هیچ صفحه‌ای برای دیدنشان در پنل ادمین وجود نداشت — پیام‌های واقعی
// مشتریان عملاً به‌جایی نمی‌رسیدند.

import * as React from "react";
import { useRouter } from "next/navigation";
import { toast } from "sonner";
import { Mail, Trash2, Phone } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { apiClientFetch, ClientApiError } from "@/lib/api-client";
import { Pagination } from "@/components/ui/pagination";

interface ContactMessageItem {
  id: number;
  name: string;
  email: string;
  phone: string;
  message: string;
  created_at_jalali?: string;
}

export function ContactMessagesClient({
  messages,
  count,
  page,
}: {
  messages: ContactMessageItem[];
  count: number;
  page: number;
}) {
  const router = useRouter();
  const [open, setOpen] = React.useState<ContactMessageItem | null>(null);
  const [deleteTarget, setDeleteTarget] = React.useState<ContactMessageItem | null>(null);
  const [deleting, setDeleting] = React.useState(false);

  async function confirmDelete() {
    if (!deleteTarget) return;
    setDeleting(true);
    try {
      await apiClientFetch(`/api/public/contact-messages/${deleteTarget.id}/`, {
        method: "DELETE",
      });
      toast.success("پیام حذف شد.");
      setDeleteTarget(null);
      setOpen(null);
      router.refresh();
    } catch (err) {
      toast.error(err instanceof ClientApiError ? err.message : "خطا در حذف.");
    } finally {
      setDeleting(false);
    }
  }

  return (
    <>
      <div>
        <h1 className="text-2xl font-semibold">پیام‌های تماس</h1>
        <p className="text-muted-foreground text-sm">پیام‌های ارسال‌شده از فرم تماس سایت</p>
      </div>

      <Card>
        <CardContent className="px-0 py-2">
          {messages.length === 0 ? (
            <p className="text-muted-foreground py-10 text-center text-sm">
              <Mail className="mx-auto mb-2 size-8 opacity-40" />
              پیامی دریافت نشده است
            </p>
          ) : (
            <div className="flex flex-col divide-y">
              {messages.map((m) => (
                <button
                  key={m.id}
                  onClick={() => setOpen(m)}
                  className="hover:bg-accent/50 flex w-full items-start justify-between gap-3 px-5 py-4 text-right"
                >
                  <div className="min-w-0">
                    <div className="flex items-center gap-2">
                      <span className="text-sm font-medium">{m.name}</span>
                      <span className="text-muted-foreground text-xs" dir="ltr">
                        {m.email}
                      </span>
                    </div>
                    <p className="text-muted-foreground mt-1 line-clamp-1 text-xs">{m.message}</p>
                  </div>
                  <span className="text-muted-foreground shrink-0 text-xs">
                    {m.created_at_jalali}
                  </span>
                </button>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      <Pagination current={page} totalItems={count} basePath="/dashboard/admin/contact-messages" />

      <Dialog open={Boolean(open)} onOpenChange={(o) => !o && setOpen(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>{open?.name}</DialogTitle>
          </DialogHeader>
          <div className="flex flex-col gap-2 text-sm">
            <p className="text-muted-foreground flex items-center gap-2" dir="ltr">
              <Mail className="size-3.5" /> {open?.email}
            </p>
            <p className="text-muted-foreground flex items-center gap-2" dir="ltr">
              <Phone className="size-3.5" /> {open?.phone}
            </p>
            <p className="bg-muted mt-2 whitespace-pre-wrap rounded-md p-3">{open?.message}</p>
          </div>
          <div className="flex justify-end gap-2">
            <Button variant="outline" asChild>
              <a href={`mailto:${open?.email}`}>پاسخ با ایمیل</a>
            </Button>
            <Button variant="destructive" onClick={() => open && setDeleteTarget(open)}>
              <Trash2 className="size-3.5" />
              حذف
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      <Dialog open={Boolean(deleteTarget)} onOpenChange={(o) => !o && setDeleteTarget(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>حذف پیام «{deleteTarget?.name}»</DialogTitle>
          </DialogHeader>
          <div className="flex justify-end gap-2">
            <Button variant="outline" onClick={() => setDeleteTarget(null)}>
              انصراف
            </Button>
            <Button variant="destructive" onClick={confirmDelete} disabled={deleting}>
              {deleting ? "در حال حذف..." : "حذف"}
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
}

import { fetchPaginated } from "@/lib/paginated-fetch";
import { ContactMessagesClient } from "./contact-messages-client";

export const metadata = { title: "پیام‌های تماس" };

interface ContactMessageItem {
  id: number;
  name: string;
  email: string;
  phone: string;
  message: string;
  created_at_jalali?: string;
}

async function fetchMessages(page: number) {
  return fetchPaginated<ContactMessageItem>(`/api/public/contact-messages/?ordering=-created_at`, page);
}

export default async function AdminContactMessagesPage({
  searchParams,
}: {
  searchParams: Promise<{ page?: string }>;
}) {
  const _page = Math.max(1, Number((await searchParams).page) || 1);
  const { items: messages, count } = await fetchMessages(_page);

  return (
    <div className="flex flex-col gap-6">
      <ContactMessagesClient messages={messages} count={count} page={_page} />
    </div>
  );
}

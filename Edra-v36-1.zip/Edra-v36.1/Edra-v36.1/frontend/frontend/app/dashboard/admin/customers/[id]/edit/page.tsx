// app/dashboard/admin/customers/[id]/edit/page.tsx  (EDRA v32)
import { notFound, redirect } from "next/navigation";
import { apiServerFetch, ApiError } from "@/lib/api-server";
import { UserForm, type UserFormInitial } from "@/components/admin/user-form";

export const metadata = { title: "ویرایش مشتری" };

interface UserDetail extends UserFormInitial {
  role: "customer" | "expert" | "admin";
}

export default async function AdminEditCustomerPage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = await params;
  if (!/^\d+$/.test(id)) notFound();

  let user: UserDetail;
  try {
    user = await apiServerFetch<UserDetail>(`/api/core/users/${id}/`);
  } catch (err) {
    if (err instanceof ApiError && err.status === 404) notFound();
    throw err;
  }

  // اگر نقش کاربر با این بخش نمی‌خواند (مثلاً کارشناس در مسیر مشتریان)، به
  // صفحه‌ی ویرایش بخش درست هدایت می‌شود؛ ادمین‌ها از این مسیر ویرایش نمی‌شوند.
  if (user.role === "admin") notFound();
  if (user.role !== "customer") {
    redirect(`/dashboard/admin/${user.role === "expert" ? "experts" : "customers"}/${id}/edit`);
  }

  return <UserForm mode="edit" role="customer" initial={user} />;
}

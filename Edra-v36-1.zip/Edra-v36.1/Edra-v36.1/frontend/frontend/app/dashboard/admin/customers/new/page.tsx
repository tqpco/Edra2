// app/dashboard/admin/customers/new/page.tsx  (EDRA v32)
import { UserForm } from "@/components/admin/user-form";

export const metadata = { title: "مشتری جدید" };

export default function AdminNewCustomerPage() {
  return <UserForm mode="create" role="customer" />;
}

// app/dashboard/admin/customers/page.tsx
import { fetchPaginated } from "@/lib/paginated-fetch";
import { Pagination } from "@/components/ui/pagination";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import Link from "next/link";
import { FileBarChart, Pencil, Plus } from "lucide-react";
import { toPersianDigits } from "@/lib/utils"; // ✅ اصلاح شد
import { RoleChangeButton } from "@/components/shared/role-change-button";

export const metadata = { title: "مشتریان" };

interface CustomerRow {
  id: number;
  username: string;
  full_name: string;
  phone: string | null;
  company_name: string | null;
  date_joined_jalali: string;
  role: "customer" | "expert" | "admin";
  is_staff: boolean;
  is_superuser: boolean;
}

export default async function AdminCustomersPage({ searchParams }: { searchParams: Promise<{ page?: string }> }) {
  const _page = Math.max(1, Number((await searchParams).page) || 1);
  const { items: customers, count } = await fetchPaginated<CustomerRow>(`/api/core/users/?role=customer`, _page);
  

  return (
    <div className="flex flex-col gap-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="text-2xl font-semibold">مشتریان</h1>
          <p className="text-muted-foreground text-sm">
            {toPersianDigits(count)} مشتری ثبت‌شده
          </p>
        </div>
        <Button asChild>
          <Link href="/dashboard/admin/customers/new">
            <Plus className="size-4" />
            مشتری جدید
          </Link>
        </Button>
      </div>

      <Card>
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b text-right">
                  <th className="text-muted-foreground px-4 py-3 text-xs font-medium">نام</th>
                  <th className="text-muted-foreground px-4 py-3 text-xs font-medium">موبایل</th>
                  <th className="text-muted-foreground px-4 py-3 text-xs font-medium">شرکت</th>
                  <th className="text-muted-foreground px-4 py-3 text-xs font-medium">تاریخ عضویت</th>
                  <th className="text-muted-foreground px-4 py-3 text-xs font-medium"></th>
                </tr>
              </thead>
              <tbody>
                {customers.map((c) => (
                  <tr key={c.id} className="hover:bg-accent/50 border-b last:border-0">
                    <td className="px-4 py-3 font-medium">{c.full_name || c.username}</td>
                    <td className="ltr-numerals px-4 py-3">{c.phone ?? "—"}</td>
                    <td className="px-4 py-3">{c.company_name || "—"}</td>
                    <td className="text-muted-foreground px-4 py-3">
                      {c.date_joined_jalali}
                    </td>
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-1">
                        <Button variant="ghost" size="sm" asChild>
                          <Link href={`/dashboard/admin/customers/${c.id}/edit`}>
                            <Pencil className="size-3.5" />
                            ویرایش
                          </Link>
                        </Button>
                        <RoleChangeButton
                          userId={c.id}
                          userDisplayName={c.full_name || c.username}
                          currentRole={c.role}
                          disabled={c.is_staff || c.is_superuser}
                        />
                        <Button variant="ghost" size="sm" asChild>
                          <a
                            href={`/api/download/core/admin/customers/${c.id}/full-report/?format=xlsx`}
                            target="_blank"
                          >
                            <FileBarChart className="size-3.5" />
                            گزارش کامل
                          </a>
                        </Button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
        {customers.length === 0 && (
          <p className="text-muted-foreground py-10 text-center text-sm">
            مشتری‌ای ثبت نشده است. با دکمه‌ی «مشتری جدید» اولین مشتری را اضافه کنید.
          </p>
        )}
      </Card>
      <Pagination current={_page} totalItems={count} basePath="/dashboard/admin/customers" />
</div>
  );
}
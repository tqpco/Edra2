"use client";

// EDRA v27 — قابلیت تازه (گزارش کاربر، سپتامبر ۲۰۲۶): «هر بخشی که در
// بک‌اند وجود دارد باید در فرانت هم وجود داشته باشه». بک‌اند ارسال کد
// تخفیف به کاربر خاص/همه‌ی کاربران (discounts/views.py) کامل نوشته و
// در همین نشست چند باگ آن (ارسال تکراری، بدون batching) رفع شده بود،
// ولی هیچ رابط کاربری‌ای برایش وجود نداشت — این کامپوننت آن گپ را می‌بندد.

import * as React from "react";
import { toast } from "sonner";
import { Send, Users, Search, Loader2, ShieldAlert } from "lucide-react";
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import { apiClientFetch, ClientApiError } from "@/lib/api-client";

interface DiscountCodeOption {
  id: number;
  code: string;
  is_active: boolean;
}

interface UserSearchResult {
  id: number;
  username: string;
  email: string;
  phone: string | null;
}

export function CampaignSendPanel({ codes }: { codes: DiscountCodeOption[] }) {
  const activeCodes = codes.filter((c) => c.is_active);
  const [selectedCodeId, setSelectedCodeId] = React.useState<string>("");

  // --- ارسال به یک کاربر ---
  const [userDialogOpen, setUserDialogOpen] = React.useState(false);
  const [query, setQuery] = React.useState("");
  const [results, setResults] = React.useState<UserSearchResult[]>([]);
  const [searching, setSearching] = React.useState(false);
  const [sendingUserId, setSendingUserId] = React.useState<number | null>(null);

  React.useEffect(() => {
    if (!userDialogOpen || query.trim().length < 2) {
      setResults([]);
      return;
    }
    const timer = setTimeout(async () => {
      setSearching(true);
      try {
        const data = await apiClientFetch<UserSearchResult[] | { results: UserSearchResult[] }>(
          `/api/discounts/user-search/?q=${encodeURIComponent(query)}`
        );
        setResults(Array.isArray(data) ? data : data.results ?? []);
      } catch {
        setResults([]);
      } finally {
        setSearching(false);
      }
    }, 350); // debounce تا با هر حرف تایپ‌شده به سرور درخواست نزند
    return () => clearTimeout(timer);
  }, [query, userDialogOpen]);

  async function sendToUser(userId: number) {
    setSendingUserId(userId);
    try {
      await apiClientFetch("/api/discounts/send-to-user/", {
        method: "POST",
        body: { user_id: userId, discount_id: Number(selectedCodeId) },
      });
      toast.success("کد تخفیف در صف ارسال قرار گرفت.");
      setUserDialogOpen(false);
      setQuery("");
      setResults([]);
    } catch (err) {
      toast.error(err instanceof ClientApiError ? err.message : "خطا در ارسال کد تخفیف.");
    } finally {
      setSendingUserId(null);
    }
  }

  // --- ارسال به همه کاربران ---
  const [allDialogOpen, setAllDialogOpen] = React.useState(false);
  const [sendingAll, setSendingAll] = React.useState(false);

  async function sendToAll() {
    setSendingAll(true);
    try {
      await apiClientFetch("/api/discounts/send-to-all/", {
        method: "POST",
        body: { discount_id: Number(selectedCodeId) },
      });
      toast.success("ارسال کد تخفیف به همه‌ی کاربران فعال آغاز شد.");
      setAllDialogOpen(false);
    } catch (err) {
      toast.error(err instanceof ClientApiError ? err.message : "خطا در شروع ارسال گروهی.");
    } finally {
      setSendingAll(false);
    }
  }

  const selectedCode = activeCodes.find((c) => String(c.id) === selectedCodeId);

  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-base">ارسال کد تخفیف</CardTitle>
        <CardDescription>
          یک کد فعال را انتخاب کنید و برای یک کاربر مشخص یا همه‌ی کاربران فعال ارسال کنید.
        </CardDescription>
      </CardHeader>
      <CardContent className="flex flex-col gap-4">
        <Select value={selectedCodeId} onValueChange={setSelectedCodeId}>
          <SelectTrigger>
            <SelectValue placeholder="یک کد تخفیف فعال انتخاب کنید" />
          </SelectTrigger>
          <SelectContent>
            {activeCodes.length === 0 ? (
              <div className="text-muted-foreground p-2 text-sm">کد تخفیف فعالی وجود ندارد</div>
            ) : (
              activeCodes.map((c) => (
                <SelectItem key={c.id} value={String(c.id)}>
                  {c.code}
                </SelectItem>
              ))
            )}
          </SelectContent>
        </Select>

        <div className="flex flex-wrap gap-2">
          <Button variant="outline" disabled={!selectedCodeId} onClick={() => setUserDialogOpen(true)}>
            <Send className="size-4" />
            ارسال به یک کاربر
          </Button>
          <Button variant="outline" disabled={!selectedCodeId} onClick={() => setAllDialogOpen(true)}>
            <Users className="size-4" />
            ارسال به همه کاربران
          </Button>
        </div>
      </CardContent>

      {/* دیالوگ جست‌وجو و ارسال به یک کاربر */}
      <Dialog open={userDialogOpen} onOpenChange={setUserDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>ارسال «{selectedCode?.code}» به یک کاربر</DialogTitle>
            <DialogDescription>با نام کاربری، ایمیل یا شماره موبایل جست‌وجو کنید.</DialogDescription>
          </DialogHeader>
          <div className="relative">
            <Search className="text-muted-foreground absolute right-3 top-1/2 size-4 -translate-y-1/2" />
            <Input
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="حداقل ۲ حرف..."
              className="pr-9"
              dir="ltr"
            />
          </div>
          <div className="flex max-h-64 flex-col gap-1 overflow-y-auto">
            {searching && (
              <div className="flex items-center justify-center py-4">
                <Loader2 className="size-4 animate-spin" />
              </div>
            )}
            {!searching && query.trim().length >= 2 && results.length === 0 && (
              <p className="text-muted-foreground py-4 text-center text-sm">کاربری یافت نشد.</p>
            )}
            {results.map((u) => (
              <div key={u.id} className="flex items-center justify-between rounded-md border p-2">
                <div className="text-sm">
                  <p className="font-medium">{u.username}</p>
                  <p className="text-muted-foreground text-xs" dir="ltr">
                    {u.phone ?? u.email ?? "—"}
                  </p>
                </div>
                <Button size="sm" disabled={sendingUserId === u.id} onClick={() => sendToUser(u.id)}>
                  {sendingUserId === u.id ? <Loader2 className="size-3.5 animate-spin" /> : "ارسال"}
                </Button>
              </div>
            ))}
          </div>
        </DialogContent>
      </Dialog>

      {/* دیالوگ تایید ارسال گروهی */}
      <Dialog open={allDialogOpen} onOpenChange={setAllDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>ارسال «{selectedCode?.code}» به همه کاربران فعال</DialogTitle>
            <DialogDescription>
              این کد برای تمام کاربران فعال سیستم صف می‌شود. این عملیات قابل لغو نیست.
            </DialogDescription>
          </DialogHeader>
          <div className="flex items-start gap-2 rounded-md border border-amber-300 bg-amber-50 p-3 text-sm text-amber-800">
            <ShieldAlert className="mt-0.5 size-4 shrink-0" />
            <p>لطفاً قبل از تایید مطمئن شوید کد تخفیف صحیح انتخاب شده است.</p>
          </div>
          <div className="flex justify-end gap-2">
            <Button variant="outline" onClick={() => setAllDialogOpen(false)}>
              انصراف
            </Button>
            <Button variant="destructive" disabled={sendingAll} onClick={sendToAll}>
              {sendingAll ? "در حال ارسال..." : "تایید و ارسال به همه"}
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </Card>
  );
}

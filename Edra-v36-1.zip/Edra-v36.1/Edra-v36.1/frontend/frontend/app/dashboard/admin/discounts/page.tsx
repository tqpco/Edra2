"use client";

import { useState, useEffect } from "react";
import { Plus, Pencil, Trash2, Loader2, TicketPercent } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { toast } from "sonner";
import { formatToman } from "@/lib/format";
import { toPersianDigits } from "@/lib/jalali";
import { CampaignSendPanel } from "./campaign-send-panel";

interface EquipmentType {
  id: number;
  name_fa: string;
}

interface DiscountCode {
  id: number;
  code: string;
  discount_type: string;
  value: number;
  is_active: boolean;
  used_count: number;
  usage_limit: number | null;
  per_user_limit: number | null;
  min_amount: number | null;
  max_amount: number | null;
  apply_to_all: boolean;
  equipment_type: EquipmentType | number | null;
  expires_at: string | null;
  description: string;
}

export default function AdminDiscountsPage() {
  const [codes, setCodes] = useState<DiscountCode[]>([]);
  const [equipmentTypes, setEquipmentTypes] = useState<EquipmentType[]>([]);
  const [loading, setLoading] = useState(true);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingCode, setEditingCode] = useState<DiscountCode | null>(null);
  const [formData, setFormData] = useState({
    code: "",
    discount_type: "percent",
    value: "",
    min_amount: "",
    max_amount: "",
    usage_limit: "",
    per_user_limit: "",
    apply_to_all: true,
    equipment_type: "",
    expires_at: "",
    description: "",
    is_active: true,
  });

  const fetchCodes = async () => {
    try {
      setLoading(true);
      const res = await fetch("/api/proxy/core/discount-codes/?ordering=code");
      if (!res.ok) throw new Error("خطا در دریافت اطلاعات");
      const data = await res.json();
      setCodes(Array.isArray(data) ? data : data.results || []);
    } catch {
      toast.error("خطا در دریافت لیست کدهای تخفیف");
    } finally {
      setLoading(false);
    }
  };

  const fetchEquipment = async () => {
    try {
      const res = await fetch("/api/proxy/core/equipment-types/?all=true");
      if (!res.ok) throw new Error("خطا در دریافت تجهیزات");
      const data = await res.json();
      setEquipmentTypes(Array.isArray(data) ? data : data.results || []);
    } catch {
      // سکوت — تجهیزات اختیاری است
    }
  };

  useEffect(() => {
    fetchCodes();
    fetchEquipment();
  }, []);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const payload: Record<string, unknown> = {
        code: formData.code,
        discount_type: formData.discount_type,
        value: Number(formData.value),
        is_active: formData.is_active,
        apply_to_all: formData.apply_to_all,
        description: formData.description,
      };
      if (formData.min_amount) payload.min_amount = Number(formData.min_amount);
      if (formData.max_amount) payload.max_amount = Number(formData.max_amount);
      if (formData.usage_limit) payload.usage_limit = Number(formData.usage_limit);
      if (formData.per_user_limit) payload.per_user_limit = Number(formData.per_user_limit);
      if (formData.expires_at) payload.expires_at = formData.expires_at;
      if (!formData.apply_to_all && formData.equipment_type) {
        payload.equipment_type = Number(formData.equipment_type);
      }

      const url = editingCode
        ? `/api/proxy/core/discount-codes/${editingCode.id}/`
        : "/api/proxy/core/discount-codes/";
      const method = editingCode ? "PUT" : "POST";

      const res = await fetch(url, {
        method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });

      if (!res.ok) {
        const err = await res.json().catch(() => ({}));
        throw new Error(err.detail || err.error || "خطا در ذخیره‌سازی");
      }

      toast.success(editingCode ? "کد تخفیف ویرایش شد" : "کد تخفیف جدید ایجاد شد");
      setDialogOpen(false);
      setEditingCode(null);
      resetForm();
      fetchCodes();
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "خطا در ذخیره‌سازی کد تخفیف");
    }
  };

  const handleDelete = async (id: number) => {
    if (!confirm("آیا از حذف این کد تخفیف مطمئن هستید؟")) return;
    try {
      const res = await fetch(`/api/proxy/core/discount-codes/${id}/`, {
        method: "DELETE",
      });
      if (!res.ok) throw new Error("خطا در حذف");
      toast.success("کد تخفیف حذف شد");
      fetchCodes();
    } catch {
      toast.error("خطا در حذف کد تخفیف");
    }
  };

  const resetForm = () => {
    setFormData({
      code: "",
      discount_type: "percent",
      value: "",
      min_amount: "",
      max_amount: "",
      usage_limit: "",
      per_user_limit: "",
      apply_to_all: true,
      equipment_type: "",
      expires_at: "",
      description: "",
      is_active: true,
    });
  };

  const startEdit = (dc: DiscountCode) => {
    setEditingCode(dc);
    setFormData({
      code: dc.code,
      discount_type: dc.discount_type,
      value: String(dc.value),
      min_amount: dc.min_amount ? String(dc.min_amount) : "",
      max_amount: dc.max_amount ? String(dc.max_amount) : "",
      usage_limit: dc.usage_limit ? String(dc.usage_limit) : "",
      per_user_limit: dc.per_user_limit ? String(dc.per_user_limit) : "",
      apply_to_all: dc.apply_to_all,
      equipment_type:
        typeof dc.equipment_type === "object" && dc.equipment_type
          ? String((dc.equipment_type as EquipmentType).id)
          : dc.equipment_type
            ? String(dc.equipment_type)
            : "",
      expires_at: dc.expires_at ? dc.expires_at.substring(0, 16) : "",
      description: dc.description || "",
      is_active: dc.is_active,
    });
    setDialogOpen(true);
  };

  const startAdd = () => {
    setEditingCode(null);
    resetForm();
    setDialogOpen(true);
  };

  if (loading && codes.length === 0) {
    return (
      <div className="flex items-center justify-center p-12">
        <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold">کدهای تخفیف</h1>
          <p className="text-muted-foreground text-sm">
            مدیریت کدهای تخفیف و ارسال به کاربران
          </p>
        </div>
        <Button onClick={startAdd}>
          <Plus className="ml-2 h-4 w-4" />
          کد جدید
        </Button>
      </div>

      <CampaignSendPanel codes={codes} />

      <Card>
        <CardHeader>
          <CardTitle>لیست کدهای تخفیف</CardTitle>
          <CardDescription>همه کدهای تخفیف ثبت‌شده در سیستم</CardDescription>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>کد</TableHead>
                <TableHead>نوع</TableHead>
                <TableHead className="text-left">مقدار</TableHead>
                <TableHead>استفاده‌شده</TableHead>
                <TableHead>وضعیت</TableHead>
                <TableHead className="text-left">عملیات</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {codes.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={6} className="text-center text-muted-foreground">
                    <TicketPercent className="mx-auto mb-2 size-8 opacity-40" />
                    هیچ کد تخفیفی ثبت نشده است.
                  </TableCell>
                </TableRow>
              ) : (
                codes.map((dc) => (
                  <TableRow key={dc.id}>
                    <TableCell className="font-mono font-medium">{dc.code}</TableCell>
                    <TableCell>
                      {dc.discount_type === "percent" ? "درصدی" : "مبلغ ثابت"}
                    </TableCell>
                    <TableCell className="text-left font-medium">
                      {toPersianDigits(formatToman(dc.value))}
                      {dc.discount_type === "percent" ? "٪" : ""}
                    </TableCell>
                    <TableCell>
                      {toPersianDigits(dc.used_count)}
                      {dc.usage_limit ? ` / ${toPersianDigits(dc.usage_limit)}` : ""}
                    </TableCell>
                    <TableCell>
                      <span
                        className={`inline-flex rounded-full px-2 py-0.5 text-xs font-medium ${
                          dc.is_active
                            ? "bg-green-100 text-green-700"
                            : "bg-red-100 text-red-700"
                        }`}
                      >
                        {dc.is_active ? "فعال" : "غیرفعال"}
                      </span>
                    </TableCell>
                    <TableCell className="text-left">
                      <Button variant="ghost" size="sm" onClick={() => startEdit(dc)}>
                        <Pencil className="h-4 w-4" />
                      </Button>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => handleDelete(dc.id)}
                        className="text-red-500 hover:text-red-700"
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      {/* دیالوگ افزودن/ویرایش */}
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-h-[85vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>{editingCode ? "ویرایش کد تخفیف" : "کد تخفیف جدید"}</DialogTitle>
            <DialogDescription>
              {editingCode
                ? "اطلاعات کد تخفیف را ویرایش کنید"
                : "کد تخفیف جدید را با مشخصات زیر ایجاد کنید"}
            </DialogDescription>
          </DialogHeader>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="code">کد تخفیف</Label>
                <Input
                  id="code"
                  value={formData.code}
                  onChange={(e) => setFormData({ ...formData, code: e.target.value.toUpperCase() })}
                  placeholder="مثلاً SUMMER40"
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="discount_type">نوع تخفیف</Label>
                <Select
                  value={formData.discount_type}
                  onValueChange={(v) => setFormData({ ...formData, discount_type: v })}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="percent">درصدی</SelectItem>
                    <SelectItem value="fixed">مبلغ ثابت (تومان)</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="value">
                  مقدار {formData.discount_type === "percent" ? "(٪)" : "(تومان)"}
                </Label>
                <Input
                  id="value"
                  type="number"
                  value={formData.value}
                  onChange={(e) => setFormData({ ...formData, value: e.target.value })}
                  placeholder={formData.discount_type === "percent" ? "مثلاً 10" : "مثلاً 50000"}
                  min="1"
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="expires_at">تاریخ انقضا (اختیاری)</Label>
                <Input
                  id="expires_at"
                  type="datetime-local"
                  value={formData.expires_at}
                  onChange={(e) => setFormData({ ...formData, expires_at: e.target.value })}
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="min_amount">حداقل مبلغ سفارش (اختیاری)</Label>
                <Input
                  id="min_amount"
                  type="number"
                  value={formData.min_amount}
                  onChange={(e) => setFormData({ ...formData, min_amount: e.target.value })}
                  placeholder="تومان"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="max_amount">حداکثر مبلغ سفارش (اختیاری)</Label>
                <Input
                  id="max_amount"
                  type="number"
                  value={formData.max_amount}
                  onChange={(e) => setFormData({ ...formData, max_amount: e.target.value })}
                  placeholder="تومان"
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="usage_limit">حداکثر استفاده کل (اختیاری)</Label>
                <Input
                  id="usage_limit"
                  type="number"
                  value={formData.usage_limit}
                  onChange={(e) => setFormData({ ...formData, usage_limit: e.target.value })}
                  placeholder="بی‌نهایت"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="per_user_limit">حداکثر استفاده هر کاربر (اختیاری)</Label>
                <Input
                  id="per_user_limit"
                  type="number"
                  value={formData.per_user_limit}
                  onChange={(e) => setFormData({ ...formData, per_user_limit: e.target.value })}
                  placeholder="بی‌نهایت"
                />
              </div>
            </div>

            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <Label htmlFor="apply_to_all">اعمال به همه تجهیزات</Label>
                <Switch
                  id="apply_to_all"
                  checked={formData.apply_to_all}
                  onCheckedChange={(checked) =>
                    setFormData({ ...formData, apply_to_all: checked })
                  }
                />
              </div>
              {!formData.apply_to_all && (
                <Select
                  value={formData.equipment_type}
                  onValueChange={(v) => setFormData({ ...formData, equipment_type: v })}
                >
                  <SelectTrigger className="w-48">
                    <SelectValue placeholder="انتخاب تجهیزات" />
                  </SelectTrigger>
                  <SelectContent>
                    {equipmentTypes.map((eq) => (
                      <SelectItem key={eq.id} value={String(eq.id)}>
                        {eq.name_fa}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              )}
            </div>

            <div className="space-y-2">
              <Label htmlFor="description">توضیحات (اختیاری)</Label>
              <Input
                id="description"
                value={formData.description}
                onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                placeholder="توضیحات داخلی"
              />
            </div>

            <div className="flex items-center justify-between">
              <Label htmlFor="is_active">فعال</Label>
              <Switch
                id="is_active"
                checked={formData.is_active}
                onCheckedChange={(checked) => setFormData({ ...formData, is_active: checked })}
              />
            </div>

            <Button type="submit" className="w-full">
              {editingCode ? "ذخیره تغییرات" : "ایجاد کد تخفیف"}
            </Button>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  );
}
// app/dashboard/admin/equipment/[id]/edit/page.tsx
"use client";

import { useState, useEffect } from "react";
import { useRouter, useParams } from "next/navigation";
import { Save, X, Trash2, Loader2, Plus, Pencil } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { toast } from "sonner";
import { parseApiError } from "@/lib/form-errors";
import { toPersianDigits } from "@/lib/utils";

// DnD Kit imports for parameter reordering
import {
  DndContext,
  closestCenter,
  KeyboardSensor,
  PointerSensor,
  useSensor,
  useSensors,
  DragEndEvent,
} from "@dnd-kit/core";
import {
  arrayMove,
  SortableContext,
  sortableKeyboardCoordinates,
  verticalListSortingStrategy,
} from "@dnd-kit/sortable";
import { useSortable } from "@dnd-kit/sortable";
import { CSS } from "@dnd-kit/utilities";

interface EquipmentType {
  id: number;
  code: string;
  name_fa: string;
  supports_install_state: boolean;
  install_state_required: boolean;
  param_schema: any;
  order: number;
}

interface Parameter {
  id: number;
  equipment_type: number;
  name: string;
  label: string;
  field_type: 'string' | 'number' | 'select' | 'boolean';
  options: string;
  required: boolean;
  order: number;
}

// کامپوننت ردیف پارامتر قابل جابجایی
function SortableParamRow({
  param,
  onEdit,
  onDelete,
}: {
  param: Parameter;
  onEdit: (param: Parameter) => void;
  onDelete: (id: number) => void;
}) {
  const {
    attributes,
    listeners,
    setNodeRef,
    transform,
    transition,
    isDragging,
  } = useSortable({ id: param.id });

  const style = {
    transform: CSS.Transform.toString(transform),
    transition,
    opacity: isDragging ? 0.5 : 1,
  };

  const fieldTypeMap = {
    string: 'متن',
    number: 'عدد',
    select: 'منوی کشویی',
    boolean: 'تیک/خیر',
  };

  return (
    <TableRow ref={setNodeRef} style={style} {...attributes}>
      <TableCell className="w-10">
        <div {...listeners} className="cursor-grab hover:text-primary">
          <span className="text-muted-foreground">⠿</span>
        </div>
      </TableCell>
      <TableCell className="font-mono text-sm">{param.name}</TableCell>
      <TableCell>{param.label}</TableCell>
      <TableCell>{fieldTypeMap[param.field_type] || param.field_type}</TableCell>
      <TableCell className="max-w-xs truncate">{param.options || '-'}</TableCell>
      <TableCell>
        {param.required ? (
          <span className="inline-flex rounded-full px-2 py-0.5 text-xs font-medium border border-red-500 text-red-700 bg-red-50">
            اجباری
          </span>
        ) : (
          <span className="inline-flex rounded-full px-2 py-0.5 text-xs font-medium border border-gray-300 text-gray-500 bg-gray-50">
            اختیاری
          </span>
        )}
      </TableCell>
      <TableCell>{toPersianDigits(param.order || 0)}</TableCell>
      <TableCell className="text-left space-x-1">
        <Button
          type="button"
          variant="ghost"
          size="sm"
          onClick={() => onEdit(param)}
        >
          <Pencil className="h-4 w-4" />
        </Button>
        <Button
          type="button"
          variant="ghost"
          size="sm"
          onClick={() => onDelete(param.id)}
          className="text-red-500 hover:text-red-700"
        >
          <Trash2 className="h-4 w-4" />
        </Button>
      </TableCell>
    </TableRow>
  );
}

export default function EditEquipmentPage() {
  const router = useRouter();
  const params = useParams();
  const id = params.id as string;

  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [item, setItem] = useState<EquipmentType | null>(null);
  const [parameters, setParameters] = useState<Parameter[]>([]);
  const [showAddDialog, setShowAddDialog] = useState(false);
  const [editingParam, setEditingParam] = useState<Parameter | null>(null);
  const [paramForm, setParamForm] = useState({
    name: "",
    label: "",
    field_type: "string" as 'string' | 'number' | 'select' | 'boolean',
    options: "",
    required: false,
    order: 0,
  });
  const [formData, setFormData] = useState({
    code: "",
    name_fa: "",
    supports_install_state: false,
    install_state_required: false,
  });
  const [reorderingParams, setReorderingParams] = useState(false);

  // Sensors for DnD
  const sensors = useSensors(
    useSensor(PointerSensor),
    useSensor(KeyboardSensor, {
      coordinateGetter: sortableKeyboardCoordinates,
    })
  );

  // دریافت اطلاعات تجهیزات و پارامترها
  useEffect(() => {
    const fetchData = async () => {
      try {
        setLoading(true);
        // دریافت اطلاعات تجهیزات
        const res = await fetch(`/api/proxy/core/equipment-types/${id}/`);
        if (!res.ok) throw new Error("خطا در دریافت اطلاعات");
        const data = await res.json();
        setItem(data);
        setFormData({
          code: data.code,
          name_fa: data.name_fa,
          supports_install_state: data.supports_install_state,
          install_state_required: data.install_state_required,
        });

        // ✅ دریافت پارامترهای این تجهیزات با اکشن اختصاصی
        const paramRes = await fetch(`/api/proxy/core/equipment-types/${id}/parameters/`);
        if (paramRes.ok) {
          const paramData = await paramRes.json();
          setParameters(Array.isArray(paramData) ? paramData : paramData.results || []);
        }
      } catch (error) {
        toast.error("خطا در دریافت اطلاعات");
        router.push("/dashboard/admin/equipment");
      } finally {
        setLoading(false);
      }
    };

    if (id) fetchData();
  }, [id, router]);

  // ذخیره اطلاعات پایه تجهیزات
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    try {
      const payload = {
        code: formData.code.trim(),
        name_fa: formData.name_fa.trim(),
        supports_install_state: formData.supports_install_state,
        install_state_required: formData.install_state_required,
      };

      const res = await fetch(`/api/proxy/core/equipment-types/${id}/`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });

      if (!res.ok) {
        const errData = await res.json().catch(() => ({}));
        throw new Error(parseApiError(errData, "خطا در ویرایش").message);
      }

      // EDRA v27 — رفع باگ (گزارش کاربر): این صفحه کاملاً client-side است
      // (useState/useEffect)، پس router.refresh() که فقط داده‌ی Server
      // Component را تازه می‌کند، هیچ تاثیری روی state محلی این صفحه
      // نداشت — فرم بعد از «ذخیره‌ی موفق» همچنان مقادیر قدیمی را نشان
      // می‌داد تا کاربر صفحه را دستی رفرش می‌کرد. حالا state مستقیماً از
      // پاسخ واقعی سرور به‌روزرسانی می‌شود.
      const updated = await res.json().catch(() => null);
      if (updated) {
        setItem(updated);
        setFormData({
          code: updated.code,
          name_fa: updated.name_fa,
          supports_install_state: updated.supports_install_state,
          install_state_required: updated.install_state_required,
        });
      }
      toast.success("نوع تجهیزات ویرایش شد");
    } catch (error: any) {
      toast.error(error.message || "خطا در ویرایش نوع تجهیزات");
    } finally {
      setSaving(false);
    }
  };

  // حذف تجهیزات
  const handleDelete = async () => {
    if (!confirm("آیا از حذف این نوع تجهیزات مطمئن هستید؟")) return;
    try {
      const res = await fetch(`/api/proxy/core/equipment-types/${id}/`, {
        method: "DELETE",
      });
      if (!res.ok) throw new Error("خطا در حذف");
      toast.success("نوع تجهیزات حذف شد");
      router.push("/dashboard/admin/equipment");
      router.refresh();
    } catch (error) {
      toast.error("خطا در حذف نوع تجهیزات");
    }
  };

  // افزودن پارامتر جدید
  const handleAddParameter = async () => {
    try {
      const payload = {
        equipment_type: parseInt(id),
        name: paramForm.name.trim(),
        label: paramForm.label.trim(),
        field_type: paramForm.field_type,
        options: paramForm.options.trim() || "",
        required: paramForm.required,
        order: paramForm.order || parameters.length,
      };

      const res = await fetch("/api/proxy/core/parameters/", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });

      if (!res.ok) {
        const errData = await res.json().catch(() => ({}));
        throw new Error(parseApiError(errData, "خطا در افزودن پارامتر").message);
      }

      const newParam = await res.json();
      setParameters([...parameters, newParam]);
      toast.success("پارامتر با موفقیت افزوده شد");
      setShowAddDialog(false);
      resetParamForm();
    } catch (error: any) {
      toast.error(error.message || "خطا در افزودن پارامتر");
    }
  };

  // ویرایش پارامتر
  const handleEditParameter = async () => {
    if (!editingParam) return;
    try {
      const payload = {
        equipment_type: parseInt(id),
        name: paramForm.name.trim(),
        label: paramForm.label.trim(),
        field_type: paramForm.field_type,
        options: paramForm.options.trim() || "",
        required: paramForm.required,
        order: paramForm.order || 0,
      };

      const res = await fetch(`/api/proxy/core/parameters/${editingParam.id}/`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });

      if (!res.ok) {
        const errData = await res.json().catch(() => ({}));
        throw new Error(parseApiError(errData, "خطا در ویرایش پارامتر").message);
      }

      const updatedParam = await res.json();
      setParameters(parameters.map(p => p.id === updatedParam.id ? updatedParam : p));
      toast.success("پارامتر با موفقیت ویرایش شد");
      setShowAddDialog(false);
      setEditingParam(null);
      resetParamForm();
    } catch (error: any) {
      toast.error(error.message || "خطا در ویرایش پارامتر");
    }
  };

  // حذف پارامتر با AJAX
  const handleDeleteParameter = async (paramId: number) => {
    if (!confirm("آیا از حذف این پارامتر مطمئن هستید؟")) return;
    try {
      const res = await fetch(`/api/proxy/core/parameters/${paramId}/`, {
        method: "DELETE",
      });

      if (!res.ok) {
        const errData = await res.json().catch(() => ({}));
        throw new Error(parseApiError(errData, "خطا در حذف پارامتر").message);
      }

      setParameters(parameters.filter(p => p.id !== paramId));
      toast.success("پارامتر با موفقیت حذف شد");
    } catch (error: any) {
      toast.error(error.message || "خطا در حذف پارامتر");
    }
  };

  // جابه‌جایی پارامترها با DnD
  const handleParamDragEnd = async (event: DragEndEvent) => {
    const { active, over } = event;
    if (!over || active.id === over.id) return;

    setReorderingParams(true);
    try {
      const oldIndex = parameters.findIndex((p) => p.id === active.id);
      const newIndex = parameters.findIndex((p) => p.id === over.id);
      const newParams = arrayMove(parameters, oldIndex, newIndex);
      setParameters(newParams);

      // EDRA v27 — رفع باگ (گزارش کاربر): قبلاً هیچ درخواستی به بک‌اند
      // ارسال نمی‌شد و فقط یک toast موفقیت جعلی نشان داده می‌شد؛ بعد از
      // رفرش صفحه، ترتیب به حالت قبل برمی‌گشت چون هیچ‌چیز ذخیره نشده
      // بود. اکشن reorder روی EquipmentParameterViewSet هم در همین
      // نشست اضافه شد.
      const orderedIds = newParams.map((p) => p.id);
      const res = await fetch("/api/proxy/core/parameters/reorder/", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ ids: orderedIds }),
      });
      if (!res.ok) {
        const errData = await res.json().catch(() => ({}));
        throw new Error(errData.error || "خطا در ذخیره‌ی ترتیب");
      }
      toast.success("ترتیب پارامترها با موفقیت ذخیره شد");
    } catch (error) {
      toast.error("خطا در تغییر ترتیب");
      // بازگردانی
      const paramRes = await fetch(`/api/proxy/core/equipment-types/${id}/parameters/`);
      if (paramRes.ok) {
        const paramData = await paramRes.json();
        setParameters(Array.isArray(paramData) ? paramData : paramData.results || []);
      }
    } finally {
      setReorderingParams(false);
    }
  };

  const resetParamForm = () => {
    setParamForm({
      name: "",
      label: "",
      field_type: "string",
      options: "",
      required: false,
      order: 0,
    });
  };

  const openAddDialog = () => {
    setEditingParam(null);
    resetParamForm();
    setShowAddDialog(true);
  };

  const openEditDialog = (param: Parameter) => {
    setEditingParam(param);
    setParamForm({
      name: param.name,
      label: param.label,
      field_type: param.field_type,
      options: param.options || "",
      required: param.required,
      order: param.order || 0,
    });
    setShowAddDialog(true);
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center p-12">
        <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
      </div>
    );
  }

  if (!item) {
    return (
      <div className="flex items-center justify-center p-12 text-muted-foreground">
        نوع تجهیزات یافت نشد.
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* هدر صفحه */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold">تغییر نوع تجهیزات</h1>
          <p className="text-muted-foreground text-sm">{item.name_fa}</p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" onClick={() => router.back()}>
            <X className="ml-2 h-4 w-4" />
            انصراف
          </Button>
        </div>
      </div>

      <form onSubmit={handleSubmit}>
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* اطلاعات پایه */}
          <Card>
            <CardHeader>
              <CardTitle>اطلاعات پایه</CardTitle>
              <CardDescription>مشخصات نوع تجهیزات</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="code">کد</Label>
                <Input
                  id="code"
                  value={formData.code}
                  onChange={(e) =>
                    setFormData({ ...formData, code: e.target.value })
                  }
                  placeholder="مثلاً forklift"
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="name_fa">نام فارسی</Label>
                <Input
                  id="name_fa"
                  value={formData.name_fa}
                  onChange={(e) =>
                    setFormData({ ...formData, name_fa: e.target.value })
                  }
                  placeholder="مثلاً لیفتراک"
                  required
                />
              </div>
            </CardContent>
          </Card>

          {/* وضعیت نصب */}
          <Card>
            <CardHeader>
              <CardTitle>وضعیت نصب</CardTitle>
              <CardDescription>تنظیمات مربوط به وضعیت نصب تجهیزات</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between">
                <Label htmlFor="supports_install_state">پشتیبانی از وضعیت نصب</Label>
                <Switch
                  id="supports_install_state"
                  checked={formData.supports_install_state}
                  onCheckedChange={(checked) =>
                    setFormData({ ...formData, supports_install_state: checked })
                  }
                />
              </div>

              <div className="flex items-center justify-between">
                <Label htmlFor="install_state_required">وضعیت نصب اجباری</Label>
                <Switch
                  id="install_state_required"
                  checked={formData.install_state_required}
                  onCheckedChange={(checked) =>
                    setFormData({ ...formData, install_state_required: checked })
                  }
                />
              </div>
            </CardContent>
          </Card>

          {/* شِمای پارامترها */}
          <Card className="lg:col-span-2">
            <CardHeader>
              <CardTitle>پارامترها</CardTitle>
              <CardDescription>
                مدیریت پارامترهای این نوع تجهیزات
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {/* نمایش شمای پارامترها (فقط برای نمایش) */}
              <div className="rounded-lg bg-muted p-4">
                <Label className="text-sm font-medium">شِمای پارامترها:</Label>
                <pre className="mt-2 text-xs bg-background p-3 rounded-md overflow-x-auto">
                  {JSON.stringify(item.param_schema || [], null, 2)}
                </pre>
                <p className="text-xs text-muted-foreground mt-2">
                  این فیلد به‌صورت خودکار توسط سیگنال‌ها به‌روز می‌شود
                </p>
              </div>

              {/* لیست پارامترها */}
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <h3 className="text-sm font-medium">پارامترهای تجهیزات</h3>
                  <Button type="button" size="sm" onClick={openAddDialog}>
                    <Plus className="ml-1 h-4 w-4" />
                    افزودن پارامتر
                  </Button>
                </div>

                {parameters.length === 0 ? (
                  <p className="text-sm text-muted-foreground text-center py-4">
                    هیچ پارامتری برای این تجهیزات تعریف نشده است.
                  </p>
                ) : (
                  <DndContext
                    sensors={sensors}
                    collisionDetection={closestCenter}
                    onDragEnd={handleParamDragEnd}
                  >
                    <SortableContext
                      items={parameters.map((p) => p.id)}
                      strategy={verticalListSortingStrategy}
                    >
                      <Table>
                        <TableHeader>
                          <TableRow>
                            <TableHead className="w-10"></TableHead>
                            <TableHead>نام متغیر (انگلیسی)</TableHead>
                            <TableHead>برچسب (فارسی)</TableHead>
                            <TableHead>نوع فیلد</TableHead>
                            <TableHead>گزینه‌ها</TableHead>
                            <TableHead>اجباری</TableHead>
                            <TableHead>ترتیب</TableHead>
                            <TableHead className="text-left">عملیات</TableHead>
                          </TableRow>
                        </TableHeader>
                        <TableBody>
                          {parameters.map((param) => (
                            <SortableParamRow
                              key={param.id}
                              param={param}
                              onEdit={openEditDialog}
                              onDelete={handleDeleteParameter}
                            />
                          ))}
                        </TableBody>
                      </Table>
                    </SortableContext>
                  </DndContext>
                )}
                {reorderingParams && (
                  <p className="text-xs text-muted-foreground text-center">
                    در حال ذخیره‌سازی ترتیب پارامترها...
                  </p>
                )}
              </div>
            </CardContent>
          </Card>

          {/* دکمه‌های پایین */}
          <div className="lg:col-span-2 space-y-4">
            <Card className="border-red-200">
              <CardContent className="pt-6">
                <Button
                  type="button"
                  variant="destructive"
                  onClick={handleDelete}
                  className="w-full"
                >
                  <Trash2 className="ml-2 h-4 w-4" />
                  حذف نوع تجهیزات
                </Button>
                <p className="text-xs text-muted-foreground mt-2 text-center">
                  با حذف این نوع تجهیزات، تمام پارامترهای مرتبط نیز حذف می‌شوند.
                </p>
              </CardContent>
            </Card>

            <Button type="submit" className="w-full" disabled={saving}>
              <Save className="ml-2 h-4 w-4" />
              {saving ? "در حال ذخیره..." : "ذخیره تغییرات"}
            </Button>
          </div>
        </div>
      </form>

      {/* دیالوگ افزودن/ویرایش پارامتر */}
      <Dialog open={showAddDialog} onOpenChange={setShowAddDialog}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle>
              {editingParam ? "ویرایش پارامتر" : "افزودن پارامتر جدید"}
            </DialogTitle>
            <DialogDescription>
              {editingParam
                ? "اطلاعات پارامتر را ویرایش کنید"
                : "پارامتر جدید را برای این نوع تجهیزات تعریف کنید"}
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="param_name">نام متغیر (انگلیسی)</Label>
              <Input
                id="param_name"
                value={paramForm.name}
                onChange={(e) =>
                  setParamForm({ ...paramForm, name: e.target.value })
                }
                placeholder="مثلاً capacity"
                required
              />
              <p className="text-xs text-muted-foreground">
                نام متغیر باید به انگلیسی و بدون فاصله باشد
              </p>
            </div>

            <div className="space-y-2">
              <Label htmlFor="param_label">برچسب (فارسی)</Label>
              <Input
                id="param_label"
                value={paramForm.label}
                onChange={(e) =>
                  setParamForm({ ...paramForm, label: e.target.value })
                }
                placeholder="مثلاً ظرفیت (تن)"
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="param_field_type">نوع فیلد</Label>
              <Select
                value={paramForm.field_type}
                onValueChange={(value: any) =>
                  setParamForm({ ...paramForm, field_type: value })
                }
              >
                <SelectTrigger id="param_field_type">
                  <SelectValue placeholder="نوع فیلد را انتخاب کنید" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="string">متن</SelectItem>
                  <SelectItem value="number">عدد</SelectItem>
                  <SelectItem value="select">منوی کشویی</SelectItem>
                  <SelectItem value="boolean">تیک/خیر</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {paramForm.field_type === 'select' && (
              <div className="space-y-2">
                <Label htmlFor="param_options">گزینه‌ها</Label>
                <Input
                  id="param_options"
                  value={paramForm.options}
                  onChange={(e) =>
                    setParamForm({ ...paramForm, options: e.target.value })
                  }
                  placeholder="مثلاً 1,2,3,5,10"
                />
                <p className="text-xs text-muted-foreground">
                  گزینه‌های منوی کشویی را با کاما جدا کنید
                </p>
              </div>
            )}

            <div className="flex items-center justify-between">
              <Label htmlFor="param_required">اجباری</Label>
              <Switch
                id="param_required"
                checked={paramForm.required}
                onCheckedChange={(checked) =>
                  setParamForm({ ...paramForm, required: checked })
                }
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="param_order">ترتیب نمایش</Label>
              <Input
                id="param_order"
                type="number"
                value={paramForm.order}
                onChange={(e) =>
                  setParamForm({ ...paramForm, order: parseInt(e.target.value) || 0 })
                }
                min="0"
              />
            </div>

            <Button
              type="button"
              className="w-full"
              onClick={editingParam ? handleEditParameter : handleAddParameter}
            >
              {editingParam ? "ویرایش پارامتر" : "افزودن پارامتر"}
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
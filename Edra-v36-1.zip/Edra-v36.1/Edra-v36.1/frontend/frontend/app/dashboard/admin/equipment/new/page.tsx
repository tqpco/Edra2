// app/dashboard/admin/equipment/new/page.tsx
"use client";

import { useState, useEffect } from "react";
import { useRouter } from "next/navigation";
import { Save, X, Trash2, Loader2, Plus, Pencil, CheckCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { toast } from "sonner";
import { parseApiError } from "@/lib/form-errors";
import { toPersianDigits } from "@/lib/utils";

// DnD Kit imports for parameter reordering
import {
  DndContext,
  closestCenter,
  KeyboardSensor,
  PointerSensor,
  useSensor,
  useSensors,
  DragEndEvent,
} from "@dnd-kit/core";
import {
  arrayMove,
  SortableContext,
  sortableKeyboardCoordinates,
  verticalListSortingStrategy,
} from "@dnd-kit/sortable";
import { useSortable } from "@dnd-kit/sortable";
import { CSS } from "@dnd-kit/utilities";

interface EquipmentType {
  id: number;
  code: string;
  name_fa: string;
  supports_install_state: boolean;
  install_state_required: boolean;
  param_schema: any;
  order: number;
}

interface Parameter {
  id: number;
  equipment_type: number;
  name: string;
  label: string;
  field_type: 'string' | 'number' | 'select' | 'boolean';
  options: string;
  required: boolean;
  order: number;
}

// کامپوننت ردیف پارامتر قابل جابجایی
function SortableParamRow({
  param,
  onEdit,
  onDelete,
}: {
  param: Parameter;
  onEdit: (param: Parameter) => void;
  onDelete: (id: number) => void;
}) {
  const {
    attributes,
    listeners,
    setNodeRef,
    transform,
    transition,
    isDragging,
  } = useSortable({ id: param.id });

  const style = {
    transform: CSS.Transform.toString(transform),
    transition,
    opacity: isDragging ? 0.5 : 1,
  };

  const fieldTypeMap = {
    string: 'متن',
    number: 'عدد',
    select: 'منوی کشویی',
    boolean: 'تیک/خیر',
  };

  return (
    <TableRow ref={setNodeRef} style={style} {...attributes}>
      <TableCell className="w-10">
        <div {...listeners} className="cursor-grab hover:text-primary">
          <span className="text-muted-foreground">⠿</span>
        </div>
      </TableCell>
      <TableCell className="font-mono text-sm">{param.name}</TableCell>
      <TableCell>{param.label}</TableCell>
      <TableCell>{fieldTypeMap[param.field_type] || param.field_type}</TableCell>
      <TableCell className="max-w-xs truncate">{param.options || '-'}</TableCell>
      <TableCell>
        {param.required ? (
          <span className="inline-flex rounded-full px-2 py-0.5 text-xs font-medium border border-red-500 text-red-700 bg-red-50">
            اجباری
          </span>
        ) : (
          <span className="inline-flex rounded-full px-2 py-0.5 text-xs font-medium border border-gray-300 text-gray-500 bg-gray-50">
            اختیاری
          </span>
        )}
      </TableCell>
      <TableCell>{toPersianDigits(param.order || 0)}</TableCell>
      <TableCell className="text-left space-x-1">
        <Button
          type="button"
          variant="ghost"
          size="sm"
          onClick={() => onEdit(param)}
        >
          <Pencil className="h-4 w-4" />
        </Button>
        <Button
          type="button"
          variant="ghost"
          size="sm"
          onClick={() => onDelete(param.id)}
          className="text-red-500 hover:text-red-700"
        >
          <Trash2 className="h-4 w-4" />
        </Button>
      </TableCell>
    </TableRow>
  );
}

export default function NewEquipmentPage() {
  const router = useRouter();
  const [loading, setLoading] = useState(false);
  const [isCreated, setIsCreated] = useState(false);
  const [equipmentId, setEquipmentId] = useState<number | null>(null);
  const [item, setItem] = useState<EquipmentType | null>(null);
  const [parameters, setParameters] = useState<Parameter[]>([]);
  const [showAddDialog, setShowAddDialog] = useState(false);
  const [editingParam, setEditingParam] = useState<Parameter | null>(null);
  const [paramForm, setParamForm] = useState({
    name: "",
    label: "",
    field_type: "string" as 'string' | 'number' | 'select' | 'boolean',
    options: "",
    required: false,
    order: 0,
  });
  const [formData, setFormData] = useState({
    code: "",
    name_fa: "",
    supports_install_state: false,
    install_state_required: false,
  });
  const [reorderingParams, setReorderingParams] = useState(false);
  const [fetchingParams, setFetchingParams] = useState(false);

  // Sensors for DnD
  const sensors = useSensors(
    useSensor(PointerSensor),
    useSensor(KeyboardSensor, {
      coordinateGetter: sortableKeyboardCoordinates,
    })
  );

  // دریافت پارامترها پس از ایجاد تجهیزات
  useEffect(() => {
    const fetchParameters = async () => {
      if (!equipmentId) return;
      setFetchingParams(true);
      try {
        const paramRes = await fetch(`/api/proxy/core/equipment-types/${equipmentId}/parameters/`);
        if (paramRes.ok) {
          const paramData = await paramRes.json();
          setParameters(Array.isArray(paramData) ? paramData : paramData.results || []);
        }
      } catch (error) {
        toast.error("خطا در دریافت پارامترها");
      } finally {
        setFetchingParams(false);
      }
    };

    if (equipmentId) {
      fetchParameters();
    }
  }, [equipmentId]);

  // ایجاد تجهیزات جدید
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      const payload = {
        code: formData.code.trim(),
        name_fa: formData.name_fa.trim(),
        supports_install_state: formData.supports_install_state,
        install_state_required: formData.install_state_required,
      };

      const res = await fetch("/api/proxy/core/equipment-types/", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });

      if (!res.ok) {
        const errData = await res.json().catch(() => ({}));
        throw new Error(parseApiError(errData, "خطا در ذخیره‌سازی").message);
      }

      const data = await res.json();
      setEquipmentId(data.id);
      setItem(data);
      setIsCreated(true);
      toast.success("نوع تجهیزات جدید با موفقیت ایجاد شد");
    } catch (error: any) {
      toast.error(error.message || "خطا در ایجاد نوع تجهیزات");
    } finally {
      setLoading(false);
    }
  };

  // افزودن پارامتر جدید
  const handleAddParameter = async () => {
    if (!equipmentId) return;
    try {
      const payload = {
        equipment_type: equipmentId,
        name: paramForm.name.trim(),
        label: paramForm.label.trim(),
        field_type: paramForm.field_type,
        options: paramForm.options.trim() || "",
        required: paramForm.required,
        order: paramForm.order || parameters.length,
      };

      const res = await fetch("/api/proxy/core/parameters/", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });

      if (!res.ok) {
        const errData = await res.json().catch(() => ({}));
        throw new Error(parseApiError(errData, "خطا در افزودن پارامتر").message);
      }

      const newParam = await res.json();
      setParameters([...parameters, newParam]);
      toast.success("پارامتر با موفقیت افزوده شد");
      setShowAddDialog(false);
      resetParamForm();

      // به‌روزرسانی param_schema در آیتم
      updateItemSchema([...parameters, newParam]);
    } catch (error: any) {
      toast.error(error.message || "خطا در افزودن پارامتر");
    }
  };

  // ویرایش پارامتر
  const handleEditParameter = async () => {
    if (!editingParam) return;
    try {
      const payload = {
        equipment_type: equipmentId,
        name: paramForm.name.trim(),
        label: paramForm.label.trim(),
        field_type: paramForm.field_type,
        options: paramForm.options.trim() || "",
        required: paramForm.required,
        order: paramForm.order || 0,
      };

      const res = await fetch(`/api/proxy/core/parameters/${editingParam.id}/`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });

      if (!res.ok) {
        const errData = await res.json().catch(() => ({}));
        throw new Error(parseApiError(errData, "خطا در ویرایش پارامتر").message);
      }

      const updatedParam = await res.json();
      const newParams = parameters.map(p => p.id === updatedParam.id ? updatedParam : p);
      setParameters(newParams);
      toast.success("پارامتر با موفقیت ویرایش شد");
      setShowAddDialog(false);
      setEditingParam(null);
      resetParamForm();

      // به‌روزرسانی param_schema در آیتم
      updateItemSchema(newParams);
    } catch (error: any) {
      toast.error(error.message || "خطا در ویرایش پارامتر");
    }
  };

  // حذف پارامتر
  const handleDeleteParameter = async (paramId: number) => {
    if (!confirm("آیا از حذف این پارامتر مطمئن هستید؟")) return;
    try {
      const res = await fetch(`/api/proxy/core/parameters/${paramId}/`, {
        method: "DELETE",
      });

      if (!res.ok) {
        const errData = await res.json().catch(() => ({}));
        throw new Error(parseApiError(errData, "خطا در حذف پارامتر").message);
      }

      const newParams = parameters.filter(p => p.id !== paramId);
      setParameters(newParams);
      toast.success("پارامتر با موفقیت حذف شد");

      // به‌روزرسانی param_schema در آیتم
      updateItemSchema(newParams);
    } catch (error: any) {
      toast.error(error.message || "خطا در حذف پارامتر");
    }
  };

  // به‌روزرسانی param_schema
  const updateItemSchema = (params: Parameter[]) => {
    if (item) {
      const schema = params.map(p => ({
        name: p.name,
        label: p.label,
        type: p.field_type,
        required: p.required,
        options: p.field_type === 'select' && p.options ? p.options.split(',').map(s => s.trim()) : undefined,
      }));
      setItem({ ...item, param_schema: schema });
    }
  };

  // جابه‌جایی پارامترها
  const handleParamDragEnd = async (event: DragEndEvent) => {
    const { active, over } = event;
    if (!over || active.id === over.id) return;

    setReorderingParams(true);
    try {
      const oldIndex = parameters.findIndex((p) => p.id === active.id);
      const newIndex = parameters.findIndex((p) => p.id === over.id);
      const newParams = arrayMove(parameters, oldIndex, newIndex);
      setParameters(newParams);
      toast.success("ترتیب پارامترها به‌روز شد");
    } catch (error) {
      toast.error("خطا در تغییر ترتیب");
      // بازگردانی
      const paramRes = await fetch(`/api/proxy/core/equipment-types/${equipmentId}/parameters/`);
      if (paramRes.ok) {
        const paramData = await paramRes.json();
        setParameters(Array.isArray(paramData) ? paramData : paramData.results || []);
      }
    } finally {
      setReorderingParams(false);
    }
  };

  const resetParamForm = () => {
    setParamForm({
      name: "",
      label: "",
      field_type: "string",
      options: "",
      required: false,
      order: 0,
    });
  };

  const openAddDialog = () => {
    setEditingParam(null);
    resetParamForm();
    setShowAddDialog(true);
  };

  const openEditDialog = (param: Parameter) => {
    setEditingParam(param);
    setParamForm({
      name: param.name,
      label: param.label,
      field_type: param.field_type,
      options: param.options || "",
      required: param.required,
      order: param.order || 0,
    });
    setShowAddDialog(true);
  };

  const handleCancel = () => {
    if (isCreated) {
      router.push("/dashboard/admin/equipment");
    } else {
      router.back();
    }
  };

  return (
    <div className="space-y-6">
      {/* هدر صفحه */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold">
            {isCreated ? `ویرایش نوع تجهیزات: ${item?.name_fa || ''}` : "افزودن نوع تجهیزات جدید"}
          </h1>
          <p className="text-muted-foreground text-sm">
            {isCreated 
              ? "مدیریت اطلاعات و پارامترهای این نوع تجهیزات" 
              : "اطلاعات نوع تجهیزات جدید را وارد کنید"}
          </p>
          {isCreated && (
            <div className="flex items-center gap-2 mt-1">
              <CheckCircle className="h-4 w-4 text-green-500" />
              <span className="text-xs text-green-600">تجهیزات با موفقیت ایجاد شد</span>
            </div>
          )}
        </div>
        <div className="flex gap-2">
          <Button variant="outline" onClick={handleCancel}>
            <X className="ml-2 h-4 w-4" />
            {isCreated ? "بازگشت به لیست" : "انصراف"}
          </Button>
          {isCreated && (
            <Button variant="outline" onClick={() => router.push(`/dashboard/admin/equipment/${equipmentId}/edit`)}>
              رفتن به صفحه ویرایش کامل
            </Button>
          )}
        </div>
      </div>

      <form onSubmit={!isCreated ? handleSubmit : (e) => e.preventDefault()}>
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* اطلاعات پایه */}
          <Card>
            <CardHeader>
              <CardTitle>اطلاعات پایه</CardTitle>
              <CardDescription>مشخصات نوع تجهیزات</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="code">کد</Label>
                <Input
                  id="code"
                  value={formData.code}
                  onChange={(e) =>
                    setFormData({ ...formData, code: e.target.value })
                  }
                  placeholder="مثلاً forklift"
                  required
                  disabled={isCreated}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="name_fa">نام فارسی</Label>
                <Input
                  id="name_fa"
                  value={formData.name_fa}
                  onChange={(e) =>
                    setFormData({ ...formData, name_fa: e.target.value })
                  }
                  placeholder="مثلاً لیفتراک"
                  required
                  disabled={isCreated}
                />
              </div>
            </CardContent>
          </Card>

          {/* وضعیت نصب */}
          <Card>
            <CardHeader>
              <CardTitle>وضعیت نصب</CardTitle>
              <CardDescription>تنظیمات مربوط به وضعیت نصب تجهیزات</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between">
                <Label htmlFor="supports_install_state">پشتیبانی از وضعیت نصب</Label>
                <Switch
                  id="supports_install_state"
                  checked={formData.supports_install_state}
                  onCheckedChange={(checked) =>
                    setFormData({ ...formData, supports_install_state: checked })
                  }
                  disabled={isCreated}
                />
              </div>

              <div className="flex items-center justify-between">
                <Label htmlFor="install_state_required">وضعیت نصب اجباری</Label>
                <Switch
                  id="install_state_required"
                  checked={formData.install_state_required}
                  onCheckedChange={(checked) =>
                    setFormData({ ...formData, install_state_required: checked })
                  }
                  disabled={isCreated}
                />
              </div>
            </CardContent>
          </Card>

          {/* پارامترها */}
          <Card className="lg:col-span-2">
            <CardHeader>
              <CardTitle>پارامترها</CardTitle>
              <CardDescription>
                {isCreated 
                  ? "مدیریت پارامترهای این نوع تجهیزات" 
                  : "پس از ایجاد تجهیزات، می‌توانید پارامترها را مدیریت کنید"}
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {/* نمایش شِمای پارامترها */}
              <div className="rounded-lg bg-muted p-4">
                <Label className="text-sm font-medium">شِمای پارامترها:</Label>
                <pre className="mt-2 text-xs bg-background p-3 rounded-md overflow-x-auto">
                  {JSON.stringify(item?.param_schema || [], null, 2)}
                </pre>
                <p className="text-xs text-muted-foreground mt-2">
                  این فیلد به‌صورت خودکار توسط سیگنال‌ها به‌روز می‌شود
                </p>
              </div>

              {/* لیست پارامترها */}
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <h3 className="text-sm font-medium">پارامترهای تجهیزات</h3>
                  <Button 
                    type="button" 
                    size="sm" 
                    onClick={openAddDialog}
                    disabled={!isCreated}
                  >
                    <Plus className="ml-1 h-4 w-4" />
                    افزودن پارامتر
                  </Button>
                </div>

                {!isCreated ? (
                  <div className="p-4 border border-dashed rounded-lg text-center text-muted-foreground">
                    <p className="text-sm">برای افزودن پارامتر، ابتدا نوع تجهیزات را ایجاد کنید.</p>
                    <p className="text-xs mt-1">پس از ایجاد، فرم پارامترها فعال می‌شود.</p>
                  </div>
                ) : fetchingParams ? (
                  <div className="flex items-center justify-center p-8">
                    <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
                  </div>
                ) : parameters.length === 0 ? (
                  <p className="text-sm text-muted-foreground text-center py-4">
                    هیچ پارامتری برای این تجهیزات تعریف نشده است.
                  </p>
                ) : (
                  <DndContext
                    sensors={sensors}
                    collisionDetection={closestCenter}
                    onDragEnd={handleParamDragEnd}
                  >
                    <SortableContext
                      items={parameters.map((p) => p.id)}
                      strategy={verticalListSortingStrategy}
                    >
                      <Table>
                        <TableHeader>
                          <TableRow>
                            <TableHead className="w-10"></TableHead>
                            <TableHead>نام متغیر (انگلیسی)</TableHead>
                            <TableHead>برچسب (فارسی)</TableHead>
                            <TableHead>نوع فیلد</TableHead>
                            <TableHead>گزینه‌ها</TableHead>
                            <TableHead>اجباری</TableHead>
                            <TableHead>ترتیب</TableHead>
                            <TableHead className="text-left">عملیات</TableHead>
                          </TableRow>
                        </TableHeader>
                        <TableBody>
                          {parameters.map((param) => (
                            <SortableParamRow
                              key={param.id}
                              param={param}
                              onEdit={openEditDialog}
                              onDelete={handleDeleteParameter}
                            />
                          ))}
                        </TableBody>
                      </Table>
                    </SortableContext>
                  </DndContext>
                )}
                {reorderingParams && (
                  <p className="text-xs text-muted-foreground text-center">
                    در حال ذخیره‌سازی ترتیب پارامترها...
                  </p>
                )}
              </div>
            </CardContent>
          </Card>

          {/* دکمه‌های پایین */}
          <div className="lg:col-span-2 space-y-4">
            {!isCreated && (
              <Button type="submit" className="w-full" disabled={loading}>
                <Save className="ml-2 h-4 w-4" />
                {loading ? "در حال ایجاد..." : "ایجاد نوع تجهیزات"}
              </Button>
            )}
            {isCreated && (
              <div className="flex gap-4">
                <Button 
                  type="button" 
                  className="flex-1" 
                  onClick={() => router.push("/dashboard/admin/equipment")}
                >
                  بازگشت به لیست تجهیزات
                </Button>
                <Button 
                  type="button" 
                  variant="outline" 
                  className="flex-1"
                  onClick={() => router.push(`/dashboard/admin/equipment/${equipmentId}/edit`)}
                >
                  رفتن به صفحه ویرایش کامل
                </Button>
              </div>
            )}
          </div>
        </div>
      </form>

      {/* دیالوگ افزودن/ویرایش پارامتر */}
      <Dialog open={showAddDialog} onOpenChange={setShowAddDialog}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle>
              {editingParam ? "ویرایش پارامتر" : "افزودن پارامتر جدید"}
            </DialogTitle>
            <DialogDescription>
              {editingParam
                ? "اطلاعات پارامتر را ویرایش کنید"
                : "پارامتر جدید را برای این نوع تجهیزات تعریف کنید"}
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="param_name">نام متغیر (انگلیسی)</Label>
              <Input
                id="param_name"
                value={paramForm.name}
                onChange={(e) =>
                  setParamForm({ ...paramForm, name: e.target.value })
                }
                placeholder="مثلاً capacity"
                required
              />
              <p className="text-xs text-muted-foreground">
                نام متغیر باید به انگلیسی و بدون فاصله باشد
              </p>
            </div>

            <div className="space-y-2">
              <Label htmlFor="param_label">برچسب (فارسی)</Label>
              <Input
                id="param_label"
                value={paramForm.label}
                onChange={(e) =>
                  setParamForm({ ...paramForm, label: e.target.value })
                }
                placeholder="مثلاً ظرفیت (تن)"
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="param_field_type">نوع فیلد</Label>
              <Select
                value={paramForm.field_type}
                onValueChange={(value: any) =>
                  setParamForm({ ...paramForm, field_type: value })
                }
              >
                <SelectTrigger id="param_field_type">
                  <SelectValue placeholder="نوع فیلد را انتخاب کنید" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="string">متن</SelectItem>
                  <SelectItem value="number">عدد</SelectItem>
                  <SelectItem value="select">منوی کشویی</SelectItem>
                  <SelectItem value="boolean">تیک/خیر</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {paramForm.field_type === 'select' && (
              <div className="space-y-2">
                <Label htmlFor="param_options">گزینه‌ها</Label>
                <Input
                  id="param_options"
                  value={paramForm.options}
                  onChange={(e) =>
                    setParamForm({ ...paramForm, options: e.target.value })
                  }
                  placeholder="مثلاً 1,2,3,5,10"
                />
                <p className="text-xs text-muted-foreground">
                  گزینه‌های منوی کشویی را با کاما جدا کنید
                </p>
              </div>
            )}

            <div className="flex items-center justify-between">
              <Label htmlFor="param_required">اجباری</Label>
              <Switch
                id="param_required"
                checked={paramForm.required}
                onCheckedChange={(checked) =>
                  setParamForm({ ...paramForm, required: checked })
                }
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="param_order">ترتیب نمایش</Label>
              <Input
                id="param_order"
                type="number"
                value={paramForm.order}
                onChange={(e) =>
                  setParamForm({ ...paramForm, order: parseInt(e.target.value) || 0 })
                }
                min="0"
              />
            </div>

            <Button
              type="button"
              className="w-full"
              onClick={editingParam ? handleEditParameter : handleAddParameter}
            >
              {editingParam ? "ویرایش پارامتر" : "افزودن پارامتر"}
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
// app/dashboard/admin/equipment/page.tsx
"use client";

import { useState, useEffect } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { Plus, Pencil, Trash2, Loader2, GripVertical } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { toast } from "sonner";
import { toPersianDigits } from "@/lib/utils";

// DnD Kit imports
import {
  DndContext,
  closestCenter,
  KeyboardSensor,
  PointerSensor,
  useSensor,
  useSensors,
  DragEndEvent,
} from "@dnd-kit/core";
import {
  arrayMove,
  SortableContext,
  sortableKeyboardCoordinates,
  verticalListSortingStrategy,
} from "@dnd-kit/sortable";
import { useSortable } from "@dnd-kit/sortable";
import { CSS } from "@dnd-kit/utilities";

interface EquipmentType {
  id: number;
  code: string;
  name_fa: string;
  supports_install_state: boolean;
  install_state_required: boolean;
  param_schema: any;
  order: number;
}

// کامپوننت ردیف قابل جابجایی
function SortableRow({
  item,
  onEdit,
  onDelete,
}: {
  item: EquipmentType;
  onEdit: (id: number) => void;
  onDelete: (id: number) => void;
}) {
  const {
    attributes,
    listeners,
    setNodeRef,
    transform,
    transition,
    isDragging,
  } = useSortable({ id: item.id });

  const style = {
    transform: CSS.Transform.toString(transform),
    transition,
    opacity: isDragging ? 0.5 : 1,
  };

  return (
    <TableRow ref={setNodeRef} style={style} {...attributes}>
      <TableCell className="w-10">
        <div {...listeners} className="cursor-grab hover:text-primary">
          <GripVertical className="h-4 w-4 text-muted-foreground" />
        </div>
      </TableCell>
      <TableCell>{toPersianDigits(item.id)}</TableCell>
      <TableCell className="font-medium">{item.code}</TableCell>
      <TableCell className="font-medium">{item.name_fa}</TableCell>
      <TableCell>
        {item.supports_install_state ? (
          <span className="inline-flex rounded-full px-2 py-0.5 text-xs font-medium border border-green-500 text-green-700 bg-green-50">
            بله
          </span>
        ) : (
          <span className="inline-flex rounded-full px-2 py-0.5 text-xs font-medium border border-gray-300 text-gray-500 bg-gray-50">
            خیر
          </span>
        )}
      </TableCell>
      <TableCell>
        {item.install_state_required ? (
          <span className="inline-flex rounded-full px-2 py-0.5 text-xs font-medium border border-blue-500 text-blue-700 bg-blue-50">
            اجباری
          </span>
        ) : (
          <span className="inline-flex rounded-full px-2 py-0.5 text-xs font-medium border border-gray-300 text-gray-500 bg-gray-50">
            اختیاری
          </span>
        )}
      </TableCell>
      <TableCell>
        <span className="inline-flex rounded-full px-2 py-0.5 text-xs font-medium border border-purple-500 text-purple-700 bg-purple-50">
          {item.param_schema?.length || 0} پارامتر
        </span>
      </TableCell>
      <TableCell className="text-left">
        <Button variant="ghost" size="sm" onClick={() => onEdit(item.id)}>
          <Pencil className="h-4 w-4" />
        </Button>
        <Button
          variant="ghost"
          size="sm"
          onClick={() => onDelete(item.id)}
          className="text-red-500 hover:text-red-700"
        >
          <Trash2 className="h-4 w-4" />
        </Button>
      </TableCell>
    </TableRow>
  );
}

export default function AdminEquipmentPage() {
  const router = useRouter();
  const [items, setItems] = useState<EquipmentType[]>([]);
  const [loading, setLoading] = useState(true);
  const [reordering, setReordering] = useState(false);

  const sensors = useSensors(
    useSensor(PointerSensor),
    useSensor(KeyboardSensor, {
      coordinateGetter: sortableKeyboardCoordinates,
    })
  );

  const fetchItems = async () => {
    try {
      setLoading(true);
      const res = await fetch("/api/proxy/core/equipment-types/");
      if (!res.ok) throw new Error("خطا در دریافت اطلاعات");
      const data = await res.json();
      setItems(Array.isArray(data) ? data : data.results || []);
    } catch (error) {
      toast.error("خطا در دریافت لیست تجهیزات");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchItems();
  }, []);

  const handleDelete = async (id: number) => {
    if (!confirm("آیا از حذف این نوع تجهیزات مطمئن هستید؟")) return;
    try {
      const res = await fetch(`/api/proxy/core/equipment-types/${id}/`, {
        method: "DELETE",
      });
      if (!res.ok) throw new Error("خطا در حذف");
      toast.success("نوع تجهیزات حذف شد");
      fetchItems();
    } catch (error) {
      toast.error("خطا در حذف نوع تجهیزات");
    }
  };

  const handleDragEnd = async (event: DragEndEvent) => {
    const { active, over } = event;
    if (!over || active.id === over.id) return;

    setReordering(true);
    try {
      const oldIndex = items.findIndex((item) => item.id === active.id);
      const newIndex = items.findIndex((item) => item.id === over.id);
      const newItems = arrayMove(items, oldIndex, newIndex);
      setItems(newItems);

      const orderedIds = newItems.map((item) => item.id);
      const res = await fetch("/api/proxy/core/equipment-types/reorder/", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ ids: orderedIds }),
      });

      if (!res.ok) {
        throw new Error("خطا در ذخیره‌سازی ترتیب جدید");
      }

      toast.success("ترتیب با موفقیت ذخیره شد");
    } catch (error) {
      toast.error("خطا در ذخیره‌سازی ترتیب");
      fetchItems();
    } finally {
      setReordering(false);
    }
  };

  if (loading && items.length === 0) {
    return (
      <div className="flex items-center justify-center p-12">
        <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold">انواع تجهیزات</h1>
          <p className="text-muted-foreground text-sm">
            مدیریت انواع تجهیزات و پارامترهای مربوطه
          </p>
          {reordering && (
            <p className="text-xs text-muted-foreground mt-1">
              در حال ذخیره‌سازی ترتیب جدید...
            </p>
          )}
        </div>
        <Link href="/dashboard/admin/equipment/new">
          <Button>
            <Plus className="ml-2 h-4 w-4" />
            نوع جدید
          </Button>
        </Link>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>لیست تجهیزات</CardTitle>
          <CardDescription>
            برای جابجایی، آیکون ≡ را بکشید و رها کنید
          </CardDescription>
        </CardHeader>
        <CardContent>
          <DndContext
            sensors={sensors}
            collisionDetection={closestCenter}
            onDragEnd={handleDragEnd}
          >
            <SortableContext
              items={items.map((item) => item.id)}
              strategy={verticalListSortingStrategy}
            >
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="w-10"></TableHead>
                    <TableHead>#</TableHead>
                    <TableHead>کد</TableHead>
                    <TableHead>نام فارسی</TableHead>
                    <TableHead>پشتیبانی از وضعیت نصب</TableHead>
                    <TableHead>وضعیت نصب اجباری</TableHead>
                    <TableHead>پارامترها</TableHead>
                    <TableHead className="text-left">عملیات</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {items.length === 0 ? (
                    <TableRow>
                      <TableCell colSpan={8} className="text-center text-muted-foreground">
                        هیچ نوع تجهیزاتی ثبت نشده است.
                      </TableCell>
                    </TableRow>
                  ) : (
                    items.map((item) => (
                      <SortableRow
                        key={item.id}
                        item={item}
                        onEdit={(id) =>
                          router.push(`/dashboard/admin/equipment/${id}/edit`)
                        }
                        onDelete={handleDelete}
                      />
                    ))
                  )}
                </TableBody>
              </Table>
            </SortableContext>
          </DndContext>
        </CardContent>
      </Card>
    </div>
  );
}
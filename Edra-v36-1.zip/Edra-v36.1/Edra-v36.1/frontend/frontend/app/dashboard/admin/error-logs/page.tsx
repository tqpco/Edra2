// app/dashboard/admin/error-logs/page.tsx
import { fetchPaginated } from "@/lib/paginated-fetch";
import { Pagination } from "@/components/ui/pagination";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { AlertTriangle } from "lucide-react";
import { toPersianDigits } from "@/lib/utils";

export const metadata = { title: "لاگ خطاها" };

interface ErrorLogItem {
  id: number;
  error_type: string;
  error_message: string;
  path: string;
  method: string;
  status_code: number;
  // EDRA v32: فیلد واقعی مدل ErrorLog «timestamp» است (نه created_at)؛
  // سریالایزر هم timestamp_jalali برمی‌گرداند. created_at_jalali همیشه
  // undefined بود و ستون تاریخ هر ردیف این صفحه همیشه خالی نمایش داده
  // می‌شد.
  timestamp_jalali: string;
}

async function fetchLogs(page: number) {
  return fetchPaginated<ErrorLogItem>(`/api/core/error-logs/`, page);
}

export default async function AdminErrorLogsPage({ searchParams }: { searchParams: Promise<{ page?: string }> }) {
  const _page = Math.max(1, Number((await searchParams).page) || 1);
  const { items: logs, count } = await fetchLogs(_page);

  return (
    <div className="flex flex-col gap-6">
      <div>
        <h1 className="text-2xl font-semibold">لاگ خطاها</h1>
        <p className="text-muted-foreground text-sm">
          ثبت خطاهای رخ‌داده در سیستم
        </p>
      </div>

      <Card>
        <CardContent className="px-0 py-2">
          {logs.length === 0 ? (
            <p className="text-muted-foreground py-10 text-center text-sm">
              <AlertTriangle className="mx-auto mb-2 size-8 opacity-40" />
              خطایی ثبت نشده است
            </p>
          ) : (
            <div className="flex flex-col divide-y">
              {logs.map((log) => (
                <div key={log.id} className="flex flex-wrap items-start justify-between gap-3 px-5 py-4">
                  <div className="min-w-0">
                    <div className="flex items-center gap-2">
                      <Badge variant="destructive">{log.error_type}</Badge>
                      <Badge variant="outline">{log.method}</Badge>
                      <span className="text-muted-foreground text-xs">
                        {log.path}
                      </span>
                    </div>
                    <p className="mt-1 text-sm font-medium">{log.error_message}</p>
                    <p className="text-muted-foreground mt-0.5 text-xs">
                      کد وضعیت: {toPersianDigits(log.status_code)}
                    </p>
                  </div>
                  <div className="shrink-0 text-left">
                    <p className="text-muted-foreground text-xs">
                      {log.timestamp_jalali}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
      <Pagination current={_page} totalItems={count} basePath="/dashboard/admin/error-logs" />
    </div>
  );
}
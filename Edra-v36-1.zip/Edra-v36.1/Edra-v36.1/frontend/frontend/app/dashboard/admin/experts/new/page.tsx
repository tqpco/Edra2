// app/dashboard/admin/experts/new/page.tsx  (EDRA v32)
import { UserForm } from "@/components/admin/user-form";

export const metadata = { title: "کارشناس جدید" };

export default function AdminNewExpertPage() {
  return <UserForm mode="create" role="expert" />;
}

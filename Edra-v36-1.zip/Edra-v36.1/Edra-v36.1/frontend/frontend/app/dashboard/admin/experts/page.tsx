// app/dashboard/admin/experts/page.tsx
import { fetchPaginated } from "@/lib/paginated-fetch";
import { Pagination } from "@/components/ui/pagination";
import { Card, CardContent } from "@/components/ui/card";
import Link from "next/link";
import { Pencil, Plus } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { toPersianDigits } from "@/lib/utils";
import { RoleChangeButton } from "@/components/shared/role-change-button";

export const metadata = { title: "کارشناسان" };

interface ExpertRow {
  id: number;
  username: string;
  full_name: string;
  phone: string | null;
  is_active: boolean;
  date_joined_jalali: string;
  role: "customer" | "expert" | "admin";
  is_staff: boolean;
  is_superuser: boolean;
}

export default async function AdminExpertsPage({ searchParams }: { searchParams: Promise<{ page?: string }> }) {
  const _page = Math.max(1, Number((await searchParams).page) || 1);
  const { items: experts, count } = await fetchPaginated<ExpertRow>(`/api/core/users/?role=expert`, _page);

  return (
    <div className="flex flex-col gap-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="text-2xl font-semibold">کارشناسان</h1>
          <p className="text-muted-foreground text-sm">
            {toPersianDigits(count)} کارشناس ثبت‌شده در سیستم
          </p>
        </div>
        <Button asChild>
          <Link href="/dashboard/admin/experts/new">
            <Plus className="size-4" />
            کارشناس جدید
          </Link>
        </Button>
      </div>

      <Card>
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b text-right">
                  <th className="text-muted-foreground px-4 py-3 text-xs font-medium">نام</th>
                  <th className="text-muted-foreground px-4 py-3 text-xs font-medium">موبایل</th>
                  <th className="text-muted-foreground px-4 py-3 text-xs font-medium">تاریخ عضویت</th>
                  <th className="text-muted-foreground px-4 py-3 text-xs font-medium">وضعیت</th>
                  <th className="text-muted-foreground px-4 py-3 text-xs font-medium"></th>
                </tr>
              </thead>
              <tbody>
                {experts.map((e) => (
                  <tr key={e.id} className="hover:bg-accent/50 border-b last:border-0">
                    <td className="px-4 py-3 font-medium">{e.full_name || e.username}</td>
                    <td className="ltr-numerals px-4 py-3">{e.phone ?? "—"}</td>
                    <td className="text-muted-foreground px-4 py-3">
                      {e.date_joined_jalali}
                    </td>
                    <td className="px-4 py-3">
                      {/* ✅ اصلاح: استفاده از variant="outline" + className */}
                      <Badge
                        variant="outline"
                        className={
                          e.is_active
                            ? "border-green-500 text-green-700 bg-green-50"
                            : "border-gray-300 text-gray-500 bg-gray-50"
                        }
                      >
                        {e.is_active ? "فعال" : "غیرفعال"}
                      </Badge>
                    </td>
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-1">
                        <Button variant="ghost" size="sm" asChild>
                          <Link href={`/dashboard/admin/experts/${e.id}/edit`}>
                            <Pencil className="size-3.5" />
                            ویرایش
                          </Link>
                        </Button>
                        <RoleChangeButton
                          userId={e.id}
                          userDisplayName={e.full_name || e.username}
                          currentRole={e.role}
                          disabled={e.is_staff || e.is_superuser}
                        />
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
        {experts.length === 0 && (
          <p className="text-muted-foreground py-10 text-center text-sm">
            کارشناسی ثبت نشده. با «کارشناس جدید» یکی بسازید، یا از دکمه‌ی «نقش» در
            صفحه‌ی مشتریان یک مشتری موجود را به کارشناس تبدیل کنید.
          </p>
        )}
      </Card>
      <Pagination current={_page} totalItems={count} basePath="/dashboard/admin/experts" />
    </div>
  );
}
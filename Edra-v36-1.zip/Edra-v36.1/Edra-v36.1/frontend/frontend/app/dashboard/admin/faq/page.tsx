import { apiServerFetch } from "@/lib/api-server";
import { FaqClient } from "./faq-client";

export const metadata = { title: "سوالات متداول" };

interface FAQItem {
  id: number;
  question: string;
  answer: string;
  category: string;
  order: number;
  is_active: boolean;
}

export default async function AdminFaqPage() {
  const data = await apiServerFetch<FAQItem[] | { results: FAQItem[] }>(`/api/public/faqs/`);
  const faqs = Array.isArray(data) ? data : data.results ?? [];

  return (
    <div className="flex flex-col gap-6">
      <FaqClient faqs={faqs} />
    </div>
  );
}

"use client";

import { NotificationInbox } from "@/components/shared/notification-inbox";

// صندوق اعلان‌های شخصی مدیر (جدا از «قالب‌ها» و «لاگ اعلان‌ها»)
export default function AdminInboxPage() {
  return <NotificationInbox />;
}

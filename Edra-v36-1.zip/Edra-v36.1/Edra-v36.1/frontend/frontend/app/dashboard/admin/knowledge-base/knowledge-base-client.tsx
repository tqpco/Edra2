"use client";

// EDRA v27 — قابلیت تازه (گزارش کاربر، سپتامبر ۲۰۲۶): پایگاه دانش در
// بک‌اند کامل بود ولی رابط مدیریتی نداشت (+ باگ created_by که رفع شد).

import * as React from "react";
import { useRouter } from "next/navigation";
import { toast } from "sonner";
import { Plus, Pencil, Trash2, BookOpen, FolderTree } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Badge } from "@/components/ui/badge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import { apiClientFetch, ClientApiError } from "@/lib/api-client";

interface CategoryItem {
  id: number;
  name: string;
  description?: string;
}

interface ArticleItem {
  id: number;
  title: string;
  content: string;
  summary?: string;
  category: number;
  category_name?: string;
  is_published: boolean;
}

const EMPTY_CATEGORY = { name: "", description: "" };
const EMPTY_ARTICLE = { title: "", content: "", summary: "", category: "", is_published: false };

export function KnowledgeBaseClient({
  categories,
  articles,
}: {
  categories: CategoryItem[];
  articles: ArticleItem[];
}) {
  const router = useRouter();

  // --- دسته‌بندی‌ها ---
  const [catDialogOpen, setCatDialogOpen] = React.useState(false);
  const [editingCat, setEditingCat] = React.useState<CategoryItem | null>(null);
  const [catForm, setCatForm] = React.useState(EMPTY_CATEGORY);
  const [savingCat, setSavingCat] = React.useState(false);

  function openCreateCat() {
    setEditingCat(null);
    setCatForm(EMPTY_CATEGORY);
    setCatDialogOpen(true);
  }
  function openEditCat(c: CategoryItem) {
    setEditingCat(c);
    setCatForm({ name: c.name, description: c.description ?? "" });
    setCatDialogOpen(true);
  }
  async function submitCat() {
    if (!catForm.name.trim()) {
      toast.error("نام دسته‌بندی الزامی است.");
      return;
    }
    setSavingCat(true);
    try {
      const path = editingCat
        ? `/api/support/knowledge-categories/${editingCat.id}/`
        : `/api/support/knowledge-categories/`;
      await apiClientFetch(path, { method: editingCat ? "PATCH" : "POST", body: catForm });
      toast.success(editingCat ? "دسته‌بندی ویرایش شد." : "دسته‌بندی جدید ساخته شد.");
      setCatDialogOpen(false);
      router.refresh();
    } catch (err) {
      toast.error(err instanceof ClientApiError ? err.message : "خطا در ذخیره‌سازی.");
    } finally {
      setSavingCat(false);
    }
  }
  async function deleteCat(c: CategoryItem) {
    try {
      await apiClientFetch(`/api/support/knowledge-categories/${c.id}/`, { method: "DELETE" });
      toast.success("دسته‌بندی حذف شد.");
      router.refresh();
    } catch (err) {
      toast.error(err instanceof ClientApiError ? err.message : "خطا در حذف.");
    }
  }

  // --- مقالات ---
  const [articleDialogOpen, setArticleDialogOpen] = React.useState(false);
  const [editingArticle, setEditingArticle] = React.useState<ArticleItem | null>(null);
  const [articleForm, setArticleForm] = React.useState(EMPTY_ARTICLE);
  const [savingArticle, setSavingArticle] = React.useState(false);
  const [deleteTarget, setDeleteTarget] = React.useState<ArticleItem | null>(null);
  const [deleting, setDeleting] = React.useState(false);

  function openCreateArticle() {
    setEditingArticle(null);
    setArticleForm(EMPTY_ARTICLE);
    setArticleDialogOpen(true);
  }
  function openEditArticle(a: ArticleItem) {
    setEditingArticle(a);
    setArticleForm({
      title: a.title,
      content: a.content,
      summary: a.summary ?? "",
      category: String(a.category),
      is_published: a.is_published,
    });
    setArticleDialogOpen(true);
  }
  async function submitArticle() {
    if (!articleForm.title.trim() || !articleForm.content.trim() || !articleForm.category) {
      toast.error("عنوان، محتوا و دسته‌بندی الزامی است.");
      return;
    }
    setSavingArticle(true);
    try {
      const payload = { ...articleForm, category: Number(articleForm.category) };
      const path = editingArticle
        ? `/api/support/knowledge-articles/${editingArticle.id}/`
        : `/api/support/knowledge-articles/`;
      await apiClientFetch(path, { method: editingArticle ? "PATCH" : "POST", body: payload });
      toast.success(editingArticle ? "مقاله ویرایش شد." : "مقاله جدید ساخته شد.");
      setArticleDialogOpen(false);
      router.refresh();
    } catch (err) {
      toast.error(err instanceof ClientApiError ? err.message : "خطا در ذخیره‌سازی.");
    } finally {
      setSavingArticle(false);
    }
  }
  async function confirmDeleteArticle() {
    if (!deleteTarget) return;
    setDeleting(true);
    try {
      await apiClientFetch(`/api/support/knowledge-articles/${deleteTarget.id}/`, { method: "DELETE" });
      toast.success("مقاله حذف شد.");
      setDeleteTarget(null);
      router.refresh();
    } catch (err) {
      toast.error(err instanceof ClientApiError ? err.message : "خطا در حذف.");
    } finally {
      setDeleting(false);
    }
  }

  return (
    <div className="flex flex-col gap-6">
      <div>
        <h1 className="text-2xl font-semibold">پایگاه دانش</h1>
        <p className="text-muted-foreground text-sm">مقالات راهنما برای مشتریان</p>
      </div>

      {/* دسته‌بندی‌ها */}
      <Card>
        <CardContent className="flex flex-col gap-3 p-5">
          <div className="flex items-center justify-between">
            <h2 className="flex items-center gap-2 text-sm font-medium">
              <FolderTree className="size-4" />
              دسته‌بندی‌ها
            </h2>
            <Button variant="outline" size="sm" onClick={openCreateCat}>
              <Plus className="size-3.5" />
              دسته‌بندی جدید
            </Button>
          </div>
          <div className="flex flex-wrap gap-2">
            {categories.length === 0 && (
              <p className="text-muted-foreground text-sm">دسته‌بندی‌ای ثبت نشده است.</p>
            )}
            {categories.map((c) => (
              <div key={c.id} className="flex items-center gap-1 rounded-full border py-1 pr-1 pl-3 text-sm">
                <button onClick={() => openEditCat(c)} className="hover:underline">
                  {c.name}
                </button>
                <Button
                  variant="ghost"
                  size="icon"
                  className="text-destructive size-6"
                  onClick={() => deleteCat(c)}
                >
                  <Trash2 className="size-3" />
                </Button>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* مقالات */}
      <div className="flex items-center justify-between">
        <h2 className="text-lg font-medium">مقالات</h2>
        <Button onClick={openCreateArticle} disabled={categories.length === 0}>
          <Plus className="size-4" />
          مقاله جدید
        </Button>
      </div>
      <Card>
        <CardContent className="px-0 py-2">
          {articles.length === 0 ? (
            <p className="text-muted-foreground py-10 text-center text-sm">
              <BookOpen className="mx-auto mb-2 size-8 opacity-40" />
              مقاله‌ای ثبت نشده است
            </p>
          ) : (
            <div className="flex flex-col divide-y">
              {articles.map((a) => (
                <div key={a.id} className="flex items-start justify-between gap-3 px-5 py-4">
                  <div className="min-w-0">
                    <div className="flex items-center gap-2">
                      <span className="text-sm font-medium">{a.title}</span>
                      <Badge variant="outline">{a.category_name}</Badge>
                      <Badge variant={a.is_published ? "success" : "muted"}>
                        {a.is_published ? "منتشرشده" : "پیش‌نویس"}
                      </Badge>
                    </div>
                    <p className="text-muted-foreground mt-1 line-clamp-1 text-xs">{a.summary}</p>
                  </div>
                  <div className="flex shrink-0 items-center gap-1">
                    <Button variant="ghost" size="icon" className="size-8" onClick={() => openEditArticle(a)}>
                      <Pencil className="size-3.5" />
                    </Button>
                    <Button
                      variant="ghost"
                      size="icon"
                      className="text-destructive size-8"
                      onClick={() => setDeleteTarget(a)}
                    >
                      <Trash2 className="size-3.5" />
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      {/* دیالوگ دسته‌بندی */}
      <Dialog open={catDialogOpen} onOpenChange={setCatDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>{editingCat ? "ویرایش دسته‌بندی" : "دسته‌بندی جدید"}</DialogTitle>
          </DialogHeader>
          <div className="flex flex-col gap-4">
            <div className="grid gap-1.5">
              <Label htmlFor="cat-name">نام</Label>
              <Input
                id="cat-name"
                value={catForm.name}
                onChange={(e) => setCatForm({ ...catForm, name: e.target.value })}
              />
            </div>
            <div className="grid gap-1.5">
              <Label htmlFor="cat-desc">توضیحات</Label>
              <Textarea
                id="cat-desc"
                rows={2}
                value={catForm.description}
                onChange={(e) => setCatForm({ ...catForm, description: e.target.value })}
              />
            </div>
          </div>
          <div className="flex justify-end gap-2">
            <Button variant="outline" onClick={() => setCatDialogOpen(false)}>
              انصراف
            </Button>
            <Button onClick={submitCat} disabled={savingCat}>
              {savingCat ? "در حال ذخیره..." : "ذخیره"}
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* دیالوگ مقاله */}
      <Dialog open={articleDialogOpen} onOpenChange={setArticleDialogOpen}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle>{editingArticle ? "ویرایش مقاله" : "مقاله جدید"}</DialogTitle>
          </DialogHeader>
          <div className="flex flex-col gap-4">
            <div className="grid gap-1.5">
              <Label htmlFor="art-title">عنوان</Label>
              <Input
                id="art-title"
                value={articleForm.title}
                onChange={(e) => setArticleForm({ ...articleForm, title: e.target.value })}
              />
            </div>
            <div className="grid gap-1.5">
              <Label>دسته‌بندی</Label>
              <Select
                value={articleForm.category}
                onValueChange={(v) => setArticleForm({ ...articleForm, category: v })}
              >
                <SelectTrigger>
                  <SelectValue placeholder="انتخاب دسته‌بندی" />
                </SelectTrigger>
                <SelectContent>
                  {categories.map((c) => (
                    <SelectItem key={c.id} value={String(c.id)}>
                      {c.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="grid gap-1.5">
              <Label htmlFor="art-summary">خلاصه</Label>
              <Textarea
                id="art-summary"
                rows={2}
                value={articleForm.summary}
                onChange={(e) => setArticleForm({ ...articleForm, summary: e.target.value })}
              />
            </div>
            <div className="grid gap-1.5">
              <Label htmlFor="art-content">محتوا</Label>
              <Textarea
                id="art-content"
                rows={6}
                value={articleForm.content}
                onChange={(e) => setArticleForm({ ...articleForm, content: e.target.value })}
              />
            </div>
            <div className="flex items-center justify-between rounded-md border p-3">
              <Label htmlFor="art-published">منتشر شود</Label>
              <Switch
                id="art-published"
                checked={articleForm.is_published}
                onCheckedChange={(v) => setArticleForm({ ...articleForm, is_published: v })}
              />
            </div>
          </div>
          <div className="flex justify-end gap-2">
            <Button variant="outline" onClick={() => setArticleDialogOpen(false)}>
              انصراف
            </Button>
            <Button onClick={submitArticle} disabled={savingArticle}>
              {savingArticle ? "در حال ذخیره..." : "ذخیره"}
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      <Dialog open={Boolean(deleteTarget)} onOpenChange={(o) => !o && setDeleteTarget(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>حذف «{deleteTarget?.title}»</DialogTitle>
            <DialogDescription>این عملیات قابل بازگشت نیست.</DialogDescription>
          </DialogHeader>
          <div className="flex justify-end gap-2">
            <Button variant="outline" onClick={() => setDeleteTarget(null)}>
              انصراف
            </Button>
            <Button variant="destructive" onClick={confirmDeleteArticle} disabled={deleting}>
              {deleting ? "در حال حذف..." : "حذف"}
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}

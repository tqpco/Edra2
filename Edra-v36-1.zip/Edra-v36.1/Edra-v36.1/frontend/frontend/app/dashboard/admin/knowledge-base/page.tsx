import { apiServerFetch } from "@/lib/api-server";
import { KnowledgeBaseClient } from "./knowledge-base-client";

export const metadata = { title: "پایگاه دانش" };

interface CategoryItem {
  id: number;
  name: string;
  description?: string;
}

interface ArticleItem {
  id: number;
  title: string;
  content: string;
  summary?: string;
  category: number;
  category_name?: string;
  is_published: boolean;
}

export default async function AdminKnowledgeBasePage() {
  const [catsRes, artsRes] = await Promise.all([
    apiServerFetch<CategoryItem[] | { results: CategoryItem[] }>(
      `/api/support/knowledge-categories/?page_size=200`
    ),
    apiServerFetch<ArticleItem[] | { results: ArticleItem[] }>(
      `/api/support/knowledge-articles/?page_size=200`
    ),
  ]);
  const categories = Array.isArray(catsRes) ? catsRes : catsRes.results ?? [];
  const articles = Array.isArray(artsRes) ? artsRes : artsRes.results ?? [];

  return <KnowledgeBaseClient categories={categories} articles={articles} />;
}

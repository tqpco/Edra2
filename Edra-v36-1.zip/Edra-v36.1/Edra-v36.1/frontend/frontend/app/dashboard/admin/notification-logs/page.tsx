import { BellRing } from "lucide-react";
import { fetchPaginated } from "@/lib/paginated-fetch";
import { Pagination } from "@/components/ui/pagination";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { getStatusInfo, NOTIFICATION_STATUS_MAP } from "@/lib/status-map";

export const metadata = { title: "لاگ نوتیفیکیشن‌ها" };

interface NotificationLogItem {
  id: number;
  type: string;
  channel: string;
  subject: string;
  content: string;
  status: string;
  created_at_jalali?: string;
  sent_at_jalali?: string | null;
  user?: number | null;
  user_username?: string;
  type_label?: string;
  recipient?: string;
  error_message?: string;
}

async function fetchLogs(page: number) {
  return fetchPaginated<NotificationLogItem>(`/api/notifications/logs/`, page);
}

const CHANNEL_LABEL: Record<string, string> = {
  sms: "پیامک",
  email: "ایمیل",
  both: "پیامک و ایمیل",
  in_app: "فقط درون‌برنامه‌ای",
};

export default async function AdminNotificationLogsPage({ searchParams }: { searchParams: Promise<{ page?: string }> }) {
  const _page = Math.max(1, Number((await searchParams).page) || 1);
  const { items: logs, count } = await fetchLogs(_page);

  return (
    <div className="flex flex-col gap-6">
      <div>
        <h1 className="text-2xl font-semibold">لاگ نوتیفیکیشن‌ها</h1>
        <p className="text-muted-foreground text-sm">
          تاریخچه ارسال پیامک/ایمیل/اعلان درون‌برنامه‌ای
        </p>
      </div>

      <Card>
        <CardContent className="px-0 py-2">
          {logs.length === 0 ? (
            <p className="text-muted-foreground py-10 text-center text-sm">
              <BellRing className="mx-auto mb-2 size-8 opacity-40" />
              نوتیفیکیشنی ارسال نشده است
            </p>
          ) : (
            <div className="flex flex-col divide-y">
              {logs.map((log) => {
                const status = getStatusInfo(NOTIFICATION_STATUS_MAP, log.status);
                return (
                  <div key={log.id} className="flex flex-wrap items-start justify-between gap-3 px-5 py-3">
                    <div className="min-w-0">
                      <div className="flex items-center gap-2">
                        <Badge variant="outline">{log.type_label || log.type}</Badge>
                        <Badge variant="secondary">{CHANNEL_LABEL[log.channel] ?? log.channel}</Badge>
                        <Badge variant={status.variant}>{status.label}</Badge>
                      </div>
                      <p className="mt-1 text-sm font-medium">{log.subject}</p>
                      <p className="text-muted-foreground mt-0.5 text-xs">
                        گیرنده: {log.user_username ?? log.user ?? "—"}
                        {log.recipient ? ` — ${log.recipient}` : ""}
                      </p>
                      <p className="text-muted-foreground mt-0.5 line-clamp-2 text-xs">{log.content}</p>
                      {log.error_message && (
                        <p className="text-destructive mt-1 text-xs">{log.error_message}</p>
                      )}
                    </div>
                    <div className="shrink-0 text-left">
                      <p className="text-muted-foreground text-xs">{log.created_at_jalali ?? ""}</p>
                      {log.sent_at_jalali && (
                        <p className="text-muted-foreground mt-0.5 text-xs">ارسال: {log.sent_at_jalali}</p>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </CardContent>
      </Card>
          <Pagination current={_page} totalItems={count} basePath="/dashboard/admin/notification-logs" />
</div>
  );
}

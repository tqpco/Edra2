import { apiServerFetch } from "@/lib/api-server";
import { Pagination } from "@/components/ui/pagination";
import { TemplatesClient } from "./templates-client";
import type { NotificationTemplate } from "./template-form-dialog";

export const metadata = { title: "قالب‌های اعلان" };

export default async function AdminNotificationsPage({ searchParams }: { searchParams: Promise<{ page?: string }> }) {
  const _page = Math.max(1, Number((await searchParams).page) || 1);
  const data = await apiServerFetch<{ count: number; results: NotificationTemplate[] } | NotificationTemplate[]>(
    `/api/notifications/templates/?page=${_page}`
  );
  const templates = Array.isArray(data) ? data : data.results ?? [];

  return (
    <div className="flex flex-col gap-6">
      <TemplatesClient templates={templates} />
      <Pagination current={_page} totalItems={Array.isArray(data) ? data.length : data.count ?? 0} basePath="/dashboard/admin/notifications" />
    </div>
  );
}

"use client";

// EDRA v27 — قابلیت تازه (گزارش کاربر، سپتامبر ۲۰۲۶): جایگزین «ویرایش
// کامل در پنل جنگو» برای قالب‌های اعلان.

import * as React from "react";
import { useRouter } from "next/navigation";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import { apiClientFetch } from "@/lib/api-client";

export interface NotificationTemplate {
  id: number;
  code: string;
  channel: "email" | "sms" | "both" | "in_app";
  subject: string;
  body_template: string;
  is_active: boolean;
}

interface TemplateFormDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  template: NotificationTemplate | null; // null = ساخت قالب جدید
}

const EMPTY: Omit<NotificationTemplate, "id"> = {
  code: "",
  channel: "both",
  subject: "",
  body_template: "",
  is_active: true,
};

export function TemplateFormDialog({ open, onOpenChange, template }: TemplateFormDialogProps) {
  const router = useRouter();
  const [form, setForm] = React.useState<Omit<NotificationTemplate, "id">>(EMPTY);
  const [saving, setSaving] = React.useState(false);

  React.useEffect(() => {
    setForm(template ? { ...template } : EMPTY);
  }, [template, open]);

  const isEdit = Boolean(template);

  const submit = async () => {
    if (!form.code.trim()) {
      toast.error("کد قالب الزامی است.");
      return;
    }
    if (!form.body_template.trim()) {
      toast.error("متن قالب نمی‌تواند خالی باشد.");
      return;
    }
    setSaving(true);
    try {
      const path = isEdit
        ? `/api/notifications/templates/${template!.id}/`
        : `/api/notifications/templates/`;
      await apiClientFetch(path, {
        method: isEdit ? "PATCH" : "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(form),
      });
      toast.success(isEdit ? "قالب ویرایش شد." : "قالب جدید ساخته شد.");
      onOpenChange(false);
      router.refresh();
    } catch (error: any) {
      toast.error(error?.message || "خطا در ذخیره‌ی قالب.");
    } finally {
      setSaving(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-lg">
        <DialogHeader>
          <DialogTitle>{isEdit ? "ویرایش قالب اعلان" : "قالب اعلان جدید"}</DialogTitle>
          <DialogDescription>
            از {"{{ variable }}"} برای درج مقادیر پویا در متن استفاده کنید.
          </DialogDescription>
        </DialogHeader>

        <div className="flex flex-col gap-4">
          <div className="grid gap-1.5">
            <Label htmlFor="tpl-code">کد قالب (یکتا)</Label>
            <Input
              id="tpl-code"
              value={form.code}
              onChange={(e) => setForm({ ...form, code: e.target.value })}
              placeholder="مثلاً new_discount_code"
              dir="ltr"
              disabled={isEdit} // ✅ کد قالب پس از ساخت قابل تغییر نیست چون در کد بک‌اند به آن ارجاع داده می‌شود
            />
          </div>

          <div className="grid gap-1.5">
            <Label>کانال ارسال</Label>
            <Select
              value={form.channel}
              onValueChange={(v) => setForm({ ...form, channel: v as NotificationTemplate["channel"] })}
            >
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="both">پیامک و ایمیل</SelectItem>
                <SelectItem value="sms">فقط پیامک</SelectItem>
                <SelectItem value="email">فقط ایمیل</SelectItem>
                <SelectItem value="in_app">فقط درون‌برنامه‌ای</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="grid gap-1.5">
            <Label htmlFor="tpl-subject">موضوع (برای ایمیل)</Label>
            <Input
              id="tpl-subject"
              value={form.subject}
              onChange={(e) => setForm({ ...form, subject: e.target.value })}
            />
          </div>

          <div className="grid gap-1.5">
            <Label htmlFor="tpl-body">متن قالب</Label>
            <Textarea
              id="tpl-body"
              rows={5}
              value={form.body_template}
              onChange={(e) => setForm({ ...form, body_template: e.target.value })}
            />
          </div>

          <div className="flex items-center justify-between rounded-md border p-3">
            <Label htmlFor="tpl-active">فعال</Label>
            <Switch
              id="tpl-active"
              checked={form.is_active}
              onCheckedChange={(v) => setForm({ ...form, is_active: v })}
            />
          </div>
        </div>

        <div className="flex justify-end gap-2">
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            انصراف
          </Button>
          <Button onClick={submit} disabled={saving}>
            {saving ? "در حال ذخیره..." : "ذخیره"}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}

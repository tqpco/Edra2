"use client";

import * as React from "react";
import { useRouter } from "next/navigation";
import { toast } from "sonner";
import { Bell, Plus, Pencil, Trash2 } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import { apiClientFetch } from "@/lib/api-client";
import { TemplateFormDialog, NotificationTemplate } from "./template-form-dialog";

const CHANNEL_LABEL: Record<string, string> = {
  sms: "پیامک",
  email: "ایمیل",
  both: "پیامک و ایمیل",
  in_app: "درون‌برنامه‌ای",
};

export function TemplatesClient({ templates }: { templates: NotificationTemplate[] }) {
  const router = useRouter();
  const [dialogOpen, setDialogOpen] = React.useState(false);
  const [editing, setEditing] = React.useState<NotificationTemplate | null>(null);
  const [deleteTarget, setDeleteTarget] = React.useState<NotificationTemplate | null>(null);
  const [deleting, setDeleting] = React.useState(false);

  const openCreate = () => {
    setEditing(null);
    setDialogOpen(true);
  };
  const openEdit = (t: NotificationTemplate) => {
    setEditing(t);
    setDialogOpen(true);
  };

  const confirmDelete = async () => {
    if (!deleteTarget) return;
    setDeleting(true);
    try {
      await apiClientFetch(`/api/notifications/templates/${deleteTarget.id}/`, {
        method: "DELETE",
      });
      toast.success("قالب حذف شد.");
      setDeleteTarget(null);
      router.refresh();
    } catch (error: any) {
      toast.error(error?.message || "خطا در حذف قالب.");
    } finally {
      setDeleting(false);
    }
  };

  return (
    <>
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="text-2xl font-semibold">قالب‌های اعلان</h1>
          <p className="text-muted-foreground text-sm">
            متن پیامک/ایمیل ارسالی برای هر رویداد سیستم
          </p>
        </div>
        <Button onClick={openCreate}>
          <Plus className="size-4" />
          قالب جدید
        </Button>
      </div>

      <div className="grid gap-3">
        {templates.map((t) => (
          <Card key={t.id}>
            <CardContent className="flex flex-wrap items-center justify-between gap-3 px-5 py-4">
              <div className="flex items-center gap-3">
                <span className="bg-primary/10 text-primary flex size-9 items-center justify-center rounded-lg">
                  <Bell className="size-4" />
                </span>
                <div>
                  <p className="font-mono text-sm font-medium">{t.code}</p>
                  <p className="text-muted-foreground text-xs">{t.subject}</p>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <Badge variant="outline">{CHANNEL_LABEL[t.channel] ?? t.channel}</Badge>
                <Badge variant={t.is_active ? "success" : "muted"}>
                  {t.is_active ? "فعال" : "غیرفعال"}
                </Badge>
                <Button variant="ghost" size="icon" className="size-8" onClick={() => openEdit(t)}>
                  <Pencil className="size-3.5" />
                </Button>
                <Button
                  variant="ghost"
                  size="icon"
                  className="text-destructive size-8"
                  onClick={() => setDeleteTarget(t)}
                >
                  <Trash2 className="size-3.5" />
                </Button>
              </div>
            </CardContent>
          </Card>
        ))}
        {templates.length === 0 && (
          <p className="text-muted-foreground py-10 text-center text-sm">
            قالبی یافت نشد. برای شروع، دکمه‌ی «قالب جدید» را بزنید.
          </p>
        )}
      </div>

      <TemplateFormDialog open={dialogOpen} onOpenChange={setDialogOpen} template={editing} />

      <Dialog open={Boolean(deleteTarget)} onOpenChange={(o) => !o && setDeleteTarget(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>حذف قالب «{deleteTarget?.code}»</DialogTitle>
            <DialogDescription>
              این عملیات قابل بازگشت نیست. اگر این قالب در کد بک‌اند برای ارسال اعلان استفاده
              می‌شود، ارسال آن رویداد دیگر کار نخواهد کرد.
            </DialogDescription>
          </DialogHeader>
          <div className="flex justify-end gap-2">
            <Button variant="outline" onClick={() => setDeleteTarget(null)}>
              انصراف
            </Button>
            <Button variant="destructive" onClick={confirmDelete} disabled={deleting}>
              {deleting ? "در حال حذف..." : "حذف"}
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
}

"use client";

// EDRA v27 — قابلیت تازه (گزارش کاربر، سپتامبر ۲۰۲۶): «هر بخشی که در
// بک‌اند وجود دارد باید در فرانت هم وجود داشته باشه». OrganizationViewSet
// از قبل ModelViewSet کامل بود (ساخت/ویرایش/حذف)، ولی صفحه‌ی سازمان‌ها
// فقط یک لیست خواندنی بود.

import * as React from "react";
import { useRouter } from "next/navigation";
import { toast } from "sonner";
import { Plus, Pencil, Trash2, Building2 } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import { apiClientFetch, ClientApiError } from "@/lib/api-client";
import { Pagination } from "@/components/ui/pagination";

interface OrganizationItem {
  id: number;
  name: string;
  billing_contact?: number | null;
  is_active?: boolean;
}

const EMPTY = { name: "", billing_contact: "", is_active: true };

export function OrganizationsClient({
  orgs,
  count,
  page,
}: {
  orgs: OrganizationItem[];
  count: number;
  page: number;
}) {
  const router = useRouter();
  const [dialogOpen, setDialogOpen] = React.useState(false);
  const [editing, setEditing] = React.useState<OrganizationItem | null>(null);
  const [form, setForm] = React.useState(EMPTY);
  const [saving, setSaving] = React.useState(false);
  const [deleteTarget, setDeleteTarget] = React.useState<OrganizationItem | null>(null);
  const [deleting, setDeleting] = React.useState(false);

  function openCreate() {
    setEditing(null);
    setForm(EMPTY);
    setDialogOpen(true);
  }

  function openEdit(org: OrganizationItem) {
    setEditing(org);
    setForm({
      name: org.name,
      billing_contact: org.billing_contact ? String(org.billing_contact) : "",
      is_active: org.is_active ?? true,
    });
    setDialogOpen(true);
  }

  async function submit() {
    if (!form.name.trim()) {
      toast.error("نام سازمان الزامی است.");
      return;
    }
    setSaving(true);
    try {
      const payload = {
        name: form.name,
        billing_contact: form.billing_contact ? Number(form.billing_contact) : null,
        is_active: form.is_active,
      };
      const path = editing
        ? `/api/core/organizations/${editing.id}/`
        : `/api/core/organizations/`;
      await apiClientFetch(path, {
        method: editing ? "PATCH" : "POST",
        body: payload,
      });
      toast.success(editing ? "سازمان ویرایش شد." : "سازمان جدید ساخته شد.");
      setDialogOpen(false);
      router.refresh();
    } catch (err) {
      toast.error(err instanceof ClientApiError ? err.message : "خطا در ذخیره‌سازی.");
    } finally {
      setSaving(false);
    }
  }

  async function confirmDelete() {
    if (!deleteTarget) return;
    setDeleting(true);
    try {
      await apiClientFetch(`/api/core/organizations/${deleteTarget.id}/`, {
        method: "DELETE",
      });
      toast.success("سازمان حذف شد.");
      setDeleteTarget(null);
      router.refresh();
    } catch (err) {
      toast.error(err instanceof ClientApiError ? err.message : "خطا در حذف.");
    } finally {
      setDeleting(false);
    }
  }

  return (
    <>
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="text-2xl font-semibold">سازمان‌ها</h1>
          <p className="text-muted-foreground text-sm">سازمان‌های دارای قرارداد بازرسی</p>
        </div>
        <Button onClick={openCreate}>
          <Plus className="size-4" />
          سازمان جدید
        </Button>
      </div>

      <Card>
        <CardContent className="px-0 py-2">
          {orgs.length === 0 ? (
            <p className="text-muted-foreground py-10 text-center text-sm">
              <Building2 className="mx-auto mb-2 size-8 opacity-40" />
              سازمانی ثبت نشده است
            </p>
          ) : (
            <div className="flex flex-col divide-y">
              {orgs.map((org) => (
                <div key={org.id} className="flex items-center justify-between px-5 py-4">
                  <div className="flex items-center gap-3">
                    <span className="bg-primary/10 text-primary flex size-9 items-center justify-center rounded-lg">
                      <Building2 className="size-4" />
                    </span>
                    <div>
                      <p className="text-sm font-medium">{org.name}</p>
                      <p className="text-muted-foreground text-xs">
                        {org.billing_contact ? `تماس مالی: کاربر #${org.billing_contact}` : "بدون تماس مالی"}
                        {!org.is_active && " — غیرفعال"}
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center gap-1">
                    <Button variant="ghost" size="icon" className="size-8" onClick={() => openEdit(org)}>
                      <Pencil className="size-3.5" />
                    </Button>
                    <Button
                      variant="ghost"
                      size="icon"
                      className="text-destructive size-8"
                      onClick={() => setDeleteTarget(org)}
                    >
                      <Trash2 className="size-3.5" />
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      <Pagination current={page} totalItems={count} basePath="/dashboard/admin/organizations" />

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>{editing ? "ویرایش سازمان" : "سازمان جدید"}</DialogTitle>
          </DialogHeader>
          <div className="flex flex-col gap-4">
            <div className="grid gap-1.5">
              <Label htmlFor="org-name">نام سازمان</Label>
              <Input
                id="org-name"
                value={form.name}
                onChange={(e) => setForm({ ...form, name: e.target.value })}
              />
            </div>
            <div className="grid gap-1.5">
              <Label htmlFor="org-contact">شناسه کاربر — تماس مالی (اختیاری)</Label>
              <Input
                id="org-contact"
                type="number"
                dir="ltr"
                value={form.billing_contact}
                onChange={(e) => setForm({ ...form, billing_contact: e.target.value })}
                placeholder="مثلاً 42"
              />
            </div>
            <div className="flex items-center justify-between rounded-md border p-3">
              <Label htmlFor="org-active">فعال</Label>
              <Switch
                id="org-active"
                checked={form.is_active}
                onCheckedChange={(v) => setForm({ ...form, is_active: v })}
              />
            </div>
          </div>
          <div className="flex justify-end gap-2">
            <Button variant="outline" onClick={() => setDialogOpen(false)}>
              انصراف
            </Button>
            <Button onClick={submit} disabled={saving}>
              {saving ? "در حال ذخیره..." : "ذخیره"}
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      <Dialog open={Boolean(deleteTarget)} onOpenChange={(o) => !o && setDeleteTarget(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>حذف «{deleteTarget?.name}»</DialogTitle>
            <DialogDescription>این عملیات قابل بازگشت نیست.</DialogDescription>
          </DialogHeader>
          <div className="flex justify-end gap-2">
            <Button variant="outline" onClick={() => setDeleteTarget(null)}>
              انصراف
            </Button>
            <Button variant="destructive" onClick={confirmDelete} disabled={deleting}>
              {deleting ? "در حال حذف..." : "حذف"}
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
}

import { fetchPaginated } from "@/lib/paginated-fetch";
import { OrganizationsClient } from "./organizations-client";

export const metadata = { title: "سازمان‌ها" };

interface OrganizationItem {
  id: number;
  name: string;
  billing_contact?: number | null;
  is_active?: boolean;
}

async function fetchOrgs(page: number) {
  return fetchPaginated<OrganizationItem>(`/api/core/organizations/`, page);
}

export default async function AdminOrganizationsPage({
  searchParams,
}: {
  searchParams: Promise<{ page?: string }>;
}) {
  const _page = Math.max(1, Number((await searchParams).page) || 1);
  const { items: orgs, count } = await fetchOrgs(_page);

  return (
    <div className="flex flex-col gap-6">
      <OrganizationsClient orgs={orgs} count={count} page={_page} />
    </div>
  );
}

"use client";

/**
 * app/dashboard/admin/payment-methods/page.tsx  (EDRA v32)
 *
 * روش‌های پرداخت یک مجموعه‌ی ثابت سیستمی هستند (درگاه آنلاین / واریز دستی /
 * اعتبار شرکتی). ادمین فقط می‌تواند هر روش را فعال/غیرفعال کند یا توضیحاتش را
 * ویرایش کند؛ افزودن و حذف وجود ندارد (حذف یک روش سیستمی جریان پرداخت را
 * می‌شکند). قبلاً این صفحه POST/PUT/DELETE می‌زد و بک‌اند همه را 405 می‌کرد.
 */
import { useCallback, useEffect, useState } from "react";
import { Loader2, Pencil } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Textarea } from "@/components/ui/textarea";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { apiClientFetch, ClientApiError } from "@/lib/api-client";
import { parseApiError } from "@/lib/form-errors";

interface PaymentMethod {
  id: number;
  name: string;
  name_display: string;
  is_active: boolean;
  description: string;
}

type PagedOrList<T> = T[] | { results: T[] };

export default function AdminPaymentMethodsPage() {
  const [items, setItems] = useState<PaymentMethod[]>([]);
  const [loading, setLoading] = useState(true);
  const [savingId, setSavingId] = useState<number | null>(null);
  const [editing, setEditing] = useState<PaymentMethod | null>(null);
  const [description, setDescription] = useState("");

  const load = useCallback(async () => {
    try {
      const data = await apiClientFetch<PagedOrList<PaymentMethod>>(
        "/api/core/payment-methods/"
      );
      setItems(Array.isArray(data) ? data : data.results ?? []);
    } catch {
      toast.error("خطا در دریافت لیست روش‌های پرداخت");
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    void load();
  }, [load]);

  async function patch(item: PaymentMethod, body: Partial<PaymentMethod>) {
    if (savingId !== null) return false;
    setSavingId(item.id);
    try {
      const updated = await apiClientFetch<PaymentMethod>(
        `/api/core/payment-methods/${item.id}/`,
        { method: "PATCH", body }
      );
      setItems((prev) => prev.map((p) => (p.id === item.id ? { ...p, ...updated } : p)));
      return true;
    } catch (err) {
      toast.error(
        parseApiError(err instanceof ClientApiError ? err.data : null, "خطا در ذخیره‌سازی").message
      );
      return false;
    } finally {
      setSavingId(null);
    }
  }

  async function toggle(item: PaymentMethod, next: boolean) {
    const ok = await patch(item, { is_active: next });
    if (ok) {
      toast.success(next ? `«${item.name_display}» فعال شد` : `«${item.name_display}» غیرفعال شد`);
    }
  }

  async function saveDescription() {
    if (!editing) return;
    const ok = await patch(editing, { description });
    if (ok) {
      toast.success("توضیحات ذخیره شد");
      setEditing(null);
    }
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center p-12">
        <Loader2 className="text-muted-foreground h-8 w-8 animate-spin" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold">روش‌های پرداخت</h1>
        <p className="text-muted-foreground text-sm">
          فعال/غیرفعال‌کردن روش‌های پرداخت سیستم
        </p>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>روش‌های پرداخت</CardTitle>
          <CardDescription>
            این سه روش سیستمی‌اند و حذف نمی‌شوند. روش غیرفعال در پرداخت مشتریان
            پذیرفته نمی‌شود.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>روش</TableHead>
                <TableHead>توضیحات</TableHead>
                <TableHead>فعال</TableHead>
                <TableHead className="text-left">ویرایش</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {items.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={4} className="text-muted-foreground text-center">
                    هنوز هیچ روشی ثبت نشده است؛ با اولین پرداخت به‌صورت خودکار ساخته می‌شود.
                  </TableCell>
                </TableRow>
              ) : (
                items.map((item) => (
                  <TableRow key={item.id}>
                    <TableCell className="font-medium">{item.name_display}</TableCell>
                    <TableCell className="text-muted-foreground text-sm">
                      {item.description || "—"}
                    </TableCell>
                    <TableCell>
                      <Switch
                        checked={item.is_active}
                        disabled={savingId === item.id}
                        onCheckedChange={(v) => void toggle(item, v)}
                        aria-label={`فعال بودن ${item.name_display}`}
                      />
                    </TableCell>
                    <TableCell className="text-left">
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => {
                          setEditing(item);
                          setDescription(item.description || "");
                        }}
                      >
                        <Pencil className="h-4 w-4" />
                      </Button>
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      <Dialog open={editing !== null} onOpenChange={(o) => !o && setEditing(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>ویرایش «{editing?.name_display}»</DialogTitle>
            <DialogDescription>فقط توضیحات قابل ویرایش است.</DialogDescription>
          </DialogHeader>
          <div className="space-y-2">
            <Label htmlFor="pm-description">توضیحات</Label>
            <Textarea
              id="pm-description"
              rows={4}
              value={description}
              onChange={(e) => setDescription(e.target.value)}
            />
          </div>
          <div className="flex justify-end gap-2 pt-2">
            <Button variant="outline" onClick={() => setEditing(null)}>
              انصراف
            </Button>
            <Button onClick={() => void saveDescription()} disabled={savingId !== null}>
              {savingId !== null ? <Loader2 className="ml-2 h-4 w-4 animate-spin" /> : null}
              ذخیره
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}

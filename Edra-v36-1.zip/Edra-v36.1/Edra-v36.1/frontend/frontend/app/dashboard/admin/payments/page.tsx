"use client";

import { useCallback, useEffect, useState } from "react";
import { PaginationClient } from "@/components/ui/pagination";
import { CheckCircle2, XCircle, Receipt, RefreshCw } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { apiClientFetch } from "@/lib/api-client";
import { formatToman } from "@/lib/format";
import { getStatusInfo, PAYMENT_STATUS_MAP } from "@/lib/status-map";
import { toast } from "sonner";

interface PaymentItem {
  id: number;
  amount: number;
  amount_rial: number | null;
  credit_amount: number;
  online_amount: number;
  status: string;
  method: number;
  authority?: string | null;
  ref_id?: string | null;
  created_at_jalali?: string;
  bank_receipt?: string | null;
  rejection_reason?: string;
  inspection_request?: number;
  inspection_request_customer?: { username: string } | string | null;
}

export default function AdminPaymentsPage() {
  const [payments, setPayments] = useState<PaymentItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState("");
  const [page, setPage] = useState(1);
  const [total, setTotal] = useState(0);

  const fetchPayments = useCallback(
    async (pageNum: number): Promise<{ rows: PaymentItem[]; total: number }> => {
      const data = await apiClientFetch<
        { count: number; results: PaymentItem[] } | PaymentItem[]
      >(`/api/core/payments/?ordering=-created_at&page=${pageNum}`);
      const rows = Array.isArray(data) ? data : data.results ?? [];
      const total =
        !Array.isArray(data) && typeof data.count === "number"
          ? data.count
          : rows.length;
      return { rows, total };
    },
    []
  );

  useEffect(() => {
    fetchPayments(page)
      .then((r) => {
        setPayments(r.rows);
        setTotal(r.total);
      })
      .catch(() => toast.error("خطا در دریافت پرداخت‌ها"))
      .finally(() => setLoading(false));
  }, [fetchPayments, page]);

  const refresh = () => {
    setLoading(true);
    fetchPayments(page)
      .then((r) => {
        setPayments(r.rows);
        setTotal(r.total);
      })
      .catch(() => toast.error("خطا در دریافت پرداخت‌ها"))
      .finally(() => setLoading(false));
  };

  const act = async (
    id: number,
    action: "verify" | "reject",
    reason?: string
  ) => {
    try {
      if (action === "verify") {
        await apiClientFetch(`/api/core/credit/verify/${id}/`, { method: "POST", body: {} });
        toast.success("پرداخت تأیید شد");
      } else {
        await apiClientFetch(`/api/core/credit/reject/${id}/`, {
          method: "POST",
          body: { rejection_reason: reason || "دلیل مشخص نشده است" },
        });
        toast.success("پرداخت رد شد");
      }
      refresh();
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "خطا در عملیات");
    }
  };

  const filtered = payments.filter(
    (p) =>
      !filter ||
      String(p.id).includes(filter) ||
      (p.authority ?? "").includes(filter)
  );

  const pendingCount = payments.filter(
    (p) => p.status === "pending_verification" || p.status === "pending"
  ).length;

  return (
    <div className="flex flex-col gap-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="text-2xl font-semibold">مدیریت پرداخت‌ها</h1>
          <p className="text-muted-foreground text-sm">
            {pendingCount > 0
              ? `${pendingCount} پرداخت در انتظار بررسی`
              : "پرداختی در انتظار بررسی نیست"}
          </p>
        </div>
        <div className="flex items-center gap-2">
          <Input
            value={filter}
            onChange={(e) => setFilter(e.target.value)}
            placeholder="جستجو: شناسه یا Authority"
            className="w-56"
          />
          <Button
            variant="outline"
            size="icon"
            onClick={refresh}
            disabled={loading}
            title="به‌روزرسانی"
          >
            <RefreshCw className={`size-4 ${loading ? "animate-spin" : ""}`} />
          </Button>
        </div>
      </div>

      <Card>
        <CardContent className="px-0 py-2">
          {loading ? (
            <p className="text-muted-foreground py-10 text-center text-sm">در حال بارگذاری...</p>
          ) : filtered.length === 0 ? (
            <p className="text-muted-foreground py-10 text-center text-sm">
              <Receipt className="mx-auto mb-2 size-8 opacity-40" />
              پرداختی یافت نشد
            </p>
          ) : (
            <div className="flex flex-col divide-y">
              {filtered.map((p) => {
                const status = getStatusInfo(PAYMENT_STATUS_MAP, p.status);
                const isManualPending = p.status === "pending_verification";
                return (
                  <div key={p.id} className="flex flex-wrap items-center justify-between gap-3 px-5 py-4">
                    <div className="min-w-0">
                      <div className="flex items-center gap-2">
                        <span className="text-sm font-semibold">پرداخت #{p.id}</span>
                        <Badge variant={status.variant}>{status.label}</Badge>
                      </div>
                      <p className="text-muted-foreground mt-1 text-xs">
                        {p.created_at_jalali ?? ""}
                        {p.authority ? ` • ${p.authority}` : ""}
                      </p>
                      {p.credit_amount > 0 && (
                        <p className="text-muted-foreground mt-0.5 text-xs">
                          اعتبار: {formatToman(p.credit_amount)}
                        </p>
                      )}
                      {p.rejection_reason && (
                        <p className="text-destructive mt-0.5 text-xs">دلیل رد: {p.rejection_reason}</p>
                      )}
                    </div>
                    <div className="flex shrink-0 items-center gap-2">
                      <span className="text-sm font-semibold">{formatToman(p.amount)}</span>
                      {p.bank_receipt && (
                        <Button size="sm" variant="outline" asChild>
                          <a
                            href={`/api/download/core/payments/${p.id}/receipt/`}
                            target="_blank"
                            rel="noreferrer"
                          >
                            فیش بانکی
                          </a>
                        </Button>
                      )}
                      {isManualPending && (
                        <>
                          <Button size="sm" variant="default" onClick={() => act(p.id, "verify")}>
                            <CheckCircle2 className="size-4" />
                            تأیید
                          </Button>
                          <Button size="sm" variant="destructive" onClick={() => act(p.id, "reject")}>
                            <XCircle className="size-4" />
                            رد
                          </Button>
                        </>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </CardContent>
      </Card>
      <PaginationClient
        current={page}
        totalItems={total}
        onPageChange={setPage}
      />
    </div>
  );
}

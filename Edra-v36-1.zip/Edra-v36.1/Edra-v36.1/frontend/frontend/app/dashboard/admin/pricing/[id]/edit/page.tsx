// app/dashboard/admin/pricing/[id]/edit/page.tsx
"use client";

import React, { useState, useEffect, useCallback } from "react";
import { useRouter, useParams } from "next/navigation";
import {
  Save,
  X,
  Trash2,
  Loader2,
  Wrench,
  Calculator,
  Users,
  Settings,
  Clock,
  List,
  Plus,
  Pencil,
  Check,
  RefreshCw,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { toast } from "sonner";
import { formatPrice, toPersianDigits } from "@/lib/utils";

// ============================================================
// 📦 تعریف انواع
// ============================================================

interface EquipmentType {
  id: number;
  name_fa: string;
}

interface EquipmentParameter {
  id: number;
  name: string;
  label: string;
  field_type: string;
  options: string;
  required: boolean;
  order: number;
}

interface ParameterPrice {
  id: number;
  pricing_rule: number;
  parameter: number;
  parameter_name: string;
  parameter_label: string;
  parameter_field_type: string;
  parameter_options: string;
  rate_type: "fixed" | "per_unit";
  rate: number;
}

interface PricingRule {
  id: number;
  equipment_type: number | EquipmentType;
  equipment_type_name: string;
  base_price: number;
  install_price: number;
  dismantle_price: number;
  standard_multiplier: number;
  pro_multiplier: number;
  custom_formula: string | null;
  updated_by: {
    id: number;
    username: string;
    full_name?: string;
  } | null;
  updated_at: string;
  created_at: string;
}

// ============================================================
// 🧩 کامپوننت مدیریت نرخ پارامترها (جدول + فرم Inline)
// ============================================================

interface ParameterPriceManagerProps {
  pricingRuleId: number;
  equipmentTypeId: number;
}

function ParameterPriceManager({
  pricingRuleId,
  equipmentTypeId,
}: ParameterPriceManagerProps) {
  const [params, setParams] = useState<EquipmentParameter[]>([]);
  const [paramPrices, setParamPrices] = useState<ParameterPrice[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);

  // حالت ویرایش Inline: یک ردیف از جدول به فرم تبدیل می‌شود
  const [editingParamId, setEditingParamId] = useState<number | null>(null);
  const [formData, setFormData] = useState({
    rate_type: "fixed" as "fixed" | "per_unit",
    rate: "",
  });
  const [editingPriceId, setEditingPriceId] = useState<number | null>(null);

  // دریافت پارامترهای تجهیزات
  const fetchParams = useCallback(async () => {
    if (!equipmentTypeId || equipmentTypeId === 0) {
      setParams([]);
      return;
    }
    try {
      const res = await fetch(`/api/proxy/core/equipment-types/${equipmentTypeId}/parameters/`);
      if (!res.ok) throw new Error(`خطا ${res.status}`);
      const data = await res.json();
      setParams(Array.isArray(data) ? data : data.results || []);
      setError(null);
    } catch (error) {
      console.error("❌ خطا در دریافت پارامترها:", error);
      setError("خطا در دریافت پارامترها");
      setParams([]);
    }
  }, [equipmentTypeId]);

  // دریافت نرخ‌های پارامترهای موجود
  const fetchParamPrices = useCallback(async () => {
    if (!pricingRuleId || pricingRuleId === 0) {
      setParamPrices([]);
      return;
    }
    try {
      const res = await fetch(`/api/proxy/pricing/parameter-prices/?pricing_rule=${pricingRuleId}`);
      if (!res.ok) throw new Error(`خطا ${res.status}`);
      const data = await res.json();
      setParamPrices(Array.isArray(data) ? data : data.results || []);
    } catch (error) {
      console.error("❌ خطا در دریافت نرخ پارامترها:", error);
      setParamPrices([]);
    }
  }, [pricingRuleId]);

  const loadData = useCallback(async () => {
    setLoading(true);
    setError(null);
    await Promise.all([fetchParams(), fetchParamPrices()]);
    setLoading(false);
  }, [fetchParams, fetchParamPrices]);

  useEffect(() => {
    loadData();
  }, [equipmentTypeId, pricingRuleId, loadData]);

  const getPriceForParam = (paramId: number): ParameterPrice | undefined => {
    return paramPrices.find((p) => p.parameter === paramId);
  };

  // شروع ویرایش یک پارامتر (تبدیل ردیف به فرم)
  const startEdit = (param: EquipmentParameter) => {
    const price = getPriceForParam(param.id);
    setEditingParamId(param.id);
    setEditingPriceId(price?.id || null);
    setFormData({
      rate_type: price?.rate_type || "fixed",
      rate: price ? String(price.rate) : "",
    });
  };

  // شروع افزودن نرخ برای یک پارامتر جدید
  const startAdd = (paramId: number) => {
    if (getPriceForParam(paramId)) {
      toast.error("این پارامتر قبلاً نرخ‌گذاری شده است.");
      return;
    }
    setEditingParamId(paramId);
    setEditingPriceId(null);
    setFormData({
      rate_type: "fixed",
      rate: "",
    });
  };

  // لغو ویرایش/افزودن
  const cancelEdit = () => {
    setEditingParamId(null);
    setEditingPriceId(null);
    setFormData({ rate_type: "fixed", rate: "" });
  };

  // ذخیره نرخ پارامتر
  const handleSavePrice = async () => {
    if (!editingParamId) {
      toast.error("لطفاً یک پارامتر را انتخاب کنید");
      return;
    }
    if (!formData.rate || Number(formData.rate) <= 0) {
      toast.error("لطفاً نرخ معتبر وارد کنید");
      return;
    }

    setSaving(true);
    try {
      const payload = {
        pricing_rule: pricingRuleId,
        parameter: editingParamId,
        rate_type: formData.rate_type,
        rate: Number(formData.rate),
      };

      const url = editingPriceId
        ? `/api/proxy/pricing/parameter-prices/${editingPriceId}/`
        : "/api/proxy/pricing/parameter-prices/";
      const method = editingPriceId ? "PUT" : "POST";

      const res = await fetch(url, {
        method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });

      if (!res.ok) {
        const errorData = await res.json().catch(() => ({}));
        throw new Error(errorData.detail || "خطا در ذخیره‌سازی");
      }

      toast.success(editingPriceId ? "نرخ پارامتر ویرایش شد" : "نرخ پارامتر افزوده شد");

      // بستن فرم و به‌روزرسانی لیست نرخ‌ها
      cancelEdit();
      await fetchParamPrices(); // فقط نرخ‌ها را به‌روز کن
    } catch (error: any) {
      console.error("❌ خطا در ذخیره‌سازی نرخ پارامتر:", error);
      toast.error(error.message || "خطا در ذخیره‌سازی نرخ پارامتر");
    } finally {
      setSaving(false);
    }
  };

  // حذف نرخ پارامتر
  const handleDeletePrice = async (id: number) => {
    if (!confirm("آیا از حذف این نرخ پارامتر مطمئن هستید؟")) return;
    try {
      const res = await fetch(`/api/proxy/pricing/parameter-prices/${id}/`, {
        method: "DELETE",
      });
      if (!res.ok) {
        const errorData = await res.json().catch(() => ({}));
        throw new Error(errorData.detail || "خطا در حذف");
      }
      toast.success("نرخ پارامتر حذف شد");
      await fetchParamPrices();
      if (editingPriceId === id) {
        cancelEdit();
      }
    } catch (error) {
      console.error("❌ خطا در حذف نرخ پارامتر:", error);
      toast.error(error instanceof Error ? error.message : "خطا در حذف نرخ پارامتر");
    }
  };

  if (loading) {
    return (
      <div className="flex justify-center py-8">
        <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
      </div>
    );
  }

  if (error) {
    return (
      <div className="text-center py-4">
        <p className="text-red-500 text-sm">{error}</p>
        <Button variant="outline" size="sm" className="mt-2" onClick={loadData}>
          تلاش مجدد
        </Button>
      </div>
    );
  }

  if (params.length === 0) {
    return (
      <div className="text-center py-4">
        <p className="text-muted-foreground text-sm">
          هیچ پارامتری برای این نوع تجهیزات تعریف نشده است.
        </p>
        <p className="text-xs text-muted-foreground mt-1">
          ابتدا در بخش "انواع تجهیزات" پارامترهای مورد نظر را تعریف کنید.
        </p>
      </div>
    );
  }

  // نگاشت نوع فیلد به نمایش فارسی
  // EDRA v32: date/time کم بودند (مدل EquipmentParameter.FIELD_TYPE_CHOICES
  // ۶ مقدار دارد نه ۴) — برای آن دو نوع، متن انگلیسی خام نشان داده می‌شد.
  const fieldTypeMap: Record<string, string> = {
    string: "متن",
    number: "عدد",
    select: "انتخاب از لیست",
    boolean: "بله/خیر",
    date: "تاریخ",
    time: "زمان",
  };

  // نگاشت نوع محاسبه به نمایش فارسی
  const rateTypeMap: Record<string, string> = {
    fixed: "ثابت",
    per_unit: "ضریب در مقدار",
  };

  return (
    <div className="space-y-4">
      <div className="overflow-x-auto">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>پارامتر</TableHead>
              <TableHead>نوع فیلد</TableHead>
              <TableHead>نوع محاسبه</TableHead>
              <TableHead>نرخ (تومان)</TableHead>
              <TableHead className="text-left">عملیات</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {params.map((param) => {
              const price = getPriceForParam(param.id);
              const isEditing = editingParamId === param.id;

              // اگر این ردیف در حال ویرایش است، فرم را نمایش بده
              if (isEditing) {
                return (
                  <TableRow key={param.id} className="bg-muted/50">
                    <TableCell className="font-medium">
                      {param.label}
                      <span className="text-xs text-muted-foreground block font-mono">
                        {param.name}
                      </span>
                    </TableCell>
                    <TableCell>{fieldTypeMap[param.field_type] || param.field_type}</TableCell>
                    <TableCell>
                      <Select
                        value={formData.rate_type}
                        onValueChange={(value: "fixed" | "per_unit") =>
                          setFormData({ ...formData, rate_type: value })
                        }
                      >
                        <SelectTrigger className="w-40">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="fixed">ثابت</SelectItem>
                          <SelectItem value="per_unit">ضریب در مقدار</SelectItem>
                        </SelectContent>
                      </Select>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <Input
                          type="number"
                          step="1000"
                          value={formData.rate}
                          onChange={(e) =>
                            setFormData({ ...formData, rate: e.target.value })
                          }
                          placeholder="نرخ"
                          className="w-36"
                        />
                        <span className="text-xs text-muted-foreground">تومان</span>
                        {price && (
                          <span className="text-xs text-muted-foreground whitespace-nowrap">
                            (قبلی: {toPersianDigits(formatPrice(price.rate))})
                          </span>
                        )}
                      </div>
                    </TableCell>
                    <TableCell className="text-left">
                      <Button
                        size="sm"
                        onClick={handleSavePrice}
                        disabled={saving}
                        className="ml-1"
                      >
                        {saving ? (
                          <Loader2 className="h-3 w-3 animate-spin" />
                        ) : (
                          <Check className="h-3 w-3" />
                        )}
                      </Button>
                      <Button
                        size="sm"
                        variant="ghost"
                        onClick={cancelEdit}
                        disabled={saving}
                      >
                        <X className="h-3 w-3" />
                      </Button>
                    </TableCell>
                  </TableRow>
                );
              }

              // نمایش عادی
              return (
                <TableRow key={param.id}>
                  <TableCell className="font-medium">
                    {param.label}
                    <span className="text-xs text-muted-foreground block font-mono">
                      {param.name}
                    </span>
                  </TableCell>
                  <TableCell>{fieldTypeMap[param.field_type] || param.field_type}</TableCell>
                  <TableCell>
                    {price ? (
                      <Badge variant="outline">
                        {rateTypeMap[price.rate_type] || price.rate_type}
                      </Badge>
                    ) : (
                      <span className="text-muted-foreground text-sm">—</span>
                    )}
                  </TableCell>
                  <TableCell>
                    {price ? (
                      <span className="font-medium">
                        {toPersianDigits(formatPrice(price.rate))}
                      </span>
                    ) : (
                      <span className="text-muted-foreground">—</span>
                    )}
                  </TableCell>
                  <TableCell className="text-left">
                    {price ? (
                      <>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => startEdit(param)}
                          title="ویرایش نرخ"
                        >
                          <Pencil className="h-3 w-3" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => handleDeletePrice(price.id)}
                          className="text-red-500 hover:text-red-700"
                          title="حذف نرخ"
                        >
                          <Trash2 className="h-3 w-3" />
                        </Button>
                      </>
                    ) : (
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => startAdd(param.id)}
                        title="افزودن نرخ"
                      >
                        <Plus className="h-3 w-3" />
                      </Button>
                    )}
                  </TableCell>
                </TableRow>
              );
            })}
          </TableBody>
        </Table>
      </div>
    </div>
  );
}

// ============================================================
// 📄 صفحه ویرایش قیمت
// ============================================================

export default function EditPricingPage() {
  const router = useRouter();
  const params = useParams();
  const id = params.id as string;

  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [fetchingEquipment, setFetchingEquipment] = useState(false);
  const [rule, setRule] = useState<PricingRule | null>(null);
  const [equipmentTypes, setEquipmentTypes] = useState<EquipmentType[]>([]);
  const [selectedEquipmentTypeId, setSelectedEquipmentTypeId] = useState<number | null>(null);
  const [formData, setFormData] = useState({
    equipment_type: "",
    base_price: "",
    install_price: "",
    dismantle_price: "",
    standard_multiplier: "",
    pro_multiplier: "",
    custom_formula: "",
  });
  const [showDeleteDialog, setShowDeleteDialog] = useState(false);

  // دریافت اطلاعات قیمت
  const fetchRule = useCallback(async () => {
    try {
      setLoading(true);
      const res = await fetch(`/api/proxy/pricing/rules/${id}/`);
      if (!res.ok) {
        const errorData = await res.json().catch(() => ({}));
        throw new Error(errorData.detail || "خطا در دریافت اطلاعات");
      }
      const data = await res.json();

      const equipmentTypeId = typeof data.equipment_type === "object"
        ? data.equipment_type.id
        : data.equipment_type;

      setRule(data);
      setSelectedEquipmentTypeId(equipmentTypeId);
      setFormData({
        equipment_type: String(equipmentTypeId),
        base_price: String(data.base_price),
        install_price: data.install_price !== null && data.install_price !== undefined ? String(data.install_price) : "",
        dismantle_price: data.dismantle_price !== null && data.dismantle_price !== undefined ? String(data.dismantle_price) : "",
        standard_multiplier: data.standard_multiplier !== null && data.standard_multiplier !== undefined ? String(data.standard_multiplier) : "",
        pro_multiplier: data.pro_multiplier !== null && data.pro_multiplier !== undefined ? String(data.pro_multiplier) : "",
        custom_formula: data.custom_formula || "",
      });
    } catch (error) {
      console.error("❌ خطا در دریافت قانون قیمت:", error);
      toast.error(error instanceof Error ? error.message : "خطا در دریافت اطلاعات");
      router.push("/dashboard/admin/pricing");
    } finally {
      setLoading(false);
    }
  }, [id, router]);

  // دریافت لیست تجهیزات (برای نمایش نام در صورت نیاز)
  const fetchEquipment = useCallback(async () => {
    try {
      setFetchingEquipment(true);
      const res = await fetch("/api/proxy/core/equipment-types/?all=true");
      if (!res.ok) {
        throw new Error("خطا در دریافت تجهیزات");
      }
      const data = await res.json();
      setEquipmentTypes(Array.isArray(data) ? data : data.results || []);
    } catch (error) {
      console.error("❌ خطا در دریافت لیست تجهیزات:", error);
      toast.error(error instanceof Error ? error.message : "خطا در دریافت لیست تجهیزات");
    } finally {
      setFetchingEquipment(false);
    }
  }, []);

  useEffect(() => {
    fetchRule();
    fetchEquipment();
  }, [fetchRule, fetchEquipment]);

  // ============================================================
  // 📤 ارسال داده‌های ویرایش قانون اصلی
  // ============================================================
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!formData.equipment_type) {
      toast.error("لطفاً نوع تجهیزات را انتخاب کنید");
      return;
    }
    if (!formData.base_price || Number(formData.base_price) <= 0) {
      toast.error("لطفاً قیمت پایه معتبر وارد کنید");
      return;
    }

    const payload: Record<string, any> = {
      equipment_type: Number(formData.equipment_type),
      base_price: Number(formData.base_price),
      standard_multiplier: formData.standard_multiplier
        ? Number(formData.standard_multiplier)
        : (rule?.standard_multiplier ?? 1.0),
      pro_multiplier: formData.pro_multiplier
        ? Number(formData.pro_multiplier)
        : (rule?.pro_multiplier ?? 1.5),
      install_price: formData.install_price ? Number(formData.install_price) : 0,
      dismantle_price: formData.dismantle_price ? Number(formData.dismantle_price) : 0,
    };

    if (formData.custom_formula && formData.custom_formula.trim() !== "") {
      payload.custom_formula = formData.custom_formula;
    }

    if (payload.standard_multiplier <= 0) {
      toast.error("ضریب خدمات استاندارد باید بزرگتر از صفر باشد.");
      return;
    }
    if (payload.pro_multiplier <= 0) {
      toast.error("ضریب خدمات حرفه‌ای باید بزرگتر از صفر باشد.");
      return;
    }
    if (payload.pro_multiplier <= payload.standard_multiplier) {
      toast.error("ضریب خدمات حرفه‌ای باید از ضریب استاندارد بیشتر باشد.");
      return;
    }

    setSaving(true);
    try {
      const res = await fetch(`/api/proxy/pricing/rules/${id}/`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });

      if (!res.ok) {
        const errorData = await res.json().catch(() => ({}));
        throw new Error(errorData.detail || errorData.error || "خطا در ذخیره‌سازی");
      }

      const result = await res.json();
      setRule(result);
      toast.success("قیمت با موفقیت ویرایش شد");
      router.push("/dashboard/admin/pricing");
      router.refresh();
    } catch (error) {
      console.error("❌ خطا در ویرایش قیمت:", error);
      toast.error(error instanceof Error ? error.message : "خطا در ویرایش قیمت");
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async () => {
    try {
      const res = await fetch(`/api/proxy/pricing/rules/${id}/`, {
        method: "DELETE",
      });
      if (!res.ok) {
        const errorData = await res.json().catch(() => ({}));
        throw new Error(errorData.detail || "خطا در حذف");
      }
      toast.success("قیمت حذف شد");
      router.push("/dashboard/admin/pricing");
      router.refresh();
    } catch (error) {
      console.error("❌ خطا در حذف قیمت:", error);
      toast.error(error instanceof Error ? error.message : "خطا در حذف قیمت");
    }
  };

  const formatDate = (dateStr: string | null) => {
    if (!dateStr) return "—";
    try {
      const date = new Date(dateStr);
      if (isNaN(date.getTime())) return "—";
      return date.toLocaleDateString("fa-IR-u-ca-persian", {
        year: "numeric",
        month: "2-digit",
        day: "2-digit",
        hour: "2-digit",
        minute: "2-digit",
      });
    } catch {
      return "—";
    }
  };

  const equipmentName = rule?.equipment_type_name || "";

  if (loading) {
    return (
      <div className="flex items-center justify-center p-12">
        <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
      </div>
    );
  }

  if (!rule) {
    return (
      <div className="flex items-center justify-center p-12 text-muted-foreground">
        قیمت مورد نظر یافت نشد.
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* هدر */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold">ویرایش قیمت</h1>
          <p className="text-muted-foreground text-sm">
            {equipmentName} - {toPersianDigits(formatPrice(rule.base_price))} تومان
          </p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" onClick={() => router.back()}>
            <X className="ml-2 h-4 w-4" />
            انصراف
          </Button>
          <Button variant="destructive" onClick={() => setShowDeleteDialog(true)}>
            <Trash2 className="ml-2 h-4 w-4" />
            حذف
          </Button>
        </div>
      </div>

      <form onSubmit={handleSubmit}>
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* ستون راست */}
          <div className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Wrench className="h-4 w-4" />
                  اطلاعات پایه
                </CardTitle>
                <CardDescription>نوع تجهیزات و قیمت پایه</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label>نوع تجهیزات</Label>
                  <Input
                    value={equipmentName}
                    disabled
                    className="bg-muted cursor-not-allowed"
                  />
                  <input type="hidden" name="equipment_type" value={formData.equipment_type} />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="base_price">قیمت پایه (تومان) *</Label>
                  <Input
                    id="base_price"
                    type="number"
                    value={formData.base_price}
                    onChange={(e) => setFormData({ ...formData, base_price: e.target.value })}
                    placeholder="مثلاً 2500000"
                    required
                  />
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Clock className="h-4 w-4" />
                  اطلاعات سیستمی
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-2 text-sm">
                <div className="flex justify-between border-b py-1">
                  <span className="text-muted-foreground">بروزرسانی‌شده توسط</span>
                  <span className="font-medium">
                    {rule.updated_by?.full_name || rule.updated_by?.username || "سیستم"}
                  </span>
                </div>
                <div className="flex justify-between border-b py-1">
                  <span className="text-muted-foreground">آخرین بروزرسانی</span>
                  <span className="font-medium">{formatDate(rule.updated_at)}</span>
                </div>
                <div className="flex justify-between py-1">
                  <span className="text-muted-foreground">تاریخ ایجاد</span>
                  <span className="font-medium">{formatDate(rule.created_at)}</span>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* ستون چپ */}
          <div className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Calculator className="h-4 w-4" />
                  هزینه‌های نصب و دمونتاژ
                </CardTitle>
                <CardDescription>اختیاری</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="install_price">هزینه نصب (تومان)</Label>
                  <Input
                    id="install_price"
                    type="number"
                    value={formData.install_price}
                    onChange={(e) => setFormData({ ...formData, install_price: e.target.value })}
                    placeholder="مثلاً 500000"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="dismantle_price">هزینه دمونتاژ (تومان)</Label>
                  <Input
                    id="dismantle_price"
                    type="number"
                    value={formData.dismantle_price}
                    onChange={(e) => setFormData({ ...formData, dismantle_price: e.target.value })}
                    placeholder="مثلاً 300000"
                  />
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Users className="h-4 w-4" />
                  ضریب خدمات
                </CardTitle>
                <CardDescription>اختیاری</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="standard_multiplier">ضریب استاندارد</Label>
                  <Input
                    id="standard_multiplier"
                    type="number"
                    step="0.01"
                    value={formData.standard_multiplier}
                    onChange={(e) => setFormData({ ...formData, standard_multiplier: e.target.value })}
                    placeholder="مثلاً 1.0"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="pro_multiplier">ضریب حرفه‌ای</Label>
                  <Input
                    id="pro_multiplier"
                    type="number"
                    step="0.01"
                    value={formData.pro_multiplier}
                    onChange={(e) => setFormData({ ...formData, pro_multiplier: e.target.value })}
                    placeholder="مثلاً 1.5"
                  />
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Settings className="h-4 w-4" />
                  تنظیمات پیشرفته
                </CardTitle>
                <CardDescription>فرمول سفارشی</CardDescription>
              </CardHeader>
              <CardContent>
                <Textarea
                  id="custom_formula"
                  value={formData.custom_formula}
                  onChange={(e) => setFormData({ ...formData, custom_formula: e.target.value })}
                  placeholder="(base_price * standard_multiplier) + install_price"
                  rows={3}
                />
                <p className="text-warning text-xs">
                  ⚠️ توجه: این فیلد فعلاً ذخیره می‌شود ولی در محاسبه‌ی قیمت اعمال نمی‌شود.
                  قیمت از «قیمت پایه + نرخ پارامترها + هزینه شهر» × «ضریب سرویس» + «هزینه نصب/دمونتاژ» محاسبه می‌شود.
                </p>
              </CardContent>
            </Card>

            {/* ✅ مدیریت نرخ پارامترها */}
            <Card className="col-span-2">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <List className="h-4 w-4" />
                  نرخ‌های پارامترها
                </CardTitle>
                <CardDescription>
                  تعیین نرخ برای هر پارامتر این نوع تجهیزات
                </CardDescription>
              </CardHeader>
              <CardContent>
                <ParameterPriceManager
                  pricingRuleId={rule.id}
                  equipmentTypeId={selectedEquipmentTypeId || 0}
                />
              </CardContent>
            </Card>
          </div>

          <div className="lg:col-span-2">
            <Button type="submit" className="w-full" disabled={saving}>
              <Save className="ml-2 h-4 w-4" />
              {saving ? "در حال ذخیره..." : "ذخیره تغییرات"}
            </Button>
          </div>
        </div>
      </form>

      <Dialog open={showDeleteDialog} onOpenChange={setShowDeleteDialog}>
        <DialogContent className="max-w-sm">
          <DialogHeader>
            <DialogTitle>تأیید حذف</DialogTitle>
            <DialogDescription>
              آیا از حذف این قیمت مطمئن هستید؟ این عملیات غیرقابل بازگشت است.
            </DialogDescription>
          </DialogHeader>
          <div className="flex gap-2 pt-4">
            <Button variant="outline" className="flex-1" onClick={() => setShowDeleteDialog(false)}>
              انصراف
            </Button>
            <Button variant="destructive" className="flex-1" onClick={handleDelete}>
              حذف
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
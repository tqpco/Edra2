// app/dashboard/admin/pricing/new/page.tsx
"use client";

import React, { useState, useEffect } from "react";
import { useRouter } from "next/navigation";
import { Save, X, Loader2, Wrench, Calculator, Users, Settings, List } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { toast } from "sonner";

interface EquipmentType {
  id: number;
  name_fa: string;
}

export default function NewPricingPage() {
  const router = useRouter();
  const [loading, setLoading] = useState(false);
  const [equipmentTypes, setEquipmentTypes] = useState<EquipmentType[]>([]);
  const [fetchingEquipment, setFetchingEquipment] = useState(false);

  const [formData, setFormData] = useState({
    equipment_type: "",
    base_price: "",
    install_price: "",
    dismantle_price: "",
    standard_multiplier: "",
    pro_multiplier: "",
    custom_formula: "",
  });

  useEffect(() => {
    const fetchEquipment = async () => {
      try {
        setFetchingEquipment(true);
        const res = await fetch("/api/proxy/core/equipment-types/?all=true");
        if (!res.ok) {
          throw new Error("خطا در دریافت تجهیزات");
        }
        const data = await res.json();
        setEquipmentTypes(Array.isArray(data) ? data : data.results || []);
      } catch (error) {
        toast.error(error instanceof Error ? error.message : "خطا در دریافت لیست تجهیزات");
      } finally {
        setFetchingEquipment(false);
      }
    };
    fetchEquipment();
  }, []);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!formData.equipment_type) {
      toast.error("لطفاً نوع تجهیزات را انتخاب کنید");
      return;
    }
    if (!formData.base_price || Number(formData.base_price) <= 0) {
      toast.error("لطفاً قیمت پایه معتبر وارد کنید");
      return;
    }

    const payload: Record<string, any> = {
      equipment_type: Number(formData.equipment_type),
      base_price: Number(formData.base_price),
    };

    if (formData.install_price && formData.install_price.trim() !== "") {
      payload.install_price = Number(formData.install_price);
    }
    if (formData.dismantle_price && formData.dismantle_price.trim() !== "") {
      payload.dismantle_price = Number(formData.dismantle_price);
    }
    if (formData.standard_multiplier && formData.standard_multiplier.trim() !== "") {
      payload.standard_multiplier = Number(formData.standard_multiplier);
    }
    if (formData.pro_multiplier && formData.pro_multiplier.trim() !== "") {
      payload.pro_multiplier = Number(formData.pro_multiplier);
    }
    if (formData.custom_formula && formData.custom_formula.trim() !== "") {
      payload.custom_formula = formData.custom_formula;
    }

    setLoading(true);
    try {
      const res = await fetch("/api/proxy/pricing/rules/", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });

      if (!res.ok) {
        const errorData = await res.json().catch(() => ({}));
        throw new Error(errorData.detail || errorData.error || "خطا در ذخیره‌سازی");
      }

      const result = await res.json();
      toast.success("قیمت جدید با موفقیت ایجاد شد");
      router.push(`/dashboard/admin/pricing/${result.id}/edit`);
      router.refresh();
    } catch (error) {
      console.error("❌ خطا در ایجاد قیمت:", error);
      toast.error(error instanceof Error ? error.message : "خطا در ایجاد قیمت");
    } finally {
      setLoading(false);
    }
  };

  const handleCancel = () => {
    router.back();
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold">افزودن قیمت جدید</h1>
          <p className="text-muted-foreground text-sm">
            قوانین قیمت‌گذاری جدید را برای نوع تجهیزات تعریف کنید
          </p>
        </div>
        <Button variant="outline" onClick={handleCancel}>
          <X className="ml-2 h-4 w-4" />
          انصراف
        </Button>
      </div>

      <form onSubmit={handleSubmit}>
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <div className="lg:col-span-1 space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Wrench className="h-4 w-4" />
                  اطلاعات پایه
                </CardTitle>
                <CardDescription>نوع تجهیزات و قیمت پایه</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="equipment_type">نوع تجهیزات *</Label>
                  <Select
                    value={formData.equipment_type}
                    onValueChange={(value) =>
                      setFormData({ ...formData, equipment_type: value })
                    }
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="انتخاب کنید" />
                    </SelectTrigger>
                    <SelectContent>
                      {fetchingEquipment ? (
                        <div className="flex items-center justify-center p-2">
                          <Loader2 className="h-4 w-4 animate-spin" />
                        </div>
                      ) : equipmentTypes.length === 0 ? (
                        <div className="p-2 text-center text-sm text-muted-foreground">
                          نوع تجهیزاتی یافت نشد
                        </div>
                      ) : (
                        equipmentTypes.map((eq) => (
                          <SelectItem key={eq.id} value={String(eq.id)}>
                            {eq.name_fa}
                          </SelectItem>
                        ))
                      )}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="base_price">قیمت پایه (تومان) *</Label>
                  <Input
                    id="base_price"
                    type="number"
                    value={formData.base_price}
                    onChange={(e) =>
                      setFormData({ ...formData, base_price: e.target.value })
                    }
                    placeholder="مثلاً 2500000"
                    required
                  />
                </div>
              </CardContent>
            </Card>
          </div>

          <div className="lg:col-span-1 space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Calculator className="h-4 w-4" />
                  هزینه‌های نصب و دمونتاژ
                </CardTitle>
                <CardDescription>اختیاری - در صورت نیاز وارد کنید</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="install_price">هزینه نصب (تومان)</Label>
                  <Input
                    id="install_price"
                    type="number"
                    value={formData.install_price}
                    onChange={(e) =>
                      setFormData({ ...formData, install_price: e.target.value })
                    }
                    placeholder="مثلاً 500000"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="dismantle_price">هزینه دمونتاژ (تومان)</Label>
                  <Input
                    id="dismantle_price"
                    type="number"
                    value={formData.dismantle_price}
                    onChange={(e) =>
                      setFormData({ ...formData, dismantle_price: e.target.value })
                    }
                    placeholder="مثلاً 300000"
                  />
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Users className="h-4 w-4" />
                  ضریب خدمات
                </CardTitle>
                <CardDescription>اختیاری - ضرایب سرویس‌های استاندارد و حرفه‌ای</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="standard_multiplier">ضریب خدمات استاندارد</Label>
                  <Input
                    id="standard_multiplier"
                    type="number"
                    step="0.01"
                    value={formData.standard_multiplier}
                    onChange={(e) =>
                      setFormData({ ...formData, standard_multiplier: e.target.value })
                    }
                    placeholder="مثلاً 1.0"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="pro_multiplier">ضریب خدمات حرفه‌ای</Label>
                  <Input
                    id="pro_multiplier"
                    type="number"
                    step="0.01"
                    value={formData.pro_multiplier}
                    onChange={(e) =>
                      setFormData({ ...formData, pro_multiplier: e.target.value })
                    }
                    placeholder="مثلاً 1.5"
                  />
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Settings className="h-4 w-4" />
                  تنظیمات پیشرفته
                </CardTitle>
                <CardDescription>فرمول سفارشی محاسبه قیمت</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  <Label htmlFor="custom_formula">فرمول سفارشی</Label>
                  <Textarea
                    id="custom_formula"
                    value={formData.custom_formula}
                    onChange={(e) =>
                      setFormData({ ...formData, custom_formula: e.target.value })
                    }
                    placeholder="مثلاً (base_price * standard_multiplier) + install_price"
                    rows={3}
                  />
                <p className="text-warning text-xs">
                  ⚠️ توجه: این فیلد فعلاً ذخیره می‌شود ولی در محاسبه‌ی قیمت اعمال نمی‌شود.
                  قیمت از «قیمت پایه + نرخ پارامترها + هزینه شهر» × «ضریب سرویس» + «هزینه نصب/دمونتاژ» محاسبه می‌شود.
                </p>
                </div>
              </CardContent>
            </Card>

            {/* ✅ بخش نرخ پارامترها (فقط راهنما، چون قانون هنوز ایجاد نشده) */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <List className="h-4 w-4" />
                  نرخ‌های پارامترها
                </CardTitle>
                <CardDescription>
                  پس از ایجاد قیمت، می‌توانید نرخ پارامترها را مدیریت کنید.
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="rounded-lg border border-dashed p-6 text-center text-muted-foreground">
                  <p className="text-sm">
                    برای افزودن نرخ پارامترها، ابتدا قیمت را ایجاد کنید.
                  </p>
                  <p className="text-xs mt-1">
                    پس از ایجاد، به صفحه ویرایش هدایت می‌شوید.
                  </p>
                </div>
              </CardContent>
            </Card>
          </div>

          <div className="lg:col-span-2">
            <Button type="submit" className="w-full" disabled={loading}>
              <Save className="ml-2 h-4 w-4" />
              {loading ? "در حال ذخیره..." : "ایجاد قیمت"}
            </Button>
          </div>
        </div>
      </form>
    </div>
  );
}
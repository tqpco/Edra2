// app/dashboard/admin/pricing/page.tsx
"use client";

import React, { useState, useEffect, useCallback } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import {
  Plus,
  Pencil,
  Trash2,
  Loader2,
  Search,
  RefreshCw,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { toast } from "sonner";
import { formatPrice, toPersianDigits } from "@/lib/utils";
import { PaginationClient } from "@/components/ui/pagination";
import { Badge } from "@/components/ui/badge";

// ============================================================
// 📦 تعریف انواع
// ============================================================

interface EquipmentType {
  id: number;
  name_fa: string;
  name?: string;
}

interface PricingRule {
  id: number;
  equipment_type: number | EquipmentType;
  base_price: number;
  install_price: number;
  dismantle_price: number;
  standard_multiplier: number;
  pro_multiplier: number;
  custom_formula: string | null;
  updated_by: {
    id: number;
    username: string;
    full_name?: string;
  } | null;
  updated_at: string;
  created_at: string;
}

// ============================================================
// توابع کمکی
// ============================================================

const renderCost = (value: number | null | undefined): string => {
  if (value === null || value === undefined) return "—";
  return toPersianDigits(formatPrice(value));
};

const renderMultiplier = (value: number | null | undefined): string => {
  if (value === null || value === undefined) return "—";
  return toPersianDigits(value);
};

// ============================================================
// 📄 صفحه اصلی لیست قیمت‌گذاری
// ============================================================

export default function AdminPricingPage() {
  const router = useRouter();
  const [rules, setRules] = useState<PricingRule[]>([]);
  const [equipmentMap, setEquipmentMap] = useState<Map<number, string>>(new Map());
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [searchTerm, setSearchTerm] = useState("");
  const [page, setPage] = useState(1);
  const [totalItems, setTotalItems] = useState(0);

  // 📥 دریافت لیست تجهیزات
  const fetchEquipmentList = useCallback(async () => {
    try {
      const res = await fetch("/api/proxy/core/equipment-types/?all=true");
      if (!res.ok) {
        console.warn("⚠️ دریافت لیست تجهیزات ناموفق:", res.status);
        return;
      }
      const data = await res.json();
      const items = Array.isArray(data) ? data : data.results || [];
      const map = new Map<number, string>();
      items.forEach((eq: EquipmentType) => {
        map.set(eq.id, eq.name_fa || eq.name || `تجهیزات ${eq.id}`);
      });
      setEquipmentMap(map);
    } catch (error) {
      console.warn("⚠️ خطا در دریافت لیست تجهیزات:", error);
    }
  }, []);

  // 📥 دریافت لیست قیمت‌ها
  const fetchRules = useCallback(
    async (pageNum: number = 1, search: string = "") => {
      try {
        setLoading(true);
        setError(null);
        const params = new URLSearchParams();
        if (search) params.append("search", search);
        if (pageNum) params.append("page", String(pageNum));

        const res = await fetch(`/api/proxy/pricing/rules/?${params.toString()}`);
        if (!res.ok) {
          let errorMessage = `خطا ${res.status}`;
          try {
            const errorData = await res.json();
            errorMessage = errorData.detail || errorData.error || errorMessage;
          } catch {
            errorMessage = `خطا ${res.status}: ${res.statusText}`;
          }
          throw new Error(errorMessage);
        }

        const data = await res.json();

        let items: PricingRule[] = [];
        let count = 0;

        if (data.results) {
          items = data.results;
          count = data.count;
        } else if (Array.isArray(data)) {
          items = data;
          count = data.length;
        }

        setRules(items);
        setTotalItems(count);
        setError(null);
      } catch (error) {
        console.error("❌ خطا در دریافت لیست قیمت‌ها:", error);
        const errorMessage = error instanceof Error ? error.message : "خطا در دریافت لیست قیمت‌ها";
        setError(errorMessage);
        toast.error(errorMessage);
      } finally {
        setLoading(false);
      }
    },
    []
  );

  // بارگذاری اولیه
  useEffect(() => {
    const loadData = async () => {
      await Promise.all([fetchEquipmentList(), fetchRules(page, searchTerm)]);
    };
    loadData();
  }, []);

  // بارگذاری مجدد با تغییر صفحه یا جستجو
  useEffect(() => {
    fetchRules(page, searchTerm);
  }, [page, searchTerm, fetchRules]);

  const handleSearch = (value: string) => {
    setSearchTerm(value);
    setPage(1);
  };

  const handleDelete = async (id: number) => {
    if (!confirm("آیا از حذف این قیمت مطمئن هستید؟")) return;
    try {
      const res = await fetch(`/api/proxy/pricing/rules/${id}/`, {
        method: "DELETE",
      });
      if (!res.ok) {
        const errorData = await res.json().catch(() => ({}));
        throw new Error(errorData.detail || "خطا در حذف");
      }
      toast.success("قیمت حذف شد");
      fetchRules(page, searchTerm);
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : "خطا در حذف قیمت";
      toast.error(errorMessage);
    }
  };

  const handleRefresh = () => {
    fetchEquipmentList();
    fetchRules(page, searchTerm);
  };

  const formatDate = (dateStr: string | null) => {
    if (!dateStr) return "—";
    try {
      const date = new Date(dateStr);
      if (isNaN(date.getTime())) return "—";
      return date.toLocaleDateString("fa-IR-u-ca-persian", {
        year: "numeric",
        month: "2-digit",
        day: "2-digit",
        hour: "2-digit",
        minute: "2-digit",
      });
    } catch {
      return "—";
    }
  };

  const getEquipmentName = (rule: PricingRule) => {
    if (typeof rule.equipment_type === "object" && rule.equipment_type !== null) {
      const eq = rule.equipment_type as EquipmentType;
      return eq.name_fa || eq.name || `تجهیزات ${eq.id}`;
    }
    const id = typeof rule.equipment_type === "number" ? rule.equipment_type : Number(rule.equipment_type);
    if (!isNaN(id) && equipmentMap.has(id)) {
      return equipmentMap.get(id) || `تجهیزات ${id}`;
    }
    return "بدون نام";
  };

  if (loading && rules.length === 0) {
    return (
      <div className="flex items-center justify-center p-12">
        <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="text-2xl font-bold">قیمت‌گذاری</h1>
          <p className="text-muted-foreground text-sm">
            مدیریت قوانین قیمت‌گذاری بر اساس نوع تجهیزات
          </p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" size="icon" onClick={handleRefresh} title="بروزرسانی">
            <RefreshCw className="h-4 w-4" />
          </Button>
          <Link href="/dashboard/admin/pricing/new">
            <Button>
              <Plus className="ml-2 h-4 w-4" />
              قیمت جدید
            </Button>
          </Link>
        </div>
      </div>

      <div className="relative max-w-sm">
        <Search className="absolute right-3 top-2.5 h-4 w-4 text-muted-foreground" />
        <Input
          placeholder="جستجوی قیمت..."
          value={searchTerm}
          onChange={(e) => handleSearch(e.target.value)}
          className="pr-9"
        />
      </div>

      <Card>
        <CardHeader>
          <CardTitle>لیست قیمت‌ها</CardTitle>
          <CardDescription>
            {totalItems > 0
              ? `${toPersianDigits(totalItems)} قیمت ثبت‌شده در سیستم`
              : "هیچ قیمتی ثبت نشده است"}
          </CardDescription>
        </CardHeader>
        <CardContent>
          {error ? (
            <div className="text-center text-red-500 py-8">
              <p>خطا در بارگذاری اطلاعات</p>
              <p className="text-sm">{error}</p>
              <Button variant="outline" className="mt-4" onClick={handleRefresh}>
                تلاش مجدد
              </Button>
            </div>
          ) : rules.length === 0 ? (
            <div className="text-center text-muted-foreground py-12">
              <p className="text-lg">هیچ قیمتی ثبت نشده است.</p>
              <p className="text-sm mt-2">برای افزودن قیمت جدید، دکمه "قیمت جدید" را کلیک کنید.</p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>#</TableHead>
                    <TableHead>نوع تجهیزات</TableHead>
                    <TableHead className="text-left">قیمت پایه</TableHead>
                    <TableHead className="text-left">هزینه نصب</TableHead>
                    <TableHead className="text-left">هزینه دمونتاژ</TableHead>
                    <TableHead>ضریب استاندارد</TableHead>
                    <TableHead>ضریب حرفه‌ای</TableHead>
                    <TableHead>آخرین بروزرسانی</TableHead>
                    <TableHead className="text-left">عملیات</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {rules.map((rule) => (
                    <TableRow key={rule.id} className="hover:bg-accent/50">
                      <TableCell>{toPersianDigits(rule.id)}</TableCell>
                      <TableCell className="font-medium">
                        {getEquipmentName(rule)}
                      </TableCell>
                      <TableCell className="text-left font-medium">
                        {toPersianDigits(formatPrice(rule.base_price))}
                      </TableCell>
                      <TableCell className="text-left">
                        {renderCost(rule.install_price)}
                      </TableCell>
                      <TableCell className="text-left">
                        {renderCost(rule.dismantle_price)}
                      </TableCell>
                      <TableCell>
                        {renderMultiplier(rule.standard_multiplier)}
                      </TableCell>
                      <TableCell>
                        {renderMultiplier(rule.pro_multiplier)}
                      </TableCell>
                      <TableCell className="text-muted-foreground text-sm">
                        {formatDate(rule.updated_at)}
                      </TableCell>
                      <TableCell className="text-left">
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() =>
                            router.push(`/dashboard/admin/pricing/${rule.id}/edit`)
                          }
                        >
                          <Pencil className="h-4 w-4" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => handleDelete(rule.id)}
                          className="text-red-500 hover:text-red-700"
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}

          {totalItems > 10 && (
            <div className="mt-4 flex items-center justify-between">
              <p className="text-muted-foreground text-sm">
                نمایش {toPersianDigits(rules.length)} از {toPersianDigits(totalItems)}
              </p>
              <PaginationClient
                current={page}
                totalItems={totalItems}
                onPageChange={setPage}
                pageSize={10}
              />
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
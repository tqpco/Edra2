import { apiServerFetch } from "@/lib/api-server";
import { fetchPaginated } from "@/lib/paginated-fetch";
import { ProjectsClient } from "./projects-client";

export const metadata = { title: "پروژه‌ها" };

interface ProjectItem {
  id: number;
  name: string;
  organization?: number | null;
  is_active?: boolean;
}

async function fetchProjects(page: number) {
  return fetchPaginated<ProjectItem>(`/api/core/projects/`, page);
}

async function fetchOrgs(): Promise<Record<number, string>> {
  try {
    const data = await apiServerFetch<{ results: { id: number; name: string }[] } | { id: number; name: string }[]>(
      "/api/core/organizations/"
    );
    const list = Array.isArray(data) ? data : data.results ?? [];
    return Object.fromEntries(list.map((o) => [o.id, o.name]));
  } catch {
    return {};
  }
}

export default async function AdminProjectsPage({ searchParams }: { searchParams: Promise<{ page?: string }> }) {
  const _page = Math.max(1, Number((await searchParams).page) || 1);
  const [projectsRes, orgs] = await Promise.all([fetchProjects(_page), fetchOrgs()]);
  const { items: projects, count } = projectsRes;

  return (
    <div className="flex flex-col gap-6">
      <ProjectsClient projects={projects} orgs={orgs} count={count} page={_page} />
    </div>
  );
}

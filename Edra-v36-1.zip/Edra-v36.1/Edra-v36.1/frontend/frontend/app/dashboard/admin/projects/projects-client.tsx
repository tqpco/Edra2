"use client";

import * as React from "react";
import { useRouter } from "next/navigation";
import { toast } from "sonner";
import { Plus, Pencil, Trash2, FolderKanban } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import { apiClientFetch, ClientApiError } from "@/lib/api-client";
import { Pagination } from "@/components/ui/pagination";

interface ProjectItem {
  id: number;
  name: string;
  organization?: number | null;
  is_active?: boolean;
}

const NONE = "__none__";
const EMPTY = { name: "", organization: NONE, is_active: true };

export function ProjectsClient({
  projects,
  orgs,
  count,
  page,
}: {
  projects: ProjectItem[];
  orgs: Record<number, string>;
  count: number;
  page: number;
}) {
  const router = useRouter();
  const [dialogOpen, setDialogOpen] = React.useState(false);
  const [editing, setEditing] = React.useState<ProjectItem | null>(null);
  const [form, setForm] = React.useState(EMPTY);
  const [saving, setSaving] = React.useState(false);
  const [deleteTarget, setDeleteTarget] = React.useState<ProjectItem | null>(null);
  const [deleting, setDeleting] = React.useState(false);

  function openCreate() {
    setEditing(null);
    setForm(EMPTY);
    setDialogOpen(true);
  }

  function openEdit(p: ProjectItem) {
    setEditing(p);
    setForm({
      name: p.name,
      organization: p.organization ? String(p.organization) : NONE,
      is_active: p.is_active ?? true,
    });
    setDialogOpen(true);
  }

  async function submit() {
    if (!form.name.trim()) {
      toast.error("نام پروژه الزامی است.");
      return;
    }
    setSaving(true);
    try {
      const payload = {
        name: form.name,
        organization: form.organization === NONE ? null : Number(form.organization),
        is_active: form.is_active,
      };
      const path = editing ? `/api/core/projects/${editing.id}/` : `/api/core/projects/`;
      await apiClientFetch(path, { method: editing ? "PATCH" : "POST", body: payload });
      toast.success(editing ? "پروژه ویرایش شد." : "پروژه جدید ساخته شد.");
      setDialogOpen(false);
      router.refresh();
    } catch (err) {
      toast.error(err instanceof ClientApiError ? err.message : "خطا در ذخیره‌سازی.");
    } finally {
      setSaving(false);
    }
  }

  async function confirmDelete() {
    if (!deleteTarget) return;
    setDeleting(true);
    try {
      await apiClientFetch(`/api/core/projects/${deleteTarget.id}/`, { method: "DELETE" });
      toast.success("پروژه حذف شد.");
      setDeleteTarget(null);
      router.refresh();
    } catch (err) {
      toast.error(err instanceof ClientApiError ? err.message : "خطا در حذف.");
    } finally {
      setDeleting(false);
    }
  }

  return (
    <>
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="text-2xl font-semibold">پروژه‌ها</h1>
          <p className="text-muted-foreground text-sm">پروژه‌های بازرسی سازمان‌ها</p>
        </div>
        <Button onClick={openCreate}>
          <Plus className="size-4" />
          پروژه جدید
        </Button>
      </div>

      <Card>
        <CardContent className="px-0 py-2">
          {projects.length === 0 ? (
            <p className="text-muted-foreground py-10 text-center text-sm">
              <FolderKanban className="mx-auto mb-2 size-8 opacity-40" />
              پروژه‌ای ثبت نشده است
            </p>
          ) : (
            <div className="flex flex-col divide-y">
              {projects.map((project) => (
                <div key={project.id} className="flex items-center justify-between px-5 py-4">
                  <div className="flex items-center gap-3">
                    <span className="bg-primary/10 text-primary flex size-9 items-center justify-center rounded-lg">
                      <FolderKanban className="size-4" />
                    </span>
                    <div>
                      <p className="text-sm font-medium">{project.name}</p>
                      {project.organization && (
                        <p className="text-muted-foreground text-xs">
                          {orgs[project.organization] ?? `سازمان #${project.organization}`}
                          {!project.is_active && " — غیرفعال"}
                        </p>
                      )}
                    </div>
                  </div>
                  <div className="flex items-center gap-1">
                    <Button variant="ghost" size="icon" className="size-8" onClick={() => openEdit(project)}>
                      <Pencil className="size-3.5" />
                    </Button>
                    <Button
                      variant="ghost"
                      size="icon"
                      className="text-destructive size-8"
                      onClick={() => setDeleteTarget(project)}
                    >
                      <Trash2 className="size-3.5" />
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      <Pagination current={page} totalItems={count} basePath="/dashboard/admin/projects" />

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>{editing ? "ویرایش پروژه" : "پروژه جدید"}</DialogTitle>
          </DialogHeader>
          <div className="flex flex-col gap-4">
            <div className="grid gap-1.5">
              <Label htmlFor="project-name">نام پروژه</Label>
              <Input
                id="project-name"
                value={form.name}
                onChange={(e) => setForm({ ...form, name: e.target.value })}
              />
            </div>
            <div className="grid gap-1.5">
              <Label>سازمان (اختیاری)</Label>
              <Select
                value={form.organization}
                onValueChange={(v) => setForm({ ...form, organization: v })}
              >
                <SelectTrigger>
                  <SelectValue placeholder="بدون سازمان" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value={NONE}>بدون سازمان</SelectItem>
                  {Object.entries(orgs).map(([id, name]) => (
                    <SelectItem key={id} value={id}>
                      {name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="flex items-center justify-between rounded-md border p-3">
              <Label htmlFor="project-active">فعال</Label>
              <Switch
                id="project-active"
                checked={form.is_active}
                onCheckedChange={(v) => setForm({ ...form, is_active: v })}
              />
            </div>
          </div>
          <div className="flex justify-end gap-2">
            <Button variant="outline" onClick={() => setDialogOpen(false)}>
              انصراف
            </Button>
            <Button onClick={submit} disabled={saving}>
              {saving ? "در حال ذخیره..." : "ذخیره"}
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      <Dialog open={Boolean(deleteTarget)} onOpenChange={(o) => !o && setDeleteTarget(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>حذف «{deleteTarget?.name}»</DialogTitle>
            <DialogDescription>این عملیات قابل بازگشت نیست.</DialogDescription>
          </DialogHeader>
          <div className="flex justify-end gap-2">
            <Button variant="outline" onClick={() => setDeleteTarget(null)}>
              انصراف
            </Button>
            <Button variant="destructive" onClick={confirmDelete} disabled={deleting}>
              {deleting ? "در حال حذف..." : "حذف"}
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
}

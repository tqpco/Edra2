// app/dashboard/admin/requests/[id]/edit/page.tsx
"use client";

import { useState, useEffect, useCallback } from "react";
import { useRouter, useParams } from "next/navigation";
import {
  Save,
  X,
  Trash2,
  Loader2,
  User,
  Package,
  MapPin,
  Calendar,
  Wallet,
  UserPlus,
  Plus,
  RefreshCw,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { toast } from "sonner";
import { toPersianDigits, formatPrice } from "@/lib/utils";

// ============================================================
// انواع داده
// ============================================================

interface User {
  id: number;
  username: string;
  full_name: string;
  phone: string;
  role?: "admin" | "expert" | "customer";
}

interface EquipmentType {
  id: number;
  code: string;
  name_fa: string;
  param_schema: ParamSchema[];
  supports_install_state: boolean;
  install_state_required: boolean;
}

interface ParamSchema {
  name: string;
  label: string;
  // EDRA v32: date/time کم بود (مدل ۶ نوع فیلد دارد)
  type: "string" | "number" | "select" | "boolean" | "date" | "time";
  required: boolean;
  options?: string[];
}

interface CityMultiplier {
  id: number;
  city: string;
  multiplier: number;
  base_cost: number;
  is_active: boolean;
}

interface InspectionRequest {
  id: number;
  request_number: string;
  customer: number;
  customer_name: string;
  equipment_type: number;
  equipment_type_name: string;
  brand_model: string;
  manufacture_year: number | null;
  params: Record<string, any>;
  install_state: string | null;
  service_type: "standard" | "pro";
  city: string;
  address: string;
  address_lat: number | null;
  address_lng: number | null;
  scheduled_at: string | null;
  assigned_expert: number | null;
  assigned_expert_name: string | null;
  discount_code: string | null;
  calculated_price: number;
  final_price: number;
  status: string;
  created_at: string;
  updated_at: string;
}

interface DiscountCode {
  id: number;
  code: string;
  discount_type: "percent" | "fixed";
  value: number;
  is_active: boolean;
}

interface NewDiscountCodeForm {
  code: string;
  discount_type: "percent" | "fixed";
  value: string;
  min_amount: string;
  max_amount: string;
  usage_limit: string;
  expires_at: string;
  is_active: boolean;
}

// ============================================================
// توابع کمکی
// ============================================================

function formatToDatetimeLocal(dateString: string | null): string {
  if (!dateString) return "";
  try {
    const date = new Date(dateString);
    if (isNaN(date.getTime())) return "";
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, "0");
    const day = String(date.getDate()).padStart(2, "0");
    const hours = String(date.getHours()).padStart(2, "0");
    const minutes = String(date.getMinutes()).padStart(2, "0");
    return `${year}-${month}-${day}T${hours}:${minutes}`;
  } catch {
    return "";
  }
}

function validateScheduledAt(dateTimeString: string): string | null {
  if (!dateTimeString) return null;
  try {
    const selectedDate = new Date(dateTimeString);
    if (isNaN(selectedDate.getTime())) return "فرمت تاریخ نامعتبر است.";
    const now = new Date();
    const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
    const selectedDay = new Date(
      selectedDate.getFullYear(),
      selectedDate.getMonth(),
      selectedDate.getDate()
    );
    if (selectedDay.getTime() <= today.getTime()) {
      return "زمان کارشناسی باید حداقل از فردا به بعد انتخاب شود.";
    }
    if (selectedDate.getDay() === 5) {
      return "جمعه‌ها جزو بازه کاری نیست، لطفاً روز دیگری انتخاب کنید.";
    }
    const hour = selectedDate.getHours();
    const minute = selectedDate.getMinutes();
    if (hour < 8 || hour > 16 || (hour === 16 && minute > 0) || (hour > 16)) {
      return "زمان کارشناسی فقط بین ساعت ۸:۰۰ تا ۱۶:۰۰ قابل انتخاب است.";
    }
    return null;
  } catch {
    return "فرمت زمان نامعتبر است.";
  }
}

function extractErrorMessage(data: any): string {
  if (!data) return "خطای ناشناخته از سرور (بدون پاسخ)";
  if (typeof data === "string") return data;
  if (data.detail) return data.detail;
  if (data.error) return data.error;
  if (data.message) return data.message;
  if (data.error_message) return data.error_message;

  if (typeof data === "object") {
    const errorMessages: string[] = [];
    for (const [key, value] of Object.entries(data)) {
      if (Array.isArray(value)) {
        errorMessages.push(`${key}: ${value.join(", ")}`);
      } else if (typeof value === "string") {
        errorMessages.push(`${key}: ${value}`);
      } else if (typeof value === "object" && value !== null) {
        const nested = extractErrorMessage(value);
        if (nested) errorMessages.push(`${key}: ${nested}`);
      }
    }
    if (errorMessages.length > 0) return errorMessages.join(" | ");
  }
  try {
    return JSON.stringify(data);
  } catch {
    return "خطای ناشناخته";
  }
}

// ============================================================
// کامپوننت اصلی
// ============================================================

export default function EditRequestPage() {
  const router = useRouter();
  const params = useParams();
  const id = params.id as string;

  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [fetchingUsers, setFetchingUsers] = useState(false);
  const [fetchingEquipment, setFetchingEquipment] = useState(false);
  const [fetchingCities, setFetchingCities] = useState(false);
  const [fetchingDiscounts, setFetchingDiscounts] = useState(false);
  const [calculating, setCalculating] = useState(false);

  const [request, setRequest] = useState<InspectionRequest | null>(null);
  const [users, setUsers] = useState<User[]>([]);
  const [equipmentTypes, setEquipmentTypes] = useState<EquipmentType[]>([]);
  const [cities, setCities] = useState<CityMultiplier[]>([]);
  const [discountCodes, setDiscountCodes] = useState<DiscountCode[]>([]);
  const [userSearch, setUserSearch] = useState("");
  const [showNewUserDialog, setShowNewUserDialog] = useState(false);
  const [showDeleteDialog, setShowDeleteDialog] = useState(false);
  const [showNewDiscountDialog, setShowNewDiscountDialog] = useState(false);

  const [formData, setFormData] = useState({
    customer: "",
    customerName: "",
    equipment_type: "",
    brand_model: "",
    manufacture_year: "",
    service_type: "standard" as "standard" | "pro",
    install_state: "",
    city: "",
    address: "",
    address_lat: "",
    address_lng: "",
    scheduled_at: "",
    assigned_expert: "",
    discount_code: "",
    params: {} as Record<string, any>,
  });

  const [priceInfo, setPriceInfo] = useState<{
    calculated_price: number;
    final_price: number;
    rounding_discount: number;
    discount_amount: number;
  } | null>(null);

  const [newUserForm, setNewUserForm] = useState({
    full_name: "",
    phone: "",
    email: "",
    company_name: "",
  });

  const [newDiscountForm, setNewDiscountForm] = useState<NewDiscountCodeForm>({
    code: "",
    discount_type: "percent",
    value: "",
    min_amount: "",
    max_amount: "",
    usage_limit: "",
    expires_at: "",
    is_active: true,
  });

  // دریافت اطلاعات اولیه
  useEffect(() => {
    const fetchData = async () => {
      try {
        setLoading(true);

        const reqRes = await fetch(`/api/proxy/core/inspection-requests/${id}/`);
        if (!reqRes.ok) throw new Error("خطا در دریافت اطلاعات درخواست");
        const reqData = await reqRes.json();
        setRequest(reqData);

        setFormData({
          customer: String(reqData.customer),
          customerName: reqData.customer_name || "",
          equipment_type: String(reqData.equipment_type),
          brand_model: reqData.brand_model || "",
          manufacture_year: reqData.manufacture_year ? String(reqData.manufacture_year) : "",
          service_type: reqData.service_type || "standard",
          install_state: reqData.install_state || "",
          city: reqData.city || "",
          address: reqData.address || "",
          address_lat: reqData.address_lat ? String(reqData.address_lat) : "",
          address_lng: reqData.address_lng ? String(reqData.address_lng) : "",
          scheduled_at: formatToDatetimeLocal(reqData.scheduled_at),
          assigned_expert: reqData.assigned_expert ? String(reqData.assigned_expert) : "",
          discount_code: reqData.discount_code || "",
          params: reqData.params || {},
        });

        setPriceInfo({
          calculated_price: reqData.calculated_price || 0,
          final_price: reqData.final_price || 0,
          rounding_discount: 0,
          discount_amount: 0,
        });

        await fetchUsers("");
        await fetchEquipment();
        await fetchCities();
        await fetchDiscountCodes();
      } catch (error: any) {
        toast.error(error.message || "خطا در دریافت اطلاعات");
        router.push("/dashboard/admin/requests");
      } finally {
        setLoading(false);
      }
    };

    if (id) fetchData();
  }, [id, router]);

  const fetchUsers = async (search: string) => {
    try {
      setFetchingUsers(true);
      const params = new URLSearchParams();
      if (search) params.set("search", search);
      params.set("limit", "20");
      const res = await fetch(`/api/proxy/core/users/?${params}`);
      if (res.ok) {
        const data = await res.json();
        setUsers(Array.isArray(data) ? data : data.results || []);
      }
    } catch (error) {
      console.error("خطا در دریافت کاربران", error);
    } finally {
      setFetchingUsers(false);
    }
  };

  const fetchEquipment = async () => {
    try {
      setFetchingEquipment(true);
      const res = await fetch("/api/proxy/core/equipment-types/");
      if (res.ok) {
        const data = await res.json();
        setEquipmentTypes(Array.isArray(data) ? data : data.results || []);
      }
    } catch (error) {
      console.error("خطا در دریافت تجهیزات", error);
    } finally {
      setFetchingEquipment(false);
    }
  };

  const fetchCities = async () => {
    try {
      setFetchingCities(true);
      const res = await fetch("/api/proxy/core/city-multipliers/?is_active=true");
      if (res.ok) {
        const data = await res.json();
        setCities(Array.isArray(data) ? data : data.results || []);
      }
    } catch (error) {
      console.error("خطا در دریافت شهرها", error);
    } finally {
      setFetchingCities(false);
    }
  };

  const fetchDiscountCodes = async () => {
    try {
      setFetchingDiscounts(true);
      const res = await fetch("/api/proxy/core/discount-codes/?is_active=true");
      if (res.ok) {
        const data = await res.json();
        setDiscountCodes(Array.isArray(data) ? data : data.results || []);
      }
    } catch (error) {
      console.error("خطا در دریافت کدهای تخفیف", error);
    } finally {
      setFetchingDiscounts(false);
    }
  };

  // ✅ محاسبه قیمت لحظه‌ای با payload صحیح
  const calculatePrice = useCallback(async () => {
    const equipmentTypeId = formData.equipment_type;
    const cityName = formData.city;

    if (!equipmentTypeId || !cityName) {
      setPriceInfo(null);
      return;
    }

    setCalculating(true);
    try {
      // ✅ استفاده از equipment_type_id و city (نه equipment_type)
      const payload = {
        equipment_type_id: parseInt(equipmentTypeId),
        city: cityName,
        params: formData.params || {},
        install_state: formData.install_state || undefined,
        service_type: formData.service_type || "standard",
        discount_code: formData.discount_code || undefined,
      };

      const res = await fetch("/api/proxy/pricing/calculate/", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });

      const responseData = await res.json();

      if (!res.ok) {
        console.error("خطای محاسبه قیمت:", responseData);
        const errorMsg = responseData.error || responseData.message || "خطا در محاسبه قیمت";
        toast.error(errorMsg);
        setPriceInfo(null);
        return;
      }

      // EDRA v32 — باگ واقعی (چهارمین نمونه‌ی همین باگ در این پروژه — بعد از
      // ویزارد مرحله‌ی ۳ و admin/requests/new): پاسخ واقعی /api/pricing/calculate/
      // هیچ‌کدام از total/calculated_price/final_price/rounding_discount را
      // ندارد (فیلدهای واقعی: total_price, final_amount). این کارت همیشه
      // «۰ تومان» نشان می‌داد.
      setPriceInfo({
        calculated_price: responseData.total_price || 0,
        final_price: responseData.final_amount || responseData.total_price || 0,
        rounding_discount: 0,
        discount_amount: responseData.discount_amount || 0,
      });
    } catch (error) {
      console.error("خطا در محاسبه قیمت", error);
      toast.error("خطا در ارتباط با سرور");
      setPriceInfo(null);
    } finally {
      setCalculating(false);
    }
  }, [formData.equipment_type, formData.city, formData.params, formData.install_state, formData.service_type, formData.discount_code]);

  // محاسبه خودکار قیمت با debounce
  useEffect(() => {
    if (formData.equipment_type && formData.city) {
      const timeout = setTimeout(() => calculatePrice(), 400);
      return () => clearTimeout(timeout);
    }
  }, [
    formData.equipment_type,
    formData.city,
    formData.params,
    formData.install_state,
    formData.service_type,
    formData.discount_code,
    calculatePrice,
  ]);

  const handleUserSearch = useCallback(async (value: string) => {
    setUserSearch(value);
    if (value.length >= 2) await fetchUsers(value);
    else if (value.length === 0) await fetchUsers("");
  }, []);

  const handleEquipmentChange = (value: string) => {
    setFormData((prev) => ({
      ...prev,
      equipment_type: value,
      params: {},
    }));
  };

  const handleParamChange = (name: string, value: any) => {
    setFormData((prev) => ({
      ...prev,
      params: { ...prev.params, [name]: value },
    }));
  };

  const handleCreateUser = async () => {
    try {
      const payload = {
        username: newUserForm.phone,
        first_name: newUserForm.full_name.split(' ')[0] || '',
        last_name: newUserForm.full_name.split(' ').slice(1).join(' ') || '',
        email: newUserForm.email || '',
        phone: newUserForm.phone,
        company_name: newUserForm.company_name || '',
      };

      const res = await fetch("/api/proxy/core/users/", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });

      if (!res.ok) {
        const errData = await res.json().catch(() => ({}));
        throw new Error(extractErrorMessage(errData) || "خطا در ایجاد کاربر");
      }

      const newUser = await res.json();
      toast.success("مشتری جدید با موفقیت ثبت شد");
      await fetchUsers("");
      setFormData((prev) => ({
        ...prev,
        customer: String(newUser.id),
        customerName: newUser.full_name || newUser.username,
      }));
      setShowNewUserDialog(false);
      setNewUserForm({ full_name: "", phone: "", email: "", company_name: "" });
    } catch (error: any) {
      toast.error(error.message || "خطا در ایجاد مشتری");
    }
  };

  const handleCreateDiscount = async () => {
    try {
      const payload = {
        code: newDiscountForm.code.trim().toUpperCase(),
        discount_type: newDiscountForm.discount_type,
        value: parseFloat(newDiscountForm.value) || 0,
        min_amount: newDiscountForm.min_amount ? parseFloat(newDiscountForm.min_amount) : null,
        max_amount: newDiscountForm.max_amount ? parseFloat(newDiscountForm.max_amount) : null,
        usage_limit: newDiscountForm.usage_limit ? parseInt(newDiscountForm.usage_limit) : null,
        expires_at: newDiscountForm.expires_at || null,
        is_active: newDiscountForm.is_active,
        apply_to_all: true,
      };

      const res = await fetch("/api/proxy/core/discount-codes/", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });

      if (!res.ok) {
        const errData = await res.json().catch(() => ({}));
        throw new Error(extractErrorMessage(errData) || "خطا در ایجاد کد تخفیف");
      }

      const newDiscount = await res.json();
      toast.success("کد تخفیف جدید با موفقیت ایجاد شد");
      await fetchDiscountCodes();
      setFormData((prev) => ({ ...prev, discount_code: newDiscount.code }));
      setShowNewDiscountDialog(false);
      setNewDiscountForm({
        code: "",
        discount_type: "percent",
        value: "",
        min_amount: "",
        max_amount: "",
        usage_limit: "",
        expires_at: "",
        is_active: true,
      });
    } catch (error: any) {
      toast.error(error.message || "خطا در ایجاد کد تخفیف");
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (formData.scheduled_at) {
      const validationError = validateScheduledAt(formData.scheduled_at);
      if (validationError) {
        toast.error(validationError);
        return;
      }
    }

    if (!formData.customer) {
      toast.error("لطفاً مشتری را انتخاب کنید");
      return;
    }
    if (!formData.equipment_type) {
      toast.error("لطفاً نوع تجهیزات را انتخاب کنید");
      return;
    }
    if (!formData.city || !formData.address) {
      toast.error("لطفاً شهر و آدرس کامل را وارد کنید");
      return;
    }

    setSaving(true);
    try {
      const payload = {
        customer: parseInt(formData.customer),
        equipment_type: parseInt(formData.equipment_type),
        brand_model: formData.brand_model.trim(),
        manufacture_year: formData.manufacture_year ? parseInt(formData.manufacture_year) : null,
        service_type: formData.service_type,
        install_state: formData.install_state || null,
        city: formData.city.trim(),
        address: formData.address.trim(),
        address_lat: formData.address_lat ? parseFloat(formData.address_lat) : null,
        address_lng: formData.address_lng ? parseFloat(formData.address_lng) : null,
        scheduled_at: formData.scheduled_at || null,
        assigned_expert: formData.assigned_expert ? parseInt(formData.assigned_expert) : null,
        discount_code: formData.discount_code || null,
        params: formData.params,
      };

      const res = await fetch(`/api/proxy/core/inspection-requests/${id}/`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });

      let responseData = {};
      const contentType = res.headers.get("content-type");
      if (contentType && contentType.includes("application/json")) {
        try {
          responseData = await res.json();
        } catch {
          responseData = { error: "پاسخ سرور به‌درستی قابل خواندن نیست." };
        }
      } else {
        try {
          const text = await res.text();
          responseData = { error: text || "پاسخ سرور نامعتبر است." };
        } catch {
          responseData = { error: "پاسخ سرور قابل خواندن نیست." };
        }
      }

      if (!res.ok) {
        console.error("خطای ویرایش درخواست - وضعیت:", res.status);
        console.error("خطای ویرایش درخواست - پاسخ:", responseData);
        const errorMessage = extractErrorMessage(responseData);
        toast.error(errorMessage);
        return;
      }

      toast.success("درخواست با موفقیت ویرایش شد");
      router.push(`/dashboard/admin/requests/${id}`);
      router.refresh();
    } catch (error: any) {
      console.error("خطا در ویرایش درخواست - استثناء:", error);
      toast.error(error.message || "خطا در ویرایش درخواست");
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async () => {
    try {
      const res = await fetch(`/api/proxy/core/inspection-requests/${id}/`, {
        method: "DELETE",
      });

      if (!res.ok) {
        const errData = await res.json().catch(() => ({}));
        throw new Error(extractErrorMessage(errData) || "خطا در حذف");
      }

      toast.success("درخواست با موفقیت حذف شد");
      router.push("/dashboard/admin/requests");
      router.refresh();
    } catch (error: any) {
      toast.error(error.message || "خطا در حذف درخواست");
    }
  };

  const selectedEquipment = equipmentTypes.find((e) => e.id === parseInt(formData.equipment_type));
  const selectedCity = cities.find((c) => c.city === formData.city);
  const selectedDiscount = discountCodes.find((d) => d.code === formData.discount_code);

  const isEditable = request?.status && ["draft", "pending_payment", "waiting_manual_payment", "rejected", "cancelled", "expired"].includes(request.status);

  if (loading) {
    return (
      <div className="flex items-center justify-center p-12">
        <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
      </div>
    );
  }

  if (!request) {
    return (
      <div className="flex items-center justify-center p-12 text-muted-foreground">
        درخواست یافت نشد.
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold">ویرایش درخواست</h1>
          <p className="text-muted-foreground text-sm">
            {request.request_number} - {request.customer_name}
          </p>
          <div className="flex items-center gap-2 mt-1">
            <Badge variant="outline">وضعیت: {request.status}</Badge>
            {!isEditable && (
              <Badge variant="destructive" className="text-xs">
                قابل ویرایش نیست
              </Badge>
            )}
          </div>
          {!isEditable && (
            <p className="text-xs text-red-500 mt-1">
              این درخواست قابل ویرایش نیست. برای تغییرات با پشتیبانی تماس بگیرید.
            </p>
          )}
        </div>
        <div className="flex gap-2">
          <Button variant="outline" onClick={() => router.push(`/dashboard/admin/requests/${id}`)}>
            <X className="ml-2 h-4 w-4" />
            انصراف
          </Button>
          <Button variant="destructive" onClick={() => setShowDeleteDialog(true)} disabled={!isEditable}>
            <Trash2 className="ml-2 h-4 w-4" />
            حذف
          </Button>
        </div>
      </div>

      <form onSubmit={handleSubmit}>
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2 space-y-6">
            {/* اطلاعات مشتری */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <User className="h-4 w-4" />
                  اطلاعات مشتری
                </CardTitle>
                <CardDescription>انتخاب یا ثبت مشتری جدید</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex gap-2">
                  <div className="flex-1 space-y-2">
                    <Label>مشتری *</Label>
                    <Select
                      value={formData.customer}
                      onValueChange={(value) => {
                        const user = users.find((u) => String(u.id) === value);
                        setFormData((prev) => ({
                          ...prev,
                          customer: value,
                          customerName: user?.full_name || user?.username || "",
                        }));
                      }}
                      disabled={!isEditable}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="انتخاب مشتری" />
                      </SelectTrigger>
                      <SelectContent className="max-h-60">
                        <div className="p-2">
                          <Input
                            placeholder="جستجوی مشتری..."
                            value={userSearch}
                            onChange={(e) => handleUserSearch(e.target.value)}
                            className="h-8 text-sm"
                          />
                          {fetchingUsers && (
                            <Loader2 className="h-4 w-4 animate-spin mx-auto mt-2" />
                          )}
                        </div>
                        {users.length === 0 && !fetchingUsers ? (
                          <div className="p-2 text-center text-sm text-muted-foreground">
                            مشتریی یافت نشد
                          </div>
                        ) : (
                          users.map((user) => (
                            <SelectItem key={user.id} value={String(user.id)}>
                              {user.full_name || user.username} - {user.phone}
                            </SelectItem>
                          ))
                        )}
                      </SelectContent>
                    </Select>
                  </div>
                  <Button
                    type="button"
                    variant="outline"
                    className="mt-6"
                    onClick={() => setShowNewUserDialog(true)}
                    disabled={!isEditable}
                  >
                    <UserPlus className="h-4 w-4" />
                    جدید
                  </Button>
                </div>
                {formData.customerName && (
                  <div className="text-sm text-muted-foreground">
                    مشتری انتخاب‌شده: <span className="font-medium">{formData.customerName}</span>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* اطلاعات تجهیزات */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Package className="h-4 w-4" />
                  اطلاعات تجهیزات
                </CardTitle>
                <CardDescription>مشخصات تجهیزات مورد نظر</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>نوع تجهیزات *</Label>
                    <Select
                      value={formData.equipment_type}
                      onValueChange={handleEquipmentChange}
                      disabled={!isEditable}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="انتخاب نوع تجهیزات" />
                      </SelectTrigger>
                      <SelectContent>
                        {equipmentTypes.map((eq) => (
                          <SelectItem key={eq.id} value={String(eq.id)}>
                            {eq.name_fa} ({eq.code})
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label>برند/مدل</Label>
                    <Input
                      value={formData.brand_model}
                      onChange={(e) => setFormData({ ...formData, brand_model: e.target.value })}
                      placeholder="مثلاً لیفتراک کوماتسو"
                      disabled={!isEditable}
                    />
                  </div>

                  <div className="space-y-2">
                    <Label>سال ساخت</Label>
                    <Input
                      type="number"
                      value={formData.manufacture_year}
                      onChange={(e) => setFormData({ ...formData, manufacture_year: e.target.value })}
                      placeholder="مثلاً 1400"
                      disabled={!isEditable}
                    />
                  </div>

                  <div className="space-y-2">
                    <Label>سطح سرویس</Label>
                    <Select
                      value={formData.service_type}
                      onValueChange={(value: "standard" | "pro") => {
                        setFormData((prev) => ({ ...prev, service_type: value }));
                      }}
                      disabled={!isEditable}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="standard">استاندارد</SelectItem>
                        <SelectItem value="pro">حرفه‌ای</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  {selectedEquipment?.supports_install_state && (
                    <div className="space-y-2">
                      <Label>وضعیت نصب</Label>
                      <Select
                        value={formData.install_state || ""}
                        onValueChange={(value) => {
                          setFormData((prev) => ({ ...prev, install_state: value }));
                        }}
                        disabled={!isEditable}
                      >
                        <SelectTrigger>
                          <SelectValue placeholder="انتخاب وضعیت نصب" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="installed">نصب‌شده</SelectItem>
                          <SelectItem value="not_installed">نصب‌نشده</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>

            {/* پارامترهای فنی */}
            {selectedEquipment && selectedEquipment.param_schema.length > 0 && (
              <Card>
                <CardHeader>
                  <CardTitle>پارامترهای فنی</CardTitle>
                  <CardDescription>
                    مشخصات فنی مربوط به {selectedEquipment.name_fa}
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {selectedEquipment.param_schema.map((param) => {
                      const value = formData.params[param.name] || "";
                      return (
                        <div key={param.name} className="space-y-2">
                          <Label>
                            {param.label}
                            {param.required && <span className="text-red-500"> *</span>}
                          </Label>

                          {param.type === "select" && param.options ? (
                            <Select
                              value={String(value)}
                              onValueChange={(val) => handleParamChange(param.name, val)}
                              disabled={!isEditable}
                            >
                              <SelectTrigger>
                                <SelectValue placeholder={`انتخاب ${param.label}`} />
                              </SelectTrigger>
                              <SelectContent>
                                {param.options.map((opt) => (
                                  <SelectItem key={opt} value={opt}>
                                    {opt}
                                  </SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                          ) : param.type === "boolean" ? (
                            <div className="flex items-center gap-2 pt-2">
                              <Switch
                                checked={value === true || value === "true"}
                                onCheckedChange={(checked) => handleParamChange(param.name, checked)}
                                disabled={!isEditable}
                              />
                              <span className="text-sm text-muted-foreground">
                                {value ? "بله" : "خیر"}
                              </span>
                            </div>
                          ) : param.type === "number" ? (
                            <Input
                              type="number"
                              step="any"
                              value={value}
                              onChange={(e) => handleParamChange(param.name, e.target.value)}
                              placeholder={param.label}
                              disabled={!isEditable}
                            />
                          ) : param.type === "date" || param.type === "time" ? (
                            // EDRA v32: همان شکاف سه‌جای تکرارشده (ویزارد مشتری،
                            // admin/requests/new) اینجا هم بود — رفع شد.
                            <Input
                              type={param.type}
                              value={value}
                              onChange={(e) => handleParamChange(param.name, e.target.value)}
                              disabled={!isEditable}
                            />
                          ) : (
                            <Input
                              value={value}
                              onChange={(e) => handleParamChange(param.name, e.target.value)}
                              placeholder={param.label}
                              disabled={!isEditable}
                            />
                          )}
                        </div>
                      );
                    })}
                  </div>
                </CardContent>
              </Card>
            )}

            {/* آدرس و مکان */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <MapPin className="h-4 w-4" />
                  آدرس و مکان
                </CardTitle>
                <CardDescription>محل دقیق انجام بازرسی</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>شهر *</Label>
                    <Select
                      value={formData.city}
                      onValueChange={(value) => {
                        setFormData((prev) => ({ ...prev, city: value }));
                      }}
                      disabled={!isEditable}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="انتخاب شهر" />
                      </SelectTrigger>
                      <SelectContent>
                        {fetchingCities ? (
                          <div className="flex items-center justify-center p-2">
                            <Loader2 className="h-4 w-4 animate-spin" />
                          </div>
                        ) : cities.length === 0 ? (
                          <div className="p-2 text-center text-sm text-muted-foreground">
                            شهری یافت نشد
                          </div>
                        ) : (
                          cities.filter(c => c.is_active).map((city) => (
                            <SelectItem key={city.id} value={city.city}>
                              {city.city} (ضریب: {city.multiplier})
                            </SelectItem>
                          ))
                        )}
                      </SelectContent>
                    </Select>
                    {selectedCity && (
                      <p className="text-xs text-muted-foreground">
                        ضریب این شهر: {selectedCity.multiplier} - هزینه پایه: {toPersianDigits(formatPrice(selectedCity.base_cost))} تومان
                      </p>
                    )}
                  </div>

                  <div className="space-y-2 md:col-span-2">
                    <Label>آدرس *</Label>
                    <Textarea
                      value={formData.address}
                      onChange={(e) => setFormData({ ...formData, address: e.target.value })}
                      placeholder="آدرس کامل محل بازرسی"
                      rows={2}
                      required
                      disabled={!isEditable}
                    />
                  </div>

                  <div className="space-y-2">
                    <Label>عرض جغرافیایی (Lat)</Label>
                    <Input
                      type="number"
                      step="0.000001"
                      value={formData.address_lat}
                      onChange={(e) => setFormData({ ...formData, address_lat: e.target.value })}
                      placeholder="مثلاً 35.6892"
                      disabled={!isEditable}
                    />
                  </div>

                  <div className="space-y-2">
                    <Label>طول جغرافیایی (Lng)</Label>
                    <Input
                      type="number"
                      step="0.000001"
                      value={formData.address_lng}
                      onChange={(e) => setFormData({ ...formData, address_lng: e.target.value })}
                      placeholder="مثلاً 51.3890"
                      disabled={!isEditable}
                    />
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* زمان‌بندی */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Calendar className="h-4 w-4" />
                  زمان‌بندی
                </CardTitle>
                <CardDescription>تاریخ و زمان انجام بازرسی</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  <Label>تاریخ و زمان بازرسی</Label>
                  <Input
                    type="datetime-local"
                    value={formData.scheduled_at}
                    onChange={(e) => {
                      setFormData({ ...formData, scheduled_at: e.target.value });
                    }}
                    disabled={!isEditable}
                  />
                  <p className="text-xs text-muted-foreground">
                    حداقل باید از فردا به بعد و بین ساعت ۸:۰۰ تا ۱۶:۰۰ باشد (جمعه‌ها مجاز نیست)
                  </p>
                  {formData.scheduled_at && validateScheduledAt(formData.scheduled_at) && (
                    <p className="text-xs text-red-500">{validateScheduledAt(formData.scheduled_at)}</p>
                  )}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* ستون سمت راست */}
          <div className="space-y-6">
            {/* کارشناس */}
            <Card>
              <CardHeader>
                <CardTitle>کارشناس</CardTitle>
                <CardDescription>تخصیص کارشناس به این درخواست</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  <Label>کارشناس</Label>
                  {/* EDRA v32 — باگ واقعی: این فیلد با ظاهر کاملاً تعاملی
                      نشان داده می‌شد ولی assigned_expert در سریالایزرِ
                      ویرایش read_only است — تغییر همیشه بی‌صدا نادیده
                      گرفته می‌شد (نه به این دلیل که اشتباه بود، بلکه چون
                      اکشن اختصاصی assign_expert کارهای مهم دیگری هم انجام
                      می‌دهد: اعلان به کارشناس، انتقال مجوز). به‌جای باز
                      کردن یک مسیر موازیِ بی‌اثر، این کنترل غیرفعال و به
                      دکمه‌ی واقعی در صفحه‌ی جزئیات درخواست ارجاع داده شد. */}
                  <Select value={formData.assigned_expert || ""} disabled>
                    <SelectTrigger>
                      <SelectValue placeholder="انتخاب کارشناس" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="">بدون کارشناس</SelectItem>
                      {users
                        .filter((u) => u.role === "expert")
                        .map((user) => (
                          <SelectItem key={user.id} value={String(user.id)}>
                            {user.full_name || user.username}
                          </SelectItem>
                        ))}
                    </SelectContent>
                  </Select>
                  <p className="text-muted-foreground text-xs">
                    برای تغییر کارشناس، از دکمه‌ی «تخصیص کارشناس» در صفحه‌ی
                    جزئیات همین درخواست استفاده کنید.
                  </p>
                </div>
              </CardContent>
            </Card>

            {/* کد تخفیف */}
            <Card>
              <CardHeader>
                <CardTitle>کد تخفیف</CardTitle>
                <CardDescription>اعمال کد تخفیف روی این درخواست</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex gap-2">
                  <div className="flex-1 space-y-2">
                    <Label>کد تخفیف</Label>
                    {/* EDRA v32 — باگ واقعی: discount_code هم مثل assigned_expert
                        در سریالایزرِ ویرایش read_only است — انتخاب از این
                        منو هیچ‌وقت روی درخواستِ از‌قبل‌ساخته‌شده ذخیره
                        نمی‌شد (کاملاً بی‌اثر، بدون خطا). برخلاف کارشناس،
                        هیچ اکشن اختصاصی دیگری برای اعمال تخفیف روی یک
                        درخواست موجود در کل پروژه پیدا نشد؛ این یک خلأ
                        واقعی در محصول است، نه چیزی که بتوانم اینجا امن
                        حدس بزنم و بسازم. فعلاً غیرفعال شد تا دیگر دروغ
                        نگوید؛ ساخت کد تخفیف جدید (دکمه‌ی «جدید» کنارش)
                        قابلیت جدایی است و همچنان کار می‌کند. */}
                    <Select value={formData.discount_code || ""} disabled>
                      <SelectTrigger>
                        <SelectValue placeholder="انتخاب کد تخفیف" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="">بدون تخفیف</SelectItem>
                        {fetchingDiscounts ? (
                          <div className="flex items-center justify-center p-2">
                            <Loader2 className="h-4 w-4 animate-spin" />
                          </div>
                        ) : (
                          discountCodes
                            .filter(d => d.is_active)
                            .map((d) => (
                              <SelectItem key={d.id} value={d.code}>
                                {d.code} ({d.discount_type === "percent" ? `${d.value}%` : `${d.value} تومان`})
                              </SelectItem>
                            ))
                        )}
                      </SelectContent>
                    </Select>
                    <p className="text-muted-foreground text-xs">
                      اعمال کد تخفیف روی درخواستِ ثبت‌شده فعلاً از این صفحه
                      ممکن نیست.
                    </p>
                  </div>
                  <Button
                    type="button"
                    variant="outline"
                    className="mt-6"
                    onClick={() => setShowNewDiscountDialog(true)}
                    disabled={!isEditable}
                  >
                    <Plus className="h-4 w-4" />
                    جدید
                  </Button>
                </div>
                {selectedDiscount && (
                  <div className="rounded-lg bg-muted p-3 text-sm">
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">نوع تخفیف:</span>
                      <span>{selectedDiscount.discount_type === "percent" ? "درصدی" : "مبلغ ثابت"}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">مقدار:</span>
                      <span>
                        {selectedDiscount.discount_type === "percent" 
                          ? `${selectedDiscount.value}%` 
                          : `${toPersianDigits(formatPrice(selectedDiscount.value))} تومان`}
                      </span>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* قیمت‌گذاری لحظه‌ای */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Wallet className="h-4 w-4" />
                  قیمت‌گذاری لحظه‌ای
                </CardTitle>
                <CardDescription>با تغییر هر فیلد، قیمت به‌روز می‌شود</CardDescription>
              </CardHeader>
              <CardContent className="space-y-3">
                {calculating ? (
                  <div className="flex items-center justify-center py-4">
                    <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
                    <span className="mr-2 text-sm text-muted-foreground">در حال محاسبه...</span>
                  </div>
                ) : priceInfo ? (
                  <>
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">قیمت محاسبه‌شده</span>
                      <span className="font-medium">
                        {toPersianDigits(formatPrice(priceInfo.calculated_price))} تومان
                      </span>
                    </div>
                    {priceInfo.discount_amount > 0 && (
                      <div className="flex justify-between text-sm text-green-600">
                        <span>تخفیف ({formData.discount_code || "کد"})</span>
                        <span>- {toPersianDigits(formatPrice(priceInfo.discount_amount))} تومان</span>
                      </div>
                    )}
                    {priceInfo.rounding_discount > 0 && (
                      <div className="flex justify-between text-sm text-blue-600">
                        <span>تخفیف رندینگ</span>
                        <span>- {toPersianDigits(formatPrice(priceInfo.rounding_discount))} تومان</span>
                      </div>
                    )}
                    <div className="flex justify-between text-sm border-t pt-2">
                      <span className="text-muted-foreground font-medium">قیمت نهایی</span>
                      <span className="font-bold text-lg text-primary">
                        {toPersianDigits(formatPrice(priceInfo.final_price))} تومان
                      </span>
                    </div>
                    <Button
                      type="button"
                      variant="outline"
                      size="sm"
                      className="w-full mt-2"
                      onClick={() => calculatePrice()}
                      disabled={calculating}
                    >
                      <RefreshCw className={`ml-2 h-4 w-4 ${calculating ? "animate-spin" : ""}`} />
                      محاسبه مجدد قیمت
                    </Button>
                  </>
                ) : (
                  <p className="text-sm text-muted-foreground text-center py-4">
                    برای محاسبه قیمت، نوع تجهیزات و شهر را انتخاب کنید.
                  </p>
                )}
                <p className="text-xs text-muted-foreground mt-2">
                  قیمت‌ها به‌صورت خودکار با تغییر هر فیلد محاسبه می‌شوند.
                </p>
              </CardContent>
            </Card>

            {/* دکمه ذخیره */}
            <Button type="submit" className="w-full" disabled={saving || !isEditable}>
              <Save className="ml-2 h-4 w-4" />
              {saving ? "در حال ذخیره..." : "ذخیره تغییرات"}
            </Button>
            {!isEditable && (
              <p className="text-xs text-center text-red-500 mt-2">
                این درخواست قابل ویرایش نیست. برای تغییرات با پشتیبانی تماس بگیرید.
              </p>
            )}
          </div>
        </div>
      </form>

      {/* دیالوگ ثبت مشتری جدید */}
      <Dialog open={showNewUserDialog} onOpenChange={setShowNewUserDialog}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>ثبت مشتری جدید</DialogTitle>
            <DialogDescription>
              اطلاعات مشتری جدید را وارد کنید. شماره موبایل الزامی است.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="new_full_name">نام کامل</Label>
              <Input
                id="new_full_name"
                value={newUserForm.full_name}
                onChange={(e) => setNewUserForm({ ...newUserForm, full_name: e.target.value })}
                placeholder="مثلاً علی محمدی"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="new_phone">شماره موبایل *</Label>
              <Input
                id="new_phone"
                value={newUserForm.phone}
                onChange={(e) => setNewUserForm({ ...newUserForm, phone: e.target.value })}
                placeholder="مثلاً 09123456789"
                required
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="new_email">ایمیل</Label>
              <Input
                id="new_email"
                type="email"
                value={newUserForm.email}
                onChange={(e) => setNewUserForm({ ...newUserForm, email: e.target.value })}
                placeholder="مثلاً ali@example.com"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="new_company">نام شرکت</Label>
              <Input
                id="new_company"
                value={newUserForm.company_name}
                onChange={(e) => setNewUserForm({ ...newUserForm, company_name: e.target.value })}
                placeholder="نام شرکت (اختیاری)"
              />
            </div>
            <div className="flex gap-2 pt-4">
              <Button variant="outline" className="flex-1" onClick={() => setShowNewUserDialog(false)}>
                انصراف
              </Button>
              <Button className="flex-1" onClick={handleCreateUser}>
                ثبت مشتری
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* دیالوگ ایجاد کد تخفیف جدید */}
      <Dialog open={showNewDiscountDialog} onOpenChange={setShowNewDiscountDialog}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>ایجاد کد تخفیف جدید</DialogTitle>
            <DialogDescription>
              اطلاعات کد تخفیف جدید را وارد کنید.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="discount_code">کد *</Label>
              <Input
                id="discount_code"
                value={newDiscountForm.code}
                onChange={(e) => setNewDiscountForm({ ...newDiscountForm, code: e.target.value.toUpperCase() })}
                placeholder="مثلاً SUMMER1405"
                required
              />
            </div>
            <div className="space-y-2">
              <Label>نوع تخفیف *</Label>
              <Select
                value={newDiscountForm.discount_type}
                onValueChange={(value: "percent" | "fixed") =>
                  setNewDiscountForm({ ...newDiscountForm, discount_type: value })
                }
              >
                <SelectTrigger>
                  <SelectValue placeholder="انتخاب نوع تخفیف" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="percent">درصدی</SelectItem>
                  <SelectItem value="fixed">مبلغ ثابت</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="discount_value">مقدار *</Label>
              <Input
                id="discount_value"
                type="number"
                step="0.01"
                value={newDiscountForm.value}
                onChange={(e) => setNewDiscountForm({ ...newDiscountForm, value: e.target.value })}
                placeholder={newDiscountForm.discount_type === "percent" ? "مثلاً 10" : "مثلاً 50000"}
                required
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="discount_min_amount">حداقل مبلغ (اختیاری)</Label>
              <Input
                id="discount_min_amount"
                type="number"
                value={newDiscountForm.min_amount}
                onChange={(e) => setNewDiscountForm({ ...newDiscountForm, min_amount: e.target.value })}
                placeholder="مثلاً 100000"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="discount_max_amount">حداکثر مبلغ (اختیاری)</Label>
              <Input
                id="discount_max_amount"
                type="number"
                value={newDiscountForm.max_amount}
                onChange={(e) => setNewDiscountForm({ ...newDiscountForm, max_amount: e.target.value })}
                placeholder="مثلاً 500000"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="discount_usage_limit">محدودیت استفاده (اختیاری)</Label>
              <Input
                id="discount_usage_limit"
                type="number"
                value={newDiscountForm.usage_limit}
                onChange={(e) => setNewDiscountForm({ ...newDiscountForm, usage_limit: e.target.value })}
                placeholder="مثلاً 100"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="discount_expires_at">تاریخ انقضا (اختیاری)</Label>
              <Input
                id="discount_expires_at"
                type="datetime-local"
                value={newDiscountForm.expires_at}
                onChange={(e) => setNewDiscountForm({ ...newDiscountForm, expires_at: e.target.value })}
              />
            </div>
            <div className="flex items-center justify-between">
              <Label htmlFor="discount_is_active">فعال</Label>
              <Switch
                id="discount_is_active"
                checked={newDiscountForm.is_active}
                onCheckedChange={(checked) => setNewDiscountForm({ ...newDiscountForm, is_active: checked })}
              />
            </div>
            <div className="flex gap-2 pt-4">
              <Button variant="outline" className="flex-1" onClick={() => setShowNewDiscountDialog(false)}>
                انصراف
              </Button>
              <Button className="flex-1" onClick={handleCreateDiscount}>
                ایجاد کد تخفیف
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* دیالوگ تأیید حذف */}
      <Dialog open={showDeleteDialog} onOpenChange={setShowDeleteDialog}>
        <DialogContent className="max-w-sm">
          <DialogHeader>
            <DialogTitle>تأیید حذف</DialogTitle>
            <DialogDescription>
              آیا از حذف این درخواست مطمئن هستید؟ این عملیات غیرقابل بازگشت است.
            </DialogDescription>
          </DialogHeader>
          <div className="flex gap-2 pt-4">
            <Button variant="outline" className="flex-1" onClick={() => setShowDeleteDialog(false)}>
              انصراف
            </Button>
            <Button variant="destructive" className="flex-1" onClick={handleDelete}>
              حذف
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
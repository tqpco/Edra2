// app/dashboard/admin/requests/actions.ts
"use server";

import { apiServerFetch } from "@/lib/api-server";

export async function getUsers(search?: string) {
  const params = new URLSearchParams();
  if (search) params.set("search", search);
  params.set("limit", "50");
  return apiServerFetch(`/api/core/users/?${params}`);
}

export async function getEquipmentTypes() {
  return apiServerFetch("/api/core/equipment-types/");
}

export async function getDiscountCodes() {
  return apiServerFetch("/api/core/discount-codes/?is_active=true");
}

export async function createUser(data: {
  full_name: string;
  phone: string;
  email?: string;
  company_name?: string;
}) {
  return apiServerFetch("/api/core/users/", {
    method: "POST",
    body: JSON.stringify(data),
  });
}

export async function calculatePrice(data: {
  equipment_type: number;
  params: Record<string, any>;
  install_state?: string;
  city_name: string;
  service_type: string;
}) {
  return apiServerFetch("/api/pricing/calculate/", {
    method: "POST",
    body: JSON.stringify(data),
  });
}
// app/dashboard/admin/requests/page.tsx
import Link from "next/link";
import { Plus } from "lucide-react";
import { Button } from "@/components/ui/button";
import { AdminRequestsTable } from "./requests-table";

export const metadata = { title: "درخواست‌ها" };

export default function AdminRequestsPage() {
  return (
    <div className="flex flex-col gap-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-semibold">مدیریت درخواست‌ها</h1>
          <p className="text-muted-foreground text-sm">
            مشاهده، فیلتر، تخصیص کارشناس و ویرایش درخواست‌های بازرسی
          </p>
        </div>
        <Link href="/dashboard/admin/requests/new">
          <Button>
            <Plus className="ml-2 h-4 w-4" />
            ثبت درخواست جدید
          </Button>
        </Link>
      </div>
      <AdminRequestsTable />
    </div>
  );
}
import { apiServerFetch } from "@/lib/api-server";
import { SavedRepliesClient } from "./saved-replies-client";

export const metadata = { title: "پاسخ‌های آماده" };

interface SavedReplyItem {
  id: number;
  title: string;
  content: string;
  category?: string;
  is_active?: boolean;
}

export default async function AdminSavedRepliesPage() {
  const data = await apiServerFetch<{ results: SavedReplyItem[] } | SavedReplyItem[]>(
    `/api/support/saved-replies/?page_size=200`
  );
  const replies = Array.isArray(data) ? data : data.results ?? [];

  return (
    <div className="flex flex-col gap-6">
      <SavedRepliesClient replies={replies} />
    </div>
  );
}

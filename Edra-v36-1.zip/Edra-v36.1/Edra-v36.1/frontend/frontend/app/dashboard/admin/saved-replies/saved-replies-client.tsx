"use client";

// EDRA v27 — قابلیت تازه (گزارش کاربر، سپتامبر ۲۰۲۶): پاسخ‌های آماده‌ی
// تیکت در بک‌اند کامل بود ولی هیچ رابط مدیریتی نداشت.

import * as React from "react";
import { useRouter } from "next/navigation";
import { toast } from "sonner";
import { Plus, Pencil, Trash2, MessageSquareText } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import { apiClientFetch, ClientApiError } from "@/lib/api-client";

interface SavedReplyItem {
  id: number;
  title: string;
  content: string;
  category?: string;
  is_active?: boolean;
}

const EMPTY = { title: "", content: "", category: "" };

export function SavedRepliesClient({ replies }: { replies: SavedReplyItem[] }) {
  const router = useRouter();
  const [dialogOpen, setDialogOpen] = React.useState(false);
  const [editing, setEditing] = React.useState<SavedReplyItem | null>(null);
  const [form, setForm] = React.useState(EMPTY);
  const [saving, setSaving] = React.useState(false);
  const [deleteTarget, setDeleteTarget] = React.useState<SavedReplyItem | null>(null);
  const [deleting, setDeleting] = React.useState(false);

  function openCreate() {
    setEditing(null);
    setForm(EMPTY);
    setDialogOpen(true);
  }

  function openEdit(r: SavedReplyItem) {
    setEditing(r);
    setForm({ title: r.title, content: r.content, category: r.category ?? "" });
    setDialogOpen(true);
  }

  async function submit() {
    if (!form.title.trim() || !form.content.trim()) {
      toast.error("عنوان و متن پاسخ الزامی است.");
      return;
    }
    setSaving(true);
    try {
      const path = editing
        ? `/api/support/saved-replies/${editing.id}/`
        : `/api/support/saved-replies/`;
      await apiClientFetch(path, { method: editing ? "PATCH" : "POST", body: form });
      toast.success(editing ? "پاسخ ویرایش شد." : "پاسخ جدید ساخته شد.");
      setDialogOpen(false);
      router.refresh();
    } catch (err) {
      toast.error(err instanceof ClientApiError ? err.message : "خطا در ذخیره‌سازی.");
    } finally {
      setSaving(false);
    }
  }

  async function confirmDelete() {
    if (!deleteTarget) return;
    setDeleting(true);
    try {
      await apiClientFetch(`/api/support/saved-replies/${deleteTarget.id}/`, { method: "DELETE" });
      toast.success("پاسخ حذف شد.");
      setDeleteTarget(null);
      router.refresh();
    } catch (err) {
      toast.error(err instanceof ClientApiError ? err.message : "خطا در حذف.");
    } finally {
      setDeleting(false);
    }
  }

  return (
    <>
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="text-2xl font-semibold">پاسخ‌های آماده</h1>
          <p className="text-muted-foreground text-sm">متن‌های پرکاربرد برای پاسخ سریع به تیکت‌ها</p>
        </div>
        <Button onClick={openCreate}>
          <Plus className="size-4" />
          پاسخ جدید
        </Button>
      </div>

      <Card>
        <CardContent className="px-0 py-2">
          {replies.length === 0 ? (
            <p className="text-muted-foreground py-10 text-center text-sm">
              <MessageSquareText className="mx-auto mb-2 size-8 opacity-40" />
              پاسخ آماده‌ای ثبت نشده است
            </p>
          ) : (
            <div className="flex flex-col divide-y">
              {replies.map((r) => (
                <div key={r.id} className="flex items-start justify-between gap-3 px-5 py-4">
                  <div className="min-w-0">
                    <div className="flex items-center gap-2">
                      <span className="text-sm font-medium">{r.title}</span>
                      {r.category && <Badge variant="outline">{r.category}</Badge>}
                    </div>
                    <p className="text-muted-foreground mt-1 line-clamp-2 text-xs">{r.content}</p>
                  </div>
                  <div className="flex shrink-0 items-center gap-1">
                    <Button variant="ghost" size="icon" className="size-8" onClick={() => openEdit(r)}>
                      <Pencil className="size-3.5" />
                    </Button>
                    <Button
                      variant="ghost"
                      size="icon"
                      className="text-destructive size-8"
                      onClick={() => setDeleteTarget(r)}
                    >
                      <Trash2 className="size-3.5" />
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>{editing ? "ویرایش پاسخ آماده" : "پاسخ آماده جدید"}</DialogTitle>
          </DialogHeader>
          <div className="flex flex-col gap-4">
            <div className="grid gap-1.5">
              <Label htmlFor="reply-title">عنوان</Label>
              <Input
                id="reply-title"
                value={form.title}
                onChange={(e) => setForm({ ...form, title: e.target.value })}
              />
            </div>
            <div className="grid gap-1.5">
              <Label htmlFor="reply-category">دسته‌بندی (اختیاری)</Label>
              <Input
                id="reply-category"
                value={form.category}
                onChange={(e) => setForm({ ...form, category: e.target.value })}
              />
            </div>
            <div className="grid gap-1.5">
              <Label htmlFor="reply-content">متن پاسخ</Label>
              <Textarea
                id="reply-content"
                rows={5}
                value={form.content}
                onChange={(e) => setForm({ ...form, content: e.target.value })}
              />
            </div>
          </div>
          <div className="flex justify-end gap-2">
            <Button variant="outline" onClick={() => setDialogOpen(false)}>
              انصراف
            </Button>
            <Button onClick={submit} disabled={saving}>
              {saving ? "در حال ذخیره..." : "ذخیره"}
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      <Dialog open={Boolean(deleteTarget)} onOpenChange={(o) => !o && setDeleteTarget(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>حذف «{deleteTarget?.title}»</DialogTitle>
            <DialogDescription>این عملیات قابل بازگشت نیست.</DialogDescription>
          </DialogHeader>
          <div className="flex justify-end gap-2">
            <Button variant="outline" onClick={() => setDeleteTarget(null)}>
              انصراف
            </Button>
            <Button variant="destructive" onClick={confirmDelete} disabled={deleting}>
              {deleting ? "در حال حذف..." : "حذف"}
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
}

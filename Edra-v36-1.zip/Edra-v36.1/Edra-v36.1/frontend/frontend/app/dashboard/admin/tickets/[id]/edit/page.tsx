// app/dashboard/admin/tickets/[id]/edit/page.tsx
"use client";

import React, { useState, useEffect, useCallback } from "react";
import { useRouter, useParams } from "next/navigation";
import {
  Save,
  X,
  Loader2,
  AlertCircle,
  TrendingUp,
  Send,
  Paperclip,
  MessageSquare,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Badge } from "@/components/ui/badge";
import { toast } from "sonner";
import { apiClientFetch, apiClientUpload } from "@/lib/api-client";

// ============================================================
// 📦 تعریف انواع
// ============================================================

interface TicketCategory {
  id: number;
  name: string;
  is_active: boolean;
}

interface TicketPriority {
  id: number;
  name: string;
  color: string;
  is_active: boolean;
}

interface TicketStatus {
  id: number;
  name: string;
  color: string;
  is_closed: boolean;
}

interface TicketDepartment {
  id: number;
  name: string;
  is_active: boolean;
}

interface TicketLabel {
  id: number;
  name: string;
  color: string;
}

interface TicketSLA {
  id: number;
  name: string;
  response_time_hours: number;
  resolution_time_hours: number;
  escalation_time_hours: number;
  is_active: boolean;
}

interface TicketComment {
  id: number;
  user: { id: number; full_name: string };
  user_name: string;
  content: string;
  is_internal: boolean;
  created_at_jalali: string;
  attachments: { id: number; filename: string; file_size: number }[];
}

interface TicketDetail {
  id: number;
  title: string;
  description: string;
  customer: { id: number; full_name: string };
  customer_name: string;
  assigned_to: { id: number; full_name: string } | null;
  assigned_to_name: string | null;
  status: TicketStatus;
  status_name: string;
  priority: TicketPriority;
  priority_name: string;
  category: TicketCategory | null;
  category_name: string | null;
  department: TicketDepartment | null;
  department_name: string | null;
  labels: TicketLabel[];
  sla: TicketSLA | null;
  sla_name: string | null;
  escalation_level: number;
  due_date: string | null;
  is_confidential: boolean;
  is_pinned: boolean;
  comments: TicketComment[];
  comments_count: number;
  created_at_jalali: string;
  updated_at_jalali: string;
}

// ============================================================
// 📄 صفحه ویرایش تیکت (با فرم کامنت و آپلود فایل)
// ============================================================

export default function EditTicketPage() {
  const router = useRouter();
  const params = useParams();
  const id = params.id as string;

  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [ticket, setTicket] = useState<TicketDetail | null>(null);
  const [categories, setCategories] = useState<TicketCategory[]>([]);
  const [priorities, setPriorities] = useState<TicketPriority[]>([]);
  const [statuses, setStatuses] = useState<TicketStatus[]>([]);
  const [departments, setDepartments] = useState<TicketDepartment[]>([]);
  const [labels, setLabels] = useState<TicketLabel[]>([]);
  const [slas, setSlas] = useState<TicketSLA[]>([]);

  const [formData, setFormData] = useState({
    title: "",
    description: "",
    category: "",
    priority: "",
    status: "",
    department: "",
    sla: "",
    labels: [] as string[],
    due_date: "",
    is_confidential: false,
  });

  const [newComment, setNewComment] = useState("");
  const [isInternal, setIsInternal] = useState(false);
  const [selectedFiles, setSelectedFiles] = useState<File[]>([]);
  const [sendingComment, setSendingComment] = useState(false);

  // ============================================================
  // دریافت اطلاعات - ✅ اصلاح شده با مدیریت خطای SLA
  // ============================================================
  const fetchData = useCallback(async () => {
    try {
      setLoading(true);

      // دریافت اطلاعات تیکت
      const ticketData = await apiClientFetch<TicketDetail>(`/api/support/tickets/${id}/`);

      // دریافت داده‌های مرجع به صورت موازی
      const [categoriesData, prioritiesData, statusesData, departmentsData, labelsData] =
        await Promise.all([
          apiClientFetch<any>("/api/support/categories/"),
          apiClientFetch<any>("/api/support/priorities/"),
          apiClientFetch<any>("/api/support/statuses/"),
          apiClientFetch<any>("/api/support/departments/"),
          apiClientFetch<any>("/api/support/labels/"),
        ]);

      // دریافت SLA به صورت جداگانه با مدیریت خطا
      let slasData: any[] = [];
      try {
        const slaResult = await apiClientFetch<any>("/api/support/slas/");
        slasData = Array.isArray(slaResult) ? slaResult : slaResult.results || [];
      } catch (slaError) {
        console.warn("SLA endpoint not found, continuing without SLA:", slaError);
        slasData = [];
      }

      setTicket(ticketData);
      setCategories(Array.isArray(categoriesData) ? categoriesData : categoriesData.results || []);
      setPriorities(Array.isArray(prioritiesData) ? prioritiesData : prioritiesData.results || []);
      setStatuses(Array.isArray(statusesData) ? statusesData : statusesData.results || []);
      setDepartments(Array.isArray(departmentsData) ? departmentsData : departmentsData.results || []);
      setLabels(Array.isArray(labelsData) ? labelsData : labelsData.results || []);
      setSlas(slasData);

      // پر کردن فرم
      setFormData({
        title: ticketData.title || "",
        description: ticketData.description || "",
        category: ticketData.category ? String(ticketData.category.id) : "",
        priority: ticketData.priority ? String(ticketData.priority.id) : "",
        status: ticketData.status ? String(ticketData.status.id) : "",
        department: ticketData.department ? String(ticketData.department.id) : "",
        sla: ticketData.sla ? String(ticketData.sla.id) : "",
        labels: ticketData.labels?.map((l: TicketLabel) => String(l.id)) || [],
        due_date: ticketData.due_date || "",
        is_confidential: ticketData.is_confidential || false,
      });
    } catch (error) {
      console.error("❌ خطا در دریافت داده‌ها:", error);
      toast.error(error instanceof Error ? error.message : "خطا در دریافت اطلاعات");
      router.push("/dashboard/admin/tickets");
    } finally {
      setLoading(false);
    }
  }, [id, router]);

  useEffect(() => {
    fetchData();
  }, [fetchData]);

  // ============================================================
  // مدیریت آپلود فایل (برای کامنت)
  // ============================================================
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      const files = Array.from(e.target.files);
      const allowedTypes = [
        "image/jpeg",
        "image/png",
        "application/pdf",
        "application/vnd.ms-excel",
        "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
      ];
      const invalidFiles = files.filter((f) => !allowedTypes.includes(f.type));
      if (invalidFiles.length > 0) {
        toast.error(
          `فایل‌های ${invalidFiles.map((f) => f.name).join(", ")} مجاز نیستند. فقط jpg, png, pdf, excel مجاز است.`
        );
        return;
      }
      const maxSize = 10 * 1024 * 1024;
      const oversized = files.filter((f) => f.size > maxSize);
      if (oversized.length > 0) {
        toast.error(`حجم فایل‌های ${oversized.map((f) => f.name).join(", ")} بیش از ۱۰ مگابایت است.`);
        return;
      }
      setSelectedFiles((prev) => [...prev, ...files]);
    }
  };

  const removeFile = (index: number) => {
    setSelectedFiles((prev) => prev.filter((_, i) => i !== index));
  };

  // ============================================================
  // ارسال کامنت با فایل‌ها - ✅ اصلاح شده با apiClientUpload
  // ============================================================
  const handleAddComment = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newComment || newComment.trim().length === 0) {
      toast.error("متن کامنت را وارد کنید.");
      return;
    }

    setSendingComment(true);
    try {
      const formData = new FormData();
      formData.append("content", newComment.trim());
      formData.append("is_internal", String(isInternal));
      selectedFiles.forEach((file) => {
        formData.append("attachments", file);
      });

      await apiClientUpload(`/api/support/tickets/${id}/add_comment/`, formData, "POST");

      toast.success("کامنت با موفقیت ارسال شد");
      setNewComment("");
      setIsInternal(false);
      setSelectedFiles([]);
      fetchData();
    } catch (error) {
      console.error("❌ خطا در ارسال کامنت:", error);
      toast.error(error instanceof Error ? error.message : "خطا در ارسال کامنت");
    } finally {
      setSendingComment(false);
    }
  };

  // ============================================================
  // ذخیره تغییرات تیکت - ✅ اصلاح شده با apiClientFetch
  // ============================================================
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!formData.title || formData.title.trim().length < 3) {
      toast.error("عنوان تیکت باید حداقل ۳ کاراکتر باشد.");
      return;
    }
    if (!formData.description || formData.description.trim().length < 10) {
      toast.error("توضیحات تیکت باید حداقل ۱۰ کاراکتر باشد.");
      return;
    }

    const payload: Record<string, any> = {
      title: formData.title.trim(),
      description: formData.description.trim(),
      is_confidential: formData.is_confidential,
    };
    if (formData.category) payload.category = Number(formData.category);
    if (formData.priority) payload.priority = Number(formData.priority);
    if (formData.status) payload.status = Number(formData.status);
    if (formData.department) payload.department = Number(formData.department);
    if (formData.sla) payload.sla = Number(formData.sla);
    if (formData.labels && formData.labels.length > 0) {
      payload.labels = formData.labels.map(Number);
    }
    if (formData.due_date) payload.due_date = formData.due_date;

    setSaving(true);
    try {
      await apiClientFetch(`/api/support/tickets/${id}/`, {
        method: "PUT",
        body: payload,
      });

      toast.success("تیکت با موفقیت ویرایش شد");
      router.push(`/dashboard/admin/tickets/${id}`);
      router.refresh();
    } catch (error) {
      console.error("❌ خطا در ویرایش تیکت:", error);
      toast.error(error instanceof Error ? error.message : "خطا در ویرایش تیکت");
    } finally {
      setSaving(false);
    }
  };

  const handleCancel = () => {
    router.back();
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center p-12">
        <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
      </div>
    );
  }

  if (!ticket) {
    return (
      <div className="flex flex-col items-center justify-center p-12 text-center">
        <AlertCircle className="h-12 w-12 text-red-500" />
        <p className="text-lg font-semibold mt-4">تیکت یافت نشد</p>
        <Button className="mt-4" onClick={() => router.push("/dashboard/admin/tickets")}>
          بازگشت به لیست تیکت‌ها
        </Button>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* هدر */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold">ویرایش تیکت</h1>
          <p className="text-muted-foreground text-sm">
            تیکت #{ticket.id} - {ticket.title}
          </p>
          <div className="flex flex-wrap gap-2 mt-1">
            <Badge
              variant="outline"
              style={{
                borderColor: ticket.status?.color || "#6B7280",
                color: ticket.status?.color || "#6B7280",
              }}
            >
              {ticket.status_name}
            </Badge>
            {ticket.escalation_level > 0 && (
              <Badge variant="destructive" className="gap-1">
                <TrendingUp className="h-3 w-3" />
                ارتقا {ticket.escalation_level}
              </Badge>
            )}
          </div>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" onClick={handleCancel}>
            <X className="ml-2 h-4 w-4" />
            انصراف
          </Button>
        </div>
      </div>

      {/* فرم ویرایش اطلاعات تیکت */}
      <form onSubmit={handleSubmit}>
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* ستون اصلی */}
          <div className="lg:col-span-2 space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>اطلاعات تیکت</CardTitle>
                <CardDescription>عنوان و توضیحات تیکت</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="title">عنوان *</Label>
                  <Input
                    id="title"
                    value={formData.title}
                    onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                    placeholder="مثلاً مشکل در ورود به سامانه"
                    required
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="description">توضیحات *</Label>
                  <Textarea
                    id="description"
                    value={formData.description}
                    onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                    placeholder="توضیحات کامل مشکل را وارد کنید..."
                    rows={6}
                    required
                  />
                </div>
              </CardContent>
            </Card>

            {/* بخش کامنت‌ها و فرم ارسال کامنت جدید با آپلود فایل */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <MessageSquare className="h-5 w-5" />
                  نظرات ({ticket.comments_count})
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {ticket.comments.length === 0 ? (
                  <p className="text-muted-foreground text-center py-4">
                    هیچ نظری برای این تیکت ثبت نشده است.
                  </p>
                ) : (
                  ticket.comments.map((comment) => (
                    <div
                      key={comment.id}
                      className={`rounded-lg p-4 ${
                        comment.is_internal
                          ? "bg-yellow-50 border border-yellow-200"
                          : "bg-muted/50"
                      }`}
                    >
                      <div className="flex items-start justify-between">
                        <div>
                          <span className="font-medium">{comment.user_name}</span>
                          <span className="text-xs text-muted-foreground mr-2">
                            {comment.created_at_jalali}
                          </span>
                          {comment.is_internal && (
                            <Badge variant="outline" className="text-yellow-600 border-yellow-300 text-xs">
                              داخلی
                            </Badge>
                          )}
                        </div>
                      </div>
                      <p className="mt-2 whitespace-pre-wrap">{comment.content}</p>
                      {comment.attachments && comment.attachments.length > 0 && (
                        <div className="mt-2 flex flex-wrap gap-2">
                          {comment.attachments.map((att: any) => (
                            <Badge key={att.id} variant="outline" className="text-xs">
                              <Paperclip className="h-3 w-3 ml-1" />
                              {att.filename}
                            </Badge>
                          ))}
                        </div>
                      )}
                    </div>
                  ))
                )}

                {/* فرم ارسال کامنت جدید با آپلود فایل */}
                <form onSubmit={handleAddComment} className="space-y-3 pt-4 border-t">
                  <Textarea
                    value={newComment}
                    onChange={(e) => setNewComment(e.target.value)}
                    placeholder="نظر خود را وارد کنید..."
                    rows={3}
                    required
                  />
                  <div className="space-y-2">
                    <div className="flex items-center gap-2">
                      <Label htmlFor="file-upload-edit" className="cursor-pointer">
                        <div className="flex items-center gap-2 rounded-md border border-dashed px-3 py-2 hover:bg-muted/50 transition-colors">
                          <Paperclip className="h-4 w-4" />
                          <span className="text-sm">ضمیمه کردن فایل</span>
                          <span className="text-xs text-muted-foreground">
                            (jpg, png, pdf, excel - حداکثر ۱۰ مگابایت)
                          </span>
                        </div>
                      </Label>
                      <Input
                        id="file-upload-edit"
                        type="file"
                        multiple
                        accept=".jpg,.jpeg,.png,.pdf,.xls,.xlsx"
                        onChange={handleFileChange}
                        className="hidden"
                      />
                    </div>
                    {selectedFiles.length > 0 && (
                      <div className="flex flex-wrap gap-2">
                        {selectedFiles.map((file, index) => (
                          <Badge
                            key={index}
                            variant="outline"
                            className="flex items-center gap-1 pl-2"
                          >
                            <span className="text-xs">{file.name}</span>
                            <span className="text-xs text-muted-foreground">
                              ({Math.round(file.size / 1024)} KB)
                            </span>
                            <button
                              type="button"
                              onClick={() => removeFile(index)}
                              className="text-red-500 hover:text-red-700"
                            >
                              <X className="h-3 w-3" />
                            </button>
                          </Badge>
                        ))}
                      </div>
                    )}
                  </div>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <Label htmlFor="is_internal" className="text-sm">
                        داخلی (فقط پشتیبانی)
                      </Label>
                      <Switch
                        id="is_internal"
                        checked={isInternal}
                        onCheckedChange={setIsInternal}
                      />
                    </div>
                    <Button type="submit" disabled={sendingComment}>
                      {sendingComment ? (
                        <Loader2 className="h-4 w-4 animate-spin" />
                      ) : (
                        <Send className="ml-1 h-4 w-4" />
                      )}
                      ارسال
                    </Button>
                  </div>
                </form>
              </CardContent>
            </Card>
          </div>

          {/* ستون سمت راست (تنظیمات) */}
          <div className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>تنظیمات</CardTitle>
                <CardDescription>دسته‌بندی، اولویت، SLA و سایر تنظیمات</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="category">دسته‌بندی</Label>
                  <Select
                    value={formData.category}
                    onValueChange={(value) => setFormData({ ...formData, category: value })}
                  >
                    <SelectTrigger id="category">
                      <SelectValue placeholder="انتخاب دسته‌بندی" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="">بدون دسته‌بندی</SelectItem>
                      {categories.filter((c) => c.is_active).map((c) => (
                        <SelectItem key={c.id} value={String(c.id)}>
                          {c.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="priority">اولویت</Label>
                  <Select
                    value={formData.priority}
                    onValueChange={(value) => setFormData({ ...formData, priority: value })}
                  >
                    <SelectTrigger id="priority">
                      <SelectValue placeholder="انتخاب اولویت" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="">بدون اولویت</SelectItem>
                      {priorities.filter((p) => p.is_active).map((p) => (
                        <SelectItem key={p.id} value={String(p.id)}>
                          <span className="flex items-center gap-2">
                            <span
                              className="inline-block h-2 w-2 rounded-full"
                              style={{ backgroundColor: p.color }}
                            />
                            {p.name}
                          </span>
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="status">وضعیت</Label>
                  <Select
                    value={formData.status}
                    onValueChange={(value) => setFormData({ ...formData, status: value })}
                  >
                    <SelectTrigger id="status">
                      <SelectValue placeholder="انتخاب وضعیت" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="">بدون وضعیت</SelectItem>
                      {statuses.map((s) => (
                        <SelectItem key={s.id} value={String(s.id)}>
                          <span className="flex items-center gap-2">
                            <span
                              className="inline-block h-2 w-2 rounded-full"
                              style={{ backgroundColor: s.color }}
                            />
                            {s.name}
                          </span>
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="department">دپارتمان</Label>
                  <Select
                    value={formData.department}
                    onValueChange={(value) => setFormData({ ...formData, department: value })}
                  >
                    <SelectTrigger id="department">
                      <SelectValue placeholder="انتخاب دپارتمان" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="">بدون دپارتمان</SelectItem>
                      {departments.filter((d) => d.is_active).map((d) => (
                        <SelectItem key={d.id} value={String(d.id)}>
                          {d.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                {/* انتخاب SLA - اگر SLA موجود نباشد، نمایش داده نمی‌شود */}
                {slas.length > 0 && (
                  <div className="space-y-2">
                    <Label htmlFor="sla">SLA</Label>
                    <Select
                      value={formData.sla}
                      onValueChange={(value) => setFormData({ ...formData, sla: value })}
                    >
                      <SelectTrigger id="sla">
                        <SelectValue placeholder="انتخاب SLA" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="">بدون SLA</SelectItem>
                        {slas.filter((s) => s.is_active).map((s) => (
                          <SelectItem key={s.id} value={String(s.id)}>
                            {s.name} (پاسخ: {s.response_time_hours}h, حل: {s.resolution_time_hours}h)
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                )}

                <div className="space-y-2">
                  <Label htmlFor="labels">برچسب‌ها</Label>
                  <Select
                    value={formData.labels.length > 0 ? formData.labels[0] : ""}
                    onValueChange={(value) => {
                      if (value) {
                        const current = formData.labels;
                        const index = current.indexOf(value);
                        if (index === -1) {
                          setFormData({ ...formData, labels: [...current, value] });
                        }
                      }
                    }}
                  >
                    <SelectTrigger id="labels">
                      <SelectValue placeholder="انتخاب برچسب" />
                    </SelectTrigger>
                    <SelectContent>
                      {labels.map((l) => (
                        <SelectItem key={l.id} value={String(l.id)}>
                          <span className="flex items-center gap-2">
                            <span
                              className="inline-block h-2 w-2 rounded-full"
                              style={{ backgroundColor: l.color }}
                            />
                            {l.name}
                          </span>
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  {formData.labels.length > 0 && (
                    <div className="flex flex-wrap gap-1 mt-2">
                      {formData.labels.map((labelId) => {
                        const label = labels.find((l) => String(l.id) === labelId);
                        return label ? (
                          <Badge
                            key={labelId}
                            variant="outline"
                            style={{ borderColor: label.color, color: label.color }}
                            className="flex items-center gap-1"
                          >
                            {label.name}
                            <button
                              type="button"
                              className="text-xs hover:text-red-500"
                              onClick={() => {
                                setFormData({
                                  ...formData,
                                  labels: formData.labels.filter((id) => id !== labelId),
                                });
                              }}
                            >
                              ×
                            </button>
                          </Badge>
                        ) : null;
                      })}
                    </div>
                  )}
                </div>

                <div className="space-y-2">
                  <Label htmlFor="due_date">تاریخ سررسید (اختیاری)</Label>
                  <Input
                    id="due_date"
                    type="datetime-local"
                    value={formData.due_date}
                    onChange={(e) => setFormData({ ...formData, due_date: e.target.value })}
                  />
                </div>

                <div className="flex items-center justify-between pt-2">
                  <Label htmlFor="is_confidential">محرمانه</Label>
                  <Switch
                    id="is_confidential"
                    checked={formData.is_confidential}
                    onCheckedChange={(checked) =>
                      setFormData({ ...formData, is_confidential: checked })
                    }
                  />
                </div>
              </CardContent>
            </Card>

            <Button type="submit" className="w-full" disabled={saving}>
              <Save className="ml-2 h-4 w-4" />
              {saving ? "در حال ذخیره..." : "ذخیره تغییرات"}
            </Button>
          </div>
        </div>
      </form>
    </div>
  );
}
// app/dashboard/admin/tickets/[id]/page.tsx
"use client";

import React, { useState, useEffect, useCallback } from "react";
import { useRouter, useParams } from "next/navigation";
import {
  ArrowRight,
  User,
  UserCog,
  Clock,
  Calendar,
  AlertCircle,
  MessageSquare,
  Paperclip,
  Plus,
  Pencil,
  Trash2,
  Loader2,
  Send,
  X,
  Eye,
  FileClock,
  CheckCircle,
  TrendingUp,
  Upload,
  Download,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Badge } from "@/components/ui/badge";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { toast } from "sonner";
import { toPersianDigits } from "@/lib/utils";
import { apiClientFetch, apiClientUpload } from "@/lib/api-client";

// ============================================================
// 📦 تعریف انواع
// ============================================================

interface User {
  id: number;
  username: string;
  full_name: string;
}

interface TicketStatus {
  id: number;
  name: string;
  color: string;
  is_closed: boolean;
}

interface TicketPriority {
  id: number;
  name: string;
  color: string;
  weight: number;
}

interface TicketCategory {
  id: number;
  name: string;
}

interface TicketDepartment {
  id: number;
  name: string;
}

interface TicketSLA {
  id: number;
  name: string;
  response_time_hours: number;
  resolution_time_hours: number;
  escalation_time_hours: number;
}

interface TicketAttachment {
  id: number;
  filename: string;
  file_size: number;
  file_url: string;
  uploaded_by: User;
  uploaded_at_jalali: string;
}

interface TicketComment {
  id: number;
  user: User;
  user_name: string;
  content: string;
  is_internal: boolean;
  created_at_jalali: string;
  attachments: TicketAttachment[];
}

interface TicketDetail {
  id: number;
  title: string;
  description: string;
  customer: User;
  customer_name: string;
  assigned_to: User | null;
  assigned_to_name: string | null;
  status: TicketStatus;
  status_name: string;
  priority: TicketPriority;
  priority_name: string;
  category: TicketCategory | null;
  category_name: string | null;
  department: TicketDepartment | null;
  department_name: string | null;
  sla: TicketSLA | null;
  sla_name: string | null;
  comments: TicketComment[];
  attachments: TicketAttachment[];
  comments_count: number;
  is_pinned: boolean;
  is_confidential: boolean;
  due_date: string | null;
  due_date_jalali: string | null;
  closed_at: string | null;
  closed_at_jalali: string | null;
  first_response_at: string | null;
  first_response_at_jalali: string | null;
  resolved_at: string | null;
  resolved_at_jalali: string | null;
  escalation_level: number;
  view_count: number;
  created_at_jalali: string;
  updated_at_jalali: string;
}

// ============================================================
// 📄 صفحه جزئیات تیکت
// ============================================================

export default function TicketDetailPage() {
  const router = useRouter();
  const params = useParams();
  const id = params.id as string;

  const [ticket, setTicket] = useState<TicketDetail | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [statuses, setStatuses] = useState<TicketStatus[]>([]);
  const [priorities, setPriorities] = useState<TicketPriority[]>([]);
  const [users, setUsers] = useState<User[]>([]);

  const [newComment, setNewComment] = useState("");
  const [isInternal, setIsInternal] = useState(false);
  const [selectedFiles, setSelectedFiles] = useState<File[]>([]);
  const [sendingComment, setSendingComment] = useState(false);

  const [assignDialogOpen, setAssignDialogOpen] = useState(false);
  const [selectedUser, setSelectedUser] = useState<string>("");
  const [statusDialogOpen, setStatusDialogOpen] = useState(false);
  const [selectedStatus, setSelectedStatus] = useState<string>("");
  const [priorityDialogOpen, setPriorityDialogOpen] = useState(false);
  const [selectedPriority, setSelectedPriority] = useState<string>("");

  const fetchTicket = useCallback(async () => {
    try {
      setLoading(true);
      setError(null);
      const data = await apiClientFetch<TicketDetail>(`/api/support/tickets/${id}/`);
      setTicket(data);
    } catch (error) {
      console.error("❌ خطا در دریافت جزئیات تیکت:", error);
      const msg = error instanceof Error ? error.message : "خطا در دریافت جزئیات تیکت";
      setError(msg);
      toast.error(msg);
    } finally {
      setLoading(false);
    }
  }, [id]);

  const fetchAuxData = useCallback(async () => {
    try {
      const [statusesData, prioritiesData, usersData] = await Promise.all([
        apiClientFetch<any>("/api/support/statuses/"),
        apiClientFetch<any>("/api/support/priorities/"),
        apiClientFetch<any>("/api/core/users/?limit=100"),
      ]);
      setStatuses(Array.isArray(statusesData) ? statusesData : statusesData.results || []);
      setPriorities(Array.isArray(prioritiesData) ? prioritiesData : prioritiesData.results || []);
      setUsers(Array.isArray(usersData) ? usersData : usersData.results || []);
    } catch (error) {
      console.error("❌ خطا در دریافت داده‌های کمکی:", error);
    }
  }, []);

  useEffect(() => {
    fetchTicket();
    fetchAuxData();
  }, [fetchTicket, fetchAuxData]);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      const files = Array.from(e.target.files);
      const allowedTypes = [
        "image/jpeg",
        "image/png",
        "application/pdf",
        "application/vnd.ms-excel",
        "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
      ];
      const invalidFiles = files.filter((f) => !allowedTypes.includes(f.type));
      if (invalidFiles.length > 0) {
        toast.error(
          `فایل‌های ${invalidFiles.map((f) => f.name).join(", ")} مجاز نیستند. فقط jpg, png, pdf, excel مجاز است.`
        );
        return;
      }
      const maxSize = 10 * 1024 * 1024;
      const oversized = files.filter((f) => f.size > maxSize);
      if (oversized.length > 0) {
        toast.error(`حجم فایل‌های ${oversized.map((f) => f.name).join(", ")} بیش از ۱۰ مگابایت است.`);
        return;
      }
      setSelectedFiles((prev) => [...prev, ...files]);
    }
  };

  const removeFile = (index: number) => {
    setSelectedFiles((prev) => prev.filter((_, i) => i !== index));
  };

  const handleAddComment = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newComment || newComment.trim().length === 0) {
      toast.error("متن کامنت را وارد کنید.");
      return;
    }

    setSendingComment(true);
    try {
      const formData = new FormData();
      formData.append("content", newComment.trim());
      formData.append("is_internal", String(isInternal));
      selectedFiles.forEach((file) => {
        formData.append("attachments", file);
      });

      await apiClientUpload(`/api/support/tickets/${id}/add_comment/`, formData, "POST");

      toast.success("کامنت با موفقیت ارسال شد");
      setNewComment("");
      setIsInternal(false);
      setSelectedFiles([]);
      fetchTicket();
    } catch (error) {
      console.error("❌ خطا در ارسال کامنت:", error);
      toast.error(error instanceof Error ? error.message : "خطا در ارسال کامنت");
    } finally {
      setSendingComment(false);
    }
  };

  const handleAssign = async () => {
    if (!selectedUser) {
      toast.error("لطفاً یک کاربر را انتخاب کنید.");
      return;
    }
    try {
      await apiClientFetch(`/api/support/tickets/${id}/assign/`, {
        method: "POST",
        body: { user_id: Number(selectedUser) },
      });
      toast.success("تیکت با موفقیت تخصیص داده شد");
      setAssignDialogOpen(false);
      setSelectedUser("");
      fetchTicket();
    } catch (error) {
      console.error("❌ خطا در تخصیص تیکت:", error);
      toast.error(error instanceof Error ? error.message : "خطا در تخصیص تیکت");
    }
  };

  const handleChangeStatus = async () => {
    if (!selectedStatus) {
      toast.error("لطفاً یک وضعیت را انتخاب کنید.");
      return;
    }
    try {
      await apiClientFetch(`/api/support/tickets/${id}/change_status/`, {
        method: "POST",
        body: { status_id: Number(selectedStatus) },
      });
      toast.success("وضعیت با موفقیت تغییر یافت");
      setStatusDialogOpen(false);
      setSelectedStatus("");
      fetchTicket();
    } catch (error) {
      console.error("❌ خطا در تغییر وضعیت:", error);
      toast.error(error instanceof Error ? error.message : "خطا در تغییر وضعیت");
    }
  };

  const handleChangePriority = async () => {
    if (!selectedPriority) {
      toast.error("لطفاً یک اولویت را انتخاب کنید.");
      return;
    }
    try {
      await apiClientFetch(`/api/support/tickets/${id}/change_priority/`, {
        method: "POST",
        body: { priority_id: Number(selectedPriority) },
      });
      toast.success("اولویت با موفقیت تغییر یافت");
      setPriorityDialogOpen(false);
      setSelectedPriority("");
      fetchTicket();
    } catch (error) {
      console.error("❌ خطا در تغییر اولویت:", error);
      toast.error(error instanceof Error ? error.message : "خطا در تغییر اولویت");
    }
  };

  const handleTogglePin = async () => {
    try {
      await apiClientFetch(`/api/support/tickets/${id}/toggle_pin/`, {
        method: "POST",
      });
      toast.success(ticket?.is_pinned ? "تیکت از پین خارج شد" : "تیکت پین شد");
      fetchTicket();
    } catch (error) {
      console.error("❌ خطا در تغییر پین:", error);
      toast.error(error instanceof Error ? error.message : "خطا در تغییر پین");
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center p-12">
        <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
      </div>
    );
  }

  if (error || !ticket) {
    return (
      <div className="flex flex-col items-center justify-center p-12 text-center">
        <AlertCircle className="h-12 w-12 text-red-500" />
        <p className="text-lg font-semibold mt-4">خطا در بارگذاری</p>
        <p className="text-muted-foreground">{error || "تیکت یافت نشد."}</p>
        <Button className="mt-4" onClick={() => router.push("/dashboard/admin/tickets")}>
          بازگشت به لیست تیکت‌ها
        </Button>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* هدر */}
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div>
          <div className="flex items-center gap-2 flex-wrap">
            <h1 className="text-2xl font-bold">{ticket.title}</h1>
            {ticket.is_pinned && (
              <Badge variant="outline" className="text-yellow-500 border-yellow-500">
                📌 پین شده
              </Badge>
            )}
            {ticket.is_confidential && (
              <Badge variant="outline" className="text-red-500 border-red-500">
                🔒 محرمانه
              </Badge>
            )}
            {ticket.escalation_level > 0 && (
              <Badge variant="destructive" className="gap-1">
                <TrendingUp className="h-3 w-3" />
                ارتقا {toPersianDigits(ticket.escalation_level)}
              </Badge>
            )}
          </div>
          <p className="text-muted-foreground text-sm">
            تیکت #{ticket.id} · {ticket.customer_name} · {ticket.created_at_jalali}
          </p>
        </div>
        <div className="flex flex-wrap gap-2">
          <Button variant="outline" size="sm" onClick={handleTogglePin}>
            {ticket.is_pinned ? "خروج از پین" : "پین کردن"}
          </Button>
          <Button variant="outline" size="sm" onClick={() => setAssignDialogOpen(true)}>
            <UserCog className="ml-1 h-4 w-4" />
            تخصیص
          </Button>
          <Button variant="outline" size="sm" onClick={() => setStatusDialogOpen(true)}>
            تغییر وضعیت
          </Button>
          <Button variant="outline" size="sm" onClick={() => setPriorityDialogOpen(true)}>
            تغییر اولویت
          </Button>
          <Button variant="outline" size="sm" onClick={() => router.push(`/dashboard/admin/tickets/${id}/edit`)}>
            <Pencil className="ml-1 h-4 w-4" />
            ویرایش
          </Button>
          <Button variant="outline" size="sm" onClick={() => router.push("/dashboard/admin/tickets")}>
            <ArrowRight className="ml-1 h-4 w-4" />
            بازگشت
          </Button>
        </div>
      </div>

      {/* اطلاعات اصلی */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>توضیحات</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="whitespace-pre-wrap">{ticket.description}</p>
            </CardContent>
          </Card>

          {/* کامنت‌ها */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <MessageSquare className="h-5 w-5" />
                نظرات ({toPersianDigits(ticket.comments_count)})
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {ticket.comments.length === 0 ? (
                <p className="text-muted-foreground text-center py-4">
                  هیچ نظری برای این تیکت ثبت نشده است.
                </p>
              ) : (
                ticket.comments.map((comment) => (
                  <div
                    key={comment.id}
                    className={`rounded-lg p-4 ${
                      comment.is_internal
                        ? "bg-yellow-50 border border-yellow-200"
                        : "bg-muted/50"
                    }`}
                  >
                    <div className="flex items-start justify-between">
                      <div>
                        <span className="font-medium">{comment.user_name}</span>
                        <span className="text-xs text-muted-foreground mr-2">
                          {comment.created_at_jalali}
                        </span>
                        {comment.is_internal && (
                          <Badge variant="outline" className="text-yellow-600 border-yellow-300 text-xs">
                            داخلی
                          </Badge>
                        )}
                      </div>
                    </div>
                    <p className="mt-2 whitespace-pre-wrap">{comment.content}</p>
                    {comment.attachments && comment.attachments.length > 0 && (
                      <div className="mt-2 flex flex-wrap gap-2">
                        {comment.attachments.map((att) => (
                          <Badge key={att.id} variant="outline" className="text-xs">
                            <a
                              href={att.file_url}
                              target="_blank"
                              rel="noopener noreferrer"
                              className="flex items-center gap-1 hover:text-primary"
                            >
                              <Paperclip className="h-3 w-3" />
                              {att.filename}
                              <Download className="h-3 w-3 ml-1" />
                            </a>
                          </Badge>
                        ))}
                      </div>
                    )}
                  </div>
                ))
              )}

              {/* فرم ارسال کامنت جدید + آپلود فایل */}
              <form onSubmit={handleAddComment} className="space-y-3 pt-4 border-t">
                <Textarea
                  value={newComment}
                  onChange={(e) => setNewComment(e.target.value)}
                  placeholder="نظر خود را وارد کنید..."
                  rows={3}
                  required
                />

                <div className="space-y-2">
                  <div className="flex items-center gap-2">
                    <Label htmlFor="file-upload" className="cursor-pointer">
                      <div className="flex items-center gap-2 rounded-md border border-dashed px-3 py-2 hover:bg-muted/50 transition-colors">
                        <Paperclip className="h-4 w-4" />
                        <span className="text-sm">ضمیمه کردن فایل</span>
                        <span className="text-xs text-muted-foreground">
                          (jpg, png, pdf, excel - حداکثر ۱۰ مگابایت)
                        </span>
                      </div>
                    </Label>
                    <Input
                      id="file-upload"
                      type="file"
                      multiple
                      accept=".jpg,.jpeg,.png,.pdf,.xls,.xlsx"
                      onChange={handleFileChange}
                      className="hidden"
                    />
                  </div>

                  {selectedFiles.length > 0 && (
                    <div className="flex flex-wrap gap-2">
                      {selectedFiles.map((file, index) => (
                        <Badge
                          key={index}
                          variant="outline"
                          className="flex items-center gap-1 pl-2"
                        >
                          <span className="text-xs">{file.name}</span>
                          <span className="text-xs text-muted-foreground">
                            ({Math.round(file.size / 1024)} KB)
                          </span>
                          <button
                            type="button"
                            onClick={() => removeFile(index)}
                            className="text-red-500 hover:text-red-700"
                          >
                            <X className="h-3 w-3" />
                          </button>
                        </Badge>
                      ))}
                    </div>
                  )}
                </div>

                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <Label htmlFor="is_internal" className="text-sm">
                      داخلی (فقط پشتیبانی)
                    </Label>
                    <Switch
                      id="is_internal"
                      checked={isInternal}
                      onCheckedChange={setIsInternal}
                    />
                  </div>
                  <Button type="submit" disabled={sendingComment}>
                    {sendingComment ? (
                      <Loader2 className="h-4 w-4 animate-spin" />
                    ) : (
                      <Send className="ml-1 h-4 w-4" />
                    )}
                    ارسال
                  </Button>
                </div>
              </form>
            </CardContent>
          </Card>
        </div>

        {/* سایدبار */}
        <div className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>اطلاعات</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3 text-sm">
              <div className="flex justify-between border-b py-1">
                <span className="text-muted-foreground">وضعیت</span>
                <Badge
                  variant="outline"
                  style={{
                    borderColor: ticket.status?.color || "#6B7280",
                    color: ticket.status?.color || "#6B7280",
                  }}
                >
                  {ticket.status_name}
                </Badge>
              </div>
              <div className="flex justify-between border-b py-1">
                <span className="text-muted-foreground">اولویت</span>
                <Badge
                  variant="outline"
                  style={{
                    borderColor: ticket.priority?.color || "#6B7280",
                    color: ticket.priority?.color || "#6B7280",
                  }}
                >
                  {ticket.priority_name}
                </Badge>
              </div>
              <div className="flex justify-between border-b py-1">
                <span className="text-muted-foreground">دسته‌بندی</span>
                <span>{ticket.category_name || "—"}</span>
              </div>
              <div className="flex justify-between border-b py-1">
                <span className="text-muted-foreground">دپارتمان</span>
                <span>{ticket.department_name || "—"}</span>
              </div>
              <div className="flex justify-between border-b py-1">
                <span className="text-muted-foreground">مسئول</span>
                <span>{ticket.assigned_to_name || "تخصیص‌نیافته"}</span>
              </div>
              {ticket.sla && (
                <div className="flex justify-between border-b py-1">
                  <span className="text-muted-foreground">SLA</span>
                  <span className="font-medium">{ticket.sla.name}</span>
                </div>
              )}
              {ticket.first_response_at_jalali && (
                <div className="flex justify-between border-b py-1">
                  <span className="text-muted-foreground">زمان اولین پاسخ</span>
                  <span>{ticket.first_response_at_jalali}</span>
                </div>
              )}
              {ticket.resolved_at_jalali && (
                <div className="flex justify-between border-b py-1">
                  <span className="text-muted-foreground">زمان حل</span>
                  <span>{ticket.resolved_at_jalali}</span>
                </div>
              )}
              {ticket.due_date_jalali && (
                <div className="flex justify-between border-b py-1">
                  <span className="text-muted-foreground">سررسید</span>
                  <span>{ticket.due_date_jalali}</span>
                </div>
              )}
              {ticket.closed_at_jalali && (
                <div className="flex justify-between border-b py-1">
                  <span className="text-muted-foreground">بسته شده در</span>
                  <span>{ticket.closed_at_jalali}</span>
                </div>
              )}
              <div className="flex justify-between py-1">
                <span className="text-muted-foreground">تعداد بازدید</span>
                <span>{toPersianDigits(ticket.view_count)}</span>
              </div>
            </CardContent>
          </Card>

          {/* پیوست‌های تیکت (سطح بالا) */}
          {ticket.attachments.length > 0 && (
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Paperclip className="h-4 w-4" />
                  پیوست‌ها
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                {ticket.attachments.map((att) => (
                  <div
                    key={att.id}
                    className="flex items-center justify-between rounded-lg bg-muted/50 p-2 text-sm"
                  >
                    <a
                      href={att.file_url}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="truncate hover:text-primary flex items-center gap-1"
                    >
                      <Paperclip className="h-3 w-3" />
                      {att.filename}
                    </a>
                    <span className="text-xs text-muted-foreground flex items-center gap-1">
                      {toPersianDigits(Math.round(att.file_size / 1024))} KB
                      <Download className="h-3 w-3" />
                    </span>
                  </div>
                ))}
              </CardContent>
            </Card>
          )}
        </div>
      </div>

      {/* دیالوگ‌ها */}
      <Dialog open={assignDialogOpen} onOpenChange={setAssignDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>تخصیص تیکت</DialogTitle>
            <DialogDescription>کاربر مسئول را برای این تیکت انتخاب کنید.</DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div className="space-y-2">
              <Label>کاربر</Label>
              <Select value={selectedUser} onValueChange={setSelectedUser}>
                <SelectTrigger>
                  <SelectValue placeholder="انتخاب کاربر" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="">انتخاب کنید</SelectItem>
                  {users.map((u) => (
                    <SelectItem key={u.id} value={String(u.id)}>
                      {u.full_name || u.username}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="flex gap-2">
              <Button variant="outline" className="flex-1" onClick={() => setAssignDialogOpen(false)}>
                انصراف
              </Button>
              <Button className="flex-1" onClick={handleAssign}>
                تخصیص
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      <Dialog open={statusDialogOpen} onOpenChange={setStatusDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>تغییر وضعیت</DialogTitle>
            <DialogDescription>وضعیت جدید تیکت را انتخاب کنید.</DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div className="space-y-2">
              <Label>وضعیت</Label>
              <Select value={selectedStatus} onValueChange={setSelectedStatus}>
                <SelectTrigger>
                  <SelectValue placeholder="انتخاب وضعیت" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="">انتخاب کنید</SelectItem>
                  {statuses.map((s) => (
                    <SelectItem key={s.id} value={String(s.id)}>
                      <span className="flex items-center gap-2">
                        <span
                          className="inline-block h-2 w-2 rounded-full"
                          style={{ backgroundColor: s.color }}
                        />
                        {s.name}
                      </span>
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="flex gap-2">
              <Button variant="outline" className="flex-1" onClick={() => setStatusDialogOpen(false)}>
                انصراف
              </Button>
              <Button className="flex-1" onClick={handleChangeStatus}>
                تغییر
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      <Dialog open={priorityDialogOpen} onOpenChange={setPriorityDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>تغییر اولویت</DialogTitle>
            <DialogDescription>اولویت جدید تیکت را انتخاب کنید.</DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div className="space-y-2">
              <Label>اولویت</Label>
              <Select value={selectedPriority} onValueChange={setSelectedPriority}>
                <SelectTrigger>
                  <SelectValue placeholder="انتخاب اولویت" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="">انتخاب کنید</SelectItem>
                  {priorities.map((p) => (
                    <SelectItem key={p.id} value={String(p.id)}>
                      <span className="flex items-center gap-2">
                        <span
                          className="inline-block h-2 w-2 rounded-full"
                          style={{ backgroundColor: p.color }}
                        />
                        {p.name}
                      </span>
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="flex gap-2">
              <Button variant="outline" className="flex-1" onClick={() => setPriorityDialogOpen(false)}>
                انصراف
              </Button>
              <Button className="flex-1" onClick={handleChangePriority}>
                تغییر
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
// app/dashboard/admin/tickets/new/page.tsx
"use client";

import React, { useState, useEffect } from "react";
import { useRouter } from "next/navigation";
import { Save, X, Loader2, Paperclip } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Badge } from "@/components/ui/badge";
import { toast } from "sonner";
import { apiClientFetch, apiClientUpload } from "@/lib/api-client";

// ============================================================
// 📦 تعریف انواع
// ============================================================

interface TicketCategory {
  id: number;
  name: string;
  is_active: boolean;
}

interface TicketPriority {
  id: number;
  name: string;
  color: string;
  is_active: boolean;
}

interface TicketStatus {
  id: number;
  name: string;
  color: string;
  is_closed: boolean;
}

interface TicketDepartment {
  id: number;
  name: string;
  is_active: boolean;
}

interface TicketSLA {
  id: number;
  name: string;
  response_time_hours: number;
  resolution_time_hours: number;
  is_active: boolean;
}

interface InspectionRequest {
  id: number;
  request_number: string;
  equipment_type_name: string;
  customer_name: string;
}

// ============================================================
// 📄 صفحه ایجاد تیکت جدید
// ============================================================

export default function NewTicketPage() {
  const router = useRouter();
  const [loading, setLoading] = useState(false);
  const [fetchingData, setFetchingData] = useState(true);

  const [categories, setCategories] = useState<TicketCategory[]>([]);
  const [priorities, setPriorities] = useState<TicketPriority[]>([]);
  const [statuses, setStatuses] = useState<TicketStatus[]>([]);
  const [departments, setDepartments] = useState<TicketDepartment[]>([]);
  const [slas, setSlas] = useState<TicketSLA[]>([]);
  const [inspectionRequests, setInspectionRequests] = useState<InspectionRequest[]>([]);

  const [formData, setFormData] = useState({
    title: "",
    description: "",
    category: "",
    priority: "",
    department: "",
    sla: "",
    inspection_request: "",
    due_date: "",
    is_confidential: false,
  });

  const [attachments, setAttachments] = useState<File[]>([]);

  // دریافت داده‌های اولیه - ✅ اصلاح شده با مدیریت خطای SLA
  useEffect(() => {
    const fetchData = async () => {
      try {
        setFetchingData(true);

        // دریافت دسته‌بندی‌ها، اولویت‌ها، وضعیت‌ها و دپارتمان‌ها به صورت همزمان
        const [categoriesData, prioritiesData, statusesData, departmentsData, requestsData] =
          await Promise.all([
            apiClientFetch<any>("/api/support/categories/"),
            apiClientFetch<any>("/api/support/priorities/"),
            apiClientFetch<any>("/api/support/statuses/"),
            apiClientFetch<any>("/api/support/departments/"),
            apiClientFetch<any>("/api/core/inspection-requests/?limit=50"),
          ]);

        setCategories(Array.isArray(categoriesData) ? categoriesData : categoriesData.results || []);
        setPriorities(Array.isArray(prioritiesData) ? prioritiesData : prioritiesData.results || []);
        setStatuses(Array.isArray(statusesData) ? statusesData : statusesData.results || []);
        setDepartments(Array.isArray(departmentsData) ? departmentsData : departmentsData.results || []);
        setInspectionRequests(Array.isArray(requestsData) ? requestsData : requestsData.results || []);

        // دریافت SLA به صورت جداگانه با مدیریت خطا (اگر 404 داد، آرایه خالی برگردان)
        try {
          const slasData = await apiClientFetch<any>("/api/support/slas/");
          setSlas(Array.isArray(slasData) ? slasData : slasData.results || []);
        } catch (slaError) {
          // اگر SLA پیدا نشد (404)، فقط لاگ کن و آرایه خالی بگذار
          console.warn("SLA endpoint not found, continuing without SLA:", slaError);
          setSlas([]);
        }
      } catch (error) {
        console.error("❌ خطا در دریافت داده‌ها:", error);
        toast.error("خطا در دریافت اطلاعات مورد نیاز");
      } finally {
        setFetchingData(false);
      }
    };
    fetchData();
  }, []);

  // مدیریت فایل‌ها
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      const files = Array.from(e.target.files);
      const allowedTypes = [
        "image/jpeg",
        "image/png",
        "application/pdf",
        "application/vnd.ms-excel",
        "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
      ];
      const invalidFiles = files.filter((f) => !allowedTypes.includes(f.type));
      if (invalidFiles.length > 0) {
        toast.error(
          `فایل‌های ${invalidFiles.map((f) => f.name).join(", ")} مجاز نیستند. فقط jpg, png, pdf, excel مجاز است.`
        );
        return;
      }
      const maxSize = 10 * 1024 * 1024;
      const oversized = files.filter((f) => f.size > maxSize);
      if (oversized.length > 0) {
        toast.error(`حجم فایل‌های ${oversized.map((f) => f.name).join(", ")} بیش از ۱۰ مگابایت است.`);
        return;
      }
      setAttachments((prev) => [...prev, ...files]);
    }
  };

  const removeFile = (index: number) => {
    setAttachments((prev) => prev.filter((_, i) => i !== index));
  };

  // ارسال فرم - ✅ اصلاح شده با apiClientUpload
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!formData.title || formData.title.trim().length < 3) {
      toast.error("عنوان تیکت باید حداقل ۳ کاراکتر باشد.");
      return;
    }
    if (!formData.description || formData.description.trim().length < 10) {
      toast.error("توضیحات تیکت باید حداقل ۱۰ کاراکتر باشد.");
      return;
    }

    const payload = new FormData();
    payload.append("title", formData.title.trim());
    payload.append("description", formData.description.trim());
    payload.append("is_confidential", String(formData.is_confidential));
    if (formData.category) payload.append("category", formData.category);
    if (formData.priority) payload.append("priority", formData.priority);
    if (formData.department) payload.append("department", formData.department);
    if (formData.sla) payload.append("sla", formData.sla);
    if (formData.inspection_request) payload.append("inspection_request", formData.inspection_request);
    if (formData.due_date) payload.append("due_date", formData.due_date);
    attachments.forEach((file) => {
      payload.append("attachments", file);
    });

    setLoading(true);
    try {
      const result = await apiClientUpload<any>("/api/support/tickets/", payload, "POST");
      toast.success("تیکت با موفقیت ایجاد شد");
      router.push(`/dashboard/admin/tickets/${result.id}`);
      router.refresh();
    } catch (error) {
      console.error("❌ خطا در ایجاد تیکت:", error);
      toast.error(error instanceof Error ? error.message : "خطا در ایجاد تیکت");
    } finally {
      setLoading(false);
    }
  };

  const handleCancel = () => {
    router.back();
  };

  if (fetchingData) {
    return (
      <div className="flex items-center justify-center p-12">
        <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* هدر */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold">تیکت جدید</h1>
          <p className="text-muted-foreground text-sm">ثبت تیکت جدید توسط مدیر</p>
        </div>
        <Button variant="outline" onClick={handleCancel}>
          <X className="ml-2 h-4 w-4" />
          انصراف
        </Button>
      </div>

      <form onSubmit={handleSubmit}>
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* ستون اصلی */}
          <div className="lg:col-span-2 space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>اطلاعات تیکت</CardTitle>
                <CardDescription>عنوان و توضیحات تیکت</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="title">عنوان *</Label>
                  <Input
                    id="title"
                    value={formData.title}
                    onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                    placeholder="مثلاً مشکل در ورود به سامانه"
                    required
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="description">توضیحات *</Label>
                  <Textarea
                    id="description"
                    value={formData.description}
                    onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                    placeholder="توضیحات کامل مشکل را وارد کنید..."
                    rows={6}
                    required
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="inspection_request">درخواست کارشناسی مرتبط (اختیاری)</Label>
                  <Select
                    value={formData.inspection_request}
                    onValueChange={(value) => setFormData({ ...formData, inspection_request: value })}
                  >
                    <SelectTrigger id="inspection_request">
                      <SelectValue placeholder="انتخاب درخواست" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="">بدون درخواست</SelectItem>
                      {inspectionRequests.map((req) => (
                        <SelectItem key={req.id} value={String(req.id)}>
                          {req.request_number} - {req.equipment_type_name} ({req.customer_name})
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                {/* بخش آپلود فایل */}
                <div className="space-y-2">
                  <Label>ضمیمه‌ها (اختیاری)</Label>
                  <div className="flex items-center gap-2">
                    <Label htmlFor="file-upload-new" className="cursor-pointer">
                      <div className="flex items-center gap-2 rounded-md border border-dashed px-3 py-2 hover:bg-muted/50 transition-colors">
                        <Paperclip className="h-4 w-4" />
                        <span className="text-sm">انتخاب فایل</span>
                        <span className="text-xs text-muted-foreground">
                          (jpg, png, pdf, excel - حداکثر ۱۰ مگابایت)
                        </span>
                      </div>
                    </Label>
                    <Input
                      id="file-upload-new"
                      type="file"
                      multiple
                      accept=".jpg,.jpeg,.png,.pdf,.xls,.xlsx"
                      onChange={handleFileChange}
                      className="hidden"
                    />
                  </div>
                  {attachments.length > 0 && (
                    <div className="flex flex-wrap gap-2">
                      {attachments.map((file, index) => (
                        <Badge key={index} variant="outline" className="flex items-center gap-1 pl-2">
                          <span className="text-xs">{file.name}</span>
                          <span className="text-xs text-muted-foreground">
                            ({Math.round(file.size / 1024)} KB)
                          </span>
                          <button
                            type="button"
                            onClick={() => removeFile(index)}
                            className="text-red-500 hover:text-red-700"
                          >
                            <X className="h-3 w-3" />
                          </button>
                        </Badge>
                      ))}
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* ستون سمت راست */}
          <div className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>تنظیمات</CardTitle>
                <CardDescription>دسته‌بندی، اولویت، SLA و سایر تنظیمات</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="category">دسته‌بندی</Label>
                  <Select
                    value={formData.category}
                    onValueChange={(value) => setFormData({ ...formData, category: value })}
                  >
                    <SelectTrigger id="category">
                      <SelectValue placeholder="انتخاب دسته‌بندی" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="">بدون دسته‌بندی</SelectItem>
                      {categories.filter((c) => c.is_active).map((c) => (
                        <SelectItem key={c.id} value={String(c.id)}>
                          {c.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="priority">اولویت</Label>
                  <Select
                    value={formData.priority}
                    onValueChange={(value) => setFormData({ ...formData, priority: value })}
                  >
                    <SelectTrigger id="priority">
                      <SelectValue placeholder="انتخاب اولویت" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="">بدون اولویت</SelectItem>
                      {priorities.filter((p) => p.is_active).map((p) => (
                        <SelectItem key={p.id} value={String(p.id)}>
                          <span className="flex items-center gap-2">
                            <span
                              className="inline-block h-2 w-2 rounded-full"
                              style={{ backgroundColor: p.color }}
                            />
                            {p.name}
                          </span>
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="department">دپارتمان</Label>
                  <Select
                    value={formData.department}
                    onValueChange={(value) => setFormData({ ...formData, department: value })}
                  >
                    <SelectTrigger id="department">
                      <SelectValue placeholder="انتخاب دپارتمان" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="">بدون دپارتمان</SelectItem>
                      {departments.filter((d) => d.is_active).map((d) => (
                        <SelectItem key={d.id} value={String(d.id)}>
                          {d.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                {/* انتخاب SLA - اگر SLA موجود نباشد، نمایش داده نمی‌شود */}
                {slas.length > 0 && (
                  <div className="space-y-2">
                    <Label htmlFor="sla">SLA</Label>
                    <Select
                      value={formData.sla}
                      onValueChange={(value) => setFormData({ ...formData, sla: value })}
                    >
                      <SelectTrigger id="sla">
                        <SelectValue placeholder="انتخاب SLA" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="">بدون SLA</SelectItem>
                        {slas.filter((s) => s.is_active).map((s) => (
                          <SelectItem key={s.id} value={String(s.id)}>
                            {s.name} (پاسخ: {s.response_time_hours}h, حل: {s.resolution_time_hours}h)
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                )}

                <div className="space-y-2">
                  <Label htmlFor="due_date">تاریخ سررسید (اختیاری)</Label>
                  <Input
                    id="due_date"
                    type="datetime-local"
                    value={formData.due_date}
                    onChange={(e) => setFormData({ ...formData, due_date: e.target.value })}
                  />
                </div>

                <div className="flex items-center justify-between pt-2">
                  <Label htmlFor="is_confidential">محرمانه</Label>
                  <Switch
                    id="is_confidential"
                    checked={formData.is_confidential}
                    onCheckedChange={(checked) =>
                      setFormData({ ...formData, is_confidential: checked })
                    }
                  />
                </div>
              </CardContent>
            </Card>

            <Button type="submit" className="w-full" disabled={loading}>
              <Save className="ml-2 h-4 w-4" />
              {loading ? "در حال ثبت..." : "ثبت تیکت"}
            </Button>
          </div>
        </div>
      </form>
    </div>
  );
}
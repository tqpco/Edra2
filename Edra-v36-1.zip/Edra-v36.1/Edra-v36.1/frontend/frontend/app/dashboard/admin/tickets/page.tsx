// app/dashboard/admin/tickets/page.tsx
"use client";

import React, { useState, useEffect, useCallback } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import {
  Plus,
  Search,
  RefreshCw,
  Pencil,
  Trash2,
  Loader2,
  UserCog,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { toast } from "sonner";
import { toPersianDigits } from "@/lib/utils";
import { PaginationClient } from "@/components/ui/pagination";
import { apiClientFetch } from "@/lib/api-client"; // ✅ اضافه شد

interface TicketStatus {
  id: number;
  name: string;
  color: string;
  is_closed: boolean;
}

interface TicketPriority {
  id: number;
  name: string;
  color: string;
  weight: number;
}

interface TicketListItem {
  id: number;
  title: string;
  customer_name: string;
  assigned_to_name: string | null;
  status_name: string;
  priority_name: string;
  sla_name: string | null;
  first_response_at_jalali: string | null;
  resolved_at_jalali: string | null;
  escalation_level: number;
  created_at_jalali: string;
  updated_at_jalali: string;
  comments_count: number;
  is_pinned: boolean;
}

export default function AdminTicketsPage() {
  const router = useRouter();
  const [tickets, setTickets] = useState<TicketListItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [searchTerm, setSearchTerm] = useState("");
  const [statusFilter, setStatusFilter] = useState<string>("");
  const [priorityFilter, setPriorityFilter] = useState<string>("");
  const [page, setPage] = useState(1);
  const [totalItems, setTotalItems] = useState(0);
  const [statuses, setStatuses] = useState<TicketStatus[]>([]);
  const [priorities, setPriorities] = useState<TicketPriority[]>([]);

  const fetchStatuses = useCallback(async () => {
    try {
      const data = await apiClientFetch<any>("/api/support/statuses/");
      setStatuses(Array.isArray(data) ? data : data.results || []);
    } catch (error) {
      console.error("خطا در دریافت وضعیت‌ها:", error);
    }
  }, []);

  const fetchPriorities = useCallback(async () => {
    try {
      const data = await apiClientFetch<any>("/api/support/priorities/");
      setPriorities(Array.isArray(data) ? data : data.results || []);
    } catch (error) {
      console.error("خطا در دریافت اولویت‌ها:", error);
    }
  }, []);

  const fetchTickets = useCallback(
    async (pageNum: number = 1) => {
      try {
        setLoading(true);
        setError(null);
        const params = new URLSearchParams();
        if (searchTerm) params.append("search", searchTerm);
        if (statusFilter) params.append("status", statusFilter);
        if (priorityFilter) params.append("priority", priorityFilter);
        params.append("page", String(pageNum));

        const data = await apiClientFetch<{ results: TicketListItem[]; count: number }>(
          `/api/support/tickets/?${params.toString()}`
        );

        setTickets(data.results || []);
        setTotalItems(data.count || 0);
      } catch (error) {
        console.error("خطا در دریافت لیست تیکت‌ها:", error);
        const msg = error instanceof Error ? error.message : "خطا در دریافت لیست تیکت‌ها";
        setError(msg);
        toast.error(msg);
      } finally {
        setLoading(false);
      }
    },
    [searchTerm, statusFilter, priorityFilter]
  );

  useEffect(() => {
    const loadData = async () => {
      await Promise.all([fetchStatuses(), fetchPriorities(), fetchTickets(page)]);
    };
    loadData();
  }, []);

  useEffect(() => {
    fetchTickets(page);
  }, [page, searchTerm, statusFilter, priorityFilter, fetchTickets]);

  const handleSearch = (value: string) => {
    setSearchTerm(value);
    setPage(1);
  };

  const handleRefresh = () => {
    fetchStatuses();
    fetchPriorities();
    fetchTickets(page);
  };

  const handleDelete = async (id: number) => {
    if (!confirm("آیا از حذف این تیکت مطمئن هستید؟")) return;
    try {
      await apiClientFetch(`/api/support/tickets/${id}/`, {
        method: "DELETE",
      });
      toast.success("تیکت حذف شد");
      fetchTickets(page);
    } catch (error) {
      const msg = error instanceof Error ? error.message : "خطا در حذف تیکت";
      toast.error(msg);
    }
  };

  const getStatusColor = (statusName: string) => {
    const status = statuses.find((s) => s.name === statusName);
    return status?.color || "#6B7280";
  };

  const getPriorityColor = (priorityName: string) => {
    const priority = priorities.find((p) => p.name === priorityName);
    return priority?.color || "#6B7280";
  };

  if (loading && tickets.length === 0) {
    return (
      <div className="flex items-center justify-center p-12">
        <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="text-2xl font-bold">مدیریت تیکت‌ها</h1>
          <p className="text-muted-foreground text-sm">
            {totalItems > 0
              ? `${toPersianDigits(totalItems)} تیکت در سیستم`
              : "هیچ تیکتی ثبت نشده است"}
          </p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" size="icon" onClick={handleRefresh} title="بروزرسانی">
            <RefreshCw className="h-4 w-4" />
          </Button>
          <Link href="/dashboard/admin/tickets/new">
            <Button>
              <Plus className="ml-2 h-4 w-4" />
              تیکت جدید
            </Button>
          </Link>
        </div>
      </div>

      <div className="flex flex-wrap gap-3">
        <div className="relative max-w-sm flex-1">
          <Search className="absolute right-3 top-2.5 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="جستجوی تیکت..."
            value={searchTerm}
            onChange={(e) => handleSearch(e.target.value)}
            className="pr-9"
          />
        </div>
        <Select value={statusFilter} onValueChange={setStatusFilter}>
          <SelectTrigger className="w-40">
            <SelectValue placeholder="همه وضعیت‌ها" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="">همه وضعیت‌ها</SelectItem>
            {statuses.map((s) => (
              <SelectItem key={s.id} value={String(s.id)}>
                <span className="flex items-center gap-2">
                  <span
                    className="inline-block h-2 w-2 rounded-full"
                    style={{ backgroundColor: s.color }}
                  />
                  {s.name}
                </span>
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
        <Select value={priorityFilter} onValueChange={setPriorityFilter}>
          <SelectTrigger className="w-40">
            <SelectValue placeholder="همه اولویت‌ها" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="">همه اولویت‌ها</SelectItem>
            {priorities.map((p) => (
              <SelectItem key={p.id} value={String(p.id)}>
                <span className="flex items-center gap-2">
                  <span
                    className="inline-block h-2 w-2 rounded-full"
                    style={{ backgroundColor: p.color }}
                  />
                  {p.name}
                </span>
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>لیست تیکت‌ها</CardTitle>
          <CardDescription>
            {totalItems > 0
              ? `${toPersianDigits(totalItems)} تیکت در سیستم`
              : "هیچ تیکتی ثبت نشده است"}
          </CardDescription>
        </CardHeader>
        <CardContent>
          {error ? (
            <div className="text-center text-red-500 py-8">
              <p>خطا در بارگذاری اطلاعات</p>
              <p className="text-sm">{error}</p>
              <Button variant="outline" className="mt-4" onClick={handleRefresh}>
                تلاش مجدد
              </Button>
            </div>
          ) : tickets.length === 0 ? (
            <div className="text-center text-muted-foreground py-12">
              <p className="text-lg">هیچ تیکتی ثبت نشده است.</p>
              <p className="text-sm mt-2">برای افزودن تیکت جدید، دکمه "تیکت جدید" را کلیک کنید.</p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>عنوان</TableHead>
                    <TableHead>مشتری</TableHead>
                    <TableHead>مسئول</TableHead>
                    <TableHead>اولویت</TableHead>
                    <TableHead>وضعیت</TableHead>
                    <TableHead>SLA</TableHead>
                    <TableHead>پاسخ اولیه</TableHead>
                    <TableHead>حل</TableHead>
                    <TableHead>سطح ارتقا</TableHead>
                    <TableHead>نظرات</TableHead>
                    <TableHead className="text-left">عملیات</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {tickets.map((ticket) => (
                    <TableRow key={ticket.id}>
                      <TableCell className="font-medium">
                        <Link
                          href={`/dashboard/admin/tickets/${ticket.id}`}
                          className="hover:text-primary"
                        >
                          {ticket.is_pinned && (
                            <span className="mr-1 text-yellow-500">📌</span>
                          )}
                          {ticket.title}
                        </Link>
                      </TableCell>
                      <TableCell>{ticket.customer_name}</TableCell>
                      <TableCell>
                        {ticket.assigned_to_name ?? (
                          <span className="text-muted-foreground">تخصیص‌نیافته</span>
                        )}
                      </TableCell>
                      <TableCell>
                        <Badge
                          variant="outline"
                          style={{
                            borderColor: getPriorityColor(ticket.priority_name),
                            color: getPriorityColor(ticket.priority_name),
                          }}
                        >
                          {ticket.priority_name}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <Badge
                          variant="outline"
                          style={{
                            borderColor: getStatusColor(ticket.status_name),
                            color: getStatusColor(ticket.status_name),
                          }}
                        >
                          {ticket.status_name}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        {ticket.sla_name ?? (
                          <span className="text-muted-foreground text-xs">—</span>
                        )}
                      </TableCell>
                      <TableCell className="text-xs">
                        {ticket.first_response_at_jalali ?? "—"}
                      </TableCell>
                      <TableCell className="text-xs">
                        {ticket.resolved_at_jalali ?? "—"}
                      </TableCell>
                      <TableCell className="text-center">
                        {ticket.escalation_level > 0 ? (
                          <Badge variant="destructive" className="text-xs">
                            {toPersianDigits(ticket.escalation_level)}
                          </Badge>
                        ) : (
                          <span className="text-muted-foreground text-xs">۰</span>
                        )}
                      </TableCell>
                      <TableCell className="text-center">
                        {toPersianDigits(ticket.comments_count)}
                      </TableCell>
                      <TableCell className="text-left">
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() =>
                            router.push(`/dashboard/admin/tickets/${ticket.id}`)
                          }
                        >
                          <UserCog className="h-4 w-4" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() =>
                            router.push(`/dashboard/admin/tickets/${ticket.id}/edit`)
                          }
                        >
                          <Pencil className="h-4 w-4" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => handleDelete(ticket.id)}
                          className="text-red-500 hover:text-red-700"
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}

          {totalItems > 10 && (
            <div className="mt-4 flex items-center justify-between">
              <p className="text-muted-foreground text-sm">
                نمایش {toPersianDigits(tickets.length)} از {toPersianDigits(totalItems)}
              </p>
              <PaginationClient
                current={page}
                totalItems={totalItems}
                onPageChange={setPage}
                pageSize={10}
              />
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
// app/dashboard/admin/tickets/settings/page.tsx
"use client";

import React, { useState, useEffect, useCallback } from "react";
import {
  Plus,
  Pencil,
  Trash2,
  Loader2,
  RefreshCw,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { toast } from "sonner";
import { toPersianDigits } from "@/lib/utils";
import { apiClientFetch } from "@/lib/api-client";

// ============================================================
// 📦 تعریف انواع
// ============================================================

interface BaseItem {
  id: number;
  name: string;
  is_active: boolean;
}

interface TicketCategory extends BaseItem {
  description?: string;
}

interface TicketPriority extends BaseItem {
  color: string;
  weight: number;
}

interface TicketStatus extends BaseItem {
  color: string;
  is_closed: boolean;
}

interface TicketDepartment extends BaseItem {
  description?: string;
}

interface TicketLabel {
  id: number;
  name: string;
  color: string;
  // no is_active
}

// ============================================================
// 🧩 کامپوننت مدیریت هر بخش - ✅ اصلاح شده
// ============================================================

type SectionItem = TicketCategory | TicketPriority | TicketStatus | TicketDepartment | TicketLabel;

interface SectionManagerProps<T extends SectionItem> {
  title: string;
  endpoint: string;
  items: T[];
  loading: boolean;
  fetchItems: () => Promise<void>;
  fields: { key: keyof T; label: string; type: "text" | "color" | "number" | "switch" }[];
  renderExtra?: (item: T) => React.ReactNode;
}

function SectionManager<T extends SectionItem>({
  title,
  endpoint,
  items,
  loading,
  fetchItems,
  fields,
  renderExtra,
}: SectionManagerProps<T>) {
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingItem, setEditingItem] = useState<T | null>(null);
  const [formData, setFormData] = useState<Partial<T>>({});
  const [saving, setSaving] = useState(false);

  const resetForm = () => {
    const defaultValues: Partial<T> = {} as Partial<T>;
    fields.forEach((f) => {
      if (f.type === "switch") {
        (defaultValues as any)[f.key] = false;
      } else if (f.type === "color") {
        (defaultValues as any)[f.key] = "#6B7280";
      } else if (f.type === "number") {
        (defaultValues as any)[f.key] = 0;
      } else {
        (defaultValues as any)[f.key] = "";
      }
    });
    if ("is_active" in defaultValues) {
      (defaultValues as any).is_active = true;
    }
    setFormData(defaultValues);
    setEditingItem(null);
  };

  const openAddDialog = () => {
    resetForm();
    setDialogOpen(true);
  };

  const openEditDialog = (item: T) => {
    setEditingItem(item);
    setFormData({ ...item });
    setDialogOpen(true);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name || (formData.name as string).trim().length === 0) {
      toast.error("نام الزامی است.");
      return;
    }

    setSaving(true);
    try {
      const payload = { ...formData };
      const url = editingItem
        ? `/api/support/${endpoint}/${editingItem.id}/`
        : `/api/support/${endpoint}/`;
      const method = editingItem ? "PUT" : "POST";

      await apiClientFetch(url, {
        method,
        body: payload,
      });

      toast.success(editingItem ? "با موفقیت ویرایش شد" : "با موفقیت افزوده شد");
      setDialogOpen(false);
      await fetchItems();
    } catch (error) {
      console.error(`❌ خطا در ذخیره‌سازی ${title}:`, error);
      toast.error(error instanceof Error ? error.message : "خطا در ذخیره‌سازی");
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async (id: number) => {
    if (!confirm(`آیا از حذف این آیتم مطمئن هستید؟`)) return;
    try {
      await apiClientFetch(`/api/support/${endpoint}/${id}/`, {
        method: "DELETE",
      });
      toast.success("با موفقیت حذف شد");
      await fetchItems();
    } catch (error) {
      console.error(`❌ خطا در حذف ${title}:`, error);
      toast.error(error instanceof Error ? error.message : "خطا در حذف");
    }
  };

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between">
        <div>
          <CardTitle>{title}</CardTitle>
          <CardDescription>مدیریت {title}</CardDescription>
        </div>
        <Button size="sm" onClick={openAddDialog}>
          <Plus className="ml-1 h-3 w-3" />
          جدید
        </Button>
      </CardHeader>
      <CardContent>
        {loading ? (
          <div className="flex justify-center py-8">
            <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
          </div>
        ) : items.length === 0 ? (
          <p className="text-center text-muted-foreground py-4">هیچ آیتمی ثبت نشده است.</p>
        ) : (
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>#</TableHead>
                  <TableHead>نام</TableHead>
                  {fields.map((f) => (
                    <TableHead key={String(f.key)}>{f.label}</TableHead>
                  ))}
                  {renderExtra && <TableHead>اطلاعات بیشتر</TableHead>}
                  {(items[0] as any).hasOwnProperty("is_active") && <TableHead>وضعیت</TableHead>}
                  <TableHead className="text-left">عملیات</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {items.map((item, index) => (
                  <TableRow key={item.id}>
                    <TableCell>{toPersianDigits(index + 1)}</TableCell>
                    <TableCell className="font-medium">{item.name}</TableCell>
                    {fields.map((f) => {
                      const value = item[f.key];
                      if (f.type === "color") {
                        return (
                          <TableCell key={String(f.key)}>
                            <span
                              className="inline-block h-4 w-4 rounded-full border"
                              style={{ backgroundColor: String(value) }}
                            />
                          </TableCell>
                        );
                      }
                      if (f.type === "switch") {
                        return (
                          <TableCell key={String(f.key)}>
                            {value ? "بله" : "خیر"}
                          </TableCell>
                        );
                      }
                      return (
                        <TableCell key={String(f.key)}>
                          {value !== null && value !== undefined ? String(value) : "—"}
                        </TableCell>
                      );
                    })}
                    {renderExtra && (
                      <TableCell>{renderExtra(item)}</TableCell>
                    )}
                    {(item as any).hasOwnProperty("is_active") && (
                      <TableCell>
                        <span
                          className={`inline-flex rounded-full px-2 py-0.5 text-xs font-medium ${
                            (item as any).is_active
                              ? "bg-green-50 text-green-700 border border-green-500"
                              : "bg-gray-50 text-gray-500 border border-gray-300"
                          }`}
                        >
                          {(item as any).is_active ? "فعال" : "غیرفعال"}
                        </span>
                      </TableCell>
                    )}
                    <TableCell className="text-left">
                      <Button variant="ghost" size="sm" onClick={() => openEditDialog(item)}>
                        <Pencil className="h-3 w-3" />
                      </Button>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => handleDelete(item.id)}
                        className="text-red-500 hover:text-red-700"
                      >
                        <Trash2 className="h-3 w-3" />
                      </Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        )}
      </CardContent>

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>
              {editingItem ? `ویرایش ${title}` : `افزودن ${title} جدید`}
            </DialogTitle>
            <DialogDescription>
              {editingItem
                ? `اطلاعات ${title} را ویرایش کنید`
                : `اطلاعات ${title} جدید را وارد کنید`}
            </DialogDescription>
          </DialogHeader>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-2">
              <Label>نام *</Label>
              <Input
                value={formData.name || ""}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                placeholder="نام را وارد کنید"
                required
              />
            </div>

            {fields.map((f) => {
              if (f.key === "name") return null;
              if (f.type === "color") {
                return (
                  <div key={String(f.key)} className="space-y-2">
                    <Label>{f.label}</Label>
                    <div className="flex gap-2">
                      <Input
                        type="color"
                        value={(formData as any)[f.key] || "#6B7280"}
                        onChange={(e) =>
                          setFormData({ ...formData, [f.key]: e.target.value })
                        }
                        className="w-16 p-1"
                      />
                      <Input
                        value={(formData as any)[f.key] || ""}
                        onChange={(e) =>
                          setFormData({ ...formData, [f.key]: e.target.value })
                        }
                        placeholder="#6B7280"
                      />
                    </div>
                  </div>
                );
              }
              if (f.type === "number") {
                return (
                  <div key={String(f.key)} className="space-y-2">
                    <Label>{f.label}</Label>
                    <Input
                      type="number"
                      value={(formData as any)[f.key] || 0}
                      onChange={(e) =>
                        setFormData({ ...formData, [f.key]: Number(e.target.value) })
                      }
                      min="0"
                    />
                  </div>
                );
              }
              if (f.type === "switch") {
                return (
                  <div key={String(f.key)} className="flex items-center justify-between">
                    <Label>{f.label}</Label>
                    <Switch
                      checked={(formData as any)[f.key] || false}
                      onCheckedChange={(checked) =>
                        setFormData({ ...formData, [f.key]: checked })
                      }
                    />
                  </div>
                );
              }
              return (
                <div key={String(f.key)} className="space-y-2">
                  <Label>{f.label}</Label>
                  <Input
                    value={(formData as any)[f.key] || ""}
                    onChange={(e) =>
                      setFormData({ ...formData, [f.key]: e.target.value })
                    }
                    placeholder={f.label}
                  />
                </div>
              );
            })}

            <div className="flex gap-2 pt-2">
              <Button
                type="button"
                variant="outline"
                className="flex-1"
                onClick={() => setDialogOpen(false)}
              >
                انصراف
              </Button>
              <Button type="submit" className="flex-1" disabled={saving}>
                {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : "ذخیره"}
              </Button>
            </div>
          </form>
        </DialogContent>
      </Dialog>
    </Card>
  );
}

// ============================================================
// 📄 صفحه اصلی تنظیمات - ✅ اصلاح شده با apiClientFetch
// ============================================================

export default function SupportSettingsPage() {
  const [activeTab, setActiveTab] = useState("categories");
  const [categories, setCategories] = useState<TicketCategory[]>([]);
  const [priorities, setPriorities] = useState<TicketPriority[]>([]);
  const [statuses, setStatuses] = useState<TicketStatus[]>([]);
  const [departments, setDepartments] = useState<TicketDepartment[]>([]);
  const [labels, setLabels] = useState<TicketLabel[]>([]);
  const [loading, setLoading] = useState(true);

  const fetchAll = useCallback(async () => {
    setLoading(true);
    try {
      const [catData, priData, staData, depData, labData] = await Promise.all([
        apiClientFetch<any>("/api/support/categories/"),
        apiClientFetch<any>("/api/support/priorities/"),
        apiClientFetch<any>("/api/support/statuses/"),
        apiClientFetch<any>("/api/support/departments/"),
        apiClientFetch<any>("/api/support/labels/"),
      ]);

      setCategories(Array.isArray(catData) ? catData : catData.results || []);
      setPriorities(Array.isArray(priData) ? priData : priData.results || []);
      setStatuses(Array.isArray(staData) ? staData : staData.results || []);
      setDepartments(Array.isArray(depData) ? depData : depData.results || []);
      setLabels(Array.isArray(labData) ? labData : labData.results || []);
    } catch (error) {
      console.error("❌ خطا در دریافت تنظیمات:", error);
      toast.error("خطا در دریافت تنظیمات");
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchAll();
  }, [fetchAll]);

  const renderSection = () => {
    switch (activeTab) {
      case "categories":
        return (
          <SectionManager
            title="دسته‌بندی‌های تیکت"
            endpoint="categories"
            items={categories}
            loading={loading}
            fetchItems={fetchAll}
            fields={[
              { key: "name", label: "نام", type: "text" },
              { key: "description", label: "توضیحات", type: "text" },
              { key: "is_active", label: "فعال", type: "switch" },
            ]}
          />
        );
      case "priorities":
        return (
          <SectionManager
            title="اولویت‌های تیکت"
            endpoint="priorities"
            items={priorities}
            loading={loading}
            fetchItems={fetchAll}
            fields={[
              { key: "name", label: "نام", type: "text" },
              { key: "color", label: "رنگ", type: "color" },
              { key: "weight", label: "وزن", type: "number" },
              { key: "is_active", label: "فعال", type: "switch" },
            ]}
          />
        );
      case "statuses":
        return (
          <SectionManager
            title="وضعیت‌های تیکت"
            endpoint="statuses"
            items={statuses}
            loading={loading}
            fetchItems={fetchAll}
            fields={[
              { key: "name", label: "نام", type: "text" },
              { key: "color", label: "رنگ", type: "color" },
              { key: "is_closed", label: "بسته شده", type: "switch" },
              { key: "is_active", label: "فعال", type: "switch" },
            ]}
          />
        );
      case "departments":
        return (
          <SectionManager
            title="دپارتمان‌های تیکت"
            endpoint="departments"
            items={departments}
            loading={loading}
            fetchItems={fetchAll}
            fields={[
              { key: "name", label: "نام", type: "text" },
              { key: "description", label: "توضیحات", type: "text" },
              { key: "is_active", label: "فعال", type: "switch" },
            ]}
          />
        );
      case "labels":
        return (
          <SectionManager
            title="برچسب‌های تیکت"
            endpoint="labels"
            items={labels}
            loading={loading}
            fetchItems={fetchAll}
            fields={[
              { key: "name", label: "نام", type: "text" },
              { key: "color", label: "رنگ", type: "color" },
            ]}
          />
        );
      default:
        return null;
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center p-12">
        <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold">تنظیمات تیکت</h1>
          <p className="text-muted-foreground text-sm">
            مدیریت دسته‌بندی‌ها، اولویت‌ها، وضعیت‌ها، دپارتمان‌ها و برچسب‌های تیکت
          </p>
        </div>
        <Button variant="outline" size="icon" onClick={fetchAll} title="بروزرسانی">
          <RefreshCw className="h-4 w-4" />
        </Button>
      </div>

      <div className="flex flex-wrap gap-2 border-b pb-2">
        <Button
          variant={activeTab === "categories" ? "default" : "outline"}
          size="sm"
          onClick={() => setActiveTab("categories")}
        >
          دسته‌بندی‌ها
        </Button>
        <Button
          variant={activeTab === "priorities" ? "default" : "outline"}
          size="sm"
          onClick={() => setActiveTab("priorities")}
        >
          اولویت‌ها
        </Button>
        <Button
          variant={activeTab === "statuses" ? "default" : "outline"}
          size="sm"
          onClick={() => setActiveTab("statuses")}
        >
          وضعیت‌ها
        </Button>
        <Button
          variant={activeTab === "departments" ? "default" : "outline"}
          size="sm"
          onClick={() => setActiveTab("departments")}
        >
          دپارتمان‌ها
        </Button>
        <Button
          variant={activeTab === "labels" ? "default" : "outline"}
          size="sm"
          onClick={() => setActiveTab("labels")}
        >
          برچسب‌ها
        </Button>
      </div>

      <div className="mt-4">{renderSection()}</div>
    </div>
  );
}
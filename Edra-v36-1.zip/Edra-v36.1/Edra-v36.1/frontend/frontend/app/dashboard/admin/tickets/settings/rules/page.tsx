// app/dashboard/admin/tickets/settings/rules/page.tsx
"use client";

import React, { useState, useEffect, useCallback } from "react";
import { Plus, Pencil, Trash2, Loader2, RefreshCw } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { toast } from "sonner";
import { toPersianDigits } from "@/lib/utils";
import { apiClientFetch } from "@/lib/api-client"; // ✅ اضافه شد

interface TicketRule {
  id: number;
  name: string;
  condition_type: string;
  condition_value: string;
  action_type: string;
  action_value: string;
  is_active: boolean;
  order: number;
}

export default function RuleSettingsPage() {
  const [rules, setRules] = useState<TicketRule[]>([]);
  const [loading, setLoading] = useState(true);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingItem, setEditingItem] = useState<TicketRule | null>(null);
  const [formData, setFormData] = useState({
    name: "",
    condition_type: "keyword",
    condition_value: "",
    action_type: "assign_user",
    action_value: "",
    is_active: true,
    order: 0,
  });
  const [saving, setSaving] = useState(false);

  // ✅ اصلاح شده با apiClientFetch
  const fetchData = useCallback(async () => {
    try {
      setLoading(true);
      const data = await apiClientFetch<any>("/api/support/rules/");
      setRules(Array.isArray(data) ? data : data.results || []);
    } catch (error) {
      console.error("❌ خطا:", error);
      toast.error("خطا در دریافت داده‌ها");
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchData();
  }, [fetchData]);

  const resetForm = () => {
    setFormData({
      name: "",
      condition_type: "keyword",
      condition_value: "",
      action_type: "assign_user",
      action_value: "",
      is_active: true,
      order: 0,
    });
    setEditingItem(null);
  };

  const openAddDialog = () => {
    resetForm();
    setDialogOpen(true);
  };

  const openEditDialog = (item: TicketRule) => {
    setEditingItem(item);
    setFormData({
      name: item.name,
      condition_type: item.condition_type,
      condition_value: item.condition_value,
      action_type: item.action_type,
      action_value: item.action_value,
      is_active: item.is_active,
      order: item.order,
    });
    setDialogOpen(true);
  };

  // ✅ اصلاح شده با apiClientFetch
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name.trim()) {
      toast.error("نام قانون الزامی است.");
      return;
    }
    if (!formData.condition_value.trim()) {
      toast.error("مقدار شرط الزامی است.");
      return;
    }
    if (!formData.action_value.trim()) {
      toast.error("مقدار اقدام الزامی است.");
      return;
    }

    setSaving(true);
    try {
      const payload = {
        name: formData.name.trim(),
        condition_type: formData.condition_type,
        condition_value: formData.condition_value.trim(),
        action_type: formData.action_type,
        action_value: formData.action_value.trim(),
        is_active: formData.is_active,
        order: Number(formData.order),
      };
      const url = editingItem
        ? `/api/support/rules/${editingItem.id}/`
        : "/api/support/rules/";
      const method = editingItem ? "PUT" : "POST";

      await apiClientFetch(url, {
        method,
        body: payload,
      });

      toast.success(editingItem ? "ویرایش شد" : "افزوده شد");
      setDialogOpen(false);
      fetchData();
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "خطا در ذخیره‌سازی");
    } finally {
      setSaving(false);
    }
  };

  // ✅ اصلاح شده با apiClientFetch
  const handleDelete = async (id: number) => {
    if (!confirm("آیا از حذف این قانون مطمئن هستید؟")) return;
    try {
      await apiClientFetch(`/api/support/rules/${id}/`, {
        method: "DELETE",
      });
      toast.success("حذف شد");
      fetchData();
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "خطا در حذف");
    }
  };

  const conditionTypes = [
    { value: "category", label: "دسته‌بندی" },
    { value: "priority", label: "اولویت" },
    { value: "status", label: "وضعیت" },
    { value: "department", label: "دپارتمان" },
    { value: "keyword", label: "کلیدواژه" },
  ];
  const actionTypes = [
    { value: "assign_user", label: "اختصاص به کاربر" },
    { value: "assign_department", label: "اختصاص به دپارتمان" },
    { value: "set_priority", label: "تنظیم اولویت" },
    { value: "set_status", label: "تنظیم وضعیت" },
    { value: "add_label", label: "افزودن برچسب" },
  ];

  if (loading) {
    return (
      <div className="flex items-center justify-center p-12">
        <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold">مدیریت قوانین تیکت</h1>
          <p className="text-muted-foreground text-sm">تعریف قوانین اتوماتیک برای تیکت‌ها</p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" size="icon" onClick={fetchData}>
            <RefreshCw className="h-4 w-4" />
          </Button>
          <Button onClick={openAddDialog}>
            <Plus className="ml-1 h-4 w-4" />
            جدید
          </Button>
        </div>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>لیست قوانین</CardTitle>
          <CardDescription>{rules.length} قانون ثبت شده</CardDescription>
        </CardHeader>
        <CardContent>
          {rules.length === 0 ? (
            <p className="text-center text-muted-foreground py-4">هیچ قانون ثبت نشده است.</p>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>#</TableHead>
                  <TableHead>نام</TableHead>
                  <TableHead>نوع شرط</TableHead>
                  <TableHead>مقدار شرط</TableHead>
                  <TableHead>نوع اقدام</TableHead>
                  <TableHead>مقدار اقدام</TableHead>
                  <TableHead>ترتیب</TableHead>
                  <TableHead>وضعیت</TableHead>
                  <TableHead>عملیات</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {rules.map((item, index) => (
                  <TableRow key={item.id}>
                    <TableCell>{toPersianDigits(index + 1)}</TableCell>
                    <TableCell className="font-medium">{item.name}</TableCell>
                    <TableCell>
                      {conditionTypes.find((c) => c.value === item.condition_type)?.label || item.condition_type}
                    </TableCell>
                    <TableCell>{item.condition_value}</TableCell>
                    <TableCell>
                      {actionTypes.find((a) => a.value === item.action_type)?.label || item.action_type}
                    </TableCell>
                    <TableCell>{item.action_value}</TableCell>
                    <TableCell className="text-center">{toPersianDigits(item.order)}</TableCell>
                    <TableCell>
                      <span
                        className={`inline-flex rounded-full px-2 py-0.5 text-xs font-medium ${
                          item.is_active
                            ? "bg-green-50 text-green-700 border border-green-500"
                            : "bg-gray-50 text-gray-500 border border-gray-300"
                        }`}
                      >
                        {item.is_active ? "فعال" : "غیرفعال"}
                      </span>
                    </TableCell>
                    <TableCell>
                      <Button variant="ghost" size="sm" onClick={() => openEditDialog(item)}>
                        <Pencil className="h-3 w-3" />
                      </Button>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => handleDelete(item.id)}
                        className="text-red-500 hover:text-red-700"
                      >
                        <Trash2 className="h-3 w-3" />
                      </Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>{editingItem ? "ویرایش قانون" : "افزودن قانون جدید"}</DialogTitle>
            <DialogDescription>شرط و اقدام خودکار را تعریف کنید.</DialogDescription>
          </DialogHeader>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-2">
              <Label>نام *</Label>
              <Input
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                placeholder="مثلاً تخصیص خودکار به پشتیبانی"
                required
              />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-2">
                <Label>نوع شرط *</Label>
                <Select
                  value={formData.condition_type}
                  onValueChange={(v) => setFormData({ ...formData, condition_type: v })}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {conditionTypes.map((c) => (
                      <SelectItem key={c.value} value={c.value}>
                        {c.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label>مقدار شرط *</Label>
                <Input
                  value={formData.condition_value}
                  onChange={(e) => setFormData({ ...formData, condition_value: e.target.value })}
                  placeholder="مثلاً فنی"
                  required
                />
              </div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-2">
                <Label>نوع اقدام *</Label>
                <Select
                  value={formData.action_type}
                  onValueChange={(v) => setFormData({ ...formData, action_type: v })}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {actionTypes.map((a) => (
                      <SelectItem key={a.value} value={a.value}>
                        {a.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label>مقدار اقدام *</Label>
                <Input
                  value={formData.action_value}
                  onChange={(e) => setFormData({ ...formData, action_value: e.target.value })}
                  placeholder="مثلاً support_user"
                  required
                />
              </div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-2">
                <Label>ترتیب</Label>
                <Input
                  type="number"
                  min="0"
                  value={formData.order}
                  onChange={(e) => setFormData({ ...formData, order: Number(e.target.value) })}
                />
              </div>
              <div className="flex items-center justify-between pt-2">
                <Label>فعال</Label>
                <Switch
                  checked={formData.is_active}
                  onCheckedChange={(checked) => setFormData({ ...formData, is_active: checked })}
                />
              </div>
            </div>
            <div className="flex gap-2 pt-2">
              <Button type="button" variant="outline" className="flex-1" onClick={() => setDialogOpen(false)}>
                انصراف
              </Button>
              <Button type="submit" className="flex-1" disabled={saving}>
                {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : "ذخیره"}
              </Button>
            </div>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  );
}
// app/dashboard/admin/tickets/settings/sla/page.tsx
"use client";

import React, { useState, useEffect, useCallback } from "react";
import { Plus, Pencil, Trash2, Loader2, RefreshCw } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { toast } from "sonner";
import { toPersianDigits } from "@/lib/utils";
import { apiClientFetch } from "@/lib/api-client"; // ✅ اضافه شد

interface SLA {
  id: number;
  name: string;
  priority: { id: number; name: string } | null;
  response_time_hours: number;
  resolution_time_hours: number;
  escalation_time_hours: number;
  is_active: boolean;
}

interface TicketPriority {
  id: number;
  name: string;
}

export default function SLASettingsPage() {
  const [slas, setSlas] = useState<SLA[]>([]);
  const [priorities, setPriorities] = useState<TicketPriority[]>([]);
  const [loading, setLoading] = useState(true);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingItem, setEditingItem] = useState<SLA | null>(null);
  const [formData, setFormData] = useState({
    name: "",
    priority: "",
    response_time_hours: 2,
    resolution_time_hours: 24,
    escalation_time_hours: 48,
    is_active: true,
  });
  const [saving, setSaving] = useState(false);

  // ✅ اصلاح شده با apiClientFetch
  const fetchData = useCallback(async () => {
    try {
      setLoading(true);
      const [slasData, prioritiesData] = await Promise.all([
        apiClientFetch<any>("/api/support/slas/"),
        apiClientFetch<any>("/api/support/priorities/"),
      ]);
      setSlas(Array.isArray(slasData) ? slasData : slasData.results || []);
      setPriorities(Array.isArray(prioritiesData) ? prioritiesData : prioritiesData.results || []);
    } catch (error) {
      console.error("❌ خطا در دریافت داده‌ها:", error);
      toast.error("خطا در دریافت داده‌ها");
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchData();
  }, [fetchData]);

  const resetForm = () => {
    setFormData({
      name: "",
      priority: "",
      response_time_hours: 2,
      resolution_time_hours: 24,
      escalation_time_hours: 48,
      is_active: true,
    });
    setEditingItem(null);
  };

  const openAddDialog = () => {
    resetForm();
    setDialogOpen(true);
  };

  const openEditDialog = (item: SLA) => {
    setEditingItem(item);
    setFormData({
      name: item.name,
      priority: item.priority ? String(item.priority.id) : "",
      response_time_hours: item.response_time_hours,
      resolution_time_hours: item.resolution_time_hours,
      escalation_time_hours: item.escalation_time_hours,
      is_active: item.is_active,
    });
    setDialogOpen(true);
  };

  // ✅ اصلاح شده با apiClientFetch
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name.trim()) {
      toast.error("نام SLA الزامی است.");
      return;
    }
    if (!formData.priority) {
      toast.error("انتخاب اولویت الزامی است.");
      return;
    }

    setSaving(true);
    try {
      const payload = {
        name: formData.name.trim(),
        priority: Number(formData.priority),
        response_time_hours: Number(formData.response_time_hours),
        resolution_time_hours: Number(formData.resolution_time_hours),
        escalation_time_hours: Number(formData.escalation_time_hours),
        is_active: formData.is_active,
      };
      const url = editingItem
        ? `/api/support/slas/${editingItem.id}/`
        : "/api/support/slas/";
      const method = editingItem ? "PUT" : "POST";

      await apiClientFetch(url, {
        method,
        body: payload,
      });

      toast.success(editingItem ? "ویرایش شد" : "افزوده شد");
      setDialogOpen(false);
      fetchData();
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "خطا در ذخیره‌سازی");
    } finally {
      setSaving(false);
    }
  };

  // ✅ اصلاح شده با apiClientFetch
  const handleDelete = async (id: number) => {
    if (!confirm("آیا از حذف این SLA مطمئن هستید؟")) return;
    try {
      await apiClientFetch(`/api/support/slas/${id}/`, {
        method: "DELETE",
      });
      toast.success("حذف شد");
      fetchData();
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "خطا در حذف");
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center p-12">
        <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold">مدیریت SLA</h1>
          <p className="text-muted-foreground text-sm">تعریف و مدیریت توافقات سطح خدمات</p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" size="icon" onClick={fetchData}>
            <RefreshCw className="h-4 w-4" />
          </Button>
          <Button onClick={openAddDialog}>
            <Plus className="ml-1 h-4 w-4" />
            جدید
          </Button>
        </div>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>لیست SLAها</CardTitle>
          <CardDescription>{slas.length} مورد ثبت شده</CardDescription>
        </CardHeader>
        <CardContent>
          {slas.length === 0 ? (
            <p className="text-center text-muted-foreground py-4">هیچ SLA ثبت نشده است.</p>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>#</TableHead>
                  <TableHead>نام</TableHead>
                  <TableHead>اولویت مرتبط</TableHead>
                  <TableHead>زمان پاسخ (ساعت)</TableHead>
                  <TableHead>زمان حل (ساعت)</TableHead>
                  <TableHead>زمان ارتقا (ساعت)</TableHead>
                  <TableHead>وضعیت</TableHead>
                  <TableHead>عملیات</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {slas.map((item, index) => (
                  <TableRow key={item.id}>
                    <TableCell>{toPersianDigits(index + 1)}</TableCell>
                    <TableCell className="font-medium">{item.name}</TableCell>
                    <TableCell>{item.priority?.name || "—"}</TableCell>
                    <TableCell>{toPersianDigits(item.response_time_hours)}</TableCell>
                    <TableCell>{toPersianDigits(item.resolution_time_hours)}</TableCell>
                    <TableCell>{toPersianDigits(item.escalation_time_hours)}</TableCell>
                    <TableCell>
                      <span
                        className={`inline-flex rounded-full px-2 py-0.5 text-xs font-medium ${
                          item.is_active
                            ? "bg-green-50 text-green-700 border border-green-500"
                            : "bg-gray-50 text-gray-500 border border-gray-300"
                        }`}
                      >
                        {item.is_active ? "فعال" : "غیرفعال"}
                      </span>
                    </TableCell>
                    <TableCell>
                      <Button variant="ghost" size="sm" onClick={() => openEditDialog(item)}>
                        <Pencil className="h-3 w-3" />
                      </Button>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => handleDelete(item.id)}
                        className="text-red-500 hover:text-red-700"
                      >
                        <Trash2 className="h-3 w-3" />
                      </Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>{editingItem ? "ویرایش SLA" : "افزودن SLA جدید"}</DialogTitle>
            <DialogDescription>اطلاعات توافق سطح خدمات را وارد کنید.</DialogDescription>
          </DialogHeader>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-2">
              <Label>نام *</Label>
              <Input
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                placeholder="مثلاً SLA طلایی"
                required
              />
            </div>
            <div className="space-y-2">
              <Label>اولویت مرتبط *</Label>
              <Select value={formData.priority} onValueChange={(v) => setFormData({ ...formData, priority: v })}>
                <SelectTrigger>
                  <SelectValue placeholder="انتخاب اولویت" />
                </SelectTrigger>
                <SelectContent>
                  {priorities.map((p) => (
                    <SelectItem key={p.id} value={String(p.id)}>
                      {p.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="grid grid-cols-3 gap-3">
              <div className="space-y-2">
                <Label>زمان پاسخ (ساعت)</Label>
                <Input
                  type="number"
                  min="1"
                  value={formData.response_time_hours}
                  onChange={(e) =>
                    setFormData({ ...formData, response_time_hours: Number(e.target.value) })
                  }
                />
              </div>
              <div className="space-y-2">
                <Label>زمان حل (ساعت)</Label>
                <Input
                  type="number"
                  min="1"
                  value={formData.resolution_time_hours}
                  onChange={(e) =>
                    setFormData({ ...formData, resolution_time_hours: Number(e.target.value) })
                  }
                />
              </div>
              <div className="space-y-2">
                <Label>زمان ارتقا (ساعت)</Label>
                <Input
                  type="number"
                  min="1"
                  value={formData.escalation_time_hours}
                  onChange={(e) =>
                    setFormData({ ...formData, escalation_time_hours: Number(e.target.value) })
                  }
                />
              </div>
            </div>
            <div className="flex items-center justify-between">
              <Label>فعال</Label>
              <Switch
                checked={formData.is_active}
                onCheckedChange={(checked) => setFormData({ ...formData, is_active: checked })}
              />
            </div>
            <div className="flex gap-2 pt-2">
              <Button type="button" variant="outline" className="flex-1" onClick={() => setDialogOpen(false)}>
                انصراف
              </Button>
              <Button type="submit" className="flex-1" disabled={saving}>
                {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : "ذخیره"}
              </Button>
            </div>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  );
}
// app/dashboard/admin/tickets/settings/webhooks/page.tsx
"use client";

import React, { useState, useEffect, useCallback } from "react";
import { Plus, Pencil, Trash2, Loader2, RefreshCw } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { toast } from "sonner";
import { toPersianDigits } from "@/lib/utils";
import { apiClientFetch } from "@/lib/api-client"; // ✅ اضافه شد

interface Webhook {
  id: number;
  name: string;
  url: string;
  events: string;
  is_active: boolean;
  secret: string;
}

export default function WebhookSettingsPage() {
  const [webhooks, setWebhooks] = useState<Webhook[]>([]);
  const [loading, setLoading] = useState(true);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingItem, setEditingItem] = useState<Webhook | null>(null);
  const [formData, setFormData] = useState({
    name: "",
    url: "",
    events: "ticket_created",
    is_active: true,
    secret: "",
  });
  const [saving, setSaving] = useState(false);

  const eventOptions = [
    { value: "ticket_created", label: "تیکت ایجاد شد" },
    { value: "ticket_updated", label: "تیکت به‌روز شد" },
    { value: "ticket_closed", label: "تیکت بسته شد" },
    { value: "comment_added", label: "کامنت اضافه شد" },
  ];

  // ✅ اصلاح شده با apiClientFetch
  const fetchData = useCallback(async () => {
    try {
      setLoading(true);
      const data = await apiClientFetch<any>("/api/support/webhooks/");
      setWebhooks(Array.isArray(data) ? data : data.results || []);
    } catch (error) {
      console.error("❌ خطا:", error);
      toast.error("خطا در دریافت داده‌ها");
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchData();
  }, [fetchData]);

  const resetForm = () => {
    setFormData({
      name: "",
      url: "",
      events: "ticket_created",
      is_active: true,
      secret: "",
    });
    setEditingItem(null);
  };

  const openAddDialog = () => {
    resetForm();
    setDialogOpen(true);
  };

  const openEditDialog = (item: Webhook) => {
    setEditingItem(item);
    setFormData({
      name: item.name,
      url: item.url,
      events: item.events,
      is_active: item.is_active,
      secret: item.secret || "",
    });
    setDialogOpen(true);
  };

  // ✅ اصلاح شده با apiClientFetch
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name.trim()) {
      toast.error("نام وب‌هوک الزامی است.");
      return;
    }
    if (!formData.url.trim()) {
      toast.error("آدرس URL الزامی است.");
      return;
    }
    if (!formData.url.startsWith("https://")) {
      toast.error("آدرس URL باید با https:// شروع شود.");
      return;
    }

    setSaving(true);
    try {
      const payload = {
        name: formData.name.trim(),
        url: formData.url.trim(),
        events: formData.events,
        is_active: formData.is_active,
        secret: formData.secret.trim(),
      };
      const url = editingItem
        ? `/api/support/webhooks/${editingItem.id}/`
        : "/api/support/webhooks/";
      const method = editingItem ? "PUT" : "POST";

      await apiClientFetch(url, {
        method,
        body: payload,
      });

      toast.success(editingItem ? "ویرایش شد" : "افزوده شد");
      setDialogOpen(false);
      fetchData();
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "خطا در ذخیره‌سازی");
    } finally {
      setSaving(false);
    }
  };

  // ✅ اصلاح شده با apiClientFetch
  const handleDelete = async (id: number) => {
    if (!confirm("آیا از حذف این وب‌هوک مطمئن هستید؟")) return;
    try {
      await apiClientFetch(`/api/support/webhooks/${id}/`, {
        method: "DELETE",
      });
      toast.success("حذف شد");
      fetchData();
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "خطا در حذف");
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center p-12">
        <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold">مدیریت وب‌هوک‌ها</h1>
          <p className="text-muted-foreground text-sm">ارسال رویدادهای تیکت به سرورهای خارجی</p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" size="icon" onClick={fetchData}>
            <RefreshCw className="h-4 w-4" />
          </Button>
          <Button onClick={openAddDialog}>
            <Plus className="ml-1 h-4 w-4" />
            جدید
          </Button>
        </div>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>لیست وب‌هوک‌ها</CardTitle>
          <CardDescription>{webhooks.length} وب‌هوک ثبت شده</CardDescription>
        </CardHeader>
        <CardContent>
          {webhooks.length === 0 ? (
            <p className="text-center text-muted-foreground py-4">هیچ وب‌هوک ثبت نشده است.</p>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>#</TableHead>
                  <TableHead>نام</TableHead>
                  <TableHead>URL</TableHead>
                  <TableHead>رویداد</TableHead>
                  <TableHead>وضعیت</TableHead>
                  <TableHead>عملیات</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {webhooks.map((item, index) => (
                  <TableRow key={item.id}>
                    <TableCell>{toPersianDigits(index + 1)}</TableCell>
                    <TableCell className="font-medium">{item.name}</TableCell>
                    <TableCell className="max-w-xs truncate">{item.url}</TableCell>
                    <TableCell>
                      {eventOptions.find((e) => e.value === item.events)?.label || item.events}
                    </TableCell>
                    <TableCell>
                      <span
                        className={`inline-flex rounded-full px-2 py-0.5 text-xs font-medium ${
                          item.is_active
                            ? "bg-green-50 text-green-700 border border-green-500"
                            : "bg-gray-50 text-gray-500 border border-gray-300"
                        }`}
                      >
                        {item.is_active ? "فعال" : "غیرفعال"}
                      </span>
                    </TableCell>
                    <TableCell>
                      <Button variant="ghost" size="sm" onClick={() => openEditDialog(item)}>
                        <Pencil className="h-3 w-3" />
                      </Button>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => handleDelete(item.id)}
                        className="text-red-500 hover:text-red-700"
                      >
                        <Trash2 className="h-3 w-3" />
                      </Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>{editingItem ? "ویرایش وب‌هوک" : "افزودن وب‌هوک جدید"}</DialogTitle>
            <DialogDescription>آدرس و رویدادهای وب‌هوک را مشخص کنید.</DialogDescription>
          </DialogHeader>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-2">
              <Label>نام *</Label>
              <Input
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                placeholder="مثلاً ارسال به CRM"
                required
              />
            </div>
            <div className="space-y-2">
              <Label>آدرس URL *</Label>
              <Input
                value={formData.url}
                onChange={(e) => setFormData({ ...formData, url: e.target.value })}
                placeholder="https://example.com/webhook"
                required
              />
            </div>
            <div className="space-y-2">
              <Label>رویداد *</Label>
              <Select value={formData.events} onValueChange={(v) => setFormData({ ...formData, events: v })}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {eventOptions.map((e) => (
                    <SelectItem key={e.value} value={e.value}>
                      {e.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>کلید امنیتی (اختیاری)</Label>
              <Input
                value={formData.secret}
                onChange={(e) => setFormData({ ...formData, secret: e.target.value })}
                placeholder="یک رشته تصادفی برای احراز هویت"
              />
            </div>
            <div className="flex items-center justify-between">
              <Label>فعال</Label>
              <Switch
                checked={formData.is_active}
                onCheckedChange={(checked) => setFormData({ ...formData, is_active: checked })}
              />
            </div>
            <div className="flex gap-2 pt-2">
              <Button type="button" variant="outline" className="flex-1" onClick={() => setDialogOpen(false)}>
                انصراف
              </Button>
              <Button type="submit" className="flex-1" disabled={saving}>
                {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : "ذخیره"}
              </Button>
            </div>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  );
}
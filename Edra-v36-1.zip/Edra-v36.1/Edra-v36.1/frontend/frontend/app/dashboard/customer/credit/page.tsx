import { Wallet } from "lucide-react";
import { apiServerFetch } from "@/lib/api-server";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { formatToman } from "@/lib/format";
import { CreditTopupForm } from "./topup-form";
import { CreditTransactionsList } from "./transactions-list";

export const metadata = { title: "اعتبار من" };

interface CreditData {
  balance: number;
}

export default async function CustomerCreditPage() {
  // EDRA v27 — رفع باگ (گزارش کاربر، سپتامبر ۲۰۲۶): این endpoint برای
  // هر کاربر همیشه دقیقاً یک رکورد (موجودی خودش) برمی‌گرداند — قبلاً با
  // fetchPaginated + کنترل Pagination نمایش داده می‌شد که هم بی‌معنی
  // بود (هیچ‌وقت صفحه‌ی دومی وجود ندارد) و هم اگر کسی به‌اشتباه
  // ?page=2 را در آدرس می‌زد، درخواست به بک‌اند ۴۰۴ می‌گرفت.
  const results = await apiServerFetch<{ results?: CreditData[] } | CreditData[]>(
    `/api/core/credit/`
  );
  const list = Array.isArray(results) ? results : results.results ?? [];
  const balance = list[0]?.balance ?? 0;

  return (
    <div className="flex flex-col gap-6">
      <div>
        <h1 className="text-2xl font-semibold">اعتبار من</h1>
        <p className="text-muted-foreground text-sm">
          موجودی خود را مدیریت و در پرداخت‌های آینده استفاده کنید
        </p>
      </div>

      <Card className="border-primary/20 bg-primary/[0.03]">
        <CardContent className="flex items-center gap-4 px-6 py-6">
          <span className="bg-primary/10 text-primary flex size-14 items-center justify-center rounded-xl">
            <Wallet className="size-7" />
          </span>
          <div>
            <p className="text-muted-foreground text-xs">موجودی فعلی</p>
            <p className="text-2xl font-bold">{formatToman(balance)}</p>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="text-base">افزایش اعتبار</CardTitle>
        </CardHeader>
        <CardContent>
          <CreditTopupForm />
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="text-base">تاریخچه تراکنش‌ها</CardTitle>
        </CardHeader>
        <CardContent>
          <CreditTransactionsList />
        </CardContent>
      </Card>
    </div>
  );
}

"use client";

import * as React from "react";
import { useQuery } from "@tanstack/react-query";
import { ArrowDownLeft, ArrowUpRight } from "lucide-react";
import { formatToman } from "@/lib/format";
import { PaginationClient } from "@/components/ui/pagination";

interface CreditTransaction {
  id: number;
  amount: number;
  transaction_type: string;
  description: string;
  created_at_jalali: string;
}

async function fetchTransactions(
  page: number
): Promise<{ rows: CreditTransaction[]; count: number }> {
  const res = await fetch(
    `/api/proxy/core/credit-transactions/?page=${page}`
  );
  const data = await res.json();
  const rows = (data.results ?? data) as CreditTransaction[];
  return {
    rows,
    count: typeof data.count === "number" ? data.count : rows.length,
  };
}

export function CreditTransactionsList() {
  const [page, setPage] = React.useState(1);
  const { data, isLoading } = useQuery({
    queryKey: ["credit-transactions", page],
    queryFn: () => fetchTransactions(page),
  });

  if (isLoading) {
    return <p className="text-muted-foreground py-6 text-center text-sm">در حال بارگذاری...</p>;
  }
  if (!data?.rows?.length) {
    return (
      <p className="text-muted-foreground py-6 text-center text-sm">
        تراکنشی ثبت نشده است
      </p>
    );
  }

  return (
    <div className="flex flex-col divide-y">
      {data.rows.map((tx) => {
        const isDeposit = tx.transaction_type === "deposit";
        return (
          <div key={tx.id} className="flex items-center justify-between py-2.5">
            <div className="flex items-center gap-2.5">
              <span
                className={`flex size-8 items-center justify-center rounded-full ${
                  isDeposit ? "bg-success/10 text-success" : "bg-destructive/10 text-destructive"
                }`}
              >
                {isDeposit ? (
                  <ArrowDownLeft className="size-4" />
                ) : (
                  <ArrowUpRight className="size-4" />
                )}
              </span>
              <div>
                <p className="text-sm">{tx.description || (isDeposit ? "واریز" : "برداشت")}</p>
                <p className="text-muted-foreground text-xs">{tx.created_at_jalali}</p>
              </div>
            </div>
            <span className={`text-sm font-medium ${isDeposit ? "text-success" : ""}`}>
              {isDeposit ? "+" : "-"} {formatToman(tx.amount)}
            </span>
          </div>
        );
      })}
      <PaginationClient
        current={page}
        totalItems={data?.count ?? 0}
        onPageChange={setPage}
      />
    </div>
  );
}

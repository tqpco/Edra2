import Link from "next/link";
import { FileDown, ChevronLeft } from "lucide-react";
import { fetchPaginated } from "@/lib/paginated-fetch";
import { Pagination } from "@/components/ui/pagination";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { formatToman } from "@/lib/format";

export const metadata = { title: "فاکتورهای من" };

interface InvoiceItem {
  id: number;
  invoice_number: string;
  final_amount: number;
  final_rial: number | null;
  is_paid: boolean;
  status: string;
  pdf_file: string | null;
  issue_date_jalali: string;
  due_date_jalali: string;
}

async function fetchInvoices(page: number) {
  return fetchPaginated<InvoiceItem>(`/api/core/invoices/?ordering=-issue_date`, page);
}

export default async function CustomerInvoicesPage({ searchParams }: { searchParams: Promise<{ page?: string }> }) {
  const _page = Math.max(1, Number((await searchParams).page) || 1);
  const { items: invoices, count } = await fetchInvoices(_page);

  return (
    <div className="flex flex-col gap-6">
      <div>
        <h1 className="text-2xl font-semibold">فاکتورهای من</h1>
        <p className="text-muted-foreground text-sm">
          فاکتورهای صادرشده بابت درخواست‌های بازرسی شما
        </p>
      </div>

      <Card>
        <CardContent className="px-0 py-2">
          {invoices.length === 0 ? (
            <p className="text-muted-foreground py-10 text-center text-sm">
              فاکتوری صادر نشده است
            </p>
          ) : (
            <div className="flex flex-col divide-y">
              {invoices.map((inv) => (
                <div
                  key={inv.id}
                  className="relative flex items-center justify-between gap-3 px-5 py-4 transition-colors hover:bg-muted/50"
                >
                  {/* لینک کشیده روی کل ردیف؛ دکمه‌ی PDF با z-10 بالای آن است (بدون آنکور تو‌در‌تو) */}
                  <Link
                    href={`/dashboard/customer/invoices/${inv.id}`}
                    className="absolute inset-0"
                    aria-label={`مشاهده فاکتور ${inv.invoice_number}`}
                  />
                  <div className="min-w-0">
                    <div className="flex items-center gap-2">
                      <p className="font-mono text-sm font-medium">{inv.invoice_number}</p>
                      {inv.is_paid ? (
                        <Badge variant="success">پرداخت شده</Badge>
                      ) : (
                        <Badge variant="warning">پرداخت نشده</Badge>
                      )}
                    </div>
                    <p className="text-muted-foreground mt-1 text-xs">
                      {inv.issue_date_jalali} • سررسید: {inv.due_date_jalali}
                    </p>
                  </div>
                  <div className="flex shrink-0 items-center gap-2">
                    <span className="text-sm font-semibold">
                      {formatToman(inv.final_amount)}
                    </span>
                    {inv.pdf_file && (
                      <Button size="icon" variant="ghost" className="relative z-10 size-8" asChild>
                        <a
                          href={`/api/download/core/invoices/${inv.id}/pdf/`}
                          target="_blank"
                          rel="noreferrer"
                          title="دانلود PDF"
                        >
                          <FileDown className="size-4" />
                        </a>
                      </Button>
                    )}
                    <ChevronLeft className="text-muted-foreground size-4" />
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
          <Pagination current={_page} totalItems={count} basePath="/dashboard/customer/invoices" />
</div>
  );
}

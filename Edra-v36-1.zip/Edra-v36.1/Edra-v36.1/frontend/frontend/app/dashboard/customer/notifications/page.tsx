"use client";

import { NotificationInbox } from "@/components/shared/notification-inbox";

export default function CustomerNotificationsPage() {
  return <NotificationInbox />;
}

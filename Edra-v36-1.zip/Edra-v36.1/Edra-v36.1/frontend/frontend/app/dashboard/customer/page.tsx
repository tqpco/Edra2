// app/dashboard/customer/page.tsx
"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import {
  ClipboardList,
  Clock,
  FileCheck,
  Wallet,
  PlusCircle,
  MapPin,
  CalendarClock,
  ArrowLeft,
  Loader2,
} from "lucide-react";

import type { CustomerDashboardData } from "@/types/dashboard";
import { StatCard } from "@/components/shared/stat-card";
import { Card, CardHeader, CardTitle, CardContent, CardAction } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { getStatusInfo, REQUEST_STATUS_MAP } from "@/lib/status-map";
import { formatToman } from "@/lib/format";
import { toPersianDigits } from "@/lib/jalali";

export default function CustomerDashboardPage() {
  const router = useRouter();
  const [data, setData] = useState<CustomerDashboardData | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchData = async () => {
      try {
        setLoading(true);
        // استفاده از fetch مستقیم با credentials: "include" برای ارسال کوکی
        const res = await fetch("/api/proxy/core/customer/dashboard/", {
          credentials: "include",
        });

        if (res.status === 401) {
          router.push("/customer-login?next=/dashboard/customer");
          return;
        }

        if (!res.ok) {
          throw new Error(`API error ${res.status}`);
        }

        const result = await res.json();
        setData(result);
        setError(null);
      } catch (err) {
        setError("خطا در دریافت اطلاعات داشبورد. لطفاً بعداً تلاش کنید.");
        console.error("Dashboard error:", err);
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, [router]);

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[60vh]">
        <Loader2 className="size-8 animate-spin text-muted-foreground" />
      </div>
    );
  }

  if (error || !data) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[60vh] gap-4">
        <p className="text-muted-foreground">{error || "داده‌ای موجود نیست"}</p>
        <Button asChild>
          <Link href="/customer-login">ورود به حساب کاربری</Link>
        </Button>
      </div>
    );
  }

  return (
    <div className="flex flex-col gap-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="text-2xl font-semibold">
            سلام {data.user.full_name} 👋
          </h1>
          <p className="text-muted-foreground text-sm">
            خلاصه‌ی وضعیت درخواست‌های بازرسی شما
          </p>
        </div>
        <Button asChild>
          <Link href="/booking?fresh=1">
            <PlusCircle />
            رزرو بازرسی جدید
          </Link>
        </Button>
      </div>

      <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
        <StatCard
          title="کل درخواست‌ها"
          value={toPersianDigits(data.total_requests)}
          icon={ClipboardList}
          tone="default"
        />
        <StatCard
          title="درخواست‌های فعال"
          value={toPersianDigits(data.active_requests)}
          icon={Clock}
          tone="primary"
        />
        <StatCard
          title="گزارش‌های آماده"
          value={toPersianDigits(data.approved_reports)}
          icon={FileCheck}
          tone="success"
        />
        <StatCard
          title="موجودی اعتبار"
          value={formatToman(data.credit)}
          icon={Wallet}
          tone="warning"
        />
      </div>

      {data.next_inspection && (
        <Card className="border-primary/30 bg-primary/[0.03]">
          <CardContent className="flex flex-wrap items-center gap-4 px-5 py-4">
            <span className="flex size-11 shrink-0 items-center justify-center rounded-lg bg-primary/10 text-primary">
              <CalendarClock className="size-5" />
            </span>
            <div className="flex-1">
              <p className="text-sm font-medium">
                نزدیک‌ترین کارشناسی: درخواست {toPersianDigits(data.next_inspection.request_number)}
              </p>
              <p className="text-muted-foreground flex flex-wrap items-center gap-x-4 gap-y-1 text-xs">
                <span className="inline-flex items-center gap-1">
                  <CalendarClock className="size-3.5" />
                  {data.next_inspection.scheduled_at_jalali}
                </span>
                <span className="inline-flex items-center gap-1">
                  <MapPin className="size-3.5" />
                  {data.next_inspection.address}
                </span>
              </p>
            </div>
            <Button variant="outline" size="sm" asChild>
              <Link href={`/dashboard/customer/requests/${data.next_inspection.id}`}>
                جزئیات
              </Link>
            </Button>
          </CardContent>
        </Card>
      )}

      <Card>
        <CardHeader>
          <CardTitle>درخواست‌های اخیر</CardTitle>
          <CardAction>
            <Button variant="ghost" size="sm" asChild>
              <Link href="/dashboard/customer/requests">
                مشاهده همه
                <ArrowLeft className="size-3.5" />
              </Link>
            </Button>
          </CardAction>
        </CardHeader>
        <CardContent>
          {data.recent_requests.length === 0 ? (
            <div className="text-muted-foreground flex flex-col items-center gap-3 py-10 text-center text-sm">
              <ClipboardList className="size-8 opacity-40" />
              هنوز درخواستی ثبت نکرده‌اید
              <Button size="sm" asChild>
                <Link href="/booking?fresh=1">شروع اولین رزرو</Link>
              </Button>
            </div>
          ) : (
            <div className="flex flex-col divide-y">
              {data.recent_requests.map((r) => {
                const status = getStatusInfo(REQUEST_STATUS_MAP, r.status);
                return (
                  <Link
                    key={r.id}
                    href={`/dashboard/customer/requests/${r.id}`}
                    className="hover:bg-accent -mx-2 flex items-center justify-between gap-3 rounded-md px-2 py-3"
                  >
                    <div className="flex flex-col gap-0.5">
                      <span className="text-sm font-medium">
                        {r.equipment || "—"} · {toPersianDigits(r.request_number)}
                      </span>
                      <span className="text-muted-foreground text-xs">
                        {r.created_at_jalali}
                      </span>
                    </div>
                    <div className="flex items-center gap-3">
                      <span className="text-sm font-medium">
                        {formatToman(r.final_price)}
                      </span>
                      <Badge variant={status.variant}>{status.label}</Badge>
                    </div>
                  </Link>
                );
              })}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
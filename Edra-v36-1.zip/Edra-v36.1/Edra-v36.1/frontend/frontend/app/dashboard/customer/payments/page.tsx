import Link from "next/link";
import { Receipt, FileDown, ChevronLeft } from "lucide-react";
import { apiServerFetch } from "@/lib/api-server";
import { fetchPaginated } from "@/lib/paginated-fetch";
import { Pagination } from "@/components/ui/pagination";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { getStatusInfo, PAYMENT_STATUS_MAP } from "@/lib/status-map";
import { formatToman } from "@/lib/format";

export const metadata = { title: "پرداخت‌ها و فاکتورها" };

interface PaymentItem {
  id: number;
  amount: number;
  status: string;
  created_at_jalali: string;
}
interface InvoiceItem {
  id: number;
  invoice_number: string;
  final_amount: number;
  pdf_file: string | null;
  issue_date_jalali: string;
}

async function fetchList<T>(
  path: string,
  page: number
): Promise<{ items: T[]; count: number }> {
  try {
    const data = await apiServerFetch<{ count: number; results: T[] } | T[]>(
      `${path}${path.includes("?") ? "&" : "?"}page=${page}`
    );
    return Array.isArray(data)
      ? { items: data, count: data.length }
      : { items: data.results ?? [], count: data.count ?? 0 };
  } catch {
    return { items: [], count: 0 };
  }
}

export default async function CustomerPaymentsPage({ searchParams }: { searchParams: Promise<{ page?: string }> }) {
  const _page = Math.max(1, Number((await searchParams).page) || 1);
  const [payments, invoices] = await Promise.all([
    fetchList<PaymentItem>("/api/core/payments/", _page),
    fetchList<InvoiceItem>("/api/core/invoices/", _page),
  ]);

  return (
    <div className="flex flex-col gap-6">
      <div>
        <h1 className="text-2xl font-semibold">پرداخت‌ها و فاکتورها</h1>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="text-base">فاکتورها</CardTitle>
        </CardHeader>
        <CardContent>
          {invoices.items.length === 0 ? (
            <p className="text-muted-foreground py-6 text-center text-sm">
              فاکتوری صادر نشده است
            </p>
          ) : (
            <div className="flex flex-col divide-y">
              {invoices.items.map((inv) => (
                <div
                  key={inv.id}
                  className="relative flex items-center justify-between py-3 transition-colors hover:bg-muted/40"
                >
                  {/* لینک کشیده روی کل ردیف؛ دکمه‌ی PDF با z-10 بالای آن است (بدون آنکور تو‌در‌تو) */}
                  <Link
                    href={`/dashboard/customer/invoices/${inv.id}`}
                    className="absolute inset-0"
                    aria-label={`مشاهده فاکتور ${inv.invoice_number}`}
                  />
                  <div>
                    <p className="text-sm font-medium">فاکتور {inv.invoice_number}</p>
                    <p className="text-muted-foreground text-xs">{inv.issue_date_jalali}</p>
                  </div>
                  <div className="flex items-center gap-3">
                    <span className="text-sm font-medium">
                      {formatToman(inv.final_amount)}
                    </span>
                    {inv.pdf_file && (
                      <Button size="sm" variant="ghost" className="relative z-10" asChild>
                        <a
                          href={`/api/download/core/invoices/${inv.id}/pdf/`}
                          target="_blank"
                          rel="noreferrer"
                        >
                          <FileDown className="size-4" />
                        </a>
                      </Button>
                    )}
                    <ChevronLeft className="text-muted-foreground size-4" />
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="text-base">تاریخچه پرداخت‌ها</CardTitle>
        </CardHeader>
        <CardContent>
          {payments.items.length === 0 ? (
            <p className="text-muted-foreground py-6 text-center text-sm">
              <Receipt className="mx-auto mb-2 size-8 opacity-40" />
              پرداختی ثبت نشده است
            </p>
          ) : (
            <div className="flex flex-col divide-y">
              {payments.items.map((p) => {
                const status = getStatusInfo(PAYMENT_STATUS_MAP, p.status);
                return (
                  <div key={p.id} className="flex items-center justify-between py-3">
                    <span className="text-muted-foreground text-xs">
                      {p.created_at_jalali}
                    </span>
                    <div className="flex items-center gap-3">
                      <span className="text-sm font-medium">{formatToman(p.amount)}</span>
                      <Badge variant={status.variant}>{status.label}</Badge>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </CardContent>
      </Card>
          <Pagination current={_page} totalItems={payments.count} basePath="/dashboard/customer/payments" />
</div>
  );
}

import { FileCheck2, FileDown } from "lucide-react";
import { fetchPaginated } from "@/lib/paginated-fetch";
import { Pagination } from "@/components/ui/pagination";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { toPersianDigits } from "@/lib/jalali";
import { getStatusInfo, REPORT_RESULT_MAP } from "@/lib/status-map";

export const metadata = { title: "گزارش‌های بازرسی" };

interface ReportItem {
  id: number;
  report_number: string;
  overall_result: string;
  pdf_file: string | null;
  pdf_ready?: boolean;
  created_at_jalali: string;
}

export default async function CustomerReportsPage({ searchParams }: { searchParams: Promise<{ page?: string }> }) {
  const _page = Math.max(1, Number((await searchParams).page) || 1);
  const { items: reports, count } = await fetchPaginated<ReportItem>(`/api/core/customer/reports/?page=${_page}`, _page);

  return (
    <div className="flex flex-col gap-6">
      <div>
        <h1 className="text-2xl font-semibold">گزارش‌های بازرسی</h1>
        <p className="text-muted-foreground text-sm">
          {/* EDRA v32: قبلاً reports.length بود (فقط همین صفحه، حداکثر ۲۵)؛
              برای مشتری با بیش از ۲۵ گزارش همیشه «۲۵» نشان داده می‌شد. */}
          {toPersianDigits(count)} گزارش صادرشده
        </p>
      </div>

      {reports.length === 0 ? (
        <Card>
          <CardContent className="text-muted-foreground flex flex-col items-center gap-3 py-16 text-center">
            <FileCheck2 className="size-10 opacity-40" />
            هنوز گزارشی برای شما صادر نشده است
          </CardContent>
        </Card>
      ) : (
        <div className="flex flex-col gap-3">
          {reports.map((r) => (
            <Card key={r.id}>
              <CardContent className="flex flex-wrap items-center justify-between gap-3 px-5 py-4">
                <div className="flex items-center gap-3">
                  <Badge variant={getStatusInfo(REPORT_RESULT_MAP, r.overall_result).variant}>
                    {getStatusInfo(REPORT_RESULT_MAP, r.overall_result).label}
                  </Badge>
                  <div>
                    <p className="text-sm font-medium">
                      گزارش {toPersianDigits(r.report_number)}
                    </p>
                    <p className="text-muted-foreground text-xs">{r.created_at_jalali}</p>
                  </div>
                </div>
                {!(r.pdf_ready ?? !!r.pdf_file) && (
                  <span className="text-muted-foreground text-xs">
                    فایل PDF در حال آماده‌سازی است
                  </span>
                )}
                {(r.pdf_ready ?? !!r.pdf_file) && (
                  <Button size="sm" variant="outline" asChild>
                    <a
                      href={`/api/download/inspections/inspection-reports/${r.id}/pdf/`}
                      target="_blank"
                      rel="noreferrer"
                    >
                      <FileDown />
                      دانلود PDF
                    </a>
                  </Button>
                )}
              </CardContent>
            </Card>
          ))}
        </div>
      )}
          <Pagination current={_page} totalItems={count} basePath="/dashboard/customer/reports" />
</div>
  );
}

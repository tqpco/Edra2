import { CalendarDays, MapPin, Wrench, ChevronRight, ChevronLeft } from "lucide-react";
import Link from "next/link";
import { apiServerFetch } from "@/lib/api-server";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { getStatusInfo, REQUEST_STATUS_MAP } from "@/lib/status-map";
import {
  dateToJalali,
  formatJalali,
  JALALI_MONTH_NAMES,
  jalaliMonthLength,
  jalaliToDate,
} from "@/lib/jalali";

export const metadata = { title: "تقویم برنامه بازرسی" };

interface RequestItem {
  id: number;
  request_number?: string;
  equipment_type_name?: string;
  customer_name?: string;
  city?: string;
  address?: string;
  status: string;
  scheduled_at?: string | null;
  scheduled_at_jalali?: string | null;
}

const SCHEDULED_STATUSES = new Set([
  "scheduled",
  "rescheduled",
  "assigned",
  "in_progress",
  "paid",
]);

// EDRA v27 — رفع باگ ریشه‌ای (گزارش کاربر، سپتامبر ۲۰۲۶): این صفحه قبلاً
// با pagination عمومی (۲۵تایی، مرتب بر اساس scheduled_at) کار می‌کرد و
// روی همان یک صفحه فیلتر «همین ماه» را در فرانت اعمال می‌کرد — برای
// کارشناسی با بیش از ۲۵ درخواست در کل تاریخچه، بازرسی‌های واقعی همین
// ماه ممکن بود اصلاً در آن صفحه نباشند و تقویم ناقص/گمراه‌کننده نمایش
// داده شود. حالا مستقیماً بازه‌ی گرگوری همان ماه جلالی را از بک‌اند
// می‌خواهد (فیلتر scheduled_at_after/before که در همین نشست اضافه شد)
// و به‌جای صفحه‌بندی عمومی، ناوبری «ماه قبل/بعد» دارد که برای یک تقویم
// معنادار است.
function toIsoDate(d: Date): string {
  // از .toISOString() استفاده نمی‌کنیم چون به UTC تبدیل می‌کند و می‌تواند
  // بسته به timezone سرور، تاریخ را یک روز جابه‌جا کند.
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, "0");
  const day = String(d.getDate()).padStart(2, "0");
  return `${y}-${m}-${day}`;
}

async function fetchMonthRequests(jy: number, jm: number) {
  const monthStart = jalaliToDate(jy, jm, 1);
  const nextJy = jm === 12 ? jy + 1 : jy;
  const nextJm = jm === 12 ? 1 : jm + 1;
  const nextMonthStart = jalaliToDate(nextJy, nextJm, 1);
  const data = await apiServerFetch<{ results: RequestItem[] } | RequestItem[]>(
    `/api/core/inspection-requests/?ordering=scheduled_at&page_size=200` +
      `&scheduled_at_after=${toIsoDate(monthStart)}&scheduled_at_before=${toIsoDate(nextMonthStart)}`
  );
  return Array.isArray(data) ? data : data.results ?? [];
}

export default async function ExpertCalendarPage({
  searchParams,
}: {
  searchParams: Promise<{ month?: string }>;
}) {
  const now = new Date();
  const todayJalali = dateToJalali(now);

  const monthParam = (await searchParams).month; // فرمت مورد انتظار: "1404-07"
  let jy = todayJalali.year;
  let jm = todayJalali.month;
  if (monthParam && /^\d{4}-\d{2}$/.test(monthParam)) {
    const [y, m] = monthParam.split("-").map(Number);
    if (m! >= 1 && m! <= 12) {
      jy = y!;
      jm = m!;
    }
  }

  const monthDays = jalaliMonthLength(jy, jm);
  const requests = await fetchMonthRequests(jy, jm);

  const isCurrentMonth = jy === todayJalali.year && jm === todayJalali.month;
  const prevJm = jm === 1 ? 12 : jm - 1;
  const prevJy = jm === 1 ? jy - 1 : jy;
  const nextJm = jm === 12 ? 1 : jm + 1;
  const nextJy = jm === 12 ? jy + 1 : jy;

  const scheduled = requests.filter(
    (r) => SCHEDULED_STATUSES.has(r.status) && r.scheduled_at
  );
  const daysWithRequests = new Map<number, RequestItem[]>();
  for (const r of scheduled) {
    try {
      const d = new Date(r.scheduled_at!);
      const j = dateToJalali(d);
      if (j.year === jy && j.month === jm) {
        const list = daysWithRequests.get(j.day) ?? [];
        list.push(r);
        daysWithRequests.set(j.day, list);
      }
    } catch {
      // تاریخ نامعتبر - رد می‌شود
    }
  }

  const grouped = scheduled.reduce<Record<string, RequestItem[]>>((acc, r) => {
    const key = r.scheduled_at_jalali?.slice(0, 10) ?? "نامشخص";
    (acc[key] ||= []).push(r);
    return acc;
  }, {});

  return (
    <div className="flex flex-col gap-6">
      <div>
        <h1 className="text-2xl font-semibold">تقویم برنامه بازرسی</h1>
        <p className="text-muted-foreground text-sm">
          {formatJalali(now)} — بازرسی‌های زمان‌بندی‌شده شما
        </p>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center justify-between text-base">
            <Button variant="ghost" size="icon" asChild>
              <Link href={`?month=${nextJy}-${String(nextJm).padStart(2, "0")}`} title="ماه بعد">
                <ChevronRight className="size-4" />
              </Link>
            </Button>
            <span className="flex items-center gap-2">
              <CalendarDays className="size-5" />
              {JALALI_MONTH_NAMES[jm - 1]} {toFa(jy)}
              {!isCurrentMonth && (
                <Link href="." className="text-primary text-xs font-normal underline">
                  برگشت به ماه جاری
                </Link>
              )}
            </span>
            <Button variant="ghost" size="icon" asChild>
              <Link href={`?month=${prevJy}-${String(prevJm).padStart(2, "0")}`} title="ماه قبل">
                <ChevronLeft className="size-4" />
              </Link>
            </Button>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-7 gap-1 text-center">
            {["ش", "ی", "د", "س", "چ", "پ", "ج"].map((d, i) => (
              <div key={i} className="text-muted-foreground py-1 text-xs font-medium">
                {d}
              </div>
            ))}
            {Array.from({ length: monthDays }, (_, i) => i + 1).map((day) => {
              const items = daysWithRequests.get(day) ?? [];
              const isToday = isCurrentMonth && day === todayJalali.day;
              const hasItems = items.length > 0;
              return (
                <div
                  key={day}
                  className={`relative flex min-h-16 flex-col items-center justify-start gap-1 rounded-lg border p-1 ${
                    isToday ? "border-primary bg-primary/5" : "border-border/60"
                  }`}
                >
                  <span
                    className={`text-xs ${isToday ? "text-primary font-bold" : "text-muted-foreground"}`}
                  >
                    {toFa(day)}
                  </span>
                  {hasItems && (
                    <span className="flex flex-col gap-0.5">
                      {items.slice(0, 2).map((r) => (
                        <span key={r.id} className="bg-primary/10 text-primary rounded px-1 py-0.5 text-[9px]">
                          #{r.id}
                        </span>
                      ))}
                      {items.length > 2 && (
                        <span className="text-muted-foreground text-[9px]">
                          +{toFa(items.length - 2)}
                        </span>
                      )}
                    </span>
                  )}
                </div>
              );
            })}
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="text-base">بازرسی‌های زمان‌بندی‌شده</CardTitle>
        </CardHeader>
        <CardContent className="px-0 py-2">
          {Object.keys(grouped).length === 0 ? (
            <p className="text-muted-foreground py-10 text-center text-sm">
              بازرسی زمان‌بندی‌شده‌ای در این ماه ندارید
            </p>
          ) : (
            <div className="flex flex-col divide-y">
              {Object.entries(grouped).sort().map(([date, items]) => (
                <div key={date} className="px-5 py-3">
                  <p className="text-muted-foreground mb-2 text-xs font-medium">{date}</p>
                  <div className="flex flex-col gap-2">
                    {items.map((r) => {
                      const status = getStatusInfo(REQUEST_STATUS_MAP, r.status);
                      return (
                        <div
                          key={r.id}
                          className="flex flex-wrap items-center justify-between gap-2 rounded-lg border p-3"
                        >
                          <div className="min-w-0">
                            <div className="flex items-center gap-2">
                              <span className="text-sm font-semibold">درخواست #{r.id}</span>
                              <Badge variant={status.variant}>{status.label}</Badge>
                            </div>
                            <p className="text-muted-foreground mt-1 flex items-center gap-1 text-xs">
                              <Wrench className="size-3" />
                              {r.equipment_type_name ?? "—"} • {r.customer_name ?? ""}
                            </p>
                            <p className="text-muted-foreground mt-0.5 flex items-center gap-1 text-xs">
                              <MapPin className="size-3" />
                              {r.city ?? ""} — {r.address ?? ""}
                            </p>
                          </div>
                          <span className="text-muted-foreground shrink-0 text-xs">
                            {r.scheduled_at_jalali ?? ""}
                          </span>
                        </div>
                      );
                    })}
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}

function toFa(n: number): string {
  return new Intl.NumberFormat("fa-IR").format(n);
}

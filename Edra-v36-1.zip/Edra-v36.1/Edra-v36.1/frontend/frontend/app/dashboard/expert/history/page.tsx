import { History } from "lucide-react";
import { apiServerFetch } from "@/lib/api-server";
import { fetchPaginated } from "@/lib/paginated-fetch";
import { Pagination } from "@/components/ui/pagination";
import { ExpertTaskCard } from "@/components/shared/expert-task-card";
import type { ExpertTask } from "@/types/dashboard";
import { toPersianDigits } from "@/lib/jalali";

export const metadata = { title: "تاریخچه گزارش‌ها" };

const PAGE_SIZE = 50;

interface HistoryResponse {
  history: {
    id: number;
    request_number: string;
    equipment_name: string;
    status: string;
    city: string;
    address: string;
  }[];
  total: number;
}

export default async function ExpertHistoryPage({ searchParams }: { searchParams: Promise<{ page?: string }> }) {
  const _page = Math.max(1, Number((await searchParams).page) || 1);
  const data = await apiServerFetch<HistoryResponse>(
    // بک‌اند با limit/offset کار می‌کند (پارامتر page را نمی‌شناسد؛ قبلاً
    // همه‌ی صفحه‌ها همان ۵۰ مورد اول را نشان می‌دادند).
    `/api/expert/history/?limit=${PAGE_SIZE}&offset=${(_page - 1) * PAGE_SIZE}`
  );

  const tasks: ExpertTask[] = data.history.map((t) => ({
    id: t.id,
    request_number: t.request_number,
    equipment: t.equipment_name,
    status: t.status,
    scheduled_at_jalali: null,
    address: t.address,
    city: t.city,
  }));
  // EDRA v27 — رفع باگ واقعی (گزارش کاربر، سپتامبر ۲۰۲۶): این کد دنبال
  // فیلد "count" می‌گشت که اصلاً در پاسخ این endpoint وجود ندارد (فیلد
  // واقعی "total" است — همان‌طور که در تایپ HistoryResponse هم تعریف
  // شده و چند خط پایین‌تر مستقیماً استفاده می‌شود). نتیجه: همیشه به
  // tasks.length (حداکثر ۵۰، یعنی فقط همین صفحه) سقوط می‌کرد، پس
  // Pagination همیشه فکر می‌کرد فقط ۱ صفحه وجود دارد — کارشناسی با
  // بیش از ۵۰ بازرسی تکمیل‌شده هرگز نمی‌توانست به صفحات قدیمی‌تر برسد.
  const count = data.total;

  return (
    <div className="flex flex-col gap-6">
      <div>
        <h1 className="text-2xl font-semibold">تاریخچه گزارش‌ها</h1>
        <p className="text-muted-foreground text-sm">
          {toPersianDigits(data.total)} بازرسی تکمیل‌شده
        </p>
      </div>

      {tasks.length === 0 ? (
        <div className="text-muted-foreground flex flex-col items-center gap-3 rounded-xl border border-dashed py-16 text-center">
          <History className="size-10 opacity-40" />
          هنوز بازرسی تکمیل‌شده‌ای ندارید
        </div>
      ) : (
        <div className="flex flex-col gap-3">
          {tasks.map((task) => (
            <ExpertTaskCard key={task.id} task={task} />
          ))}
        </div>
      )}
          <Pagination current={_page} totalItems={count} pageSize={PAGE_SIZE} basePath="/dashboard/expert/history" />
</div>
  );
}

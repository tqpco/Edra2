"use client";

import { NotificationInbox } from "@/components/shared/notification-inbox";

export default function ExpertNotificationsPage() {
  return <NotificationInbox />;
}

"use client";

import * as React from "react";
import { useRouter } from "next/navigation";
import {
  CheckCircle2,
  XCircle,
  MinusCircle,
  Camera,
  MapPin,
  Loader2,
  Send,
  Trash2,
} from "lucide-react";

import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";
import { compressImage } from "@/lib/image-compress";
import type { ChecklistTemplateData, ItemResult, ChecklistAnswer } from "@/types/checklist";

type Coords = { lat: number; lng: number } | null;

function useGeolocation() {
  const [coords, setCoords] = React.useState<Coords>(null);
  const [status, setStatus] = React.useState<"idle" | "loading" | "done" | "error">("idle");

  // EDRA v27 — رفع باگ امنیتی/ضد-تقلب واقعی (گزارش کاربر، سپتامبر
  // ۲۰۲۶): capture() یک تماس ناهمگام (callback مرورگر) است. کد قبلی
  // در handleSubmit بلافاصله بعد از صدا زدن capture()، مقدار
  // endGps.coords را (از همان render فعلی، قبل از پایان callback) در
  // FormData می‌گذاشت — یعنی همیشه null بود (چون state هنوز آپدیت
  // نشده بود) مگر در حالت‌های نادر race condition. نتیجه‌ی واقعی:
  // مختصات GPS پایان بازرسی عملاً هیچ‌وقت ارسال نمی‌شد و بررسی ضد-تقلب
  // سمت سرور برای «پایان بازرسی» همیشه بدون داده اجرا می‌شد. حالا
  // capture() یک Promise برمی‌گرداند که handleSubmit واقعاً await
  // می‌کند.
  const capture = React.useCallback((): Promise<Coords> => {
    return new Promise((resolve) => {
      if (!navigator.geolocation) {
        setStatus("error");
        resolve(null);
        return;
      }
      setStatus("loading");
      navigator.geolocation.getCurrentPosition(
        (pos) => {
          const next = { lat: pos.coords.latitude, lng: pos.coords.longitude };
          setCoords(next);
          setStatus("done");
          resolve(next);
        },
        () => {
          setStatus("error");
          resolve(null);
        },
        { enableHighAccuracy: true, timeout: 15000 }
      );
    });
  }, []);

  return { coords, status, capture };
}

export function ChecklistForm({
  taskId,
  template,
  gpsEnabled = false,
}: {
  taskId: number;
  template: ChecklistTemplateData;
  gpsEnabled?: boolean;
  addressLat: number | null;
  addressLng: number | null;
}) {
  const router = useRouter();
  const startGps = useGeolocation();
  const endGps = useGeolocation();
  const [startedAt] = React.useState(() => new Date().toISOString());

  const [answers, setAnswers] = React.useState<Record<number, ChecklistAnswer>>(() => {
    // EDRA v5 — CRITICAL-07: پیش‌فرض «بدون پاسخ» است؛ هیچ آیتمی خودکار
    // PASS نمی‌شود (کارشناس باید هر آیتم را صریح بررسی کند).
    const init: Record<number, ChecklistAnswer> = {};
    for (const item of template.items) {
      init[item.id] = { result: null, note: "", photos: [] };
    }
    return init;
  });
  const [inspectorNotes, setInspectorNotes] = React.useState("");
  const [submitting, setSubmitting] = React.useState(false);
  const [error, setError] = React.useState<string | null>(null);

  React.useEffect(() => {
    // ضدتقلب GPS اختیاری است؛ خاموش = اصلاً مجوز موقعیت مکانی نمی‌خواهیم.
    if (gpsEnabled) startGps.capture();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  function updateAnswer(itemId: number, patch: Partial<ChecklistAnswer>) {
    setAnswers((prev) => ({ ...prev, [itemId]: { ...prev[itemId]!, ...patch } }));
  }

  const grouped = React.useMemo(() => {
    const map = new Map<string, typeof template.items>();
    for (const item of template.items) {
      const list = map.get(item.category) ?? [];
      list.push(item);
      map.set(item.category, list);
    }
    return Array.from(map.entries());
  }, [template.items]);

  const missingRequired = template.items.filter((item) => {
    const ans = answers[item.id];
    if (item.requires_note && !ans?.note.trim()) return true;
    if (item.requires_photo && (ans?.photos.length ?? 0) === 0) return true;
    return false;
  });

  // CRITICAL-07/HIGH-44: آیتم‌های بی‌پاسخ (بدون انتخاب نتیجه)
  const unansweredCount = template.items.filter(
    (item) => answers[item.id]?.result == null
  ).length;

  const overallResult: "pass" | "fail" | null = unansweredCount > 0
    ? null
    : Object.values(answers).some((a) => a.result === "fail")
      ? "fail"
      : "pass";

  async function handleSubmit() {
    setError(null);
    if (unansweredCount > 0) {
      setError(
        `${unansweredCount} آیتم هنوز پاسخ داده نشده است. لطفاً برای همه آیتم‌ها نتیجه را مشخص کنید.`
      );
      return;
    }
    if (missingRequired.length > 0) {
      setError(
        `لطفاً موارد الزامی (عکس/توضیح) را برای ${missingRequired.length} آیتم تکمیل کنید.`
      );
      return;
    }
    setSubmitting(true);
    try {
      // EDRA v27: باید واقعاً منتظر نتیجه‌ی GPS پایان بازرسی بمانیم؛
      // مقدار را مستقیماً از Promise برگشتی می‌گیریم (نه از state، که
      // ممکن است هنوز از رندر قبلی باشد) تا تضمین شود همان مقدار تازه
      // ارسال می‌شود.
      const endCoords = gpsEnabled ? await endGps.capture() : null;

      const formData = new FormData();
      formData.append("request_id", String(taskId));
      // HIGH-45: overall سمت سرور محاسبه می‌شود؛ فقط برای اطلاع ارسال می‌شود
      if (overallResult) formData.append("overall_result", overallResult);
      formData.append("inspector_notes", inspectorNotes);
      formData.append("inspection_started_at", startedAt);
      if (gpsEnabled && startGps.coords) {
        formData.append("gps_start_lat", String(startGps.coords.lat));
        formData.append("gps_start_lng", String(startGps.coords.lng));
      }
      if (endCoords) {
        formData.append("gps_end_lat", String(endCoords.lat));
        formData.append("gps_end_lng", String(endCoords.lng));
      }

      const results = template.items.map((item) => ({
        item_id: item.id,
        title: item.title,
        result: answers[item.id]!.result,
        note: answers[item.id]!.note,
      }));
      formData.append("results", JSON.stringify(results));

      template.items.forEach((item) => {
        answers[item.id]!.photos.forEach((file, idx) => {
          formData.append(`photo_${item.id}_${idx}`, file);
        });
      });

      const res = await fetch("/api/proxy/expert/submit-checklist/", {
        method: "POST",
        body: formData,
      });
      // EDRA v34: پاسخ خطای Nginx (مثلاً ۴۱۳ حجم زیاد) JSON نیست؛ قبلاً
      // res.json() می‌شکست و کارشناس «ارتباط با سرور برقرار نشد» می‌دید.
      const data = await res.json().catch(() => ({}));
      if (!res.ok) {
        if (res.status === 413) {
          setError("حجم عکس‌ها بیش از حد مجاز است؛ تعداد/اندازه‌ی عکس‌ها را کم کنید.");
        } else {
          setError(
            data.error || data.detail || "ثبت گزارش با خطا مواجه شد."
          );
        }
        return;
      }
      router.push(`/dashboard/expert/tasks`);
      router.refresh();
    } catch {
      setError("ارتباط با سرور برقرار نشد.");
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <div className="flex flex-col gap-4">
      <Card>
        <CardContent className="flex items-center justify-between gap-3 px-5 py-3">
          <span className="flex items-center gap-2 text-sm">
            <MapPin className="text-muted-foreground size-4" />
            موقعیت شروع بازرسی
          </span>
          {startGps.status === "loading" && (
            <Loader2 className="text-muted-foreground size-4 animate-spin" />
          )}
          {startGps.status === "done" && (
            <Badge variant="success">ثبت شد</Badge>
          )}
          {startGps.status === "error" && (
            <Badge variant="warning">در دسترس نبود</Badge>
          )}
        </CardContent>
      </Card>

      {grouped.map(([category, items]) => (
        <Card key={category}>
          <CardHeader>
            <CardTitle className="text-base">{category}</CardTitle>
          </CardHeader>
          <CardContent className="flex flex-col divide-y">
            {items.map((item) => (
              <ChecklistItemRow
                key={item.id}
                item={item}
                answer={answers[item.id]!}
                onChange={(patch) => updateAnswer(item.id, patch)}
              />
            ))}
          </CardContent>
        </Card>
      ))}

      <Card>
        <CardHeader>
          <CardTitle className="text-base">یادداشت کلی کارشناس</CardTitle>
        </CardHeader>
        <CardContent>
          <Textarea
            rows={4}
            placeholder="یادداشت‌ها یا توضیحات تکمیلی درباره بازرسی..."
            value={inspectorNotes}
            onChange={(e) => setInspectorNotes(e.target.value)}
          />
        </CardContent>
      </Card>

      {error && (
        <Alert variant="destructive">
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      )}

      <div className="bg-background sticky bottom-0 -mx-4 flex items-center justify-between gap-3 border-t px-4 py-3 md:-mx-6 md:px-6">
        <div className="flex items-center gap-2">
          {unansweredCount > 0 ? (
            <Badge variant="warning">{unansweredCount} آیتم بی‌پاسخ</Badge>
          ) : (
            <Badge variant={overallResult === "pass" ? "success" : "destructive"}>
              نتیجه کلی: {overallResult === "pass" ? "موفق" : "مردود"}
            </Badge>
          )}
        </div>
        <Button
          onClick={handleSubmit}
          disabled={submitting || unansweredCount > 0}
          size="lg"
        >
          {submitting && <Loader2 className="animate-spin" />}
          {unansweredCount > 0
            ? `پاسخ ${unansweredCount} آیتم باقی مانده`
            : "ثبت نهایی گزارش"}
          {!submitting && unansweredCount === 0 && <Send />}
        </Button>
      </div>
    </div>
  );
}

function ChecklistItemRow({
  item,
  answer,
  onChange,
}: {
  item: ChecklistTemplateData["items"][number];
  answer: ChecklistAnswer;
  onChange: (patch: Partial<ChecklistAnswer>) => void;
}) {
  const fileInputRef = React.useRef<HTMLInputElement>(null);

  return (
    <div className="flex flex-col gap-3 py-4 first:pt-0 last:pb-0">
      <div>
        <p className="text-sm font-medium">{item.title}</p>
        {item.description && (
          <p className="text-muted-foreground text-xs">{item.description}</p>
        )}
      </div>

      <div className="grid grid-cols-3 gap-2">
        <ResultButton
          active={answer.result === "pass"}
          tone="success"
          icon={CheckCircle2}
          label="سالم"
          onClick={() => onChange({ result: "pass" })}
        />
        <ResultButton
          active={answer.result === "fail"}
          tone="destructive"
          icon={XCircle}
          label="ایراد دارد"
          onClick={() => onChange({ result: "fail" })}
        />
        <ResultButton
          active={answer.result === "na"}
          tone="muted"
          icon={MinusCircle}
          label="فاقد موضوعیت"
          onClick={() => onChange({ result: "na" })}
        />
      </div>

      {(item.requires_note || answer.result === "fail") && (
        <Textarea
          placeholder={
            item.requires_note
              ? "توضیح الزامی برای این مورد..."
              : "توضیح ایراد (اختیاری ولی توصیه می‌شود)..."
          }
          rows={2}
          value={answer.note}
          onChange={(e) => onChange({ note: e.target.value })}
        />
      )}

      {/* EDRA v34: ثبت عکس برای همه‌ی آیتم‌ها ممکن است (سرور می‌پذیرد)؛ قبلاً
          کارشناس فقط برای آیتم‌های «عکس الزامی» می‌توانست مستند ایراد پیوست کند. */}
      {(
        <div>
          <input
            ref={fileInputRef}
            type="file"
            accept="image/*"
            capture="environment"
            multiple
            className="hidden"
            onChange={async (e) => {
              const picked = Array.from(e.target.files ?? []);
              e.target.value = "";
              // فشرده‌سازی سمت مرورگر تا حجم کل از سقف آپلود نگذرد
              const files = await Promise.all(picked.map((f) => compressImage(f)));
              onChange({ photos: [...answer.photos, ...files].slice(0, 10) });
            }}
          />
          <div className="flex flex-wrap items-center gap-2">
            <Button
              type="button"
              variant="outline"
              size="sm"
              onClick={() => fileInputRef.current?.click()}
            >
              <Camera className="size-3.5" />
              {item.requires_photo ? "افزودن عکس (الزامی)" : "افزودن عکس (اختیاری)"}
            </Button>
            {answer.photos.map((file, i) => (
              <span
                key={i}
                className="bg-muted flex items-center gap-1 rounded-md px-2 py-1 text-xs"
              >
                {file.name.slice(0, 15)}
                <button
                  type="button"
                  onClick={() =>
                    onChange({ photos: answer.photos.filter((_, idx) => idx !== i) })
                  }
                >
                  <Trash2 className="text-destructive size-3" />
                </button>
              </span>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

function ResultButton({
  active,
  tone,
  icon: Icon,
  label,
  onClick,
}: {
  active: boolean;
  tone: "success" | "destructive" | "muted";
  icon: typeof CheckCircle2;
  label: string;
  onClick: () => void;
}) {
  const toneActive: Record<string, string> = {
    success: "border-success bg-success/10 text-success",
    destructive: "border-destructive bg-destructive/10 text-destructive",
    muted: "border-foreground bg-muted text-foreground",
  };
  return (
    <button
      type="button"
      onClick={onClick}
      className={cn(
        "flex flex-col items-center gap-1 rounded-md border py-2 text-xs transition-colors",
        active ? toneActive[tone] : "text-muted-foreground hover:border-foreground/30"
      )}
    >
      <Icon className="size-4" />
      {label}
    </button>
  );
}

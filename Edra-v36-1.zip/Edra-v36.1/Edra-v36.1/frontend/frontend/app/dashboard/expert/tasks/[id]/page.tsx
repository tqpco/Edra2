import { notFound } from "next/navigation";
import { MapPin, Calendar, Package, Building2, FileDown } from "lucide-react";

import { apiServerFetch, ApiError } from "@/lib/api-server";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { getStatusInfo, REQUEST_STATUS_MAP } from "@/lib/status-map";
import { formatToman } from "@/lib/format";
import type { TaskDetailResponse } from "@/types/checklist";
import { ChecklistForm } from "./checklist-form";

export const metadata = { title: "جزئیات وظیفه" };

export default async function ExpertTaskDetailPage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = await params;

  let data: TaskDetailResponse;
  try {
    data = await apiServerFetch<TaskDetailResponse>(`/api/expert/tasks/${id}/`);
  } catch (err) {
    if (err instanceof ApiError && err.status === 404) notFound();
    throw err;
  }

  const { task, checklist_template, existing_report, gps_enabled } = data;
  const status = getStatusInfo(REQUEST_STATUS_MAP, task.status);

  return (
    <div className="flex flex-col gap-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-2xl font-semibold">{task.equipment_name}</h1>
            <Badge variant={status.variant}>{status.label}</Badge>
          </div>
          <p className="text-muted-foreground text-sm">
            درخواست {task.request_number}
          </p>
        </div>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="text-base">مشخصات درخواست</CardTitle>
        </CardHeader>
        <CardContent className="grid gap-3 text-sm sm:grid-cols-2">
          <InfoRow icon={Building2} label="مشتری" value={task.customer_name} />
          <InfoRow icon={Package} label="برند/مدل" value={task.brand_model || "—"} />
          {task.scheduled_at_jalali && (
            <InfoRow icon={Calendar} label="زمان کارشناسی" value={task.scheduled_at_jalali} />
          )}
          <InfoRow icon={MapPin} label="آدرس" value={`${task.city} - ${task.address}`} />
          {Object.keys(task.params || {}).length > 0 && (
            <div className="sm:col-span-2">
              <p className="text-muted-foreground mb-1.5 text-xs">مشخصات فنی</p>
              <div className="flex flex-wrap gap-1.5">
                {Object.entries(task.params).map(([key, value]) => (
                  <Badge key={key} variant="outline">
                    {key}: {String(value)}
                  </Badge>
                ))}
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      {existing_report ? (
        <Card>
          <CardContent className="flex flex-wrap items-center justify-between gap-3 px-5 py-4">
            <p className="text-sm">
              گزارش شماره {existing_report.report_number} برای این وظیفه ثبت شده
              است
              {existing_report.pdf_ready ? "." : " و فایل PDF آن در حال تولید است (چند دقیقه‌ی دیگر دوباره بررسی کنید)."}
            </p>
            {existing_report.pdf_ready && (
              <Button size="sm" variant="outline" asChild>
                <a
                  href={`/api/download/inspections/inspection-reports/${existing_report.id}/pdf/`}
                  target="_blank"
                  rel="noreferrer"
                >
                  <FileDown />
                  دانلود PDF
                </a>
              </Button>
            )}
          </CardContent>
        </Card>
      ) : !task.can_submit ? (
        // EDRA v34: قبلاً فرم چک‌لیست برای هر وضعیتی (حتی لغوشده/تکمیل‌شده)
        // باز می‌شد و کارشناس بعد از پر کردن کل فرم و عکس‌ها خطا می‌گرفت.
        <Card>
          <CardContent className="text-muted-foreground px-5 py-8 text-center text-sm">
            در وضعیت «{status.label}» امکان ثبت گزارش بازرسی وجود ندارد.
          </CardContent>
        </Card>
      ) : checklist_template ? (
        <ChecklistForm
          taskId={task.id}
          template={checklist_template}
          addressLat={task.address_lat}
          addressLng={task.address_lng}
          gpsEnabled={gps_enabled}
        />
      ) : (
        <Card>
          <CardContent className="text-muted-foreground px-5 py-8 text-center text-sm">
            قالب چک‌لیستی برای این نوع تجهیز تعریف نشده است. لطفاً با مدیر
            تماس بگیرید.
          </CardContent>
        </Card>
      )}
    </div>
  );
}

function InfoRow({
  icon: Icon,
  label,
  value,
}: {
  icon: typeof MapPin;
  label: string;
  value: string;
}) {
  return (
    <div className="flex items-start gap-2">
      <Icon className="text-muted-foreground mt-0.5 size-4 shrink-0" />
      <div>
        <span className="text-muted-foreground">{label}: </span>
        <span className="font-medium">{value}</span>
      </div>
    </div>
  );
}

import { apiServerFetch } from "@/lib/api-server";
import { fetchPaginated } from "@/lib/paginated-fetch";
import { Pagination } from "@/components/ui/pagination";
import { ExpertTaskCard } from "@/components/shared/expert-task-card";
import type { ExpertTask } from "@/types/dashboard";
import { ClipboardList } from "lucide-react";

export const metadata = { title: "وظایف من" };

interface TaskListResponse {
  tasks: {
    id: number;
    equipment_name: string;
    status: string;
    city: string;
    address: string;
    request_number: string;
    scheduled_at_jalali?: string | null;
  }[];
  count: number;
}

export default async function ExpertTasksPage({ searchParams }: { searchParams: Promise<{ page?: string }> }) {
  const _page = Math.max(1, Number((await searchParams).page) || 1);
  const data = await apiServerFetch<TaskListResponse>(`/api/expert/tasks/?page=${_page}`);

  const tasks: ExpertTask[] = data.tasks.map((t) => ({
    id: t.id,
    request_number: t.request_number,
    equipment: t.equipment_name,
    status: t.status,
    scheduled_at_jalali: t.scheduled_at_jalali ?? null,
    address: t.address,
    city: t.city,
  }));
  const count =
    typeof (data as { count?: number }).count === "number"
      ? (data as { count?: number }).count!
      : tasks.length;

  return (
    <div className="flex flex-col gap-6">
      <div>
        <h1 className="text-2xl font-semibold">وظایف من</h1>
        <p className="text-muted-foreground text-sm">
          {data.count} وظیفه ارجاع‌شده به شما
        </p>
      </div>

      {tasks.length === 0 ? (
        <div className="text-muted-foreground flex flex-col items-center gap-3 rounded-xl border border-dashed py-16 text-center">
          <ClipboardList className="size-10 opacity-40" />
          هنوز وظیفه‌ای به شما ارجاع نشده است
        </div>
      ) : (
        <div className="flex flex-col gap-3">
          {tasks.map((task) => (
            <ExpertTaskCard key={task.id} task={task} />
          ))}
        </div>
      )}
          <Pagination current={_page} totalItems={count} basePath="/dashboard/expert/tasks" />
</div>
  );
}

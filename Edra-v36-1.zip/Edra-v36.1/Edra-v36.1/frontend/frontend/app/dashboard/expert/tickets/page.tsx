import Link from "next/link";
import { apiServerFetch } from "@/lib/api-server";
import { fetchPaginated } from "@/lib/paginated-fetch";
import { Pagination } from "@/components/ui/pagination";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { MessagesSquare } from "lucide-react";
import type { TicketListItem } from "@/types/ticket";

export const metadata = { title: "تیکت‌ها" };

export default async function ExpertTicketsPage({ searchParams }: { searchParams: Promise<{ page?: string }> }) {
  const _page = Math.max(1, Number((await searchParams).page) || 1);
  const data = await apiServerFetch<{ count: number; results: TicketListItem[] }>(
    `/api/support/tickets/?page=${_page}`
  );
  const tickets = data.results ?? [];
  const count =
    typeof data.count === "number" ? data.count : tickets.length;

  return (
    <div className="flex flex-col gap-6">
      <div>
        <h1 className="text-2xl font-semibold">تیکت‌های مرتبط با من</h1>
      </div>

      {tickets.length === 0 ? (
        <div className="text-muted-foreground flex flex-col items-center gap-3 rounded-xl border border-dashed py-16 text-center">
          <MessagesSquare className="size-10 opacity-40" />
          تیکتی وجود ندارد
        </div>
      ) : (
        <div className="flex flex-col gap-3">
          {tickets.map((t) => (
            <Link key={t.id} href={`/dashboard/expert/tickets/${t.id}`}>
              <Card className="transition-shadow hover:shadow-md">
                <CardContent className="flex flex-wrap items-center justify-between gap-3 px-5 py-4">
                  <div>
                    <p className="text-sm font-medium">{t.title}</p>
                    <p className="text-muted-foreground text-xs">
                      {t.customer_name} · {t.updated_at_jalali}
                    </p>
                  </div>
                  <Badge variant="outline">{t.status_name}</Badge>
                </CardContent>
              </Card>
            </Link>
          ))}
        </div>
      )}
          <Pagination current={_page} totalItems={count} basePath="/dashboard/expert/tickets" />
</div>
  );
}

import Link from "next/link";
import { Home, SearchX } from "lucide-react";
import { Button } from "@/components/ui/button";

export const metadata = { title: "صفحه پیدا نشد" };

/* EDRA v26 — صفحه ۴۰۴: پالت سبز رولکسی / خاکستری / کاکی */

export default function NotFound() {
  return (
    <div className="flex min-h-svh flex-col items-center justify-center gap-6 px-6 text-center">
      <div className="flex size-20 items-center justify-center rounded-3xl bg-primary/10 text-primary">
        <SearchX className="size-9" strokeWidth={1.5} />
      </div>
      <div className="flex flex-col gap-2">
        <h1 className="text-4xl font-bold tracking-tight text-foreground">
          ۴۰۴
        </h1>
        <p className="text-lg font-medium text-foreground">صفحه پیدا نشد</p>
        <p className="text-muted-foreground max-w-sm text-sm">
          صفحه‌ای که دنبالش بودید وجود ندارد یا جابه‌جا شده است.
        </p>
      </div>
      <Button asChild className="mt-2 h-11 rounded-xl px-6 text-sm">
        <Link href="/">
          <Home className="size-4" />
          بازگشت به صفحه اصلی
        </Link>
      </Button>
    </div>
  );
}

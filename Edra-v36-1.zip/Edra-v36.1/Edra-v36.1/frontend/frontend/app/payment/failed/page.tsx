import Link from "next/link";
import { XCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";

export const metadata = { title: "پرداخت ناموفق" };

// EDRA v35: وقتی تایید نهایی درگاه به‌خاطر قطعی/timeout انجام نشد، نتیجه‌ی
// تراکنش «نامعلوم» است؛ نباید قطعی گفت «مبلغی کسر نشده».
export default async function PaymentFailedPage({
  searchParams,
}: {
  searchParams: Promise<{ reason?: string }>;
}) {
  const { reason } = await searchParams;
  const unknownResult = reason === "verify_unavailable";
  return (
    <div className="bg-muted/30 flex min-h-svh items-center justify-center p-4">
      <Card className="w-full max-w-md">
        <CardContent className="flex flex-col items-center gap-4 py-10 text-center">
          <span className="bg-destructive/10 flex size-16 items-center justify-center rounded-full">
            <XCircle className="text-destructive size-9" />
          </span>
          <div>
            <h1 className="text-xl font-semibold">
              {unknownResult ? "نتیجه‌ی پرداخت هنوز مشخص نیست" : "پرداخت ناموفق بود"}
            </h1>
            <p className="text-muted-foreground mt-1 text-sm">
              {unknownResult
                ? "ارتباط با درگاه برای تایید نهایی برقرار نشد. اگر مبلغ از حساب شما کسر شده، لطفاً دوباره پرداخت نکنید و با پشتیبانی تماس بگیرید؛ در غیر این صورت مبلغ توسط بانک به حساب شما برمی‌گردد."
                : "مبلغی از حساب شما کسر نشده است. می‌توانید دوباره تلاش کنید یا از روش واریز دستی استفاده کنید."}
            </p>
          </div>
          <div className="mt-2 flex w-full gap-2">
            <Button asChild className="flex-1">
              <Link href="/dashboard/customer/requests">تلاش مجدد</Link>
            </Button>
            <Button asChild variant="outline" className="flex-1">
              <Link href="/dashboard/customer/tickets">تماس با پشتیبانی</Link>
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

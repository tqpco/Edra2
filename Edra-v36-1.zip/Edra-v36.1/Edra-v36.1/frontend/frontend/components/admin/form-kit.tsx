"use client";

/**
 * components/admin/form-kit.tsx  (EDRA v32)
 *
 * «استاندارد واحد» همه‌ی صفحات ایجاد / ویرایش مدیریتی. قبلاً هر صفحه
 * هدر، گرید، دکمه‌ی ذخیره و نمایش خطا را از نو و کمی متفاوت می‌ساخت؛
 * حالا فقط از همین چهار قطعه استفاده می‌شود:
 *
 *   <FormShell>      هدر (عنوان + انصراف) + بنر خطا + گرید ۲/۳ + کارت ذخیره
 *     <FormSection>  کارت گروه فیلدها (عنوان/توضیح)
 *       <Field>      برچسب + ستاره‌ی الزامی + راهنما + خطای همان فیلد
 *       <SwitchField> سوییچ فعال/غیرفعال با توضیح
 *
 * منطق ذخیره (ارسال، خطا، toast، redirect) در hooks/use-resource-submit.ts است.
 */
import * as React from "react";
import Link from "next/link";
import { AlertCircle, Loader2, Save, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";

interface FormShellProps {
  title: string;
  description?: string;
  /** مقصد دکمه‌ی «انصراف» (معمولاً صفحه‌ی لیست) */
  backHref: string;
  onSubmit: (e: React.FormEvent<HTMLFormElement>) => void;
  saving?: boolean;
  /** هنگام دریافت اطلاعات اولیه در صفحه‌ی ویرایش */
  loading?: boolean;
  submitLabel?: string;
  /** پیام خطای کلی (non-field) */
  error?: string | null;
  /** ستون کناری (کارت‌های خلاصه/راهنما) — دکمه‌ی ذخیره همیشه زیر آن است */
  aside?: React.ReactNode;
  children: React.ReactNode;
}

export function FormShell({
  title,
  description,
  backHref,
  onSubmit,
  saving = false,
  loading = false,
  submitLabel = "ذخیره",
  error,
  aside,
  children,
}: FormShellProps) {
  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="text-2xl font-bold">{title}</h1>
          {description ? (
            <p className="text-muted-foreground text-sm">{description}</p>
          ) : null}
        </div>
        <Button variant="outline" asChild>
          <Link href={backHref}>
            <X className="ml-2 h-4 w-4" />
            انصراف
          </Link>
        </Button>
      </div>

      {error ? (
        <Alert variant="destructive">
          <AlertCircle />
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      ) : null}

      {loading ? (
        <div className="text-muted-foreground flex items-center justify-center gap-2 py-20 text-sm">
          <Loader2 className="h-4 w-4 animate-spin" />
          در حال دریافت اطلاعات...
        </div>
      ) : (
        <form onSubmit={onSubmit} noValidate>
          <div className="grid grid-cols-1 gap-6 lg:grid-cols-3">
            <div className="space-y-6 lg:col-span-2">{children}</div>
            <div className="space-y-6 lg:col-span-1">
              {aside}
              <Button type="submit" className="w-full" disabled={saving}>
                {saving ? (
                  <Loader2 className="ml-2 h-4 w-4 animate-spin" />
                ) : (
                  <Save className="ml-2 h-4 w-4" />
                )}
                {saving ? "در حال ذخیره..." : submitLabel}
              </Button>
            </div>
          </div>
        </form>
      )}
    </div>
  );
}

export function FormSection({
  title,
  description,
  children,
}: {
  title: string;
  description?: string;
  children: React.ReactNode;
}) {
  return (
    <Card>
      <CardHeader>
        <CardTitle>{title}</CardTitle>
        {description ? <CardDescription>{description}</CardDescription> : null}
      </CardHeader>
      <CardContent className="space-y-4">{children}</CardContent>
    </Card>
  );
}

/** دو ستون در دسکتاپ، یک ستون در موبایل */
export function FieldRow({ children }: { children: React.ReactNode }) {
  return <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">{children}</div>;
}

interface FieldProps {
  id: string;
  label: string;
  required?: boolean;
  hint?: string;
  error?: string;
  children: React.ReactNode;
}

export function Field({ id, label, required, hint, error, children }: FieldProps) {
  return (
    <div className="space-y-2">
      <Label htmlFor={id}>
        {label}
        {required ? <span className="text-destructive mr-1">*</span> : null}
      </Label>
      {children}
      {error ? (
        <p className="text-destructive text-xs" role="alert">
          {error}
        </p>
      ) : hint ? (
        <p className="text-muted-foreground text-xs">{hint}</p>
      ) : null}
    </div>
  );
}

export function SwitchField({
  id,
  label,
  hint,
  checked,
  onCheckedChange,
  disabled,
}: {
  id: string;
  label: string;
  hint?: string;
  checked: boolean;
  onCheckedChange: (checked: boolean) => void;
  disabled?: boolean;
}) {
  return (
    <div className="flex items-center justify-between gap-4 pt-2">
      <div className="space-y-0.5">
        <Label htmlFor={id}>{label}</Label>
        {hint ? <p className="text-muted-foreground text-xs">{hint}</p> : null}
      </div>
      <Switch
        id={id}
        checked={checked}
        onCheckedChange={onCheckedChange}
        disabled={disabled}
      />
    </div>
  );
}

"use client";

/**
 * components/admin/user-form.tsx  (EDRA v32)
 *
 * فرم مشترک «مشتری / کارشناس» برای صفحه‌های ایجاد و ویرایش مدیریتی.
 * هر دو نقش یک فرم و یک منطق دارند؛ فقط نقش (و متن‌ها) فرق می‌کند.
 */
import * as React from "react";
import { Input } from "@/components/ui/input";
import { FormShell, FormSection, Field, FieldRow, SwitchField } from "@/components/admin/form-kit";
import { useResourceSubmit } from "@/hooks/use-resource-submit";

export type ManagedRole = "customer" | "expert";

export interface UserFormInitial {
  id: number;
  username: string;
  first_name: string;
  last_name: string;
  email: string;
  phone: string | null;
  company_name: string | null;
  registration_number: string | null;
  is_active: boolean;
  is_staff?: boolean;
  is_superuser?: boolean;
}

const COPY: Record<ManagedRole, { singular: string; listHref: string }> = {
  customer: { singular: "مشتری", listHref: "/dashboard/admin/customers" },
  expert: { singular: "کارشناس", listHref: "/dashboard/admin/experts" },
};

const PERSIAN_DIGITS = "۰۱۲۳۴۵۶۷۸۹";
const ARABIC_DIGITS = "٠١٢٣٤٥٦٧٨٩";

/** ۰۹۱۲… و ٠٩١٢… را به 0912… تبدیل می‌کند (بک‌اند فقط ارقام لاتین می‌پذیرد) */
function normalizeDigits(value: string): string {
  return value
    .replace(/[۰-۹]/g, (d) => String(PERSIAN_DIGITS.indexOf(d)))
    .replace(/[٠-٩]/g, (d) => String(ARABIC_DIGITS.indexOf(d)));
}

export function UserForm({
  mode,
  role,
  initial,
}: {
  mode: "create" | "edit";
  role: ManagedRole;
  initial?: UserFormInitial;
}) {
  const copy = COPY[role];
  const isEdit = mode === "edit";

  const [form, setForm] = React.useState({
    first_name: initial?.first_name ?? "",
    last_name: initial?.last_name ?? "",
    phone: initial?.phone ?? "",
    email: initial?.email ?? "",
    company_name: initial?.company_name ?? "",
    registration_number: initial?.registration_number ?? "",
    is_active: initial?.is_active ?? true,
  });
  const [localErrors, setLocalErrors] = React.useState<Record<string, string>>({});

  const { submit, saving, error, fieldErrors, clearFieldError } = useResourceSubmit({
    endpoint: isEdit ? `/api/core/users/${initial?.id}/` : "/api/core/users/",
    method: isEdit ? "PATCH" : "POST",
    successMessage: isEdit ? `اطلاعات ${copy.singular} ذخیره شد.` : `${copy.singular} جدید ثبت شد.`,
    redirectTo: copy.listHref,
    errorFallback: `خطا در ذخیره‌ی ${copy.singular}.`,
  });

  const errors = { ...fieldErrors, ...localErrors };
  const privileged = Boolean(initial?.is_staff || initial?.is_superuser);

  function set<K extends keyof typeof form>(key: K, value: (typeof form)[K]) {
    setForm((prev) => ({ ...prev, [key]: value }));
    clearFieldError(key as string);
    setLocalErrors((prev) => {
      if (!prev[key as string]) return prev;
      const next = { ...prev };
      delete next[key as string];
      return next;
    });
  }

  function handleSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();

    const phone = normalizeDigits(form.phone.trim());
    const problems: Record<string, string> = {};
    if (!form.first_name.trim() && !form.last_name.trim()) {
      problems.first_name = "نام یا نام خانوادگی را وارد کنید.";
    }
    if (!/^09\d{9}$/.test(phone)) {
      problems.phone = "شماره موبایل باید با 09 شروع شود و ۱۱ رقم باشد.";
    }
    if (form.email.trim() && !/^\S+@\S+\.\S+$/.test(form.email.trim())) {
      problems.email = "فرمت ایمیل معتبر نیست.";
    }
    setLocalErrors(problems);
    if (Object.keys(problems).length > 0) return;

    const payload: Record<string, unknown> = {
      first_name: form.first_name.trim(),
      last_name: form.last_name.trim(),
      phone,
      email: form.email.trim(),
      company_name: form.company_name.trim(),
      registration_number: form.registration_number.trim(),
      is_active: form.is_active,
    };
    if (!isEdit) payload.role = role;
    void submit(payload);
  }

  return (
    <FormShell
      title={isEdit ? `ویرایش ${copy.singular}` : `${copy.singular} جدید`}
      description={
        isEdit
          ? `اطلاعات ${copy.singular} را ویرایش کنید`
          : `مشخصات ${copy.singular} جدید را وارد کنید`
      }
      backHref={copy.listHref}
      onSubmit={handleSubmit}
      saving={saving}
      submitLabel={isEdit ? "ذخیره تغییرات" : `ثبت ${copy.singular}`}
      error={error}
    >
      <FormSection title="مشخصات فردی" description="نام و اطلاعات تماس">
        <FieldRow>
          <Field id="first_name" label="نام" required error={errors.first_name}>
            <Input
              id="first_name"
              value={form.first_name}
              onChange={(e) => set("first_name", e.target.value)}
              aria-invalid={Boolean(errors.first_name)}
              autoComplete="off"
            />
          </Field>
          <Field id="last_name" label="نام خانوادگی" error={errors.last_name}>
            <Input
              id="last_name"
              value={form.last_name}
              onChange={(e) => set("last_name", e.target.value)}
              aria-invalid={Boolean(errors.last_name)}
              autoComplete="off"
            />
          </Field>
        </FieldRow>
        <FieldRow>
          <Field
            id="phone"
            label="شماره موبایل"
            required
            hint="ورود با کد یک‌بارمصرف (OTP) روی همین شماره انجام می‌شود."
            error={errors.phone}
          >
            <Input
              id="phone"
              dir="ltr"
              inputMode="tel"
              placeholder="09123456789"
              value={form.phone}
              onChange={(e) => set("phone", e.target.value)}
              aria-invalid={Boolean(errors.phone)}
              autoComplete="off"
            />
          </Field>
          <Field id="email" label="ایمیل" error={errors.email}>
            <Input
              id="email"
              dir="ltr"
              type="email"
              value={form.email}
              onChange={(e) => set("email", e.target.value)}
              aria-invalid={Boolean(errors.email)}
              autoComplete="off"
            />
          </Field>
        </FieldRow>
      </FormSection>

      {role === "customer" ? (
        <FormSection title="اطلاعات سازمانی" description="برای مشتریان حقوقی (اختیاری)">
          <FieldRow>
            <Field id="company_name" label="نام شرکت" error={errors.company_name}>
              <Input
                id="company_name"
                value={form.company_name}
                onChange={(e) => set("company_name", e.target.value)}
                autoComplete="off"
              />
            </Field>
            <Field
              id="registration_number"
              label="شماره ثبت / کد ملی"
              error={errors.registration_number}
            >
              <Input
                id="registration_number"
                dir="ltr"
                value={form.registration_number}
                onChange={(e) => set("registration_number", e.target.value)}
                autoComplete="off"
              />
            </Field>
          </FieldRow>
        </FormSection>
      ) : null}

      <FormSection title="وضعیت حساب">
        <SwitchField
          id="is_active"
          label="حساب فعال است"
          hint={
            privileged
              ? "این کاربر دسترسی مدیریتی دارد؛ وضعیت او فقط توسط سوپریوزر قابل تغییر است."
              : "با غیرفعال‌کردن، کاربر دیگر نمی‌تواند وارد شود (سوابق او حذف نمی‌شود)."
          }
          checked={form.is_active}
          onCheckedChange={(v) => set("is_active", v)}
        />
        {errors.is_active ? (
          <p className="text-destructive text-xs" role="alert">
            {errors.is_active}
          </p>
        ) : null}
      </FormSection>
    </FormShell>
  );
}

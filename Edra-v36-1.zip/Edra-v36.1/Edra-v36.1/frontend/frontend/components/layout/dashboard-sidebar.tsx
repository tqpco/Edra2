// components/layout/dashboard-sidebar.tsx
"use client";

import * as React from "react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { Menu, ShieldCheck } from "lucide-react";

import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetTrigger } from "@/components/ui/sheet";
import type { NavSection } from "@/lib/nav-config";

function NavContent({ sections, onNavigate }: { sections: NavSection[]; onNavigate?: () => void }) {
  const pathname = usePathname();

  return (
    <div className="flex h-full flex-col gap-6 overflow-y-auto p-4">
      <Link href="/" className="flex items-center gap-2 px-2 font-semibold">
        <span className="flex size-8 items-center justify-center rounded-md bg-primary text-primary-foreground">
          <ShieldCheck className="size-4" />
        </span>
        ادرو
      </Link>

      <nav className="flex flex-1 flex-col gap-6">
        {sections.map((section, i) => (
          <div key={i} className="flex flex-col gap-1">
            {section.label && (
              <p className="text-muted-foreground px-2 text-xs font-medium">
                {section.label}
              </p>
            )}
            {section.items.map((item) => {
              const isActive =
                pathname === item.href ||
                (item.href !== "/dashboard/admin" &&
                  item.href !== "/dashboard/expert" &&
                  item.href !== "/dashboard/customer" &&
                  pathname.startsWith(item.href));
              return (
                <Link
                  key={item.href}
                  href={item.href}
                  onClick={onNavigate}
                  className={cn(
                    "flex items-center gap-2.5 rounded-md px-2.5 py-2 text-sm font-medium transition-colors",
                    isActive
                      ? "bg-primary/10 text-primary"
                      : "text-foreground/80 hover:bg-accent hover:text-accent-foreground"
                  )}
                >
                  {/* ✅ آیکون را به‌عنوان ReactNode رندر می‌کنیم */}
                  {item.icon}
                  {item.title}
                </Link>
              );
            })}
          </div>
        ))}
      </nav>
    </div>
  );
}

export function DashboardSidebar({ sections }: { sections: NavSection[] }) {
  return (
    <aside className="bg-sidebar text-sidebar-foreground border-sidebar-border hidden w-64 shrink-0 border-l lg:block">
      <NavContent sections={sections} />
    </aside>
  );
}

export function DashboardMobileNav({ sections }: { sections: NavSection[] }) {
  const [open, setOpen] = React.useState(false);
  return (
    <Sheet open={open} onOpenChange={setOpen}>
      <SheetTrigger asChild>
        <Button variant="ghost" size="icon" className="lg:hidden">
          <Menu />
          <span className="sr-only">باز کردن منو</span>
        </Button>
      </SheetTrigger>
      <SheetContent side="right" className="bg-sidebar text-sidebar-foreground w-72 p-0">
        <SheetHeader className="sr-only">
          <SheetTitle>منوی ناوبری</SheetTitle>
        </SheetHeader>
        <NavContent sections={sections} onNavigate={() => setOpen(false)} />
      </SheetContent>
    </Sheet>
  );
}
import Link from "next/link";
import { ShieldCheck, Phone, Mail, MapPin, ArrowUpLeft } from "lucide-react";

const EQUIPMENT_LINKS = [
  { name: "جرثقیل برجی", href: "#" },
  { name: "جرثقیل سیار", href: "#" },
  { name: "لیفتراک", href: "#" },
  { name: "بالابر", href: "#" },
  { name: "جرثقیل سقفی", href: "#" },
];

const COMPANY_LINKS = [
  { name: "درباره ما", href: "/about" },
  { name: "پروژه‌های ما", href: "/projects" },
  { name: "وبلاگ", href: "/blog" },
  { name: "سوالات متداول", href: "/faq" },
  { name: "استعلام گزارش", href: "/verify" },
  { name: "تماس با ما", href: "/contact" },
];

export function MarketingFooter() {
  return (
    <footer className="border-t border-border/50 bg-foreground text-background/80">
      <div className="mx-auto grid max-w-6xl gap-10 px-4 pt-14 pb-8 sm:grid-cols-2 lg:grid-cols-4">
        {/* Brand */}
        <div className="lg:col-span-1">
          <Link href="/" className="text-background flex items-center gap-2.5 font-bold">
            <span className="bg-primary flex size-9 items-center justify-center rounded-xl">
              <ShieldCheck className="size-5" />
            </span>
            <span className="text-lg tracking-tight">ادرو</span>
          </Link>
          <p className="mt-5 text-sm leading-relaxed text-background/60">
            بازرسی و صدور گواهی تخصصی تجهیزات سنگین صنعتی برای کسب‌وکارهای
            ایرانی — سریع، استاندارد، قابل‌اعتماد.
          </p>
          <div className="mt-6 flex flex-col gap-2.5 text-sm">
            <a href="tel:021XXXXXXXX" className="flex items-center gap-2 text-background/60 transition-colors hover:text-background">
              <Phone className="size-3.5" />
              <span dir="ltr">021-XXXXXXXX</span>
            </a>
            <a href="mailto:info@edra-inspect.ir" className="flex items-center gap-2 text-background/60 transition-colors hover:text-background">
              <Mail className="size-3.5" />
              info@edra-inspect.ir
            </a>
            <span className="flex items-center gap-2 text-background/60">
              <MapPin className="size-3.5" />
              تهران، ایران
            </span>
          </div>
        </div>

        {/* Equipment */}
        <div>
          <h3 className="text-background mb-4 text-xs font-semibold uppercase tracking-wider">
            تجهیزات
          </h3>
          <ul className="flex flex-col gap-2.5 text-sm">
            {EQUIPMENT_LINKS.map((e) => (
              <li key={e.name}>
                <Link href={e.href} className="text-background/50 transition-colors hover:text-background">
                  {e.name}
                </Link>
              </li>
            ))}
          </ul>
        </div>

        {/* Company */}
        <div>
          <h3 className="text-background mb-4 text-xs font-semibold uppercase tracking-wider">
            شرکت
          </h3>
          <ul className="flex flex-col gap-2.5 text-sm">
            {COMPANY_LINKS.map((link) => (
              <li key={link.name}>
                <Link href={link.href} className="text-background/50 transition-colors hover:text-background">
                  {link.name}
                </Link>
              </li>
            ))}
          </ul>
        </div>

        {/* CTA */}
        <div>
          <h3 className="text-background mb-4 text-xs font-semibold uppercase tracking-wider">
            شروع کنید
          </h3>
          <p className="mb-5 text-sm leading-relaxed text-background/50">
            همین حالا بازرسی تجهیز خود را به‌صورت آنلاین رزرو کنید.
          </p>
          <Link
            href="/booking?fresh=1"
            className="bg-primary inline-flex items-center gap-2 rounded-xl px-5 py-2.5 text-sm font-medium text-primary-foreground transition-all hover:opacity-90"
          >
            رزرو بازرسی
            <ArrowUpLeft className="size-4" />
          </Link>
        </div>
      </div>

      {/* Bottom bar */}
      <div className="border-background/10 border-t px-4 py-5">
        <div className="mx-auto flex max-w-6xl flex-col items-center justify-between gap-3 sm:flex-row">
          <p className="text-xs text-background/40">
            © {new Date().getFullYear()} ادرو — تمامی حقوق محفوظ است
          </p>
          <div className="flex gap-4 text-xs text-background/40">
            <Link href="/faq" className="transition-colors hover:text-background/70">حریم خصوصی</Link>
            <Link href="/faq" className="transition-colors hover:text-background/70">شرایط استفاده</Link>
          </div>
        </div>
      </div>
    </footer>
  );
}

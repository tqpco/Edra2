import { Shield, Clock, FileCheck2, CalendarRange } from "lucide-react";

const STATS = [
  { icon: Shield, value: "۷+", label: "نوع تجهیز تحت پوشش" },
  { icon: Clock, value: "۴۸", label: "ساعت زمان پاسخ‌گویی" },
  { icon: FileCheck2, value: "۱۰۰٪", label: "گزارش دیجیتال و قابل‌پیگیری" },
  { icon: CalendarRange, value: "۸-۱۶", label: "بازه زمانی رزرو روزانه" },
];

export function TrustStats() {
  return (
    <div className="grid grid-cols-2 gap-4 sm:grid-cols-4">
      {STATS.map((s) => (
        <div
          key={s.label}
          className="group relative overflow-hidden rounded-2xl border border-border bg-card px-5 py-5 text-center transition-all hover:border-primary/30 hover:shadow-sm"
        >
          <div className="mx-auto mb-2.5 flex size-10 items-center justify-center rounded-xl bg-primary/10 text-primary transition-colors group-hover:bg-primary group-hover:text-primary-foreground">
            <s.icon className="size-5" strokeWidth={1.5} />
          </div>
          <p className="text-2xl font-bold tracking-tight text-foreground sm:text-3xl">
            {s.value}
          </p>
          <p className="mt-1 text-xs text-muted-foreground">{s.label}</p>
        </div>
      ))}
    </div>
  );
}

// components/shared/notification-inbox.tsx
"use client";

import { useCallback, useEffect, useState } from "react";
import { Bell, CheckCheck, MailOpen } from "lucide-react";
import { toast } from "sonner";
import { PaginationClient } from "@/components/ui/pagination";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { apiClientFetch } from "@/lib/api-client";
import { NOTIFICATIONS_CHANGED_EVENT } from "@/hooks/use-notification-socket";

interface NotificationItem {
  id: number;
  type: string;
  type_label?: string;
  subject: string;
  content: string;
  is_read: boolean;
  created_at_jalali?: string;
}

interface Page {
  rows: NotificationItem[];
  total: number;
}

/**
 * صندوق اعلان‌های کاربر جاری — مشترک بین مشتری، کارشناس و مدیر.
 * EDRA v33: قبلاً فقط مشتری صفحه‌ی اعلان داشت (و آن هم بدون به‌روزرسانی زنده و
 * با صفحه‌بندی خراب به‌خاطر حذف query string در پروکسی).
 */
export function NotificationInbox() {
  const [notifications, setNotifications] = useState<NotificationItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [page, setPage] = useState(1);
  const [total, setTotal] = useState(0);
  const [onlyUnread, setOnlyUnread] = useState(false);

  const fetchPage = useCallback(async (): Promise<Page> => {
    const qs = `?page=${page}${onlyUnread ? "&is_read=false" : ""}`;
    const data = await apiClientFetch<
      { count: number; results: NotificationItem[] } | NotificationItem[]
    >(`/api/core/notifications/${qs}`);
    const rows = Array.isArray(data) ? data : data.results ?? [];
    const count = !Array.isArray(data) && typeof data.count === "number" ? data.count : rows.length;
    return { rows, total: count };
  }, [page, onlyUnread]);

  const load = useCallback(() => {
    fetchPage()
      .then((r) => {
        setNotifications(r.rows);
        setTotal(r.total);
      })
      .catch(() => toast.error("خطا در دریافت اعلان‌ها"))
      .finally(() => setLoading(false));
  }, [fetchPage]);

  useEffect(() => {
    load();
  }, [load]);

  // به‌روزرسانی زنده: با هر اعلان جدید / تغییر خوانده‌شدن از زنگوله
  useEffect(() => {
    window.addEventListener(NOTIFICATIONS_CHANGED_EVENT, load);
    return () => window.removeEventListener(NOTIFICATIONS_CHANGED_EVENT, load);
  }, [load]);

  const markRead = async (id: number) => {
    try {
      await apiClientFetch(`/api/core/notifications/${id}/mark_read/`, { method: "POST", body: {} });
      setNotifications((prev) => prev.map((n) => (n.id === id ? { ...n, is_read: true } : n)));
      window.dispatchEvent(new CustomEvent(NOTIFICATIONS_CHANGED_EVENT));
    } catch {
      toast.error("خطا در علامت‌گذاری");
    }
  };

  const markAllRead = async () => {
    try {
      await apiClientFetch("/api/core/notifications/mark_all_read/", { method: "POST", body: {} });
      setNotifications((prev) => prev.map((n) => ({ ...n, is_read: true })));
      toast.success("همه اعلان‌ها خوانده شد");
      window.dispatchEvent(new CustomEvent(NOTIFICATIONS_CHANGED_EVENT));
    } catch {
      toast.error("خطا در عملیات");
    }
  };

  const unread = notifications.filter((n) => !n.is_read).length;

  return (
    <div className="flex flex-col gap-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="text-2xl font-semibold">اعلان‌ها</h1>
          <p className="text-muted-foreground text-sm">
            {unread > 0 ? `${unread} اعلان خوانده‌نشده در این صفحه` : "اعلان خوانده‌نشده‌ای ندارید"}
          </p>
        </div>
        <div className="flex gap-2">
          <Button
            variant={onlyUnread ? "default" : "outline"}
            size="sm"
            onClick={() => {
              setPage(1);
              setLoading(true);
              setOnlyUnread((v) => !v);
            }}
          >
            فقط خوانده‌نشده
          </Button>
          {unread > 0 && (
            <Button variant="outline" size="sm" onClick={markAllRead}>
              <CheckCheck className="size-4" />
              خواندن همه
            </Button>
          )}
        </div>
      </div>

      <Card>
        <CardContent className="px-0 py-2">
          {loading ? (
            <p className="text-muted-foreground py-10 text-center text-sm">در حال بارگذاری...</p>
          ) : notifications.length === 0 ? (
            <p className="text-muted-foreground py-10 text-center text-sm">
              <Bell className="mx-auto mb-2 size-8 opacity-40" />
              اعلانی دریافت نکرده‌اید
            </p>
          ) : (
            <div className="flex flex-col divide-y">
              {notifications.map((n) => (
                <button
                  key={n.id}
                  onClick={() => !n.is_read && markRead(n.id)}
                  className={`flex w-full items-start gap-3 px-5 py-4 text-right transition-colors hover:bg-muted/40 ${
                    !n.is_read ? "bg-primary/[0.03]" : ""
                  }`}
                >
                  <span
                    className={`mt-0.5 flex size-9 shrink-0 items-center justify-center rounded-lg ${
                      n.is_read ? "bg-muted text-muted-foreground" : "bg-primary/10 text-primary"
                    }`}
                  >
                    {n.is_read ? <MailOpen className="size-4" /> : <Bell className="size-4" />}
                  </span>
                  <span className="min-w-0 flex-1">
                    <span className="flex flex-wrap items-center gap-2">
                      <span className="text-sm font-medium">{n.subject}</span>
                      {n.type_label && <Badge variant="outline">{n.type_label}</Badge>}
                      {!n.is_read && <Badge variant="default">جدید</Badge>}
                    </span>
                    <span className="text-muted-foreground mt-0.5 block text-sm">{n.content}</span>
                    <span className="text-muted-foreground mt-1 block text-xs">
                      {n.created_at_jalali ?? ""}
                    </span>
                  </span>
                </button>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
      <PaginationClient current={page} totalItems={total} onPageChange={setPage} />
    </div>
  );
}

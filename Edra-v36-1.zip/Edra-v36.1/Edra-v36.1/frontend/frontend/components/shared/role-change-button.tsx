"use client";

// EDRA v27 — قابلیت تازه (گزارش کاربر، سپتامبر ۲۰۲۶): جایگزین امن برای
// تغییر نقش کاربر به‌جای دستکاری مستقیم چک‌باکس‌های is_staff/is_superuser
// یا لیست گروه‌ها در پنل خام جنگو (که کاربر آن را «گیج‌کننده و پرخطر»
// توصیف کرد). فقط سه گزینه‌ی واضح، با تاییدیه‌ی جدا برای اعطای نقش ادمین.

import * as React from "react";
import { useRouter } from "next/navigation";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { ShieldAlert, UserCog } from "lucide-react";
import { apiClientFetch } from "@/lib/api-client";

type Role = "customer" | "expert" | "admin";

const ROLE_LABELS: Record<Role, string> = {
  customer: "مشتری",
  expert: "کارشناس",
  admin: "ادمین",
};

interface RoleChangeButtonProps {
  userId: number;
  userDisplayName: string;
  currentRole: Role;
  /** اگر کاربر is_staff/is_superuser باشد، این دکمه اصلاً نباید نمایش
   * داده شود — چنین کاربری باید مستقیماً در پنل جنگو مدیریت شود. */
  disabled?: boolean;
}

export function RoleChangeButton({
  userId,
  userDisplayName,
  currentRole,
  disabled,
}: RoleChangeButtonProps) {
  const router = useRouter();
  const [open, setOpen] = React.useState(false);
  const [selectedRole, setSelectedRole] = React.useState<Role>(currentRole);
  const [confirming, setConfirming] = React.useState(false);
  const [saving, setSaving] = React.useState(false);

  if (disabled) {
    return (
      <Button variant="ghost" size="sm" disabled title="این کاربر دسترسی ویژه دارد و باید در پنل جنگو مدیریت شود">
        <UserCog className="size-3.5" />
        نقش: {ROLE_LABELS[currentRole]}
      </Button>
    );
  }

  const isDangerous = selectedRole === "admin";

  const handleOpenChange = (next: boolean) => {
    setOpen(next);
    if (!next) {
      setSelectedRole(currentRole);
      setConfirming(false);
    }
  };

  const submit = async () => {
    setSaving(true);
    try {
      await apiClientFetch(`/api/core/users/${userId}/set-role/`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ role: selectedRole }),
      });
      toast.success(`نقش ${userDisplayName} به «${ROLE_LABELS[selectedRole]}» تغییر یافت.`);
      setOpen(false);
      setConfirming(false);
      router.refresh();
    } catch (error: any) {
      toast.error(error?.message || "خطا در تغییر نقش. لطفاً دوباره تلاش کنید.");
    } finally {
      setSaving(false);
    }
  };

  return (
    <>
      <Button variant="ghost" size="sm" onClick={() => setOpen(true)}>
        <UserCog className="size-3.5" />
        نقش: {ROLE_LABELS[currentRole]}
      </Button>

      <Dialog open={open} onOpenChange={handleOpenChange}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>تغییر نقش {userDisplayName}</DialogTitle>
            <DialogDescription>
              نقش فعلی: <strong>{ROLE_LABELS[currentRole]}</strong>. نقش جدید را انتخاب کنید.
            </DialogDescription>
          </DialogHeader>

          <Select
            value={selectedRole}
            onValueChange={(v) => {
              setSelectedRole(v as Role);
              setConfirming(false);
            }}
          >
            <SelectTrigger>
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="customer">مشتری</SelectItem>
              <SelectItem value="expert">کارشناس</SelectItem>
              <SelectItem value="admin">ادمین</SelectItem>
            </SelectContent>
          </Select>

          {isDangerous && (
            <div className="flex items-start gap-2 rounded-md border border-destructive/30 bg-destructive/5 p-3 text-sm text-destructive">
              <ShieldAlert className="mt-0.5 size-4 shrink-0" />
              <p>
                این کاربر به تمام بخش‌های مدیریتی دسترسی کامل پیدا می‌کند. این عملیات فقط
                توسط سوپریوزر قابل انجام است و در تاریخچه‌ی ممیزی ثبت می‌شود.
              </p>
            </div>
          )}

          <div className="flex justify-end gap-2">
            <Button variant="outline" onClick={() => handleOpenChange(false)}>
              انصراف
            </Button>
            {isDangerous && !confirming ? (
              <Button
                variant="destructive"
                disabled={selectedRole === currentRole}
                onClick={() => setConfirming(true)}
              >
                ادامه برای اعطای دسترسی ادمین
              </Button>
            ) : (
              <Button
                variant={isDangerous ? "destructive" : "default"}
                disabled={selectedRole === currentRole || saving}
                onClick={submit}
              >
                {saving ? "در حال ذخیره..." : isDangerous ? "تایید نهایی و اعطای دسترسی ادمین" : "ذخیره تغییر نقش"}
              </Button>
            )}
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
}

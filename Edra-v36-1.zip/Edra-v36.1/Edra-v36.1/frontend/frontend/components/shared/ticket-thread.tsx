// components/shared/ticket-thread.tsx
"use client";

import * as React from "react";
import { useRouter } from "next/navigation";
import { toast } from "sonner";
import { Send, Loader2, Paperclip, Lock } from "lucide-react";

import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { cn } from "@/lib/utils";
import type { TicketDetail } from "@/types/ticket";

function initials(name: string) {
  const parts = name.trim().split(/\s+/);
  return ((parts[0]?.[0] ?? "") + (parts[1]?.[0] ?? "")) || "?";
}

export function TicketThread({
  ticket,
  currentUserId,
  isStaff,
}: {
  ticket: TicketDetail;
  currentUserId: number;
  isStaff: boolean;
}) {
  const router = useRouter();
  const [content, setContent] = React.useState("");
  const [isInternal, setIsInternal] = React.useState(false);
  const [submitting, setSubmitting] = React.useState(false);

  async function handleReply() {
    if (!content.trim()) return;
    setSubmitting(true);
    try {
      const res = await fetch(
        `/api/proxy/support/tickets/${ticket.id}/add_comment/`,
        {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ content, is_internal: isInternal }),
        }
      );
      if (res.ok) {
        setContent("");
        // EDRA v27 — رفع باگ واقعی (گزارش کاربر، سپتامبر ۲۰۲۶): این
        // چک‌باکس قبلاً بعد از ارسال موفق ریست نمی‌شد. اگر یک پشتیبان
        // یک «یادداشت داخلی» می‌فرستاد و بعد فراموش می‌کرد تیک را
        // بردارد، پاسخ عمومی بعدی‌اش هم به‌اشتباه internal ثبت می‌شد و
        // مشتری هرگز آن را نمی‌دید — دقیقاً همان «تیکت عملاً کار
        // نمی‌کند» که گزارش شده بود.
        setIsInternal(false);
        router.refresh();
      } else {
        // EDRA v27 — رفع باگ واقعی: قبلاً در صورت شکست، هیچ پیام خطایی
        // نشان داده نمی‌شد؛ کاربر فقط می‌دید دکمه چرخیدن را متوقف کرد و
        // فکر می‌کرد پاسخش ارسال شده، درحالی‌که نشده بود.
        const data = await res.json().catch(() => ({}));
        toast.error(data?.detail || data?.error || "ارسال پاسخ با خطا مواجه شد. دوباره تلاش کنید.");
      }
    } catch {
      toast.error("ارتباط با سرور برقرار نشد.");
    } finally {
      setSubmitting(false);
    }
  }

  const visibleComments = isStaff
    ? ticket.comments
    : ticket.comments.filter((c) => !c.is_internal);

  return (
    <div className="flex flex-col gap-4">
      <Card>
        <CardHeader>
          <div className="flex flex-wrap items-center justify-between gap-2">
            <CardTitle>{ticket.title}</CardTitle>
            <Badge variant="outline">{ticket.status_name}</Badge>
          </div>
        </CardHeader>
        <CardContent>
          <p className="text-sm leading-relaxed whitespace-pre-wrap">
            {ticket.description}
          </p>
          <div className="text-muted-foreground mt-4 flex flex-wrap gap-x-4 gap-y-1 text-xs">
            <span>ایجادکننده: {ticket.customer_name}</span>
            {ticket.assigned_to_name && (
              <span>مسئول: {ticket.assigned_to_name}</span>
            )}
            <span>{ticket.created_at_jalali}</span>
          </div>
        </CardContent>
      </Card>

      <div className="flex flex-col gap-3">
        {visibleComments.map((c) => (
          <div
            key={c.id}
            className={cn(
              "flex gap-3",
              // EDRA v27 — رفع باگ واقعی: قبلاً بر اساس user_name مقایسه
              // می‌شد؛ اگر دو کاربر نام یکسان داشتند (کاملاً محتمل)،
              // پیام‌ها در سمت اشتباه نمایش داده می‌شدند. حالا از شناسه‌ی
              // پایدار کاربر استفاده می‌شود.
              c.user === currentUserId && "flex-row-reverse"
            )}
          >
            <Avatar className="mt-0.5">
              <AvatarFallback
                className={cn(
                  c.is_internal
                    ? "bg-yellow-100 text-yellow-700"
                    : "bg-primary/10 text-primary"
                )}
              >
                {initials(c.user_name)}
              </AvatarFallback>
            </Avatar>
            <div
              className={cn(
                "flex max-w-[80%] flex-col gap-1 rounded-xl px-4 py-2.5 text-sm",
                c.is_internal
                  ? "bg-yellow-50 border-yellow-200 border"
                  : "bg-muted"
              )}
            >
              <div className="flex items-center gap-2">
                <span className="text-xs font-medium">{c.user_name}</span>
                {c.is_internal && (
                  <Badge
                    variant="outline"
                    className="h-4 px-1.5 text-[9px] border-yellow-400 text-yellow-700 bg-yellow-50"
                  >
                    <Lock className="size-2.5" />
                    داخلی
                  </Badge>
                )}
              </div>
              <p className="whitespace-pre-wrap">{c.content}</p>
              <span className="text-muted-foreground text-[10px]">
                {c.created_at_jalali}
              </span>
            </div>
          </div>
        ))}
      </div>

      <Card>
        <CardContent className="flex flex-col gap-3 px-4 py-4">
          <Textarea
            placeholder="پاسخ خود را بنویسید..."
            rows={3}
            value={content}
            onChange={(e) => setContent(e.target.value)}
          />
          <div className="flex items-center justify-between">
            {isStaff ? (
              <label className="text-muted-foreground flex items-center gap-1.5 text-xs">
                <input
                  type="checkbox"
                  checked={isInternal}
                  onChange={(e) => setIsInternal(e.target.checked)}
                />
                یادداشت داخلی (مشتری نمی‌بیند)
              </label>
            ) : (
              <span />
            )}
            <Button size="sm" onClick={handleReply} disabled={submitting || !content.trim()}>
              {submitting ? <Loader2 className="animate-spin" /> : <Send />}
              ارسال پاسخ
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
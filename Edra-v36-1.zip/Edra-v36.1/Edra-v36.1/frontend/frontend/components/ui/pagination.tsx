import Link from "next/link";
import { ChevronLeft, ChevronRight } from "lucide-react";
import { toPersianDigits } from "@/lib/jalali";

/**
 * EDRA v18+/v19 — صفحه‌بندی مینیمال (خاکستری/مشکی/سفید).
 * مخصوص سرورکامپوننت‌ها: navigation با Link و searchParams.
 * برای لیست‌های client از PaginationClient استفاده کنید.
 */
interface PaginationProps {
  current: number;
  totalItems: number;
  pageSize?: number;
  basePath: string;
}

export function Pagination({
  current,
  totalItems,
  pageSize = 25,
  basePath,
}: PaginationProps) {
  const totalPages = Math.max(1, Math.ceil(totalItems / pageSize));
  if (totalPages <= 1) return null;

  // EDRA v20 — root-cause (ممیزی v19): basePath هرگز نباید با // به
  // href بدل شود (protocol-relative → open redirect در <Link>). این
  // محافظ در خودِ کامپوننت است، نه فقط در محل‌های فراخوانی.
  const safeBasePath = (basePath || "/").replace(/^\/+/, "/") || "/";
  const link = (p: number) =>
    `${safeBasePath}${safeBasePath.includes("?") ? "&" : "?"}page=${p}`;

  return (
    <nav className="mt-6 flex items-center justify-between gap-3 border-t border-neutral-200 px-1 pt-4">
      <p className="text-sm text-neutral-500">
        {toPersianDigits(totalItems)} مورد
        <span className="mx-1.5 text-neutral-300">|</span>
        صفحه {toPersianDigits(current)} از {toPersianDigits(totalPages)}
      </p>
      <div className="flex items-center gap-2">
        <Link
          href={link(Math.max(1, current - 1))}
          aria-disabled={current <= 1}
          className={`inline-flex size-9 items-center justify-center rounded-lg border border-neutral-200 text-neutral-700 transition-colors hover:border-neutral-950 hover:bg-neutral-50 ${
            current <= 1 ? "pointer-events-none opacity-40" : ""
          }`}
        >
          <ChevronRight className="size-4" />
        </Link>
        <Link
          href={link(Math.min(totalPages, current + 1))}
          aria-disabled={current >= totalPages}
          className={`inline-flex size-9 items-center justify-center rounded-lg border border-neutral-200 text-neutral-700 transition-colors hover:border-neutral-950 hover:bg-neutral-50 ${
            current >= totalPages ? "pointer-events-none opacity-40" : ""
          }`}
        >
          <ChevronLeft className="size-4" />
        </Link>
      </div>
    </nav>
  );
}

/**
 * نسخه client-side (useState) برای صفحات react-query.
 */
interface PaginationClientProps {
  current: number;
  totalItems: number;
  pageSize?: number;
  onPageChange: (page: number) => void;
}

export function PaginationClient({
  current,
  totalItems,
  pageSize = 25,
  onPageChange,
}: PaginationClientProps) {
  const totalPages = Math.max(1, Math.ceil(totalItems / pageSize));
  if (totalPages <= 1) return null;

  const btn = (p: number, disabled: boolean, icon: React.ReactNode) => (
    <button
      type="button"
      onClick={() => !disabled && onPageChange(p)}
      disabled={disabled}
      className={`inline-flex size-9 items-center justify-center rounded-lg border border-neutral-200 text-neutral-700 transition-colors hover:border-neutral-950 hover:bg-neutral-50 disabled:pointer-events-none disabled:opacity-40`}
    >
      {icon}
    </button>
  );

  return (
    <nav className="mt-6 flex items-center justify-between gap-3 border-t border-neutral-200 px-1 pt-4">
      <p className="text-sm text-neutral-500">
        {toPersianDigits(totalItems)} مورد
        <span className="mx-1.5 text-neutral-300">|</span>
        صفحه {toPersianDigits(current)} از {toPersianDigits(totalPages)}
      </p>
      <div className="flex items-center gap-2">
        {btn(Math.max(1, current - 1), current <= 1, <ChevronRight className="size-4" />)}
        {btn(Math.min(totalPages, current + 1), current >= totalPages, <ChevronLeft className="size-4" />)}
      </div>
    </nav>
  );
}

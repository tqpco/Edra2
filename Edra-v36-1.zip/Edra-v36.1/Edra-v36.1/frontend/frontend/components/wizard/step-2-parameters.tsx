// components/wizard/step-2-parameters.tsx
"use client";

import * as React from "react";
import { useQuery } from "@tanstack/react-query";
import { Settings2 } from "lucide-react";

import { Card, CardHeader, CardTitle, CardDescription, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import {
  Select,
  SelectTrigger,
  SelectValue,
  SelectContent,
  SelectItem,
} from "@/components/ui/select";
import { WizardFooter } from "./wizard-footer";
import { useWizardStore } from "@/lib/wizard-store";
import type { EquipmentType } from "@/types/equipment";

async function fetchEquipmentType(id: number): Promise<EquipmentType> {
  const res = await fetch(`/api/proxy/core/equipment-types/${id}/`);
  if (!res.ok) throw new Error("خطا در دریافت مشخصات تجهیزات");
  return res.json();
}

export function StepParameters() {
  const {
    equipmentTypeId,
    equipmentName,
    params,
    installState,
    setParams,
    setInstallState,
    setStep,
  } = useWizardStore();

  const { data: equipment, isLoading } = useQuery({
    queryKey: ["equipment-type", equipmentTypeId],
    queryFn: () => fetchEquipmentType(equipmentTypeId!),
    enabled: !!equipmentTypeId,
    staleTime: 5 * 60 * 1000,
  });

  const schema = equipment?.param_schema ?? [];

  const requiredFilled = schema
    .filter((f) => f.required)
    .every((f) => {
      const v = params[f.name];
      return v !== undefined && v !== null && v !== "";
    });

  const installOk = !equipment?.install_state_required || !!installState;
  const canContinue = requiredFilled && installOk;

  const updateParam = React.useCallback(
    (name: string, value: string | number | boolean) => {
      setParams({ ...params, [name]: value });
    },
    [params, setParams]
  );

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Settings2 className="size-5" />
          مشخصات فنی {equipmentName}
        </CardTitle>
        <CardDescription>
          این اطلاعات مستقیماً روی محاسبه‌ی قیمت بازرسی تاثیر می‌گذارد
        </CardDescription>
      </CardHeader>
      <CardContent className="flex flex-col gap-5">
        {isLoading && (
          <p className="text-muted-foreground text-sm">در حال بارگذاری...</p>
        )}

        {schema.map((field) => (
          <div key={field.name} className="grid gap-2">
            <Label htmlFor={`param-${field.name}`}>
              {field.label}
              {field.required && <span className="text-destructive">*</span>}
            </Label>
            {field.type === "select" && field.options?.length ? (
              <Select
                value={params[field.name] ? String(params[field.name]) : undefined}
                onValueChange={(v) => updateParam(field.name, v)}
              >
                <SelectTrigger id={`param-${field.name}`} className="w-full">
                  <SelectValue placeholder="انتخاب کنید..." />
                </SelectTrigger>
                <SelectContent>
                  {field.options.map((opt) => (
                    <SelectItem key={opt} value={opt}>
                      {opt}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            ) : field.type === "number" ? (
              <Input
                id={`param-${field.name}`}
                type="number"
                inputMode="decimal"
                value={(params[field.name] as string | number) ?? ""}
                onChange={(e) => updateParam(field.name, e.target.value)}
              />
            ) : field.type === "boolean" ? (
              <div className="flex items-center gap-3 pt-1">
                <RadioGroup
                  // EDRA v27 — رفع باگ واقعی (گزارش کاربر): قبلاً وقتی
                  // مقدار هنوز تعیین نشده بود (undefined)، به‌خاطر
                  // falsy بودن، گزینه‌ی «خیر» به‌اشتباه انتخاب‌شده نشان
                  // داده می‌شد — کاربر فکر می‌کرد پاسخ داده، ولی دکمه‌ی
                  // بعدی همچنان (به‌درستی) غیرفعال می‌ماند، بدون هیچ
                  // دلیل قابل‌مشاهده‌ای.
                  value={
                    params[field.name] === undefined
                      ? undefined
                      : params[field.name]
                        ? "true"
                        : "false"
                  }
                  onValueChange={(val) => updateParam(field.name, val === "true")}
                  className="flex gap-4"
                >
                  <div className="flex items-center gap-2">
                    <RadioGroupItem value="true" id={`${field.name}-true`} />
                    <Label htmlFor={`${field.name}-true`}>بله</Label>
                  </div>
                  <div className="flex items-center gap-2">
                    <RadioGroupItem value="false" id={`${field.name}-false`} />
                    <Label htmlFor={`${field.name}-false`}>خیر</Label>
                  </div>
                </RadioGroup>
              </div>
            ) : field.type === "date" || field.type === "time" ? (
              // EDRA v32: مدل EquipmentParameter شش نوع فیلد دارد
              // (string/number/select/boolean/date/time) ولی اینجا فقط سه‌تای
              // اول هندل می‌شدند؛ date/time به کادر متنی خام می‌افتادند —
              // کاربر مجبور بود تاریخ/زمان را دستی و بدون قالب مشخص تایپ
              // کند. فعلاً هیچ پارامتر واقعی از این دو نوع استفاده نمی‌کند
              // (بررسی شد)، ولی اگر در آینده اضافه شود این مشکل همین الان
              // رفع است.
              <Input
                id={`param-${field.name}`}
                type={field.type}
                value={(params[field.name] as string) ?? ""}
                onChange={(e) => updateParam(field.name, e.target.value)}
              />
            ) : (
              <Input
                id={`param-${field.name}`}
                value={(params[field.name] as string) ?? ""}
                onChange={(e) => updateParam(field.name, e.target.value)}
              />
            )}
          </div>
        ))}

        {equipment?.supports_install_state && (
          <div className="grid gap-2">
            <Label>
              وضعیت استقرار دستگاه
              {equipment.install_state_required && (
                <span className="text-destructive">*</span>
              )}
            </Label>
            <RadioGroup
              value={installState ?? ""}
              onValueChange={setInstallState}
              className="grid grid-cols-2 gap-3"
            >
              <Label
                htmlFor="install-installed"
                className="hover:bg-accent flex cursor-pointer items-center gap-2 rounded-md border p-3 has-[[data-state=checked]]:border-primary has-[[data-state=checked]]:bg-primary/5"
              >
                <RadioGroupItem value="installed" id="install-installed" />
                دستگاه نصب می‌باشد
              </Label>
              <Label
                htmlFor="install-dismantled"
                className="hover:bg-accent flex cursor-pointer items-center gap-2 rounded-md border p-3 has-[[data-state=checked]]:border-primary has-[[data-state=checked]]:bg-primary/5"
              >
                <RadioGroupItem value="dismantled" id="install-dismantled" />
                دستگاه دمونتاژ می‌باشد
              </Label>
            </RadioGroup>
          </div>
        )}
      </CardContent>
      <CardContent>
        <WizardFooter
          onBack={() => setStep(1)}
          onNext={() => setStep(3)}
          nextDisabled={!canContinue}
        />
      </CardContent>
    </Card>
  );
}
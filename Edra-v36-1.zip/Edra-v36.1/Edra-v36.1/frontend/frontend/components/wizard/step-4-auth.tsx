"use client";

import * as React from "react";
import { useQueryClient } from "@tanstack/react-query";
import { Phone, ShieldAlert, ArrowRight, Loader2, UserCheck } from "lucide-react";

import { Card, CardHeader, CardTitle, CardDescription, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { WizardFooter } from "./wizard-footer";
import { useWizardStore } from "@/lib/wizard-store";
import { toPersianDigits, toEnglishDigits } from "@/lib/jalali";
import { useAuth } from "@/hooks/use-auth";
import { useWebOtp } from "@/hooks/use-web-otp";

export function StepAuth() {
  const setStep = useWizardStore((s) => s.setStep);
  const queryClient = useQueryClient();
  // EDRA v25 — root-cause فیکس: قبلاً این مرحله همیشه فرم شماره/کد را نشان
  // می‌داد، حتی برای کاربری که از قبل لاگین بود (مثلاً از داشبورد روی
  // «رزرو جدید» زده). نتیجه دو مشکل بود: (۱) کاربر دوباره مجبور به تایید
  // OTP می‌شد، و (۲) اگر در همین فرم یک شماره‌ی دیگر وارد می‌کرد، session
  // بی‌صدا به آن اکانت دیگر سوییچ می‌شد و درخواست نهایی زیر اکانت اشتباه
  // ثبت می‌گشت. راه‌حل: اگر از قبل لاگین است، اصلاً فرم شماره/کد نشان داده
  // نمی‌شود — به‌جایش یک تاییدیه‌ی هویت با گزینه‌ی صریح و امن «این حساب من
  // نیست» (که از مسیر رسمی logout رد می‌شود، نه سوییچ بی‌صدا).
  const { user, isLoading: authLoading, isAuthenticated, logout } = useAuth();

  const [phase, setPhase] = React.useState<"phone" | "code">("phone");
  const [phone, setPhone] = React.useState("");
  const [code, setCode] = React.useState("");
  const [error, setError] = React.useState<string | null>(null);
  const [loading, setLoading] = React.useState(false);
  const [seconds, setSeconds] = React.useState(0);
  const [loggingOut, setLoggingOut] = React.useState(false);

  React.useEffect(() => {
    if (seconds <= 0) return;
    const t = setInterval(() => setSeconds((s: number) => s - 1), 1000);
    return () => clearInterval(t);
  }, [seconds]);

  async function requestCode() {
    setError(null);
    const normalized = toEnglishDigits(phone);
    if (!/^09\d{9}$/.test(normalized)) {
      setError("شماره موبایل معتبر نیست (مثال: ۰۹۱۲۳۴۵۶۷۸۹)");
      return;
    }
    setLoading(true);
    try {
      const res = await fetch("/api/auth/otp-request", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ phone: normalized }),
      });
      const data = await res.json();
      if (!res.ok) {
        setError(data.error || data.detail || "ارسال کد ناموفق بود.");
        return;
      }
      setPhone(normalized);
      setPhase("code");
      setSeconds(120);
    } catch {
      setError("ارتباط با سرور برقرار نشد.");
    } finally {
      setLoading(false);
    }
  }

  // codeOverride برای تکمیل خودکار WebOTP لازم است: چون setCode ناهمزمان
  // است، اگر مستقیم بعد از setCode(otpCode) این تابع را صدا بزنیم، هنوز
  // مقدار قدیمیِ state را می‌بیند؛ با override مقدار تازه مستقیم پاس داده می‌شود.
  async function verifyCode(codeOverride?: string) {
    setError(null);
    const normalizedCode = toEnglishDigits(codeOverride ?? code);
    if (!/^\d{6}$/.test(normalizedCode)) {
      setError("کد تایید باید ۶ رقم باشد");
      return;
    }
    setLoading(true);
    try {
      const res = await fetch("/api/auth/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ phone, code: normalizedCode }),
      });
      const data = await res.json();
      if (!res.ok) {
        setError(data.error || data.detail || "کد وارد شده نامعتبر است.");
        return;
      }
      queryClient.setQueryData(["current-user"], data.user);
      setStep(5);
    } catch {
      setError("ارتباط با سرور برقرار نشد.");
    } finally {
      setLoading(false);
    }
  }

  // تکمیل خودکار کد OTP از پیامک (WebOTP API) — فقط در مرحله‌ی کد فعال است
  useWebOtp((otpCode) => {
    setCode(otpCode);
    verifyCode(otpCode);
  }, phase === "code");

  async function handleNotMyAccount() {
    setLoggingOut(true);
    try {
      await logout();
    } finally {
      setLoggingOut(false);
    }
  }

  // در حال بررسی وضعیت لاگین فعلی — فرم را قبل از این چک نشان نمی‌دهیم
  if (authLoading) {
    return (
      <Card>
        <CardContent className="flex flex-col items-center justify-center gap-3 py-12 text-muted-foreground">
          <Loader2 className="size-6 animate-spin" />
          <span className="text-sm">در حال بررسی ورود...</span>
        </CardContent>
      </Card>
    );
  }

  // کاربر از قبل لاگین است — دیگر فرم شماره/کد نشان داده نمی‌شود
  if (isAuthenticated && user) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <UserCheck className="size-5 text-primary" />
            هویت شما تایید شد
          </CardTitle>
          <CardDescription>
            شما با حساب «{user.full_name || toPersianDigits(user.username)}» وارد شده‌اید.
            این رزرو زیر همین حساب ثبت می‌شود.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <button
            type="button"
            onClick={handleNotMyAccount}
            disabled={loggingOut}
            className="text-muted-foreground hover:text-foreground inline-flex items-center gap-1.5 text-sm disabled:opacity-60"
          >
            {loggingOut && <Loader2 className="size-3.5 animate-spin" />}
            این حساب من نیست — خروج و ورود با شماره‌ی دیگر
          </button>
        </CardContent>
        <CardContent>
          <WizardFooter
            onBack={() => setStep(3)}
            onNext={() => setStep(5)}
            nextLabel="ادامه"
            isLoading={false}
          />
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Phone className="size-5" />
          ورود با شماره موبایل
        </CardTitle>
        <CardDescription>
          برای ادامه‌ی رزرو، شماره موبایل خود را تایید کنید (در صورت نبود حساب،
          به‌صورت خودکار برای شما ساخته می‌شود)
        </CardDescription>
      </CardHeader>
      <CardContent className="flex flex-col gap-4">
        {error && (
          <Alert variant="destructive">
            <ShieldAlert />
            <AlertDescription>{error}</AlertDescription>
          </Alert>
        )}

        {phase === "phone" ? (
          <div className="grid gap-2">
            <Label htmlFor="wizard-phone">شماره موبایل</Label>
            <Input
              id="wizard-phone"
              dir="ltr"
              inputMode="numeric"
              autoComplete="tel"
              className="text-center tracking-widest"
              placeholder="09123456789"
              value={phone}
              onChange={(e) => setPhone(e.target.value)}
            />
          </div>
        ) : (
          <div className="grid gap-2">
            <Label htmlFor="wizard-code">
              کد ۶ رقمی ارسال‌شده به {toPersianDigits(phone)}
            </Label>
            <Input
              id="wizard-code"
              dir="ltr"
              inputMode="numeric"
              maxLength={6}
              autoFocus
              autoComplete="one-time-code"
              className="text-center text-lg tracking-[0.5em]"
              placeholder="------"
              value={code}
              onChange={(e) => setCode(e.target.value)}
            />
            <div className="flex items-center justify-between text-sm">
              <button
                type="button"
                onClick={() => setPhase("phone")}
                className="text-muted-foreground hover:text-foreground inline-flex items-center gap-1"
              >
                <ArrowRight className="size-3.5" />
                تغییر شماره
              </button>
              {seconds > 0 ? (
                <span className="text-muted-foreground">
                  ارسال مجدد تا {toPersianDigits(seconds)} ثانیه
                </span>
              ) : (
                <button
                  type="button"
                  className="text-primary hover:underline"
                  onClick={requestCode}
                >
                  ارسال مجدد کد
                </button>
              )}
            </div>
          </div>
        )}
      </CardContent>
      <CardContent>
        <WizardFooter
          onBack={() => setStep(3)}
          onNext={phase === "phone" ? requestCode : () => verifyCode()}
          nextLabel={phase === "phone" ? "دریافت کد" : "تایید و ادامه"}
          isLoading={loading}
        />
      </CardContent>
    </Card>
  );
}

// components/wizard/step-5-scheduling.tsx
"use client";

import * as React from "react";
import { ChevronRight, ChevronLeft, Clock, CalendarDays, CheckCircle2 } from "lucide-react";

import { Card, CardHeader, CardTitle, CardDescription, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import { WizardFooter } from "./wizard-footer";
import { useWizardStore } from "@/lib/wizard-store";
import {
  dateToJalali,
  jalaliToDate,
  jalaliMonthLength,
  toPersianDigits,
  JALALI_MONTH_NAMES,
  formatJalaliWithWeekday,
  formatPersianTime,
} from "@/lib/jalali";


import { getAccurateDateTime } from "@/lib/edra_jalalidate/ntp";

const WEEKDAY_HEADER = ["ش", "ی", "د", "س", "چ", "پ", "ج"];

// ساعت‌های کاری (۸ تا ۱۶ با بازه ۳۰ دقیقه)
const ALL_TIME_SLOTS = (() => {
  const slots: string[] = [];
  for (let h = 8; h < 16; h++) {
    slots.push(`${String(h).padStart(2, "0")}:00`);
    slots.push(`${String(h).padStart(2, "0")}:30`);
  }
  return slots;
})();

// ===== توابع کمکی (اصلاح شده) =====
function isWorkingDay(date: Date): boolean {
  const day = date.getDay(); // 0=Sunday, 1=Monday, ... 6=Saturday
  // در تقویم ایران جمعه = 5 (Friday)
  return day !== 5;
}

function toDateOnly(d: Date): Date {
  return new Date(d.getFullYear(), d.getMonth(), d.getDate());
}

function getEarliestBookableDate(today: Date): Date {
  let candidate = new Date(today);
  // اگر امروز جمعه است، فردا را امتحان کن
  while (!isWorkingDay(candidate)) {
    candidate.setDate(candidate.getDate() + 1);
  }
  candidate.setHours(0, 0, 0, 0);
  return candidate;
}

export function StepScheduling() {
  const { scheduledAt, setScheduledAt, setStep } = useWizardStore();

  // EDRA v27 — قابلیت تازه (گزارش کاربر، سپتامبر ۲۰۲۶): «چون ممکنه
  // ساعت کامپیوتر و موبایل اشتباه کنه». قبلاً «امروز» و «الان» مستقیماً
  // از new Date() دستگاه کاربر خوانده می‌شد — اگر ساعت گوشی/کامپیوتر
  // مشتری اشتباه بود، محاسبه‌ی «اولین روز قابل‌رزرو» و «حداقل ۳ ساعت
  // فاصله» هم اشتباه می‌شد. حالا زمان از سرور (NTP-synced، با fallback
  // امن به ساعت سیستم در صورت قطعی شبکه) خوانده می‌شود.
  const [now, setNow] = React.useState<Date>(() => new Date());
  React.useEffect(() => {
    let cancelled = false;
    getAccurateDateTime(true).then((dt) => {
      if (!cancelled) setNow(dt);
    });
    return () => {
      cancelled = true;
    };
  }, []);

  const today = React.useMemo(() => toDateOnly(now), [now]);
  const earliest = React.useMemo(() => getEarliestBookableDate(today), [today]);
  const earliestJalali = React.useMemo(() => dateToJalali(earliest), [earliest]);

  const [viewYear, setViewYear] = React.useState<number>(earliestJalali.year);
  const [viewMonth, setViewMonth] = React.useState<number>(earliestJalali.month);
  const hasManuallyNavigated = React.useRef(false);
  React.useEffect(() => {
    // اگر کاربر خودش ماه را عوض نکرده، وقتی زمان دقیق سرور برسد (که
    // می‌تواند با ساعت اولیه‌ی سیستم فرق داشته باشد)، نمای تقویم را با
    // آن هماهنگ کن.
    if (!hasManuallyNavigated.current) {
      setViewYear(earliestJalali.year);
      setViewMonth(earliestJalali.month);
    }
  }, [earliestJalali.year, earliestJalali.month]);
  const [selectedDate, setSelectedDate] = React.useState<Date | null>(
    scheduledAt ? new Date(scheduledAt) : null
  );
  const [selectedTime, setSelectedTime] = React.useState<string | null>(
    scheduledAt
      ? `${String(new Date(scheduledAt).getHours()).padStart(2, "0")}:${String(
          new Date(scheduledAt).getMinutes()
        ).padStart(2, "0")}`
      : null
  );

  const monthLength = jalaliMonthLength(viewYear, viewMonth);
  const firstOfMonth = jalaliToDate(viewYear, viewMonth, 1);
  const leadingBlanks = (firstOfMonth.getDay() + 1) % 7;

  const days = React.useMemo(() => {
    const result: (Date | null)[] = Array(leadingBlanks).fill(null);
    for (let i = 1; i <= monthLength; i++) {
      result.push(jalaliToDate(viewYear, viewMonth, i));
    }
    return result;
  }, [viewYear, viewMonth, leadingBlanks, monthLength]);

  // بررسی قابل انتخاب بودن تاریخ
  const isSelectableDate = React.useCallback(
    (d: Date) => {
      // تاریخ باید از امروز به بعد باشد
      if (d < today) return false;
      // روز باید کاری باشد (جمعه نباشد)
      if (!isWorkingDay(d)) return false;
      return true;
    },
    [today]
  );

  // بررسی قابل انتخاب بودن ساعت
  const isSelectableTime = React.useCallback(
    (slot: string) => {
      if (!selectedDate) return false;

      const [h, m] = slot.split(":").map(Number);

      // اگر تاریخ انتخاب شده امروز است
      if (selectedDate.toDateString() === today.toDateString()) {
        // حداقل ۳ ساعت بعد از زمان فعلی (دقیق سرور، نه ساعت دستگاه کاربر)
        const minHour = now.getHours() + 3;
        const minMinute = now.getMinutes();

        if (h! < minHour) return false;
        if (h! === minHour && m! < minMinute) return false;
      }

      return true;
    },
    [selectedDate, today, now]
  );

  const goPrevMonth = React.useCallback((): void => {
    hasManuallyNavigated.current = true;
    if (viewMonth === 1) {
      setViewMonth(12);
      setViewYear((prevYear: number) => prevYear - 1);
    } else {
      setViewMonth((prevMonth: number) => prevMonth - 1);
    }
  }, [viewMonth]);

  const goNextMonth = React.useCallback((): void => {
    hasManuallyNavigated.current = true;
    if (viewMonth === 12) {
      setViewMonth(1);
      setViewYear((prevYear: number) => prevYear + 1);
    } else {
      setViewMonth((prevMonth: number) => prevMonth + 1);
    }
  }, [viewMonth]);

  const handleNext = React.useCallback((): void => {
    if (!selectedDate || !selectedTime) return;
    const [h, m] = selectedTime.split(":").map(Number);
    // EDRA v27 — رفع باگ واقعی (گزارش کاربر، سپتامبر ۲۰۲۶): «چون ممکنه
    // ساعت کامپیوتر و موبایل اشتباه کنه». قبلاً از
    // `combined.toISOString()` استفاده می‌شد که ساعت محلی را بر اساس
    // timezone خودِ مرورگر/سیستم‌عامل کاربر به UTC تبدیل می‌کند — اگر
    // timezone دستگاه کاربر اشتباه تنظیم شده باشد (نه فقط ساعت، بلکه
    // منطقه‌ی زمانی)، لحظه‌ی واقعی ارسالی به بک‌اند می‌تواند ساعت‌ها جابه‌جا
    // شود. چون تاریخ/ساعت انتخابی همیشه به‌معنای «ساعت ایران» است (نه
    // هرچه مرورگر حدس می‌زند)، اینجا رشته‌ی ISO را با افست ثابت +۰۳:۳۰
    // (ایران، بدون DST) می‌سازیم — مستقل از timezone دستگاه کاربر.
    const y = selectedDate.getFullYear();
    const mo = String(selectedDate.getMonth() + 1).padStart(2, "0");
    const da = String(selectedDate.getDate()).padStart(2, "0");
    const hh = String(h).padStart(2, "0");
    const mm = String(m).padStart(2, "0");
    setScheduledAt(`${y}-${mo}-${da}T${hh}:${mm}:00+03:30`);
    setStep(6);
  }, [selectedDate, selectedTime, setScheduledAt, setStep]);

  // نمایش خلاصه انتخاب
  const selectedDateFormatted = selectedDate
    ? formatJalaliWithWeekday(selectedDate)
    : "";
  const selectedTimeFormatted = selectedTime
    ? formatPersianTime(new Date(`2000-01-01T${selectedTime}:00`))
    : "";

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <CalendarDays className="size-5" />
          زمان کارشناسی
        </CardTitle>
        <CardDescription>
          جمعه‌ها تعطیل است و فقط بین ساعت ۸ تا ۱۶ قابل رزرو است
          {selectedDate?.toDateString() === today.toDateString() &&
            " (امروز: حداقل ۳ ساعت بعد از زمان فعلی)"}
        </CardDescription>
      </CardHeader>
      <CardContent className="flex flex-col gap-6">
        {/* تقویم با اندازه کوچکتر */}
        <div className="max-w-sm mx-auto w-full">
          <div className="mb-3 flex items-center justify-between">
            <Button variant="ghost" size="icon" onClick={goPrevMonth} className="h-8 w-8">
              <ChevronRight className="size-4" />
            </Button>
            <span className="text-sm font-medium">
              {JALALI_MONTH_NAMES[viewMonth - 1]} {toPersianDigits(viewYear)}
            </span>
            <Button variant="ghost" size="icon" onClick={goNextMonth} className="h-8 w-8">
              <ChevronLeft className="size-4" />
            </Button>
          </div>
          <div className="grid grid-cols-7 gap-1 text-center text-xs">
            {WEEKDAY_HEADER.map((d) => (
              <span key={d} className="text-muted-foreground py-1">
                {d}
              </span>
            ))}
            {days.map((d, i) => {
              if (!d) return <span key={`blank-${i}`} className="aspect-square" />;
              const selectable = isSelectableDate(d);
              const isSelected =
                selectedDate && d.toDateString() === selectedDate.toDateString();
              const jd = dateToJalali(d);
              const isToday = d.toDateString() === today.toDateString();
              return (
                <button
                  key={i}
                  type="button"
                  disabled={!selectable}
                  onClick={() => {
                    setSelectedDate(d);
                    setSelectedTime(null);
                  }}
                  className={cn(
                    "aspect-square rounded-md text-sm transition-colors relative",
                    !selectable && "text-muted-foreground/40 cursor-not-allowed",
                    selectable && !isSelected && "hover:bg-accent hover:text-accent-foreground",
                    isSelected && "bg-primary text-primary-foreground font-medium",
                    isToday && !isSelected && "border border-primary/30"
                  )}
                >
                  {toPersianDigits(jd.day)}
                  {isToday && (
                    <span className="absolute -top-1 -right-1 size-1.5 rounded-full bg-primary" />
                  )}
                </button>
              );
            })}
          </div>
        </div>

        {/* انتخاب ساعت */}
        {selectedDate && (
          <div className="grid gap-2 max-w-sm mx-auto w-full">
            <p className="flex items-center gap-1.5 text-sm font-medium">
              <Clock className="size-4" />
              ساعت کارشناسی
            </p>
            <div className="grid grid-cols-4 gap-2 sm:grid-cols-6">
              {ALL_TIME_SLOTS.map((slot: string) => {
                const selectable = isSelectableTime(slot);
                const isSelected = selectedTime === slot;
                return (
                  <button
                    key={slot}
                    type="button"
                    disabled={!selectable}
                    onClick={() => setSelectedTime(slot)}
                    className={cn(
                      "rounded-md border py-1.5 text-sm transition-colors",
                      !selectable && "opacity-40 cursor-not-allowed text-muted-foreground",
                      selectable && !isSelected && "hover:border-primary/40 hover:bg-accent",
                      isSelected && "border-primary bg-primary text-primary-foreground"
                    )}
                  >
                    {toPersianDigits(slot)}
                  </button>
                );
              })}
            </div>
          </div>
        )}

        {/* خلاصه انتخاب */}
        <div className="border-t pt-4 mt-2">
          <div className="flex items-center justify-between text-sm">
            <span className="text-muted-foreground">تاریخ و ساعت انتخاب‌شده:</span>
            <span className="font-medium">
              {selectedDate && selectedTime ? (
                <>
                  {selectedDateFormatted} ساعت {selectedTimeFormatted}
                </>
              ) : (
                <span className="text-muted-foreground">هیچ تاریخی انتخاب نشده است</span>
              )}
            </span>
          </div>
          {selectedDate && selectedTime && (
            <div className="mt-2 flex items-center gap-2 text-xs text-muted-foreground">
              <CheckCircle2 className="size-3.5 text-primary" />
              <span>تاریخ و ساعت مورد نظر انتخاب شد</span>
            </div>
          )}
        </div>
      </CardContent>
      <CardContent>
        <WizardFooter
          onBack={() => setStep(4)}
          onNext={handleNext}
          nextDisabled={!selectedDate || !selectedTime}
        />
      </CardContent>
    </Card>
  );
}
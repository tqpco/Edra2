// components/wizard/step-7-review.tsx
"use client";

import * as React from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import {
  FileText,
  MapPin,
  Calendar,
  Wallet,
  Tag,
  Loader2,
  CheckCircle2,
  XCircle,
  AlertCircle,
} from "lucide-react";

import { Card, CardHeader, CardTitle, CardDescription, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { WizardFooter } from "./wizard-footer";
import { useWizardStore } from "@/lib/wizard-store";
import { formatToman } from "@/lib/format";
import { formatJalaliWithWeekday, formatPersianTime } from "@/lib/jalali";

interface PricePreviewResponse {
  total_price: number;
  city_multiplier: number;
  city_base_cost: number;
  discount_amount: number;
  discount_error: string | null;
  tax_rate_percent: number;
  tax_amount: number;
  final_amount: number;
  credit_balance: number;
  max_usable_credit: number;
  credit_used: number;
  final_payable: number;
  has_discount: boolean;
}

interface DiscountValidationResponse {
  valid: boolean;
  code: string;
  discount_type: string;
  value: number;
  max_amount: number | null;
  min_amount: number | null;
  expires_at: string | null;
  message?: string;
}

// EDRA v27 — رفع بدهی فنی (گزارش کاربر، سپتامبر ۲۰۲۶): این پروژه کاملاً
// بر پایه‌ی کوکی httpOnly است — login هیچ‌وقت چیزی در localStorage
// نمی‌نویسد، پس getAuthToken() همیشه null بود و هدر Authorization دستی
// اینجا هرگز واقعاً اضافه نمی‌شد (درخواست‌ها به لطف کوکی httpOnly که
// خودِ پروکسی می‌خواند، همچنان کار می‌کردند — این کد مرده بود، نه
// شکسته، ولی در تناقض با معماری واقعی پروژه و گمراه‌کننده برای توسعه‌ی
// بعدی بود).
function getHeaders(): HeadersInit {
  return { "Content-Type": "application/json" };
}

async function fetchPricePreview(payload: Record<string, unknown>): Promise<PricePreviewResponse> {
  const res = await fetch("/api/proxy/pricing/calculate/", {
    method: "POST",
    headers: getHeaders(),
    body: JSON.stringify(payload),
    credentials: "include",
  });
  if (res.status === 401) throw new Error("نشست شما منقضی شده است.");
  if (!res.ok) {
    let msg = "خطا در محاسبه قیمت";
    try { const err = await res.json(); msg = err.error || msg; } catch {}
    throw new Error(msg);
  }
  return res.json();
}

async function validateDiscountCode(
  code: string,
  equipmentTypeId?: number,
  amount?: number
): Promise<DiscountValidationResponse> {
  const res = await fetch("/api/proxy/core/discount-codes/validate/", {
    method: "POST",
    headers: getHeaders(),
    body: JSON.stringify({ code, equipment_type_id: equipmentTypeId, amount: amount || 0 }),
    credentials: "include",
  });
  if (res.status === 401) {
    return { valid: false, code: "", discount_type: "", value: 0, max_amount: null, min_amount: null, expires_at: null, message: "نشست شما منقضی شده است." };
  }
  if (!res.ok) {
    let msg = "خطا در اعتبارسنجی کد تخفیف";
    try { const err = await res.json(); msg = err.error || err.message || msg; } catch {}
    return { valid: false, code: "", discount_type: "", value: 0, max_amount: null, min_amount: null, expires_at: null, message: msg };
  }
  return res.json();
}

export function StepReview() {
  const store = useWizardStore();
  const {
    equipmentName, city, serviceType, scheduledAt, applicantName, companyName, projectName, address,
    discountCode, setDiscountCode, useCreditAmount, setUseCreditAmount, setStep,
    setCreatedRequest, equipmentTypeId, params, installState, addressLat, addressLng,
    setFinalWithTax, // ✅ اضافه شد
  } = store;

  const [discountInput, setDiscountInput] = React.useState(discountCode || "");
  const [isDiscountApplied, setIsDiscountApplied] = React.useState(!!discountCode);
  const [isValidatingDiscount, setIsValidatingDiscount] = React.useState(false);
  const [discountError, setDiscountError] = React.useState<string | null>(null);
  const [submitting, setSubmitting] = React.useState(false);
  const [error, setError] = React.useState<string | null>(null);
  const [creditInput, setCreditInput] = React.useState<string>(String(useCreditAmount || ""));

  const {
    data: priceData,
    isLoading: isPriceLoading,
    refetch: refetchPrice,
    error: priceError,
    isFetching,
  } = useQuery({
    queryKey: ["price-preview", equipmentTypeId, city, serviceType, JSON.stringify(params ?? {}), installState, discountCode, useCreditAmount],
    queryFn: () => fetchPricePreview({
      equipment_type_id: equipmentTypeId,
      params: params ?? {},
      install_state: installState,
      service_type: serviceType,
      city: city,
      discount_code: discountCode || undefined,
      credit_amount: useCreditAmount || 0,
    }),
    enabled: !!equipmentTypeId && !!city,
    staleTime: 0,
    retry: 1,
  });

  const validateMutation = useMutation({
    mutationFn: (code: string) => validateDiscountCode(code, equipmentTypeId ?? undefined, priceData?.total_price || 0),
    onSuccess: (data) => {
      if (data.valid) {
        setDiscountCode(data.code);
        setIsDiscountApplied(true);
        setDiscountError(null);
        refetchPrice();
      } else {
        setDiscountError(data.message || "کد تخفیف نامعتبر است");
        setIsDiscountApplied(false);
        setDiscountCode("");
      }
      setIsValidatingDiscount(false);
    },
    onError: (err: Error) => {
      setDiscountError(err.message || "خطا در اعتبارسنجی کد تخفیف");
      setIsValidatingDiscount(false);
      setIsDiscountApplied(false);
      setDiscountCode("");
    },
  });

  const price = priceData?.total_price ?? 0;
  const finalWithTax = priceData?.final_amount ?? 0;
  const finalPayable = priceData?.final_payable ?? 0;
  const creditBalance = priceData?.credit_balance ?? 0;
  const maxCredit = priceData?.max_usable_credit ?? 0;
  const discountAmount = priceData?.discount_amount ?? 0;
  const cityMultiplier = priceData?.city_multiplier ?? 1;
  const cityBaseCost = priceData?.city_base_cost ?? 0;
  const taxRate = priceData?.tax_rate_percent ?? 0;
  const taxAmount = priceData?.tax_amount ?? 0;

  const hasError = !!discountError || !!error || !!priceError;
  const isBusy = isPriceLoading || isFetching || submitting || isValidatingDiscount;

  const handleApplyDiscount = React.useCallback(async () => {
    const code = discountInput.trim();
    if (!code) { setDiscountError("لطفاً کد تخفیف را وارد کنید"); return; }
    setDiscountError(null);
    setIsValidatingDiscount(true);
    await validateMutation.mutateAsync(code);
  }, [discountInput, validateMutation]);

  const handleRemoveDiscount = React.useCallback(() => {
    setDiscountCode("");
    setDiscountInput("");
    setIsDiscountApplied(false);
    setDiscountError(null);
    refetchPrice();
  }, [setDiscountCode, refetchPrice]);

  const handleCreditChange = React.useCallback((value: string) => {
    const num = Number(value);
    if (isNaN(num) || num < 0) { setCreditInput(value); return; }
    const clamped = Math.min(num, maxCredit);
    setCreditInput(String(clamped));
    setUseCreditAmount(clamped);
    refetchPrice();
  }, [maxCredit, setUseCreditAmount, refetchPrice]);

  const handleUseMaxCredit = React.useCallback(() => {
    setCreditInput(String(maxCredit));
    setUseCreditAmount(maxCredit);
    refetchPrice();
  }, [maxCredit, setUseCreditAmount, refetchPrice]);

  const handleSubmit = React.useCallback(async () => {
    if (hasError) { setError("لطفاً خطاهای موجود را برطرف کنید."); return; }
    setError(null);
    setSubmitting(true);
    try {
      // EDRA v32 — باگ واقعی: «نام پروژه» در مرحله‌ی ۶ از کاربر گرفته می‌شد ولی
      // اینجا اصلاً در payload نبود — بی‌صدا دور ریخته می‌شد. چون مدل
      // InspectionRequest.project یک ForeignKey به جدول Project (مدیریت‌شده
      // توسط ادمین/سازمان) است، نه یک فیلد متنی آزاد، نمی‌توان این نام را
      // مستقیم در آن فیلد نوشت؛ وصل‌کردن درست آن (مثلاً انتخاب از پروژه‌های
      // موجودِ مشتری) یک تصمیم محصول جداگانه است. حداقلِ درست: مثل companyName
      // که از قبل همین‌طور ذخیره می‌شود، در address اضافه می‌شود تا لااقل گم
      // نشود و برای ادمین/کارشناس قابل‌مشاهده بماند.
      const payload: Record<string, unknown> = {
        title: `${equipmentName} - ${applicantName}`,
        equipment_type: equipmentTypeId,
        params: params || {},
        service_type: serviceType,
        city: city,
        address: [companyName, projectName, address].filter(Boolean).join(" - "),
        scheduled_at: scheduledAt,
      };

      if (installState) payload.install_state = installState;
      if (addressLat) payload.address_lat = addressLat;
      if (addressLng) payload.address_lng = addressLng;
      if (isDiscountApplied && discountCode) payload.discount_code = discountCode;
      if (useCreditAmount > 0) payload.credit_amount = useCreditAmount;

      const res = await fetch("/api/proxy/core/inspection-requests/", {
        method: "POST",
        headers: getHeaders(),
        body: JSON.stringify(payload),
        credentials: "include",
      });

      if (res.status === 401) { setError("نشست شما منقضی شده است."); return; }
      const data = await res.json();
      if (!res.ok) {
        let errorMsg = "ثبت درخواست با خطا مواجه شد.";
        if (data.detail) {
          errorMsg = data.detail;
        } else if (data.non_field_errors) {
          errorMsg = data.non_field_errors.join(", ");
        } else {
          // نام انگلیسی فیلد (مثل scheduled_at) به مشتری نشان داده نمی‌شود؛
          // فقط خود پیام فارسی سرور.
          const keys = Object.keys(data);
          for (const key of keys) {
            if (Array.isArray(data[key])) {
              errorMsg = data[key].map(String).join("، ");
              break;
            }
            if (typeof data[key] === "string") {
              errorMsg = data[key];
              break;
            }
          }
        }
        setError(errorMsg);
        return;
      }
      setCreatedRequest(data.id, data.request_number);
      setStep(8);
    } catch (err) {
      setError("ارتباط با سرور برقرار نشد.");
    } finally {
      setSubmitting(false);
    }
  }, [equipmentName, applicantName, equipmentTypeId, params, installState, serviceType, city, companyName, projectName, address, addressLat, addressLng, scheduledAt, discountCode, isDiscountApplied, useCreditAmount, hasError, setCreatedRequest, setStep]);

  // ✅ ذخیره finalWithTax در store برای استفاده در استپ ۸
  React.useEffect(() => {
    if (priceData?.final_amount !== undefined && priceData?.final_amount !== null) {
      setFinalWithTax(priceData.final_amount);
    }
  }, [priceData, setFinalWithTax]);

  React.useEffect(() => {
    if (priceData?.discount_error) {
      setDiscountError(priceData.discount_error);
      setIsDiscountApplied(false);
      setDiscountCode("");
    }
  }, [priceData, setDiscountCode]);

  React.useEffect(() => {
    if (priceError) setError(priceError.message);
  }, [priceError]);

  React.useEffect(() => {
    if (useCreditAmount !== undefined && useCreditAmount !== null) {
      setCreditInput(String(useCreditAmount));
    }
  }, [useCreditAmount]);

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2"><FileText className="size-5" /> بررسی نهایی و پرداخت</CardTitle>
        <CardDescription>اطلاعات درخواست را بررسی و تایید کنید</CardDescription>
      </CardHeader>
      <CardContent className="flex flex-col gap-5">
        {error && (
          <Alert variant="destructive">
            <AlertCircle className="size-4" />
            <AlertTitle>خطا</AlertTitle>
            <AlertDescription>{error}</AlertDescription>
          </Alert>
        )}
        <div className="grid gap-2 rounded-lg border p-4 text-sm">
          <Row icon={FileText} label="تجهیز و سرویس">{equipmentName} · {serviceType === "pro" ? "حرفه‌ای" : "استاندارد"}</Row>
          {scheduledAt && (
            <Row icon={Calendar} label="زمان کارشناسی">
              {formatJalaliWithWeekday(new Date(scheduledAt))} ساعت {formatPersianTime(new Date(scheduledAt))}
            </Row>
          )}
          <Row icon={MapPin} label="محل بازرسی">{city} - {address}</Row>
        </div>

        <div className="grid gap-2">
          <Label htmlFor="discount" className="flex items-center gap-1.5">
            <Tag className="size-4" /> کد تخفیف {isDiscountApplied && <CheckCircle2 className="size-4 text-green-600" />}
          </Label>
          <div className="flex gap-2">
            <Input
              id="discount"
              value={discountInput}
              onChange={(e) => {
                const val = e.target.value;
                setDiscountInput(val);
                if (isDiscountApplied) { setIsDiscountApplied(false); setDiscountCode(""); }
                setDiscountError(null);
              }}
              placeholder="کد تخفیف را وارد کنید"
              disabled={isDiscountApplied || isValidatingDiscount}
              className={"flex-1 " + (isDiscountApplied ? "border-green-600/50 bg-green-50 dark:bg-green-950/20" : "")}
            />
            {!isDiscountApplied ? (
              <Button
                type="button"
                onClick={handleApplyDiscount}
                disabled={isValidatingDiscount || !discountInput.trim() || isPriceLoading}
                variant="outline"
                className="shrink-0"
              >
                {isValidatingDiscount ? <Loader2 className="size-4 animate-spin" /> : "اعمال"}
              </Button>
            ) : (
              <Button type="button" onClick={handleRemoveDiscount} variant="ghost" className="shrink-0 text-destructive hover:text-destructive">
                <XCircle className="size-4" /> حذف
              </Button>
            )}
          </div>
          {discountError && <p className="text-destructive text-xs flex items-center gap-1"><AlertCircle className="size-3" /> {discountError}</p>}
          {isDiscountApplied && !discountError && <p className="text-green-600 text-xs flex items-center gap-1"><CheckCircle2 className="size-3" /> کد تخفیف با موفقیت اعمال شد</p>}
        </div>

        {creditBalance > 0 && (
          <div className="grid gap-2">
            <Label htmlFor="credit-use" className="flex items-center gap-1.5">
              <Wallet className="size-4" /> استفاده از اعتبار (موجودی: {formatToman(creditBalance)})
            </Label>
            <div className="flex gap-2">
              <Input
                id="credit-use"
                type="number"
                min={0}
                max={maxCredit}
                value={creditInput}
                onChange={(e) => handleCreditChange(e.target.value)}
                placeholder="مقدار اعتبار مورد استفاده"
                className="flex-1"
              />
              <Button type="button" variant="link" size="sm" className="shrink-0 px-0" onClick={handleUseMaxCredit} disabled={maxCredit <= 0}>
                حداکثر ({formatToman(maxCredit)})
              </Button>
            </div>
            {Number(creditInput) > maxCredit && <p className="text-destructive text-xs flex items-center gap-1"><AlertCircle className="size-3" /> مقدار وارد شده بیش از حد مجاز است (حداکثر {formatToman(maxCredit)})</p>}
            {Number(creditInput) > 0 && <p className="text-muted-foreground text-xs">پس از کسر اعتبار، مبلغ قابل پرداخت کاهش می‌یابد.</p>}
          </div>
        )}

        <div className="bg-muted flex flex-col gap-1.5 rounded-lg p-4">
          <div className="flex justify-between text-sm"><span className="text-muted-foreground">هزینه پایه بازرسی</span><span>{formatToman(price)}</span></div>
          <div className="flex justify-between text-sm"><span className="text-muted-foreground">ضریب شهر</span><span>{Math.round(cityMultiplier * 100)}%</span></div>
          {cityBaseCost > 0 && <div className="flex justify-between text-sm"><span className="text-muted-foreground">هزینه ایاب‌وذهاب شهر</span><span>{formatToman(cityBaseCost)}</span></div>}
          {taxRate > 0 && <div className="flex justify-between text-sm"><span className="text-muted-foreground">مالیات بر ارزش افزوده ({taxRate}٪)</span><span>{formatToman(taxAmount)}</span></div>}
          {isDiscountApplied && discountAmount > 0 && <div className="flex justify-between text-sm text-green-600"><span className="text-muted-foreground">تخفیف اعمال‌شده</span><span>- {formatToman(discountAmount)}</span></div>}
          <div className="flex justify-between text-sm font-medium"><span className="text-muted-foreground">مبلغ نهایی (با مالیات)</span><span>{formatToman(finalWithTax)}</span></div>
          {useCreditAmount > 0 && <div className="flex justify-between text-sm"><span className="text-muted-foreground">استفاده از اعتبار</span><span>- {formatToman(useCreditAmount)}</span></div>}
          <div className="mt-1 flex justify-between border-t pt-1.5 text-base font-semibold"><span>قابل پرداخت</span><span className="text-primary">{formatToman(finalPayable)}</span></div>
        </div>

        {isPriceLoading && (
          <div className="flex items-center justify-center gap-2 text-muted-foreground text-sm">
            <Loader2 className="size-4 animate-spin" /> در حال محاسبه قیمت...
          </div>
        )}
      </CardContent>
      <CardContent>
        <WizardFooter onBack={() => setStep(6)} onNext={handleSubmit} nextLabel="ثبت درخواست و ادامه" isLoading={isBusy} />
      </CardContent>
    </Card>
  );
}

function Row({ icon: Icon, label, children }: { icon: typeof FileText; label: string; children: React.ReactNode }) {
  return (
    <div className="flex items-start gap-2">
      <Icon className="text-muted-foreground mt-0.5 size-4 shrink-0" />
      <div><span className="text-muted-foreground">{label}: </span><span className="font-medium">{children}</span></div>
    </div>
  );
}
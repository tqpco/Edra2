// components/wizard/step-8-payment.tsx
"use client";

import * as React from "react";
import { useRouter } from "next/navigation";
import { CreditCard, Building2, Loader2, Upload, CheckCircle2, Wallet } from "lucide-react";

import { Card, CardHeader, CardTitle, CardDescription, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { cn } from "@/lib/utils";
import { useWizardStore } from "@/lib/wizard-store";
import { toPersianDigits } from "@/lib/jalali";
import { formatToman } from "@/lib/format";
import { useAuth } from "@/hooks/use-auth";
import { apiClientFetch, apiClientUpload, ClientApiError } from "@/lib/api-client";

type Method = "online" | "manual" | "credit";

export function StepPayment() {
  const router = useRouter();
  const { user, isLoading: authLoading, isAuthenticated } = useAuth();

  const {
    requestId,
    requestNumber,
    useCreditAmount,
    finalWithTax,
    reset,
  } = useWizardStore();

  const finalPayable = Math.max((finalWithTax || 0) - (useCreditAmount || 0), 0);

  const [method, setMethod] = React.useState<Method>("online");
  const [receiptFile, setReceiptFile] = React.useState<File | null>(null);
  const [loading, setLoading] = React.useState(false);
  const [error, setError] = React.useState<string | null>(null);
  const [manualSubmitted, setManualSubmitted] = React.useState(false);

  const hasCredit = useCreditAmount > 0;
  const isFullyCovered = hasCredit && finalPayable === 0;

  // هدایت به لاگین در صورت نبود احراز هویت
  // EDRA v32 — باگ واقعی و جدی: مقصد /auth/signin اصلاً در این پروژه وجود
  // ندارد (فقط /login و /customer-login هستند) و پارامتر redirect= هم با
  // چیزی که فرم‌های ورود واقعاً می‌خوانند (?next=) یکی نبود. یعنی اگر نشست
  // مشتری دقیقاً در حساس‌ترین قدم (صفحه‌ی پرداخت، بعد از طی‌کردن کل ویزارد)
  // منقضی می‌شد، به یک صفحه‌ی ۴۰۴ هدایت می‌شد — بدون هیچ راهی برای ورود
  // دوباره و تکمیل خرید.
  React.useEffect(() => {
    if (!authLoading && !isAuthenticated) {
      router.push("/customer-login?next=/booking");
    }
  }, [authLoading, isAuthenticated, router]);

  // EDRA v27 — رفع باگ/بدهی فنی (گزارش کاربر، سپتامبر ۲۰۲۶): این فایل
  // (و step-7-review.tsx) قبلاً کد مرده‌ای برای خواندن توکن از
  // localStorage و CSRF از کوکی داشتند — چیزی که هیچ‌جای دیگر این
  // پروژه (که کاملاً بر پایه‌ی کوکی httpOnly است) استفاده نمی‌شود؛
  // login هیچ‌وقت چیزی در localStorage نمی‌نویسد، پس getAuthToken()
  // همیشه null برمی‌گرداند و آن هدر Authorization دستی هرگز واقعاً
  // اضافه نمی‌شد. به لطف credentials موجود در fetch زیرساخت apiClientFetch،
  // درخواست‌ها همچنان کار می‌کردند (چون پروکسی خودش کوکی httpOnly را
  // می‌خواند) — یعنی این کد مرده بود نه شکسته، ولی گمراه‌کننده و در
  // تناقض با معماری واقعی پروژه بود. با helper استاندارد پروژه جایگزین شد.

  // پرداخت با اعتبار
  const payWithCredit = React.useCallback(async () => {
    if (!isFullyCovered) {
      setError("اعتبار شما برای پرداخت کامل کافی نیست.");
      return;
    }
    setError(null);
    setLoading(true);
    try {
      await apiClientFetch("/api/core/credit/deposit/", {
        method: "POST",
        body: {
          request_id: requestId,
          method: "credit",
          credit_amount: useCreditAmount,
        },
      });
      reset();
      window.location.href = "/dashboard/customer/requests";
    } catch (err: any) {
      console.error("payWithCredit error:", err);
      setError(
        err instanceof ClientApiError
          ? err.message
          : "ارتباط با سرور برقرار نشد."
      );
    } finally {
      setLoading(false);
    }
  }, [requestId, useCreditAmount, isFullyCovered, reset]);

  // پرداخت آنلاین
  const payOnline = React.useCallback(async () => {
    setError(null);
    setLoading(true);
    try {
      const data = await apiClientFetch<{ payment_url?: string }>(
        "/api/core/payment/initiate/",
        {
          method: "POST",
          body: {
            request_id: requestId,
            ...(hasCredit && { credit_amount: useCreditAmount }),
          },
        }
      );
      if (!data.payment_url) {
        setError("اتصال به درگاه پرداخت ناموفق بود.");
        return;
      }
      reset();
      window.location.href = data.payment_url;
    } catch (err: any) {
      console.error("payOnline error:", err);
      setError(
        err instanceof ClientApiError
          ? err.message
          : "ارتباط با سرور برقرار نشد."
      );
    } finally {
      setLoading(false);
    }
  }, [requestId, hasCredit, useCreditAmount, reset]);

  // واریز دستی
  const payManual = React.useCallback(async () => {
    if (!receiptFile) {
      setError("لطفاً تصویر یا فایل فیش واریزی را انتخاب کنید.");
      return;
    }
    setError(null);
    setLoading(true);
    try {
      const formData = new FormData();
      formData.append("amount", String(finalPayable || 0));
      formData.append("method", "manual");
      formData.append("request_id", String(requestId));
      if (hasCredit) formData.append("credit_amount", String(useCreditAmount));
      formData.append("receipt_file", receiptFile);

      await apiClientUpload("/api/core/credit/deposit/", formData);
      setManualSubmitted(true);
      // پس از ثبت موفق، به داشبورد هدایت شود
      reset();
      window.location.href = "/dashboard/customer/requests";
    } catch (err: any) {
      console.error("payManual error:", err);
      setError(
        err instanceof ClientApiError
          ? err.message
          : "ارتباط با سرور برقرار نشد."
      );
    } finally {
      setLoading(false);
    }
  }, [receiptFile, requestId, hasCredit, useCreditAmount, finalPayable, reset]);

  // در حال بررسی وضعیت احراز هویت
  if (authLoading) {
    return (
      <Card>
        <CardContent className="flex flex-col items-center justify-center gap-3 py-12 text-muted-foreground">
          <Loader2 className="size-6 animate-spin" />
          <span className="text-sm">در حال بررسی ورود...</span>
        </CardContent>
      </Card>
    );
  }

  // اگر احراز نشده باشد، چیزی نمایش نمی‌دهیم (useEffect هدایت می‌کند)
  if (!isAuthenticated) {
    return null;
  }

  // صفحه موفقیت واریز دستی (در صورت عدم هدایت خودکار)
  if (manualSubmitted) {
    return (
      <Card>
        <CardContent className="flex flex-col items-center gap-4 py-12 text-center">
          <CheckCircle2 className="text-success size-14" />
          <div>
            <h2 className="text-lg font-semibold">فیش شما با موفقیت ثبت شد</h2>
            <p className="text-muted-foreground mt-1 text-sm">
              درخواست شماره {toPersianDigits(requestNumber ?? "")} پس از تایید فیش تکمیل می‌شود.
            </p>
          </div>
          <Button onClick={() => { reset(); window.location.href = "/dashboard/customer/requests"; }}>
            مشاهده درخواست‌های من
          </Button>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <CreditCard className="size-5" />
          روش پرداخت
        </CardTitle>
        <CardDescription>
          درخواست شماره {toPersianDigits(requestNumber ?? "")}
          {hasCredit && (
            <span className="block mt-1 text-sm text-primary">
              اعتبار: {formatToman(useCreditAmount)} - قابل پرداخت: {formatToman(finalPayable)}
            </span>
          )}
          {!hasCredit && (
            <span className="block mt-1 text-sm text-muted-foreground">
              مبلغ قابل پرداخت: {formatToman(finalPayable)}
            </span>
          )}
        </CardDescription>
      </CardHeader>
      <CardContent className="flex flex-col gap-5">
        {error && (
          <Alert variant="destructive">
            <AlertDescription>{error}</AlertDescription>
          </Alert>
        )}

        <div className="grid gap-3 sm:grid-cols-2">
          <button
            type="button"
            onClick={() => setMethod("online")}
            className={cn(
              "flex flex-col items-start gap-2 rounded-xl border p-4 text-right transition-all",
              method === "online"
                ? "border-primary bg-primary/[0.04] ring-1 ring-primary"
                : "hover:border-primary/40"
            )}
          >
            <CreditCard className="size-6 text-primary" />
            <span className="font-medium">پرداخت آنلاین</span>
            <span className="text-muted-foreground text-xs">
              {hasCredit ? `پرداخت ${formatToman(finalPayable)} از طریق درگاه` : "پرداخت از طریق درگاه بانکی"}
            </span>
          </button>

          <button
            type="button"
            onClick={() => setMethod("manual")}
            className={cn(
              "flex flex-col items-start gap-2 rounded-xl border p-4 text-right transition-all",
              method === "manual"
                ? "border-primary bg-primary/[0.04] ring-1 ring-primary"
                : "hover:border-primary/40"
            )}
          >
            <Building2 className="size-6 text-primary" />
            <span className="font-medium">واریز دستی</span>
            <span className="text-muted-foreground text-xs">
              {hasCredit ? `واریز ${formatToman(finalPayable)} و آپلود فیش` : "واریز به حساب و آپلود فیش"}
            </span>
          </button>

          {isFullyCovered && (
            <button
              type="button"
              onClick={() => setMethod("credit")}
              className={cn(
                "flex flex-col items-start gap-2 rounded-xl border p-4 text-right transition-all col-span-full",
                method === "credit"
                  ? "border-primary bg-primary/[0.04] ring-1 ring-primary"
                  : "hover:border-primary/40"
              )}
            >
              <Wallet className="size-6 text-primary" />
              <span className="font-medium">پرداخت با اعتبار</span>
              <span className="text-muted-foreground text-xs">
                مبلغ {formatToman(finalPayable)} از اعتبار کسر می‌شود
              </span>
            </button>
          )}

          {hasCredit && !isFullyCovered && method === "credit" && (
            <div className="col-span-full rounded-lg border border-amber-200 bg-amber-50 p-3 text-sm text-amber-800">
              ⚠️ اعتبار شما ({formatToman(useCreditAmount)}) کافی نیست. مابقی ({formatToman(finalPayable)}) را از روش‌های دیگر پرداخت کنید.
            </div>
          )}
        </div>

        {method === "manual" && (
          <div className="rounded-lg border border-dashed p-4">
            <label className="flex cursor-pointer flex-col items-center gap-2 text-center">
              <Upload className="text-muted-foreground size-6" />
              <span className="text-sm font-medium">
                {receiptFile ? receiptFile.name : "برای آپلود فیش کلیک کنید"}
              </span>
              <span className="text-muted-foreground text-xs">JPG, PNG یا PDF</span>
              <input
                type="file"
                accept=".jpg,.jpeg,.png,.pdf"
                className="hidden"
                onChange={(e) => setReceiptFile(e.target.files?.[0] ?? null)}
              />
            </label>
          </div>
        )}

        <Button
          size="lg"
          onClick={
            method === "online" ? payOnline :
            method === "manual" ? payManual :
            payWithCredit
          }
          disabled={loading || (method === "credit" && !isFullyCovered)}
        >
          {loading && <Loader2 className="animate-spin" />}
          {method === "online" && "انتقال به درگاه پرداخت"}
          {method === "manual" && "ثبت فیش واریزی"}
          {method === "credit" && "پرداخت با اعتبار"}
        </Button>
      </CardContent>
    </Card>
  );
}
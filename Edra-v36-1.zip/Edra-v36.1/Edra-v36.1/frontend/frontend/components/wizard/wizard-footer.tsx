// components/wizard/wizard-footer.tsx
"use client";

import { ArrowLeft, ArrowRight, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

export function WizardFooter({
  onBack,
  onNext,
  nextLabel = "ادامه",
  nextDisabled = false,
  isLoading = false,
  hideBack = false,
  className,
}: {
  onBack?: () => void;
  onNext?: () => void;
  nextLabel?: string;
  nextDisabled?: boolean;
  isLoading?: boolean;
  hideBack?: boolean;
  className?: string;
}) {
  // ✅ اطمینان از اینکه nextDisabled همیشه boolean است (برای رفع Hydration)
  const isDisabled = !!nextDisabled || isLoading;

  return (
    <div className={cn("mt-8 flex items-center justify-between gap-3", className)}>
      {!hideBack && onBack ? (
        <Button type="button" variant="ghost" onClick={onBack} disabled={isLoading}>
          <ArrowRight className="size-4" />
          مرحله قبل
        </Button>
      ) : (
        <span />
      )}
      {onNext && (
        <Button
          type="button"
          onClick={onNext}
          disabled={isDisabled}
          className="min-w-[120px]"
        >
          {isLoading && <Loader2 className="size-4 animate-spin" />}
          {nextLabel}
          {!isLoading && <ArrowLeft className="size-4" />}
        </Button>
      )}
    </div>
  );
}
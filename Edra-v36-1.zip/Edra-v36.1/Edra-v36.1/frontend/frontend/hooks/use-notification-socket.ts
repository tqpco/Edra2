"use client";

import * as React from "react";
import { useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { apiClientFetch } from "@/lib/api-client";

export interface LiveNotification {
  id: number;
  title: string;
  message: string;
  created_at: string;
  type: string;
  type_label?: string;
  status?: string;
  is_read?: boolean;
}

/** رویداد window که با هر اعلان جدید/تغییر خوانده‌شدن پخش می‌شود (صفحه‌ی اعلان‌ها گوش می‌دهد). */
export const NOTIFICATIONS_CHANGED_EVENT = "edra:notifications-changed";

/** پاسخ REST (subject/content) و WebSocket (title/message) را یکسان می‌کند. */
function normalize(raw: Record<string, unknown>): LiveNotification {
  return {
    id: Number(raw.id),
    title: String(raw.title ?? raw.subject ?? ""),
    message: String(raw.message ?? raw.content ?? ""),
    created_at: String(raw.created_at ?? ""),
    type: String(raw.type ?? ""),
    type_label: raw.type_label ? String(raw.type_label) : undefined,
    status: raw.status ? String(raw.status) : undefined,
    is_read: Boolean(raw.is_read),
  };
}

function notifyChanged() {
  window.dispatchEvent(new CustomEvent(NOTIFICATIONS_CHANGED_EVENT));
}

/**
 * آدرس پایه‌ی WebSocket.
 * - production (پشت nginx): same-origin از origin واقعی مرورگر (https → wss).
 * - توسعه‌ی محلی (localhost): اگر NEXT_PUBLIC_WS_URL تنظیم شده باشد (مثلاً
 *   ws://localhost:8001 که مستقیم به سرویس backend-ws می‌رود) از آن استفاده می‌شود؛
 *   سرور dev نکست WebSocket را پراکسی نمی‌کند.
 */
function wsBase(): string {
  const configured = process.env.NEXT_PUBLIC_WS_URL;
  const host = window.location.hostname;
  if (configured && (host === "localhost" || host === "127.0.0.1")) {
    return configured.replace(/\/+$/, "");
  }
  const proto = window.location.protocol === "https:" ? "wss:" : "ws:";
  return `${proto}//${window.location.host}`;
}

const HEARTBEAT_MS = 25_000;
const POLL_MS = 60_000;
const MAX_LIST = 50;

/**
 * اتصال بلادرنگ اعلان‌ها.
 *
 * EDRA v33 — تغییرات نسبت به v32:
 *  • reconnect خودکار با backoff نمایی و ticket تازه (ticket یک‌بارمصرف است)؛
 *    قبلاً با اولین قطع شدن اتصال (ری‌استارت سرور، idle، قطع شبکه) زنگوله تا
 *    رفرش دستی صفحه برای همیشه از کار می‌افتاد.
 *  • heartbeat (ping) تا پراکسی‌ها اتصال بی‌کار را نبُرند.
 *  • fallback REST: وقتی WebSocket وصل نیست (یا هنگام mount) فهرست/تعداد
 *    خوانده‌نشده‌ها از API خوانده و هر ۶۰ ثانیه تازه می‌شود؛ قبلاً با شکست
 *    WebSocket زنگوله همیشه «اعلانی ندارید» نشان می‌داد.
 *  • خوانده‌شدن از طریق REST قابل‌اعتماد انجام می‌شود (نه فقط send روی سوکتی که
 *    ممکن است بسته باشد).
 *  • حذف تکراری‌ها بر اساس id، و شمارنده‌ی واقعی سمت سرور.
 */
export function useNotificationSocket(wsTicketFetcher: () => Promise<string | null>) {
  const [notifications, setNotifications] = React.useState<LiveNotification[]>([]);
  const [unreadCount, setUnreadCount] = React.useState(0);
  const [isConnected, setIsConnected] = React.useState(false);
  const queryClient = useQueryClient();

  const socketRef = React.useRef<WebSocket | null>(null);
  const fetcherRef = React.useRef(wsTicketFetcher);
  fetcherRef.current = wsTicketFetcher;

  const refreshFromRest = React.useCallback(async () => {
    try {
      const data = await apiClientFetch<{
        count?: number;
        results?: Record<string, unknown>[];
      } | Record<string, unknown>[]>("/api/core/notifications/?is_read=false&page_size=50");
      const rows = Array.isArray(data) ? data : (data.results ?? []);
      const total = !Array.isArray(data) && typeof data.count === "number" ? data.count : rows.length;
      setNotifications(rows.map(normalize));
      setUnreadCount(total);
    } catch {
      // شبکه/نشست — دور بعدی دوباره تلاش می‌شود
    }
  }, []);

  React.useEffect(() => {
    let stopped = false;
    let attempt = 0;
    let socket: WebSocket | null = null;
    let reconnectTimer: ReturnType<typeof setTimeout> | undefined;
    let heartbeatTimer: ReturnType<typeof setInterval> | undefined;
    let pollTimer: ReturnType<typeof setInterval> | undefined;
    // شناسه‌هایی که قبلاً toast شده‌اند (reconnect نباید دوباره toast بسازد)
    const seenToast = new Set<number>();

    const clearHeartbeat = () => {
      if (heartbeatTimer) clearInterval(heartbeatTimer);
      heartbeatTimer = undefined;
    };

    const startPolling = () => {
      if (pollTimer) return;
      pollTimer = setInterval(refreshFromRest, POLL_MS);
    };
    const stopPolling = () => {
      if (pollTimer) clearInterval(pollTimer);
      pollTimer = undefined;
    };

    const scheduleReconnect = () => {
      if (stopped) return;
      if (reconnectTimer) clearTimeout(reconnectTimer);
      const delay = Math.min(30_000, 1_000 * 2 ** attempt) + Math.random() * 500;
      attempt += 1;
      reconnectTimer = setTimeout(connect, delay);
    };

    async function connect() {
      if (stopped) return;
      if (socket && (socket.readyState === WebSocket.OPEN || socket.readyState === WebSocket.CONNECTING)) {
        return;
      }
      let ticket: string | null = null;
      try {
        ticket = await fetcherRef.current();
      } catch {
        ticket = null;
      }
      if (stopped) return;
      if (!ticket) {
        startPolling();
        scheduleReconnect();
        return;
      }

      const ws = new WebSocket(`${wsBase()}/ws/notifications/?ticket=${ticket}`);
      socket = ws;
      socketRef.current = ws;

      ws.onopen = () => {
        attempt = 0;
        setIsConnected(true);
        stopPolling();
        clearHeartbeat();
        heartbeatTimer = setInterval(() => {
          if (ws.readyState === WebSocket.OPEN) ws.send(JSON.stringify({ action: "ping" }));
        }, HEARTBEAT_MS);
      };

      ws.onclose = () => {
        if (socketRef.current === ws) socketRef.current = null;
        clearHeartbeat();
        setIsConnected(false);
        if (stopped) return;
        startPolling();
        refreshFromRest();
        scheduleReconnect();
      };

      ws.onerror = () => {
        // onclose بلافاصله بعد از این فراخوانی می‌شود و reconnect را زمان‌بندی می‌کند
      };

      ws.onmessage = (event) => {
        try {
          const payload = JSON.parse(event.data);
          if (payload.type === "notification") {
            const n = normalize(payload.data as Record<string, unknown>);
            setNotifications((prev) =>
              prev.some((p) => p.id === n.id) ? prev : [n, ...prev].slice(0, MAX_LIST)
            );
            // toast و شمارنده فقط یک‌بار به‌ازای هر id (تکرار بعد از reconnect نادیده)
            if (!seenToast.has(n.id)) {
              seenToast.add(n.id);
              toast(n.title, { description: n.message });
              setUnreadCount((c) => c + 1);
            }
            queryClient.invalidateQueries({ queryKey: ["unread-notifications-count"] });
            notifyChanged();
          } else if (payload.type === "unread_notifications") {
            const list = (payload.data as Record<string, unknown>[]).map(normalize);
            list.forEach((n) => seenToast.add(n.id));
            setNotifications(list.slice(0, MAX_LIST));
            setUnreadCount(typeof payload.count === "number" ? payload.count : list.length);
          }
        } catch {
          // پیام غیرمنتظره - نادیده گرفته می‌شود
        }
      };
    }

    const onVisible = () => {
      if (document.visibilityState !== "visible" || stopped) return;
      refreshFromRest();
      if (!socket || socket.readyState === WebSocket.CLOSED) {
        if (reconnectTimer) clearTimeout(reconnectTimer);
        attempt = 0;
        connect();
      }
    };
    const onOnline = () => onVisible();
    document.addEventListener("visibilitychange", onVisible);
    window.addEventListener("online", onOnline);

    refreshFromRest(); // شروع: بدون انتظار برای WebSocket
    connect();

    return () => {
      stopped = true;
      if (reconnectTimer) clearTimeout(reconnectTimer);
      clearHeartbeat();
      stopPolling();
      document.removeEventListener("visibilitychange", onVisible);
      window.removeEventListener("online", onOnline);
      socket?.close();
      socketRef.current = null;
    };
  }, [queryClient, refreshFromRest]);

  const markAsRead = React.useCallback(
    async (id: number) => {
      setNotifications((prev) => prev.filter((n) => n.id !== id));
      setUnreadCount((c) => Math.max(0, c - 1));
      try {
        await apiClientFetch(`/api/core/notifications/${id}/mark_read/`, { method: "POST", body: {} });
      } catch {
        refreshFromRest(); // شکست: وضعیت واقعی سرور را برگردان
        return;
      }
      queryClient.invalidateQueries({ queryKey: ["unread-notifications-count"] });
      notifyChanged();
    },
    [queryClient, refreshFromRest]
  );

  const markAllAsRead = React.useCallback(async () => {
    setNotifications([]);
    setUnreadCount(0);
    try {
      await apiClientFetch("/api/core/notifications/mark_all_read/", { method: "POST", body: {} });
    } catch {
      refreshFromRest();
      return;
    }
    queryClient.invalidateQueries({ queryKey: ["unread-notifications-count"] });
    notifyChanged();
  }, [queryClient, refreshFromRest]);

  return { notifications, unreadCount, isConnected, markAsRead, markAllAsRead };
}

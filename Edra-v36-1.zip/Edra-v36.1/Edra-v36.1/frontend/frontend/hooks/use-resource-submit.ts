"use client";

/**
 * hooks/use-resource-submit.ts  (EDRA v32)
 *
 * منطق مشترک «ذخیره» برای همه‌ی صفحات ایجاد/ویرایش مدیریتی:
 *  - ارسال از طریق apiClientFetch (پروکسی BFF)
 *  - مدیریت وضعیت saving (جلوگیری از ثبت دوباره با دوبار کلیک)
 *  - پارس یکسان خطای DRF → پیام کلی + خطای هر فیلد
 *  - toast موفقیت + بازگشت به لیست + refresh داده‌ی سرور
 */
import * as React from "react";
import { useRouter } from "next/navigation";
import { toast } from "sonner";
import { apiClientFetch, ClientApiError } from "@/lib/api-client";
import { parseApiError } from "@/lib/form-errors";

interface SubmitOptions {
  /** مسیر API، مثل /api/core/users/ یا /api/core/users/5/ */
  endpoint: string;
  method: "POST" | "PUT" | "PATCH";
  successMessage: string;
  /** صفحه‌ای که بعد از موفقیت به آن برمی‌گردیم (لیست) */
  redirectTo: string;
  errorFallback?: string;
}

export function useResourceSubmit<TResponse = unknown>(options: SubmitOptions) {
  const router = useRouter();
  const [saving, setSaving] = React.useState(false);
  const [error, setError] = React.useState<string | null>(null);
  const [fieldErrors, setFieldErrors] = React.useState<Record<string, string>>({});
  // قفل همزمانی: state async است و دو کلیک پشت‌سرهم هر دو از آن عبور می‌کردند
  const inFlight = React.useRef(false);

  const clearFieldError = React.useCallback((name: string) => {
    setFieldErrors((prev) => {
      if (!prev[name]) return prev;
      const next = { ...prev };
      delete next[name];
      return next;
    });
  }, []);

  const submit = React.useCallback(
    async (payload: unknown): Promise<TResponse | null> => {
      if (inFlight.current) return null;
      inFlight.current = true;
      setSaving(true);
      setError(null);
      setFieldErrors({});
      try {
        const data = await apiClientFetch<TResponse>(options.endpoint, {
          method: options.method,
          body: payload,
        });
        toast.success(options.successMessage);
        router.push(options.redirectTo);
        router.refresh();
        return data;
      } catch (err) {
        const parsed =
          err instanceof ClientApiError
            ? parseApiError(err.data, options.errorFallback)
            : parseApiError(null, "ارتباط با سرور برقرار نشد. لطفاً دوباره تلاش کنید.");
        setError(parsed.message);
        setFieldErrors(parsed.fieldErrors);
        toast.error(parsed.message);
        return null;
      } finally {
        inFlight.current = false;
        setSaving(false);
      }
    },
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [options.endpoint, options.method, options.successMessage, options.redirectTo, options.errorFallback, router]
  );

  return { submit, saving, error, fieldErrors, clearFieldError };
}

"use client";

import * as React from "react";

/**
 * تکمیل خودکار کد OTP با WebOTP API.
 *
 * به‌محض این‌که پیامکِ حاوی کد به گوشی می‌رسد (در مرورگرها/سیستم‌عامل‌هایی
 * که از WebOTP پشتیبانی می‌کنند — عمدتاً Chrome روی اندروید)، مرورگر خودش
 * یک پیشنهاد سیستمی نشان می‌دهد؛ با تایید کاربر (یک لمس)، `onCode` با کد
 * ۶ رقمی صدا زده می‌شود — بدون این‌که کاربر مجبور باشد پیامک را باز کند
 * یا چیزی تایپ کند.
 *
 * این یک بهبود تدریجی (progressive enhancement) است:
 *  - در مرورگرهایی که WebOTP ندارند (از جمله سافاری iOS)، این هوک کاملاً
 *    بی‌اثر است و هیچ خطایی نمی‌دهد. آن‌ها همچنان از طریق ویژگی استاندارد
 *    HTML، یعنی `autoComplete="one-time-code"` روی input کد (که جدا روی
 *    عنصر Input تنظیم شده)، پیشنهاد پرشدن خودکار را از کیبورد خود سیستم‌عامل
 *    می‌بینند.
 *  - اگر کاربر پیشنهاد را رد کند یا timeout شود، فقط بی‌صدا نادیده گرفته
 *    می‌شود؛ ورود دستی کد همیشه به‌عنوان راه اصلی در دسترس می‌ماند.
 *
 * نکته برای بک‌اند: پیامک باید طبق استاندارد WebOTP در آخرین خط دقیقاً
 * "@دامنه #کد" باشد — این فرمت در notifications/services.py
 * (format_otp_sms_body) پیاده شده است.
 */
export function useWebOtp(onCode: (code: string) => void, enabled: boolean = true) {
  const onCodeRef = React.useRef(onCode);
  React.useEffect(() => {
    onCodeRef.current = onCode;
  }, [onCode]);

  React.useEffect(() => {
    if (!enabled) return;
    if (typeof window === "undefined") return;
    if (!("OTPCredential" in window)) return; // مرورگر/پلتفرم پشتیبانی نمی‌کند

    const abortController = new AbortController();

    // نکته: OTPCredential/گزینه‌ی otp هنوز در type declarations استاندارد
    // TS/DOM به‌طور کامل جا نیفتاده و بسته به نسخه‌ی TS ممکن است خطای type
    // بدهد یا ندهد؛ به‌جای @ts-expect-error (که در نبود خطا خودش خطای
    // «دایرکتیو بلااستفاده» می‌دهد)، از یک cast صریح و بی‌خطر استفاده شده.
    const credentialRequestOptions = {
      otp: { transport: ["sms"] },
      signal: abortController.signal,
    } as unknown as CredentialRequestOptions;

    navigator.credentials
      .get(credentialRequestOptions)
      .then((otp: unknown) => {
        const code = (otp as { code?: string } | null)?.code;
        if (code) onCodeRef.current(code);
      })
      .catch(() => {
        // رد شدن توسط کاربر / timeout / abort — بی‌صدا نادیده گرفته می‌شود
      });

    return () => abortController.abort();
  }, [enabled]);
}

import { describe, it, expect, vi, beforeEach } from "vitest";

// EDRA v21 — تست قرارداد مشترک pagination (تنها منبع حقیقت)
const apiServerFetch = vi.fn();

vi.mock("@/lib/api-server", () => ({
  apiServerFetch: (...args: unknown[]) => apiServerFetch(...args),
}));

import { fetchPaginated } from "@/lib/paginated-fetch";

beforeEach(() => {
  apiServerFetch.mockReset();
});

describe("fetchPaginated", () => {
  it("پاسخی از نوع envelope {count, results} → items و count واقعی", async () => {
    apiServerFetch.mockResolvedValue({
      count: 137,
      next: "/api/x/?page=2",
      previous: null,
      results: [{ id: 1 }, { id: 2 }],
    });
    const { items, count } = await fetchPaginated<{ id: number }>(
      "/api/core/x/",
      3
    );
    expect(count).toBe(137);
    expect(items).toHaveLength(2);
    expect(apiServerFetch).toHaveBeenCalledWith("/api/core/x/?page=3");
  });

  it("آرایه‌ی خام (endpoint بدون pagination) → count = length آرایه", async () => {
    apiServerFetch.mockResolvedValue([{ id: 1 }, { id: 2 }, { id: 3 }]);
    const { items, count } = await fetchPaginated<{ id: number }>(
      "/api/core/y/",
      1
    );
    expect(count).toBe(3);
    expect(items).toHaveLength(3);
  });

  it("URL با پارامتر موجود → & به‌جای ?", async () => {
    apiServerFetch.mockResolvedValue({ count: 5, results: [] });
    await fetchPaginated("/api/core/z/?ordering=-id", 2);
    expect(apiServerFetch).toHaveBeenCalledWith(
      "/api/core/z/?ordering=-id&page=2"
    );
  });

  it("envelope خالی → items=[] و count=0", async () => {
    apiServerFetch.mockResolvedValue({ count: 0, results: [] });
    const { items, count } = await fetchPaginated("/api/core/w/", 1);
    expect(items).toEqual([]);
    expect(count).toBe(0);
  });
});

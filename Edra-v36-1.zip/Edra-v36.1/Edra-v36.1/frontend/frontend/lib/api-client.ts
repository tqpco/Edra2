// lib/api-client.ts
"use client";

export class ClientApiError extends Error {
  status: number;
  data: unknown;
  constructor(status: number, data: unknown) {
    super((data as { detail?: string })?.detail || `خطا (${status})`);
    this.status = status;
    this.data = data;
  }
}

interface ClientFetchOptions extends Omit<RequestInit, "body"> {
  body?: unknown;
}

/**
 * ارسال درخواست به بک‌اند از طریق پروکسی داخلی
 * توکن به‌طور خودکار توسط پروکسی از کوکی خوانده می‌شود
 */
export async function apiClientFetch<T = unknown>(
  path: string,
  options: ClientFetchOptions = {}
): Promise<T> {
  // path باید با /api/ شروع شود، پروکسی آن را به /api/proxy/ تبدیل می‌کند
  const proxyPath = path.replace(/^\/api\//, "/api/proxy/");
  const { body, headers, ...rest } = options;

  const res = await fetch(proxyPath, {
    ...rest,
    headers: {
      "Content-Type": "application/json",
      ...(headers as Record<string, string>),
    },
    body: body !== undefined ? JSON.stringify(body) : undefined,
  });

  // اگر پاسخ 204 (بدون محتوا) باشد، خالی برگردان
  if (res.status === 204) {
    return {} as T;
  }

  const data = await res.json().catch(() => ({}));
  if (!res.ok) {
    throw new ClientApiError(res.status, data);
  }
  return data as T;
}

/**
 * آپلود فایل (عکس/فیش/پیوست) از طریق پروکسی
 */
export async function apiClientUpload<T = unknown>(
  path: string,
  formData: FormData,
  method: "POST" | "PUT" | "PATCH" = "POST"
): Promise<T> {
  const proxyPath = path.replace(/^\/api\//, "/api/proxy/");
  const res = await fetch(proxyPath, {
    method,
    body: formData,
    // توجه: هدر Content-Type را تنظیم نکنید (فرم‌دیتا خودش boundary را مدیریت می‌کند)
  });

  if (res.status === 204) {
    return {} as T;
  }

  const data = await res.json().catch(() => ({}));
  if (!res.ok) {
    throw new ClientApiError(res.status, data);
  }
  return data as T;
}
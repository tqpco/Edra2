/**
 * lib/api-server.ts
 *
 * فراخوانی بک‌اند جنگو از سمت سرور (Server Components / Route Handlers).
 * توکن را از کوکی httpOnly می‌خواند؛ اگر منقضی بود (۴۰۱)، یک‌بار با
 * refresh token تازه‌سازی می‌کند و درخواست را دوباره می‌فرستد.
 */
import "server-only";
import {
  getAccessToken,
  setAccessToken,
  refreshAccessToken,
} from "./session";
import { getClientIpHeaders } from "./client-ip";

const API_BASE_URL = process.env.NEXT_PUBLIC_API_URL || "http://localhost:8000";

export class ApiError extends Error {
  status: number;
  data: unknown;
  constructor(status: number, data: unknown, message?: string) {
    super(message || `API error ${status}`);
    this.status = status;
    this.data = data;
  }
}

// refresh مشترک single-flight از lib/session.ts استفاده می‌شود
// (EDRA v9 — P1: نسخه محلی قبلی single-flight نداشت؛ چند refresh همزمان
//  می‌توانست logout ناخواسته ایجاد کند.)

interface ApiFetchOptions extends Omit<RequestInit, "body"> {
  body?: unknown;
  /** اگر false باشد، بدون Authorization ارسال می‌شود (برای endpoint های عمومی) */
  authenticated?: boolean;
}

export async function apiServerFetch<T = unknown>(
  path: string,
  options: ApiFetchOptions = {}
): Promise<T> {
  const { body, authenticated = true, headers, ...rest } = options;

  const clientIpHeaders = await getClientIpHeaders();
  const doFetch = async (token?: string) => {
    const finalHeaders: Record<string, string> = {
      "Content-Type": "application/json",
      ...clientIpHeaders,
      ...(headers as Record<string, string>),
    };
    if (authenticated && token) {
      finalHeaders.Authorization = `Bearer ${token}`;
    }
    return fetch(`${API_BASE_URL}${path}`, {
      ...rest,
      headers: finalHeaders,
      body: body !== undefined ? JSON.stringify(body) : undefined,
      cache: rest.cache ?? "no-store",
    });
  };

  const token = authenticated ? await getAccessToken() : undefined;
  let res = await doFetch(token);

  if (res.status === 401 && authenticated) {
    const newToken = await refreshAccessToken();
    if (newToken) {
      res = await doFetch(newToken);
    }
  }

  if (!res.ok) {
    let data: unknown = null;
    try {
      data = await res.json();
    } catch {
      // بدنه خالی یا غیر-JSON بود
    }
    throw new ApiError(res.status, data);
  }

  if (res.status === 204) return undefined as T;
  const data = await res.json();
  // EDRA v18 — باگ #۱ (ممیزی v17): auto-unwrap حذف شد. ۷ صفحه‌ی داشبورد
  // (customer/requests، credit، tickets، admin/customers، admin/experts،
  // admin/tickets، expert/tickets) با انتظار envelope کامل {results,count}
  // نوشته شده‌اند و unwrap آن‌ها را به آرایه‌ی خام می‌رساند → لیست خالی.
  // با برگرداندن پاسخ خام، هر دو گروه مصرف‌کننده درست کار می‌کنند.
  return data as T;
}

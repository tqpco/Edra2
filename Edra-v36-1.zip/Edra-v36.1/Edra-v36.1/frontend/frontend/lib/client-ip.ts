/**
 * lib/client-ip.ts  (EDRA v32)
 *
 * ریشه‌ی یک مشکل جدی در بار همزمان: همه‌ی درخواست‌های مرورگرها از طریق
 * سرور Next.js (BFF) به جنگو می‌رسند، پس جنگو فقط IP کانتینر Next را
 * می‌بیند. throttleهای DRF (otp_request=5/h، otp_verify=10/h، login=20/h،
 * refresh=120/h، anon=1000/day) بر اساس IP شمارش می‌شوند → کل سایت یک
 * «سطل مشترک» داشت؛ با چند کاربر همزمان همه با 429 قفل می‌شدند.
 *
 * اینجا IP واقعی کاربر از هدر X-Forwarded-For (که Nginx با
 * $proxy_add_x_forwarded_for می‌گذارد) خوانده و به جنگو فوروارد می‌شود.
 * فقط «آخرین» آیتم هدر مورد اعتماد است (همانی که Nginx خودش افزوده)؛
 * مقادیری که کاربر خودش در ابتدای هدر جعل کند نادیده گرفته می‌شود.
 * سمت جنگو NUM_PROXIES=1 همین یک آدرس را به‌عنوان IP کلاینت برمی‌دارد.
 */
import "server-only";
import { headers } from "next/headers";

export async function getClientIpHeaders(): Promise<Record<string, string>> {
  try {
    const h = await headers();
    const forwarded = h.get("x-forwarded-for");
    let ip = "";
    if (forwarded) {
      const parts = forwarded
        .split(",")
        .map((p) => p.trim())
        .filter(Boolean);
      ip = parts[parts.length - 1] ?? "";
    } else {
      ip = (h.get("x-real-ip") ?? "").trim();
    }
    return ip ? { "X-Forwarded-For": ip } : {};
  } catch {
    // خارج از context درخواست (مثلاً تست/ساخت استاتیک)
    return {};
  }
}

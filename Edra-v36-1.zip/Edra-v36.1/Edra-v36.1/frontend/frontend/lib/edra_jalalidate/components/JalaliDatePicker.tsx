"use client";
// lib/edra_jalalidate/components/JalaliDatePicker.tsx
import React, { useState, useRef, useEffect, forwardRef, useImperativeHandle } from 'react';
import { JalaliDate, jalaliMonthDays, toPersianDigits } from '../jalali';
import type { JalaliDateObject, JalaliDatePickerProps, JalaliDatePickerRef } from '../types';
import '../styles/jalali-datepicker.css';

export const JalaliDatePicker = forwardRef<JalaliDatePickerRef, JalaliDatePickerProps>(
  (
    {
      value,
      onChange,
      format = 'YYYY/MM/DD',
      usePersianDigits = false,
      placeholder = '۱۴۰۴/۰۵/۱۲',
      className = '',
      disabled = false,
      readOnly = false,
      name,
      id,
    },
    ref,
  ) => {
    const [isOpen, setIsOpen] = useState(false);
    const [inputValue, setInputValue] = useState<string>('');
    const [selectedDate, setSelectedDate] = useState<JalaliDate | null>(null);
    const [viewDate, setViewDate] = useState<JalaliDate | null>(null);
    const containerRef = useRef<HTMLDivElement>(null);
    const inputRef = useRef<HTMLInputElement>(null);

    useEffect(() => {
      let jd: JalaliDate | null = null;
      if (value instanceof Date) {
        jd = JalaliDate.fromDate(value);
      } else if (value && typeof value === 'object' && 'year' in value && !(value instanceof JalaliDate)) {
        const obj = value as JalaliDateObject;
        try {
          jd = new JalaliDate(obj.year, obj.month, obj.day);
        } catch {
          jd = null;
        }
      } else if (typeof value === 'string' && value.trim()) {
        try {
          jd = JalaliDate.fromString(value);
        } catch {
          jd = null;
        }
      } else if (value instanceof JalaliDate) {
        jd = value;
      }
      if (jd) {
        setSelectedDate(jd);
        setInputValue(jd.format(format));
        setViewDate(jd);
      } else {
        setInputValue('');
        setViewDate(JalaliDate.fromDate(new Date()));
      }
    }, [value, format]);

    useEffect(() => {
      const handleClickOutside = (event: MouseEvent) => {
        if (containerRef.current && !containerRef.current.contains(event.target as Node)) {
          setIsOpen(false);
        }
      };
      document.addEventListener('mousedown', handleClickOutside);
      return () => document.removeEventListener('mousedown', handleClickOutside);
    }, []);

    useImperativeHandle(ref, () => ({
      getValue: () => inputValue,
      getJalaliObject: () => selectedDate?.toJSON() || null,
      setValue: (val: string | Date | JalaliDateObject) => {
        let jd: JalaliDate | null = null;
        if (val instanceof Date) {
          jd = JalaliDate.fromDate(val);
        } else if (typeof val === 'string') {
          try {
            jd = JalaliDate.fromString(val);
          } catch {
            jd = null;
          }
        } else if (typeof val === 'object' && 'year' in val) {
          try {
            jd = new JalaliDate(val.year, val.month, val.day);
          } catch {
            jd = null;
          }
        }
        if (jd) {
          setSelectedDate(jd);
          setInputValue(jd.format(format));
          setViewDate(jd);
          onChange?.(jd.format(format), jd.toJSON());
        }
      },
      openPicker: () => !disabled && !readOnly && setIsOpen(true),
      closePicker: () => setIsOpen(false),
    }));

    const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
      const val = e.target.value;
      setInputValue(val);
      try {
        const jd = JalaliDate.fromString(val);
        setSelectedDate(jd);
        setViewDate(jd);
        onChange?.(val, jd.toJSON());
      } catch {
        setSelectedDate(null);
        onChange?.(val, null);
      }
    };

    const handleInputFocus = () => {
      if (!disabled && !readOnly) {
        setIsOpen(true);
      }
    };

    const handleInputKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
      if (e.key === 'Escape') {
        setIsOpen(false);
      }
      if (e.key === 'Enter' && isOpen && viewDate) {
        selectDate(viewDate.year, viewDate.month, viewDate.day);
      }
    };

    const selectDate = (year: number, month: number, day: number) => {
      try {
        const jd = new JalaliDate(year, month, day);
        setSelectedDate(jd);
        const formatted = jd.format(format);
        setInputValue(formatted);
        setViewDate(jd);
        setIsOpen(false);
        onChange?.(formatted, jd.toJSON());
        inputRef.current?.focus();
      } catch (error) {
        console.warn('Invalid date selection:', error);
      }
    };

    const goToMonth = (delta: number) => {
      if (!viewDate) return;
      let newMonth = viewDate.month + delta;
      let newYear = viewDate.year;
      if (newMonth < 1) { newMonth = 12; newYear--; }
      else if (newMonth > 12) { newMonth = 1; newYear++; }
      const maxDay = jalaliMonthDays(newYear, newMonth);
      const newDay = Math.min(viewDate.day, maxDay);
      try {
        setViewDate(new JalaliDate(newYear, newMonth, newDay));
      } catch {
        setViewDate(new JalaliDate(newYear, newMonth, 1));
      }
    };

    const goToToday = () => {
      const today = JalaliDate.fromDate(new Date());
      setViewDate(today);
      selectDate(today.year, today.month, today.day);
    };

    const renderDays = (): React.ReactElement[] => {
      if (!viewDate) return [];
      const year = viewDate.year;
      const month = viewDate.month;
      const daysInMonth = viewDate.daysInMonth();
      const firstDayOfMonth = JalaliDate.fromGregorian(
        viewDate.toGregorian().year,
        viewDate.toGregorian().month,
        1,
      ).weekday();
      const today = JalaliDate.fromDate(new Date());
      const isToday = (d: number) => today.year === year && today.month === month && today.day === d;

      const rows: React.ReactElement[] = [];
      let cells: React.ReactElement[] = [];

      for (let i = 0; i < firstDayOfMonth; i++) {
        cells.push(<td key={`empty-${i}`} className="empty" />);
      }

      for (let d = 1; d <= daysInMonth; d++) {
        const selected = selectedDate && selectedDate.year === year && selectedDate.month === month && selectedDate.day === d;
        const todayClass = isToday(d) ? 'today' : '';
        const selectedClass = selected ? 'selected' : '';
        cells.push(
          <td
            key={d}
            className={`${todayClass} ${selectedClass}`}
            onClick={() => selectDate(year, month, d)}
          >
            {usePersianDigits ? toPersianDigits(d) : d}
          </td>,
        );
        if ((firstDayOfMonth + d - 1) % 7 === 6) {
          rows.push(<tr key={`row-${d}`}>{cells}</tr>);
          cells = [];
        }
      }
      if (cells.length > 0) {
        while (cells.length < 7) {
          cells.push(<td key={`empty-end-${cells.length}`} className="empty" />);
        }
        rows.push(<tr key="row-last">{cells}</tr>);
      }
      return rows;
    };

    const displayNumber = (num: number): string => {
      return usePersianDigits ? toPersianDigits(num) : String(num);
    };

    return (
      <div ref={containerRef} className={`jalali-datepicker-wrapper ${className}`}>
        <input
          ref={inputRef}
          type="text"
          className="jalali-datepicker-input"
          value={inputValue}
          onChange={handleInputChange}
          onFocus={handleInputFocus}
          onKeyDown={handleInputKeyDown}
          placeholder={placeholder}
          disabled={disabled}
          readOnly={readOnly}
          name={name}
          id={id}
          autoComplete="off"
        />
        {isOpen && !disabled && !readOnly && (
          <div className="jalali-datepicker-popup">
            <div className="jalali-datepicker-header">
              <button type="button" className="nav-btn" onClick={() => goToMonth(-1)}>◀</button>
              <span className="month-year">
                {viewDate ? `${displayNumber(viewDate.year)} ${viewDate.monthName('fa')}` : ''}
              </span>
              <button type="button" className="nav-btn" onClick={() => goToMonth(1)}>▶</button>
            </div>
            <table className="jalali-datepicker-table">
              <thead>
                <tr><th>ش</th><th>ی</th><th>د</th><th>س</th><th>چ</th><th>پ</th><th>ج</th></tr>
              </thead>
              <tbody>{renderDays()}</tbody>
            </table>
            <div className="jalali-datepicker-footer">
              <button type="button" className="today-btn" onClick={goToToday}>امروز</button>
              <button type="button" className="close-btn" onClick={() => setIsOpen(false)}>بستن</button>
            </div>
          </div>
        )}
      </div>
    );
  },
);

JalaliDatePicker.displayName = 'JalaliDatePicker';
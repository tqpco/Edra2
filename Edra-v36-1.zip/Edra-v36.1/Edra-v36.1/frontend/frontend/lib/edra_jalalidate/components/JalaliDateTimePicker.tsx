"use client";
// lib/edra_jalalidate/components/JalaliDateTimePicker.tsx
import React, { useState, useRef, useEffect, forwardRef, useImperativeHandle } from 'react';
import { JalaliDate, JalaliDateTime, jalaliMonthDays, toPersianDigits } from '../jalali';
import type { JalaliDateObject, JalaliDateTimePickerProps, JalaliDatePickerRef } from '../types';
import '../styles/jalali-datepicker.css';

export const JalaliDateTimePicker = forwardRef<JalaliDatePickerRef, JalaliDateTimePickerProps>(
  (
    {
      value,
      onChange,
      format = 'YYYY/MM/DD HH:mm',
      usePersianDigits = false,
      placeholder = '۱۴۰۴/۰۵/۱۲ ۱۴:۳۰',
      className = '',
      disabled = false,
      readOnly = false,
      name,
      id,
    },
    ref,
  ) => {
    const [isOpen, setIsOpen] = useState(false);
    const [inputValue, setInputValue] = useState<string>('');
    const [selectedDateTime, setSelectedDateTime] = useState<JalaliDateTime | null>(null);
    const [viewDate, setViewDate] = useState<JalaliDate | null>(null);
    const [selectedHour, setSelectedHour] = useState<number>(0);
    const [selectedMinute, setSelectedMinute] = useState<number>(0);
    const containerRef = useRef<HTMLDivElement>(null);
    const inputRef = useRef<HTMLInputElement>(null);

    useEffect(() => {
      let jdt: JalaliDateTime | null = null;
      if (value instanceof Date) {
        jdt = JalaliDateTime.fromDate(value);
      } else if (typeof value === 'string' && value.trim()) {
        try {
          const parts = value.split(/[ /:]/);
          if (parts.length >= 5) {
            const year = parseInt(parts[0]!, 10);
            const month = parseInt(parts[1]!, 10);
            const day = parseInt(parts[2]!, 10);
            const hour = parseInt(parts[3]!, 10);
            const minute = parseInt(parts[4]!, 10);
            const second = parts.length > 5 ? parseInt(parts[5]!, 10) : 0;
            jdt = new JalaliDateTime(year, month, day, hour, minute, second);
          } else {
            const jd = JalaliDate.fromString(value);
            const now = new Date();
            jdt = new JalaliDateTime(jd.year, jd.month, jd.day, now.getHours(), now.getMinutes(), 0);
          }
        } catch {
          jdt = null;
        }
      } else if (value && typeof value === 'object' && 'year' in value) {
        const obj = value as any;
        try {
          jdt = new JalaliDateTime(obj.year, obj.month, obj.day, obj.hour || 0, obj.minute || 0, obj.second || 0);
        } catch {
          jdt = null;
        }
      }
      if (jdt) {
        setSelectedDateTime(jdt);
        setInputValue(jdt.format(format));
        setViewDate(jdt.date);
        setSelectedHour(jdt.hour);
        setSelectedMinute(jdt.minute);
      } else {
        const now = JalaliDateTime.fromDate(new Date());
        setViewDate(now.date);
        setSelectedHour(now.hour);
        setSelectedMinute(now.minute);
        setInputValue('');
      }
    }, [value, format]);

    useEffect(() => {
      const handleClickOutside = (event: MouseEvent) => {
        if (containerRef.current && !containerRef.current.contains(event.target as Node)) {
          setIsOpen(false);
        }
      };
      document.addEventListener('mousedown', handleClickOutside);
      return () => document.removeEventListener('mousedown', handleClickOutside);
    }, []);

    useImperativeHandle(ref, () => ({
      getValue: () => inputValue,
      getJalaliObject: () => selectedDateTime?.toJSON() || null,
      setValue: (val: string | Date | JalaliDateObject) => {
        let jdt: JalaliDateTime | null = null;
        if (val instanceof Date) {
          jdt = JalaliDateTime.fromDate(val);
        } else if (typeof val === 'string') {
          try {
            const parts = val.split(/[ /:]/);
            if (parts.length >= 5) {
              const year = parseInt(parts[0]!, 10);
              const month = parseInt(parts[1]!, 10);
              const day = parseInt(parts[2]!, 10);
              const hour = parseInt(parts[3]!, 10);
              const minute = parseInt(parts[4]!, 10);
              const second = parts.length > 5 ? parseInt(parts[5]!, 10) : 0;
              jdt = new JalaliDateTime(year, month, day, hour, minute, second);
            } else {
              const jd = JalaliDate.fromString(val);
              const now = new Date();
              jdt = new JalaliDateTime(jd.year, jd.month, jd.day, now.getHours(), now.getMinutes(), 0);
            }
          } catch {
            jdt = null;
          }
        }
        if (jdt) {
          setSelectedDateTime(jdt);
          setInputValue(jdt.format(format));
          setViewDate(jdt.date);
          setSelectedHour(jdt.hour);
          setSelectedMinute(jdt.minute);
          onChange?.(jdt.format(format), jdt.toJSON());
        }
      },
      openPicker: () => !disabled && !readOnly && setIsOpen(true),
      closePicker: () => setIsOpen(false),
    }));

    const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
      const val = e.target.value;
      setInputValue(val);
      try {
        const parts = val.split(/[ /:]/);
        if (parts.length >= 5) {
          const year = parseInt(parts[0]!, 10);
          const month = parseInt(parts[1]!, 10);
          const day = parseInt(parts[2]!, 10);
          const hour = parseInt(parts[3]!, 10);
          const minute = parseInt(parts[4]!, 10);
          const second = parts.length > 5 ? parseInt(parts[5]!, 10) : 0;
          const jdt = new JalaliDateTime(year, month, day, hour, minute, second);
          setSelectedDateTime(jdt);
          setViewDate(jdt.date);
          setSelectedHour(hour);
          setSelectedMinute(minute);
          onChange?.(val, jdt.toJSON());
        } else {
          const jd = JalaliDate.fromString(val);
          const now = new Date();
          const jdt = new JalaliDateTime(jd.year, jd.month, jd.day, now.getHours(), now.getMinutes(), 0);
          setSelectedDateTime(jdt);
          setViewDate(jdt.date);
          setSelectedHour(jdt.hour);
          setSelectedMinute(jdt.minute);
          onChange?.(val, jdt.toJSON());
        }
      } catch {
        setSelectedDateTime(null);
        onChange?.(val, null);
      }
    };

    const selectDateTime = (year: number, month: number, day: number, hour?: number, minute?: number) => {
      try {
        const h = hour !== undefined ? hour : selectedHour;
        const m = minute !== undefined ? minute : selectedMinute;
        const jdt = new JalaliDateTime(year, month, day, h, m, 0);
        setSelectedDateTime(jdt);
        const formatted = jdt.format(format);
        setInputValue(formatted);
        setViewDate(jdt.date);
        setSelectedHour(h);
        setSelectedMinute(m);
        setIsOpen(false);
        onChange?.(formatted, jdt.toJSON());
        inputRef.current?.focus();
      } catch (error) {
        console.warn('Invalid datetime selection:', error);
      }
    };

    const renderDays = (): React.ReactElement[] => {
      if (!viewDate) return [];
      const year = viewDate.year;
      const month = viewDate.month;
      const daysInMonth = viewDate.daysInMonth();
      const firstDayOfMonth = JalaliDate.fromGregorian(
        viewDate.toGregorian().year,
        viewDate.toGregorian().month,
        1,
      ).weekday();
      const today = JalaliDate.fromDate(new Date());
      const isToday = (d: number) => today.year === year && today.month === month && today.day === d;

      const rows: React.ReactElement[] = [];
      let cells: React.ReactElement[] = [];

      for (let i = 0; i < firstDayOfMonth; i++) {
        cells.push(<td key={`empty-${i}`} className="empty" />);
      }

      for (let d = 1; d <= daysInMonth; d++) {
        const selected = selectedDateTime &&
          selectedDateTime.date.year === year &&
          selectedDateTime.date.month === month &&
          selectedDateTime.date.day === d;
        const todayClass = isToday(d) ? 'today' : '';
        const selectedClass = selected ? 'selected' : '';
        cells.push(
          <td
            key={d}
            className={`${todayClass} ${selectedClass}`}
            onClick={() => selectDateTime(year, month, d, selectedHour, selectedMinute)}
          >
            {usePersianDigits ? toPersianDigits(d) : d}
          </td>,
        );
        if ((firstDayOfMonth + d - 1) % 7 === 6) {
          rows.push(<tr key={`row-${d}`}>{cells}</tr>);
          cells = [];
        }
      }
      if (cells.length > 0) {
        while (cells.length < 7) {
          cells.push(<td key={`empty-end-${cells.length}`} className="empty" />);
        }
        rows.push(<tr key="row-last">{cells}</tr>);
      }
      return rows;
    };

    const goToMonth = (delta: number) => {
      if (!viewDate) return;
      let newMonth = viewDate.month + delta;
      let newYear = viewDate.year;
      if (newMonth < 1) { newMonth = 12; newYear--; }
      else if (newMonth > 12) { newMonth = 1; newYear++; }
      const maxDay = jalaliMonthDays(newYear, newMonth);
      const newDay = Math.min(viewDate.day, maxDay);
      try {
        setViewDate(new JalaliDate(newYear, newMonth, newDay));
      } catch {
        setViewDate(new JalaliDate(newYear, newMonth, 1));
      }
    };

    const goToToday = () => {
      const now = JalaliDateTime.fromDate(new Date());
      setViewDate(now.date);
      setSelectedHour(now.hour);
      setSelectedMinute(now.minute);
      selectDateTime(now.date.year, now.date.month, now.date.day, now.hour, now.minute);
    };

    const displayNumber = (num: number): string => {
      return usePersianDigits ? toPersianDigits(num) : String(num);
    };

    return (
      <div ref={containerRef} className={`jalali-datepicker-wrapper ${className}`}>
        <input
          ref={inputRef}
          type="text"
          className="jalali-datepicker-input"
          value={inputValue}
          onChange={handleInputChange}
          onFocus={() => !disabled && !readOnly && setIsOpen(true)}
          onKeyDown={(e) => e.key === 'Escape' && setIsOpen(false)}
          placeholder={placeholder}
          disabled={disabled}
          readOnly={readOnly}
          name={name}
          id={id}
          autoComplete="off"
        />
        {isOpen && !disabled && !readOnly && (
          <div className="jalali-datepicker-popup jalali-datetime-popup">
            <div className="jalali-datepicker-header">
              <button type="button" className="nav-btn" onClick={() => goToMonth(-1)}>◀</button>
              <span className="month-year">
                {viewDate ? `${displayNumber(viewDate.year)} ${viewDate.monthName('fa')}` : ''}
              </span>
              <button type="button" className="nav-btn" onClick={() => goToMonth(1)}>▶</button>
            </div>
            <table className="jalali-datepicker-table">
              <thead>
                <tr><th>ش</th><th>ی</th><th>د</th><th>س</th><th>چ</th><th>پ</th><th>ج</th></tr>
              </thead>
              <tbody>{renderDays()}</tbody>
            </table>
            <div className="jalali-datetime-time">
              <div className="time-selector">
                <label>ساعت</label>
                <input
                  type="number"
                  min="0"
                  max="23"
                  value={selectedHour}
                  onChange={(e) => {
                    const val = parseInt(e.target.value, 10);
                    if (!isNaN(val) && val >= 0 && val <= 23) {
                      setSelectedHour(val);
                      if (selectedDateTime) {
                        const jdt = new JalaliDateTime(
                          selectedDateTime.date.year,
                          selectedDateTime.date.month,
                          selectedDateTime.date.day,
                          val,
                          selectedMinute,
                          0,
                        );
                        setSelectedDateTime(jdt);
                        setInputValue(jdt.format(format));
                        onChange?.(jdt.format(format), jdt.toJSON());
                      }
                    }
                  }}
                />
              </div>
              <div className="time-selector">
                <label>دقیقه</label>
                <input
                  type="number"
                  min="0"
                  max="59"
                  value={selectedMinute}
                  onChange={(e) => {
                    const val = parseInt(e.target.value, 10);
                    if (!isNaN(val) && val >= 0 && val <= 59) {
                      setSelectedMinute(val);
                      if (selectedDateTime) {
                        const jdt = new JalaliDateTime(
                          selectedDateTime.date.year,
                          selectedDateTime.date.month,
                          selectedDateTime.date.day,
                          selectedHour,
                          val,
                          0,
                        );
                        setSelectedDateTime(jdt);
                        setInputValue(jdt.format(format));
                        onChange?.(jdt.format(format), jdt.toJSON());
                      }
                    }
                  }}
                />
              </div>
            </div>
            <div className="jalali-datepicker-footer">
              <button type="button" className="today-btn" onClick={goToToday}>اکنون</button>
              <button type="button" className="close-btn" onClick={() => setIsOpen(false)}>بستن</button>
            </div>
          </div>
        )}
      </div>
    );
  },
);

JalaliDateTimePicker.displayName = 'JalaliDateTimePicker';
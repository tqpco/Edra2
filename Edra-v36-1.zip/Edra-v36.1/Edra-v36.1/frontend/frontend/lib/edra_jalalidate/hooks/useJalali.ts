"use client";
// lib/edra_jalalidate/hooks/useJalali.ts
import { useState, useEffect, useCallback, useMemo } from 'react';
import { JalaliDate, JalaliDateTime } from '../jalali';
import { getAccurateDateTime } from '../ntp';

interface UseJalaliOptions {
  accurate?: boolean;
}

export function useJalaliToday(options: UseJalaliOptions = {}) {
  const { accurate = false } = options;
  const [date, setDate] = useState<JalaliDate | null>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<Error | null>(null);

  const fetchToday = useCallback(async () => {
    try {
      setLoading(true);
      setError(null);
      const dt = accurate ? await getAccurateDateTime(true) : new Date();
      setDate(JalaliDate.fromDate(dt));
    } catch (err) {
      setError(err instanceof Error ? err : new Error('خطا در دریافت تاریخ'));
    } finally {
      setLoading(false);
    }
  }, [accurate]);

  useEffect(() => {
    fetchToday();
    const interval = setInterval(() => {
      if (!accurate) {
        setDate(JalaliDate.fromDate(new Date()));
      }
    }, 60000);
    return () => clearInterval(interval);
  }, [accurate, fetchToday]);

  return { date, loading, error, refetch: fetchToday };
}

export function useJalaliNow(options: UseJalaliOptions = {}) {
  const { accurate = false } = options;
  const [datetime, setDatetime] = useState<JalaliDateTime | null>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<Error | null>(null);

  const fetchNow = useCallback(async () => {
    try {
      setLoading(true);
      setError(null);
      const dt = accurate ? await getAccurateDateTime(true) : new Date();
      setDatetime(JalaliDateTime.fromDate(dt));
    } catch (err) {
      setError(err instanceof Error ? err : new Error('خطا در دریافت زمان'));
    } finally {
      setLoading(false);
    }
  }, [accurate]);

  useEffect(() => {
    fetchNow();
    const interval = setInterval(() => {
      if (!accurate) {
        setDatetime(JalaliDateTime.fromDate(new Date()));
      } else {
        fetchNow();
      }
    }, accurate ? 10000 : 1000);
    return () => clearInterval(interval);
  }, [accurate, fetchNow]);

  return { datetime, loading, error, refetch: fetchNow };
}

export function useJalaliDate(date: Date | string | null | undefined): JalaliDate | null {
  return useMemo(() => {
    if (!date) return null;
    const d = typeof date === 'string' ? new Date(date) : date;
    if (isNaN(d.getTime())) return null;
    return JalaliDate.fromDate(d);
  }, [date]);
}

export function useJalaliDateTime(date: Date | string | null | undefined): JalaliDateTime | null {
  return useMemo(() => {
    if (!date) return null;
    const d = typeof date === 'string' ? new Date(date) : date;
    if (isNaN(d.getTime())) return null;
    return JalaliDateTime.fromDate(d);
  }, [date]);
}

export function useJalaliField(initialValue?: string | Date | JalaliDate | null) {
  const [value, setValue] = useState<string>('');
  const [jalaliObject, setJalaliObject] = useState<JalaliDate | null>(null);

  const setFromDate = useCallback((date: Date | string | JalaliDate | null) => {
    if (!date) {
      setValue('');
      setJalaliObject(null);
      return;
    }
    let jd: JalaliDate;
    if (date instanceof JalaliDate) {
      jd = date;
    } else if (typeof date === 'string') {
      try {
        jd = JalaliDate.fromString(date);
      } catch {
        jd = JalaliDate.fromDate(new Date(date));
      }
    } else {
      jd = JalaliDate.fromDate(date);
    }
    setValue(jd.format('YYYY/MM/DD'));
    setJalaliObject(jd);
  }, []);

  const setFromString = useCallback((str: string) => {
    try {
      const jd = JalaliDate.fromString(str);
      setValue(jd.format('YYYY/MM/DD'));
      setJalaliObject(jd);
    } catch {
      setValue(str);
      setJalaliObject(null);
    }
  }, []);

  const onChange = useCallback((newValue: string) => {
    setFromString(newValue);
  }, [setFromString]);

  useEffect(() => {
    if (initialValue) {
      setFromDate(initialValue);
    }
  }, [initialValue, setFromDate]);

  return {
    value,
    jalaliObject,
    setValue: onChange,
    setFromDate,
    setFromString,
  };
}
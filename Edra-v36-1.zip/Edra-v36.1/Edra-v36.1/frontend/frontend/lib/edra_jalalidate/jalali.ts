// lib/edra_jalalidate/jalali.ts
import type { JalaliDateObject, JalaliDateTimeObject } from './types';

// ============================================================
// ثابت‌های مرجع (هماهنگ با بک‌اند)
// ============================================================
const REF_JALALI_YEAR = 1400;
const REF_JALALI_MONTH = 1;
const REF_JALALI_DAY = 1;
const REF_GREGORIAN = new Date(Date.UTC(2021, 2, 21, 12, 0, 0)); // 2021-03-21

const LEAP_EXCEPTIONS = new Set([1408, 1412, 1416]);
const COMMON_EXCEPTIONS = new Set([1407]);

// ============================================================
// نام‌ها
// ============================================================
export const MONTH_NAMES_FA = [
  'فروردین', 'اردیبهشت', 'خرداد', 'تیر', 'مرداد', 'شهریور',
  'مهر', 'آبان', 'آذر', 'دی', 'بهمن', 'اسفند',
];
export const MONTH_NAMES_EN = [
  'Farvardin', 'Ordibehesht', 'Khordad', 'Tir', 'Mordad', 'Shahrivar',
  'Mehr', 'Aban', 'Azar', 'Dey', 'Bahman', 'Esfand',
];
export const DAY_NAMES_FA = ['شنبه', 'یکشنبه', 'دوشنبه', 'سه‌شنبه', 'چهارشنبه', 'پنجشنبه', 'جمعه'];
export const DAY_NAMES_EN = ['Saturday', 'Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday'];

// ============================================================
// هسته تبدیل (همان الگوریتم بک‌اند)
// ============================================================

export function isJalaliLeapYear(year: number): boolean {
  if (COMMON_EXCEPTIONS.has(year)) return false;
  const rem = year % 33;
  const standardLeap = rem === 1 || rem === 5 || rem === 9 || rem === 13 ||
                       rem === 17 || rem === 21 || rem === 26 || rem === 30;
  if (LEAP_EXCEPTIONS.has(year)) return true;
  return standardLeap;
}

export function jalaliMonthDays(year: number, month: number): number {
  if (month < 1 || month > 12) throw new Error('ماه باید بین ۱ تا ۱۲ باشد');
  if (month <= 6) return 31;
  if (month <= 11) return 30;
  // EDRA v27 — رفع باگ واقعی (گزارش کاربر، سپتامبر ۲۰۲۶): اسفند در
  // سال کبیسه ۳۰ روز دارد، نه همیشه ۲۹ — این دقیقاً همان چیزی است که
  // یک سال جلالی را «کبیسه» می‌کند (مشابه ۲۹ اسفند/فوریه در تقویم
  // میلادی). نسخه‌ی قبلی این تابع همیشه ۲۹ برمی‌گرداند و کاملاً با
  // پیاده‌سازی صحیح بک‌اند (_jalali_core.py) ناهماهنگ بود — یعنی هر
  // سال کبیسه (هر ۴ سال یک‌بار)، انتخاب/محاسبه‌ی تاریخ نزدیک پایان سال
  // در فرانت‌اند یک روز اشتباه می‌شد.
  return isJalaliLeapYear(year) ? 30 : 29;
}

function jalaliToDaysSinceRef(year: number, month: number, day: number): number {
  let days = 0;
  for (let y = REF_JALALI_YEAR; y < year; y++) {
    days += 365 + (isJalaliLeapYear(y) ? 1 : 0);
  }
  for (let m = 1; m < month; m++) {
    days += jalaliMonthDays(year, m);
  }
  days += day - 1;
  return days;
}

export function jalaliToGregorian(year: number, month: number, day: number): { year: number; month: number; day: number } {
  const daysOffset = jalaliToDaysSinceRef(year, month, day);
  const target = new Date(REF_GREGORIAN.getTime() + daysOffset * 86400000);
  return {
    year: target.getUTCFullYear(),
    month: target.getUTCMonth() + 1,
    day: target.getUTCDate(),
  };
}

export function gregorianToJalali(year: number, month: number, day: number): JalaliDateObject {
  const target = new Date(Date.UTC(year, month - 1, day, 12, 0, 0));
  const deltaDays = Math.round((target.getTime() - REF_GREGORIAN.getTime()) / 86400000);
  if (deltaDays < 0) {
    throw new Error('تاریخ میلادی قبل از مرجع (۱۴۰۰/۰۱/۰۱) است');
  }
  let yearGuess = REF_JALALI_YEAR;
  let remaining = deltaDays;
  while (true) {
    const daysInYear = 365 + (isJalaliLeapYear(yearGuess) ? 1 : 0);
    if (remaining < daysInYear) break;
    remaining -= daysInYear;
    yearGuess++;
  }
  let monthGuess = 1;
  while (monthGuess <= 12) {
    const daysInMonth = jalaliMonthDays(yearGuess, monthGuess);
    if (remaining < daysInMonth) break;
    remaining -= daysInMonth;
    monthGuess++;
  }
  const dayGuess = remaining + 1;
  return { year: yearGuess, month: monthGuess, day: dayGuess };
}

// ============================================================
// کلاس JalaliDate
// ============================================================
export class JalaliDate {
  readonly year: number;
  readonly month: number;
  readonly day: number;

  constructor(year: number, month: number, day: number) {
    if (month < 1 || month > 12) throw new Error('ماه باید بین ۱ تا ۱۲ باشد');
    const maxDay = jalaliMonthDays(year, month);
    if (day < 1 || day > maxDay) throw new Error(`روز باید بین ۱ تا ${maxDay} باشد`);
    this.year = year;
    this.month = month;
    this.day = day;
  }

  static fromGregorian(year: number, month: number, day: number): JalaliDate {
    const j = gregorianToJalali(year, month, day);
    return new JalaliDate(j.year, j.month, j.day);
  }

  static fromDate(date: Date): JalaliDate {
    return JalaliDate.fromGregorian(date.getFullYear(), date.getMonth() + 1, date.getDate());
  }

  static fromString(str: string, _format: string = 'YYYY/MM/DD'): JalaliDate {
    const cleaned = toEnglishDigits(str.trim());
    const parts = cleaned.split(/[\/\-]/);
    if (parts.length !== 3) throw new Error('فرمت تاریخ نامعتبر است');
    const year = parseInt(parts[0]!, 10);
    const month = parseInt(parts[1]!, 10);
    const day = parseInt(parts[2]!, 10);
    if (isNaN(year) || isNaN(month) || isNaN(day) || year < 1) {
      throw new Error('تاریخ نامعتبر است');
    }
    return new JalaliDate(year, month, day);
  }

  toGregorian(): { year: number; month: number; day: number } {
    return jalaliToGregorian(this.year, this.month, this.day);
  }

  toDate(): Date {
    const g = this.toGregorian();
    return new Date(g.year, g.month - 1, g.day);
  }

  weekday(): number {
    const jdn = this.toJd();
    return (jdn + 2) % 7; // 0=شنبه
  }

  dayOfYear(): number {
    let days = 0;
    for (let m = 1; m < this.month; m++) {
      days += jalaliMonthDays(this.year, m);
    }
    return days + this.day;
  }

  daysInMonth(): number {
    return jalaliMonthDays(this.year, this.month);
  }

  isLeapYear(): boolean {
    return isJalaliLeapYear(this.year);
  }

  monthName(lang: 'fa' | 'en' = 'fa'): string {
    return lang === 'fa' ? MONTH_NAMES_FA[this.month - 1]! : MONTH_NAMES_EN[this.month - 1]!;
  }

  dayName(lang: 'fa' | 'en' = 'fa'): string {
    const wd = this.weekday();
    return lang === 'fa' ? DAY_NAMES_FA[wd]! : DAY_NAMES_EN[wd]!;
  }

  format(fmt: string = 'YYYY/MM/DD'): string {
    const replacements: Record<string, string> = {
      YYYY: String(this.year).padStart(4, '0'),
      YY: String(this.year % 100).padStart(2, '0'),
      MM: String(this.month).padStart(2, '0'),
      M: String(this.month),
      DD: String(this.day).padStart(2, '0'),
      D: String(this.day),
      MMMM: this.monthName('fa'),
      MMM: this.monthName('fa'),
      dddd: this.dayName('fa'),
      ddd: this.dayName('fa'),
    };
    let result = fmt;
    for (const [key, val] of Object.entries(replacements)) {
      result = result.replaceAll(key, val);
    }
    return result;
  }

  toString(): string {
    return this.format('YYYY/MM/DD');
  }

  toJSON(): JalaliDateObject {
    return { year: this.year, month: this.month, day: this.day };
  }

  equals(other: JalaliDate): boolean {
    return this.year === other.year && this.month === other.month && this.day === other.day;
  }

  compare(other: JalaliDate): number {
    const diff = this.year - other.year;
    if (diff !== 0) return diff;
    const diffM = this.month - other.month;
    if (diffM !== 0) return diffM;
    return this.day - other.day;
  }

  // برای سازگاری با کد قبلی
  toJd(): number {
    let days = 0;
    for (let y = 1; y < this.year; y++) {
      days += 365 + (isJalaliLeapYear(y) ? 1 : 0);
    }
    for (let m = 1; m < this.month; m++) {
      days += jalaliMonthDays(this.year, m);
    }
    days += this.day - 1;
    // JDN مرجع جلالی (عدد ثابت) = 1948320.5، ولی ما عدد صحیح می‌خواهیم
    return days + 1948320; // مقدار تقریبی
  }
}

// ============================================================
// کلاس JalaliDateTime
// ============================================================
export class JalaliDateTime {
  readonly date: JalaliDate;
  readonly hour: number;
  readonly minute: number;
  readonly second: number;
  readonly microsecond: number;

  constructor(
    year: number,
    month: number,
    day: number,
    hour: number = 0,
    minute: number = 0,
    second: number = 0,
    microsecond: number = 0,
  ) {
    this.date = new JalaliDate(year, month, day);
    this.hour = hour;
    this.minute = minute;
    this.second = second;
    this.microsecond = microsecond;
    this._validateTime();
  }

  private _validateTime(): void {
    if (this.hour < 0 || this.hour > 23) throw new Error('ساعت باید بین ۰ تا ۲۳ باشد');
    if (this.minute < 0 || this.minute > 59) throw new Error('دقیقه باید بین ۰ تا ۵۹ باشد');
    if (this.second < 0 || this.second > 59) throw new Error('ثانیه باید بین ۰ تا ۵۹ باشد');
    if (this.microsecond < 0 || this.microsecond > 999999) throw new Error('میکروثانیه نامعتبر است');
  }

  static fromGregorian(
    year: number,
    month: number,
    day: number,
    hour: number = 0,
    minute: number = 0,
    second: number = 0,
    microsecond: number = 0,
  ): JalaliDateTime {
    const j = gregorianToJalali(year, month, day);
    return new JalaliDateTime(j.year, j.month, j.day, hour, minute, second, microsecond);
  }

  static fromDate(date: Date): JalaliDateTime {
    return JalaliDateTime.fromGregorian(
      date.getFullYear(),
      date.getMonth() + 1,
      date.getDate(),
      date.getHours(),
      date.getMinutes(),
      date.getSeconds(),
      date.getMilliseconds() * 1000,
    );
  }

  static fromString(str: string, _format: string = 'YYYY/MM/DD HH:mm'): JalaliDateTime {
    const cleaned = toEnglishDigits(str.trim());
    const parts = cleaned.split(/[\/\- :]/);
    if (parts.length < 5) throw new Error('فرمت تاریخ و ساعت نامعتبر است');
    const year = parseInt(parts[0]!, 10);
    const month = parseInt(parts[1]!, 10);
    const day = parseInt(parts[2]!, 10);
    const hour = parseInt(parts[3]!, 10);
    const minute = parseInt(parts[4]!, 10);
    const second = parts.length > 5 ? parseInt(parts[5]!, 10) : 0;
    if (isNaN(year) || isNaN(month) || isNaN(day) || isNaN(hour) || isNaN(minute) || isNaN(second)) {
      throw new Error('تاریخ و ساعت نامعتبر است');
    }
    return new JalaliDateTime(year, month, day, hour, minute, second);
  }

  toDate(): Date {
    const g = this.date.toGregorian();
    return new Date(g.year, g.month - 1, g.day, this.hour, this.minute, this.second, this.microsecond / 1000);
  }

  format(fmt: string = 'YYYY/MM/DD HH:mm'): string {
    let result = this.date.format(fmt);
    const replacements: Record<string, string> = {
      HH: String(this.hour).padStart(2, '0'),
      H: String(this.hour),
      mm: String(this.minute).padStart(2, '0'),
      m: String(this.minute),
      ss: String(this.second).padStart(2, '0'),
      s: String(this.second),
      f: String(this.microsecond).padStart(6, '0'),
    };
    for (const [key, val] of Object.entries(replacements)) {
      result = result.replaceAll(key, val);
    }
    return result;
  }

  toString(): string {
    return this.format('YYYY/MM/DD HH:mm');
  }

  toJSON(): JalaliDateTimeObject {
    return {
      year: this.date.year,
      month: this.date.month,
      day: this.date.day,
      hour: this.hour,
      minute: this.minute,
      second: this.second,
      microsecond: this.microsecond,
    };
  }
}

// ============================================================
// توابع کمکی سطح بالا
// ============================================================
export function toJalaliString(date: Date | string, fmt: string = 'YYYY/MM/DD'): string {
  const d = typeof date === 'string' ? new Date(date) : date;
  const jd = JalaliDate.fromDate(d);
  return jd.format(fmt);
}

export function toJalaliDateTimeString(date: Date | string, fmt: string = 'YYYY/MM/DD HH:mm'): string {
  const d = typeof date === 'string' ? new Date(date) : date;
  const jdt = JalaliDateTime.fromDate(d);
  return jdt.format(fmt);
}

export function parseJalali(str: string): JalaliDate {
  return JalaliDate.fromString(str);
}

export function parseJalaliDateTime(str: string): JalaliDateTime {
  return JalaliDateTime.fromString(str);
}

// ============================================================
// تبدیل ارقام
// ============================================================
const PERSIAN_DIGITS = ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'];

export function toPersianDigits(input: string | number): string {
  return String(input).replace(/[0-9]/g, (d) => PERSIAN_DIGITS[Number(d)]!);
}

export function toEnglishDigits(input: string): string {
  return input
    .replace(/[۰-۹]/g, (d) => String(PERSIAN_DIGITS.indexOf(d)))
    .replace(/[٠-٩]/g, (d) => String(d.charCodeAt(0) - 1632));
}

// ============================================================
// میان‌برهای اضافی
// ============================================================
export function dateToJalali(date: Date): JalaliDateObject {
  return gregorianToJalali(date.getFullYear(), date.getMonth() + 1, date.getDate());
}

export function jalaliToDate(jy: number, jm: number, jd: number): Date {
  const g = jalaliToGregorian(jy, jm, jd);
  return new Date(g.year, g.month - 1, g.day);
}

export function formatJalali(date: Date | JalaliDate): string {
  const j = date instanceof Date ? dateToJalali(date) : { year: date.year, month: date.month, day: date.day };
  return `${toPersianDigits(j.day)} ${MONTH_NAMES_FA[j.month - 1]!} ${toPersianDigits(j.year)}`;
}

export function formatJalaliNumeric(date: Date | JalaliDate, separator: string = '/'): string {
  const j = date instanceof Date ? dateToJalali(date) : { year: date.year, month: date.month, day: date.day };
  const mm = String(j.month).padStart(2, '0');
  const dd = String(j.day).padStart(2, '0');
  return toPersianDigits(`${j.year}${separator}${mm}${separator}${dd}`);
}

// ============================================================
// ✅ اصلاح تابع formatJalaliWithWeekday (رفع اشتباه روز هفته)
// ============================================================
export function formatJalaliWithWeekday(date: Date): string {
  const jd = JalaliDate.fromDate(date);
  const weekday = jd.dayName('fa');
  return `${weekday}، ${formatJalali(date)}`;
}

export function formatPersianTime(date: Date): string {
  const hh = String(date.getHours()).padStart(2, '0');
  const mm = String(date.getMinutes()).padStart(2, '0');
  return toPersianDigits(`${hh}:${mm}`);
}

// ============================================================
// توابع مربوط به برنامه‌ریزی (scheduling)
// ============================================================

// این تابع برای پیدا کردن اولین روز قابل رزرو (مثلاً فردا یا روز کاری بعدی)
export function earliestBookableDate(): Date {
  const now = new Date();
  // فردا را در نظر می‌گیریم
  let candidate = new Date(now);
  candidate.setDate(candidate.getDate() + 1);
  // اگر روز تعطیل (جمعه) باشد، به روز بعدی می‌رویم
  while (!isWorkingDay(candidate)) {
    candidate.setDate(candidate.getDate() + 1);
  }
  // ساعت را به ابتدای روز تنظیم می‌کنیم (برای مقایسه)
  candidate.setHours(0, 0, 0, 0);
  return candidate;
}

// بررسی روز کاری (جمعه تعطیل)
export function isWorkingDay(date: Date): boolean {
  const day = date.getDay(); // 0=Sunday, 1=Monday, ... 6=Saturday
  // در تقویم ایران جمعه = 5 (Friday)
  return day !== 5;
}

// تعداد روزهای ماه جلالی
export function jalaliMonthLength(year: number, month: number): number {
  return jalaliMonthDays(year, month);
}

// لیست اسامی ماه‌های جلالی
export const JALALI_MONTH_NAMES = MONTH_NAMES_FA;

// لیست ساعات کاری (۸ تا ۱۶)
export function availableTimeSlots(): string[] {
  const slots: string[] = [];
  for (let h = 8; h < 16; h++) {
    const hourStr = String(h).padStart(2, '0');
    slots.push(`${hourStr}:00`);
    slots.push(`${hourStr}:30`);
  }
  return slots;
}

// ============================================================
// صادرات دیگر
// ============================================================
export * from './types';
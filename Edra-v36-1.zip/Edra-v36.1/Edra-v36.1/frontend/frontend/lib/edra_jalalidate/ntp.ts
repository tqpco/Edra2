// lib/edra_jalalidate/ntp.ts
import { JalaliDate, JalaliDateTime } from './jalali';

export interface NtpResponse {
  datetime: string;
}

export async function getAccurateDateTime(fallbackToSystem: boolean = true): Promise<Date> {
  try {
    // EDRA v32 — باگ واقعی: این تابع از کامپوننت‌های کلاینت (مثلاً مرحله‌ی
    // زمان‌بندی ویزارد) در مرورگر کاربر اجرا می‌شود، ولی قبلاً مستقیماً
    // NEXT_PUBLIC_API_URL (در production چیزی مثل http://backend:8000 —
    // آدرس داخلی شبکه‌ی Docker) را fetch می‌کرد. این میزبان از بیرون قابل
    // resolve نیست؛ یعنی در محیط واقعی (نه روی لپ‌تاپ توسعه‌دهنده، که
    // NEXT_PUBLIC_API_URL=http://localhost:8000 تصادفاً برای مرورگر خودش هم
    // کار می‌کرد) این fetch همیشه fail می‌شد و بی‌صدا به ساعت دستگاه کاربر
    // سقوط می‌کرد — دقیقاً همان مشکلی که این قابلیت قرار بود حلش کند.
    // رفع: مثل بقیه‌ی فراخوانی‌های کلاینت، از مسیر نسبی BFF (/api/proxy/)
    // عبور می‌کند.
    const url = '/api/proxy/core/ntp-time/';
    const response = await fetch(url, {
      headers: { 'Content-Type': 'application/json' },
      cache: 'no-store',
    });
    if (!response.ok) throw new Error('NTP API error');
    const data: NtpResponse = await response.json();
    return new Date(data.datetime);
  } catch (error) {
    console.warn('NTP fallback to system time:', error);
    if (fallbackToSystem) return new Date();
    throw error;
  }
}

export async function getAccurateJalaliToday(): Promise<JalaliDate> {
  const dt = await getAccurateDateTime(true);
  return JalaliDate.fromDate(dt);
}

export async function getAccurateJalaliNow(): Promise<JalaliDateTime> {
  const dt = await getAccurateDateTime(true);
  return JalaliDateTime.fromDate(dt);
}
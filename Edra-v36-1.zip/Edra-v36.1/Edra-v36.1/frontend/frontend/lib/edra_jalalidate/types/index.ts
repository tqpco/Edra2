// lib/edra_jalalidate/types/index.ts
import type { JalaliDate } from '../jalali';

export interface JalaliDateObject {
  year: number;
  month: number;
  day: number;
}

export interface JalaliDateTimeObject extends JalaliDateObject {
  hour: number;
  minute: number;
  second: number;
  microsecond?: number;
}

export interface JalaliDatePickerProps {
  value?: string | Date | JalaliDateObject | JalaliDate | null;
  onChange?: (value: string, jalaliObject: JalaliDateObject | null) => void;
  format?: string;
  usePersianDigits?: boolean;
  placeholder?: string;
  className?: string;
  disabled?: boolean;
  readOnly?: boolean;
  name?: string;
  id?: string;
}

export interface JalaliDateTimePickerProps extends JalaliDatePickerProps {
  format?: string;
}

export interface JalaliDatePickerRef {
  getValue: () => string;
  getJalaliObject: () => JalaliDateObject | null;
  setValue: (value: string | Date | JalaliDateObject) => void;
  openPicker: () => void;
  closePicker: () => void;
}

export type JalaliDatePickerRefType = React.RefObject<JalaliDatePickerRef>;
// lib/edra_jalalidate/utils.ts
import { JalaliDate, JalaliDateTime, toPersianDigits, toEnglishDigits } from './jalali';

export function formatJalaliDate(date: Date | string | null, format: string = 'YYYY/MM/DD'): string {
  if (!date) return '';
  const d = typeof date === 'string' ? new Date(date) : date;
  if (isNaN(d.getTime())) return '';
  const jd = JalaliDate.fromDate(d);
  return jd.format(format);
}

export function formatJalaliDateTime(date: Date | string | null, format: string = 'YYYY/MM/DD HH:mm'): string {
  if (!date) return '';
  const d = typeof date === 'string' ? new Date(date) : date;
  if (isNaN(d.getTime())) return '';
  const jdt = JalaliDateTime.fromDate(d);
  return jdt.format(format);
}

export function isValidJalaliDate(str: string): boolean {
  try {
    JalaliDate.fromString(str);
    return true;
  } catch {
    return false;
  }
}

export function isValidJalaliDateTime(str: string): boolean {
  try {
    JalaliDateTime.fromString(str);
    return true;
  } catch {
    return false;
  }
}

export function toPersianDigitsWrapper(input: string | number): string {
  return toPersianDigits(input);
}

export function toEnglishDigitsWrapper(input: string): string {
  return toEnglishDigits(input);
}
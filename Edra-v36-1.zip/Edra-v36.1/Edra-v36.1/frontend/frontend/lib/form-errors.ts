/**
 * lib/form-errors.ts  (EDRA v32)
 *
 * پارس یکسان خطاهای DRF برای همه‌ی فرم‌های ایجاد/ویرایش.
 *
 * قبلاً صفحات فقط `errData.message` را می‌خواندند؛ ولی DRF خطاها را به
 * شکل‌های دیگری برمی‌گرداند و پیام عمومی «خطا در ذخیره‌سازی» جایگزین
 * علت واقعی می‌شد:
 *   { "phone": ["این شماره قبلاً ثبت شده است."] }      ← خطای فیلد
 *   { "non_field_errors": ["..."] }                      ← خطای کلی
 *   { "detail": "..." } / { "error": "..." } / { "message": "..." }
 */

export interface ParsedApiError {
  /** پیام قابل‌نمایش برای toast/بنر */
  message: string;
  /** خطای هر فیلد (اولین پیام) برای نمایش زیر input */
  fieldErrors: Record<string, string>;
}

function firstString(value: unknown): string | null {
  if (typeof value === "string") return value;
  if (Array.isArray(value)) {
    for (const v of value) {
      const s = firstString(v);
      if (s) return s;
    }
    return null;
  }
  if (value && typeof value === "object") {
    for (const v of Object.values(value as Record<string, unknown>)) {
      const s = firstString(v);
      if (s) return s;
    }
  }
  return null;
}

const GLOBAL_KEYS = ["detail", "error", "message", "non_field_errors"];

export function parseApiError(
  data: unknown,
  fallback = "خطا در ذخیره‌سازی. لطفاً دوباره تلاش کنید."
): ParsedApiError {
  const fieldErrors: Record<string, string> = {};
  let message: string | null = null;

  if (typeof data === "string" && data.trim()) {
    return { message: data.trim(), fieldErrors };
  }

  if (data && typeof data === "object" && !Array.isArray(data)) {
    const obj = data as Record<string, unknown>;

    for (const key of GLOBAL_KEYS) {
      const s = firstString(obj[key]);
      if (s) {
        message = s;
        break;
      }
    }

    for (const [key, value] of Object.entries(obj)) {
      if (GLOBAL_KEYS.includes(key)) continue;
      const s = firstString(value);
      if (s) fieldErrors[key] = s;
    }

    if (!message) {
      const firstField = Object.keys(fieldErrors)[0];
      if (firstField) message = fieldErrors[firstField];
    }
  } else if (Array.isArray(data)) {
    message = firstString(data);
  }

  return { message: message || fallback, fieldErrors };
}

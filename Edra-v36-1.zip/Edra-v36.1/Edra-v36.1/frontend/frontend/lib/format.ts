// lib/format.ts  (EDRA v32)
/**
 * فرمت اعداد و مبالغ با ارقام فارسی و جداکننده‌ی هزارگان «,».
 *
 * چرا بدون toLocaleString('fa-IR')؟ خروجی آن به ICU هر محیط وابسته است و
 * ممکن است بین رندر سرور (Node) و مرورگر فرق کند (Hydration mismatch)، و
 * جداکننده‌ی آن «٬» (U+066C) است که با باقی UI و تست‌ها یکی نیست. این پیاده‌سازی
 * در همه‌ی محیط‌ها خروجی یکسان می‌دهد.
 */

const FA_DIGITS = "۰۱۲۳۴۵۶۷۸۹";

function toFaDigits(value: string): string {
  return value.replace(/\d/g, (d) => FA_DIGITS[Number(d)]);
}

function toFiniteNumber(value: unknown): number | null {
  if (typeof value === "number") return Number.isFinite(value) ? value : null;
  if (typeof value === "string") {
    const cleaned = value.replace(/[,٬\s]/g, "").trim();
    if (cleaned === "") return null;
    const n = Number(cleaned);
    return Number.isFinite(n) ? n : null;
  }
  return null;
}

/** عدد گردشده با ارقام فارسی و جداکننده‌ی هزارگان؛ نامعتبر → "-" */
export function formatNumber(value: number | string | null | undefined): string {
  const n = toFiniteNumber(value);
  if (n === null) return "-";
  const rounded = Math.round(n);
  const grouped = Math.abs(rounded)
    .toString()
    .replace(/\B(?=(\d{3})+(?!\d))/g, ",");
  return (rounded < 0 ? "-" : "") + toFaDigits(grouped);
}

/** مثال: 1250000 -> ۱,۲۵۰,۰۰۰ تومان ؛ نامعتبر → "-" */
export function formatToman(amount: number | string | null | undefined): string {
  const f = formatNumber(amount);
  return f === "-" ? "-" : `${f} تومان`;
}

/** مثال: 250000000 -> ۲۵۰,۰۰۰,۰۰۰ ریال ؛ نامعتبر → "-" */
export function formatRial(amount: number | string | null | undefined): string {
  const f = formatNumber(amount);
  return f === "-" ? "-" : `${f} ریال`;
}

/** مثال: 12.5 -> ۱۲٫۵٪ */
export function formatPercent(value: number | string | null | undefined): string {
  const n = toFiniteNumber(value);
  if (n === null) return "۰٪";
  const text = Number.isInteger(n) ? String(n) : String(Math.round(n * 100) / 100);
  return `${toFaDigits(text.replace(".", "٫"))}٪`;
}

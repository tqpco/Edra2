/**
 * lib/image-compress.ts — EDRA v34
 *
 * عکس‌های دوربین موبایل ۳ تا ۸ مگابایت‌اند و فرم چک‌لیست تا ۱۰۰ عکس می‌فرستد؛
 * بدون فشرده‌سازی، حجم کل درخواست از سقف Nginx (و زمان آپلود در اینترنت ضعیف
 * محل پروژه) فراتر می‌رفت و ثبت گزارش با ۴۱۳ شکست می‌خورد. این تابع عکس را
 * (در مرورگر) به حداکثر `maxSide` پیکسل کوچک و با کیفیت JPEG ذخیره می‌کند.
 * اگر مرورگر پشتیبانی نکند یا خطایی رخ دهد، فایل اصلی برگردانده می‌شود.
 */
export async function compressImage(
  file: File,
  { maxSide = 1600, quality = 0.8 }: { maxSide?: number; quality?: number } = {}
): Promise<File> {
  try {
    if (!file.type.startsWith("image/")) return file;
    // فایل‌های کوچک را دست نزن
    if (file.size <= 500 * 1024) return file;
    if (typeof createImageBitmap !== "function") return file;

    const bitmap = await createImageBitmap(file);
    const scale = Math.min(1, maxSide / Math.max(bitmap.width, bitmap.height));
    const width = Math.max(1, Math.round(bitmap.width * scale));
    const height = Math.max(1, Math.round(bitmap.height * scale));

    const canvas = document.createElement("canvas");
    canvas.width = width;
    canvas.height = height;
    const ctx = canvas.getContext("2d");
    if (!ctx) return file;
    ctx.drawImage(bitmap, 0, 0, width, height);
    bitmap.close?.();

    const blob: Blob | null = await new Promise((resolve) =>
      canvas.toBlob(resolve, "image/jpeg", quality)
    );
    if (!blob || blob.size >= file.size) return file;

    const base = file.name.replace(/\.[^.]+$/, "") || "photo";
    return new File([blob], `${base}.jpg`, {
      type: "image/jpeg",
      lastModified: Date.now(),
    });
  } catch {
    return file;
  }
}

// lib/jalali.test.ts
import { describe, expect, it } from "vitest";
import {
  dateToJalali,
  gregorianToJalali,
  jalaliToGregorian,
  toEnglishDigits,
  toPersianDigits,
} from "@/lib/edra_jalalidate"; // ✅ ایمپورت از مسیر صحیح

describe("toPersianDigits", () => {
  it("ارقام انگلیسی → فارسی", () => {
    expect(toPersianDigits("1234567890")).toBe("۱۲۳۴۵۶۷۸۹۰");
  });

  it("عدد را هم می‌پذیرد", () => {
    expect(toPersianDigits(1403)).toBe("۱۴۰۳");
  });
});

describe("toEnglishDigits", () => {
  it("ارقام فارسی → انگلیسی", () => {
    expect(toEnglishDigits("۱۴۰۳/۰۵/۱۲")).toBe("1403/05/12");
  });
});

describe("gregorianToJalali", () => {
  it("۲۲ بهمن ۱۳۵۷ (تاریخ مرجع انقلاب)", () => {
    const j = gregorianToJalali(1979, 2, 11);
    expect(j).toEqual({ year: 1357, month: 11, day: 22 });
  });

  it("تاریخ شناخته‌شده مدرن", () => {
    const j = gregorianToJalali(2025, 3, 21);
    expect(j).toEqual({ year: 1404, month: 1, day: 1 });
  });
});

describe("jalaliToGregorian (معکوس)", () => {
  it("۲۲ بهمن ۱۳۵۷ → ۱۱ فوریه ۱۹۷۹", () => {
    const g = jalaliToGregorian(1357, 11, 22);
    expect(g).toEqual({ year: 1979, month: 2, day: 11 });
  });
});

describe("dateToJalali", () => {
  it("تبدیل از Date", () => {
    const j = dateToJalali(new Date(1979, 1, 11));
    expect(j).toEqual({ year: 1357, month: 11, day: 22 });
  });
});
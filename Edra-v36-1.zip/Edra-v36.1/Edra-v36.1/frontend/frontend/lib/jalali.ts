// lib/jalali.ts
// این فایل به عنوان پل (bridge) برای سازگاری با کدهای موجود عمل می‌کند.
// تمام توابع مربوط به تاریخ جلالی از edra_jalalidate مجدداً صادر می‌شوند.

// ============================================================
// ایمپورت صریح از edra_jalalidate
// ============================================================
import {
  // توابع اصلی تبدیل
  toPersianDigits as _toPersianDigits,
  toEnglishDigits as _toEnglishDigits,
  JalaliDate as _JalaliDate,
  JalaliDateTime as _JalaliDateTime,
  gregorianToJalali as _gregorianToJalali,
  jalaliToGregorian as _jalaliToGregorian,
  isJalaliLeapYear as _isJalaliLeapYear,
  jalaliMonthDays as _jalaliMonthDays,
  dateToJalali as _dateToJalali,
  jalaliToDate as _jalaliToDate,
  formatJalali as _formatJalali,
  formatJalaliNumeric as _formatJalaliNumeric,
  formatJalaliWithWeekday as _formatJalaliWithWeekday,
  formatPersianTime as _formatPersianTime,
  toJalaliString as _toJalaliString,
  toJalaliDateTimeString as _toJalaliDateTimeString,
  parseJalali as _parseJalali,
  parseJalaliDateTime as _parseJalaliDateTime,
  // نام‌ها
  MONTH_NAMES_FA as _MONTH_NAMES_FA,
  MONTH_NAMES_EN as _MONTH_NAMES_EN,
  DAY_NAMES_FA as _DAY_NAMES_FA,
  DAY_NAMES_EN as _DAY_NAMES_EN,
  // توابع برنامه‌ریزی
  earliestBookableDate as _earliestBookableDate,
  isWorkingDay as _isWorkingDay,
  availableTimeSlots as _availableTimeSlots,
  jalaliMonthLength as _jalaliMonthLength,
  JALALI_MONTH_NAMES as _JALALI_MONTH_NAMES,
  // types
  JalaliDateObject as _JalaliDateObject,
  JalaliDateTimeObject as _JalaliDateTimeObject,
  // hooks
  useJalaliToday as _useJalaliToday,
  useJalaliNow as _useJalaliNow,
  useJalaliDate as _useJalaliDate,
  useJalaliDateTime as _useJalaliDateTime,
  useJalaliField as _useJalaliField,
  // components
  JalaliDatePicker as _JalaliDatePicker,
  JalaliDateTimePicker as _JalaliDateTimePicker,
} from './edra_jalalidate';

// ============================================================
// صادرات مجدد با نام‌های اصلی
// ============================================================

// توابع اصلی تبدیل
export const toPersianDigits = _toPersianDigits;
export const toEnglishDigits = _toEnglishDigits;
export const JalaliDate = _JalaliDate;
export const JalaliDateTime = _JalaliDateTime;
export const gregorianToJalali = _gregorianToJalali;
export const jalaliToGregorian = _jalaliToGregorian;
export const isJalaliLeapYear = _isJalaliLeapYear;
export const jalaliMonthDays = _jalaliMonthDays;
export const dateToJalali = _dateToJalali;
export const jalaliToDate = _jalaliToDate;
export const formatJalali = _formatJalali;
export const formatJalaliNumeric = _formatJalaliNumeric;
export const formatJalaliWithWeekday = _formatJalaliWithWeekday;
export const formatPersianTime = _formatPersianTime;
export const toJalaliString = _toJalaliString;
export const toJalaliDateTimeString = _toJalaliDateTimeString;
export const parseJalali = _parseJalali;
export const parseJalaliDateTime = _parseJalaliDateTime;

// نام‌ها
export const MONTH_NAMES_FA = _MONTH_NAMES_FA;
export const MONTH_NAMES_EN = _MONTH_NAMES_EN;
export const DAY_NAMES_FA = _DAY_NAMES_FA;
export const DAY_NAMES_EN = _DAY_NAMES_EN;

// توابع برنامه‌ریزی (scheduling)
export const earliestBookableDate = _earliestBookableDate;
export const isWorkingDay = _isWorkingDay;
export const availableTimeSlots = _availableTimeSlots;
export const jalaliMonthLength = _jalaliMonthLength;
export const JALALI_MONTH_NAMES = _JALALI_MONTH_NAMES;

// هوک‌ها
export const useJalaliToday = _useJalaliToday;
export const useJalaliNow = _useJalaliNow;
export const useJalaliDate = _useJalaliDate;
export const useJalaliDateTime = _useJalaliDateTime;
export const useJalaliField = _useJalaliField;

// کامپوننت‌ها
export const JalaliDatePicker = _JalaliDatePicker;
export const JalaliDateTimePicker = _JalaliDateTimePicker;

// صادرات typeها
export type JalaliDateObject = _JalaliDateObject;
export type JalaliDateTimeObject = _JalaliDateTimeObject;

// صادرات همه موارد به صورت * برای پشتیبانی از import * as jalali
export * from './edra_jalalidate';
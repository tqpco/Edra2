// lib/nav-config.ts
/**
 * lib/nav-config.ts
 * آیتم‌های سایدبار به تفکیک نقش. یک منبع واحد تا اضافه‌کردن مسیر جدید
 * فقط در یک‌جا لازم باشد.
 */
import type { ReactNode } from "react";
import React from "react";
import {
  LayoutDashboard,
  ClipboardList,
  Users,
  UserCog,
  Wrench,
  Calculator,
  TicketPercent,
  MessagesSquare,
  FileBarChart,
  Bell,
  BellRing,
  Mail,
  Megaphone,
  HelpCircle,
  BookOpen,
  Settings,
  ListChecks,
  History,
  UserCircle,
  PlusCircle,
  FileText,
  Wallet,
  Receipt,
  CreditCard,
  ScrollText,
  CalendarDays,
  Building2,
  FolderKanban,
  MapPin,
  AlertTriangle,
  Ticket,
  Plus,
  type LucideIcon,
} from "lucide-react";

export interface NavItem {
  title: string;
  href: string;
  icon: ReactNode;
  badgeKey?: "openTickets" | "unassignedRequests" | "pendingReceipts";
}

export interface NavSection {
  label?: string;
  items: NavItem[];
}

// ✅ استفاده از React.createElement به‌جای JSX (چون فایل .ts است)
const icon = (Component: LucideIcon) =>
  React.createElement(Component, {
    className: "h-4 w-4 shrink-0",
  });

export const ADMIN_NAV: NavSection[] = [
  {
    items: [{ title: "داشبورد", href: "/dashboard/admin", icon: icon(LayoutDashboard) }],
  },
  {
    label: "عملیات",
    items: [
      { title: "درخواست‌ها", href: "/dashboard/admin/requests", icon: icon(ClipboardList) },
      { title: "مشتریان", href: "/dashboard/admin/customers", icon: icon(Users) },
      { title: "کارشناسان", href: "/dashboard/admin/experts", icon: icon(UserCog) },
      {
        title: "پرداخت‌ها",
        href: "/dashboard/admin/payments",
        icon: icon(CreditCard),
        badgeKey: "pendingReceipts",
      },
      { title: "فاکتورها", href: "/dashboard/admin/invoices", icon: icon(Receipt) },
    ],
  },
  {
    label: "پیکربندی",
    items: [
      { title: "تجهیزات", href: "/dashboard/admin/equipment", icon: icon(Wrench) },
      { title: "قیمت‌گذاری", href: "/dashboard/admin/pricing", icon: icon(Calculator) },
      { title: "ضرایب شهر", href: "/dashboard/admin/city-multipliers", icon: icon(MapPin) },
      { title: "روش‌های پرداخت", href: "/dashboard/admin/payment-methods", icon: icon(CreditCard) },
      { title: "کدهای تخفیف", href: "/dashboard/admin/discounts", icon: icon(TicketPercent) },
      { title: "قالب‌های چک‌لیست", href: "/dashboard/admin/checklist-templates", icon: icon(ListChecks) },
      { title: "صندوق اعلان‌های من", href: "/dashboard/admin/inbox", icon: icon(Bell) },
      { title: "قالب‌های اعلان", href: "/dashboard/admin/notifications", icon: icon(Bell) },
      { title: "لاگ اعلان‌ها", href: "/dashboard/admin/notification-logs", icon: icon(BellRing) },
      { title: "پیام‌های تماس", href: "/dashboard/admin/contact-messages", icon: icon(Mail) },
      { title: "اعلانیه‌ها", href: "/dashboard/admin/announcements", icon: icon(Megaphone) },
      { title: "سوالات متداول", href: "/dashboard/admin/faq", icon: icon(HelpCircle) },
      { title: "پایگاه دانش", href: "/dashboard/admin/knowledge-base", icon: icon(BookOpen) },
      { title: "سازمان‌ها", href: "/dashboard/admin/organizations", icon: icon(Building2) },
      { title: "پروژه‌ها", href: "/dashboard/admin/projects", icon: icon(FolderKanban) },
    ],
  },
  // ✅ بخش جدید: پشتیبانی و تیکت‌ها
  {
    label: "پشتیبانی",
    items: [
      { title: "همه تیکت‌ها", href: "/dashboard/admin/tickets", icon: icon(Ticket) },
      { title: "تیکت جدید", href: "/dashboard/admin/tickets/new", icon: icon(Plus) },
      { title: "تنظیمات تیکت", href: "/dashboard/admin/tickets/settings", icon: icon(Settings) },
      { title: "پاسخ‌های آماده", href: "/dashboard/admin/saved-replies", icon: icon(MessagesSquare) },
    ],
  },
  {
    label: "گزارش‌گیری و نظارت",
    items: [
      { title: "گزارش‌های مدیریتی", href: "/dashboard/admin/reports", icon: icon(FileBarChart) },
      { title: "لاگ ممیزی", href: "/dashboard/admin/audit-logs", icon: icon(ScrollText) },
      { title: "لاگ خطاها", href: "/dashboard/admin/error-logs", icon: icon(AlertTriangle) },
    ],
  },
  {
    items: [{ title: "تنظیمات", href: "/dashboard/admin/settings", icon: icon(Settings) }],
  },
];

export const EXPERT_NAV: NavSection[] = [
  {
    items: [
      { title: "داشبورد", href: "/dashboard/expert", icon: icon(LayoutDashboard) },
      { title: "وظایف من", href: "/dashboard/expert/tasks", icon: icon(ListChecks) },
      { title: "تقویم برنامه", href: "/dashboard/expert/calendar", icon: icon(CalendarDays) },
      { title: "تاریخچه گزارش‌ها", href: "/dashboard/expert/history", icon: icon(History) },
      { title: "تیکت‌ها", href: "/dashboard/expert/tickets", icon: icon(MessagesSquare) },
      { title: "اعلان‌ها", href: "/dashboard/expert/notifications", icon: icon(Bell) },
      { title: "پروفایل", href: "/dashboard/expert/profile", icon: icon(UserCircle) },
    ],
  },
];

export const CUSTOMER_NAV: NavSection[] = [
  {
    items: [
      { title: "داشبورد", href: "/dashboard/customer", icon: icon(LayoutDashboard) },
      { title: "رزرو جدید", href: "/booking", icon: icon(PlusCircle) },
    ],
  },
  {
    label: "درخواست‌های من",
    items: [
      { title: "درخواست‌ها", href: "/dashboard/customer/requests", icon: icon(ClipboardList) },
      { title: "گزارش‌های بازرسی", href: "/dashboard/customer/reports", icon: icon(FileText) },
    ],
  },
  {
    label: "مالی",
    items: [
      { title: "اعتبار من", href: "/dashboard/customer/credit", icon: icon(Wallet) },
      { title: "فاکتورها", href: "/dashboard/customer/invoices", icon: icon(Receipt) },
      { title: "پرداخت‌ها", href: "/dashboard/customer/payments", icon: icon(CreditCard) },
    ],
  },
  {
    items: [
      { title: "اعلان‌ها", href: "/dashboard/customer/notifications", icon: icon(Bell) },
      { title: "تیکت‌های پشتیبانی", href: "/dashboard/customer/tickets", icon: icon(MessagesSquare) },
      { title: "پروفایل", href: "/dashboard/customer/profile", icon: icon(UserCircle) },
    ],
  },
];
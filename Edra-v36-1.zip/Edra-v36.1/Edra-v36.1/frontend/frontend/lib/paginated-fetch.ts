import { apiServerFetch } from "@/lib/api-server";

/**
 * EDRA v21 — تنها منبع حقیقت برای fetch لیست‌های صفحه‌بندی‌شده.
 *
 * چرا: در سه دور متوالی (v17/v19/v20) «صفحه‌بندی» ۲۵ بار به‌صورت دستی و
 * کپی‌شده در هر صفحه پیاده شد و هر بار ۱-۲۱ نسخه از قلم افتاد (باگ
 * backtick، totalItems غلط، Pagination بدون رندر). این تابع قرارداد
 * pagination را در یک نقطه نگه می‌دارد: اگر فردا شکل پاسخ API تغییر
 * کند، فقط همین یک فایل به‌روزرسانی می‌شود.
 *
 * خروجی همیشه `{ items, count }` است:
 *   - پاسخ envelope {count, results} → items=results، count=count واقعی
 *   - پاسخ آرایه‌ی خام (endpoint های بدون pagination) → items=آرایه،
 *     count=آرایه.length (سازگار با عقب)
 */
export async function fetchPaginated<T>(
  path: string,
  page: number
): Promise<{ items: T[]; count: number }> {
  const sep = path.includes("?") ? "&" : "?";
  const data = await apiServerFetch<{ count: number; results: T[] } | T[]>(
    `${path}${sep}page=${page}`
  );
  if (Array.isArray(data)) {
    return { items: data, count: data.length };
  }
  return { items: data.results ?? [], count: data.count ?? 0 };
}

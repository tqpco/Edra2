/**
 * lib/session.ts
 *
 * مدیریت توکن‌های JWT از طریق کوکی httpOnly (نه localStorage) - چون
 * localStorage در معرض دسترسی هر اسکریپتی (از جمله حملات XSS) است، ولی
 * کوکی httpOnly اصلاً از جاوااسکریپت سمت مرورگر قابل خواندن نیست.
 *
 * توکن دسترسی (access) عمر کوتاهی دارد (۳۰ دقیقه، هماهنگ با بک‌اند) و
 * توکن تازه‌سازی (refresh) عمر ۷ روزه دارد.
 */
import "server-only";
import { cookies } from "next/headers";
import { getClientIpHeaders } from "./client-ip";

const ACCESS_COOKIE = "edra_access";
const REFRESH_COOKIE = "edra_refresh";

const isProd = process.env.NODE_ENV === "production";

const baseCookieOptions = {
  httpOnly: true,
  secure: isProd,
  sameSite: "lax" as const,
  path: "/",
};

export async function setSessionTokens(access: string, refresh: string | null) {
  const store = await cookies();
  store.set(ACCESS_COOKIE, access, {
    ...baseCookieOptions,
    maxAge: 30 * 60, // ۳۰ دقیقه - هماهنگ با ACCESS_TOKEN_LIFETIME بک‌اند
  });
  if (refresh) {
    store.set(REFRESH_COOKIE, refresh, {
      ...baseCookieOptions,
      maxAge: 7 * 24 * 60 * 60, // ۷ روز - هماهنگ با REFRESH_TOKEN_LIFETIME بک‌اند
    });
  }
}

export async function setAccessToken(access: string) {
  const store = await cookies();
  store.set(ACCESS_COOKIE, access, {
    ...baseCookieOptions,
    maxAge: 30 * 60,
  });
}

export async function getAccessToken(): Promise<string | undefined> {
  const store = await cookies();
  return store.get(ACCESS_COOKIE)?.value;
}

export async function getRefreshToken(): Promise<string | undefined> {
  const store = await cookies();
  return store.get(REFRESH_COOKIE)?.value;
}

export async function clearSessionTokens() {
  const store = await cookies();
  store.delete(ACCESS_COOKIE);
  store.delete(REFRESH_COOKIE);
}

// ============================================================
// P1 (EDRA v9): refresh single-flight — چند درخواست هم‌زمانِ «همان
// کاربر» نباید چند refresh موازی با هم اجرا کنند (rotation → logout).
//
// EDRA v17 — CRITICAL-1 (ممیزی v16): نسخه‌ی قبلی از یک متغیر سطح
// ماژول (refreshInFlight) استفاده می‌کرد که بین همه‌ی کاربرانِ یک
// پروسه‌ی Node مشترک است → درخواست کاربر B می‌توانست توکن تازه‌ی
// کاربر A را بگیرد (نشت داده بین کاربران هم‌زمان).
// حالا single-flight با Map کلیدخورده بر اساس «مقدار خود refresh
// token» انجام می‌شود: درخواست‌های هم‌زمانِ همان کاربر dedup می‌شوند
// و کاربران مختلف هرگز روی هم اثر نمی‌گذارند.
// ============================================================
const refreshInFlightMap = new Map<string, Promise<string | null>>();

export async function refreshAccessToken(): Promise<string | null> {
  const refresh = await getRefreshToken();
  if (!refresh) return null;

  const existing = refreshInFlightMap.get(refresh);
  if (existing) return existing;

  const clientIpHeaders = await getClientIpHeaders();
  const promise = (async () => {
    const API_BASE_URL = process.env.NEXT_PUBLIC_API_URL || "http://localhost:8000";
    try {
      const res = await fetch(`${API_BASE_URL}/api/token/refresh/`, {
        method: "POST",
        headers: { "Content-Type": "application/json", ...clientIpHeaders },
        body: JSON.stringify({ refresh }),
        // EDRA v18 (Info از ممیزی v17): اگر بک‌اند هنگ کند، ورودی Map
        // نباید تا ابد بماند — بعد از ۱۵ ثانیه ابطال و خالی می‌شود.
        signal: AbortSignal.timeout(15000),
      });
      if (!res.ok) {
        await clearSessionTokens();
        return null;
      }
      const data = await res.json();
      await setSessionTokens(data.access, data.refresh ?? refresh);
      return data.access as string;
    } catch {
      return null;
    } finally {
      refreshInFlightMap.delete(refresh);
    }
  })();

  refreshInFlightMap.set(refresh, promise);
  return promise;
}

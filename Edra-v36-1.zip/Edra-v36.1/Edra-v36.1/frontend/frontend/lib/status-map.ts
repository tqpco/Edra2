/**
 * lib/status-map.ts
 * نگاشت مقادیر status بک‌اند (core/models/request.py، Payment، Ticket و ...)
 * به رنگ Badge و برچسب فارسی مناسب - یک منبع واحد برای همه داشبوردها.
 */
import type { VariantProps } from "class-variance-authority";
import type { badgeVariants } from "@/components/ui/badge";

type BadgeVariant = NonNullable<VariantProps<typeof badgeVariants>["variant"]>;

export const REQUEST_STATUS_MAP: Record<string, { label: string; variant: BadgeVariant }> = {
  draft: { label: "پیش‌نویس", variant: "muted" },
  pending_payment: { label: "در انتظار پرداخت آنلاین", variant: "warning" },
  waiting_manual_payment: { label: "در انتظار تایید فیش", variant: "warning" },
  paid: { label: "پرداخت‌شده", variant: "info" },
  assigned: { label: "ارجاع‌شده به کارشناس", variant: "info" },
  scheduled: { label: "زمان‌بندی‌شده", variant: "info" },
  rescheduled: { label: "زمان‌بندی مجدد شده", variant: "warning" },
  in_progress: { label: "در حال بازرسی", variant: "default" },
  completed: { label: "تکمیل‌شده", variant: "success" },
  cancelled: { label: "لغو‌شده", variant: "destructive" },
  expired: { label: "منقضی‌شده", variant: "destructive" },
};

export const PAYMENT_STATUS_MAP: Record<string, { label: string; variant: BadgeVariant }> = {
  pending: { label: "در انتظار", variant: "warning" },
  pending_verification: { label: "در انتظار تایید", variant: "warning" },
  paid: { label: "پرداخت‌شده", variant: "success" },
  rejected: { label: "رد شده", variant: "destructive" },
  failed: { label: "ناموفق", variant: "destructive" },
  // EDRA v32: دو مقدار واقعی Payment.STATUS_CHOICES (از جمله عودت، که
  // یک قابلیت واقعی با refund_payment است) اینجا نبودند؛ getStatusInfo
  // بدون این دو، متن انگلیسیِ خام "cancelled"/"refunded" را به ادمین
  // نشان می‌داد.
  cancelled: { label: "لغو شده", variant: "outline" },
  refunded: { label: "عودت داده‌شده", variant: "outline" },
};

export const NOTIFICATION_STATUS_MAP: Record<string, { label: string; variant: BadgeVariant }> = {
  pending: { label: "در انتظار ارسال", variant: "warning" },
  sent: { label: "ارسال‌شده", variant: "success" },
  failed: { label: "ناموفق", variant: "destructive" },
};

// EDRA v27 — رفع باگ واقعی (گزارش کاربر، سپتامبر ۲۰۲۶): overall_result
// گزارش بازرسی سه مقدار دارد (pass/conditional/fail)، ولی چند صفحه فقط
// دو حالت را می‌شناختند و نتیجه‌ی «مشروط» را به‌اشتباه «مردود» (قرمز)
// نشان می‌دادند — برای مشتری گمراه‌کننده/ناراحت‌کننده بود. اینجا
// متمرکز شد تا دیگر در چند فایل جداگانه تکرار نشود.
export const REPORT_RESULT_MAP: Record<string, { label: string; variant: BadgeVariant }> = {
  pass: { label: "قبول", variant: "success" },
  conditional: { label: "مشروط", variant: "warning" },
  fail: { label: "مردود", variant: "destructive" },
};

export function getStatusInfo(
  map: Record<string, { label: string; variant: BadgeVariant }>,
  status: string
): { label: string; variant: BadgeVariant } {
  return map[status] || { label: status, variant: "outline" };
}

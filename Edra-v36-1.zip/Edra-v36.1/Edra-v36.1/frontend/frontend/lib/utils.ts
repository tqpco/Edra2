// lib/utils.ts
import { clsx, type ClassValue } from "clsx";
import { twMerge } from "tailwind-merge";
// تمام توابع تبدیل اعداد را از jalali (که خود از edra_jalalidate صادر میکند) میگیریم
import { toPersianDigits, toEnglishDigits } from "./jalali";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export function formatPrice(price: number): string {
  return new Intl.NumberFormat('fa-IR').format(price) + ' تومان';
}

// صادرات مجدد برای راحتی و سازگاری با کدهای موجود
export { toPersianDigits, toEnglishDigits };
"use client";

import { create } from "zustand";
import { persist } from "zustand/middleware";

export interface WizardState {
  step: number;
  equipmentTypeId: number | null;
  equipmentName: string | null;
  city: string | null;
  params: Record<string, string | number | boolean>;
  installState: string | null;
  serviceType: "standard" | "pro";
  calculatedPrice: number | null;
  cityCost: number | null;
  finalWithTax: number | null; // ✅ مبلغ نهایی با مالیات (از استپ ۷)

  scheduledAt: string | null; // ISO string

  applicantName: string;
  companyName: string;
  projectName: string;
  address: string;
  addressLat: number | null;
  addressLng: number | null;

  discountCode: string;
  useCreditAmount: number;

  requestId: number | null;
  requestNumber: string | null;

  setStep: (step: number) => void;
  setEquipment: (id: number, name: string) => void;
  setCity: (city: string) => void;
  setParams: (params: Record<string, string | number | boolean>) => void;
  setInstallState: (state: string | null) => void;
  setServiceType: (type: "standard" | "pro") => void;
  setPrice: (calculatedPrice: number, cityCost: number) => void;
  setFinalWithTax: (amount: number) => void; // ✅ تابع جدید برای تنظیم مبلغ نهایی با مالیات
  setScheduledAt: (iso: string) => void;
  setApplicantInfo: (info: Partial<Pick<WizardState,
    "applicantName" | "companyName" | "projectName" | "address" | "addressLat" | "addressLng">>) => void;
  setDiscountCode: (code: string) => void;
  setUseCreditAmount: (amount: number) => void;
  setCreatedRequest: (id: number, requestNumber: string) => void;
  reset: () => void;
}

const initialState = {
  step: 1,
  equipmentTypeId: null,
  equipmentName: null,
  city: null,
  params: {},
  installState: null,
  serviceType: "standard" as const,
  calculatedPrice: null,
  cityCost: null,
  finalWithTax: null, // ✅ مقدار اولیه null
  scheduledAt: null,
  applicantName: "",
  companyName: "",
  projectName: "",
  address: "",
  addressLat: null,
  addressLng: null,
  discountCode: "",
  useCreditAmount: 0,
  requestId: null,
  requestNumber: null,
};

export const useWizardStore = create<WizardState>()(
  persist(
    (set) => ({
      ...initialState,
      setStep: (step) => set({ step }),
      setEquipment: (id, name) =>
        set({
          equipmentTypeId: id,
          equipmentName: name,
          params: {},
          // EDRA v34: وضعیت استقرار مخصوص هر نوع تجهیز است؛ با عوض‌شدن
          // تجهیز باید پاک شود (قبلاً مقدار تجهیز قبلی به قیمت‌گذاری/ثبت
          // تجهیزِ جدید نشت می‌کرد).
          installState: null,
          calculatedPrice: null,
          cityCost: null,
          finalWithTax: null, // ✅ بازنشانی مبلغ نهایی
        }),
      setCity: (city) => set({ city }),
      setParams: (params) => set({ params }),
      setInstallState: (installState) => set({ installState }),
      setServiceType: (serviceType) => set({ serviceType }),
      setPrice: (calculatedPrice, cityCost) => set({ calculatedPrice, cityCost }),
      setFinalWithTax: (amount) => set({ finalWithTax: amount }), // ✅ تابع جدید
      setScheduledAt: (scheduledAt) => set({ scheduledAt }),
      setApplicantInfo: (info) => set((s) => ({ ...s, ...info })),
      setDiscountCode: (discountCode) => set({ discountCode }),
      setUseCreditAmount: (useCreditAmount) => set({ useCreditAmount }),
      setCreatedRequest: (requestId, requestNumber) =>
        set({ requestId, requestNumber }),
      reset: () => set(initialState),
    }),
    { name: "edra-booking-wizard" }
  )
);
import { NextRequest, NextResponse } from "next/server";

/**
 * middleware.ts
 * یک بررسی سریع و سبک (بدون تماس شبکه‌ای) که آیا اصلاً کوکی نشستی وجود
 * دارد یا نه؛ اگر نه، مستقیم به صفحه‌ی ورود مناسب هدایت می‌کند. اعتبار
 * دقیق توکن (و تازه‌سازی خودکار در صورت انقضا) در لایه‌ی API انجام
 * می‌شود - این middleware فقط از رندر بی‌فایده‌ی صفحات محافظت‌شده برای
 * کاربر کاملاً مهمان جلوگیری می‌کند.
 *
 * EDRA v27 — قابلیت تازه (گزارش کاربر، سپتامبر ۲۰۲۶): «سیستم تفکیک
 * اتوماتیک مدیر/کارشناس/مشتری». قبلاً این فایل فقط وجود کوکی را چک
 * می‌کرد؛ یعنی یک مشتریِ واردشده می‌توانست مستقیماً آدرس
 * /dashboard/admin را در مرورگر تایپ کند و پوسته‌ی صفحه (طرح‌بندی،
 * برچسب‌ها، ساختار کامپوننت) برایش رندر شود — حتی اگر API واقعی در
 * نهایت ۴۰۱/۴۰۳ برمی‌گرداند. حالا نقش از claim توکن (که در بک‌اند در
 * همین نشست اضافه شد) خوانده و مسیر بر همان اساس enforce می‌شود.
 * توجه مهم: این هنوز فقط لایه‌ی UX/دفاع در عمق است — مرجع واقعی امنیت
 * همچنان permission_class های DRF روی خودِ بک‌اند است (چون این توکن
 * اینجا امضایش verify نمی‌شود، فقط decode می‌شود).
 */

function decodeJwtRole(token: string): string | null {
  try {
    const payloadB64 = token.split(".")[1];
    if (!payloadB64) return null;
    const normalized = payloadB64.replace(/-/g, "+").replace(/_/g, "/");
    const padded = normalized.padEnd(
      normalized.length + ((4 - (normalized.length % 4)) % 4),
      "="
    );
    const payload = JSON.parse(atob(padded));
    return typeof payload.role === "string" ? payload.role : null;
  } catch {
    return null;
  }
}

const ROLE_HOME: Record<string, string> = {
  admin: "/dashboard/admin",
  expert: "/dashboard/expert",
  customer: "/dashboard/customer",
};

export function middleware(request: NextRequest) {
  const { pathname } = request.nextUrl;
  const accessToken = request.cookies.get("edra_access")?.value;
  const hasSession = Boolean(accessToken) || request.cookies.has("edra_refresh");

  if (pathname.startsWith("/dashboard") && !hasSession) {
    const loginPath = pathname.startsWith("/dashboard/customer")
      ? "/customer-login"
      : "/login";
    const url = new URL(loginPath, request.url);
    url.searchParams.set("next", pathname);
    return NextResponse.redirect(url);
  }

  // بررسی نقش فقط وقتی access token در دسترس است (اگر فقط refresh
  // مانده، لایه‌ی API خودش access جدید می‌سازد و صفحه بارگذاری می‌شود؛
  // جلوگیری از رندر اینجا برای آن حالت گذرا لازم نیست).
  if (accessToken) {
    const role = decodeJwtRole(accessToken);
    const section = ["admin", "expert", "customer"].find((s) =>
      pathname.startsWith(`/dashboard/${s}`)
    );
    if (role && section && role !== section) {
      const home = ROLE_HOME[role] ?? "/dashboard/customer";
      return NextResponse.redirect(new URL(home, request.url));
    }
  }

  return NextResponse.next();
}

export const config = {
  matcher: ["/dashboard/:path*"],
};

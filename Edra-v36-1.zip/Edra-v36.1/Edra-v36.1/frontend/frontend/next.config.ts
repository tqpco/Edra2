import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  reactStrictMode: true,
  // EDRA v26 — Next.js 16 پیش‌فرض trailing slash را حذف می‌کند (308).
  // این با APPEND_SLASH جنگو برای POST درخواست‌ها تداخل دارد.
  trailingSlash: true,
  // EDRA v7 — SEC-04/P2: خروجی standalone → image نهایی فقط runtime
  // لازم را دارد (بدون node_modules کامل)؛ کوچک‌تر و حمله‌پذیری کمتر.
  output: "standalone",
  images: {
    remotePatterns: [
      {
        protocol: "http",
        hostname: "localhost",
      },
      {
        protocol: "http",
        hostname: "backend",  // ✅ اضافه شد تا تصاویر از بک‌اند قابل دریافت باشند
      },
      {
        protocol: "https",
        hostname: process.env.NEXT_PUBLIC_API_HOSTNAME || "api.edra-inspect.ir",
      },
    ],
  },
  async rewrites() {
    // در توسعه، درخواست‌های /api/* را به بک‌اند جنگو پراکسی می‌کنیم تا
    // نیازی به تنظیم دستی CORS برای هر درخواست نباشد.
    return [
      {
        source: "/backend/:path*",
        // ✅ تغییر: استفاده از متغیر محیطی با fallback به http://backend:8000
        destination: `${process.env.NEXT_PUBLIC_API_URL || "http://backend:8000"}/:path*`,
      },
    ];
  },
};

export default nextConfig;
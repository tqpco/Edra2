export interface ChecklistItemData {
  id: number;
  category: string;
  title: string;
  description: string;
  requires_photo: boolean;
  requires_note: boolean;
  /** EDRA v5 — HIGH-46: از backend مدل/API آمده؛ در صورت نبود، undefined. */
  is_critical?: boolean;
}

export interface ChecklistTemplateData {
  id: number;
  name: string;
  version: number;
  items: ChecklistItemData[];
}

export interface TaskDetail {
  id: number;
  request_number: string;
  customer_name: string;
  customer_phone: string;
  equipment_name: string;
  brand_model: string;
  manufacture_year: number | null;
  params: Record<string, unknown>;
  install_state: string | null;
  service_type: string;
  city: string;
  address: string;
  address_lat: number | null;
  address_lng: number | null;
  scheduled_at_jalali: string | null;
  status: string;
  final_price: number;
  created_at: string;
  has_report: boolean;
  report_id: number | null;
  /** EDRA v34: آیا کارشناس هم‌اکنون می‌تواند گزارش ثبت کند؟ (از سرور) */
  can_submit?: boolean;
}

export interface TaskDetailResponse {
  task: TaskDetail;
  checklist_template: ChecklistTemplateData | null;
  /** ضدتقلب GPS روشن است؟ (تنظیم سیستم؛ پیش‌فرض خاموش) */
  gps_enabled?: boolean;
  existing_report: {
    id: number;
    report_number: string;
    overall_result?: string;
    pdf_ready?: boolean;
    signed?: boolean;
  } | null;
}

export type ItemResult = "pass" | "fail" | "na";

export interface ChecklistAnswer {
  /**
   * EDRA v5 — CRITICAL-07/HIGH-44: null = «بدون پاسخ». هیچ آیتمی
   * پیش‌فرض PASS ندارد؛ ثبت نهایی فقط با پاسخ صریح همه آیتم‌ها مجاز است
   * (backend نیز این قانون را enforce می‌کند).
   */
  result: ItemResult | null;
  note: string;
  photos: File[];
}

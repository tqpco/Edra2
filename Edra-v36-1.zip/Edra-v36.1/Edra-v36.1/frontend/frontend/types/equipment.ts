export interface EquipmentParamSchema {
  name: string;
  label: string;
  // EDRA v32: date/time کم بود — مدل EquipmentParameter.FIELD_TYPE_CHOICES
  // شش مقدار دارد (string/number/select/boolean/date/time)، نه چهار.
  type: "string" | "number" | "select" | "boolean" | "date" | "time";
  required: boolean;
  options?: string[];
}

export interface EquipmentType {
  id: number;
  code: string;
  name_fa: string;
  supports_install_state: boolean;
  install_state_required: boolean;
  param_schema: EquipmentParamSchema[] | null;
}

export interface CityMultiplier {
  id: number;
  city: string;
  multiplier: string;
  base_cost: string;
}

// EDRA v32 — این تایپ با پاسخ واقعی POST /api/pricing/calculate/
// (pricing/views.py: PriceCalculateView._handle_post) هم‌خوان نبود — فیلدهایی
// مثل success/equipment/city که اصلاً در پاسخ نیستند را وعده می‌داد، و
// city_cost را (نام واقعی: city_base_cost) اشتباه می‌نوشت، و فیلدهای واقعی
// تخفیف/مالیات/اعتبار را اصلاً نداشت.
export interface PriceCalculateResponse {
  total_price: number;
  city_multiplier: number;
  city_base_cost: number;
  discount_amount: number;
  discount_error: string | null;
  tax_rate_percent: number;
  tax_amount: number;
  final_amount: number;
  credit_balance: number;
  max_usable_credit: number;
  credit_used: number;
  final_payable: number;
  has_discount: boolean;
}

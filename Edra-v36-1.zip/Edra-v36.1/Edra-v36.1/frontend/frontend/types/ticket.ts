export interface TicketListItem {
  id: number;
  title: string;
  customer_name: string;
  assigned_to_name: string | null;
  status_name: string;
  priority_name: string;
  comments_count: number;
  created_at_jalali: string;
  updated_at_jalali: string;
}

export interface TicketComment {
  id: number;
  user: number;
  user_name: string;
  content: string;
  is_internal: boolean;
  created_at_jalali: string;
}

export interface TicketAttachment {
  id: number;
  file: string;
  filename: string;
}

export interface TicketDetail {
  id: number;
  title: string;
  description: string;
  customer_name: string;
  assigned_to_name: string | null;
  status_name: string;
  priority_name: string;
  category_name: string | null;
  department_name: string | null;
  comments: TicketComment[];
  attachments: TicketAttachment[];
  created_at_jalali: string;
}

export interface TicketCategory {
  id: number;
  name: string;
}
export interface TicketDepartment {
  id: number;
  name: string;
}

export interface TicketPriority {
  id: number;
  name: string;
}

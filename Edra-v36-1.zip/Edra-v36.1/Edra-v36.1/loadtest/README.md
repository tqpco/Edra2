# تست بار EDRA — ۲۰۰ کاربر همزمان

> ⚠️ این تست در محیط ساخت v32 اجرا **نشده**. تا اجرا و بررسی نتیجه، «۲۰۰ کاربر مشکلی ندارد» ثابت‌شده نیست.

## ۱) آماده‌سازی استیجینگ (نه production!)
در `.env.staging`:
```
DJANGO_ENV=staging
DEV_OTP_ENABLED=true
DEV_OTP_CODE=246810
# ۳۰۰ شماره‌ی تست (0912 + 7 رقم)
DEV_OTP_ALLOWED_PHONES=<خروجی دستور زیر>
# سقف‌های IP را برای تست از یک ماشین بالا ببرید
THROTTLE_OTP_REQUEST=100000/hour
THROTTLE_OTP_VERIFY=100000/hour
THROTTLE_INSPECTION_CREATE=100000/hour
THROTTLE_ANON=10000000/day
THROTTLE_USER=10000000/day
```
ساخت لیست شماره‌ها:
```
python -c "print(','.join(f'0912{n:07d}' for n in range(1,301)))"
```
> `DEV_OTP_ENABLED` در `DJANGO_ENV=production` اجازه‌ی بالا آمدن نمی‌دهد (عمداً).

## ۲) اجرا
```
pip install locust
locust -f loadtest/locustfile.py --host https://staging.example.ir \
       --users 200 --spawn-rate 10 --run-time 10m --headless --csv=loadtest/result
```
(با `--headless` حذف شود، رابط وب روی http://localhost:8089 باز می‌شود.)

## ۳) معیار قبولی (در اسکریپت هم چک می‌شود)
- نرخ خطا < ۱٪ و p95 < ۲ ثانیه
- در حین تست ببینید:
  - `docker stats` — CPU/RAM سرویس‌های backend و frontend
  - اتصال‌های دیتابیس: `select count(*) from pg_stat_activity;` باید زیر ~۶۰ بماند
  - `docker compose logs backend | grep -c "WORKER TIMEOUT"` باید صفر باشد
  - صف Celery: `docker compose exec redis redis-cli -n 0 llen celery` بعد از توقف بار به صفر برگردد

## ۴) نکته
اسکریپت مستقیم به API جنگو (از طریق Nginx) می‌زند و ظرفیت بک‌اند را می‌سنجد. برای
سنجش رندر سمت سرور داشبوردها (Next.js) یک سناریوی جدا روی `/dashboard/...` با کوکی
نشست اضافه کنید.

"""
loadtest/locustfile.py  (EDRA v32)

شبیه‌سازی ~۲۰۰ مشتری همزمان: ورود با OTP، مرور تجهیزات/شهرها، محاسبه قیمت،
مشاهده درخواست‌ها و داشبورد، و (به‌ندرت) ثبت درخواست جدید.

⚠️ این اسکریپت در محیط ساخت v32 «اجرا نشده»؛ باید روی استیجینگ اجرا شود.
راهنما: loadtest/README.md
"""
import os
import random

from locust import HttpUser, between, events, task

# شماره‌ها باید در DEV_OTP_ALLOWED_PHONES سرورِ استیجینگ باشند (README را ببینید)
PHONE_PREFIX = os.environ.get("LT_PHONE_PREFIX", "0912")
DEV_OTP_CODE = os.environ.get("DEV_OTP_CODE", "246810")
_counter = {"n": 0}


def next_phone() -> str:
    _counter["n"] += 1
    return f"{PHONE_PREFIX}{_counter['n']:07d}"


class Customer(HttpUser):
    wait_time = between(2, 6)  # مکث انسانی بین کارها

    def on_start(self):
        self.phone = next_phone()
        self.token = None
        self.equipment = []
        self.cities = []
        self._login()
        self._load_reference_data()

    # ---------------- ورود ----------------
    def _login(self):
        r = self.client.post("/api/core/otp/request/",
                             json={"phone": self.phone}, name="OTP request")
        if r.status_code != 200:
            return
        r = self.client.post("/api/core/otp/verify/",
                             json={"phone": self.phone, "code": DEV_OTP_CODE},
                             name="OTP verify")
        if r.status_code == 200:
            self.token = r.json().get("access")

    @property
    def auth(self):
        return {"Authorization": f"Bearer {self.token}"} if self.token else {}

    def _load_reference_data(self):
        r = self.client.get("/api/core/equipment-types/", name="GET equipment-types")
        if r.status_code == 200:
            data = r.json()
            self.equipment = data if isinstance(data, list) else data.get("results", [])
        r = self.client.get("/api/core/city-multipliers/", name="GET city-multipliers")
        if r.status_code == 200:
            data = r.json()
            rows = data if isinstance(data, list) else data.get("results", [])
            self.cities = [c["city"] for c in rows]

    # ---------------- کارها (وزن = تکرار نسبی) ----------------
    @task(5)
    def browse_reference_data(self):
        self.client.get("/api/core/equipment-types/", name="GET equipment-types")
        self.client.get("/api/core/city-multipliers/", name="GET city-multipliers")

    @task(6)
    def price_calculation(self):
        if not (self.equipment and self.cities):
            return
        self.client.post("/api/pricing/calculate/", json={
            "equipment_type_id": random.choice(self.equipment)["id"],
            "params": {},
            "city": random.choice(self.cities),
            "service_type": random.choice(["standard", "pro"]),
        }, name="POST pricing/calculate")

    @task(5)
    def my_requests(self):
        self.client.get("/api/core/inspection-requests/", headers=self.auth,
                        name="GET inspection-requests")

    @task(4)
    def dashboard(self):
        self.client.get("/api/core/customer/dashboard/", headers=self.auth,
                        name="GET customer/dashboard")

    @task(2)
    def me(self):
        self.client.get("/api/core/users/me/", headers=self.auth, name="GET users/me")

    @task(1)
    def tickets(self):
        self.client.get("/api/support/tickets/", headers=self.auth, name="GET tickets")

    @task(1)
    def create_request(self):
        """ثبت درخواست جدید — کم‌تکرار؛ سقف ۵ درخواست باز و ۲۰/ساعت در بک‌اند اعمال می‌شود."""
        if not (self.equipment and self.cities and self.token):
            return
        with self.client.post("/api/core/inspection-requests/", headers=self.auth, json={
            "equipment_type": random.choice(self.equipment)["id"],
            "params": {},
            "city": random.choice(self.cities),
            "address": "آدرس تست بار",
            "brand_model": "LT-1",
            "manufacture_year": 1400,
        }, name="POST inspection-requests", catch_response=True) as r:
            # 400 به‌دلیل سقف «۵ درخواست باز» رفتار مورد انتظار است، شکست نیست
            if r.status_code in (201, 400, 429):
                r.success()


@events.quitting.add_listener
def _fail_on_errors(environment, **kw):
    """CI: اگر نرخ خطا >۱٪ یا p95 > ۲ثانیه بود با کد خروج ۱ تمام شود."""
    s = environment.stats.total
    if s.num_requests and (s.fail_ratio > 0.01 or s.get_response_time_percentile(0.95) > 2000):
        print(f"FAIL: fail_ratio={s.fail_ratio:.3%} p95={s.get_response_time_percentile(0.95)}ms")
        environment.process_exit_code = 1

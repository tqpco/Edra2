# setup_edra_jalalidate.py
# -*- coding: utf-8 -*-
"""
اسکریپت ساخت کامل پکیج edra_jalalidate در فرانت‌اند
اجرا: python setup_edra_jalalidate.py
"""

import os
import sys

# ================================================================
# مسیرها
# ================================================================
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
FRONTEND_DIR = os.path.join(BASE_DIR, 'frontend')
LIB_DIR = os.path.join(FRONTEND_DIR, 'lib')
JALALI_DIR = os.path.join(LIB_DIR, 'edra_jalalidate')

# ================================================================
# محتوای فایل‌ها
# ================================================================

# 1. types/index.ts
TYPES_INDEX = '''// lib/edra_jalalidate/types/index.ts

export interface JalaliDateObject {
  year: number;
  month: number;
  day: number;
}

export interface JalaliDateTimeObject extends JalaliDateObject {
  hour: number;
  minute: number;
  second: number;
  microsecond?: number;
}

export interface JalaliDatePickerProps {
  /** مقدار اولیه (به صورت رشته جلالی یا Date) */
  value?: string | Date | JalaliDateObject | null;
  /** تغییر مقدار */
  onChange?: (value: string, jalaliObject: JalaliDateObject | null) => void;
  /** فرمت نمایش (پیش‌فرض: YYYY/MM/DD) */
  format?: string;
  /** استفاده از اعداد فارسی */
  usePersianDigits?: boolean;
  /** placeholder */
  placeholder?: string;
  /** کلاس‌های اضافی */
  className?: string;
  /** غیرفعال */
  disabled?: boolean;
  /** فقط خواندنی */
  readOnly?: boolean;
  /** نام فیلد (برای فرم) */
  name?: string;
  /** شناسه (برای فرم) */
  id?: string;
}

export interface JalaliDateTimePickerProps extends JalaliDatePickerProps {
  /** فرمت پیش‌فرض تاریخ و ساعت (پیش‌فرض: YYYY/MM/DD HH:mm) */
  format?: string;
}

export interface JalaliDatePickerRef {
  getValue: () => string;
  getJalaliObject: () => JalaliDateObject | null;
  setValue: (value: string | Date | JalaliDateObject) => void;
  openPicker: () => void;
  closePicker: () => void;
}

export type JalaliDatePickerRefType = React.RefObject<JalaliDatePickerRef>;
'''

# 2. jalali.ts
JALALI_TS = '''// lib/edra_jalalidate/jalali.ts
import type { JalaliDateObject, JalaliDateTimeObject } from './types';

// ============================================================
// ثابت‌های تقویم جلالی
// ============================================================
const JALALI_EPOCH = 1948320.5;

export const MONTH_NAMES_FA = [
  'فروردین', 'اردیبهشت', 'خرداد', 'تیر', 'مرداد', 'شهریور',
  'مهر', 'آبان', 'آذر', 'دی', 'بهمن', 'اسفند',
];
export const MONTH_NAMES_EN = [
  'Farvardin', 'Ordibehesht', 'Khordad', 'Tir', 'Mordad', 'Shahrivar',
  'Mehr', 'Aban', 'Azar', 'Dey', 'Bahman', 'Esfand',
];
export const DAY_NAMES_FA = ['شنبه', 'یکشنبه', 'دوشنبه', 'سه‌شنبه', 'چهارشنبه', 'پنجشنبه', 'جمعه'];
export const DAY_NAMES_EN = ['Saturday', 'Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday'];

// ============================================================
// توابع اصلی تبدیل
// ============================================================
export function isJalaliLeapYear(year: number): boolean {
  const a = year % 33;
  return [1, 5, 9, 13, 17, 21, 25, 29].includes(a);
}

export function jalaliMonthDays(year: number, month: number): number {
  if (month < 1 || month > 12) throw new Error('ماه باید بین ۱ تا ۱۲ باشد');
  if (month <= 6) return 31;
  if (month <= 11) return 30;
  return 29;
}

function gregorianToJd(year: number, month: number, day: number): number {
  const a = Math.floor((14 - month) / 12);
  const y = year + 4800 - a;
  const m = month + 12 * a - 3;
  return (
    day +
    Math.floor((153 * m + 2) / 5) +
    365 * y +
    Math.floor(y / 4) -
    Math.floor(y / 100) +
    Math.floor(y / 400) -
    32045
  );
}

function jdToGregorian(jd: number): { year: number; month: number; day: number } {
  jd = Math.floor(jd) + 0.5;
  const z = Math.floor(jd);
  const f = jd - z;
  let a: number;
  if (z < 2299161) {
    a = z;
  } else {
    const alpha = Math.floor((z - 1867216.25) / 36524.25);
    a = z + 1 + alpha - Math.floor(alpha / 4);
  }
  const b = a + 1524;
  const c = Math.floor((b - 122.1) / 365.25);
  const d = Math.floor(365.25 * c);
  const e = Math.floor((b - d) / 30.6001);
  const day = b - d - Math.floor(30.6001 * e) + f;
  const month = e < 14 ? e - 1 : e - 13;
  const year = month > 2 ? c - 4715 : c - 4716;
  return { year, month, day: Math.floor(day) };
}

function jalaliToJd(year: number, month: number, day: number): number {
  let totalDays: number;
  if (month > 6) {
    totalDays = (month - 1) * 30 + 6 + day;
  } else {
    totalDays = (month - 1) * 31 + day - 1;
  }
  let leapYears = 0;
  for (let y = 1; y < year; y++) {
    if (isJalaliLeapYear(y)) leapYears++;
  }
  const daysBefore = (year - 1) * 365 + leapYears;
  return JALALI_EPOCH + daysBefore + totalDays;
}

function jdToJalali(jd: number): JalaliDateObject {
  jd = Math.floor(jd);
  let year = Math.floor((jd - JALALI_EPOCH) / 365.2422) + 1;
  while (true) {
    const jdYearStart = jalaliToJd(year, 1, 1);
    if (jd < jdYearStart) {
      year--;
    } else {
      break;
    }
  }
  const dayOfYear = jd - jalaliToJd(year, 1, 1) + 1;
  let month: number, day: number;
  if (dayOfYear <= 186) {
    month = Math.floor((dayOfYear - 1) / 31) + 1;
    day = (dayOfYear - 1) % 31 + 1;
  } else {
    const rest = dayOfYear - 186;
    month = Math.floor((rest - 1) / 30) + 7;
    day = (rest - 1) % 30 + 1;
  }
  return { year, month, day };
}

// ============================================================
// توابع اصلی تبدیل
// ============================================================
export function gregorianToJalali(year: number, month: number, day: number): JalaliDateObject {
  const jd = gregorianToJd(year, month, day);
  return jdToJalali(jd);
}

export function jalaliToGregorian(year: number, month: number, day: number): { year: number; month: number; day: number } {
  const jd = jalaliToJd(year, month, day);
  return jdToGregorian(jd);
}

export function gregorianToJalaliDate(date: Date): JalaliDateObject {
  return gregorianToJalali(date.getFullYear(), date.getMonth() + 1, date.getDate());
}

export function jalaliToGregorianDate(jalali: JalaliDateObject): Date {
  const { year, month, day } = jalaliToGregorian(jalali.year, jalali.month, jalali.day);
  return new Date(year, month - 1, day);
}

// ============================================================
// کلاس JalaliDate
// ============================================================
export class JalaliDate {
  readonly year: number;
  readonly month: number;
  readonly day: number;

  constructor(year: number, month: number, day: number) {
    if (month < 1 || month > 12) throw new Error('ماه باید بین ۱ تا ۱۲ باشد');
    const maxDay = jalaliMonthDays(year, month);
    if (day < 1 || day > maxDay) throw new Error(f`روز باید بین ۱ تا ${maxDay} باشد`);
    this.year = year;
    this.month = month;
    this.day = day;
  }

  static fromGregorian(year: number, month: number, day: number): JalaliDate {
    const j = gregorianToJalali(year, month, day);
    return new JalaliDate(j.year, j.month, j.day);
  }

  static fromDate(date: Date): JalaliDate {
    return JalaliDate.fromGregorian(date.getFullYear(), date.getMonth() + 1, date.getDate());
  }

  static fromString(str: string, format: string = 'YYYY/MM/DD'): JalaliDate {
    const parts = str.split(/[/\\-: ]/);
    if (parts.length < 3) throw new Error('فرمت تاریخ نامعتبر است');
    let year = parseInt(parts[0]);
    let month = parseInt(parts[1]);
    let day = parseInt(parts[2]);
    if (isNaN(year) || isNaN(month) || isNaN(day)) throw new Error('تاریخ نامعتبر است');
    return new JalaliDate(year, month, day);
  }

  toGregorian(): { year: number; month: number; day: number } {
    return jalaliToGregorian(this.year, this.month, this.day);
  }

  toDate(): Date {
    const g = this.toGregorian();
    return new Date(g.year, g.month - 1, g.day);
  }

  toJd(): number {
    return jalaliToJd(this.year, this.month, this.day);
  }

  weekday(): number {
    return Math.floor((this.toJd() + 2) % 7);
  }

  dayOfYear(): number {
    if (this.month <= 6) {
      return (this.month - 1) * 31 + this.day;
    } else {
      return 186 + (this.month - 7) * 30 + this.day;
    }
  }

  daysInMonth(): number {
    return jalaliMonthDays(this.year, this.month);
  }

  isLeapYear(): boolean {
    return isJalaliLeapYear(this.year);
  }

  monthName(lang: 'fa' | 'en' = 'fa'): string {
    return lang === 'fa' ? MONTH_NAMES_FA[this.month - 1] : MONTH_NAMES_EN[this.month - 1];
  }

  dayName(lang: 'fa' | 'en' = 'fa'): string {
    const wd = this.weekday();
    return lang === 'fa' ? DAY_NAMES_FA[wd] : DAY_NAMES_EN[wd];
  }

  format(fmt: string = 'YYYY/MM/DD'): string {
    const replacements: Record<string, string> = {
      YYYY: String(this.year).padStart(4, '0'),
      YY: String(this.year % 100).padStart(2, '0'),
      MM: String(this.month).padStart(2, '0'),
      M: String(this.month),
      DD: String(this.day).padStart(2, '0'),
      D: String(this.day),
      MMMM: this.monthName('fa'),
      MMM: this.monthName('fa'),
      dddd: this.dayName('fa'),
      ddd: this.dayName('fa'),
    };
    let result = fmt;
    for (const [key, val] of Object.entries(replacements)) {
      result = result.replaceAll(key, val);
    }
    return result;
  }

  toString(): string {
    return this.format('YYYY/MM/DD');
  }

  toJSON(): JalaliDateObject {
    return { year: this.year, month: this.month, day: this.day };
  }

  equals(other: JalaliDate): boolean {
    return this.year === other.year && this.month === other.month && this.day === other.day;
  }

  compare(other: JalaliDate): number {
    const diff = this.year - other.year;
    if (diff !== 0) return diff;
    const diffM = this.month - other.month;
    if (diffM !== 0) return diffM;
    return this.day - other.day;
  }
}

// ============================================================
// کلاس JalaliDateTime
// ============================================================
export class JalaliDateTime {
  readonly date: JalaliDate;
  readonly hour: number;
  readonly minute: number;
  readonly second: number;
  readonly microsecond: number;

  constructor(
    year: number,
    month: number,
    day: number,
    hour: number = 0,
    minute: number = 0,
    second: number = 0,
    microsecond: number = 0
  ) {
    this.date = new JalaliDate(year, month, day);
    this.hour = hour;
    this.minute = minute;
    this.second = second;
    this.microsecond = microsecond;
    this._validateTime();
  }

  private _validateTime(): void {
    if (this.hour < 0 || this.hour > 23) throw new Error('ساعت باید بین ۰ تا ۲۳ باشد');
    if (this.minute < 0 || this.minute > 59) throw new Error('دقیقه باید بین ۰ تا ۵۹ باشد');
    if (this.second < 0 || this.second > 59) throw new Error('ثانیه باید بین ۰ تا ۵۹ باشد');
    if (this.microsecond < 0 || this.microsecond > 999999) throw new Error('میکروثانیه نامعتبر است');
  }

  static fromGregorian(
    year: number,
    month: number,
    day: number,
    hour: number = 0,
    minute: number = 0,
    second: number = 0,
    microsecond: number = 0
  ): JalaliDateTime {
    const j = gregorianToJalali(year, month, day);
    return new JalaliDateTime(j.year, j.month, j.day, hour, minute, second, microsecond);
  }

  static fromDate(date: Date): JalaliDateTime {
    return JalaliDateTime.fromGregorian(
      date.getFullYear(),
      date.getMonth() + 1,
      date.getDate(),
      date.getHours(),
      date.getMinutes(),
      date.getSeconds(),
      date.getMilliseconds() * 1000
    );
  }

  toDate(): Date {
    const g = this.date.toGregorian();
    return new Date(g.year, g.month - 1, g.day, this.hour, this.minute, this.second, this.microsecond / 1000);
  }

  format(fmt: string = 'YYYY/MM/DD HH:mm'): string {
    let result = this.date.format(fmt);
    const replacements: Record<string, string> = {
      HH: String(this.hour).padStart(2, '0'),
      H: String(this.hour),
      mm: String(this.minute).padStart(2, '0'),
      m: String(this.minute),
      ss: String(this.second).padStart(2, '0'),
      s: String(this.second),
      f: String(this.microsecond).padStart(6, '0'),
    };
    for (const [key, val] of Object.entries(replacements)) {
      result = result.replaceAll(key, val);
    }
    return result;
  }

  toString(): string {
    return this.format('YYYY/MM/DD HH:mm');
  }

  toJSON(): JalaliDateTimeObject {
    return {
      year: this.date.year,
      month: this.date.month,
      day: this.date.day,
      hour: this.hour,
      minute: this.minute,
      second: this.second,
      microsecond: this.microsecond,
    };
  }
}

// ============================================================
// توابع کمکی
// ============================================================
export function toJalaliString(date: Date | string, fmt: string = 'YYYY/MM/DD'): string {
  if (typeof date === 'string') {
    date = new Date(date);
  }
  const jd = JalaliDate.fromDate(date);
  return jd.format(fmt);
}

export function toJalaliDateTimeString(date: Date | string, fmt: string = 'YYYY/MM/DD HH:mm'): string {
  if (typeof date === 'string') {
    date = new Date(date);
  }
  const jdt = JalaliDateTime.fromDate(date);
  return jdt.format(fmt);
}

export function parseJalali(str: string, fmt: string = 'YYYY/MM/DD'): JalaliDate {
  return JalaliDate.fromString(str, fmt);
}

export function parseJalaliDateTime(str: string, fmt: string = 'YYYY/MM/DD HH:mm'): JalaliDateTime {
  const parts = str.split(/[ /:]/);
  if (parts.length < 5) throw new Error('فرمت تاریخ و ساعت نامعتبر است');
  const year = parseInt(parts[0]);
  const month = parseInt(parts[1]);
  const day = parseInt(parts[2]);
  const hour = parseInt(parts[3]);
  const minute = parseInt(parts[4]);
  const second = parts.length > 5 ? parseInt(parts[5]) : 0;
  return new JalaliDateTime(year, month, day, hour, minute, second);
}

// ============================================================
// توابع تبدیل ارقام
// ============================================================
const PERSIAN_DIGITS = ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'];

export function toPersianDigits(input: string | number): string {
  return String(input).replace(/[0-9]/g, (d) => PERSIAN_DIGITS[Number(d)]!);
}

export function toEnglishDigits(input: string): string {
  return input
    .replace(/[۰-۹]/g, (d) => String(PERSIAN_DIGITS.indexOf(d)))
    .replace(/[٠-٩]/g, (d) => String(d.charCodeAt(0) - 1632));
}

// ============================================================
// میان‌برهای اضافی
// ============================================================
export function dateToJalali(date: Date): JalaliDateObject {
  return gregorianToJalali(date.getFullYear(), date.getMonth() + 1, date.getDate());
}

export function jalaliToDate(jy: number, jm: number, jd: number): Date {
  const g = jalaliToGregorian(jy, jm, jd);
  return new Date(g.year, g.month - 1, g.day);
}

export function formatJalali(date: Date | JalaliDate): string {
  const j = date instanceof Date ? dateToJalali(date) : { year: date.year, month: date.month, day: date.day };
  return f`${toPersianDigits(j.day)} ${MONTH_NAMES_FA[j.month - 1]} ${toPersianDigits(j.year)}`;
}

export function formatJalaliNumeric(date: Date | JalaliDate, separator = '/'): string {
  const j = date instanceof Date ? dateToJalali(date) : { year: date.year, month: date.month, day: date.day };
  const mm = String(j.month).padStart(2, '0');
  const dd = String(j.day).padStart(2, '0');
  return toPersianDigits(f`${j.year}${separator}${mm}${separator}${dd}`);
}

export function formatJalaliWithWeekday(date: Date): string {
  const weekday = DAY_NAMES_FA[date.getDay()];
  return f`${weekday}، ${formatJalali(date)}`;
}

export function formatPersianTime(date: Date): string {
  const hh = String(date.getHours()).padStart(2, '0');
  const mm = String(date.getMinutes()).padStart(2, '0');
  return toPersianDigits(f`${hh}:${mm}`);
}
'''

# 3. utils.ts
UTILS_TS = '''// lib/edra_jalalidate/utils.ts
import { JalaliDate, JalaliDateTime } from './jalali';

export function formatJalali(date: Date | string | null, format: string = 'YYYY/MM/DD'): string {
  if (!date) return '';
  const d = typeof date === 'string' ? new Date(date) : date;
  if (isNaN(d.getTime())) return '';
  const jd = JalaliDate.fromDate(d);
  return jd.format(format);
}

export function formatJalaliDateTime(date: Date | string | null, format: string = 'YYYY/MM/DD HH:mm'): string {
  if (!date) return '';
  const d = typeof date === 'string' ? new Date(date) : date;
  if (isNaN(d.getTime())) return '';
  const jdt = JalaliDateTime.fromDate(d);
  return jdt.format(format);
}

export function isValidJalaliDate(str: string): boolean {
  try {
    JalaliDate.fromString(str);
    return true;
  } catch {
    return false;
  }
}

export function isValidJalaliDateTime(str: string): boolean {
  try {
    const parts = str.split(/[ /:]/);
    if (parts.length < 5) return false;
    const year = parseInt(parts[0]);
    const month = parseInt(parts[1]);
    const day = parseInt(parts[2]);
    const hour = parseInt(parts[3]);
    const minute = parseInt(parts[4]);
    if (isNaN(year) || isNaN(month) || isNaN(day) || isNaN(hour) || isNaN(minute)) return false;
    new JalaliDateTime(year, month, day, hour, minute);
    return true;
  } catch {
    return false;
  }
}
'''

# 4. ntp.ts
NTP_TS = '''// lib/edra_jalalidate/ntp.ts
import { JalaliDate, JalaliDateTime } from './jalali';

export interface NtpResponse {
  datetime: string;
}

export async function getAccurateDateTime(fallbackToSystem: boolean = true): Promise<Date> {
  try {
    const apiUrl = process.env.NEXT_PUBLIC_API_URL || '';
    const url = f`${apiUrl}/api/core/ntp-time/`;
    const response = await fetch(url, {
      headers: { 'Content-Type': 'application/json' },
      cache: 'no-store',
    });
    if (!response.ok) throw new Error('NTP API error');
    const data: NtpResponse = await response.json();
    return new Date(data.datetime);
  } catch (error) {
    console.warn('NTP fallback to system time:', error);
    if (fallbackToSystem) return new Date();
    throw error;
  }
}

export async function getAccurateJalaliToday(): Promise<JalaliDate> {
  const dt = await getAccurateDateTime(true);
  return JalaliDate.fromDate(dt);
}

export async function getAccurateJalaliNow(): Promise<JalaliDateTime> {
  const dt = await getAccurateDateTime(true);
  return JalaliDateTime.fromDate(dt);
}
'''

# 5. index.ts
INDEX_TS = '''// lib/edra_jalalidate/index.ts

export * from './jalali';
export * from './utils';
export * from './ntp';
export * from './types';
export * from './hooks';
export * from './components';
'''

# 6. components/index.ts
COMPONENTS_INDEX = '''// lib/edra_jalalidate/components/index.ts

export { JalaliDatePicker } from './JalaliDatePicker';
export { JalaliDateTimePicker } from './JalaliDateTimePicker';
'''

# 7. components/JalaliDatePicker.tsx
JALALI_DATE_PICKER = '''// lib/edra_jalalidate/components/JalaliDatePicker.tsx
import React, { useState, useRef, useEffect, forwardRef, useImperativeHandle } from 'react';
import {
  JalaliDate,
  jalaliMonthDays,
  toPersianDigits,
  type JalaliDateObject,
  type JalaliDatePickerProps,
  type JalaliDatePickerRef,
} from '../index';
import '../styles/jalali-datepicker.css';

export const JalaliDatePicker = forwardRef<JalaliDatePickerRef, JalaliDatePickerProps>(
  (
    {
      value,
      onChange,
      format = 'YYYY/MM/DD',
      usePersianDigits = false,
      placeholder = '۱۴۰۴/۰۵/۱۲',
      className = '',
      disabled = false,
      readOnly = false,
      name,
      id,
    },
    ref
  ) => {
    const [isOpen, setIsOpen] = useState(false);
    const [inputValue, setInputValue] = useState<string>('');
    const [selectedDate, setSelectedDate] = useState<JalaliDate | null>(null);
    const [viewDate, setViewDate] = useState<JalaliDate | null>(null);
    const containerRef = useRef<HTMLDivElement>(null);
    const inputRef = useRef<HTMLInputElement>(null);

    useEffect(() => {
      let jd: JalaliDate | null = null;
      if (value instanceof Date) {
        jd = JalaliDate.fromDate(value);
      } else if (value && typeof value === 'object' && 'year' in value) {
        const obj = value as JalaliDateObject;
        try {
          jd = new JalaliDate(obj.year, obj.month, obj.day);
        } catch {
          jd = null;
        }
      } else if (typeof value === 'string' && value.trim()) {
        try {
          jd = JalaliDate.fromString(value);
        } catch {
          jd = null;
        }
      } else if (value instanceof JalaliDate) {
        jd = value;
      }
      if (jd) {
        setSelectedDate(jd);
        setInputValue(jd.format(format));
        setViewDate(jd);
      } else {
        setInputValue('');
        setViewDate(JalaliDate.fromDate(new Date()));
      }
    }, [value, format]);

    useEffect(() => {
      const handleClickOutside = (event: MouseEvent) => {
        if (containerRef.current && !containerRef.current.contains(event.target as Node)) {
          setIsOpen(false);
        }
      };
      document.addEventListener('mousedown', handleClickOutside);
      return () => document.removeEventListener('mousedown', handleClickOutside);
    }, []);

    useImperativeHandle(ref, () => ({
      getValue: () => inputValue,
      getJalaliObject: () => selectedDate?.toJSON() || null,
      setValue: (val: string | Date | JalaliDateObject) => {
        let jd: JalaliDate | null = null;
        if (val instanceof Date) {
          jd = JalaliDate.fromDate(val);
        } else if (typeof val === 'string') {
          try {
            jd = JalaliDate.fromString(val);
          } catch {
            jd = null;
          }
        } else if (typeof val === 'object' && 'year' in val) {
          try {
            jd = new JalaliDate(val.year, val.month, val.day);
          } catch {
            jd = null;
          }
        }
        if (jd) {
          setSelectedDate(jd);
          setInputValue(jd.format(format));
          setViewDate(jd);
          onChange?.(jd.format(format), jd.toJSON());
        }
      },
      openPicker: () => !disabled && !readOnly && setIsOpen(true),
      closePicker: () => setIsOpen(false),
    }));

    const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
      const val = e.target.value;
      setInputValue(val);
      try {
        const jd = JalaliDate.fromString(val);
        setSelectedDate(jd);
        setViewDate(jd);
        onChange?.(val, jd.toJSON());
      } catch {
        setSelectedDate(null);
        onChange?.(val, null);
      }
    };

    const handleInputFocus = () => {
      if (!disabled && !readOnly) {
        setIsOpen(true);
      }
    };

    const handleInputKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
      if (e.key === 'Escape') {
        setIsOpen(false);
      }
      if (e.key === 'Enter' && isOpen && viewDate) {
        selectDate(viewDate.year, viewDate.month, viewDate.day);
      }
    };

    const selectDate = (year: number, month: number, day: number) => {
      try {
        const jd = new JalaliDate(year, month, day);
        setSelectedDate(jd);
        const formatted = jd.format(format);
        setInputValue(formatted);
        setViewDate(jd);
        setIsOpen(false);
        onChange?.(formatted, jd.toJSON());
        inputRef.current?.focus();
      } catch (error) {
        console.warn('Invalid date selection:', error);
      }
    };

    const goToMonth = (delta: number) => {
      if (!viewDate) return;
      let newMonth = viewDate.month + delta;
      let newYear = viewDate.year;
      if (newMonth < 1) { newMonth = 12; newYear--; }
      else if (newMonth > 12) { newMonth = 1; newYear++; }
      const maxDay = jalaliMonthDays(newYear, newMonth);
      const newDay = Math.min(viewDate.day, maxDay);
      try {
        setViewDate(new JalaliDate(newYear, newMonth, newDay));
      } catch {
        setViewDate(new JalaliDate(newYear, newMonth, 1));
      }
    };

    const goToToday = () => {
      const today = JalaliDate.fromDate(new Date());
      setViewDate(today);
      selectDate(today.year, today.month, today.day);
    };

    const renderDays = (): React.ReactElement[] => {
      if (!viewDate) return [];
      const year = viewDate.year;
      const month = viewDate.month;
      const daysInMonth = viewDate.daysInMonth();
      const firstDayOfMonth = JalaliDate.fromGregorian(
        viewDate.toGregorian().year,
        viewDate.toGregorian().month,
        1
      ).weekday();
      const today = JalaliDate.fromDate(new Date());
      const isToday = (d: number) => today.year === year && today.month === month && today.day === d;

      const rows: React.ReactElement[] = [];
      let cells: React.ReactElement[] = [];

      for (let i = 0; i < firstDayOfMonth; i++) {
        cells.push(<td key={`empty-${i}`} className="empty" />);
      }

      for (let d = 1; d <= daysInMonth; d++) {
        const selected = selectedDate && selectedDate.year === year && selectedDate.month === month && selectedDate.day === d;
        const todayClass = isToday(d) ? 'today' : '';
        const selectedClass = selected ? 'selected' : '';
        cells.push(
          <td
            key={d}
            className={`${todayClass} ${selectedClass}`}
            onClick={() => selectDate(year, month, d)}
          >
            {d}
          </td>
        );
        if ((firstDayOfMonth + d - 1) % 7 === 6) {
          rows.push(<tr key={`row-${d}`}>{cells}</tr>);
          cells = [];
        }
      }
      if (cells.length > 0) {
        while (cells.length < 7) {
          cells.push(<td key={`empty-end-${cells.length}`} className="empty" />);
        }
        rows.push(<tr key="row-last">{cells}</tr>);
      }
      return rows;
    };

    const displayNumber = (num: number): string => {
      return usePersianDigits ? toPersianDigits(num) : String(num);
    };

    return (
      <div ref={containerRef} className={`jalali-datepicker-wrapper ${className}`}>
        <input
          ref={inputRef}
          type="text"
          className="jalali-datepicker-input"
          value={inputValue}
          onChange={handleInputChange}
          onFocus={handleInputFocus}
          onKeyDown={handleInputKeyDown}
          placeholder={placeholder}
          disabled={disabled}
          readOnly={readOnly}
          name={name}
          id={id}
          autoComplete="off"
        />
        {isOpen && !disabled && !readOnly && (
          <div className="jalali-datepicker-popup">
            <div className="jalali-datepicker-header">
              <button type="button" className="nav-btn" onClick={() => goToMonth(-1)}>◀</button>
              <span className="month-year">
                {viewDate ? `${displayNumber(viewDate.year)} ${viewDate.monthName('fa')}` : ''}
              </span>
              <button type="button" className="nav-btn" onClick={() => goToMonth(1)}>▶</button>
            </div>
            <table className="jalali-datepicker-table">
              <thead>
                <tr><th>ش</th><th>ی</th><th>د</th><th>س</th><th>چ</th><th>پ</th><th>ج</th></tr>
              </thead>
              <tbody>{renderDays()}</tbody>
            </table>
            <div className="jalali-datepicker-footer">
              <button type="button" className="today-btn" onClick={goToToday}>امروز</button>
              <button type="button" className="close-btn" onClick={() => setIsOpen(false)}>بستن</button>
            </div>
          </div>
        )}
      </div>
    );
  }
);

JalaliDatePicker.displayName = 'JalaliDatePicker';
'''

# 8. components/JalaliDateTimePicker.tsx
JALALI_DATETIME_PICKER = '''// lib/edra_jalalidate/components/JalaliDateTimePicker.tsx
import React, { useState, useRef, useEffect, forwardRef, useImperativeHandle } from 'react';
import {
  JalaliDate,
  JalaliDateTime,
  jalaliMonthDays,
  toPersianDigits,
  type JalaliDateObject,
  type JalaliDateTimePickerProps,
  type JalaliDatePickerRef,
} from '../index';
import '../styles/jalali-datepicker.css';

export const JalaliDateTimePicker = forwardRef<JalaliDatePickerRef, JalaliDateTimePickerProps>(
  (
    {
      value,
      onChange,
      format = 'YYYY/MM/DD HH:mm',
      usePersianDigits = false,
      placeholder = '۱۴۰۴/۰۵/۱۲ ۱۴:۳۰',
      className = '',
      disabled = false,
      readOnly = false,
      name,
      id,
    },
    ref
  ) => {
    const [isOpen, setIsOpen] = useState(false);
    const [inputValue, setInputValue] = useState<string>('');
    const [selectedDateTime, setSelectedDateTime] = useState<JalaliDateTime | null>(null);
    const [viewDate, setViewDate] = useState<JalaliDate | null>(null);
    const [selectedHour, setSelectedHour] = useState<number>(0);
    const [selectedMinute, setSelectedMinute] = useState<number>(0);
    const containerRef = useRef<HTMLDivElement>(null);
    const inputRef = useRef<HTMLInputElement>(null);

    useEffect(() => {
      let jdt: JalaliDateTime | null = null;
      if (value instanceof Date) {
        jdt = JalaliDateTime.fromDate(value);
      } else if (typeof value === 'string' && value.trim()) {
        try {
          const parts = value.split(/[ /:]/);
          if (parts.length >= 5) {
            const year = parseInt(parts[0]);
            const month = parseInt(parts[1]);
            const day = parseInt(parts[2]);
            const hour = parseInt(parts[3]);
            const minute = parseInt(parts[4]);
            const second = parts.length > 5 ? parseInt(parts[5]) : 0;
            jdt = new JalaliDateTime(year, month, day, hour, minute, second);
          } else {
            const jd = JalaliDate.fromString(value);
            const now = new Date();
            jdt = new JalaliDateTime(jd.year, jd.month, jd.day, now.getHours(), now.getMinutes(), 0);
          }
        } catch {
          jdt = null;
        }
      } else if (value && typeof value === 'object' && 'year' in value) {
        const obj = value as any;
        try {
          jdt = new JalaliDateTime(obj.year, obj.month, obj.day, obj.hour || 0, obj.minute || 0, obj.second || 0);
        } catch {
          jdt = null;
        }
      }
      if (jdt) {
        setSelectedDateTime(jdt);
        setInputValue(jdt.format(format));
        setViewDate(jdt.date);
        setSelectedHour(jdt.hour);
        setSelectedMinute(jdt.minute);
      } else {
        const now = JalaliDateTime.fromDate(new Date());
        setViewDate(now.date);
        setSelectedHour(now.hour);
        setSelectedMinute(now.minute);
        setInputValue('');
      }
    }, [value, format]);

    useEffect(() => {
      const handleClickOutside = (event: MouseEvent) => {
        if (containerRef.current && !containerRef.current.contains(event.target as Node)) {
          setIsOpen(false);
        }
      };
      document.addEventListener('mousedown', handleClickOutside);
      return () => document.removeEventListener('mousedown', handleClickOutside);
    }, []);

    useImperativeHandle(ref, () => ({
      getValue: () => inputValue,
      getJalaliObject: () => selectedDateTime?.toJSON() || null,
      setValue: (val: string | Date | JalaliDateObject) => {
        let jdt: JalaliDateTime | null = null;
        if (val instanceof Date) {
          jdt = JalaliDateTime.fromDate(val);
        } else if (typeof val === 'string') {
          try {
            const parts = val.split(/[ /:]/);
            if (parts.length >= 5) {
              const year = parseInt(parts[0]);
              const month = parseInt(parts[1]);
              const day = parseInt(parts[2]);
              const hour = parseInt(parts[3]);
              const minute = parseInt(parts[4]);
              const second = parts.length > 5 ? parseInt(parts[5]) : 0;
              jdt = new JalaliDateTime(year, month, day, hour, minute, second);
            } else {
              const jd = JalaliDate.fromString(val);
              const now = new Date();
              jdt = new JalaliDateTime(jd.year, jd.month, jd.day, now.getHours(), now.getMinutes(), 0);
            }
          } catch {
            jdt = null;
          }
        }
        if (jdt) {
          setSelectedDateTime(jdt);
          setInputValue(jdt.format(format));
          setViewDate(jdt.date);
          setSelectedHour(jdt.hour);
          setSelectedMinute(jdt.minute);
          onChange?.(jdt.format(format), jdt.toJSON());
        }
      },
      openPicker: () => !disabled && !readOnly && setIsOpen(true),
      closePicker: () => setIsOpen(false),
    }));

    const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
      const val = e.target.value;
      setInputValue(val);
      try {
        const parts = val.split(/[ /:]/);
        if (parts.length >= 5) {
          const year = parseInt(parts[0]);
          const month = parseInt(parts[1]);
          const day = parseInt(parts[2]);
          const hour = parseInt(parts[3]);
          const minute = parseInt(parts[4]);
          const second = parts.length > 5 ? parseInt(parts[5]) : 0;
          const jdt = new JalaliDateTime(year, month, day, hour, minute, second);
          setSelectedDateTime(jdt);
          setViewDate(jdt.date);
          setSelectedHour(hour);
          setSelectedMinute(minute);
          onChange?.(val, jdt.toJSON());
        } else {
          const jd = JalaliDate.fromString(val);
          const now = new Date();
          const jdt = new JalaliDateTime(jd.year, jd.month, jd.day, now.getHours(), now.getMinutes(), 0);
          setSelectedDateTime(jdt);
          setViewDate(jdt.date);
          setSelectedHour(jdt.hour);
          setSelectedMinute(jdt.minute);
          onChange?.(val, jdt.toJSON());
        }
      } catch {
        setSelectedDateTime(null);
        onChange?.(val, null);
      }
    };

    const selectDateTime = (year: number, month: number, day: number, hour?: number, minute?: number) => {
      try {
        const h = hour !== undefined ? hour : selectedHour;
        const m = minute !== undefined ? minute : selectedMinute;
        const jdt = new JalaliDateTime(year, month, day, h, m, 0);
        setSelectedDateTime(jdt);
        const formatted = jdt.format(format);
        setInputValue(formatted);
        setViewDate(jdt.date);
        setSelectedHour(h);
        setSelectedMinute(m);
        setIsOpen(false);
        onChange?.(formatted, jdt.toJSON());
        inputRef.current?.focus();
      } catch (error) {
        console.warn('Invalid datetime selection:', error);
      }
    };

    const renderDays = (): React.ReactElement[] => {
      if (!viewDate) return [];
      const year = viewDate.year;
      const month = viewDate.month;
      const daysInMonth = viewDate.daysInMonth();
      const firstDayOfMonth = JalaliDate.fromGregorian(
        viewDate.toGregorian().year,
        viewDate.toGregorian().month,
        1
      ).weekday();
      const today = JalaliDate.fromDate(new Date());
      const isToday = (d: number) => today.year === year && today.month === month && today.day === d;

      const rows: React.ReactElement[] = [];
      let cells: React.ReactElement[] = [];

      for (let i = 0; i < firstDayOfMonth; i++) {
        cells.push(<td key={`empty-${i}`} className="empty" />);
      }

      for (let d = 1; d <= daysInMonth; d++) {
        const selected = selectedDateTime &&
          selectedDateTime.date.year === year &&
          selectedDateTime.date.month === month &&
          selectedDateTime.date.day === d;
        const todayClass = isToday(d) ? 'today' : '';
        const selectedClass = selected ? 'selected' : '';
        cells.push(
          <td
            key={d}
            className={`${todayClass} ${selectedClass}`}
            onClick={() => selectDateTime(year, month, d, selectedHour, selectedMinute)}
          >
            {d}
          </td>
        );
        if ((firstDayOfMonth + d - 1) % 7 === 6) {
          rows.push(<tr key={`row-${d}`}>{cells}</tr>);
          cells = [];
        }
      }
      if (cells.length > 0) {
        while (cells.length < 7) {
          cells.push(<td key={`empty-end-${cells.length}`} className="empty" />);
        }
        rows.push(<tr key="row-last">{cells}</tr>);
      }
      return rows;
    };

    const goToMonth = (delta: number) => {
      if (!viewDate) return;
      let newMonth = viewDate.month + delta;
      let newYear = viewDate.year;
      if (newMonth < 1) { newMonth = 12; newYear--; }
      else if (newMonth > 12) { newMonth = 1; newYear++; }
      const maxDay = jalaliMonthDays(newYear, newMonth);
      try {
        setViewDate(new JalaliDate(newYear, newMonth, Math.min(viewDate.day, maxDay)));
      } catch {
        setViewDate(new JalaliDate(newYear, newMonth, 1));
      }
    };

    const displayNumber = (num: number): string => {
      return usePersianDigits ? toPersianDigits(num) : String(num);
    };

    return (
      <div ref={containerRef} className={`jalali-datepicker-wrapper ${className}`}>
        <input
          ref={inputRef}
          type="text"
          className="jalali-datepicker-input"
          value={inputValue}
          onChange={handleInputChange}
          onFocus={() => !disabled && !readOnly && setIsOpen(true)}
          onKeyDown={(e) => e.key === 'Escape' && setIsOpen(false)}
          placeholder={placeholder}
          disabled={disabled}
          readOnly={readOnly}
          name={name}
          id={id}
          autoComplete="off"
        />
        {isOpen && !disabled && !readOnly && (
          <div className="jalali-datepicker-popup jalali-datetime-popup">
            <div className="jalali-datepicker-header">
              <button type="button" className="nav-btn" onClick={() => goToMonth(-1)}>◀</button>
              <span className="month-year">
                {viewDate ? `${displayNumber(viewDate.year)} ${viewDate.monthName('fa')}` : ''}
              </span>
              <button type="button" className="nav-btn" onClick={() => goToMonth(1)}>▶</button>
            </div>
            <table className="jalali-datepicker-table">
              <thead><tr><th>ش</th><th>ی</th><th>د</th><th>س</th><th>چ</th><th>پ</th><th>ج</th></tr></thead>
              <tbody>{renderDays()}</tbody>
            </table>
            <div className="jalali-datetime-time">
              <div className="time-selector">
                <label>ساعت</label>
                <input
                  type="number"
                  min="0"
                  max="23"
                  value={selectedHour}
                  onChange={(e) => {
                    const val = parseInt(e.target.value);
                    if (!isNaN(val) && val >= 0 && val <= 23) {
                      setSelectedHour(val);
                      if (selectedDateTime) {
                        const jdt = new JalaliDateTime(
                          selectedDateTime.date.year,
                          selectedDateTime.date.month,
                          selectedDateTime.date.day,
                          val,
                          selectedMinute,
                          0
                        );
                        setSelectedDateTime(jdt);
                        setInputValue(jdt.format(format));
                        onChange?.(jdt.format(format), jdt.toJSON());
                      }
                    }
                  }}
                />
              </div>
              <div className="time-selector">
                <label>دقیقه</label>
                <input
                  type="number"
                  min="0"
                  max="59"
                  value={selectedMinute}
                  onChange={(e) => {
                    const val = parseInt(e.target.value);
                    if (!isNaN(val) && val >= 0 && val <= 59) {
                      setSelectedMinute(val);
                      if (selectedDateTime) {
                        const jdt = new JalaliDateTime(
                          selectedDateTime.date.year,
                          selectedDateTime.date.month,
                          selectedDateTime.date.day,
                          selectedHour,
                          val,
                          0
                        );
                        setSelectedDateTime(jdt);
                        setInputValue(jdt.format(format));
                        onChange?.(jdt.format(format), jdt.toJSON());
                      }
                    }
                  }}
                />
              </div>
            </div>
            <div className="jalali-datepicker-footer">
              <button type="button" className="today-btn" onClick={() => {
                const now = JalaliDateTime.fromDate(new Date());
                setViewDate(now.date);
                setSelectedHour(now.hour);
                setSelectedMinute(now.minute);
                selectDateTime(now.date.year, now.date.month, now.date.day, now.hour, now.minute);
              }}>اکنون</button>
              <button type="button" className="close-btn" onClick={() => setIsOpen(false)}>بستن</button>
            </div>
          </div>
        )}
      </div>
    );
  }
);

JalaliDateTimePicker.displayName = 'JalaliDateTimePicker';
'''

# 9. hooks/index.ts
HOOKS_INDEX = '''// lib/edra_jalalidate/hooks/index.ts
export * from './useJalali';
'''

# 10. hooks/useJalali.ts
USE_JALALI = '''// lib/edra_jalalidate/hooks/useJalali.ts
import { useState, useEffect, useCallback, useMemo } from 'react';
import { JalaliDate, JalaliDateTime } from '../jalali';
import { getAccurateDateTime } from '../ntp';

interface UseJalaliOptions {
  accurate?: boolean;
}

export function useJalaliToday(options: UseJalaliOptions = {}) {
  const { accurate = false } = options;
  const [date, setDate] = useState<JalaliDate | null>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<Error | null>(null);

  const fetchToday = useCallback(async () => {
    try {
      setLoading(true);
      setError(null);
      const dt = accurate ? await getAccurateDateTime(true) : new Date();
      setDate(JalaliDate.fromDate(dt));
    } catch (err) {
      setError(err instanceof Error ? err : new Error('خطا در دریافت تاریخ'));
    } finally {
      setLoading(false);
    }
  }, [accurate]);

  useEffect(() => {
    fetchToday();
    const interval = setInterval(() => {
      if (!accurate) {
        setDate(JalaliDate.fromDate(new Date()));
      }
    }, 60000);
    return () => clearInterval(interval);
  }, [accurate, fetchToday]);

  return { date, loading, error, refetch: fetchToday };
}

export function useJalaliNow(options: UseJalaliOptions = {}) {
  const { accurate = false } = options;
  const [datetime, setDatetime] = useState<JalaliDateTime | null>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<Error | null>(null);

  const fetchNow = useCallback(async () => {
    try {
      setLoading(true);
      setError(null);
      const dt = accurate ? await getAccurateDateTime(true) : new Date();
      setDatetime(JalaliDateTime.fromDate(dt));
    } catch (err) {
      setError(err instanceof Error ? err : new Error('خطا در دریافت زمان'));
    } finally {
      setLoading(false);
    }
  }, [accurate]);

  useEffect(() => {
    fetchNow();
    const interval = setInterval(() => {
      if (!accurate) {
        setDatetime(JalaliDateTime.fromDate(new Date()));
      } else {
        fetchNow();
      }
    }, accurate ? 10000 : 1000);
    return () => clearInterval(interval);
  }, [accurate, fetchNow]);

  return { datetime, loading, error, refetch: fetchNow };
}

export function useJalaliDate(date: Date | string | null | undefined): JalaliDate | null {
  return useMemo(() => {
    if (!date) return null;
    const d = typeof date === 'string' ? new Date(date) : date;
    if (isNaN(d.getTime())) return null;
    return JalaliDate.fromDate(d);
  }, [date]);
}

export function useJalaliDateTime(date: Date | string | null | undefined): JalaliDateTime | null {
  return useMemo(() => {
    if (!date) return null;
    const d = typeof date === 'string' ? new Date(date) : date;
    if (isNaN(d.getTime())) return null;
    return JalaliDateTime.fromDate(d);
  }, [date]);
}

export function useJalaliField(initialValue?: string | Date | JalaliDate | null) {
  const [value, setValue] = useState<string>('');
  const [jalaliObject, setJalaliObject] = useState<JalaliDate | null>(null);

  const setFromDate = useCallback((date: Date | string | JalaliDate | null) => {
    if (!date) {
      setValue('');
      setJalaliObject(null);
      return;
    }
    let jd: JalaliDate;
    if (date instanceof JalaliDate) {
      jd = date;
    } else if (typeof date === 'string') {
      try {
        jd = JalaliDate.fromString(date);
      } catch {
        jd = JalaliDate.fromDate(new Date(date));
      }
    } else {
      jd = JalaliDate.fromDate(date);
    }
    setValue(jd.format('YYYY/MM/DD'));
    setJalaliObject(jd);
  }, []);

  const setFromString = useCallback((str: string) => {
    try {
      const jd = JalaliDate.fromString(str);
      setValue(jd.format('YYYY/MM/DD'));
      setJalaliObject(jd);
    } catch {
      setValue(str);
      setJalaliObject(null);
    }
  }, []);

  const onChange = useCallback((newValue: string) => {
    setFromString(newValue);
  }, [setFromString]);

  useEffect(() => {
    if (initialValue) {
      setFromDate(initialValue);
    }
  }, [initialValue, setFromDate]);

  return {
    value,
    jalaliObject,
    setValue: onChange,
    setFromDate,
    setFromString,
  };
}
'''

# 11. styles/jalali-datepicker.css
CSS_FILE = '''/* lib/edra_jalalidate/styles/jalali-datepicker.css */
@font-face {
  font-family: 'IRANYekanX';
  src: url('/fonts/IRANYekanXFaNum-Regular.ttf') format('truetype');
  font-weight: 400;
  font-style: normal;
  font-display: swap;
}

@font-face {
  font-family: 'IRANYekanX';
  src: url('/fonts/IRANYekanXFaNum-Medium.ttf') format('truetype');
  font-weight: 500;
  font-style: normal;
  font-display: swap;
}

@font-face {
  font-family: 'IRANYekanX';
  src: url('/fonts/IRANYekanXFaNum-Bold.ttf') format('truetype');
  font-weight: 700;
  font-style: normal;
  font-display: swap;
}

.jalali-datepicker-wrapper {
  display: inline-block;
  position: relative;
  font-family: 'IRANYekanX', Tahoma, Arial, sans-serif;
  direction: rtl;
  width: 100%;
}

.jalali-datepicker-input {
  width: 100%;
  padding: 8px 12px;
  border: 1px solid #d1d5db;
  border-radius: 8px;
  font-family: inherit;
  font-size: 14px;
  background: #ffffff;
  color: #1e293b;
  transition: border-color 0.15s, box-shadow 0.15s;
  direction: ltr;
  text-align: left;
  box-sizing: border-box;
}

.jalali-datepicker-input:focus {
  outline: none;
  border-color: #1a73e8;
  box-shadow: 0 0 0 3px rgba(26, 115, 232, 0.15);
}

.jalali-datepicker-input:disabled {
  background: #f3f4f6;
  cursor: not-allowed;
}

.jalali-datepicker-input::placeholder {
  color: #9ca3af;
}

.jalali-datepicker-popup {
  position: absolute;
  top: calc(100% + 4px);
  right: 0;
  z-index: 9999;
  background: #ffffff;
  border: 1px solid #e2e8f0;
  border-radius: 12px;
  box-shadow: 0 8px 30px rgba(0, 0, 0, 0.15), 0 2px 8px rgba(0, 0, 0, 0.05);
  padding: 16px 20px 20px 20px;
  width: 280px;
  direction: rtl;
  font-family: 'IRANYekanX', Tahoma, Arial, sans-serif;
}

.jalali-datetime-popup {
  width: 320px;
}

.jalali-datepicker-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 14px;
  padding-bottom: 10px;
  border-bottom: 1px solid #f0f0f0;
}

.jalali-datepicker-header .nav-btn {
  background: transparent;
  border: none;
  cursor: pointer;
  font-size: 18px;
  color: #555;
  padding: 4px 12px;
  border-radius: 8px;
  transition: background 0.15s, color 0.15s;
}

.jalali-datepicker-header .nav-btn:hover {
  background: #f0f4ff;
  color: #1a73e8;
}

.jalali-datepicker-header .month-year {
  font-size: 16px;
  font-weight: 500;
  color: #1e293b;
}

.jalali-datepicker-table {
  width: 100%;
  border-collapse: collapse;
  direction: rtl;
}

.jalali-datepicker-table th {
  text-align: center;
  padding: 6px 0;
  font-weight: 500;
  color: #94a3b8;
  font-size: 13px;
}

.jalali-datepicker-table td {
  text-align: center;
  padding: 6px 0;
  cursor: pointer;
  border-radius: 8px;
  font-size: 15px;
  font-weight: 400;
  color: #1e293b;
  transition: background 0.15s, color 0.15s, transform 0.1s;
}

.jalali-datepicker-table td:hover:not(.empty) {
  background: #e8f0fe;
  transform: scale(1.02);
}

.jalali-datepicker-table td.selected {
  background: #1a73e8;
  color: #ffffff;
  font-weight: 500;
}

.jalali-datepicker-table td.today {
  background: #e8f0fe;
  color: #1a73e8;
  font-weight: 500;
}

.jalali-datepicker-table td.today.selected {
  background: #1a73e8;
  color: #ffffff;
}

.jalali-datepicker-table td.empty {
  cursor: default;
  color: transparent;
}

.jalali-datepicker-footer {
  display: flex;
  justify-content: space-between;
  margin-top: 14px;
  padding-top: 12px;
  border-top: 1px solid #f0f0f0;
}

.jalali-datepicker-footer button {
  background: transparent;
  border: 1px solid #e2e8f0;
  padding: 6px 16px;
  border-radius: 8px;
  cursor: pointer;
  font-size: 13px;
  font-family: inherit;
  color: #475569;
  transition: background 0.15s, border-color 0.15s;
}

.jalali-datepicker-footer button:hover {
  background: #f8fafc;
  border-color: #cbd5e1;
}

.jalali-datepicker-footer .today-btn {
  background: #1a73e8;
  border-color: #1a73e8;
  color: #ffffff;
}

.jalali-datepicker-footer .today-btn:hover {
  background: #1557b0;
  border-color: #1557b0;
}

.jalali-datepicker-footer .close-btn {
  color: #64748b;
}

.jalali-datetime-time {
  display: flex;
  gap: 16px;
  justify-content: center;
  margin-top: 12px;
  padding-top: 12px;
  border-top: 1px solid #f0f0f0;
}

.jalali-datetime-time .time-selector {
  display: flex;
  align-items: center;
  gap: 6px;
}

.jalali-datetime-time .time-selector label {
  font-size: 13px;
  color: #475569;
}

.jalali-datetime-time .time-selector input {
  width: 50px;
  padding: 4px 6px;
  border: 1px solid #d1d5db;
  border-radius: 6px;
  text-align: center;
  font-family: inherit;
  font-size: 14px;
}

.jalali-datetime-time .time-selector input:focus {
  outline: none;
  border-color: #1a73e8;
  box-shadow: 0 0 0 2px rgba(26, 115, 232, 0.15);
}
'''

# ================================================================
# لیست فایل‌ها
# ================================================================
files = {
    'types/index.ts': TYPES_INDEX,
    'jalali.ts': JALALI_TS,
    'utils.ts': UTILS_TS,
    'ntp.ts': NTP_TS,
    'index.ts': INDEX_TS,
    'components/index.ts': COMPONENTS_INDEX,
    'components/JalaliDatePicker.tsx': JALALI_DATE_PICKER,
    'components/JalaliDateTimePicker.tsx': JALALI_DATETIME_PICKER,
    'hooks/index.ts': HOOKS_INDEX,
    'hooks/useJalali.ts': USE_JALALI,
    'styles/jalali-datepicker.css': CSS_FILE,
}

# ================================================================
# اجرای ساخت
# ================================================================
def main():
    print("=" * 60)
    print("  ساخت پکیج edra_jalalidate برای فرانت‌اند")
    print("  مسیر:", JALALI_DIR)
    print("=" * 60)

    # حذف پوشه قدیمی اگر وجود دارد
    if os.path.exists(JALALI_DIR):
        import shutil
        print(f"  ⚠️  حذف پوشه قدیمی: {JALALI_DIR}")
        shutil.rmtree(JALALI_DIR)

    # ایجاد پوشه‌ها
    os.makedirs(JALALI_DIR, exist_ok=True)
    os.makedirs(os.path.join(JALALI_DIR, 'types'), exist_ok=True)
    os.makedirs(os.path.join(JALALI_DIR, 'components'), exist_ok=True)
    os.makedirs(os.path.join(JALALI_DIR, 'hooks'), exist_ok=True)
    os.makedirs(os.path.join(JALALI_DIR, 'styles'), exist_ok=True)

    # ایجاد فایل‌ها
    for rel_path, content in files.items():
        full_path = os.path.join(JALALI_DIR, rel_path)
        with open(full_path, 'w', encoding='utf-8') as f:
            f.write(content)
        print(f"  ✅ {rel_path}")

    print("=" * 60)
    print("  ✅ پکیج edra_jalalidate با موفقیت ساخته شد!")
    print("  📁 مسیر:", JALALI_DIR)
    print("  🚀 حالا سرور Next.js را ریستارت کنید:")
    print("     cd frontend")
    print("     npm run dev   (یا yarn dev)")
    print("=" * 60)

if __name__ == "__main__":
    main()
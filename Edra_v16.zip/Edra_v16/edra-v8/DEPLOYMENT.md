# راهنمای استقرار EDRA v4/v8 (Production)

این راهنما مراحل راه‌اندازی واقعی پروژه را قدم‌به‌قدم توضیح می‌دهد.
پیش‌نیاز: سرور لینوکسی (Ubuntu/Debian) با Docker و Docker Compose.

> **نکته v6/v7 — مهم**: اجرای compose باید با `--env-file` باشد تا
> interpolation خود Compose (DB_NAME/DB_USER/DB_PASSWORD برای PostgreSQL)
> از همان env واقعی backend بخواند — در غیر این صورت mismatch رمز دیتابیس
> رخ می‌دهد. fallbackهای ضعیف حذف شده‌اند و بدون این متغیرها Compose خطا
> می‌دهد (P1). همچنین متغیرهای build-time فرانت‌اند
> `FRONTEND_PUBLIC_API_URL` / `FRONTEND_PUBLIC_WS_URL` (دامنه عمومی) را
> در env ست کنید (HIGH-25).

---

## ۱) پیش‌نیازها

```bash
# نصب Docker + Compose
curl -fsSL https://get.docker.com | sh
sudo usermod -aG docker $USER   # خروج/ورود مجدد
docker compose version
```

## ۲) آماده‌سازی فایل محیط

```bash
cd backend/backend
cp .env.production.example .env.production
# ✏️ سپس همه مقادیر REPLACE_* را با مقادیر واقعی جایگزین کنید:
#   - SECRET_KEY      : python -c "from django.core.management.utils import get_random_secret_key; print(get_random_secret_key())"
#   - DB_PASSWORD     : یک رمز قوی برای PostgreSQL
#   - SMS_API_KEY     : کلید واقعی Kavenegar
#   - ZARINPAL_MERCHANT_ID : شناسه درگاه (یا ZARINPAL_SANDBOX=true برای تست)
#   - ALLOWED_HOSTS / CORS_ALLOWED_ORIGINS / SITE_URL / FRONTEND_URL : دامنه واقعی
```

> ⚠️ **نکته امنیتی**: بدون `SMS_PROVIDER`+`SMS_API_KEY` معتبر، `DEBUG=true`،
> `SECRET_KEY` placeholder، CORS خالی یا `DB_ENGINE=sqlite`، بک‌اند **عمداً
> بالا نمی‌آید** (fail-closed — P0-11/P0-12).

## ۳) استقرار با docker-compose

```bash
cd <root پروژه>   # جایی که docker-compose.yml است
# EDRA v6 — P1: --env-file الزامی است (interpolation خود Compose)
docker compose --env-file backend/backend/.env.production up -d --build
docker compose ps          # بررسی: backend/celery-worker/celery-beat سالم
curl http://localhost:8000/health/ready/    # انتظار: {"status": "ok"}
```

سرویس‌ها: `postgres` + `redis` + `backend` (Uvicorn/ASGI) +
`celery-worker` + `celery-beat` + `frontend` (Next.js) با healthcheck و
restart خودکار.

## ۴) مهاجرت‌ها و داده اولیه

```bash
docker compose exec backend python manage.py migrate
docker compose exec backend python manage.py createsuperuser
# داده‌های اولیه (اختیاری اما توصیه‌شده):
docker compose exec backend python manage.py seed_notification_templates
docker compose exec backend python manage.py setup_groups      # Admin/Expert/Support
docker compose exec backend python manage.py init_checklist
docker compose exec backend python manage.py seed_demo_data   # فقط تست
```

## ۵) Nginx + HTTPS

1. دامنه را به IP سرور DNS کنید.
2. کپی نمونه: `cp deploy/nginx.conf /etc/nginx/sites-available/edra`
3. نام‌های `server_name` و مسیر cert را اصلاح کنید.
4. گواهی (در نمونه، دامنه API هم گنجانده شده — در صورت same-origin حذف کنید):
   `sudo certbot --nginx -d edra-inspect.ir -d www.edra-inspect.ir -d api.edra-inspect.ir`
5. `sudo ln -s /etc/nginx/sites-available/edra /etc/nginx/sites-enabled/ && sudo nginx -t && sudo systemctl reload nginx`

> `location /media/ { deny all; }` از قبل در نمونه موجود است — فایل‌های حساس
> فقط از endpoint های دارای احراز هویت در دسترس‌اند (P0-09).

## ۶) پشتیبان‌گیری خودکار (P1-13)

```bash
chmod +x backend/backend/scripts/backup.sh
# تست دستی:
backend/backend/scripts/backup.sh backup
# کرون شبانه:
crontab -e
# 0 3 * * * cd /opt/edra && backend/backend/scripts/backup.sh backup >> /var/log/edra-backup.log 2>&1
```

بازیابی: `backend/backend/scripts/backup.sh restore backups/edra_XXXX.dump`

## ۶.۵) ردیابی خطا (اختیاری — Sentry) و لاگ JSON

1. پروژه در [sentry.io](https://sentry.io) بسازید و DSN بگیرید.
2. `SENTRY_DSN=...` را به `.env.production` اضافه کنید (نمونه در
   `.env.production.example`). بدون آن، هیچ‌چیز ارسال نمی‌شود (fail-open).
3. لاگ‌ها در Production به‌صورت **JSON ساختاریافته** (با `request_id`) به
   خروجی استاندارد و `logs/django.log` می‌روند — برای جمع‌آوری با ELK/Loki
   آماده‌اند.

## ۶.۶) متریک‌ها (اختیاری — Prometheus)

- `GET /metrics/` (فقط برای کاربران Admin) متریک‌های Django/DB/cache را
  به فرمت Prometheus می‌دهد.
- اسکرپ در prometheus.yml:
  ```yaml
  scrape_configs:
    - job_name: edra
      scheme: https
      metrics_path: /metrics
      basic_auth: { username: <admin-username>, password: <admin-password> }
      static_configs: [{ targets: ["api.edra-inspect.ir"] }]
  ```

## ۶.۷) Object Storage (اختیاری — S3/MinIO)

فایل‌های media (فیش، عکس چک‌لیست، PDF) را می‌توانید روی S3/MinIO ببرید:
متغیرهای `AWS_*` در `.env.production.example` را پر کنید. بدون تنظیم،
فایل‌ها روی دیسک محلی می‌مانند (fail-open). بعد از فعال‌سازی، streaming
فایل‌های حساس (payment_receipt و ...) را با کاربر واقعی تست کنید.

## ۶.۸) تست E2E (اختیاری — Playwright)

```bash
docker compose up -d                      # stack بالا
cd frontend/frontend
npx playwright install --with-deps chromium
BASE_URL=https://edra-inspect.ir npm run e2e   # یا localhost:3000
```

## ۶.۹) Release Gate (EDRA v8 — SEC-03/CI)

مشاهده‌ی `.github/workflows/ci.yml` — روی هر Push/PR اینها اجرا می‌شود:
backend (`check --deploy`، `makemigrations --check`، pytest روی PostgreSQL)
و frontend (`npm ci`، lint، typecheck، test، build standalone).

اسکن دستی dependency قبل از Release:

```bash
pip install pip-audit
backend/backend/scripts/security-scan.sh   # pip-audit + npm audit + trivy
```

> نکته `check --deploy`: هشدارهای SECURE_COOKIE/HSTS در `edra.settings`
> (پایه/توسعه) طبیعی است؛ `edra.settings_production` همه را در startup
> enforce می‌کند. برای اجرای real check روی production:
> `DJANGO_SETTINGS_MODULE=edra.settings_production <env های کامل> python manage.py check --deploy`

## ۶.۱۰) معماری Deployment (EDRA v8 — OPS-02)

- `migrate` و `collectstatic` در **job یکبارمصرف** (`docker compose run --rm migrate`)
  اجرا می‌شوند؛ backend فقط `uvicorn` است (ایمن برای چند Replica).
- Frontend با **خروجی standalone** ساخته می‌شود (بدون node_modules کامل).
- دستور روزمره: `docker compose --env-file backend/backend/.env.production up -d`

## ۷) بررسی نهایی قبل از Go-live

- [ ] `/health/ready/` → 200 و `{"status": "ok"}`
- [ ] لاگین پیامکی واقعی (کد از Kavenegar می‌رسد)
- [ ] پرداخت زرین‌پال در حالت sandbox تست شد
- [ ] اعلان بلادرنگ WebSocket (گروه کاربر) کار می‌کند
- [ ] دانلود PDF گزارش از سمت مشتری/کارشناس OK
- [ ] ایمپورت اکسل چک‌لیست از پنل ادمین OK
- [ ] خروجی `docker compose ps` همه `healthy`
- [ ] cron پشتیبان‌گیری ثبت و تست شد

---

## عیب‌یابی سریع

| مشکل | راه‌حل |
|---|---|
| backend بالا نمی‌آید | پیام ImproperlyConfigured را بخوانید؛ معمولاً env ناقص است (P0-12) |
| پیامک نمی‌رسد | `SMS_API_KEY` و `SMS_PROVIDER` را چک کنید؛ `SMS_FAIL_CLOSED=true` یعنی بدون کلید، ارسال fail می‌شود (عمدی) |
| WebSocket وصل نمی‌شود | nginx باید `Upgrade`/`Connection` را پاس دهد (نمونه آماده است) |
| 403 در مدیریتی‌ها | کاربر باید `is_staff` یا عضو گروه `Admin` باشد (HIGH-21) |
| فیش بانکی نمایش داده نمی‌شود | فقط صاحب درخواست/ادمین دسترسی دارد (P0-09) — با کاربر صحیح تست کنید |

# این فایل برای بارگذاری ادمین‌ها کافی است
from .common import to_jalali, get_customer_info, dashboard_callback
from .user import CustomUserAdmin, UserProfileInline, OTPCodeAdmin
from .equipment import EquipmentTypeAdmin, EquipmentParameterInline
from .location import CityMultiplierAdmin, OrganizationAdmin, ProjectAdmin
from .request import InspectionRequestAdmin, DiscountCodeAdmin  # ✅ اضافه شد
from .finance import PaymentAdmin, InvoiceAdmin, CreditTransactionAdmin, PaymentMethodAdmin, UserCreditAdmin
from .checklist import ChecklistTemplateAdmin, ChecklistItemAdmin, InspectionReportAdmin, ReportVerificationAdmin
from .logs import AuditLogAdmin, ErrorLogAdmin, SequenceCounterAdmin
# NotificationTemplateAdmin/NotificationLogAdmin به notifications/admin.py
# منتقل شدند (همراه با حذف مدل‌های تکراری از core)

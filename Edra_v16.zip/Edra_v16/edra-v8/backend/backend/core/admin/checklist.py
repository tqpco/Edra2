from django.contrib import admin
from django.urls import reverse
from django.utils.html import format_html
from ..models import ChecklistTemplate, ChecklistItem, InspectionReport, ChecklistPhoto, ReportVerification
from .common import to_jalali, get_customer_info
from jalali_date.admin import ModelAdminJalaliMixin


class ChecklistPhotoInline(admin.TabularInline):
    model = ChecklistPhoto
    extra = 0
    fields = ('checklist_item', 'image_preview', 'caption', 'created_at')
    readonly_fields = ('image_preview', 'created_at')

    def image_preview(self, obj):
        if obj.image:
            return format_html(
                '<a href="{0}" target="_blank"><img src="{0}" style="max-height:80px;border-radius:4px;" /></a>',
                obj.image.url)
        return "—"
    image_preview.short_description = "پیش‌نمایش"


@admin.register(ChecklistTemplate)
class ChecklistTemplateAdmin(admin.ModelAdmin):
    list_display = ('name', 'equipment_type', 'version', 'is_active')
    list_filter = ('is_active', 'equipment_type')
    search_fields = ('name',)


@admin.register(ChecklistItem)
class ChecklistItemAdmin(admin.ModelAdmin):
    list_display = ('title', 'category', 'checklist_template')
    list_filter = ('category',)
    search_fields = ('title',)


@admin.register(InspectionReport)
class InspectionReportAdmin(admin.ModelAdmin):
    list_display = (
        'report_number',
        'inspection_request_link',
        'customer_name_phone',
        'overall_result',
        'signed_at')
    list_filter = ('overall_result',)
    search_fields = (
        'report_number',
        'inspection_request__title',
        'inspection_request__request_number',
        'inspection_request__customer__username',
        'inspection_request__customer__profile__phone')
    inlines = [ChecklistPhotoInline]

    def get_queryset(self, request):
        qs = super().get_queryset(request)
        return qs.select_related('inspection_request__customer__profile')

    def inspection_request_link(self, obj):
        url = reverse(
            'admin:core_inspectionrequest_change', args=[
                obj.inspection_request.id])
        return format_html('<a href="{}">درخواست #{}</a>',
                           url, obj.inspection_request.id)
    inspection_request_link.short_description = "درخواست"

    def customer_name_phone(self, obj):
        return get_customer_info(obj)
    customer_name_phone.short_description = "مشتری (نام و شماره)"


@admin.register(ReportVerification)
class ReportVerificationAdmin(admin.ModelAdmin):
    list_display = (
        'report',
        'verification_code',
        'customer_name_phone',
        'view_count')
    search_fields = (
        'verification_code',
        'report__report_number',
        'report__inspection_request__title',
        'report__inspection_request__request_number',
        'report__inspection_request__customer__username',
        'report__inspection_request__customer__profile__phone')
    readonly_fields = ('customer_name_phone',)

    def get_queryset(self, request):
        qs = super().get_queryset(request)
        return qs.select_related(
            'report__inspection_request__customer__profile')

    def customer_name_phone(self, obj):
        return get_customer_info(obj.report) if obj.report else "—"
    customer_name_phone.short_description = "مشتری (نام و شماره)"

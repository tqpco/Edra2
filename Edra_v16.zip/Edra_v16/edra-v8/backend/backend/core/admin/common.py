from django.utils.html import format_html, mark_safe
from django.urls import reverse
from django.utils import timezone
import jdatetime


def to_jalali(dt):
    """تبدیل datetime به تاریخ شمسی"""
    if not dt:
        return "—"
    try:
        if timezone.is_aware(dt):
            dt = timezone.localtime(dt)
        else:
            dt = timezone.make_aware(dt, timezone.get_current_timezone())
        jalali = jdatetime.datetime.fromgregorian(datetime=dt)
        return jalali.strftime("%Y/%m/%d - %H:%M")
    except Exception as e:
        return str(dt)


def get_customer_info(obj):
    """دریافت اطلاعات مشتری (نام کامل و شماره موبایل)"""
    if hasattr(obj, 'inspection_request') and obj.inspection_request:
        customer = obj.inspection_request.customer
    elif hasattr(obj, 'user'):
        customer = obj.user
    else:
        return "—"

    if not customer:
        return "—"

    # ✅ جلوگیری از AttributeError در صورت عدم وجود پروفایل
    try:
        phone = customer.profile.phone if hasattr(
            customer, 'profile') and customer.profile else "—"
    except AttributeError:
        phone = "—"

    full_name = customer.get_full_name() or customer.username
    return f"{full_name} - {phone}"


def dashboard_callback(request):
    from django.shortcuts import render
    from ..models import InspectionRequest, Payment, User, InspectionReport
    from django.db.models import Count
    context = {
        'title': 'داشبورد مدیریت',
        'total_requests': InspectionRequest.objects.count(),
        'total_payments': Payment.objects.count(),
        'total_users': User.objects.count(),
        'total_reports': InspectionReport.objects.count(),
        'pending_requests': InspectionRequest.objects.filter(status='pending_payment').count(),
        'recent_requests': InspectionRequest.objects.order_by('-created_at')[:5],
    }
    return render(request, 'admin/dashboard.html', context)

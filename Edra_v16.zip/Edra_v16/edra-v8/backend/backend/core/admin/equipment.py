from django.contrib import admin
from ..models import EquipmentType, EquipmentParameter
from .common import to_jalali


class EquipmentParameterInline(admin.TabularInline):
    model = EquipmentParameter
    extra = 1
    fields = ('name', 'label', 'field_type', 'options', 'required', 'order')
    ordering = ('order',)


@admin.register(EquipmentType)
class EquipmentTypeAdmin(admin.ModelAdmin):
    list_display = (
        'code',
        'name_fa',
        'supports_install_state',
        'install_state_required')
    list_filter = ('supports_install_state',)
    search_fields = ('code', 'name_fa')
    inlines = [EquipmentParameterInline]
    readonly_fields = ('param_schema',)
    fieldsets = (
        ('اطلاعات پایه', {'fields': ('code', 'name_fa')}),
        ('وضعیت نصب', {'fields': ('supports_install_state', 'install_state_required')}),
        ('پارامترها', {'fields': ('param_schema',)}),
    )

    def save_related(self, request, form, formsets, change):
        super().save_related(request, form, formsets, change)
        obj = form.instance
        if hasattr(obj, 'parameters') and obj.parameters.exists():
            schema = [param.to_json_schema()
                      for param in obj.parameters.all().order_by('order')]
            obj.param_schema = schema
            obj.save(update_fields=['param_schema'])

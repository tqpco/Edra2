from django.contrib import admin
from django.utils.html import format_html
from django.utils import timezone
from django.contrib import messages
from ..models import AuditLog, ErrorLog, SequenceCounter


@admin.register(AuditLog)
class AuditLogAdmin(admin.ModelAdmin):
    list_display = ('user', 'action', 'object_id', 'timestamp')
    list_filter = ('action',)
    search_fields = ('user__username',)


@admin.register(SequenceCounter)
class SequenceCounterAdmin(admin.ModelAdmin):
    list_display = ('key', 'value')
    search_fields = ('key',)


@admin.register(ErrorLog)
class ErrorLogAdmin(admin.ModelAdmin):
    list_display = (
        'error_id',
        'severity_display',
        'error_type',
        'status_code',
        'user',
        'timestamp',
        'resolved')
    list_filter = ('severity', 'status_code', 'resolved', 'timestamp')
    search_fields = (
        'error_id',
        'error_type',
        'error_message',
        'path',
        'user__username')
    readonly_fields = (
        'error_id',
        'timestamp',
        'user',
        'path',
        'method',
        'status_code',
        'error_type',
        'error_message',
        'traceback',
        'request_data',
        'user_agent',
        'ip_address')
    date_hierarchy = 'timestamp'
    actions = ['mark_as_resolved']

    fieldsets = (
        ('اطلاعات خطا', {
            'fields': (
                'error_id', 'severity', 'timestamp', 'status_code', 'error_type')}), ('کاربر و درخواست', {
                    'fields': (
                        'user', 'path', 'method', 'ip_address', 'user_agent')}), ('جزئیات خطا', {
                            'fields': (
                                'error_message', 'traceback', 'request_data')}), ('رفع خطا', {
                                    'fields': (
                                        'resolved', 'resolved_at', 'resolved_by', 'resolution_note')}), )

    def severity_display(self, obj):
        colors = {
            'debug': 'gray',
            'info': 'blue',
            'warning': 'orange',
            'error': 'red',
            'critical': 'darkred'}
        return format_html(
            '<span style="color: {}; font-weight: bold;">{}</span>',
            colors.get(
                obj.severity,
                'black'),
            obj.get_severity_display())
    severity_display.short_description = 'شدت'

    @admin.action(description='علامت‌گذاری به عنوان برطرف‌شده')
    def mark_as_resolved(self, request, queryset):
        updated = queryset.update(
            resolved=True,
            resolved_at=timezone.now(),
            resolved_by=request.user)
        self.message_user(
            request,
            f'{updated} خطا به عنوان برطرف‌شده علامت‌گذاری شد.')

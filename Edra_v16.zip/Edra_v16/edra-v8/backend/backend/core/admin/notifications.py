# مدل‌های NotificationTemplate/NotificationLog از core حذف شدند (تکراری با
# اپ notifications بودند). ثبت ادمین آن‌ها اکنون در notifications/admin.py
# انجام می‌شود - همان‌جایی که لینک‌های سایدبار Unfold (/admin/notifications/...)
# به آن اشاره می‌کنند.

from django.contrib import admin
from django.contrib.auth.models import User, Group
from jalali_date.admin import ModelAdminJalaliMixin
from ..models import UserProfile, OTPCode
from .common import to_jalali


class UserProfileInline(admin.StackedInline):
    model = UserProfile
    can_delete = False
    verbose_name = 'پروفایل'
    verbose_name_plural = 'پروفایل'
    # ✅ اضافه کردن فیلدهای جدید
    fields = ('phone', 'registration_number', 'company_name', 'projects')
    # ✅ استفاده از ویجت مناسب برای انتخاب چندین پروژه
    filter_horizontal = ('projects',)


class CustomUserAdmin(admin.ModelAdmin):
    list_display = (
        'username',
        'email',
        'first_name',
        'last_name',
        'phone_display',
        'is_staff')
    list_filter = ('is_staff', 'is_superuser', 'is_active')
    search_fields = (
        'username',
        'email',
        'first_name',
        'last_name',
        'profile__phone')
    inlines = [UserProfileInline]
    readonly_fields = ('phone_display',)

    def phone_display(self, obj):
        if hasattr(obj, 'profile') and obj.profile:
            return obj.profile.phone
        return "—"
    phone_display.short_description = "شماره موبایل"


@admin.register(OTPCode)
class OTPCodeAdmin(ModelAdminJalaliMixin, admin.ModelAdmin):
    # EDRA v6 — P1: کد OTP از list/form Admin حذف شد (credential افشا نشود)
    list_display = ('phone', 'created_at_display', 'is_used', 'attempts')
    list_filter = ('is_used',)
    search_fields = ('phone',)
    # از فرم: code و is_used و attempts فقط خواندنی (کد قابل دیدن/تغییر نیست)
    readonly_fields = ('phone', 'code', 'is_used', 'attempts', 'created_at')
    list_per_page = 50

    def created_at_display(self, obj):
        return to_jalali(obj.created_at)
    created_at_display.short_description = "تاریخ ایجاد"


# ثبت کاربران و گروه‌ها
try:
    admin.site.unregister(User)
except Exception as e:
    pass
try:
    admin.site.unregister(Group)
except Exception as e:
    pass

admin.site.register(User, CustomUserAdmin)


@admin.register(Group)
class GroupAdmin(admin.ModelAdmin):
    list_display = ('name',)
    search_fields = ('name',)

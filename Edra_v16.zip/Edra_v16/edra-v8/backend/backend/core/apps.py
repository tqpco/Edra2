# ============================================================
# ۴. core/apps.py (ثبت سیگنال‌ها)
# مسیر: backend/core/apps.py
# ============================================================
from django.apps import AppConfig


class CoreConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'core'
    verbose_name = 'مدیریت'

    def ready(self):
        import core.signals  # ثبت سیگنال‌ها

        # (بقیه کدهای قبلی برای ترتیب منوها - در صورت نیاز)
        from django.contrib import admin
        original_get_app_list = admin.site.get_app_list

        def get_app_list(self, request, app_label=None):
            app_list = original_get_app_list(request, app_label)
            app_order = [
                'core',
                'pricing',
                'inspections',
                'public',
                'notifications',
                'support',
                'auth']
            ordered = []
            for name in app_order:
                for app in app_list:
                    if app.get('app_label') == name:
                        ordered.append(app)
                        break
            for app in app_list:
                if app not in ordered:
                    ordered.append(app)
            for app in ordered:
                models = app.get('models', [])
                if app.get('app_label') == 'core':
                    order = {
                        'EquipmentType': 1,
                        'CityMultiplier': 3,
                        'DiscountCode': 4,
                        'InspectionRequest': 5,
                        'Payment': 6,
                        'Invoice': 7,
                        'UserCredit': 8,
                        'CreditTransaction': 9,
                        'ChecklistTemplate': 10,
                        'ChecklistItem': 11,
                        'InspectionReport': 12,
                        'ReportVerification': 13,
                        'Organization': 14,
                        'Project': 15,
                        'PaymentMethod': 16,
                        'AuditLog': 17,
                        'OTPCode': 18,
                        'SequenceCounter': 19}
                elif app.get('app_label') == 'pricing':
                    order = {}
                elif app.get('app_label') == 'inspections':
                    order = {
                        'InspectionRequest': 1,
                        'InspectionReport': 2,
                        'ChecklistTemplate': 3,
                        'ChecklistItem': 4}
                elif app.get('app_label') == 'auth':
                    order = {'User': 1, 'Group': 2}
                else:
                    order = {}
                if order:
                    models.sort(
                        key=lambda m: order.get(
                            m.get(
                                'object_name',
                                ''),
                            999))
                    app['models'] = models
            return ordered

        admin.site.get_app_list = get_app_list.__get__(
            admin.site, type(admin.site))

# core/exceptions.py
"""
قرارداد خطای یکسان API (Phase 2 ممیزی):

هر پاسخ خطا شامل دو کلید است:
  error  → پیام انسانی قابل نمایش (همیشه موجود)
  detail → ساختار اصلی خطا (برای سازگاری و جزئیات فیلدها)

نکته: به این ساختار افزوده می‌شود، نه جایگزین؛ فرانت‌اندهایی که از
`detail` می‌خوانند همچنان کار می‌کنند.
"""
from rest_framework.views import exception_handler as drf_exception_handler

# نگاشت نوع خطا به کد ماشینی (P1 — گزارش V3 بند ۳۹)
_ERROR_CODES = {
    'NotFound': 'NOT_FOUND',
    'Http404': 'NOT_FOUND',
    'PermissionDenied': 'FORBIDDEN',
    'NotAuthenticated': 'UNAUTHENTICATED',
    'ValidationError': 'VALIDATION_ERROR',
    'Throttled': 'RATE_LIMITED',
    'MethodNotAllowed': 'METHOD_NOT_ALLOWED',
    'AuthenticationFailed': 'AUTH_FAILED',
    'ParseError': 'BAD_REQUEST',
}


def api_exception_handler(exc, context):
    response = drf_exception_handler(exc, context)
    if response is None:
        return None

    data = response.data
    normalized = dict(data) if isinstance(data, dict) else {'detail': data}

    if 'error' not in normalized:
        if 'detail' in normalized:
            detail = normalized['detail']
            if isinstance(detail, (list, tuple)):
                normalized['error'] = str(detail[0]) if detail else 'خطای نامشخص'
            else:
                normalized['error'] = str(detail)
        else:
            # ValidationError با ساختار {field: [messages]}
            first = next(iter(normalized.values()), None)
            if isinstance(first, (list, tuple)):
                normalized['error'] = str(first[0]) if first else 'داده نامعتبر است.'
            elif first is not None:
                normalized['error'] = str(first)
            else:
                normalized['error'] = 'داده نامعتبر است.'

    # کد ماشینی برای فرانت‌اند (کنترل‌پذیر)
    normalized.setdefault(
        'code', _ERROR_CODES.get(type(exc).__name__, 'ERROR'))

    response.data = normalized
    return response

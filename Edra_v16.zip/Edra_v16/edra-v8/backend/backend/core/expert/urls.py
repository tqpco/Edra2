# core/expert/urls.py
from django.urls import path
from .views import (
    ExpertDashboardView,
    ExpertTaskListView,
    ExpertTaskDetailView,
    ExpertStartInspectionView,
    ExpertSubmitChecklistView,
    ExpertGenerateReportView,
    ExpertHistoryView,
    ExpertProfileView,
    ExpertChangePasswordView,
    SuggestExpertsForRequestView,
)

app_name = 'expert'

urlpatterns = [
    path(
        'dashboard/',
        ExpertDashboardView.as_view(),
        name='dashboard'),
    path(
        'tasks/',
        ExpertTaskListView.as_view(),
        name='tasks'),
    path(
        'tasks/<int:task_id>/',
        ExpertTaskDetailView.as_view(),
        name='task_detail'),
    path(
        'tasks/<int:task_id>/start/',
        ExpertStartInspectionView.as_view(),
        name='start_inspection'),
    path(
        'submit-checklist/',
        ExpertSubmitChecklistView.as_view(),
        name='submit_checklist'),
    path(
        'report/<int:report_id>/pdf/',
        ExpertGenerateReportView.as_view(),
        name='report_pdf'),
    path(
        'history/',
        ExpertHistoryView.as_view(),
        name='history'),
    path(
        'profile/',
        ExpertProfileView.as_view(),
        name='profile'),
    path(
        'profile/change-password/',
        ExpertChangePasswordView.as_view(),
        name='change_password'),
    path(
        'suggest/<int:request_id>/',
        SuggestExpertsForRequestView.as_view(),
        name='suggest_experts'),
]

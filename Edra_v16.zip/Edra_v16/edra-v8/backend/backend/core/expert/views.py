# core/expert/views.py
from rest_framework import generics, status, serializers
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated
from core.permissions import IsAdminUserOrGroup
from rest_framework.parsers import MultiPartParser, FormParser
from django.contrib.auth import get_user_model
from django.db import transaction
from django.db.models import Count, Q
from django.db.models.functions import TruncMonth
from django.utils import timezone
from django.template.loader import render_to_string
from weasyprint import HTML
from django.http import HttpResponse
from decimal import Decimal, InvalidOperation
import logging
import re

from ..models import (
    InspectionRequest, InspectionReport, ChecklistTemplate, ChecklistItem,
    ChecklistPhoto, SequenceCounter
)
from ..utils.geo import haversine_distance_meters
from ..serializers import InspectionReportSerializer, UserSerializer

User = get_user_model()
logger = logging.getLogger(__name__)

# ============================================================
# سریالایزرها
# ============================================================


class ExpertTaskSerializer(serializers.ModelSerializer):
    customer_name = serializers.SerializerMethodField()
    customer_phone = serializers.SerializerMethodField()
    equipment_name = serializers.SerializerMethodField()
    has_report = serializers.SerializerMethodField()
    report_id = serializers.SerializerMethodField()
    scheduled_at_jalali = serializers.SerializerMethodField()

    class Meta:
        model = InspectionRequest
        fields = (
            'id',
            'request_number',
            'customer_name',
            'customer_phone',
            'equipment_name',
            'brand_model',
            'manufacture_year',
            'params',
            'install_state',
            'service_type',
            'city',
            'address',
            'address_lat',
            'address_lng',
            'scheduled_at_jalali',
            'status',
            'final_price',
            'created_at',
            'has_report',
            'report_id')

    def get_scheduled_at_jalali(self, obj):
        from .utils.date_utils import to_jalali
        return to_jalali(obj.scheduled_at) if obj.scheduled_at else None

    def get_customer_name(self, obj):
        return obj.customer.get_full_name() or obj.customer.username

    def get_customer_phone(self, obj):
        return obj.customer.username

    def get_equipment_name(self, obj):
        return obj.equipment_type.name_fa if obj.equipment_type else "نامشخص"

    def get_has_report(self, obj):
        return hasattr(obj, 'report')

    def get_report_id(self, obj):
        return obj.report.id if hasattr(obj, 'report') else None

# ============================================================
# ویوها
# ============================================================


class ExpertDashboardView(generics.GenericAPIView):
    permission_classes = [IsAuthenticated]

    def get(self, request):
        user = request.user
        if not user.is_staff and not user.groups.filter(
                name='Expert').exists():
            return Response({'error': 'دسترسی غیرمجاز'}, status=403)

        total = InspectionRequest.objects.filter(assigned_expert=user).count()
        pending = InspectionRequest.objects.filter(
            assigned_expert=user, status='scheduled').count()
        in_progress = InspectionRequest.objects.filter(
            assigned_expert=user, status='in_progress').count()
        completed = InspectionRequest.objects.filter(
            assigned_expert=user, status='completed').count()
        reports_count = InspectionReport.objects.filter(signed_by=user).count()

        recent = InspectionRequest.objects.filter(
            assigned_expert=user).order_by('-created_at')[:5]
        recent_data = ExpertTaskSerializer(recent, many=True).data

        return Response({'statistics': {'total_assigned': total,
                                        'pending': pending,
                                        'in_progress': in_progress,
                                        'completed': completed,
                                        'reports_count': reports_count},
                         'recent_tasks': recent_data,
                         'user': {'id': user.id,
                                  'username': user.username,
                                  'full_name': user.get_full_name() or user.username}})


class ExpertTaskListView(generics.GenericAPIView):
    permission_classes = [IsAuthenticated]

    def get(self, request):
        user = request.user
        if not user.is_staff and not user.groups.filter(
                name='Expert').exists():
            return Response({'error': 'دسترسی غیرمجاز'}, status=403)

        status_filter = request.query_params.get('status', '')
        search = request.query_params.get('search', '')

        queryset = InspectionRequest.objects.filter(
            assigned_expert=user).select_related(
            'customer', 'equipment_type')
        if status_filter:
            queryset = queryset.filter(status=status_filter)
        if search:
            queryset = queryset.filter(
                Q(customer__username__icontains=search) | Q(brand_model__icontains=search))

        queryset = queryset.order_by('-created_at')
        serializer = ExpertTaskSerializer(queryset, many=True)
        return Response({'tasks': serializer.data, 'count': queryset.count()})


class ExpertTaskDetailView(generics.GenericAPIView):
    permission_classes = [IsAuthenticated]

    def get(self, request, task_id):
        user = request.user
        try:
            task = InspectionRequest.objects.get(
                id=task_id, assigned_expert=user)
        except InspectionRequest.DoesNotExist:
            return Response({'error': 'وظیفه یافت نشد'}, status=404)

        template = ChecklistTemplate.objects.filter(
            equipment_type=task.equipment_type,
            is_active=True).order_by('-version').first()
        existing_report = InspectionReportSerializer(
            task.report).data if hasattr(
            task, 'report') else None

        checklist_data = None
        if template:
            items = ChecklistItem.objects.filter(
                checklist_template=template,
                is_active=True).order_by('order')
            checklist_data = {'id': template.id,
                              'name': template.name,
                              'version': template.version,
                              'items': [{'id': i.id,
                                         'category': i.category,
                                         'title': i.title,
                                         'description': i.description,
                                         'requires_photo': i.requires_photo,
                                         'requires_note': i.requires_note} for i in items]}

        return Response({
            'task': ExpertTaskSerializer(task).data,
            'checklist_template': checklist_data,
            'existing_report': existing_report
        })


class ExpertStartInspectionView(generics.GenericAPIView):
    permission_classes = [IsAuthenticated]

    def post(self, request, task_id):
        user = request.user
        try:
            task = InspectionRequest.objects.get(
                id=task_id, assigned_expert=user)
        except InspectionRequest.DoesNotExist:
            return Response({'error': 'وظیفه یافت نشد'}, status=404)

        if task.status not in ['scheduled', 'paid']:
            return Response(
                {'error': f'وضعیت {task.status} اجازه شروع را نمی‌دهد'}, status=400)

        task.status = 'in_progress'
        task.save()
        return Response({'success': True, 'status': task.status})


class ExpertSubmitChecklistView(generics.GenericAPIView):
    permission_classes = [IsAuthenticated]
    parser_classes = [MultiPartParser, FormParser]

    def post(self, request):
        """
        EDRA v5 — ثبت چک‌لیست از سرویس یکپارچه report_service.submit_checklist:
          - همه آیتم‌های قالب الزامی‌اند (foreign/duplicate/missing رد می‌شود)
          - result فقط pass/fail/na
          - requires_note/requires_photo سمت سرور enforce می‌شود
          - overall_result سمت سرور محاسبه می‌شود
          - signed_by/signed_at هنگام submit خالی است (امضا مرحله جدا)
          - checklist_template_version snapshot می‌شود
        """
        from ..services.report_service import (
            submit_checklist, ChecklistSubmissionError)

        user = request.user
        task_id = request.data.get('request_id')
        results = request.data.get('results')
        if not task_id or results is None:
            return Response({'error': 'اطلاعات کامل نیست'}, status=400)

        try:
            task = InspectionRequest.objects.select_related(
                'equipment_type').get(id=task_id, assigned_expert=user)
        except InspectionRequest.DoesNotExist:
            return Response({'error': 'وظیفه یافت نشد'}, status=404)

        try:
            result = submit_checklist(
                user=user,
                task=task,
                results=results,
                overall_result=request.data.get('overall_result'),
                inspector_notes=request.data.get('inspector_notes', ''),
                request=request,
                gps_start_lat=request.data.get('gps_start_lat'),
                gps_start_lng=request.data.get('gps_start_lng'),
                gps_end_lat=request.data.get('gps_end_lat'),
                gps_end_lng=request.data.get('gps_end_lng'),
                inspection_started_at=request.data.get(
                    'inspection_started_at'),
            )
        except ChecklistSubmissionError as e:
            return Response({'error': str(e)}, status=e.status_code)
        except Exception as e:
            logger.error(f"submit_checklist error task={task_id}: {e}")
            return Response({'error': 'خطای داخلی در ثبت گزارش.'}, status=500)

        # P0-06 (EDRA v9): مسیر اصلی (ExpertSubmitChecklistView) قبلاً PDF
        # را queue نمی‌کرد و گزارش بدون pdf_file می‌ماند. حالا بعد از commit
        # تراکنش، تولید PDF حتماً در صف Celery قرار می‌گیرد.
        try:
            from django.db import transaction
            from ..tasks import generate_report_pdf_task
            transaction.on_commit(
                lambda: generate_report_pdf_task.delay(
                    result['report_id'], user.id))
        except Exception as pdf_q_error:
            logger.error(f"Error queueing report PDF: {pdf_q_error}")

        return Response({'success': True, **result})


class ExpertGenerateReportView(generics.GenericAPIView):
    permission_classes = [IsAuthenticated]

    def get(self, request, report_id):
        user = request.user
        try:
            report = InspectionReport.objects.get(id=report_id)
        except InspectionReport.DoesNotExist:
            return Response({'error': 'گزارش یافت نشد'}, status=404)

        if report.signed_by != user and report.inspection_request.assigned_expert != user:
            return Response({'error': 'دسترسی غیرمجاز'}, status=403)

        # تولید PDF ساده
        try:
            context = {
                'report': report,
                'request': report.inspection_request,
                'customer': report.inspection_request.customer,
                'equipment': report.inspection_request.equipment_type,
                'checklist_items': report.results if report.results else [],
                'overall_result': dict(
                    InspectionReport.OVERALL_RESULT_CHOICES).get(
                    report.overall_result,
                    report.overall_result)}
            html = render_to_string('expert_report_pdf.html', context)
            pdf = HTML(string=html, base_url=settings.BASE_DIR).write_pdf()
            response = HttpResponse(pdf, content_type='application/pdf')
            response['Content-Disposition'] = f'attachment; filename="گزارش_{
                report.report_number}.pdf"'
            return response
        except Exception as e:
            return Response({'error': str(e)}, status=500)


class ExpertHistoryView(generics.GenericAPIView):
    permission_classes = [IsAuthenticated]

    def get(self, request):
        user = request.user
        limit = int(request.query_params.get('limit', 20))
        offset = int(request.query_params.get('offset', 0))

        queryset = InspectionRequest.objects.filter(
            assigned_expert=user, status='completed').order_by('-created_at')
        total = queryset.count()
        items = queryset[offset:offset + limit]
        serializer = ExpertTaskSerializer(items, many=True)
        return Response({'history': serializer.data,
                        'total': total, 'limit': limit, 'offset': offset})


class ExpertProfileView(generics.GenericAPIView):
    permission_classes = [IsAuthenticated]

    def get(self, request):
        user = request.user
        return Response({'id': user.id,
                         'username': user.username,
                         'first_name': user.first_name,
                         'last_name': user.last_name,
                         'full_name': user.get_full_name() or user.username,
                         'email': user.email,
                         'date_joined': user.date_joined,
                         'last_login': user.last_login,
                         'groups': [g.name for g in user.groups.all()]})

    def put(self, request):
        user = request.user
        data = request.data
        if 'first_name' in data:
            user.first_name = data['first_name']
        if 'last_name' in data:
            user.last_name = data['last_name']
        if 'email' in data:
            user.email = data['email']
        user.save()
        return Response({'success': True})


class ExpertChangePasswordView(generics.GenericAPIView):
    permission_classes = [IsAuthenticated]

    def post(self, request):
        user = request.user
        old = request.data.get('old_password')
        new = request.data.get('new_password')
        confirm = request.data.get('confirm_password')

        if not old or not new or not confirm:
            return Response({'error': 'همه فیلدها پر شوند'}, status=400)
        if new != confirm:
            return Response({'error': 'رمزها مطابقت ندارند'}, status=400)
        if not user.check_password(old):
            return Response({'error': 'رمز فعلی اشتباه است'}, status=400)

        user.set_password(new)
        user.save()
        # P1-07 (EDRA v8): باطل کردن همه refresh token های قبلی
        from ..security import revoke_user_refresh_tokens
        revoke_user_refresh_tokens(user)
        return Response({'success': True})


class SuggestExpertsForRequestView(generics.GenericAPIView):
    """
    GET /api/expert/suggest/<request_id>/
    پیشنهاد هوشمند کارشناس برای یک درخواست خاص - برای کاهش دخالت دستی
    مدیر (طبق سرویس Assignment در سند معماری): بر اساس پوشش شهر، تجربه‌ی
    قبلی با همین نوع تجهیز، و بار کاری فعلی (کمتر = در دسترس‌تر) رتبه‌بندی
    می‌شود. تصمیم نهایی همچنان با مدیر است - این فقط لیست را برایش
    اولویت‌بندی می‌کند تا مجبور نباشد بین همه کارشناس‌ها دستی بگردد.
    """
    permission_classes = [IsAdminUserOrGroup]

    def get(self, request, request_id):
        try:
            target = InspectionRequest.objects.select_related(
                'equipment_type').get(id=request_id)
        except InspectionRequest.DoesNotExist:
            return Response({'error': 'درخواست یافت نشد'}, status=404)

        experts = User.objects.filter(
            groups__name='Expert', is_active=True
        ).select_related('profile').prefetch_related('profile__covered_cities')

        suggestions = []
        for exp in experts:
            profile = getattr(exp, 'profile', None)
            covers_city = False
            if profile:
                covers_city = profile.covered_cities.filter(
                    city=target.city).exists()

            active_workload = InspectionRequest.objects.filter(
                assigned_expert=exp,
                status__in=['assigned', 'scheduled', 'in_progress']
            ).count()

            equipment_experience = InspectionReport.objects.filter(
                inspection_request__assigned_expert=exp,
                inspection_request__equipment_type=target.equipment_type,
            ).count()

            # امتیازدهی ساده: پوشش شهر مهم‌ترین عامل، بعد تجربه، بعد بار کاری کمتر
            score = (
                (100 if covers_city else 0)
                + min(equipment_experience * 10, 50)
                - min(active_workload * 15, 60)
            )

            suggestions.append({
                'expert_id': exp.id,
                'name': exp.get_full_name() or exp.username,
                'phone': getattr(profile, 'phone', None),
                'covers_city': covers_city,
                'equipment_experience': equipment_experience,
                'active_workload': active_workload,
                'score': score,
            })

        suggestions.sort(key=lambda s: s['score'], reverse=True)

        return Response({
            'request_id': target.id,
            'request_number': target.request_number,
            'city': target.city,
            'equipment_type': target.equipment_type.name_fa if target.equipment_type else None,
            'suggestions': suggestions[:10],
        })

# core/filters.py
from django_filters import rest_framework as filters
from django_filters import FilterSet, DateFilter, CharFilter, NumberFilter, BooleanFilter
from django.contrib.auth import get_user_model
from .models import (
    InspectionRequest,
    Payment,
    Invoice,
    EquipmentType,
    Organization,
    Project,
    DiscountCode,
    InspectionReport,
)

User = get_user_model()


class InspectionRequestFilter(FilterSet):
    """فیلترهای پیشرفته برای درخواست‌های بازرسی"""
    status = CharFilter(lookup_expr='exact', label="وضعیت")
    city = CharFilter(lookup_expr='icontains', label="شهر")
    equipment_type = NumberFilter(
        field_name='equipment_type__id',
        label="نوع تجهیزات")
    brand_model = CharFilter(lookup_expr='icontains', label="برند/مدل")
    customer = NumberFilter(field_name='customer__id', label="شناسه مشتری")
    assigned_expert = NumberFilter(
        field_name='assigned_expert__id',
        label="شناسه کارشناس")
    created_at_after = DateFilter(
        field_name='created_at',
        lookup_expr='gte',
        label="از تاریخ")
    created_at_before = DateFilter(
        field_name='created_at',
        lookup_expr='lte',
        label="تا تاریخ")
    final_price_min = NumberFilter(
        field_name='final_price',
        lookup_expr='gte',
        label="حداقل قیمت")
    final_price_max = NumberFilter(
        field_name='final_price',
        lookup_expr='lte',
        label="حداکثر قیمت")

    class Meta:
        model = InspectionRequest
        fields = [
            'status', 'city', 'equipment_type', 'brand_model',
            'customer', 'assigned_expert', 'final_price_min', 'final_price_max'
        ]


class PaymentFilter(FilterSet):
    status = CharFilter(lookup_expr='exact', label="وضعیت")
    method = NumberFilter(field_name='method__id', label="روش پرداخت")
    amount_min = NumberFilter(
        field_name='amount',
        lookup_expr='gte',
        label="حداقل مبلغ")
    amount_max = NumberFilter(
        field_name='amount',
        lookup_expr='lte',
        label="حداکثر مبلغ")
    created_at_after = DateFilter(
        field_name='created_at',
        lookup_expr='gte',
        label="از تاریخ")
    created_at_before = DateFilter(
        field_name='created_at',
        lookup_expr='lte',
        label="تا تاریخ")

    class Meta:
        model = Payment
        fields = ['status', 'method', 'amount_min', 'amount_max']


class InvoiceFilter(FilterSet):
    is_paid = BooleanFilter(label="پرداخت شده")
    status = CharFilter(lookup_expr='exact', label="وضعیت")
    invoice_number = CharFilter(lookup_expr='icontains', label="شماره فاکتور")
    final_amount_min = NumberFilter(
        field_name='final_amount',
        lookup_expr='gte',
        label="حداقل مبلغ")
    final_amount_max = NumberFilter(
        field_name='final_amount',
        lookup_expr='lte',
        label="حداکثر مبلغ")

    class Meta:
        model = Invoice
        fields = ['is_paid', 'status', 'invoice_number']


class UserFilter(FilterSet):
    username = CharFilter(lookup_expr='icontains', label="نام کاربری")
    email = CharFilter(lookup_expr='icontains', label="ایمیل")
    is_active = BooleanFilter(label="فعال")
    is_staff = BooleanFilter(label="ادمین")
    # نکته: کاربران «مشتری» به هیچ Group ای اضافه نمی‌شوند (فقط Admin و
    # Expert گروه دارند؛ مشتری یعنی نه staff نه عضو گروه Expert) - پس
    # role=customer را جداگانه مدیریت می‌کنیم، نه با یک نام گروه که
    # اصلاً وجود ندارد.
    role = CharFilter(method='filter_by_role', label="نقش")

    def filter_by_role(self, queryset, name, value):
        value = (value or '').lower()
        if value == 'expert':
            return queryset.filter(groups__name='Expert')
        if value == 'admin':
            return queryset.filter(is_staff=True)
        if value == 'customer':
            return queryset.filter(
                is_staff=False).exclude(groups__name='Expert')
        return queryset

    class Meta:
        model = User
        fields = ['username', 'email', 'is_active', 'is_staff']


class EquipmentTypeFilter(FilterSet):
    name_fa = CharFilter(lookup_expr='icontains', label="نام")
    code = CharFilter(lookup_expr='icontains', label="کد")
    supports_install_state = BooleanFilter(label="پشتیبانی از وضعیت نصب")

    class Meta:
        model = EquipmentType
        fields = ['name_fa', 'code', 'supports_install_state']


class OrganizationFilter(FilterSet):
    name = CharFilter(lookup_expr='icontains', label="نام")
    code = CharFilter(lookup_expr='icontains', label="کد")

    class Meta:
        model = Organization
        fields = ['name', 'code']


class ProjectFilter(FilterSet):
    name = CharFilter(lookup_expr='icontains', label="نام")
    organization = NumberFilter(field_name='organization__id', label="سازمان")

    class Meta:
        model = Project
        fields = ['name', 'organization']


class DiscountCodeFilter(FilterSet):
    code = CharFilter(lookup_expr='icontains', label="کد")
    is_active = BooleanFilter(label="فعال")
    discount_type = CharFilter(lookup_expr='exact', label="نوع تخفیف")

    class Meta:
        model = DiscountCode
        fields = ['code', 'is_active', 'discount_type']


class InspectionReportFilter(FilterSet):
    report_number = CharFilter(lookup_expr='icontains', label="شماره گزارش")
    inspection_request = NumberFilter(
        field_name='inspection_request__id',
        label="درخواست")
    signed_by = NumberFilter(field_name='signed_by__id', label="امضاکننده")

    class Meta:
        model = InspectionReport
        fields = ['report_number', 'inspection_request', 'signed_by']

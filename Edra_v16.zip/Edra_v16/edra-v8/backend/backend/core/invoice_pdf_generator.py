# core/invoice_pdf_generator.py
import io
from django.template.loader import render_to_string
import os
from django.conf import settings
from weasyprint import HTML


def generate_invoice_pdf(invoice, inspection_request, customer, equipment):
    # ✅ استخراج اطلاعات شرکت و پروژه
    company_name = customer.profile.company_name if hasattr(
        customer, 'profile') and customer.profile and customer.profile.company_name else ""
    project_name = inspection_request.project.name if inspection_request.project else ""

    context = {
        'invoice': invoice,
        'request': inspection_request,
        'customer': customer,
        'equipment': equipment,
        'company_name': company_name,   # ✅ جدید
        'project_name': project_name,   # ✅ جدید
    }
    html_string = render_to_string('invoice_pdf.html', context)
    pdf_file = HTML(string=html_string, base_url=settings.BASE_DIR).write_pdf()
    return pdf_file

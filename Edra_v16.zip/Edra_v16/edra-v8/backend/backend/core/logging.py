# core/logging.py
"""
P1-10/P2: لاگ‌گیری ساختاریافته JSON برای Production.

- هر لاگ یک شیء JSON تک‌خطی است (پارسی/قابل خوراک برای ELK/Sentry/جمع‌آور).
- فیلد request_id از thread-local می‌آید که RequestIdMiddleware ست می‌کند،
  بنابراین همه لاگ‌های یک درخواست قابل دنبال کردن هستند.
- فیلدهای حساس (OTP، پسورد، body درخواست) عمداً لاگ نمی‌شوند.
"""
import json
import logging
import threading
from datetime import datetime, timezone

_local = threading.local()


def set_request_id(request_id: str) -> None:
    _local.request_id = request_id


def get_request_id() -> str | None:
    return getattr(_local, 'request_id', None)


class JsonFormatter(logging.Formatter):
    """تبدیل LogRecord به JSON تک‌خطی."""

    def format(self, record: logging.LogRecord) -> str:
        payload = {
            'timestamp': datetime.now(timezone.utc).isoformat(),
            'level': record.levelname,
            'logger': record.name,
            'module': record.module,
            'message': record.getMessage(),
            'request_id': get_request_id(),
        }
        if record.exc_info:
            payload['exception'] = self.formatException(record.exc_info)
        # فیلدهای اضافه‌شده با extra= (غیر از reserved) را هم اضافه کن
        for key, value in getattr(record, '__dict__', {}).items():
            if key not in payload and not key.startswith('_'):
                try:
                    json.dumps(value)  # مطمئن شو قابل سریال است
                    payload[key] = value
                except (TypeError, ValueError):
                    payload[key] = str(value)
        return json.dumps(payload, ensure_ascii=False, default=str)

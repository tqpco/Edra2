# core/management/commands/add_user_to_group.py
from django.core.management.base import BaseCommand
from django.contrib.auth.models import User, Group


class Command(BaseCommand):
    help = "اضافه کردن کاربر به گروه"

    def add_arguments(self, parser):
        parser.add_argument('username', type=str)
        parser.add_argument('groupname', type=str)

    def handle(self, *args, **options):
        username = options['username']
        groupname = options['groupname']
        try:
            user = User.objects.get(username=username)
        except User.DoesNotExist:
            self.stdout.write(
                self.style.ERROR(
                    f'❌ کاربر {username} یافت نشد.'))
            return
        try:
            group = Group.objects.get(name=groupname)
        except Group.DoesNotExist:
            self.stdout.write(
                self.style.ERROR(
                    f'❌ گروه {groupname} یافت نشد.'))
            return
        user.groups.add(group)
        user.save()
        self.stdout.write(
            self.style.SUCCESS(
                f'✅ کاربر {username} به گروه {groupname} اضافه شد.'))

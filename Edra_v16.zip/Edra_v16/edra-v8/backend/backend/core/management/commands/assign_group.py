# ============================================================
# ۶. core/management/commands/assign_group.py (دستور مدیریتی)
# مسیر: backend/core/management/commands/assign_group.py
# ============================================================
from django.core.management.base import BaseCommand
from django.contrib.auth.models import User, Group


class Command(BaseCommand):
    help = 'Assign a user to a group (Admin or Expert)'

    def add_arguments(self, parser):
        parser.add_argument('username', type=str, help='Username of the user')
        parser.add_argument(
            'group', type=str, choices=[
                'Admin', 'Expert'], help='Group name')

    def handle(self, *args, **options):
        username = options['username']
        group_name = options['group']
        try:
            user = User.objects.get(username=username)
        except User.DoesNotExist:
            self.stdout.write(
                self.style.ERROR(
                    f'User "{username}" not found.'))
            return
        try:
            group = Group.objects.get(name=group_name)
        except Group.DoesNotExist:
            self.stdout.write(
                self.style.ERROR(
                    f'Group "{group_name}" not found. Please run migrations first.'))
            return
        user.groups.add(group)
        self.stdout.write(
            self.style.SUCCESS(
                f'User "{username}" added to group "{group_name}".'))

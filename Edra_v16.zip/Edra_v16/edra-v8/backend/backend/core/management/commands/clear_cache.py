# core/management/commands/clear_cache.py
from django.core.management.base import BaseCommand
from django.core.cache import cache


class Command(BaseCommand):
    help = 'Clear all cached data'

    def handle(self, *args, **options):
        cache.clear()
        self.stdout.write(self.style.SUCCESS("✅ Cache cleared successfully!"))

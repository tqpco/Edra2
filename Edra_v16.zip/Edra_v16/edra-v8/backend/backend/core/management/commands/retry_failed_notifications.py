# backend/core/management/commands/retry_failed_notifications.py
from django.core.management.base import BaseCommand
from notifications.models import NotificationLog
from notifications.services import send_notification


class Command(BaseCommand):
    help = 'تلاش مجدد برای ارسال نوتیفیکیشن‌های ناموفق (status=failed)'

    def add_arguments(self, parser):
        parser.add_argument(
            '--limit', type=int, default=100,
            help='حداکثر تعداد لاگ برای تلاش مجدد (پیش‌فرض ۱۰۰)')
        parser.add_argument(
            '--log-id', type=int, default=None,
            help='تلاش مجدد فقط برای یک لاگ خاص')

    def handle(self, *args, **options):
        qs = NotificationLog.objects.filter(status='failed')
        if options['log_id']:
            qs = qs.filter(id=options['log_id'])
        qs = qs.order_by('-created_at')[:options['limit']]

        success = 0
        failed = 0
        for log in qs:
            try:
                user = log.user
                # بازفرستادن با همان قالب؛ send_notification لاگ جدید می‌سازد
                send_notification(user, log.type)
                success += 1
                self.stdout.write(f"  ✓ retry #{log.id} ({log.type})")
            except Exception as e:  # pragma: no cover
                failed += 1
                self.stdout.write(f"  ✗ retry #{log.id}: {e}")

        self.stdout.write(self.style.SUCCESS(
            f"Retry done: {success} ok, {failed} failed "
            f"(از {qs.count()} مورد)."))

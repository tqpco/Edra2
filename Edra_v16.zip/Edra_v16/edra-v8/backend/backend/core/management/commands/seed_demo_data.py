# backend/core/management/commands/seed_demo_data.py
"""
داده اولیه برای محیط توسعه/دمو: تجهیزات، پارامترها، قوانین قیمت،
شهرها، کاربران نمونه و قالب‌های اعلان.

استفاده:
  python manage.py seed_demo_data [--with-users]
"""
from decimal import Decimal

from django.contrib.auth import get_user_model
from django.core.management import call_command
from django.core.management.base import BaseCommand
from django.db import transaction

from core.models import CityMultiplier, EquipmentParameter, EquipmentType, UserProfile
from pricing.models import ParameterPrice, PricingRule

User = get_user_model()


class Command(BaseCommand):
    help = 'Seed داده اولیه دمو (تجهیزات/قیمت/شهر/قالب اعلان/کاربران اختیاری)'

    def add_arguments(self, parser):
        parser.add_argument(
            '--with-users', action='store_true',
            help='ساخت کاربران نمونه (admin/expert/customer)')

    EQUIPMENT = [
        # (code, name_fa, base_price, [params: (name, label, rate)])
        ('tower_crane', 'جرثقیل برجی', 1500000, [
            ('capacity', 'ظرفیت (تن)', 200000),
            ('height', 'ارتفاع (متر)', 50000),
        ]),
        ('mobile_crane', 'جرثقیل سیار', 1200000, [
            ('capacity', 'ظرفیت (تن)', 150000),
        ]),
        ('excavator', 'بیل مکانیکی', 900000, [
            ('weight', 'وزن (تن)', 80000),
        ]),
        ('wheel_loader', 'لودر چرخ لاستیکی', 800000, [
            ('bucket_capacity', 'ظرفیت جام (مترمکعب)', 100000),
        ]),
        ('forklift', 'لیفتراک', 600000, [
            ('capacity', 'ظرفیت (تن)', 70000),
        ]),
    ]

    CITIES = [
        ('تهران', Decimal('1.0'), 200000),
        ('کرج', Decimal('1.0'), 150000),
        ('اصفهان', Decimal('1.05'), 180000),
        ('مشهد', Decimal('1.05'), 160000),
        ('شیراز', Decimal('1.05'), 160000),
        ('تبریز', Decimal('1.0'), 150000),
    ]

    @transaction.atomic
    def handle(self, *args, **options):
        # ---------- تجهیزات + قیمت ----------
        for code, name_fa, base, params in self.EQUIPMENT:
            eq, created = EquipmentType.objects.get_or_create(
                code=code,
                defaults={'name_fa': name_fa, 'param_schema': [
                    {'key': k, 'label_fa': lbl, 'unit': ''}
                    for k, lbl, _ in params]})
            rule, _ = PricingRule.objects.get_or_create(
                equipment_type=eq,
                defaults={
                    'base_price': base,
                    'standard_multiplier': Decimal('1.0'),
                    'pro_multiplier': Decimal('1.2'),
                })
            for name, label, rate in params:
                param, _ = EquipmentParameter.objects.get_or_create(
                    equipment_type=eq, name=name,
                    defaults={'label': label, 'field_type': 'number'})
                ParameterPrice.objects.get_or_create(
                    pricing_rule=rule, parameter=param,
                    defaults={'rate_type': 'per_unit', 'rate': rate})
            self.stdout.write(f"  ✓ {code} ({name_fa})")

        # ---------- شهرها ----------
        for city, mult, base_cost in self.CITIES:
            CityMultiplier.objects.get_or_create(
                city=city,
                defaults={'multiplier': mult, 'base_cost': base_cost})
        self.stdout.write("  ✓ city multipliers")

        # ---------- قالب‌های اعلان ----------
        call_command('seed_notification_templates')
        self.stdout.write("  ✓ notification templates")

        # ---------- گروه‌ها و کاربران نمونه (اختیاری) ----------
        if options['with_users']:
            call_command('setup_expert_group')
            from django.contrib.auth.models import Group
            admin_group, _ = Group.objects.get_or_create(name='Admin')

            users = [
                ('09120000000', 'demo_admin', 'Admin'),
                ('09120000001', 'demo_expert', 'Expert'),
                ('09120000002', 'demo_customer', None),
            ]
            for phone, username, group_name in users:
                user, created = User.objects.get_or_create(
                    username=username, defaults={'is_staff': group_name == 'Admin'})
                if group_name:
                    user.groups.add(Group.objects.get(name=group_name))
                UserProfile.objects.get_or_create(
                    user=user, defaults={'phone': phone})
                self.stdout.write(
                    f"  ✓ user {username} (تازه‌ساخت: {created})")

        self.stdout.write(self.style.SUCCESS("Seed demo data: done."))

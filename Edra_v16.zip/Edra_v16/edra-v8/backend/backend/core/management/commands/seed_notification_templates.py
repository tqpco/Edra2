# backend/core/management/commands/seed_notification_templates.py
from django.core.management.base import BaseCommand
from notifications.models import NotificationTemplate


class Command(BaseCommand):
    help = 'Seed notification templates'

    def handle(self, *args, **options):
        # نکته: قالب‌ها با سینتکس Django Template ({{ var }}) نوشته می‌شوند
        # چون notifications.services.send_notification با
        # django.template.Template().render() آن‌ها را رندر می‌کند
        # (سینتکس تک‌آکولاد Python-format قبلی اصلاً رندر نمی‌شد).
        templates = [
            {'code': 'request_created',
             'channel': 'both',
             'subject': 'درخواست جدید ایجاد شد',
             'body_template': 'سلام {{ user.get_full_name|default:user.username }}، درخواست شما با شماره {{ request_id }} ثبت شد.',
             'is_active': True},
            {'code': 'new_request_admin',
             'channel': 'both',
             'subject': 'درخواست جدید برای بررسی',
             'body_template': 'یک درخواست جدید با شماره {{ request_id }} از کاربر {{ customer }} ثبت شده است.',
             'is_active': True},
            {'code': 'assigned_to_expert',
             'channel': 'both',
             'subject': 'تخصیص کارشناس',
             'body_template': 'شما به عنوان کارشناس برای درخواست {{ request_id }} تعیین شده‌اید.',
             'is_active': True},
            {'code': 'status_changed',
             'channel': 'both',
             'subject': 'تغییر وضعیت درخواست',
             'body_template': 'وضعیت درخواست {{ request_id }} به {{ new_status }} تغییر یافت.',
             'is_active': True},
            {'code': 'payment_successful',
             'channel': 'both',
             'subject': 'پرداخت موفق',
             'body_template': 'پرداخت شما به مبلغ {{ amount }} تومان با موفقیت انجام شد.',
             'is_active': True},
            {'code': 'payment_failed',
             'channel': 'both',
             'subject': 'پرداخت ناموفق',
             'body_template': 'متاسفانه پرداخت شما برای درخواست {{ request_id }} ناموفق بود. لطفاً دوباره تلاش کنید.',
             'is_active': True},
            {'code': 'invoice_pdf_ready',
             'channel': 'both',
             'subject': 'فاکتور PDF آماده شد',
             'body_template': 'فاکتور شماره {{ invoice_number }} آماده دانلود است.',
             'is_active': True},
            {'code': 'invoice_pdf_failed',
             'channel': 'email',
             'subject': 'خطا در تولید فاکتور',
             'body_template': 'در تولید فایل PDF فاکتور شما خطایی رخ داد. تیم پشتیبانی در حال بررسی است.',
             'is_active': True},
            {'code': 'invoice_pdf_failed_admin',
             'channel': 'email',
             'subject': '[ادمین] خطا در تولید فاکتور',
             'body_template': 'تولید PDF فاکتور {{ invoice_id }} با خطا مواجه شد: {{ error }}',
             'is_active': True},
            {'code': 'report_pdf_ready',
             'channel': 'both',
             'subject': 'گزارش PDF آماده شد',
             'body_template': 'گزارش شماره {{ report_number }} آماده دانلود است.',
             'is_active': True},
            {'code': 'report_pdf_failed',
             'channel': 'email',
             'subject': 'خطا در تولید گزارش',
             'body_template': 'در تولید فایل PDF گزارش شما خطایی رخ داد. تیم پشتیبانی در حال بررسی است.',
             'is_active': True},
            {'code': 'payment_verified',
             'channel': 'both',
             'subject': 'تایید پرداخت و افزایش اعتبار',
             'body_template': '{{ message }}',
             'is_active': True},
            {'code': 'payment_verified_request',
             'channel': 'both',
             'subject': 'تایید پرداخت و زمان‌بندی درخواست',
             'body_template': '{{ message }}',
             'is_active': True},
            {'code': 'payment_rejected',
             'channel': 'both',
             'subject': 'رد فیش پرداخت',
             'body_template': 'فیش پرداخت شما بابت درخواست #{{ request_id }} تایید نشد. دلیل: {{ reason }}',
             'is_active': True},
            {'code': 'payment_manual_upload',
             'channel': 'both',
             'subject': 'آپلود فیش جدید',
             'body_template': 'کاربر {{ customer }} یک فیش به مبلغ {{ amount }} تومان برای درخواست #{{ request_id }} آپلود کرده است.',
             'is_active': True},
            {'code': 'new_discount_code',
             'channel': 'both',
             'subject': 'کد تخفیف جدید',
             'body_template': 'یک کد تخفیف جدید برای شما فعال شد: {{ code }}',
             'is_active': True},
            {'code': 'discount_code_expiring',
             'channel': 'both',
             'subject': 'کد تخفیف شما رو به اتمام است',
             'body_template': 'کد تخفیف {{ code }} شما تا {{ days_left }} روز دیگر منقضی می‌شود.',
             'is_active': True},
            {'code': 'inspection_scheduled',
             'channel': 'both',
             'subject': 'زمان کارشناسی ثبت شد',
             'body_template': 'زمان کارشناسی درخواست {{ request_id }} ثبت شد.',
             'is_active': True},
        ]
        for t in templates:
            obj, created = NotificationTemplate.objects.get_or_create(
                code=t['code'], defaults=t)
            if created:
                self.stdout.write(
                    self.style.SUCCESS(f'Created template: {t["code"]}'))
            else:
                self.stdout.write(
                    self.style.WARNING(f'Template {t["code"]} already exists'))

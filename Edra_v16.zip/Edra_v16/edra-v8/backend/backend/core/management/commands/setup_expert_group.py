# core/management/commands/setup_expert_group.py
from django.core.management.base import BaseCommand
from django.contrib.auth.models import Group, Permission
from django.contrib.contenttypes.models import ContentType
from core.models import InspectionRequest, InspectionReport


class Command(BaseCommand):
    help = "ایجاد گروه Expert و تنظیم دسترسی‌ها"

    def handle(self, *args, **options):
        group, created = Group.objects.get_or_create(name='Expert')
        if created:
            self.stdout.write(self.style.SUCCESS('✅ گروه Expert ایجاد شد.'))
        else:
            self.stdout.write(self.style.WARNING(
                '⚠️ گروه Expert قبلاً وجود داشت.'))

        ct_request = ContentType.objects.get_for_model(InspectionRequest)
        permissions_request = Permission.objects.filter(
            content_type=ct_request)
        ct_report = ContentType.objects.get_for_model(InspectionReport)
        permissions_report = Permission.objects.filter(content_type=ct_report)

        for perm in permissions_request:
            group.permissions.add(perm)
        for perm in permissions_report:
            group.permissions.add(perm)

        self.stdout.write(
            self.style.SUCCESS(
                f'✅ {
                    permissions_request.count() +
                    permissions_report.count()} پرمیشن اضافه شد.'))
        experts = group.user_set.all()
        if experts:
            self.stdout.write(
                self.style.SUCCESS(
                    f'👤 تعداد کارشناسان: {
                        experts.count()}'))
            for expert in experts:
                self.stdout.write(f'  - {expert.username}')
        else:
            self.stdout.write(self.style.WARNING(
                '⚠️ هیچ کاربری در گروه Expert نیست.'))
            self.stdout.write(
                'برای افزودن: python manage.py add_user_to_group <username> Expert')

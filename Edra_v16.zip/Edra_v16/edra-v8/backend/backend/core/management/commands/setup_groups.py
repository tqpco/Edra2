# core/management/commands/setup_groups.py
"""
ایجاد/هماهنگ‌سازی گروه‌های نقش (Admin / Expert / Support) به‌صورت
idempotent — ستون فقرات مجوزهای پروژه (HIGH-21).

کاربرد:
  python manage.py setup_groups

این دستور هیچ داده‌ای را حذف نمی‌کند؛ فقط گروه‌های از دست رفته را می‌سازد
و دسترسی‌های پیش‌فرض هر نقش را اضافه می‌کند (بدون برداشتن دسترسی اضافه‌ای
که ادمین بعداً تنظیم کرده باشد).
"""
from django.contrib.auth.models import Group, Permission
from django.contrib.contenttypes.models import ContentType
from django.core.management.base import BaseCommand
from django.apps import apps


class Command(BaseCommand):
    help = 'ایجاد گروه‌های نقش (Admin/Expert/Support) و دسترسی‌های پیش‌فرض'

    # نقش → (نام‌های مدل/اپی که دسترسی کامل روی آن‌ها می‌گیرد)
    ROLE_MODELS = {
        'Admin': ['*'],  # همه‌ی اپ‌ها
        'Expert': [
            'inspectionrequest', 'inspectionreport', 'checklisttemplate',
            'checklistitem', 'reportverification',
        ],
        'Support': [
            'ticket', 'ticketmessage', 'savedreply',
            'knowledgebasecategory', 'knowledgebasearticle', 'announcement',
        ],
    }

    def handle(self, *args, **options):
        all_perms = Permission.objects.select_related('content_type').all()

        for role, model_names in self.ROLE_MODELS.items():
            group, created = Group.objects.get_or_create(name=role)
            added = 0
            for perm in all_perms:
                ct = perm.content_type
                if '*' in model_names or ct.model in model_names:
                    # برای Admin همه‌چیز؛ برای بقیه فقط view/change/add (نه delete)
                    if role == 'Admin' or perm.codename.startswith(
                            ('view_', 'change_', 'add_')):
                        group.permissions.add(perm)
                        added += 1

            if created:
                self.stdout.write(
                    self.style.SUCCESS(f'✅ گروه {role} ایجاد شد '
                                       f'({added} دسترسی).'))
            else:
                self.stdout.write(
                    self.style.SUCCESS(f'↺ گروه {role} موجود بود — '
                                       f'{added} دسترسی پیش‌فرض هماهنگ شد.'))

        # صحت‌سنجی
        for role in self.ROLE_MODELS:
            if not Group.objects.filter(name=role).exists():
                self.stdout.write(
                    self.style.ERROR(f'❌ گروه {role} ساخته نشد!'))
                return
        self.stdout.write(self.style.SUCCESS(
            '✅ همه گروه‌های نقش آماده‌اند (Admin/Expert/Support).'))

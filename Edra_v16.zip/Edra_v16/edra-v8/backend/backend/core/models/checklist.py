from django.db import models
from django_jalali.db import models as jmodels
from django.contrib.auth import get_user_model
from ..utils.upload_paths import (
    report_pdf_upload_path, signed_report_pdf_upload_path,
    checklist_photo_upload_path,
)
from ..utils.image_utils import compress_and_save_image_field

User = get_user_model()


class ChecklistTemplate(models.Model):
    """قالب چک‌لیست"""
    equipment_type = models.ForeignKey(
        'EquipmentType',
        on_delete=models.CASCADE,
        related_name='checklist_templates',
        verbose_name='نوع تجهیزات'
    )
    version = models.PositiveIntegerField(default=1, verbose_name='نسخه')
    name = models.CharField(max_length=200, verbose_name='نام')
    description = models.TextField(blank=True, verbose_name='توضیحات')
    is_active = models.BooleanField(default=True, verbose_name='فعال')
    created_at = jmodels.jDateTimeField(
        auto_now_add=True, verbose_name='تاریخ ایجاد')
    created_by = models.ForeignKey(
        User,
        on_delete=models.PROTECT,
        null=True,
        verbose_name='ایجادکننده'
    )
    updated_at = jmodels.jDateTimeField(
        auto_now=True, verbose_name='تاریخ بروزرسانی')

    class Meta:
        unique_together = ('equipment_type', 'version')
        ordering = ['-version']
        verbose_name = 'قالب چک‌لیست'
        verbose_name_plural = 'قالب‌های چک‌لیست'

    def __str__(self):
        return f"{self.equipment_type.name_fa} - v{self.version}"


class ChecklistItem(models.Model):
    """آیتم چک‌لیست"""
    RESULT_CHOICES = [
        ('pass', 'قبول'),
        ('fail', 'مردود'),
        ('na', 'غیرقابل‌اجرا'),
        ('pending', 'در انتظار بررسی')
    ]

    checklist_template = models.ForeignKey(
        'ChecklistTemplate',
        on_delete=models.CASCADE,
        related_name='items',
        verbose_name='قالب چک‌لیست'
    )
    category = models.CharField(max_length=100, verbose_name='دسته‌بندی')
    title = models.CharField(max_length=200, verbose_name='عنوان')
    description = models.TextField(blank=True, verbose_name='توضیحات')
    order = models.PositiveSmallIntegerField(default=0, verbose_name='ترتیب')
    requires_photo = models.BooleanField(
        default=False, verbose_name='نیاز به عکس')
    requires_note = models.BooleanField(
        default=False, verbose_name='نیاز به یادداشت')
    # EDRA v5 — HIGH-46/47: آیتم حیاتی (جلوگیری از contract drift بین
    # فرانت‌اند و بک‌اند). هر fail در آیتم حیاتی → گزارش مردود.
    is_critical = models.BooleanField(
        default=False, verbose_name='آیتم حیاتی')
    photo = models.ImageField(
        upload_to='checklist_templates/reference_photos/',
        blank=True,
        null=True,
        verbose_name='عکس نمونه/مرجع',
        help_text='عکس مرجع نمایشی برای این آیتم در قالب (متفاوت از عکس‌های واقعی ثبت‌شده توسط کارشناس در هر بازرسی - نگاه کنید به مدل ChecklistPhoto)'
    )
    is_active = models.BooleanField(default=True, verbose_name='فعال')

    class Meta:
        ordering = ['order']
        verbose_name = 'آیتم چک‌لیست'
        verbose_name_plural = 'آیتم‌های چک‌لیست'

    def __str__(self):
        return f"{self.category} - {self.title}"


class InspectionReport(models.Model):
    """گزارش کارشناسی"""
    OVERALL_RESULT_CHOICES = [
        ('pass', 'قبول'),
        ('conditional', 'مشروط'),
        ('fail', 'مردود')
    ]

    inspection_request = models.OneToOneField(
        'InspectionRequest',
        on_delete=models.PROTECT,
        related_name='report',
        verbose_name='درخواست کارشناسی'
    )
    report_number = models.CharField(
        max_length=40,
        unique=True,
        verbose_name='شماره گزارش')
    checklist_template_version = models.ForeignKey(
        'ChecklistTemplate',
        on_delete=models.PROTECT,
        null=True,
        verbose_name='نسخه قالب چک‌لیست'
    )
    results = models.JSONField(default=list, verbose_name='نتایج')
    overall_result = models.CharField(
        max_length=20,
        choices=OVERALL_RESULT_CHOICES,
        verbose_name='نتیجه کلی')
    inspector_notes = models.TextField(
        blank=True, verbose_name='یادداشت کارشناس')

    # --- ضدتقلب: GPS و زمان شروع/پایان کارشناسی در محل ---
    gps_start_lat = models.DecimalField(
        max_digits=9, decimal_places=6, null=True, blank=True,
        verbose_name='عرض جغرافیایی شروع')
    gps_start_lng = models.DecimalField(
        max_digits=9, decimal_places=6, null=True, blank=True,
        verbose_name='طول جغرافیایی شروع')
    gps_end_lat = models.DecimalField(
        max_digits=9, decimal_places=6, null=True, blank=True,
        verbose_name='عرض جغرافیایی پایان')
    gps_end_lng = models.DecimalField(
        max_digits=9, decimal_places=6, null=True, blank=True,
        verbose_name='طول جغرافیایی پایان')
    gps_distance_meters = models.FloatField(
        null=True, blank=True,
        verbose_name='فاصله از محل پروژه (متر)',
        help_text='فاصله محاسبه‌شده بین GPS شروع کارشناسی و آدرس ثبت‌شده پروژه')
    inspection_started_at = jmodels.jDateTimeField(
        null=True, blank=True, verbose_name='زمان شروع کارشناسی در محل')
    inspection_ended_at = jmodels.jDateTimeField(
        null=True, blank=True, verbose_name='زمان پایان کارشناسی در محل')
    pdf_file = models.FileField(
        upload_to=report_pdf_upload_path,
        blank=True,
        null=True,
        verbose_name='فایل PDF')
    signed_pdf_file = models.FileField(
        upload_to=signed_report_pdf_upload_path,
        blank=True,
        null=True,
        verbose_name='PDF امضا شده')
    signature_hash = models.CharField(
        max_length=255, blank=True, verbose_name='هش امضا')
    signed_at = jmodels.jDateTimeField(
        null=True, blank=True, verbose_name='تاریخ امضا')
    signed_by = models.ForeignKey(
        User,
        on_delete=models.PROTECT,
        null=True,
        related_name='signed_reports',
        verbose_name='امضاکننده'
    )
    created_at = jmodels.jDateTimeField(
        auto_now_add=True, verbose_name='تاریخ ایجاد')
    updated_at = jmodels.jDateTimeField(
        auto_now=True, verbose_name='تاریخ بروزرسانی')

    def __str__(self):
        return self.report_number

    class Meta:
        verbose_name = 'گزارش کارشناسی'
        verbose_name_plural = 'گزارش‌های کارشناسی'


class ChecklistPhoto(models.Model):
    """
    عکس واقعی ثبت‌شده توسط کارشناس برای یک آیتم چک‌لیست، در یک گزارش
    بازرسی مشخص (نه عکس نمونه‌ی قالب). هر آیتمی که requires_photo=True
    باشد می‌تواند یک یا چند عکس از این مدل داشته باشد.
    فایل به‌صورت خودکار فشرده می‌شود (حداکثر بعد ۱۹۲۰px، JPEG کیفیت ۸۲).
    """
    report = models.ForeignKey(
        'InspectionReport',
        on_delete=models.CASCADE,
        related_name='photos',
        verbose_name='گزارش بازرسی')
    checklist_item = models.ForeignKey(
        'ChecklistItem',
        on_delete=models.PROTECT,
        related_name='photo_responses',
        verbose_name='آیتم چک‌لیست')
    image = models.ImageField(
        upload_to=checklist_photo_upload_path,
        verbose_name='عکس')
    caption = models.CharField(
        max_length=255, blank=True, verbose_name='توضیح کوتاه')
    gps_lat = models.DecimalField(
        max_digits=9, decimal_places=6, null=True, blank=True,
        verbose_name='عرض جغرافیایی ثبت عکس')
    gps_lng = models.DecimalField(
        max_digits=9, decimal_places=6, null=True, blank=True,
        verbose_name='طول جغرافیایی ثبت عکس')
    created_at = jmodels.jDateTimeField(
        auto_now_add=True, verbose_name='تاریخ ثبت')

    class Meta:
        verbose_name = 'عکس چک‌لیست'
        verbose_name_plural = 'عکس‌های چک‌لیست'
        ordering = ['checklist_item__order', 'created_at']

    def __str__(self):
        return f"{self.report.report_number} - {self.checklist_item.title}"

    def save(self, *args, **kwargs):
        if self.image and not kwargs.pop('_skip_compression', False):
            compress_and_save_image_field(self, 'image')
        super().save(*args, **kwargs)


class ReportVerification(models.Model):
    """تأییدیه گزارش"""
    report = models.OneToOneField(
        'InspectionReport',
        on_delete=models.CASCADE,
        related_name='verification',
        verbose_name='گزارش'
    )
    verification_code = models.CharField(
        max_length=50, unique=True, verbose_name='کد تأیید')
    view_count = models.PositiveIntegerField(
        default=0, verbose_name='تعداد بازدید')
    last_viewed_at = jmodels.jDateTimeField(
        null=True, blank=True, verbose_name='آخرین بازدید')
    created_at = jmodels.jDateTimeField(
        auto_now_add=True, verbose_name='تاریخ ایجاد')

    def __str__(self):
        return f"{self.report.report_number} - {self.verification_code}"

    class Meta:
        verbose_name = 'تأییدیه گزارش'
        verbose_name_plural = 'تأییدیه‌های گزارش'

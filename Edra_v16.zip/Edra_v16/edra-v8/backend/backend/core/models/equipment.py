from django.db import models
from django_jalali.db import models as jmodels
from django.contrib.auth import get_user_model

User = get_user_model()


class EquipmentType(models.Model):
    """نوع تجهیزات"""
    code = models.SlugField(unique=True, verbose_name='کد')
    name_fa = models.CharField(max_length=100, verbose_name='نام فارسی')
    supports_install_state = models.BooleanField(
        default=False, verbose_name='پشتیبانی از وضعیت نصب')
    install_state_required = models.BooleanField(
        default=False, verbose_name='وضعیت نصب اجباری')
    param_schema = models.JSONField(
        verbose_name='شِمای پارامترها',
        blank=True,
        null=True,
        help_text='این فیلد به‌صورت خودکار توسط سیگنال‌ها به‌روز می‌شود'
    )

    def __str__(self):
        return self.name_fa

    class Meta:
        verbose_name = 'نوع تجهیزات'
        verbose_name_plural = 'انواع تجهیزات'


class EquipmentParameter(models.Model):
    """
    پارامترهای اضافی برای یک نوع تجهیزات
    این مدل جایگزین نوشتن دستی JSON در فیلد param_schema می‌شود.
    """
    equipment_type = models.ForeignKey(
        EquipmentType,
        on_delete=models.CASCADE,
        related_name='parameters',
        verbose_name='نوع تجهیزات'
    )
    name = models.SlugField(max_length=50, verbose_name='نام متغیر (انگلیسی)')
    label = models.CharField(max_length=100, verbose_name='برچسب (فارسی)')
    field_type = models.CharField(
        max_length=20,
        choices=[
            ('string', 'متن'),
            ('number', 'عدد'),
            ('select', 'منوی کشویی'),
            ('boolean', 'تیک/خیر')
        ],
        default='string',
        verbose_name='نوع فیلد'
    )
    options = models.TextField(
        blank=True,
        help_text='گزینه‌های منوی کشویی را با کاما جدا کنید (فقط برای نوع "منوی کشویی")',
        verbose_name='گزینه‌ها')
    required = models.BooleanField(default=False, verbose_name='اجباری')
    order = models.PositiveSmallIntegerField(
        default=0, verbose_name='ترتیب نمایش')

    class Meta:
        ordering = ['order']
        verbose_name = 'پارامتر تجهیزات'
        verbose_name_plural = 'پارامترهای تجهیزات'
        unique_together = ('equipment_type', 'name')

    def __str__(self):
        return f"{self.equipment_type.name_fa} - {self.label}"

    def get_options_list(self):
        if self.options:
            return [opt.strip()
                    for opt in self.options.split(',') if opt.strip()]
        return []

    def to_json_schema(self):
        """این پارامتر را به فرمت JSON که در param_schema استفاده می‌شود تبدیل می‌کند"""
        schema = {
            'name': self.name,
            'label': self.label,
            'type': self.field_type,
            'required': self.required
        }
        if self.field_type == 'select' and self.options:
            schema['options'] = self.get_options_list()
        return schema

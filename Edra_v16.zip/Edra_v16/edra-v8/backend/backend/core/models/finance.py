from django.db import models
from django_jalali.db import models as jmodels
from django.contrib.auth import get_user_model
from ..utils.upload_paths import bank_receipt_upload_path, invoice_pdf_upload_path

User = get_user_model()


class PaymentMethod(models.Model):
    """روش پرداخت"""
    METHOD_CHOICES = [
        ('online', 'درگاه آنلاین'),
        ('manual', 'واریز دستی'),
        ('credit', 'اعتبار شرکتی')
    ]
    name = models.CharField(
        max_length=50,
        choices=METHOD_CHOICES,
        unique=True,
        verbose_name='نام')
    is_active = models.BooleanField(default=True, verbose_name='فعال')
    description = models.TextField(blank=True, verbose_name='توضیحات')

    def __str__(self):
        return self.get_name_display()

    class Meta:
        verbose_name = 'روش پرداخت'
        verbose_name_plural = 'روش‌های پرداخت'


class Payment(models.Model):
    """پرداخت"""
    STATUS_CHOICES = [
        ('pending', 'در انتظار'),
        ('paid', 'پرداخت‌شده'),
        ('failed', 'ناموفق'),
        ('cancelled', 'لغو شده'),
        ('refunded', 'عودت داده‌شده'),
        ('pending_verification', 'در انتظار تایید'),
        ('rejected', 'رد شده'),
    ]

    inspection_request = models.ForeignKey(
        'InspectionRequest',
        on_delete=models.PROTECT,
        related_name='payments',
        verbose_name='درخواست بازرسی'
    )
    amount = models.DecimalField(
        max_digits=12,
        decimal_places=0,
        verbose_name='مبلغ کل')
    # مبلغ canonical دفتر مالی/درگاه به ریال (سیاست واحد پول: نمایش تومان،
    # پرداخت و حسابداری ریال). برای تراکنش‌های قدیمی می‌تواند null باشد و
    # در صورت نیاز از amount (تومان) محاسبه می‌شود.
    amount_rial = models.DecimalField(
        max_digits=14,
        decimal_places=0,
        null=True,
        blank=True,
        verbose_name='مبلغ ریالی (دفتر مالی)')
    credit_amount = models.DecimalField(
        max_digits=12,
        decimal_places=0,
        default=0,
        verbose_name='مبلغ از اعتبار')
    online_amount = models.DecimalField(
        max_digits=12,
        decimal_places=0,
        default=0,
        verbose_name='مبلغ آنلاین')
    manual_amount = models.DecimalField(
        max_digits=12,
        decimal_places=0,
        default=0,
        verbose_name='مبلغ دستی')
    method = models.ForeignKey(
        PaymentMethod,
        on_delete=models.PROTECT,
        verbose_name='روش پرداخت')
    status = models.CharField(
        max_length=20,
        choices=STATUS_CHOICES,
        default='pending',
        verbose_name='وضعیت')
    # شناسه درگاه پرداخت (Authority زرین‌پال) — یکتا برای idempotency کال‌بک
    authority = models.CharField(
        max_length=100,
        blank=True,
        null=True,
        unique=True,
        db_index=True,
        verbose_name='شناسه درگاه (Authority)')
    # کد مرجع پرداخت (RefID زرین‌پال پس از verify موفق)
    ref_id = models.CharField(
        max_length=100,
        blank=True,
        null=True,
        db_index=True,
        verbose_name='کد مرجع پرداخت (RefID)')
    transaction_id = models.CharField(
        max_length=100,
        blank=True,
        null=True,
        verbose_name='شناسه تراکنش')
    reference_code = models.CharField(
        max_length=100,
        blank=True,
        null=True,
        verbose_name='کد مرجع')
    bank_receipt = models.FileField(
        upload_to=bank_receipt_upload_path,
        blank=True,
        null=True,
        verbose_name='فیش بانکی')
    bank_receipt_uploaded_at = jmodels.jDateTimeField(
        null=True, blank=True, verbose_name='تاریخ آپلود فیش')
    # SHA-256 محتوای فیش (P0-8 گزارش V3) — برای تشخیص دستکاری/تطبیق
    bank_receipt_hash = models.CharField(
        max_length=64, blank=True, default='',
        verbose_name='هش محتوای فیش (SHA-256)')
    verified_by = models.ForeignKey(
        User,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name='verified_payments',
        verbose_name='تاییدکننده'
    )
    verified_at = jmodels.jDateTimeField(
        null=True, blank=True, verbose_name='تاریخ تایید')
    rejected_by = models.ForeignKey(
        User,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name='rejected_payments',
        verbose_name='ردکننده'
    )
    rejected_at = jmodels.jDateTimeField(
        null=True, blank=True, verbose_name='تاریخ رد')
    rejection_reason = models.TextField(blank=True, verbose_name='دلیل رد')
    notes = models.TextField(blank=True, verbose_name='یادداشت')
    created_at = jmodels.jDateTimeField(
        auto_now_add=True, verbose_name='تاریخ ایجاد')
    updated_at = jmodels.jDateTimeField(
        auto_now=True, verbose_name='تاریخ بروزرسانی')

    def clean(self):
        """
        Invariant مبلغ (P0 — گزارش V3 بند ۸):
        amount باید دقیقاً برابر مجموع credit + online + manual باشد.
        قبلاً mismatch با pass رها می‌شد؛ اکنون ValidationError پرتاب می‌شود.
        """
        from django.core.exceptions import ValidationError
        total_parts = self.credit_amount + self.online_amount + self.manual_amount
        if self.amount != total_parts:
            raise ValidationError({
                'amount': (
                    f'مبلغ پرداخت ({self.amount}) با مجموع اجزا '
                    f'({total_parts}) برابر نیست.')})

    def save(self, *args, **kwargs):
        """
        اجرای invariant هنگام ایجاد (نه هنگام به‌روزرسانی جزئی) تا مسیرهای
        ORM مستقیم هم نتوانند Payment ناسازگار بسازند.
        """
        if self._state.adding and not kwargs.get('update_fields'):
            from django.core.exceptions import ValidationError
            total_parts = self.credit_amount + self.online_amount + self.manual_amount
            if self.amount != total_parts:
                raise ValidationError({
                    'amount': (
                        f'مبلغ پرداخت ({self.amount}) با مجموع اجزا '
                        f'({total_parts}) برابر نیست.')})
        super().save(*args, **kwargs)

    def __str__(self):
        return f"{self.inspection_request.id} - {self.amount} - {self.status}"

    class Meta:
        verbose_name = 'پرداخت'
        verbose_name_plural = 'پرداخت‌ها'


class Invoice(models.Model):
    STATUS_CHOICES = [
        ('pending', 'در انتظار تولید'),
        ('generated', 'تولید شده'),
        ('failed', 'خطا در تولید'),
    ]

    inspection_request = models.OneToOneField(
        'InspectionRequest',
        on_delete=models.PROTECT,
        related_name='invoice',
        verbose_name='درخواست کارشناسی'
    )
    invoice_number = models.CharField(
        max_length=50,
        unique=True,
        verbose_name='شماره فاکتور')
    issue_date = jmodels.jDateTimeField(
        auto_now_add=True, verbose_name='تاریخ صدور')
    due_date = jmodels.jDateTimeField(verbose_name='تاریخ سررسید')
    # ------------------------------------------------------------------
    # Snapshot قیمت‌گذاری (FIN-03) — منبع واحد برای Invoice/Payment/Accounting
    # پایه پیش از تخفیف / تخفیف / مالیات / نهایی (تومان) + نهایی ریالی
    # ------------------------------------------------------------------
    base_amount = models.DecimalField(
        max_digits=12,
        decimal_places=0,
        default=0,
        verbose_name='مبلغ پایه (پیش از تخفیف)')
    total_amount = models.DecimalField(
        max_digits=12,
        decimal_places=0,
        verbose_name='مبلغ کل (پس از تخفیف، پیش از مالیات)')
    discount_amount = models.DecimalField(
        max_digits=12,
        decimal_places=0,
        default=0,
        verbose_name='مبلغ تخفیف')
    tax_amount = models.DecimalField(
        max_digits=12,
        decimal_places=0,
        default=0,
        verbose_name='مبلغ مالیات')
    # P0-08 (EDRA v9): snapshot نرخ مالیات (درصد) — فاکتور قدیمی هرگز با
    # تغییر نرخ جدید تغییر نمی‌کند.
    tax_rate_percent = models.DecimalField(
        max_digits=5,
        decimal_places=2,
        default=0,
        verbose_name='نرخ مالیات (٪)')
    final_amount = models.DecimalField(
        max_digits=12,
        decimal_places=0,
        verbose_name='مبلغ نهایی (تومان)')
    # مبلغ canonical دفتر مالی به ریال (سیاست واحد پول: نمایش تومان،
    # پرداخت/حسابداری ریال). برای فاکتورهای قدیمی null است و فقط در
    # صورت نیاز از final_amount (تومان) محاسبه می‌شود.
    final_rial = models.DecimalField(
        max_digits=14,
        decimal_places=0,
        null=True,
        blank=True,
        verbose_name='مبلغ نهایی به ریال (دفتر مالی)')
    pricing_version = models.CharField(
        max_length=20, blank=True, default='1.0',
        verbose_name='نسخه قانون قیمت‌گذاری')
    calculated_at = jmodels.jDateTimeField(
        null=True, blank=True, verbose_name='زمان محاسبه قیمت')
    pdf_file = models.FileField(
        upload_to=invoice_pdf_upload_path,
        blank=True,
        null=True,
        verbose_name='فایل PDF')
    is_paid = models.BooleanField(default=False, verbose_name='پرداخت شده')
    paid_at = jmodels.jDateTimeField(
        null=True, blank=True, verbose_name='تاریخ پرداخت')
    status = models.CharField(
        max_length=20,
        choices=STATUS_CHOICES,
        default='pending',
        verbose_name='وضعیت فاکتور')
    retry_count = models.PositiveIntegerField(
        default=0, verbose_name='تعداد تلاش مجدد')
    last_error = models.TextField(blank=True, verbose_name='آخرین خطا')

    def __str__(self):
        return self.invoice_number

    class Meta:
        verbose_name = 'فاکتور'


class TaxRate(models.Model):
    """
    P0-08 (EDRA v9): نرخ مالیات مدیریتی، versioned/effective-dated.

    مثال:
      rate_percent=10.00, effective_from=1405-01-01 (شروع سال مالیاتی)
      rate_percent=11.00, effective_from=1406-01-01

    سیستم در تاریخ موردنظر، آخرین نرخ فعال با effective_from <= آن تاریخ
    را انتخاب می‌کند (TaxRateService.get_rate).
    """
    rate_percent = models.DecimalField(
        max_digits=5,
        decimal_places=2,
        verbose_name='نرخ مالیات (٪)')
    effective_from = jmodels.jDateField(
        verbose_name='تاریخ شروع اعتبار')
    effective_to = jmodels.jDateField(
        null=True, blank=True, verbose_name='تاریخ پایان اعتبار (اختیاری)')
    is_active = models.BooleanField(default=True, verbose_name='فعال')
    created_by = models.ForeignKey(
        User, null=True, blank=True, on_delete=models.SET_NULL,
        related_name='tax_rates_created', verbose_name='ایجادکننده')
    created_at = jmodels.jDateTimeField(
        auto_now_add=True, verbose_name='تاریخ ایجاد')
    updated_at = jmodels.jDateTimeField(
        auto_now=True, verbose_name='تاریخ بروزرسانی')

    class Meta:
        ordering = ['effective_from']
        verbose_name = 'نرخ مالیات'
        verbose_name_plural = 'نرخ‌های مالیات'

    def __str__(self):
        return f'{self.rate_percent}٪ از {self.effective_from}'

    def clean(self):
        """EDRA v12 — P1-04: invariants نرخ مالیات."""
        from django.core.exceptions import ValidationError
        if self.rate_percent is None or self.rate_percent < 0:
            raise ValidationError({'rate_percent': 'نرخ نمی‌تواند منفی باشد.'})
        if self.effective_to and self.effective_from \
                and self.effective_to < self.effective_from:
            raise ValidationError(
                {'effective_to': 'تاریخ پایان نمی‌تواند قبل از شروع باشد.'})
        if not self.is_active:
            return
        # جلوگیری از بازه‌های فعال هم‌پوشان (ambiguous rate)
        from django.db.models import Q
        new_start = self.effective_from
        new_end = self.effective_to  # None = باز
        overlaps = type(self).objects.filter(
            is_active=True,
            effective_from__lte=(
                new_end if new_end else new_start),
        ).filter(
            Q(effective_to__isnull=True)
            | Q(effective_to__gte=new_start)
        ).exclude(pk=self.pk)
        if overlaps.exists():
            raise ValidationError(
                {'effective_from':
                 'یک نرخ فعال هم‌پوشان وجود دارد — بازه‌ها نباید هم‌پوشی کنند.'})


class Refund(models.Model):
    """
    P0 (EDRA v10): عودت با state machine واقعی — Payment هرگز به‌صرف
    «ثبت درخواست عودت» refunded نمی‌شود؛ فقط بعد از نتیجه قطعی درگاه
    (یا بازگشت واقعی سهم اعتبار) وضعیت نهایی می‌گیرد.

    وضعیت‌ها:
      requested → gateway_processing → gateway_refunded → completed
      gateway_processing → gateway_failed (در صورت خطای درگاه)
    """
    STATUS_CHOICES = [
        ('requested', 'درخواست شده'),
        ('gateway_processing', 'در حال پردازش درگاه'),
        ('gateway_refunded', 'عودت درگاه تأیید شد'),
        ('completed', 'تکمیل شده'),
        ('gateway_failed', 'خطای درگاه در عودت'),
    ]

    payment = models.ForeignKey(
        Payment, on_delete=models.PROTECT, related_name='refunds',
        verbose_name='پرداخت')
    inspection_request = models.ForeignKey(
        'InspectionRequest', on_delete=models.PROTECT,
        related_name='refunds', verbose_name='درخواست بازرسی')
    customer = models.ForeignKey(
        User, on_delete=models.PROTECT, related_name='refunds',
        verbose_name='مشتری')
    invoice = models.ForeignKey(
        Invoice, null=True, blank=True, on_delete=models.SET_NULL,
        related_name='refunds', verbose_name='فاکتور')
    amount_toman = models.DecimalField(
        max_digits=12, decimal_places=0, verbose_name='مبلغ عودت (تومان)')
    amount_rial = models.DecimalField(
        max_digits=14, decimal_places=0, verbose_name='مبلغ عودت (ریال)')
    credit_amount = models.DecimalField(
        max_digits=12, decimal_places=0, default=0,
        verbose_name='سهم اعتبار (تومان)')
    online_amount = models.DecimalField(
        max_digits=12, decimal_places=0, default=0,
        verbose_name='سهم آنلاین (تومان)')
    reason = models.TextField(verbose_name='علت عودت')
    requested_by = models.ForeignKey(
        User, null=True, blank=True, on_delete=models.SET_NULL,
        related_name='refunds_requested', verbose_name='درخواست‌دهنده')
    approved_by = models.ForeignKey(
        User, null=True, blank=True, on_delete=models.SET_NULL,
        related_name='refunds_approved', verbose_name='تأییدکننده')
    gateway_reference = models.CharField(
        max_length=200, blank=True, default='',
        verbose_name='Reference عودت درگاه')
    gateway_status = models.CharField(
        max_length=50, blank=True, default='',
        verbose_name='وضعیت اعلام‌شده توسط درگاه')
    status = models.CharField(
        max_length=30, choices=STATUS_CHOICES, default='requested',
        verbose_name='وضعیت عودت')
    failure_reason = models.TextField(
        blank=True, default='', verbose_name='دلیل خطا')
    requested_at = jmodels.jDateTimeField(
        auto_now_add=True, verbose_name='زمان درخواست')
    processed_at = jmodels.jDateTimeField(
        null=True, blank=True, verbose_name='زمان پردازش درگاه')
    completed_at = jmodels.jDateTimeField(
        null=True, blank=True, verbose_name='زمان تکمیل')
    created_at = jmodels.jDateTimeField(
        auto_now_add=True, verbose_name='تاریخ ایجاد')
    updated_at = jmodels.jDateTimeField(
        auto_now=True, verbose_name='تاریخ بروزرسانی')

    class Meta:
        ordering = ['-created_at']
        verbose_name = 'عودت'
        verbose_name_plural = 'عودت‌ها'

    def __str__(self):
        return f'Refund #{self.id} — {self.payment_id} ({self.status})'


class UserCredit(models.Model):
    """اعتبار کاربر"""
    user = models.OneToOneField(
        User,
        on_delete=models.CASCADE,
        related_name='credit',
        verbose_name='کاربر'
    )
    balance = models.DecimalField(
        max_digits=12,
        decimal_places=0,
        default=0,
        verbose_name='موجودی')
    credit_limit = models.DecimalField(
        max_digits=12,
        decimal_places=0,
        default=0,
        verbose_name='سقف اعتبار')
    is_active = models.BooleanField(default=True, verbose_name='فعال')
    updated_at = jmodels.jDateTimeField(
        auto_now=True, verbose_name='تاریخ بروزرسانی')

    def __str__(self):
        return f"{self.user.username} - {self.balance}"

    class Meta:
        verbose_name = 'اعتبار کاربر'
        verbose_name_plural = 'اعتبار کاربران'


class CreditTransaction(models.Model):
    """تراکنش اعتباری"""
    TRANSACTION_TYPES = [
        ('deposit', 'افزایش اعتبار'),
        ('withdraw', 'کاهش اعتبار'),
        ('purchase', 'خرید'),
        ('refund', 'عودت')
    ]
    user = models.ForeignKey(
        User,
        on_delete=models.PROTECT,
        related_name='credit_transactions',
        verbose_name='کاربر'
    )
    amount = models.DecimalField(
        max_digits=12,
        decimal_places=0,
        verbose_name='مبلغ')
    transaction_type = models.CharField(
        max_length=20,
        choices=TRANSACTION_TYPES,
        verbose_name='نوع تراکنش')
    description = models.CharField(max_length=200, verbose_name='توضیحات')
    reference_id = models.CharField(
        max_length=100,
        blank=True,
        null=True,
        verbose_name='شناسه مرجع')
    balance_after = models.DecimalField(
        max_digits=12,
        decimal_places=0,
        verbose_name='موجودی پس از تراکنش')
    created_at = jmodels.jDateTimeField(
        auto_now_add=True, verbose_name='تاریخ ایجاد')

    def __str__(self):
        return f"{self.user.username} - {self.amount} - {self.transaction_type}"

    class Meta:
        verbose_name = 'تراکنش اعتباری'
        verbose_name_plural = 'تراکنش‌های اعتباری'


class LedgerEntry(models.Model):
    """
    دفتر کل حسابداری (P0 — گزارش V3 بند ۱۵/۲۳):
    سوابق غیرقابل‌تغییر (append-only) تسویه/عودت؛ منبع reconciliation
    گزارش مالی. هر ورودی به Payment اصلی و reference درگاه متصل است.

    entry_type:
      settlement       = تسویه پرداخت موفق (مثبت)
      refund           = عودت (معکوس)
      credit_consumed  = مصرف اعتبار در پرداخت ترکیبی
    """
    ENTRY_TYPES = [
        ('settlement', 'تسویه پرداخت'),
        ('refund', 'عودت'),
        ('credit_consumed', 'مصرف اعتبار'),
    ]

    payment = models.ForeignKey(
        'Payment',
        on_delete=models.PROTECT,
        related_name='ledger_entries',
        verbose_name='پرداخت')
    entry_type = models.CharField(
        max_length=30, choices=ENTRY_TYPES, verbose_name='نوع ورودی')
    amount_toman = models.DecimalField(
        max_digits=14, decimal_places=0, verbose_name='مبلغ (تومان)')
    amount_rial = models.DecimalField(
        max_digits=14, decimal_places=0, verbose_name='مبلغ (ریال)')
    reference = models.CharField(
        max_length=100, blank=True, default='', verbose_name='مرجع (RefID/Authority)')
    performed_by = models.ForeignKey(
        User, on_delete=models.SET_NULL, null=True, blank=True,
        related_name='ledger_entries', verbose_name='انجام‌دهنده')
    metadata = models.JSONField(default=dict, blank=True, verbose_name='فراداده')
    created_at = jmodels.jDateTimeField(
        auto_now_add=True, verbose_name='تاریخ ثبت')

    class Meta:
        verbose_name = 'ورودی دفتر کل'
        verbose_name_plural = 'دفتر کل حسابداری'
        ordering = ['created_at']
        # EDRA v5 — HIGH-29/30: یکتایی در سطح database برای idempotency
        # واقعی (در race condition دو worker نمی‌توانند ورودی تکراری بسازند).
        constraints = [
            models.UniqueConstraint(
                fields=['payment', 'entry_type'],
                name='uniq_payment_ledger_type'),
        ]

    def save(self, *args, **kwargs):
        # Append-only: ورودی‌های موجود هرگز تغییر نمی‌کنند
        if self.pk and LedgerEntry.objects.filter(pk=self.pk).exists():
            raise ValueError('LedgerEntry را نمی‌توان تغییر داد (append-only).')
        super().save(*args, **kwargs)

    def delete(self, *args, **kwargs):
        raise ValueError('LedgerEntry را نمی‌توان حذف کرد (append-only).')


class CreditReservation(models.Model):
    """رزرو اعتبار برای پرداخت ترکیبی Credit+Online (FIN-04)

    Lifecycle: reserved → consumed (پرداخت موفق) | released (شکست/انصراف)
    رزرو اتمیک است؛ موجودی قابل مصرف = balance - مجموع رزروهای فعال.
    """
    STATUS_CHOICES = [
        ('reserved', 'رزرو شده'),
        ('consumed', 'مصرف شده'),
        ('released', 'آزاد شده'),
    ]

    user = models.ForeignKey(
        User,
        on_delete=models.PROTECT,
        related_name='credit_reservations',
        verbose_name='کاربر'
    )
    inspection_request = models.ForeignKey(
        'InspectionRequest',
        on_delete=models.PROTECT,
        related_name='credit_reservations',
        null=True,
        blank=True,
        verbose_name='درخواست بازرسی'
    )
    payment = models.ForeignKey(
        'Payment',
        on_delete=models.SET_NULL,
        related_name='credit_reservations',
        null=True,
        blank=True,
        verbose_name='پرداخت'
    )
    amount = models.DecimalField(
        max_digits=12,
        decimal_places=0,
        verbose_name='مبلغ رزرو شده (تومان)')
    status = models.CharField(
        max_length=20,
        choices=STATUS_CHOICES,
        default='reserved',
        verbose_name='وضعیت')
    created_at = jmodels.jDateTimeField(
        auto_now_add=True, verbose_name='تاریخ رزرو')
    consumed_at = jmodels.jDateTimeField(
        null=True, blank=True, verbose_name='تاریخ مصرف')
    released_at = jmodels.jDateTimeField(
        null=True, blank=True, verbose_name='تاریخ آزادسازی')

    def __str__(self):
        return f"{self.user.username} - {self.amount} - {self.status}"

    class Meta:
        verbose_name = 'رزرو اعتبار'
        verbose_name_plural = 'رزروهای اعتبار'

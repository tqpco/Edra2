from django.db import models
from django_jalali.db import models as jmodels
from django.contrib.auth import get_user_model

User = get_user_model()


class CityMultiplier(models.Model):
    """ضریب شهر و هزینه پایه ثابت"""
    city = models.CharField(max_length=80, unique=True, verbose_name='شهر')
    multiplier = models.DecimalField(
        max_digits=5,
        decimal_places=2,
        default=1.00,
        verbose_name='ضریب')
    base_cost = models.DecimalField(
        max_digits=12, decimal_places=0, default=100000,
        verbose_name='هزینه پایه شهر (تومان)',
        help_text='این مقدار در ضریب ضرب شده و به‌صورت هزینه ثابت به قیمت اضافه می‌شود.'
    )

    def __str__(self):
        return self.city

    class Meta:
        verbose_name = 'ضریب شهر'
        verbose_name_plural = 'ضرایب شهرها'


class Organization(models.Model):
    """سازمان"""
    name = models.CharField(max_length=150, verbose_name='نام')
    billing_contact = models.ForeignKey(
        User,
        on_delete=models.SET_NULL,
        null=True,
        related_name='orgs',
        verbose_name='تماس مالی'
    )

    def __str__(self):
        return self.name

    class Meta:
        verbose_name = 'سازمان'
        verbose_name_plural = 'سازمان‌ها'


class Project(models.Model):
    """پروژه"""
    organization = models.ForeignKey(
        Organization,
        on_delete=models.CASCADE,
        null=True,
        blank=True,
        verbose_name='سازمان'
    )
    name = models.CharField(max_length=150, verbose_name='نام')

    def __str__(self):
        return self.name

    class Meta:
        verbose_name = 'پروژه'
        verbose_name_plural = 'پروژه‌ها'

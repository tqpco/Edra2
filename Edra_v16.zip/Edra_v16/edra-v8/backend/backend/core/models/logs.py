from django.db import models
from django_jalali.db import models as jmodels
from django.contrib.auth import get_user_model

User = get_user_model()


class AuditLog(models.Model):
    """لاگ ممیزی"""
    user = models.ForeignKey(
        User,
        on_delete=models.SET_NULL,
        null=True,
        verbose_name='کاربر'
    )
    action = models.CharField(max_length=50, verbose_name='عملیات')
    object_id = models.PositiveIntegerField(verbose_name='شناسه شیء')
    changes = models.JSONField(verbose_name='تغییرات')
    timestamp = jmodels.jDateTimeField(auto_now_add=True, verbose_name='زمان')

    class Meta:
        verbose_name = 'لاگ ممیزی'
        verbose_name_plural = 'لاگ‌های ممیزی'


class SequenceCounter(models.Model):
    """شمارنده ترتیبی"""
    key = models.CharField(max_length=100, unique=True, verbose_name='کلید')
    value = models.PositiveIntegerField(default=0, verbose_name='مقدار')
    updated_at = models.DateTimeField(
        auto_now=True, verbose_name='تاریخ بروزرسانی')

    def __str__(self):
        return f"{self.key}: {self.value}"

    class Meta:
        verbose_name = 'شمارنده ترتیبی'
        verbose_name_plural = 'شمارنده‌های ترتیبی'


class ErrorLog(models.Model):
    """لاگ خطاهای سیستم"""
    SEVERITY_CHOICES = [
        ('debug', 'Debug'),
        ('info', 'Info'),
        ('warning', 'Warning'),
        ('error', 'Error'),
        ('critical', 'Critical'),
    ]

    error_id = models.CharField(
        max_length=20,
        unique=True,
        verbose_name='شناسه خطا')
    timestamp = models.DateTimeField(auto_now_add=True, verbose_name='زمان')
    severity = models.CharField(
        max_length=10,
        choices=SEVERITY_CHOICES,
        default='error',
        verbose_name='شدت')
    user = models.ForeignKey(
        User,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        verbose_name='کاربر'
    )
    path = models.CharField(max_length=500, verbose_name='مسیر')
    method = models.CharField(max_length=10, verbose_name='متد')
    status_code = models.PositiveSmallIntegerField(verbose_name='کد وضعیت')
    error_type = models.CharField(max_length=100, verbose_name='نوع خطا')
    error_message = models.TextField(verbose_name='پیام خطا')
    traceback = models.TextField(verbose_name='Traceback', blank=True)
    request_data = models.JSONField(
        default=dict, verbose_name='داده‌های درخواست')
    user_agent = models.CharField(
        max_length=500,
        blank=True,
        verbose_name='مرورگر')
    ip_address = models.CharField(
        max_length=50,
        blank=True,
        verbose_name='آی‌پی')
    resolved = models.BooleanField(default=False, verbose_name='برطرف شده')
    resolution_note = models.TextField(
        blank=True, verbose_name='توضیح رفع خطا')
    resolved_at = models.DateTimeField(
        null=True, blank=True, verbose_name='تاریخ رفع')
    resolved_by = models.ForeignKey(
        User,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name='resolved_errors',
        verbose_name='برطرف شده توسط'
    )

    class Meta:
        verbose_name = 'لاگ خطا'
        verbose_name_plural = 'لاگ‌های خطا'
        ordering = ['-timestamp']
        indexes = [
            models.Index(fields=['error_id']),
            models.Index(fields=['timestamp']),
            models.Index(fields=['status_code']),
            models.Index(fields=['resolved']),
        ]

    def __str__(self):
        return f"{self.error_id} - {self.error_type} - {self.timestamp}"

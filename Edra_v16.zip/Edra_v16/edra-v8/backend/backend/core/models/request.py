from django.db import models
from django_jalali.db import models as jmodels
from django.contrib.auth import get_user_model
from django.db import transaction
from django.utils import timezone

User = get_user_model()


class InspectionRequest(models.Model):
    """درخواست بازرسی"""
    STATUS_CHOICES = [
        ('draft', 'پیش‌نویس'),
        ('pending_payment', 'در انتظار پرداخت آنلاین'),
        ('waiting_manual_payment', 'در انتظار تایید فیش واریزی'),
        ('paid', 'پرداخت‌شده'),
        ('assigned', 'ارجاع‌شده به کارشناس'),
        ('scheduled', 'زمان‌بندی‌شده'),
        ('rescheduled', 'زمان‌بندی مجدد شده'),
        ('in_progress', 'در حال بازرسی'),
        ('completed', 'تکمیل‌شده'),
        ('cancelled', 'لغو‌شده'),
        ('expired', 'منقضی‌شده (عدم پرداخت طی ۴۸ ساعت)'),
    ]

    # فیلدهای جدید برای شناسایی درخواست
    title = models.CharField(
        max_length=200,
        blank=True,
        verbose_name='عنوان درخواست'
    )
    request_number = models.CharField(
        max_length=20,
        unique=True,
        blank=True,
        null=True,
        verbose_name='شماره درخواست'
    )

    customer = models.ForeignKey(
        User,
        on_delete=models.PROTECT,
        related_name='requests',
        verbose_name='مشتری'
    )
    project = models.ForeignKey(
        'Project',
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        verbose_name='پروژه'
    )
    equipment_type = models.ForeignKey(
        'EquipmentType',
        on_delete=models.PROTECT,
        verbose_name='نوع تجهیزات'
    )
    brand_model = models.CharField(
        max_length=200,
        verbose_name='برند/مدل',
        blank=True,
        null=True,
        default='نامشخص'
    )
    manufacture_year = models.PositiveSmallIntegerField(
        verbose_name='سال ساخت',
        blank=True,
        null=True,
        default=1990
    )
    params = models.JSONField(
        verbose_name='پارامترها',
        blank=True,
        null=True,
        default=dict
    )
    install_state = models.CharField(
        max_length=20,
        null=True,
        blank=True,
        verbose_name='وضعیت نصب')
    SERVICE_TYPE_CHOICES = [
        ('standard', 'استاندارد'),
        ('pro', 'حرفه‌ای'),
    ]
    service_type = models.CharField(
        max_length=20,
        choices=SERVICE_TYPE_CHOICES,
        default='standard',
        verbose_name='سطح سرویس')
    city = models.CharField(max_length=80, verbose_name='شهر')
    address = models.TextField(verbose_name='آدرس')
    address_lat = models.DecimalField(
        max_digits=9, decimal_places=6, null=True, blank=True,
        verbose_name='عرض جغرافیایی آدرس',
        help_text='برای مقایسه با GPS کارشناس در سرویس ضدتقلب')
    address_lng = models.DecimalField(
        max_digits=9, decimal_places=6, null=True, blank=True,
        verbose_name='طول جغرافیایی آدرس')
    scheduled_at = jmodels.jDateTimeField(
        null=True, blank=True, verbose_name='زمان بازرسی')
    assigned_expert = models.ForeignKey(
        User,
        on_delete=models.SET_NULL,
        null=True,
        related_name='assigned_requests',
        verbose_name='کارشناس'
    )
    calculated_price = models.DecimalField(
        max_digits=12,
        decimal_places=0,
        verbose_name='قیمت محاسبه‌شده')
    discount_code = models.ForeignKey(
        'DiscountCode',
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        verbose_name='کد تخفیف'
    )
    final_price = models.DecimalField(
        max_digits=12,
        decimal_places=0,
        verbose_name='قیمت نهایی')
    status = models.CharField(
        max_length=30,
        choices=STATUS_CHOICES,
        default='draft',
        verbose_name='وضعیت')
    created_at = jmodels.jDateTimeField(
        auto_now_add=True, verbose_name='تاریخ ایجاد')
    updated_at = jmodels.jDateTimeField(
        auto_now=True, verbose_name='تاریخ بروزرسانی')

    def save(self, *args, **kwargs):
        if not self.request_number:
            from .logs import SequenceCounter
            # استفاده از transaction.atomic و select_for_update برای جلوگیری از شماره‌های تکراری
            # فرمت طبق سند معماری: IR-YYYY-XXXXX (شمارنده هرسال از نو شروع می‌شود)
            with transaction.atomic():
                year = timezone.now().year
                counter, _ = SequenceCounter.objects.select_for_update(
                ).get_or_create(key=f'inspection_request_{year}')
                counter.value += 1
                counter.save()
                self.request_number = f"IR-{year}-{counter.value:05d}"
        super().save(*args, **kwargs)

    def __str__(self):
        return f"{self.request_number} - {self.title or self.customer.get_full_name()}"

    class Meta:
        verbose_name = 'درخواست کارشناسی'
        verbose_name_plural = 'درخواست‌های کارشناسی'
        ordering = ['-created_at']


class DiscountCode(models.Model):
    """کد تخفیف"""
    DISCOUNT_TYPES = [
        ('percent', 'درصد'),
        ('fixed', 'مبلغ ثابت')
    ]

    code = models.CharField(max_length=50, unique=True, verbose_name='کد')
    discount_type = models.CharField(
        max_length=10,
        choices=DISCOUNT_TYPES,
        verbose_name='نوع تخفیف'
    )
    value = models.DecimalField(
        max_digits=10,
        decimal_places=0,
        verbose_name='مقدار')
    min_amount = models.DecimalField(
        max_digits=12,
        decimal_places=0,
        null=True,
        blank=True,
        verbose_name='حداقل مبلغ')
    max_amount = models.DecimalField(
        max_digits=12,
        decimal_places=0,
        null=True,
        blank=True,
        verbose_name='حداکثر مبلغ')
    equipment_type = models.ForeignKey(
        'EquipmentType',
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        verbose_name='نوع تجهیزات'
    )
    # ✅ فیلد جدید: اعمال تخفیف برای همه تجهیزات
    apply_to_all = models.BooleanField(
        default=False,
        verbose_name='اعمال برای همه تجهیزات'
    )
    usage_limit = models.PositiveIntegerField(
        null=True, blank=True, verbose_name='محدودیت استفاده')
    used_count = models.PositiveIntegerField(
        default=0, verbose_name='تعداد استفاده')
    per_user_limit = models.PositiveIntegerField(
        default=1, verbose_name='محدودیت هر کاربر')
    expires_at = models.DateTimeField(
        null=True, blank=True, verbose_name='تاریخ انقضا')
    is_active = models.BooleanField(default=True, verbose_name='فعال')
    description = models.TextField(blank=True, verbose_name='توضیحات')

    class Meta:
        verbose_name = 'کد تخفیف'
        verbose_name_plural = 'کدهای تخفیف'

    def __str__(self):
        return self.code

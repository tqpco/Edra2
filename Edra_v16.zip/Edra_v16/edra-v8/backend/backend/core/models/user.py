from django.db import models
from django_jalali.db import models as jmodels
from django.contrib.auth import get_user_model
from django.core.validators import RegexValidator

User = get_user_model()


class UserProfile(models.Model):
    """پروفایل کاربر با شماره تماس، اطلاعات حقوقی و پروژه‌ها"""
    user = models.OneToOneField(
        User,
        on_delete=models.CASCADE,
        related_name='profile',
        verbose_name='کاربر'
    )
    phone = models.CharField(
        max_length=15,
        unique=True,
        validators=[
            RegexValidator(
                r'^09\d{9}$',
                'شماره موبایل باید با 09 شروع شود و 11 رقم باشد.')],
        verbose_name='شماره موبایل')
    # ✅ فیلد جدید: شماره ثبت/کد ملی (برای اشخاص حقوقی یا حقیقی)
    registration_number = models.CharField(
        max_length=50,
        blank=True,
        verbose_name='شماره ثبت / کد ملی'
    )
    company_name = models.CharField(
        max_length=200,
        blank=True,
        verbose_name='نام شرکت'
    )
    # ✅ تغییر به ManyToManyField برای امکان انتخاب چندین پروژه
    projects = models.ManyToManyField(
        'Project',
        blank=True,
        verbose_name='پروژه‌ها'
    )
    # فقط برای کاربران نقش Expert معنا دارد: شهرهایی که کارشناس پوشش
    # می‌دهد - برای پیشنهاد هوشمند تخصیص کارشناس به درخواست استفاده می‌شود.
    covered_cities = models.ManyToManyField(
        'CityMultiplier',
        blank=True,
        related_name='covering_experts',
        verbose_name='شهرهای تحت پوشش (کارشناس)')
    # فیلدهای پروفایل کارشناس - قبلاً در profile_views.py استفاده می‌شدند
    # ولی هیچ‌جای مدل تعریف نشده بودند (باعث می‌شد ذخیره‌شان بی‌اثر باشد)
    bio = models.TextField(
        blank=True, verbose_name='بیوگرافی (کارشناس)')
    expertise = models.CharField(
        max_length=255, blank=True, verbose_name='حوزه تخصص (کارشناس)')
    years_experience = models.PositiveSmallIntegerField(
        null=True, blank=True, verbose_name='سابقه کار به سال (کارشناس)')
    created_at = jmodels.jDateTimeField(
        auto_now_add=True, verbose_name='تاریخ ایجاد')
    updated_at = jmodels.jDateTimeField(
        auto_now=True, verbose_name='تاریخ بروزرسانی')

    def __str__(self):
        return f"{self.user.get_full_name()} - {self.phone}"

    class Meta:
        verbose_name = 'پروفایل کاربر'
        verbose_name_plural = 'پروفایل‌های کاربران'


class OTPCode(models.Model):
    """کد تایید"""
    phone = models.CharField(max_length=15, verbose_name='شماره موبایل')
    code = models.CharField(max_length=6, verbose_name='کد')
    created_at = models.DateTimeField(
        auto_now_add=True, verbose_name='تاریخ ایجاد')
    is_used = models.BooleanField(default=False, verbose_name='استفاده شده')
    attempts = models.PositiveSmallIntegerField(
        default=0, verbose_name='تعداد تلاش')

    class Meta:
        indexes = [models.Index(fields=['phone', 'created_at'])]
        verbose_name = 'کد تایید'
        verbose_name_plural = 'کدهای تایید'

    def __str__(self):
        # EDRA v6 — P1: کد OTP یک credential کوتاه‌عمر است و نباید در
        # نمایش/لاگ‌ها درز کند (قبلاً خود code برمی‌گشت).
        return f"OTP {self.phone} ({'استفاده‌شده' if self.is_used else 'معتبر'})"

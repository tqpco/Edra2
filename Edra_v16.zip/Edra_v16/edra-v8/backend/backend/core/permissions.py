# ============================================================
# ۱. فایل core/permissions.py (کامل)
# مسیر: backend/core/permissions.py
# ============================================================
from rest_framework.permissions import BasePermission, SAFE_METHODS
from guardian.shortcuts import get_perms


def is_admin_user(user) -> bool:
    """
    EDRA v6 — P1 (نقش canonical): تعریف واحد Admin.
    قبلاً بعضی جاها فقط is_staff و بعضی فقط group=Admin بود؛ این ناسازگاری
    باعث می‌شد staff بدون گروه Admin در بعضی endpointها دسترسی مدیریتی
    داشته باشد ولی queryset کامل نگیرد. همه‌جا باید از همین helper استفاده
    شود.
    """
    return bool(
        user and user.is_authenticated
        and (user.is_staff
             or user.is_superuser
             or user.groups.filter(name='Admin').exists()))


def is_expert_user(user) -> bool:
    return bool(
        user and user.is_authenticated
        and user.groups.filter(name='Expert').exists())


def is_support_user(user) -> bool:
    return bool(
        user and user.is_authenticated
        and user.groups.filter(name='Support').exists())


class IsAdminGroup(BasePermission):
    """کاربر باید عضو گروه Admin باشد"""

    def has_permission(self, request, view):
        return request.user and request.user.is_authenticated and request.user.groups.filter(
            name='Admin').exists()


class IsAdminOrReadOnly(BasePermission):
    """
    CRITICAL-02 / HIGH-09: برای resourceهای مدیریتی (Blog/FAQ/KB/Announcement/
    SavedReply) — خواندن برای همه مجاز است (یا طبق نیاز احراز هویت)، ولی
    create/update/delete فقط برای Admin (is_staff یا گروه Admin).

    این کلاس جایگزین ترکیب‌های ناامن `IsAuthenticatedOrReadOnly` / `AllowAny`
    روی ModelViewSet می‌شود که در عمل متدهای write را برای کاربر عادی باز
    می‌کردند.
    """

    #: اگر True باشد، متدهای خواندن نیاز به احراز هویت دارند (برای
    #: Announcement/SavedReply که محتوای داخلی دارند).
    require_auth_for_read = False
    #: نقش‌های دیگری که علاوه بر Admin اجازه‌ی write دارند (مثلاً Support
    #: برای SavedReply).
    write_groups = ('Admin',)

    def _is_admin(self, user):
        return bool(
            user and user.is_authenticated
            and (user.is_staff or user.groups.filter(
                name__in=self.write_groups).exists()))

    def has_permission(self, request, view):
        if request.method in SAFE_METHODS:
            if self.require_auth_for_read:
                return bool(
                    request.user and request.user.is_authenticated)
            return True
        return self._is_admin(request.user)


class IsAdminOrSupportOrReadOnly(IsAdminOrReadOnly):
    """خواندن برای کاربران احراز هویت‌شده؛ write فقط Admin یا Support."""
    require_auth_for_read = True
    write_groups = ('Admin', 'Support')


class IsAdminOrAuthenticatedReadOnly(IsAdminOrReadOnly):
    """خواندن برای کاربران احراز هویت‌شده؛ write فقط Admin."""
    require_auth_for_read = True


class IsAdminUserOrGroup(BasePermission):
    """
    یکسان‌سازی مجوز ادمین: یا is_staff است (DRF IsAdminUser) یا عضو گروه
    Admin. ادمین‌های پنل که از طریق گروه ساخته شده‌اند (بدون is_staff)
    باید به تمام endpoint های مدیریتی دسترسی داشته باشند.
    """

    def has_permission(self, request, view):
        if not request.user or not request.user.is_authenticated:
            return False
        return request.user.is_staff or request.user.groups.filter(
            name='Admin').exists()


class IsExpertGroup(BasePermission):
    """کاربر باید عضو گروه Expert باشد"""

    def has_permission(self, request, view):
        return request.user and request.user.is_authenticated and request.user.groups.filter(
            name='Expert').exists()


class IsAdminOrExpert(BasePermission):
    """کاربر یا Admin است یا Expert"""

    def has_permission(self, request, view):
        if not request.user or not request.user.is_authenticated:
            return False
        return request.user.groups.filter(
            name__in=['Admin', 'Expert']).exists()


class IsCustomerOrAdmin(BasePermission):
    """کاربر یا Admin است یا مالک درخواست (مشتری)"""

    def has_object_permission(self, request, view, obj):
        if request.user.groups.filter(name='Admin').exists():
            return True
        if hasattr(obj, 'customer'):
            return obj.customer == request.user
        return False


class ObjectPermissionForInspectionReport(BasePermission):
    """
    مجوز سطح شیء برای InspectionReport
    """

    def has_object_permission(self, request, view, obj):
        if request.user.groups.filter(name='Admin').exists():
            return True
        perms = get_perms(request.user, obj)
        if request.method in SAFE_METHODS:
            return 'view_inspectionreport' in perms
        elif request.method in ['PUT', 'PATCH']:
            return 'change_inspectionreport' in perms
        elif request.method == 'DELETE':
            return 'delete_inspectionreport' in perms
        return False


class IsAdminOrHasObjectPermissionForInspectionRequest(BasePermission):
    """
    مجوز برای InspectionRequest (EDRA v6 — P1 defense-in-depth):

    قبلاً GET در has_object_permission برای همه برمی‌گشت True و امنیت فقط
    به queryset ViewSet وابسته بود؛ اگر View دیگری از این permission استفاده
    می‌کرد و queryset را فراموش می‌کرد، IDOR رخ می‌داد. حالا مالکیت در
    خود permission هم enforce می‌شود:
      - Admin (is_staff یا گروه Admin) → کامل
      - مالک مشتری / کارشناس assigned → کامل
      - بقیه → رد
    """

    def has_permission(self, request, view):
        return bool(request.user and request.user.is_authenticated)

    def has_object_permission(self, request, view, obj):
        user = request.user
        if not user or not user.is_authenticated:
            return False
        if is_admin_user(user):
            return True
        # مالکیت (defense-in-depth — مستقل از queryset)
        if hasattr(obj, 'customer') and obj.customer_id == user.id:
            return True
        if (hasattr(obj, 'assigned_expert_id')
                and obj.assigned_expert_id == user.id):
            return True
        # مجوزهای صریح guardian (موارد خاص)
        perms = get_perms(user, obj)
        if request.method in SAFE_METHODS:
            return 'view_inspectionrequest' in perms
        if request.method in ['PUT', 'PATCH']:
            return 'change_inspectionrequest' in perms
        if request.method == 'DELETE':
            return 'delete_inspectionrequest' in perms
        return False

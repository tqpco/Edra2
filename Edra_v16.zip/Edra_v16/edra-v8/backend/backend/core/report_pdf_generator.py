# core/report_pdf_generator.py
import io
from django.template.loader import render_to_string
import os
from django.conf import settings
from weasyprint import HTML


def generate_report_pdf(
        report,
        inspection_request,
        customer,
        equipment,
        checklist_items):
    context = {
        'report': report,
        'request': inspection_request,
        'customer': customer,
        'equipment': equipment,
        'checklist_items': checklist_items,
    }
    html_string = render_to_string('report_pdf.html', context)
    pdf_file = HTML(string=html_string, base_url=settings.BASE_DIR).write_pdf()
    return pdf_file

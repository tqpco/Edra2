# core/security.py
"""
ابزارهای امنیتی مشترک — EDRA v8 (P1-07).

پس از تغییر رمز عبور، تمام refresh token های صادرشده قبلی باید باطل
شوند؛ در غیر این صورت یک refresh token دزدیده‌شده (با طول عمر ۷ روز)
تا انقضا معتبر می‌ماند. این helper همه OutstandingToken های کاربر را
blacklist می‌کند (همان مکانیزم logout).
"""
import logging

logger = logging.getLogger(__name__)


def revoke_user_refresh_tokens(user) -> int:
    """
    باطل کردن همه refresh token های فعال یک کاربر (blacklist).

    Returns: تعداد توکن‌های باطل‌شده.
    اگر app ساده‌ج‌دبلیوتی blacklist فعال نباشد یا خطایی رخ دهد،
    خطا لاگ می‌شود و 0 برمی‌گردد (بدون شکستن مسیر تغییر رمز).
    """
    try:
        from rest_framework_simplejwt.token_blacklist.models import (
            BlacklistedToken,
            OutstandingToken,
        )
        tokens = OutstandingToken.objects.filter(user=user)
        revoked = 0
        for token in tokens:
            if not hasattr(token, 'blacklisted') or not token.blacklisted:
                BlacklistedToken.objects.get_or_create(token=token)
                revoked += 1
        if revoked:
            logger.info(
                f"Revoked {revoked} refresh token(s) for user {user.id} "
                "after password change")
        return revoked
    except Exception as exc:  # pragma: no cover - defensive
        logger.warning(
            f"Could not revoke refresh tokens for user {user.id}: {exc}")
        return 0

# backend/core/serializers.py
from rest_framework import serializers
from django.contrib.auth import get_user_model
from django.utils import timezone
from .models import (
    EquipmentType, CityMultiplier, Organization, Project,
    InspectionRequest, DiscountCode, AuditLog, OTPCode,
    PaymentMethod, Payment, Invoice, UserCredit, CreditTransaction,
    ChecklistTemplate, ChecklistItem, InspectionReport,
    ReportVerification, SequenceCounter, ErrorLog
)
from .utils.date_utils import to_jalali
from core.utils.date_utils import (
    to_jalali,
    get_created_at_jalali,
    get_updated_at_jalali,
    get_scheduled_at_jalali,
    get_expires_at_jalali,
    get_due_date_jalali,
    get_signed_at_jalali,
    get_last_viewed_at_jalali,
    get_timestamp_jalali,
    get_resolved_at_jalali,
    get_verified_at_jalali,
    get_rejected_at_jalali,
    get_bank_receipt_uploaded_at_jalali,
    get_paid_at_jalali,
    get_issue_date_jalali,
    get_closed_at_jalali,
    get_sent_at_jalali,
    get_used_at_jalali,
    get_last_run_at_jalali,
    get_date_joined_jalali,
)


User = get_user_model()


# ============================================================
# سریالایزرهای پایه
# ============================================================

class EquipmentTypeSerializer(serializers.ModelSerializer):
    class Meta:
        model = EquipmentType
        fields = '__all__'


class CityMultiplierSerializer(serializers.ModelSerializer):
    class Meta:
        model = CityMultiplier
        fields = '__all__'   # شامل base_cost و multiplier


class OrganizationSerializer(serializers.ModelSerializer):
    class Meta:
        model = Organization
        fields = '__all__'


class ProjectSerializer(serializers.ModelSerializer):
    class Meta:
        model = Project
        fields = '__all__'


# ============================================================
# سریالایزر کاربر (فقط بخش مربوطه)
# ============================================================

class UserSerializer(serializers.ModelSerializer):
    full_name = serializers.SerializerMethodField()
    date_joined_jalali = serializers.SerializerMethodField()
    # HIGH-21: نقش نهایی به‌صورت صریح از سمت backend برمی‌گردد تا frontend
    # مجبور نباشد از چند flag (is_staff/is_superuser/groups) نقش را حدس بزند.
    # قرارداد مشترک: admin = is_staff یا عضو گروه Admin؛ expert = گروه Expert؛
    # در غیر این صورت customer.
    role = serializers.SerializerMethodField()
    # ✅ فیلدهای جدید از پروفایل
    registration_number = serializers.CharField(
        source='profile.registration_number', read_only=True, allow_null=True)
    company_name = serializers.CharField(
        source='profile.company_name',
        read_only=True,
        allow_null=True)
    projects = serializers.PrimaryKeyRelatedField(
        source='profile.projects', many=True, read_only=True)
    project_names = serializers.SerializerMethodField()
    # نام گروه‌ها (نقش) - قبلاً اینجا نبود و فرانت‌اند هیچ راهی برای
    # تشخیص «این کاربر کارشناس است یا مشتری» نداشت (چون نقش‌ها با
    # django.contrib.auth.Group مدیریت می‌شوند، نه یک فیلد role ساده)
    groups = serializers.SlugRelatedField(
        slug_field='name', many=True, read_only=True)
    phone = serializers.CharField(
        source='profile.phone', read_only=True, allow_null=True)

    class Meta:
        model = User
        fields = (
            'id', 'username', 'email', 'first_name', 'last_name', 'full_name',
            'is_staff', 'is_superuser', 'groups', 'role', 'phone', 'date_joined', 'date_joined_jalali',
            'registration_number', 'company_name', 'projects', 'project_names'
        )

    def get_full_name(self, obj):
        return obj.get_full_name() or obj.username

    def get_date_joined_jalali(self, obj):
        return to_jalali(obj.date_joined)

    def get_role(self, obj):
        if obj.is_staff or obj.is_superuser:
            return 'admin'
        if obj.groups.filter(name='Admin').exists():
            return 'admin'
        if obj.groups.filter(name='Expert').exists():
            return 'expert'
        return 'customer'

    def get_project_names(self, obj):
        if hasattr(obj, 'profile') and obj.profile:
            return [p.name for p in obj.profile.projects.all()]
        return []


# ============================================================
# سریالایزر InspectionRequest
# ============================================================

class InspectionRequestSerializer(serializers.ModelSerializer):
    equipment_type_name = serializers.CharField(
        source='equipment_type.name_fa', read_only=True)
    customer_name = serializers.CharField(
        source='customer.username', read_only=True)
    assigned_expert_name = serializers.CharField(
        source='assigned_expert.username', read_only=True)
    created_at_jalali = serializers.SerializerMethodField()
    updated_at_jalali = serializers.SerializerMethodField()
    scheduled_at_jalali = serializers.SerializerMethodField()
    # مشتری کد تخفیف را به‌صورت رشته (مثلاً "SUMMER1405") وارد می‌کند، نه
    # شناسه عددی دیتابیس - قبلاً این فیلد چون ModelSerializer خودکار آن را
    # PrimaryKeyRelatedField می‌ساخت، فقط یک عدد ID قبول می‌کرد که هیچ
    # مشتری‌ای نمی‌دانست چیست.
    discount_code = serializers.SlugRelatedField(
        slug_field='code',
        queryset=DiscountCode.objects.all(),
        required=False,
        allow_null=True,
    )

    class Meta:
        model = InspectionRequest
        fields = '__all__'
        read_only_fields = (
            'customer',
            'calculated_price',
            'final_price',
            'created_at',
            'updated_at')

    def get_created_at_jalali(self, obj):
        return to_jalali(obj.created_at)

    def get_updated_at_jalali(self, obj):
        return to_jalali(obj.updated_at)

    def get_scheduled_at_jalali(self, obj):
        return to_jalali(obj.scheduled_at)

    def validate_scheduled_at(self, value):
        """
        قوانین زمان‌بندی کارشناسی (طبق مستند نیازمندی‌ها):
        - جمعه‌ها جزو بازه کاری نیست
        - فقط بین ساعت ۸:۰۰ تا ۱۶:۰۰ قابل انتخاب است
        - حداقل باید برای «فردا» یا بعد از آن باشد (امروز/گذشته مجاز نیست)
        توجه: این فقط رد کردن مقادیر نامعتبر است؛ محاسبه‌ی «نزدیک‌ترین زمان
        مجاز» (با در نظر گرفتن پنج‌شنبه/جمعه) وظیفه‌ی فرانت‌اند (تقویم) است.
        """
        # مقدار می‌تواند datetime استاندارد یا jdatetime.datetime باشد
        dt = value.togregorian() if hasattr(value, 'togregorian') else value

        now = timezone.now()
        if timezone.is_naive(dt):
            dt = timezone.make_aware(dt, timezone.get_current_timezone())
        now_local = timezone.localtime(now)
        dt_local = timezone.localtime(dt)

        if dt_local.date() <= now_local.date():
            raise serializers.ValidationError(
                'زمان کارشناسی باید حداقل از فردا به بعد انتخاب شود.')

        if dt_local.weekday() == 4:  # Python: Monday=0 ... Friday=4
            raise serializers.ValidationError(
                'جمعه‌ها جزو بازه کاری نیست، لطفاً روز دیگری انتخاب کنید.')

        if not (8 <= dt_local.hour < 16 or (dt_local.hour == 16 and dt_local.minute == 0)):
            raise serializers.ValidationError(
                'زمان کارشناسی فقط بین ساعت ۸:۰۰ تا ۱۶:۰۰ قابل انتخاب است.')

        return value

    def validate(self, attrs):
        # discount_code روی این سریالایزر یک ForeignKey است؛ در create()
        # به‌عنوان شیء معتبرشده در دسترس است، اینجا فقط فعال/منقضی بودن
        # و محدودیت‌های استفاده را بررسی می‌کنیم.
        discount = attrs.get('discount_code')
        if discount:
            request = self.context.get('request')
            if not discount.is_active:
                raise serializers.ValidationError(
                    {'discount_code': 'این کد تخفیف غیرفعال است.'})
            if discount.expires_at and discount.expires_at < timezone.now():
                raise serializers.ValidationError(
                    {'discount_code': 'این کد تخفیف منقضی شده است.'})
            if discount.usage_limit and discount.used_count >= discount.usage_limit:
                raise serializers.ValidationError(
                    {'discount_code': 'ظرفیت استفاده از این کد تخفیف تمام شده است.'})
            equipment_type = attrs.get('equipment_type')
            if (not discount.apply_to_all and discount.equipment_type_id
                    and equipment_type and discount.equipment_type_id != equipment_type.id):
                raise serializers.ValidationError(
                    {'discount_code': 'این کد تخفیف برای این نوع تجهیزات معتبر نیست.'})
            if discount.per_user_limit and request and request.user.is_authenticated:
                used_by_user = InspectionRequest.objects.filter(
                    customer=request.user, discount_code=discount
                ).count()
                if used_by_user >= discount.per_user_limit:
                    raise serializers.ValidationError(
                        {'discount_code': 'شما قبلاً از این کد تخفیف استفاده کرده‌اید.'})
        return attrs

    def create(self, validated_data):
        from pricing.utils import calculate_price_with_components

        request = self.context.get('request')
        equipment_type = validated_data['equipment_type']
        params = validated_data.get('params') or {}
        install_state = validated_data.get('install_state')
        city = validated_data.get('city')
        service_type = validated_data.get('service_type', 'standard')
        discount = validated_data.get('discount_code')

        components = calculate_price_with_components(
            equipment_type, params, install_state,
            city_name=city, service_type=service_type,
        )
        calculated_price = components['total']

        final_price = calculated_price
        if discount:
            # P1-02 (EDRA v8): شمارش used_count باید اتمیک (select_for_update)
            # و درون تراکنش باشد تا دو درخواست همزمان از usage_limit عبور
            # نکنند. قبلاً used_count بدون قفل read-modify-write می‌شد.
            from django.db import transaction
            with transaction.atomic():
                discount = DiscountCode.objects.select_for_update().get(
                    pk=discount.pk)
                # بررسی مجدد ظرفیت درون قفل
                if discount.usage_limit and discount.used_count >= discount.usage_limit:
                    raise serializers.ValidationError(
                        {'discount_code': 'ظرفیت استفاده از این کد تخفیف تمام شده است.'})
                if discount.per_user_limit and request and request.user.is_authenticated:
                    used_by_user = InspectionRequest.objects.filter(
                        customer=request.user, discount_code=discount
                    ).count()
                    if used_by_user >= discount.per_user_limit:
                        raise serializers.ValidationError(
                            {'discount_code': 'شما قبلاً از این کد تخفیف استفاده کرده‌اید.'})
                if discount.min_amount and calculated_price < discount.min_amount:
                    raise serializers.ValidationError(
                        {'discount_code': 'مبلغ درخواست کمتر از حداقل مجاز برای این کد تخفیف است.'})
                if discount.discount_type == 'percent':
                    discount_amount = calculated_price * discount.value / 100
                else:
                    discount_amount = discount.value
                if discount.max_amount:
                    discount_amount = min(discount_amount, discount.max_amount)
                final_price = max(calculated_price - discount_amount, 0)

                discount.used_count = discount.used_count + 1
                discount.save(update_fields=['used_count'])

        # مشتری: اگر view از طریق save(customer=...) مقدار داده باشد از آن
        # استفاده کن؛ در غیر این صورت request.user. (باگ قبلی: همیشه
        # request.user جایگزین می‌شد و ثبت درخواست توسط کاربر ناشناس با
        # AnonymousUser به خطای 500 می‌خورد.)
        customer = validated_data.get('customer') or (
            request.user if request else None)
        validated_data['customer'] = customer
        validated_data['calculated_price'] = calculated_price
        validated_data['final_price'] = final_price
        validated_data.setdefault('status', 'draft')
        return super().create(validated_data)


class InspectionRequestUpdateSerializer(InspectionRequestSerializer):
    """
    CRITICAL-01: serializer مخصوص update/partial_update.

    مالکیت object نباید به معنی اختیار تغییر تمام فیلدها باشد. فیلدهای
    workflow و مالی فقط از طریق actionهای server-side تغییر می‌کنند:
      - status        → pay / assign_expert / schedule / start / complete / cancel
      - assigned_expert → assign_expert (فقط Admin)
      - مبالغ/فاکتور/پرداخت → PaymentService / InvoiceService
    بنابراین این فیلدها در اینجا read-only هستند.
    """

    # EDRA v5 — CRITICAL-10: فیلدهای هویت business که بعد از پرداخت
    # immutable می‌شوند (تغییر تجهیز/پارامتر/آدرس بعد از پرداخت باعث
    # ناسازگاری با فاکتور/بازرسی می‌شود).
    PROTECTED_AFTER_PAID = {
        'equipment_type', 'params', 'city', 'address', 'brand_model',
        'manufacture_year', 'service_type', 'install_state', 'scheduled_at',
    }

    class Meta(InspectionRequestSerializer.Meta):
        read_only_fields = InspectionRequestSerializer.Meta.read_only_fields + (
            'status',
            'assigned_expert',
            'request_number',
            'discount_code',
            'project',
        )

    def validate(self, attrs):
        instance = getattr(self, 'instance', None)
        if instance is not None:
            editable_states = {
                'draft', 'pending_payment', 'waiting_manual_payment',
                'rejected', 'cancelled', 'expired',
            }
            if instance.status not in editable_states:
                changed = set(attrs.keys()) & self.PROTECTED_AFTER_PAID
                if changed:
                    raise serializers.ValidationError(
                        {'detail': (
                            f'پس از پرداخت، فیلدهای '
                            f'{", ".join(sorted(changed))} قابل تغییر نیستند. '
                            'برای تغییر باید از پشتیبانی استفاده کنید.')})
        return attrs


class InspectionRequestListSerializer(InspectionRequestSerializer):
    """
    P1-01: serializer سبک برای list (بدون nested سنگین) — کاهش payload و
    تعداد کوئری. فیلدهای لازم برای جدول‌های فرانت‌اند در دسترس هستند.
    """

    class Meta(InspectionRequestSerializer.Meta):
        fields = (
            'id', 'title', 'request_number', 'status', 'city', 'address',
            'brand_model', 'install_state', 'service_type', 'params',
            'final_price', 'calculated_price', 'scheduled_at',
            'equipment_type', 'equipment_type_name',
            'customer', 'customer_name', 'assigned_expert',
            'assigned_expert_name', 'project', 'created_at',
            'created_at_jalali', 'updated_at_jalali',
            'scheduled_at_jalali',
        )
        read_only_fields = InspectionRequestSerializer.Meta.read_only_fields + (
            'status', 'assigned_expert', 'request_number', 'project',
        )


# ============================================================
# سریالایزر DiscountCode
# ============================================================

class DiscountCodeSerializer(serializers.ModelSerializer):
    equipment_type_name = serializers.CharField(
        source='equipment_type.name_fa', read_only=True, allow_null=True)
    expires_at_jalali = serializers.SerializerMethodField()

    class Meta:
        model = DiscountCode
        fields = '__all__'
        read_only_fields = ('id', 'used_count')

    def get_expires_at_jalali(self, obj):
        return to_jalali(obj.expires_at)


# ============================================================
# سریالایزرهای Payment و Invoice
# ============================================================

class PaymentMethodSerializer(serializers.ModelSerializer):
    class Meta:
        model = PaymentMethod
        fields = '__all__'


class PaymentSerializer(serializers.ModelSerializer):
    created_at_jalali = serializers.SerializerMethodField()
    updated_at_jalali = serializers.SerializerMethodField()
    verified_at_jalali = serializers.SerializerMethodField()
    rejected_at_jalali = serializers.SerializerMethodField()
    bank_receipt_uploaded_at_jalali = serializers.SerializerMethodField()

    class Meta:
        model = Payment
        fields = '__all__'
        # فیلدهای مالی/وضعیت فقط server-controlled (SEC-01/FIN-05):
        # مشتری نباید بتواند status/authority/ref_id/amount را مستقیم بنویسد.
        read_only_fields = [
            'status', 'authority', 'ref_id', 'transaction_id',
            'amount', 'amount_rial', 'credit_amount', 'online_amount',
            'manual_amount', 'verified_by', 'verified_at',
            'rejected_by', 'rejected_at', 'rejection_reason',
        ]

    def get_created_at_jalali(self, obj):
        return to_jalali(obj.created_at)

    def get_updated_at_jalali(self, obj):
        return to_jalali(obj.updated_at)

    def get_verified_at_jalali(self, obj):
        return to_jalali(obj.verified_at)

    def get_rejected_at_jalali(self, obj):
        return to_jalali(obj.rejected_at)

    def get_bank_receipt_uploaded_at_jalali(self, obj):
        return to_jalali(obj.bank_receipt_uploaded_at)


class InvoiceSerializer(serializers.ModelSerializer):
    issue_date_jalali = serializers.SerializerMethodField()
    due_date_jalali = serializers.SerializerMethodField()
    paid_at_jalali = serializers.SerializerMethodField()

    class Meta:
        model = Invoice
        fields = '__all__'

    def get_issue_date_jalali(self, obj):
        return to_jalali(obj.issue_date)

    def get_due_date_jalali(self, obj):
        return to_jalali(obj.due_date)

    def get_paid_at_jalali(self, obj):
        return to_jalali(obj.paid_at)


# ============================================================
# سریالایزرهای اعتبار
# ============================================================

class UserCreditSerializer(serializers.ModelSerializer):
    updated_at_jalali = serializers.SerializerMethodField()

    class Meta:
        model = UserCredit
        fields = '__all__'

    def get_updated_at_jalali(self, obj):
        return to_jalali(obj.updated_at)


class CreditTransactionSerializer(serializers.ModelSerializer):
    created_at_jalali = serializers.SerializerMethodField()

    class Meta:
        model = CreditTransaction
        fields = '__all__'

    def get_created_at_jalali(self, obj):
        return to_jalali(obj.created_at)


# ============================================================
# سریالایزرهای چک‌لیست و گزارش
# ============================================================

class ChecklistItemSerializer(serializers.ModelSerializer):
    class Meta:
        model = ChecklistItem
        fields = '__all__'


class ChecklistTemplateSerializer(serializers.ModelSerializer):
    items = ChecklistItemSerializer(many=True, read_only=True)
    created_at_jalali = serializers.SerializerMethodField()
    updated_at_jalali = serializers.SerializerMethodField()

    class Meta:
        model = ChecklistTemplate
        fields = '__all__'

    def get_created_at_jalali(self, obj):
        return to_jalali(obj.created_at)

    def get_updated_at_jalali(self, obj):
        return to_jalali(obj.updated_at)


class InspectionReportSerializer(serializers.ModelSerializer):
    inspection_request_detail = InspectionRequestSerializer(
        source='inspection_request', read_only=True)
    overall_result_display = serializers.SerializerMethodField()
    created_at_jalali = serializers.SerializerMethodField()
    updated_at_jalali = serializers.SerializerMethodField()
    signed_at_jalali = serializers.SerializerMethodField()

    class Meta:
        model = InspectionReport
        fields = '__all__'
        read_only_fields = (
            'report_number',
            'created_at',
            'updated_at',
            'signed_at',
            'signature_hash')

    def get_overall_result_display(self, obj):
        return obj.get_overall_result_display() if obj.overall_result else None

    def get_created_at_jalali(self, obj):
        return to_jalali(obj.created_at)

    def get_updated_at_jalali(self, obj):
        return to_jalali(obj.updated_at)

    def get_signed_at_jalali(self, obj):
        return to_jalali(obj.signed_at)


class InspectionReportDetailSerializer(InspectionReportSerializer):
    pass


class ReportVerificationSerializer(serializers.ModelSerializer):
    report_number = serializers.CharField(
        source='report.report_number', read_only=True)
    inspection_request_id = serializers.IntegerField(
        source='report.inspection_request.id', read_only=True)
    equipment_name = serializers.CharField(
        source='report.inspection_request.equipment_type.name_fa',
        read_only=True)
    overall_result = serializers.CharField(
        source='report.overall_result', read_only=True)
    signed_at = serializers.DateTimeField(
        source='report.signed_at', read_only=True)
    created_at_jalali = serializers.SerializerMethodField()
    last_viewed_at_jalali = serializers.SerializerMethodField()

    class Meta:
        model = ReportVerification
        fields = '__all__'

    def get_created_at_jalali(self, obj):
        return to_jalali(obj.created_at)

    def get_last_viewed_at_jalali(self, obj):
        return to_jalali(obj.last_viewed_at)


# ============================================================
# سریالایزرهای لاگ‌ها
# ============================================================

class AuditLogSerializer(serializers.ModelSerializer):
    timestamp_jalali = serializers.SerializerMethodField()

    class Meta:
        model = AuditLog
        fields = '__all__'

    def get_timestamp_jalali(self, obj):
        return to_jalali(obj.timestamp)


class ErrorLogSerializer(serializers.ModelSerializer):
    timestamp_jalali = serializers.SerializerMethodField()
    resolved_at_jalali = serializers.SerializerMethodField()

    class Meta:
        model = ErrorLog
        fields = '__all__'

    def get_timestamp_jalali(self, obj):
        return to_jalali(obj.timestamp)

    def get_resolved_at_jalali(self, obj):
        return to_jalali(obj.resolved_at)


# ============================================================
# سریالایزرهای OTP
# ============================================================

class OTPRequestSerializer(serializers.Serializer):
    phone = serializers.CharField(max_length=15)


class OTPVerifySerializer(serializers.Serializer):
    phone = serializers.CharField(max_length=15)
    code = serializers.CharField(max_length=6)

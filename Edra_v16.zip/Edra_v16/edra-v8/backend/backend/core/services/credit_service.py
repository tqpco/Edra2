# core/services/credit_service.py
"""
سرویس مرکزی اعتبار — اصلاح FIN-04 از گزارش ممیزی

الزامات:
- رزرو اعتبار باید اتمیک باشد (select_for_update) و قابل مصرف/آزادسازی.
- در failure درگاه، اعتبار رزروشده آزاد می‌شود (rollback واقعی).
- موجودی قابل مصرف = balance - مجموع رزروهای فعال.
- همه تغییرات balance فقط از این سرویس انجام می‌شود و همیشه
  CreditTransaction ثبت می‌گردد (audit trail).
"""
import logging
from decimal import Decimal

from django.db import models, transaction
from django.utils import timezone

from ..models import CreditReservation, CreditTransaction, UserCredit

logger = logging.getLogger(__name__)


class InsufficientCreditError(Exception):
    """اعتبار کافی نیست."""


def _get_credit(user, create=True):
    if create:
        credit, _ = UserCredit.objects.get_or_create(user=user)
        return credit
    return UserCredit.objects.get(user=user)


def get_available_balance(user) -> Decimal:
    """موجودی قابل مصرف = balance - رزروهای فعال."""
    credit = _get_credit(user, create=False)
    reserved = CreditReservation.objects.filter(
        user=user, status='reserved'
    ).aggregate(total=models.Sum('amount'))
    reserved_total = reserved['total'] or Decimal('0')
    return credit.balance - reserved_total


class CreditService:
    """عملیات اتمیک روی اعتبار کاربر."""

    @classmethod
    def reserve(cls, user, amount, inspection_request=None, payment=None) -> CreditReservation:
        """
        رزرو اتمیک مبلغ از اعتبار. اگر موجودی قابل مصرف کافی نباشد
        InsufficientCreditError پرتاب می‌شود.
        """
        amount = Decimal(amount)
        if amount <= 0:
            raise ValueError("مبلغ رزرو باید مثبت باشد.")

        with transaction.atomic():
            credit = UserCredit.objects.select_for_update().get_or_create(
                user=user)[0]
            reserved_total = CreditReservation.objects.filter(
                user=user, status='reserved'
            ).aggregate(
                total=models.Sum('amount'))
            reserved_total = reserved_total['total'] or Decimal('0')
            available = credit.balance - reserved_total
            if available < amount:
                raise InsufficientCreditError(
                    f"اعتبار کافی نیست. موجودی قابل مصرف: {available:,} تومان")

            reservation = CreditReservation.objects.create(
                user=user,
                amount=amount,
                inspection_request=inspection_request,
                payment=payment,
                status='reserved',
            )
            logger.info(
                f"Credit reserved: user={user.id} amount={amount} "
                f"reservation={reservation.id}")
            return reservation

    @classmethod
    def consume(cls, reservation: CreditReservation, description='') -> Decimal:
        """
        مصرف رزرو: موجودی کسر و تراکنش ثبت می‌شود (اتمیک).
        فقط رزرو با status='reserved' قابل مصرف است.

        P0-05 (EDRA v9): خود ردیف Reservation هم با select_for_update قفل
        و refresh می‌شود؛ قبلاً فقط UserCredit قفل می‌شد و دو worker همزمان
        می‌توانستند یک Reservation را هر دو consume کنند (double debit).
        """
        if reservation.status != 'reserved':
            raise ValueError(
                f"رزرو {reservation.id} در وضعیت {reservation.status} "
                "قابل مصرف نیست.")

        with transaction.atomic():
            # قفل ردیف رزرو + re-check وضعیت داخل تراکنش (P0-05)
            reservation = CreditReservation.objects.select_for_update().get(
                pk=reservation.pk)
            if reservation.status != 'reserved':
                raise ValueError(
                    f"رزرو {reservation.id} در وضعیت {reservation.status} "
                    "قابل مصرف نیست (race detected).")

            credit = UserCredit.objects.select_for_update().get(
                user=reservation.user)
            credit.balance -= reservation.amount
            credit.save(update_fields=['balance'])

            reservation.status = 'consumed'
            reservation.consumed_at = timezone.now()
            reservation.save(update_fields=['status', 'consumed_at'])

            CreditTransaction.objects.create(
                user=reservation.user,
                amount=reservation.amount,
                transaction_type='purchase',
                description=description or (
                    f'استفاده از اعتبار بابت درخواست '
                    f'#{reservation.inspection_request_id}'),
                balance_after=credit.balance,
                reference_id=(
                    str(reservation.inspection_request_id)
                    if reservation.inspection_request_id else
                    str(reservation.id)),
            )
            return credit.balance

    @classmethod
    def release(cls, reservation: CreditReservation, reason='') -> None:
        """آزادسازی رزرو (شکست درگاه/انصراف)."""
        if reservation.status != 'reserved':
            return  # idempotent
        with transaction.atomic():
            reservation.status = 'released'
            reservation.released_at = timezone.now()
            reservation.save(update_fields=['status', 'released_at'])
            logger.info(
                f"Credit reservation {reservation.id} released: {reason}")

    @classmethod
    def release_for_payment(cls, payment) -> None:
        """آزادسازی همه رزروهای فعال یک پرداخت (failure/cancel)."""
        for reservation in CreditReservation.objects.filter(
                payment=payment, status='reserved'):
            cls.release(reservation, reason=f'payment {payment.id} not settled')

    @classmethod
    def consume_for_payment(cls, payment) -> None:
        """مصرف همه رزروهای فعال یک پرداخت (settlement موفق)."""
        for reservation in CreditReservation.objects.filter(
                payment=payment, status='reserved'):
            cls.consume(
                reservation,
                description=(
                    f'پرداخت ترکیبی اعتبار + آنلاین بابت درخواست '
                    f'#{payment.inspection_request_id}'))

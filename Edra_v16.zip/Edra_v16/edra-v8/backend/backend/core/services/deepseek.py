import os
import re
import requests
import logging
from typing import Dict, Any, Optional

logger = logging.getLogger(__name__)

DEEPSEEK_API_KEY = os.environ.get('DEEPSEEK_API_KEY', '')
DEEPSEEK_API_URL = "https://api.deepseek.com/v1/chat/completions"

# EDRA v5 — MEDIUM-38: الگوهای redaction قبل از ارسال به سرویس خارجی تا
# داده حساس (شماره تلفن، ایمیل، نشانه، کلید، آدرس IP داخلی) خارج نشود.
_REDACT_PATTERNS = [
    (re.compile(r'\b09\d{9}\b'), '[PHONE]'),                    # موبایل ایران
    (re.compile(r'\b\d{4}[-\s]?\d{4}[-\s]?\d{4}\b'), '[CARD]'),  # شماره کارت
    (re.compile(r'[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}'),
     '[EMAIL]'),
    (re.compile(r'\beyJ[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}\b'),
     '[JWT]'),                                                  # JWT
    (re.compile(r'\b(?:Bearer\s+)?[A-Za-z0-9_-]{32,}\b'),
     '[SECRET]'),                                               # token/key بلند
    (re.compile(r'\b(?:sk-[A-Za-z0-9]+|api[_-]?key[=:]\s*\S+)',
                re.IGNORECASE), '[API_KEY]'),
    (re.compile(r'\b(?:10|172\.(?:1[6-9]|2\d|3[01])|192\.168)\.\d{1,3}\.\d{1,3}\b'),
     '[PRIVATE_IP]'),                                           # IP خصوصی
    (re.compile(r'\b\d{10,12}\b'), '[LONG_NUMBER]'),            # سایر اعداد بلند
]


def _redact(text: str) -> str:
    if not text:
        return text
    for pattern, replacement in _REDACT_PATTERNS:
        text = pattern.sub(replacement, text)
    return text


def analyze_error(error_message: str,
                  context: Optional[str] = None) -> Dict[str, Any]:
    if not DEEPSEEK_API_KEY:
        return {
            'success': False,
            'error': 'DEEPSEEK_API_KEY تنظیم نشده است.'
        }

    # MEDIUM-38: قبل از ارسال، PII/secret ها پاک می‌شوند
    error_message = _redact(error_message)
    context = _redact(context)

    prompt = f"""شما یک دستیار عیب‌یابی Django و Next.js هستید.
لطفاً خطای زیر را تحلیل کنید و راه‌حل ارائه دهید:

خطا:
{error_message}

{context if context else ''}

پاسخ را به این صورت ساختار دهید:
1. **علت خطا**: توضیح مختصر
2. **راه‌حل**: مراحل رفع مشکل
3. **پیشنهادات**: نکات تکمیلی
"""

    headers = {
        "Content-Type": "application/json",
        "Authorization": f"Bearer {DEEPSEEK_API_KEY}"
    }

    payload = {
        "model": "deepseek-chat",
        "messages": [
            {"role": "system", "content": "شما یک دستیار حرفه‌ای برای عیب‌یابی پروژه‌های Django و Next.js هستید."},
            {"role": "user", "content": prompt}
        ],
        "temperature": 0.3,
        "max_tokens": 2000
    }

    try:
        response = requests.post(
            DEEPSEEK_API_URL,
            headers=headers,
            json=payload,
            timeout=30)
        response.raise_for_status()
        data = response.json()
        result = data.get(
            'choices', [
                {}])[0].get(
            'message', {}).get(
                'content', '')
        return {'success': True, 'analysis': result}
    except requests.exceptions.Timeout:
        return {'success': False, 'error': 'زمان پاسخ‌دهی API به پایان رسید.'}
    except requests.exceptions.RequestException as e:
        return {'success': False, 'error': f'خطا در ارتباط با API: {str(e)}'}
    except Exception as e:
        return {'success': False, 'error': f'خطای ناشناخته: {str(e)}'}

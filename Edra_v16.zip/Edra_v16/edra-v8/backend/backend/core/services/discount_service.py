# core/services/discount_service.py
"""
سرویس مرکزی تخفیف — یک منبع واحد برای اعتبارسنجی و محاسبه.

قوانین:
- اعتبارسنجی: فعال بودن، انقضا، ظرفیت (usage_limit)، سقف هر کاربر
  (per_user_limit)، نوع تجهیزات، حداقل مبلغ.
- محاسبه: percent/fixed + سقف max_amount؛ نتیجه هرگز منفی نمی‌شود.
- شمارش used_count فقط یک‌بار به ازای هر درخواست (اتمیک با
  select_for_update) و فقط در زمان اعمال واقعی (create یا apply-discount)،
  نه در پیش‌نمایش.
"""
import logging
from decimal import Decimal

from django.db import transaction

logger = logging.getLogger(__name__)


def compute_discount_amount(discount, amount: Decimal) -> Decimal:
    """مبلغ تخفیف از روی مبلغ ورودی (percent/fixed + max_amount)."""
    amount = Decimal(amount)
    if discount.discount_type == 'percent':
        discount_amount = amount * discount.value / Decimal('100')
    else:
        discount_amount = discount.value
    if discount.max_amount:
        discount_amount = min(discount_amount, Decimal(discount.max_amount))
    return max(discount_amount, Decimal('0'))


def validate_discount(discount, *, amount=None, equipment_type=None, user=None):
    """
    اعتبارسنجی کد تخفیف؛ در صورت نامعتبر بودن پیام خطای فارسی برمی‌گرداند.
    amount: برای بررسی min_amount (اختیاری)
    equipment_type: برای بررسی نوع تجهیزات (اختیاری)
    user: برای بررسی per_user_limit از طریق تعداد درخواست‌های کاربر (اختیاری)
    """
    from django.utils import timezone
    from ..models import InspectionRequest

    if not discount.is_active:
        return 'این کد تخفیف غیرفعال است.'
    if discount.expires_at and discount.expires_at < timezone.now():
        return 'این کد تخفیف منقضی شده است.'
    if discount.usage_limit and discount.used_count >= discount.usage_limit:
        return 'ظرفیت استفاده از این کد تخفیف تمام شده است.'
    if (amount is not None and discount.min_amount
            and Decimal(amount) < Decimal(discount.min_amount)):
        return f'حداقل مبلغ برای این کد {discount.min_amount:,} تومان است.'
    if (equipment_type is not None and not discount.apply_to_all
            and discount.equipment_type_id
            and discount.equipment_type_id != equipment_type.id):
        return 'این کد تخفیف برای این نوع تجهیزات معتبر نیست.'
    if (user is not None and discount.per_user_limit
            and user.is_authenticated):
        used_by_user = InspectionRequest.objects.filter(
            customer=user, discount_code=discount).count()
        if used_by_user >= discount.per_user_limit:
            return 'شما قبلاً از این کد تخفیف استفاده کرده‌اید.'
    return None


class DiscountApplyError(Exception):
    """خطای اعمال تخفیف (پیام فارسی در .message)."""


def apply_discount_to_request(inspection_request, code, user=None):
    """
    اعمال کد تخفیف روی یک درخواست ساخته‌شده (idempotent).

    - کد تکراری روی همان درخواست → بدون تغییر (شمارش دوباره نمی‌شود).
    - تعویض کد → کد قبلی آزاد و کد جدید شمارش می‌شود.
    - used_count اتمیک (select_for_update).

    خروجی: (discount, discount_amount, new_final_price)
    """
    from ..models import DiscountCode

    code = (code or '').strip()
    try:
        discount = DiscountCode.objects.get(code=code)
    except DiscountCode.DoesNotExist:
        raise DiscountApplyError('کد تخفیف نامعتبر است.')

    amount = inspection_request.calculated_price or inspection_request.final_price
    error = validate_discount(
        discount, amount=amount,
        equipment_type=inspection_request.equipment_type,
        user=user or inspection_request.customer)
    if error:
        raise DiscountApplyError(error)

    old_discount = inspection_request.discount_code

    with transaction.atomic():
        discount = DiscountCode.objects.select_for_update().get(pk=discount.pk)
        # بررسی مجدد ظرفیت درون تراکنش
        if discount.usage_limit and discount.used_count >= discount.usage_limit:
            raise DiscountApplyError('ظرفیت استفاده از این کد تخفیف تمام شده است.')

        if old_discount and old_discount.pk != discount.pk:
            # آزادسازی کد قبلی
            old_discount.used_count = max(old_discount.used_count - 1, 0)
            old_discount.save(update_fields=['used_count'])

        if old_discount is None or old_discount.pk != discount.pk:
            discount.used_count += 1
            discount.save(update_fields=['used_count'])

        discount_amount = compute_discount_amount(
            discount, inspection_request.calculated_price)
        new_final_price = max(
            inspection_request.calculated_price - discount_amount, Decimal('0'))

        inspection_request.discount_code = discount
        inspection_request.final_price = new_final_price
        inspection_request.save(
            update_fields=['discount_code', 'final_price'])

    logger.info(
        f"Discount {discount.code} applied to request "
        f"{inspection_request.id}: -{discount_amount}")
    return discount, discount_amount, new_final_price

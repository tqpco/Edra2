# core/services/inspection_service.py
"""
P0-03: State machine وضعیت‌های InspectionRequest.

تمام تغییرات وضعیت باید از این سرویس عبور کنند تا transition های غیرمجاز
(draft → completed، paid → cancelled و ...) به‌صورت متمرکز مسدود شوند.
اکشن‌های ViewSet (pay, assign_expert, schedule, start, complete, cancel)
و این سرویس با هم قرارداد واحد دارند.
"""
from __future__ import annotations

from typing import Dict, Optional, Set

# وضعیت‌های پایانی: بعد از رسیدن به این وضعیت‌ها دیگر transition مجازی نیست.
TERMINAL_STATUSES = {'completed', 'cancelled', 'expired'}

# map: old_status → set of allowed new_status (workflow مجاز)
ALLOWED_STATUS_TRANSITIONS: Dict[str, Set[str]] = {
    'draft': {'pending_payment', 'cancelled'},
    'pending_payment': {
        'waiting_manual_payment', 'paid', 'cancelled', 'expired',
    },
    'waiting_manual_payment': {
        'pending_payment', 'paid', 'rejected', 'cancelled', 'expired',
    },
    # P1-05 (EDRA v8): paid → cancelled/expired بدون refund/reconciliation
    # مالی مجاز نیست. لغو پرداخت‌شده فقط از مسیر refund (financial workflow)
    # انجام می‌شود؛ انقضای درخواست پرداخت‌شده نیز مسیر جداگانه‌ای دارد.
    'paid': {'assigned', 'scheduled'},
    'assigned': {'scheduled', 'rescheduled', 'in_progress', 'cancelled'},
    'scheduled': {'rescheduled', 'in_progress', 'cancelled'},
    'rescheduled': {'scheduled', 'in_progress', 'cancelled'},
    'in_progress': {'completed', 'cancelled'},
    'completed': set(),      # terminal
    'cancelled': set(),      # terminal
    'expired': set(),        # terminal
}

# توضیح فارسی خطای transition برای پاسخ API
TRANSITION_ERROR_MESSAGES: Dict[str, str] = {
    'draft': 'درخواست در وضعیت پیش‌نویس است و این تغییر وضعیت مجاز نیست.',
    'pending_payment': 'در انتظار پرداخت — این تغییر وضعیت مجاز نیست.',
    'waiting_manual_payment': 'در انتظار تأیید فیش — این تغییر وضعیت مجاز نیست.',
    'paid': 'پرداخت‌شده — تغییر وضعیت فقط از طریق تخصیص/زمان‌بندی مجاز است.',
    'assigned': 'ارجاع‌شده — این تغییر وضعیت مجاز نیست.',
    'scheduled': 'زمان‌بندی‌شده — این تغییر وضعیت مجاز نیست.',
    'rescheduled': 'زمان‌بندی مجدد — این تغییر وضعیت مجاز نیست.',
    'in_progress': 'در حال بازرسی — این تغییر وضعیت مجاز نیست.',
    'completed': 'درخواست تکمیل‌شده است و وضعیت آن قابل تغییر نیست.',
    'cancelled': 'درخواست لغو شده است و وضعیت آن قابل تغییر نیست.',
    'expired': 'درخواست منقضی شده است و وضعیت آن قابل تغییر نیست.',
}


def can_transition(old_status: str, new_status: str) -> bool:
    """آیا تغییر از old_status به new_status در workflow مجاز است؟"""
    allowed = ALLOWED_STATUS_TRANSITIONS.get(old_status, set())
    return new_status in allowed


def transition_error(old_status: str, new_status: str) -> str:
    if old_status in TRANSITION_ERROR_MESSAGES:
        base = TRANSITION_ERROR_MESSAGES[old_status]
    else:
        base = 'تغییر وضعیت درخواست از وضعیت فعلی مجاز نیست.'
    return f'{base} (از «{old_status}» به «{new_status}»).'


def assert_transition(old_status: str, new_status: str) -> None:
    """raise ValueError اگر transition مجاز نباشد."""
    if not can_transition(old_status, new_status):
        raise ValueError(transition_error(old_status, new_status))

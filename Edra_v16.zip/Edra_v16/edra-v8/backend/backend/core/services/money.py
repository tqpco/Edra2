"""
core/services/money.py

سیاست واحد پول (قانون غیرقابل مذاکره سیستم):

- نمایش و قیمت‌گذاری به مشتری: تومان (TOMAN)
- مبلغ ارسالی به درگاه و دفتر مالی/گزارش حسابداری: ریال (IRR)
- ۱ تومان = ۱۰ ریال

همه تبدیل‌ها فقط از این ماژول انجام می‌شود؛ هیچ View/Serializer/Component
نباید به‌صورت پراکنده `* 10` یا `/ 10` انجام دهد.
"""
from decimal import ROUND_HALF_UP, Decimal

TOMAN_TO_RIAL = Decimal(10)

# واحد نمایش: تومان
DISPLAY_CURRENCY = 'TOMAN'
# واحد مالی/درگاه: ریال
ACCOUNTING_CURRENCY = 'IRR'


def toman_to_rial(amount: Decimal) -> Decimal:
    """تبدیل تومان به ریال (مبلغ درگاه/دفتر مالی)."""
    return (Decimal(amount) * TOMAN_TO_RIAL).quantize(
        Decimal(1), rounding=ROUND_HALF_UP)


def rial_to_toman(amount: Decimal) -> Decimal:
    """تبدیل ریال به تومان (فقط برای نمایش/محاسبه معکوس)."""
    return (Decimal(amount) / TOMAN_TO_RIAL).quantize(
        Decimal(1), rounding=ROUND_HALF_UP)


def format_toman(amount) -> str:
    """قالب‌بندی مبلغ با جداکننده هزارگان + برچسب تومان."""
    value = Decimal(amount or 0).quantize(Decimal(1))
    return f"{value:,.0f} تومان"


def format_rial(amount) -> str:
    """قالب‌بندی مبلغ با جداکننده هزارگان + برچسب ریال."""
    value = Decimal(amount or 0).quantize(Decimal(1))
    return f"{value:,.0f} ریال"


def toman_display_and_rial(amount: Decimal) -> dict:
    """نمایش دوتایی برای API/گزارش: amount_toman + amount_rial + currency."""
    amount = Decimal(amount or 0)
    return {
        'amount_toman': amount,
        'amount_rial': toman_to_rial(amount),
        'currency': ACCOUNTING_CURRENCY,
    }

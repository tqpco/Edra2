# backend/core/services/payment_service.py
import requests
from django.conf import settings
import logging

logger = logging.getLogger(__name__)


class ZarinpalService:
    MERCHANT_ID = settings.ZARINPAL_MERCHANT_ID
    SANDBOX = getattr(settings, 'ZARINPAL_SANDBOX', True)

    @classmethod
    def get_base_url(cls):
        if cls.SANDBOX:
            return 'https://sandbox.zarinpal.com/pg/v4/payment/'
        return 'https://api.zarinpal.com/pg/v4/payment/'

    @classmethod
    def create_payment(cls, amount, description, callback_url, metadata=None):
        url = cls.get_base_url() + 'request.json'
        data = {
            'merchant_id': cls.MERCHANT_ID,
            'amount': int(amount),
            'description': description,
            'callback_url': callback_url,
            'metadata': metadata or {},
        }
        try:
            response = requests.post(url, json=data, timeout=10)
            result = response.json()
            if result.get('data', {}).get('code') == 100:
                authority = result['data']['authority']
                payment_url = f"https://{
                    'sandbox.' if cls.SANDBOX else ''}zarinpal.com/pg/StartPay/{authority}"
                return {
                    'success': True,
                    'authority': authority,
                    'payment_url': payment_url,
                }
            else:
                error = result.get(
                    'errors', {}).get(
                    'message', 'خطا در ایجاد پرداخت')
                logger.error(f"Zarinpal create error: {error}")
                return {'success': False, 'error': error}
        except Exception as e:
            logger.exception("Zarinpal create exception")
            return {'success': False, 'error': str(e)}

    @classmethod
    def verify_payment(cls, authority, amount):
        url = cls.get_base_url() + 'verify.json'
        data = {
            'merchant_id': cls.MERCHANT_ID,
            'authority': authority,
            'amount': int(amount),
        }
        try:
            response = requests.post(url, json=data, timeout=10)
            result = response.json()
            if result.get('data', {}).get('code') == 100:
                return {
                    'success': True,
                    'ref_id': result['data']['ref_id'],
                }
            else:
                error = result.get(
                    'errors', {}).get(
                    'message', 'خطا در تایید پرداخت')
                logger.error(f"Zarinpal verify error: {error}")
                return {'success': False, 'error': error}
        except Exception as e:
            logger.exception("Zarinpal verify exception")
            return {'success': False, 'error': str(e)}


# ============================================================
# settle_admin_payment — P0-03 (EDRA v9)
# مسیر رسمی تأیید دستی پرداخت از Admin: همه settlement مالی
# (paid + مصرف رزرو اعتبار + فاکتور + ledger) در یک transaction
# اتمیک. Admin دیگر نمی‌تواند با تغییر مستقیم status این زنجیره
# را دور بزند. از payment_views.callback رفتار canonical دارد.
# ============================================================
    @classmethod
    def refund_payment(cls, authority, ref_id, amount_rial):
        """
        P0 (EDRA v10): عودت واقعی وجه به درگاه زرین‌پال.

        - Sandbox: عودت واقعی در sandbox زرین‌پال پشتیبانی کامل ندارد؛
          برای تست، موفقیت شبیه‌سازی می‌شود (مستند در پاسخ gateway_status).
        - Production: فراخوانی API عودت زرین‌پال انجام می‌شود؛ فقط پاسخ
          موفق یعنی پول واقعاً برگشته است.
        خروجی: {'success': bool, 'reference': str|None, 'error': str|None}
        """
        if cls.SANDBOX:
            # شبیه‌سازی صادقانه برای sandbox — در Production واقعی است
            return {
                'success': True,
                'reference': f'SANDBOX-REFUND-{ref_id or authority}',
                'gateway_status': 'sandbox_simulated',
                'error': None,
            }
        try:
            url = 'https://api.zarinpal.com/pg/v4/payment/refund.json'
            data = {
                'merchant_id': cls.MERCHANT_ID,
                'authority': authority,
                'amount': int(amount_rial),
            }
            response = requests.post(url, json=data, timeout=15)
            result = response.json()
            # در Zarinpal v4، کد 100 در data یعنی موفق
            if result.get('data', {}).get('code') == 100:
                return {
                    'success': True,
                    'reference': str(result['data'].get(
                        'ref_id', result['data'].get('reference', ''))),
                    'gateway_status': 'refunded',
                    'error': None,
                }
            error = result.get(
                'errors', {}).get('message', 'خطای ناشناخته در عودت درگاه')
            logger.error(f"Zarinpal refund error: {error}")
            return {
                'success': False, 'reference': None,
                'gateway_status': 'refund_failed', 'error': error}
        except Exception as e:
            logger.exception("Zarinpal refund exception")
            return {
                'success': False, 'reference': None,
                'gateway_status': 'refund_failed', 'error': str(e)}

def settle_admin_payment(payment, verified_by):
    """
    تأیید یک پرداخت (manual/online) توسط Admin با settlement کامل.

    - فقط pending / pending_verification قابل تأییدند.
    - مصرف رزروهای اعتبار (consume_for_payment)
    - فاکتور + ledger از InvoiceSettlementService (idempotent)
    - درخواست به 'paid' منتقل می‌شود
    - برای واریز اعتبار (is_deposit) به‌جای آن موجودی افزایش می‌یابد
    """
    from django.db import transaction
    from django.utils import timezone
    from django.contrib.auth import get_user_model
    from ..models import UserCredit, CreditTransaction
    from .credit_service import CreditService
    from .invoice_service import InvoiceSettlementService
    from notifications.services import send_notification
    import logging
    logger = logging.getLogger(__name__)

    with transaction.atomic():
        from django.db.models import F
        payment = type(payment).objects.select_for_update().get(
            pk=payment.pk)
        if payment.status not in ('pending', 'pending_verification'):
            raise ValueError(
                f'پرداخت #{payment.id} در وضعیت قابل تأیید نیست '
                f'({payment.status}).')

        payment.status = 'paid'
        payment.verified_by = verified_by
        payment.verified_at = timezone.now()
        payment.save()

        inspection_request = payment.inspection_request
        user = inspection_request.customer

        is_deposit = bool(
            inspection_request.params
            and inspection_request.params.get('is_deposit'))

        if is_deposit:
            # واریز اعتبار: موجودی افزایش + تراکنش ثبت
            credit, _ = UserCredit.objects.select_for_update().get_or_create(
                user=user)
            credit.balance += payment.amount
            credit.save(update_fields=['balance'])
            CreditTransaction.objects.create(
                user=user,
                amount=payment.amount,
                transaction_type='deposit',
                description=(
                    f'واریز اعتبار به مبلغ {payment.amount:,} تومان - '
                    f'تأیید شده توسط {verified_by.username}'),
                balance_after=credit.balance,
                reference_id=str(payment.id))
            inspection_request.status = 'completed'
            inspection_request.save(update_fields=['status'])
        else:
            # مصرف رزروهای اعتبار (اگر ترکیبی باشد)
            if payment.credit_amount:
                CreditService.consume_for_payment(payment)
            # فاکتور + ledger idempotent
            InvoiceSettlementService.settle(
                inspection_request, payment=payment,
                is_paid=True, paid_at=payment.verified_at,
                user=user)
            if inspection_request.status in ('pending_payment', 'paid'):
                inspection_request.status = 'scheduled'
                inspection_request.save(update_fields=['status'])

    try:
        send_notification(
            user,
            'payment_verified_request' if not is_deposit
            else 'payment_verified',
            {
                'request_id': inspection_request.id,
                'payment_id': payment.id,
                'amount': str(payment.amount),
                'message': 'پرداخت شما تأیید شد.'
            })
    except Exception as notif_error:
        logger.error(f"Error sending payment verified notification: "
                     f"{notif_error}")
    return payment



# core/services/report_service.py
"""
سرویس یکپارچه ثبت چک‌لیست / نهایی‌سازی گزارش (EDRA v5).

رفع مشکلات:
  CRITICAL-06: همه آیتم‌های چک‌لیست باید ارسال شوند؛ item_id خارجی/تکراری
               رد می‌شود؛ result معتبر باشد؛ requires_photo/requires_note
               سمت سرور enforce می‌شود.
  CRITICAL-07/44: نتیجه پیش‌فرض وجود ندارد — آیتم بدون result مجاز نیست.
  CRITICAL-08:  هنگام submit، signed_by/signed_at = null (امضا مرحله جدا).
  HIGH-18:      checklist_template_version snapshot می‌شود.
  HIGH-22/23:   عکس‌ها از validator مرکزی + محدودیت تعداد عبور می‌کنند.
  HIGH-45:      overall_result از نتایج آیتم‌ها سمت سرور محاسبه می‌شود.
  MEDIUM-27:    هر دو route (ExpertSubmitChecklistView و
               InspectionReportViewSet.submit_results) همین سرویس را صدا می‌زنند.
"""
import json
import logging
import re
from collections import defaultdict

from django.db import transaction
from django.utils import timezone
from decimal import Decimal, InvalidOperation

from ..models import (
    InspectionReport, ChecklistTemplate, ChecklistItem,
    ChecklistPhoto, SequenceCounter, AuditLog,
)
from ..utils.geo import haversine_distance_meters
from ..validators import (
    validate_uploaded_file, ALLOWED_IMAGE_EXTENSIONS, MAX_IMAGE_SIZE,
)

logger = logging.getLogger(__name__)

ALLOWED_RESULTS = {'pass', 'fail', 'na'}
MAX_PHOTOS_PER_ITEM = 10
MAX_TOTAL_PHOTOS = 100
_PHOTO_PATTERN = re.compile(r'^photo_(\d+)_(\d+)$')


class ChecklistSubmissionError(ValueError):
    """خطای اعتبارسنجی ثبت چک‌لیست (message فارسی)."""

    def __init__(self, message, status_code=400):
        self.status_code = status_code
        super().__init__(message)


def resolve_active_template(equipment_type):
    """جدیدترین قالب فعال برای نوع تجهیز (snapshot منبع)."""
    return ChecklistTemplate.objects.filter(
        equipment_type=equipment_type, is_active=True
    ).order_by('-version').first()


def normalize_results(results, template):
    """
    اعتبارسنجی و نرمال‌سازی نتایج در برابر آیتم‌های قالب.

    قوانین:
      - مجموعه item_id های ارسالی == مجموعه آیتم‌های فعال قالب (بدون نقص/اضافه)
      - item_id تکراری → خطا
      - result فقط pass/fail/na
      - requires_note → note غیرخالی
      - خروجی: (normalized_results, derived_overall)
    """
    expected_items = list(
        template.items.filter(is_active=True).order_by('order'))
    expected_ids = {i.id for i in expected_items}

    if not isinstance(results, (list, tuple)):
        raise ChecklistSubmissionError('نتایج چک‌لیست باید لیست باشد.')

    by_id = {}
    seen = set()
    for entry in results:
        if not isinstance(entry, dict):
            raise ChecklistSubmissionError('ساختار نتایج نامعتبر است.')
        try:
            item_id = int(entry.get('item_id'))
        except (TypeError, ValueError):
            raise ChecklistSubmissionError('item_id نامعتبر است.')
        if item_id in seen:
            raise ChecklistSubmissionError(
                f'آیتم {item_id} دوباره ارسال شده است.')
        seen.add(item_id)

        result = (entry.get('result') or '').strip()
        if result not in ALLOWED_RESULTS:
            raise ChecklistSubmissionError(
                f'نتیجه آیتم {item_id} نامعتبر است (فقط pass/fail/na).')

        note = (entry.get('note') or '').strip()
        by_id[item_id] = {
            'item_id': item_id,
            'result': result,
            'note': note,
        }

    submitted_ids = set(by_id)
    missing = expected_ids - submitted_ids
    foreign = submitted_ids - expected_ids
    if missing or foreign:
        parts = []
        if missing:
            parts.append(f'آیتم‌های ناقص: {sorted(missing)}')
        if foreign:
            parts.append(f'آیتم‌های نامعتبر: {sorted(foreign)}')
        raise ChecklistSubmissionError(
            'پاسخ چک‌لیست کامل نیست — ' + '؛ '.join(parts))

    # enforce required note/photo + غنی‌سازی خروجی
    normalized = []
    item_by_id = {i.id: i for i in expected_items}
    for item in expected_items:
        entry = by_id[item.id]
        if item.requires_note and not entry['note']:
            raise ChecklistSubmissionError(
                f'آیتم «{item.title}» نیاز به یادداشت دارد.')
        normalized.append({
            'item_id': item.id,
            'category': item.category,
            'title': item.title,
            'result': entry['result'],
            'note': entry['note'],
        })

    # HIGH-45: overall از سمت سرور — هر fail یعنی مردود
    derived = 'fail' if any(
        e['result'] == 'fail' for e in normalized) else 'pass'
    return normalized, derived


def _save_photos(request, report, expected_ids, gps_lat, gps_lng):
    """اعتبارسنجی و ذخیره عکس‌های ارسالی (فقط برای آیتم‌های معتبر)."""
    per_item = defaultdict(int)
    total = 0
    for field_name, uploaded_file in request.FILES.items():
        match = _PHOTO_PATTERN.match(field_name)
        if not match:
            continue  # فیلدهای نامرتبط نادیده گرفته می‌شوند
        item_id = int(match.group(1))
        if item_id not in expected_ids:
            raise ChecklistSubmissionError(
                f'عکس برای آیتم {item_id} ارسال شده ولی این آیتم '
                f'در چک‌لیست نیست (foreign item).')

        file_error = validate_uploaded_file(
            uploaded_file,
            allowed_extensions=ALLOWED_IMAGE_EXTENSIONS,
            max_size=MAX_IMAGE_SIZE)
        if file_error:
            raise ChecklistSubmissionError(
                f'عکس آیتم {item_id}: {file_error}')

        per_item[item_id] += 1
        total += 1
        if (per_item[item_id] > MAX_PHOTOS_PER_ITEM
                or total > MAX_TOTAL_PHOTOS):
            raise ChecklistSubmissionError(
                'تعداد عکس‌های ارسالی بیش از حد مجاز است.')

        ChecklistPhoto.objects.create(
            report=report,
            checklist_item_id=item_id,
            image=uploaded_file,
            gps_lat=gps_lat,
            gps_lng=gps_lng,
        )
    return per_item


def _to_decimal(val):
    try:
        return Decimal(str(val)) if val not in (None, '') else None
    except (InvalidOperation, ValueError):
        return None


def submit_checklist(*, user, task, results, overall_result=None,
                     inspector_notes='', request=None,
                     gps_start_lat=None, gps_start_lng=None,
                     gps_end_lat=None, gps_end_lng=None,
                     inspection_started_at=None):
    """
    مسیر اصلی (create): اعتبارسنجی کامل + snapshot نسخه + ساخت گزارش +
    ذخیره عکس‌ها + تغییر وضعیت task — همه در یک transaction.

    خروجی: dict شامل report_id / report_number / gps_distance_meters
    """
    from django.core.exceptions import ObjectDoesNotExist

    if task.status not in ('in_progress', 'scheduled'):
        raise ChecklistSubmissionError(
            f'وضعیت «{task.status}» اجازه ثبت گزارش را نمی‌دهد.')

    template = resolve_active_template(task.equipment_type)
    if template is None:
        raise ChecklistSubmissionError(
            'قالب چک‌لیست فعالی برای این تجهیز یافت نشد.')

    if isinstance(results, str):
        try:
            results = json.loads(results)
        except json.JSONDecodeError:
            raise ChecklistSubmissionError('فرمت نتایج نامعتبر است.')

    normalized, derived_overall = normalize_results(results, template)
    expected_ids = {i.id for i in template.items.filter(is_active=True)}

    gps_start_lat = _to_decimal(gps_start_lat)
    gps_start_lng = _to_decimal(gps_start_lng)
    gps_end_lat = _to_decimal(gps_end_lat)
    gps_end_lng = _to_decimal(gps_end_lng)

    gps_distance = None
    if gps_start_lat is not None and gps_start_lng is not None:
        gps_distance = haversine_distance_meters(
            gps_start_lat, gps_start_lng,
            task.address_lat, task.address_lng)

    with transaction.atomic():
        # گزارش یکتا برای هر درخواست (OneToOne)
        if hasattr(task, 'report'):
            raise ChecklistSubmissionError(
                'برای این درخواست قبلاً گزارش ثبت شده است.', 409)

        year = timezone.now().year
        counter, _ = SequenceCounter.objects.select_for_update(
        ).get_or_create(key=f'inspection_report_{year}')
        counter.value += 1
        counter.save(update_fields=['value'])
        report_number = f"REP-{year}-{counter.value:05d}"

        report = InspectionReport.objects.create(
            inspection_request=task,
            report_number=report_number,
            checklist_template_version=template,   # HIGH-18: snapshot
            results=normalized,
            overall_result=derived_overall,        # HIGH-45: server-derived
            inspector_notes=inspector_notes or '',
            signed_by=None,                        # CRITICAL-08: بعد از امضا
            signed_at=None,
            gps_start_lat=gps_start_lat,
            gps_start_lng=gps_start_lng,
            gps_end_lat=gps_end_lat,
            gps_end_lng=gps_end_lng,
            gps_distance_meters=gps_distance,
            inspection_started_at=inspection_started_at or None,
            inspection_ended_at=timezone.now(),
        )

        # عکس‌ها (با validator مرکزی + محدودیت تعداد)
        if request is not None and request.FILES:
            photo_counts = _save_photos(
                request, report, expected_ids, gps_end_lat, gps_end_lng)
        else:
            photo_counts = defaultdict(int)

        # enforce: هر آیتم requires_photo باید حداقل یک عکس داشته باشد
        for item in template.items.filter(
                is_active=True, requires_photo=True):
            if photo_counts.get(item.id, 0) == 0:
                raise ChecklistSubmissionError(
                    f'آیتم «{item.title}» نیاز به حداقل یک عکس دارد.')

        task.status = 'completed'
        task.save(update_fields=['status'])

        try:
            AuditLog.objects.create(
                user=user,
                action='report_submitted',
                object_id=report.id,
                changes={
                    'report_number': report_number,
                    'overall_result': derived_overall,
                    'template_version': template.id,
                    'item_count': len(normalized),
                })
        except Exception as log_error:  # audit نباید جریان را بشکند
            logger.error(f"AuditLog write failed: {log_error}")

    return {
        'report_id': report.id,
        'report_number': report.report_number,
        'overall_result': derived_overall,
        'gps_distance_meters': gps_distance,
    }


def validate_and_finalize_existing(report, *, user, results, overall_result,
                                   inspector_notes='', request=None):
    """
    مسیر دوم (InspectionReportViewSet.submit_results): همان قوانین را روی
    گزارش موجود اعمال می‌کند. گزارش امضاشده/نهایی دیگر قابل تغییر نیست.
    """
    task = report.inspection_request
    if report.signed_at is not None or report.signed_pdf_file:
        raise ChecklistSubmissionError(
            'گزارش امضا/نهایی شده و دیگر قابل تغییر نیست.', 403)
    if task.assigned_expert != user and not user.is_staff:
        raise ChecklistSubmissionError('دسترسی غیرمجاز.', 403)

    template = report.checklist_template_version or resolve_active_template(
        task.equipment_type)
    if template is None:
        raise ChecklistSubmissionError(
            'قالب چک‌لیست فعالی برای این تجهیز یافت نشد.')

    if isinstance(results, str):
        try:
            results = json.loads(results)
        except json.JSONDecodeError:
            raise ChecklistSubmissionError('فرمت نتایج نامعتبر است.')

    normalized, derived_overall = normalize_results(results, template)

    with transaction.atomic():
        report.results = normalized
        report.overall_result = derived_overall
        report.inspector_notes = inspector_notes or ''
        report.checklist_template_version = template
        # P1 (EDRA v9): enforce عکس‌های الزامی در مسیر دوم هم — منطق مشترک
        # با submit_checklist؛ قبلاً فقط در مسیر اول بررسی می‌شد.
        expected_ids = {i.id for i in template.items.filter(is_active=True)}
        if request is not None and request.FILES:
            photo_counts = _save_photos(
                request, report, expected_ids,
                report.gps_end_lat, report.gps_end_lng)
        else:
            photo_counts = defaultdict(int)
        for item in template.items.filter(
                is_active=True, requires_photo=True):
            if photo_counts.get(item.id, 0) == 0:
                raise ChecklistSubmissionError(
                    f'آیتم «{item.title}» نیاز به حداقل یک عکس دارد.')
        report.save()
        task.status = 'completed'
        task.save(update_fields=['status'])

    return report

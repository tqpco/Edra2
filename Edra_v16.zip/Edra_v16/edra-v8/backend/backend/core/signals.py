# core/signals.py
from django.db.models.signals import post_save, post_delete, post_migrate
from django.dispatch import receiver
from django.utils import timezone
from decimal import Decimal
import logging
from django.contrib.auth.models import Group, Permission
from django.contrib.contenttypes.models import ContentType
from django.db import IntegrityError, transaction
from django.core.files.base import ContentFile
from django.contrib.auth import get_user_model

from .models import (
    Payment, InspectionRequest, InspectionReport, DiscountCode,
    EquipmentParameter, EquipmentType
)
from notifications.services import send_notification
from notifications.models import NotificationLog, NotificationTemplate

# ✅ دریافت مدل User یکبار در بالای فایل
User = get_user_model()
logger = logging.getLogger(__name__)


# ============================================================
# سیگنال‌های جدید برای به‌روزرسانی خودکار param_schema
# ============================================================

@receiver(post_save, sender=EquipmentParameter)
def update_param_schema_on_save(sender, instance, created, **kwargs):
    """
    پس از ذخیره‌سازی یک پارامتر، param_schema نوع تجهیزات مرتبط را به‌روز می‌کند.
    """
    equipment = instance.equipment_type
    if equipment.parameters.exists():
        schema = [p.to_json_schema()
                  for p in equipment.parameters.all().order_by('order')]
        equipment.param_schema = schema
    else:
        equipment.param_schema = None
    equipment.save(update_fields=['param_schema'])


@receiver(post_delete, sender=EquipmentParameter)
def update_param_schema_on_delete(sender, instance, **kwargs):
    """
    پس از حذف یک پارامتر، param_schema نوع تجهیزات مرتبط را به‌روز می‌کند.
    """
    equipment = instance.equipment_type
    if equipment.parameters.exists():
        schema = [p.to_json_schema()
                  for p in equipment.parameters.all().order_by('order')]
        equipment.param_schema = schema
    else:
        equipment.param_schema = None
    equipment.save(update_fields=['param_schema'])


# ============================================================
# سیگنال‌های قبلی (بدون تغییر)
# ============================================================

@receiver(post_migrate)
def create_default_groups_and_permissions(sender, **kwargs):
    if sender.name != 'core':
        return

    # ایجاد گروه‌ها
    admin_group, _ = Group.objects.get_or_create(name='Admin')
    expert_group, _ = Group.objects.get_or_create(name='Expert')

    # دریافت ContentType برای مدل‌ها
    inspection_request_ct = ContentType.objects.get_for_model(
        InspectionRequest)
    inspection_report_ct = ContentType.objects.get_for_model(InspectionReport)

    # تابع کمکی برای ایجاد یا دریافت مجوز با مدیریت خطا
    def get_or_create_permission(codename, name, content_type):
        try:
            perm, created = Permission.objects.get_or_create(
                codename=codename,
                defaults={'name': name},
                content_type=content_type,
            )
            return perm
        except IntegrityError:
            return Permission.objects.get(
                codename=codename,
                content_type=content_type,
            )

    view_request_perm = get_or_create_permission(
        'view_inspectionrequest',
        'Can view inspection request',
        inspection_request_ct
    )
    change_request_perm = get_or_create_permission(
        'change_inspectionrequest',
        'Can change inspection request',
        inspection_request_ct
    )
    delete_request_perm = get_or_create_permission(
        'delete_inspectionrequest',
        'Can delete inspection request',
        inspection_request_ct
    )

    view_report_perm = get_or_create_permission(
        'view_inspectionreport',
        'Can view inspection report',
        inspection_report_ct
    )
    change_report_perm = get_or_create_permission(
        'change_inspectionreport',
        'Can change inspection report',
        inspection_report_ct
    )
    delete_report_perm = get_or_create_permission(
        'delete_inspectionreport',
        'Can delete inspection report',
        inspection_report_ct
    )

    admin_group.permissions.add(
        view_request_perm, change_request_perm, delete_request_perm,
        view_report_perm, change_report_perm, delete_report_perm
    )
    expert_group.permissions.add(
        view_report_perm, change_report_perm
    )
    expert_group.permissions.add(view_request_perm)

    logger.info("Default groups and permissions created successfully.")


@receiver(post_save, sender=Payment)
def create_invoice_on_payment_success(sender, instance, created, **kwargs):
    """
    پس از پرداخت‌شدن (paid)، فاکتور فقط از طریق سرویس مرکزی
    InvoiceSettlementService.settle ساخته می‌شود (idempotent — FIN-01/FIN-02).
    """
    if instance.status != 'paid':
        return

    from .services.invoice_service import InvoiceSettlementService

    try:
        inspection_request = instance.inspection_request
        invoice, created_invoice = InvoiceSettlementService.settle(
            inspection_request,
            payment=instance,
            is_paid=True,
            paid_at=instance.verified_at or timezone.now(),
            user=inspection_request.customer,
        )

        if created_invoice:
            try:
                send_notification(
                    inspection_request.customer, 'payment_successful', {
                        'request_id': inspection_request.id,
                        'amount': str(instance.amount),
                        'invoice_number': invoice.invoice_number,
                    })
            except Exception as notif_error:
                logger.error(f"Error sending notification: {notif_error}")
    except Exception as e:
        logger.error(
            f"Critical error in invoice creation for payment {instance.id}: {e}")
        raise


@receiver(post_save, sender=DiscountCode)
def notify_new_discount_code(sender, instance, created, **kwargs):
    if created and instance.is_active and instance.usage_limit != 0:
        try:
            template_code = 'new_discount_code'
            try:
                template = NotificationTemplate.objects.get(
                    code=template_code, is_active=True)
            except NotificationTemplate.DoesNotExist:
                logger.warning(
                    f"Notification template '{template_code}' not found. Skipping bulk notification.")
                return

            customers = User.objects.filter(is_staff=False, is_superuser=False)
            notifications = []
            content = f"کد تخفیف جدید: {
                instance.code} - {
                instance.get_discount_type_display()} به مقدار {
                instance.value} - تا {
                instance.expires_at} معتبر است."

            for user in customers:
                notifications.append(
                    NotificationLog(
                        user=user,
                        template=template,
                        channel=template.channel,
                        subject=template.subject,
                        content=content,
                        status='pending',
                        type='new_discount_code'
                    )
                )

            if notifications:
                NotificationLog.objects.bulk_create(
                    notifications, batch_size=100)
                logger.info(
                    f"Created {
                        len(notifications)} discount code notifications for users.")

        except Exception as e:
            logger.error(
                f"Failed to send discount notifications using bulk_create: {e}")

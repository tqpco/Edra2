document.addEventListener('DOMContentLoaded', function () {
    // یافتن تمام دکمه‌های حذف و اتصال رویداد کلیک
    document.querySelectorAll('.delete-param-btn').forEach(function (button) {
        button.addEventListener('click', function (e) {
            e.preventDefault();

            const url = this.getAttribute('data-url');
            const row = this.closest('tr'); // ردیف فعلی در جدول Inline

            if (!confirm('آیا مطمئن هستید که می‌خواهید این پارامتر را حذف کنید؟')) {
                return;
            }

            // ارسال درخواست AJAX
            fetch(url, {
                method: 'POST',
                headers: {
                    'X-CSRFToken': getCsrfToken(),
                    'Content-Type': 'application/json',
                }
            })
            .then(response => response.json())
            .then(data => {
                if (data.status === 'success') {
                    // حذف ردیف از DOM به‌صورت پویا
                    if (row) {
                        row.remove();
                    }

                    // به‌روزرسانی فیلد read-only param_schema در فرم
                    updateParamSchema(data.param_schema);

                    // نمایش پیام موفقیت (اختیاری)
                    alert(data.message);
                } else {
                    alert(data.message);
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert('خطا در برقراری ارتباط با سرور.');
            });
        });
    });

    // تابع برای دریافت توکن CSRF
    function getCsrfToken() {
        const cookieValue = document.cookie.match(/(?:^|;)\s*csrftoken\s*=\s*([^;]+)/);
        return cookieValue ? cookieValue[1] : '';
    }

    // تابع برای به‌روزرسانی فیلد param_schema
    function updateParamSchema(schema) {
        const field = document.querySelector('.field-param_schema pre');
        if (field) {
            field.textContent = JSON.stringify(schema, null, 2);
        }
    }
});
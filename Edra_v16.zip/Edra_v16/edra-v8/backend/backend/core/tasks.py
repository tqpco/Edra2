# core/tasks.py
from celery import shared_task
from django.core.files.base import ContentFile
from django.utils import timezone
import logging

from .models import InspectionReport, Invoice, DiscountCode, InspectionRequest, Payment
from .report_pdf_generator import generate_report_pdf
from .invoice_pdf_generator import generate_invoice_pdf
from notifications.services import send_notification
from django.contrib.auth import get_user_model

User = get_user_model()
logger = logging.getLogger(__name__)


@shared_task
def generate_report_pdf_task(report_id, user_id):
    """
    تسک تولید PDF گزارش
    """
    try:
        report = InspectionReport.objects.get(id=report_id)
        inspection_request = report.inspection_request
        customer = inspection_request.customer
        equipment = inspection_request.equipment_type
        checklist_items = report.results if report.results else []

        pdf_content = generate_report_pdf(
            report=report,
            inspection_request=inspection_request,
            customer=customer,
            equipment=equipment,
            checklist_items=checklist_items
        )

        filename = f"report_{report.report_number}.pdf"
        report.pdf_file.save(filename, ContentFile(pdf_content), save=True)
        report.save()

        # ارسال اعلان موفقیت به کاربر
        send_notification(customer, 'report_pdf_ready', {
            'report_number': report.report_number,
            'report_id': report.id
        })

        logger.info(f"PDF generated for report {report.report_number}")
        return True
    except Exception as e:
        logger.error(
            f"Error generating report PDF for report {report_id}: {e}")
        # ارسال اعلان خطا به کاربر
        try:
            user = User.objects.get(id=user_id)
            send_notification(user, 'report_pdf_failed', {
                'report_id': report_id,
                'error': str(e)
            })
        except Exception:
            pass
        return False


@shared_task
def generate_invoice_pdf_task(invoice_id, user_id):
    """
    تسک تولید PDF فاکتور
    """
    try:
        invoice = Invoice.objects.get(id=invoice_id)
        inspection_request = invoice.inspection_request
        customer = inspection_request.customer
        equipment = inspection_request.equipment_type

        pdf_content = generate_invoice_pdf(
            invoice=invoice,
            inspection_request=inspection_request,
            customer=customer,
            equipment=equipment
        )

        filename = f"invoice_{invoice.invoice_number}.pdf"
        invoice.pdf_file.save(filename, ContentFile(pdf_content), save=True)
        invoice.status = 'generated'
        invoice.last_error = ''
        invoice.save(update_fields=['pdf_file', 'status', 'last_error'])

        # ارسال اعلان موفقیت
        send_notification(customer, 'invoice_pdf_ready', {
            'invoice_number': invoice.invoice_number,
            'invoice_id': invoice.id
        })

        logger.info(f"PDF generated for invoice {invoice.invoice_number}")
        return True
    except Exception as e:
        logger.error(
            f"Error generating invoice PDF for invoice {invoice_id}: {e}")
        # بروزرسانی وضعیت فاکتور به failed
        try:
            invoice = Invoice.objects.get(id=invoice_id)
            invoice.status = 'failed'
            invoice.last_error = str(e)
            invoice.retry_count += 1
            invoice.save(update_fields=['status', 'last_error', 'retry_count'])
        except Exception:
            pass
        # ارسال اعلان خطا
        try:
            user = User.objects.get(id=user_id)
            send_notification(user, 'invoice_pdf_failed', {
                'invoice_id': invoice_id,
                'error': str(e)
            })
        except Exception:
            pass
        return False


# ===== تسک بررسی کدهای تخفیف در حال انقضا =====
@shared_task
def check_expiring_discount_codes():
    """
    بررسی کدهای تخفیف که کمتر از ۳ روز تا انقضا دارند و ارسال اعلان
    """
    now = timezone.now()
    expiring_soon = now + timezone.timedelta(days=3)

    codes = DiscountCode.objects.filter(
        is_active=True,
        expires_at__gt=now,
        expires_at__lte=expiring_soon
    )

    if not codes.exists():
        logger.info("No expiring discount codes found.")
        return

    customers = User.objects.filter(is_staff=False, is_superuser=False)

    for user in customers:
        for code in codes:
            try:
                send_notification(
                    user,
                    'discount_code_expiring',
                    {
                        'code': code.code,
                        'expires_at': code.expires_at.isoformat(),
                        'days_left': (code.expires_at - now).days,
                        'discount_type': code.discount_type,
                        'value': code.value,
                    }
                )
                logger.info(
                    f"Sent expiring notification for code {
                        code.code} to {
                        user.username}")
            except Exception as e:
                logger.error(
                    f"Failed to send expiring notification to {
                        user.username}: {e}")


# ===== تسک بستن خودکار درخواست‌های پرداخت‌نشده بعد از ۴۸ ساعت =====
@shared_task
def close_expired_manual_payments():
    """
    طبق مستند نیازمندی‌ها: «اگر واریز به صورت دستی انتخاب شد ... که پس از
    ۴۸ ساعت درخواست پرداخت انجام نشد به صورت اتوماتیک درخواست بسته شود»

    این تسک پرداخت‌های دستی (method='manual') که بیش از ۴۸ ساعت است در
    وضعیت "در انتظار تایید" (pending_verification) مانده‌اند را پیدا کرده،
    خود پرداخت را rejected و درخواست بازرسی مرتبط را expired می‌کند (فقط
    اگر درخواست هنوز نهایی نشده - یعنی هنوز paid/scheduled/completed نشده).
    """
    cutoff = timezone.now() - timezone.timedelta(hours=48)

    stale_payments = Payment.objects.filter(
        status='pending_verification',
        method__name='manual',
        created_at__lt=cutoff,
    ).select_related('inspection_request', 'inspection_request__customer')

    closed_count = 0
    for payment in stale_payments:
        try:
            inspection_request = payment.inspection_request
            # اگر درخواست از حالت انتظار پرداخت جلوتر رفته (مثلاً با روش
            # دیگری پرداخت شده)، دست نمی‌زنیم
            if inspection_request.status not in (
                    'pending_payment', 'waiting_manual_payment', 'draft'):
                continue

            payment.status = 'rejected'
            payment.save(update_fields=['status'])

            # P1 (EDRA v9): آزادسازی رزروهای اعتبار این پرداخت — قبلاً
            # اعتبار مشتری برای همیشه reserved می‌ماند.
            try:
                from ..services.credit_service import CreditService
                CreditService.release_for_payment(payment)
            except Exception as release_error:
                logger.error(
                    f"Error releasing credit for expired payment "
                    f"{payment.id}: {release_error}")

            inspection_request.status = 'expired'
            inspection_request.save(update_fields=['status'])

            closed_count += 1

            try:
                send_notification(
                    inspection_request.customer,
                    'payment_rejected',
                    {
                        'request_id': inspection_request.id,
                        'request_number': inspection_request.request_number,
                        'reason': 'عدم تایید فیش واریزی طی ۴۸ ساعت',
                    }
                )
            except Exception as notif_error:
                logger.error(
                    f"Error sending expiry notification for request "
                    f"{inspection_request.id}: {notif_error}")
        except Exception as e:
            logger.error(
                f"Error closing expired manual payment {payment.id}: {e}")

    logger.info(
        f"close_expired_manual_payments: {closed_count} درخواست بسته شد "
        f"(از {stale_payments.count()} کاندید).")
    return closed_count

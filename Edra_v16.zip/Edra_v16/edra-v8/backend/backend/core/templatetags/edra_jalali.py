# core/templatetags/jalali_tags.py
"""
فیلترهای تمپلیت جلالی — اصلاح PDF-01 از گزارش ممیزی.

استفاده در قالب:
    {% load jalali_tags %}
    {{ invoice.issue_date|jalali:"%Y/%m/%d" }}
    {{ report.signed_at|jalali_date }}
    {% jalali_now "%Y/%m/%d" %}     ← تاریخ چاپ به‌جای {% now %}
"""
from django import template
from django.utils import timezone

from ..utils.date_utils import to_jalali

register = template.Library()


@register.filter(name='jalali')
def jalali_filter(value, fmt="%Y/%m/%d %H:%M"):
    """تبدیل datetime/date به رشته شمسی با فرمت اختیاری."""
    return to_jalali(value, fmt)


@register.filter(name='jalali_date')
def jalali_date_filter(value):
    """تاریخ شمسی (بدون ساعت)."""
    return to_jalali(value, "%Y/%m/%d")


@register.simple_tag(name='jalali_now')
def jalali_now(fmt="%Y/%m/%d %H:%M"):
    """تاریخ/زمان فعلی شمسی (جایگزین {% now %} گرگوری)."""
    return to_jalali(timezone.now(), fmt)

# core/tests/test_admin_permissions_and_errors.py
"""
تست یکسان‌سازی مجوز ادمین (IsAdminUserOrGroup) + قرارداد خطای یکسان API.
"""
import os

import pytest
from django.contrib.auth import get_user_model
from django.contrib.auth.models import Group
from rest_framework.test import APIClient

User = get_user_model()
pytestmark = pytest.mark.django_db
PASSWORD = os.getenv("PASSWORD", "CHANGE_ME")


class _Base:
    def setup_method(self):
        self.client = APIClient()
        self.admin_group, _ = Group.objects.get_or_create(name='Admin')
        # ادمین گروهی بدون is_staff (مدل پنل EDRA)
        self.group_admin = User.objects.create_user(
            username="grp_admin", password=PASSWORD)
        self.group_admin.groups.add(self.admin_group)
        # کاربر عادی
        self.normal = User.objects.create_user(
            username="09120000444", password=PASSWORD)
        self.admin_client = APIClient()
        self.admin_client.force_authenticate(user=self.group_admin)
        self.normal_client = APIClient()
        self.normal_client.force_authenticate(user=self.normal)


class TestGroupAdminAccess(_Base):
    """ادمین گروهی (بدون is_staff) به همه پنل دسترسی دارد."""

    def test_discount_codes(self):
        r = self.admin_client.get('/api/core/discount-codes/')
        assert r.status_code == 200
        r = self.admin_client.post('/api/core/discount-codes/', {
            'code': 'GA10', 'discount_type': 'percent', 'value': 10,
            'apply_to_all': True, 'is_active': True,
        }, format='json')
        assert r.status_code in (200, 201)

    def test_financial_report(self):
        r = self.admin_client.get('/api/core/admin/reports/financial/')
        assert r.status_code == 200
        assert r.data['summary']['currency'] == 'IRR'

    def test_audit_logs(self):
        r = self.admin_client.get('/api/core/audit-logs/')
        assert r.status_code == 200

    def test_notification_logs(self):
        r = self.admin_client.get('/api/notifications/logs/')
        assert r.status_code == 200

    def test_refund_endpoint(self):
        # عدم وجود پرداخت → 404 (مجوز عبور کرده)
        r = self.admin_client.post('/api/core/payment/refund/999999/')
        assert r.status_code == 404

    def test_verify_reject_receipt(self):
        r = self.admin_client.post('/api/core/credit/verify/999999/')
        assert r.status_code == 404
        r = self.admin_client.post('/api/core/credit/reject/999999/')
        assert r.status_code == 404


class TestNormalUserBlocked(_Base):
    """کاربر عادی به پنل ادمین دسترسی ندارد."""

    def test_discount_codes_forbidden(self):
        r = self.normal_client.get('/api/core/discount-codes/')
        assert r.status_code == 403

    def test_financial_report_forbidden(self):
        r = self.normal_client.get('/api/core/admin/reports/financial/')
        assert r.status_code == 403

    def test_audit_logs_forbidden(self):
        r = self.normal_client.get('/api/core/audit-logs/')
        assert r.status_code == 403


class TestErrorContract(_Base):
    """هر خطا شامل error (انسانی) + detail است."""

    def test_401_has_error(self):
        anon = APIClient()
        r = anon.get('/api/core/invoices/')
        assert r.status_code == 401
        assert 'error' in r.data
        assert 'detail' in r.data

    def test_404_has_error(self):
        r = self.normal_client.get('/api/core/invoices/99999/')
        assert r.status_code == 404
        assert 'error' in r.data

    def test_validation_error_has_error(self):
        # ساخت درخواست بدون تجهیزات → ValidationError فیلدی
        r = self.normal_client.post('/api/core/inspection-requests/', {
            'city': 'تهران', 'address': 'x', 'brand_model': 'm',
        }, format='json')
        assert r.status_code == 400
        assert 'error' in r.data
        assert isinstance(r.data['error'], str) and len(r.data['error']) > 0

    def test_403_has_error(self):
        r = self.normal_client.get('/api/core/audit-logs/')
        assert r.status_code == 403
        assert 'error' in r.data

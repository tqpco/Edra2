# core/tests/test_checklist_excel_import.py
"""
تست قابلیت جدید: ایمپورت آیتم‌های چک‌لیست از فایل Excel.
- دانلود قالب نمونه (فقط ادمین)
- پیش‌نمایش (preview) بدون ذخیره
- ایمپورت واقعی و ساخت آیتم‌ها
- رد شدن فایل غیر xlsx و فایل بدون ستون الزامی
"""
import io
import os

import pytest
from django.contrib.auth import get_user_model
from django.contrib.auth.models import Group
from django.core.files.uploadedfile import SimpleUploadedFile
from openpyxl import Workbook
from rest_framework.test import APIClient

from core.models import ChecklistTemplate, ChecklistItem, EquipmentType

User = get_user_model()
pytestmark = pytest.mark.django_db
PASSWORD = os.getenv("PASSWORD", "CHANGE_ME")


def _make_xlsx(headers, rows):
    wb = Workbook()
    ws = wb.active
    ws.append(headers)
    for row in rows:
        ws.append(row)
    buf = io.BytesIO()
    wb.save(buf)
    buf.seek(0)
    return SimpleUploadedFile(
        'checklist.xlsx', buf.read(),
        content_type='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')


@pytest.fixture
def admin_client():
    admin = User.objects.create_user(
        username='xlsx_admin', password=PASSWORD, is_staff=True)
    admin_group, _ = Group.objects.get_or_create(name='Admin')
    admin.groups.add(admin_group)
    client = APIClient()
    client.force_authenticate(user=admin)
    return client


@pytest.fixture
def template():
    eq = EquipmentType.objects.create(code='tower', name_fa='تاور کرین')
    return ChecklistTemplate.objects.create(
        equipment_type=eq, name='چک‌لیست تاور کرین', version=1)


def test_import_template_download(admin_client, template):
    r = admin_client.get(
        f'/api/inspections/checklist-templates/{template.id}/import-template/')
    assert r.status_code == 200
    assert r['Content-Type'].startswith(
        'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')


def test_import_preview_no_save(admin_client, template):
    xlsx = _make_xlsx(
        ['دسته‌بندی', 'عنوان', 'توضیحات', 'ترتیب', 'نیاز به عکس', 'نیاز به یادداشت'],
        [['سازه', 'بررسی جوش‌ها', 'تست بصری', 1, 'بله', 'خیر']])
    r = admin_client.post(
        f'/api/inspections/checklist-templates/{template.id}/import-items/?preview=true',
        {'file': xlsx}, format='multipart')
    assert r.status_code == 200
    assert r.data['preview'] is True
    assert len(r.data['items']) == 1
    assert r.data['items'][0]['title'] == 'بررسی جوش‌ها'
    assert ChecklistItem.objects.filter(
        checklist_template=template).count() == 0  # بدون ذخیره


def test_import_creates_items(admin_client, template):
    xlsx = _make_xlsx(
        ['دسته‌بندی', 'عنوان', 'توضیحات', 'ترتیب', 'نیاز به عکس', 'نیاز به یادداشت'],
        [
            ['سازه فلزی', 'بررسی سلامت جوش‌ها', '', 1, 'بله', 'خیر'],
            ['سیستم بالابری', 'تست ترمز', 'تست در بار نامی', 2, 'خیر', 'بله'],
        ])
    r = admin_client.post(
        f'/api/inspections/checklist-templates/{template.id}/import-items/',
        {'file': xlsx}, format='multipart')
    assert r.status_code == 200
    assert r.data['success'] is True
    assert r.data['created_count'] == 2
    items = ChecklistItem.objects.filter(checklist_template=template)
    assert items.count() == 2
    first = items.get(order=1)
    assert first.title == 'بررسی سلامت جوش‌ها'
    assert first.requires_photo is True
    assert first.requires_note is False


def test_import_rejects_non_xlsx(admin_client, template):
    fake = SimpleUploadedFile('checklist.txt', b'not an excel', content_type='text/plain')
    r = admin_client.post(
        f'/api/inspections/checklist-templates/{template.id}/import-items/',
        {'file': fake}, format='multipart')
    assert r.status_code == 400


def test_import_requires_columns(admin_client, template):
    # بدون ستون «عنوان»
    xlsx = _make_xlsx(['دسته‌بندی'], [['سازه']])
    r = admin_client.post(
        f'/api/inspections/checklist-templates/{template.id}/import-items/',
        {'file': xlsx}, format='multipart')
    assert r.status_code == 400
    assert 'عنوان' in r.data['error']


def test_import_requires_admin(admin_client, template):
    customer = User.objects.create_user(username='xlsx_cust', password=PASSWORD)
    c = APIClient()
    c.force_authenticate(user=customer)
    xlsx = _make_xlsx(
        ['دسته‌بندی', 'عنوان'], [['سازه', 'آیتم']])
    r = c.post(
        f'/api/inspections/checklist-templates/{template.id}/import-items/',
        {'file': xlsx}, format='multipart')
    assert r.status_code == 403

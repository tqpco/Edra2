# core/tests/test_discount_flow.py
"""
تست اتصال تخفیف به زنجیره پرداخت (P1):
- اعمال واقعی روی درخواست (apply-discount) و کاهش final_price
- idempotency: اعمال تکراری بدون شمارش دوباره
- تعویض کد: آزادسازی کد قبلی + شمارش کد جدید
- پیش‌نمایش بدون تغییر used_count
- مبلغ پرداخت و snapshot فاکتور با تخفیف
"""
import os
from decimal import Decimal

import pytest
from django.contrib.auth import get_user_model
from django.contrib.auth.models import Group
from rest_framework.test import APIClient

from core.models import (
    CityMultiplier, DiscountCode, EquipmentParameter, EquipmentType,
    InspectionRequest, Invoice, Payment, PaymentMethod, UserCredit,
)
from core.services.invoice_service import InvoiceSettlementService
from core.services.money import toman_to_rial
from pricing.models import ParameterPrice, PricingRule

User = get_user_model()
pytestmark = pytest.mark.django_db
PASSWORD = os.getenv("PASSWORD", "CHANGE_ME")


class _Base:
    def setup_method(self):
        self.client = APIClient()
        self.customer = User.objects.create_user(
            username="09120000222", password=PASSWORD)
        self.admin_group, _ = Group.objects.get_or_create(name='Admin')
        self.admin = User.objects.create_user(
            username="disc_admin", password=PASSWORD, is_staff=True)
        self.admin.groups.add(self.admin_group)
        self.admin_client = APIClient()
        self.admin_client.force_authenticate(user=self.admin)
        self.client.force_authenticate(user=self.customer)

        self.eq = EquipmentType.objects.create(
            code='disc_eq', name_fa='تجهیز تخفیف')
        self.param = EquipmentParameter.objects.create(
            equipment_type=self.eq, name='tonnage', label='تناژ',
            field_type='number')
        self.rule = PricingRule.objects.create(
            equipment_type=self.eq, base_price=1000000,
            standard_multiplier=Decimal('1.0'),
            pro_multiplier=Decimal('1.0'))
        ParameterPrice.objects.create(
            pricing_rule=self.rule, parameter=self.param,
            rate_type='per_unit', rate=100000)
        CityMultiplier.objects.create(
            city='تهران', multiplier=Decimal('1.0'), base_cost=200000)

        self.d10 = DiscountCode.objects.create(
            code='DISC10', discount_type='percent', value=10,
            apply_to_all=True, is_active=True,
            usage_limit=100, per_user_limit=3)
        self.dfix = DiscountCode.objects.create(
            code='FIX50', discount_type='fixed', value=50000,
            apply_to_all=True, is_active=True,
            usage_limit=100, per_user_limit=3)

    def _make_request(self, with_discount=None):
        data = {
            'equipment_type': self.eq.id,
            'params': {'tonnage': 10},
            'city': 'تهران',
            'address': 'تست',
            'brand_model': 'مدل',
        }
        if with_discount:
            data['discount_code'] = with_discount
        r = self.client.post('/api/core/inspection-requests/', data, format='json')
        assert r.status_code == 201, r.content
        return r.data


class TestApplyDiscountAction(_Base):
    def test_apply_reduces_final_price(self):
        req = self._make_request()
        r = self.client.post(
            f"/api/core/inspection-requests/{req['id']}/apply-discount/",
            {'code': 'DISC10'}, format='json')
        assert r.status_code == 200, r.content
        assert int(r.data['discount_amount']) == 220000
        assert int(r.data['final_price']) == 1980000

        obj = InspectionRequest.objects.get(id=req['id'])
        assert obj.discount_code_id == self.d10.id
        assert int(obj.final_price) == 1980000
        self.d10.refresh_from_db()
        assert self.d10.used_count == 1

    def test_idempotent_apply_no_double_count(self):
        req = self._make_request()
        url = f"/api/core/inspection-requests/{req['id']}/apply-discount/"
        assert self.client.post(url, {'code': 'DISC10'}, format='json').status_code == 200
        assert self.client.post(url, {'code': 'DISC10'}, format='json').status_code == 200
        self.d10.refresh_from_db()
        assert self.d10.used_count == 1

    def test_switch_code_releases_old(self):
        req = self._make_request()
        url = f"/api/core/inspection-requests/{req['id']}/apply-discount/"
        assert self.client.post(url, {'code': 'DISC10'}, format='json').status_code == 200
        r = self.client.post(url, {'code': 'FIX50'}, format='json')
        assert r.status_code == 200
        self.d10.refresh_from_db()
        self.dfix.refresh_from_db()
        assert self.d10.used_count == 0   # آزاد شد
        assert self.dfix.used_count == 1
        obj = InspectionRequest.objects.get(id=req['id'])
        assert int(obj.final_price) == 2150000  # ۲٬۲۰۰٬۰۰۰ − ۵۰٬۰۰۰

    def test_preview_does_not_count(self):
        req = self._make_request()
        before = self.d10.used_count
        r = self.client.post('/api/core/discount-codes/apply/', {
            'code': 'DISC10', 'request_id': req['id'],
        }, format='json')
        assert r.status_code == 200
        assert r.data['preview'] is True
        self.d10.refresh_from_db()
        assert self.d10.used_count == before
        # درخواست تغییری نکرد
        obj = InspectionRequest.objects.get(id=req['id'])
        assert int(obj.final_price) == 2200000

    def test_apply_after_payment_forbidden(self):
        req = self._make_request()
        obj = InspectionRequest.objects.get(id=req['id'])
        obj.status = 'scheduled'
        obj.save(update_fields=['status'])
        r = self.client.post(
            f"/api/core/inspection-requests/{req['id']}/apply-discount/",
            {'code': 'DISC10'}, format='json')
        assert r.status_code == 400

    def test_other_customer_cannot_apply(self):
        req = self._make_request()
        other = User.objects.create_user(username="09120000333", password=PASSWORD)
        client2 = APIClient()
        client2.force_authenticate(user=other)
        r = client2.post(
            f"/api/core/inspection-requests/{req['id']}/apply-discount/",
            {'code': 'DISC10'}, format='json')
        assert r.status_code == 404

    def test_apply_at_creation_counts_once(self):
        # ساخت درخواست همراه با کد → used_count فقط یک‌بار
        self._make_request(with_discount='DISC10')
        self.d10.refresh_from_db()
        assert self.d10.used_count == 1
        # اعمال روی درخواست دوم → شمارش دوم (تا سقف ۳ مجاز)
        req2 = self._make_request()
        r = self.client.post(
            f"/api/core/inspection-requests/{req2['id']}/apply-discount/",
            {'code': 'DISC10'}, format='json')
        assert r.status_code == 200
        self.d10.refresh_from_db()
        assert self.d10.used_count == 2
        # چهارمین استفاده → رد (سقف per_user_limit=3)
        req3 = self._make_request()
        assert self.client.post(
            f"/api/core/inspection-requests/{req3['id']}/apply-discount/",
            {'code': 'DISC10'}, format='json').status_code == 200
        req4 = self._make_request()
        r4 = self.client.post(
            f"/api/core/inspection-requests/{req4['id']}/apply-discount/",
            {'code': 'DISC10'}, format='json')
        assert r4.status_code == 400  # سقف ۳

    def test_payment_and_invoice_reflect_discount(self):
        req = self._make_request()
        url = f"/api/core/inspection-requests/{req['id']}/apply-discount/"
        assert self.client.post(url, {'code': 'DISC10'}, format='json').status_code == 200

        # مبلغ نهایی شامل ۹٪ مالیات (P0-6): ۱٬۹۸۰٬۰۰۰ × ۱.۰۹ = ۲٬۱۵۸٬۲۰۰
        final = 2158200
        UserCredit.objects.create(user=self.customer, balance=final)
        method, _ = PaymentMethod.objects.get_or_create(
            name='credit', defaults={'is_active': True})
        from core.services.credit_service import CreditService
        reservation = CreditService.reserve(
            self.customer, final,
            inspection_request=InspectionRequest.objects.get(id=req['id']))
        payment = Payment.objects.create(
            inspection_request_id=req['id'],
            amount=final,
            amount_rial=toman_to_rial(final),
            credit_amount=final,
            online_amount=0,
            method=method,
            status='paid',
            verified_at=None,
        )
        reservation.payment = payment
        reservation.save(update_fields=['payment'])
        CreditService.consume(reservation)

        invoice, _ = InvoiceSettlementService.settle(
            InspectionRequest.objects.get(id=req['id']), payment=payment,
            is_paid=True)
        assert int(invoice.base_amount) == 2200000
        assert int(invoice.discount_amount) == 220000
        assert int(invoice.total_amount) == 1980000
        assert int(invoice.final_rial) == 21582000
        assert int(payment.amount_rial) == 21582000  # شامل مالیات (P0-6)

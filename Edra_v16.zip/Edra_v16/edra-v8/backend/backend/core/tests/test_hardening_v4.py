# core/tests/test_hardening_v4.py
"""
تست‌های سخت‌سازی V4 (گزارش V3):
- throttle مسیرهای حساس (payment_initiate / public_verify)
- error contract با کلید code
- Public Verify بدون نشت داده داخلی
- دانلود محافظت‌شده PDF فاکتور/گزارش (IDOR)
- هش SHA-256 فیش بانکی
- رویداد audit برای ورود OTP و تخصیص کارشناس
"""
import hashlib
import os

import pytest
from django.contrib.auth import get_user_model
from django.contrib.auth.models import Group
from rest_framework.test import APIClient

from core.models import (
    AuditLog, EquipmentType, InspectionRequest, Invoice, Payment,
    PaymentMethod, ReportVerification, UserCredit,
)
from core.services.invoice_service import InvoiceSettlementService
from core.services.money import toman_to_rial

User = get_user_model()
pytestmark = pytest.mark.django_db
PASSWORD = os.getenv("PASSWORD", "CHANGE_ME")


class _Base:
    def setup_method(self):
        self.client = APIClient()
        self.customer = User.objects.create_user(
            username="09120004001", password=PASSWORD)
        self.other = User.objects.create_user(
            username="09120004002", password=PASSWORD)
        self.admin_group, _ = Group.objects.get_or_create(name='Admin')
        self.admin = User.objects.create_user(
            username="v4_admin", password=PASSWORD, is_staff=True)
        self.admin.groups.add(self.admin_group)
        self.admin_client = APIClient()
        self.admin_client.force_authenticate(user=self.admin)
        self.client.force_authenticate(user=self.customer)

        self.eq = EquipmentType.objects.create(
            code='v4_eq', name_fa='تجهیز v4')
        self.request = InspectionRequest.objects.create(
            customer=self.customer,
            equipment_type=self.eq,
            city='تهران',
            address='تست',
            brand_model='م',
            calculated_price=1000000,
            final_price=1000000,
            status='pending_payment',
        )


class TestErrorCodeContract(_Base):
    def test_404_has_code(self):
        r = self.client.get('/api/core/invoices/99999/')
        assert r.status_code == 404
        assert r.data['code'] == 'NOT_FOUND'

    def test_401_has_code(self):
        anon = APIClient()
        r = anon.get('/api/core/invoices/')
        assert r.status_code == 401
        assert r.data['code'] == 'UNAUTHENTICATED'

    def test_403_has_code(self):
        r = self.client.get('/api/core/audit-logs/')
        assert r.status_code == 403
        assert r.data['code'] == 'FORBIDDEN'


class TestThrottle(_Base):
    def test_public_verify_throttled(self, monkeypatch):
        from django.core.cache import cache
        cache.clear()
        from rest_framework.throttling import ScopedRateThrottle
        # نرخ را برای تست پایین می‌آوریم
        monkeypatch.setattr(
            ScopedRateThrottle, 'THROTTLE_RATES', {'public_verify': '2/hour'})
        from core.models import InspectionReport
        report = InspectionReport.objects.create(
            inspection_request=self.request,
            report_number='V4-TEST-1',
            overall_result='pass',
            results=[],
        )
        verification = ReportVerification.objects.create(
            report=report, verification_code='V4CODE123456')
        url = (f'/api/inspections/report-verification/'
               f'{verification.verification_code}/')
        anon = APIClient()
        assert anon.get(url).status_code == 200
        assert anon.get(url).status_code == 200
        r = anon.get(url)
        assert r.status_code == 429
        assert r.data['code'] == 'RATE_LIMITED'


class TestPublicVerifyNoLeak(_Base):
    def test_response_has_no_sensitive_data(self):
        from core.models import InspectionReport
        report = InspectionReport.objects.create(
            inspection_request=self.request,
            report_number='V4-TEST-2',
            overall_result='pass',
            results=[],
            inspector_notes='یادداشت داخلی محرمانه',
        )
        verification = ReportVerification.objects.create(
            report=report, verification_code='V4SECRET99999')
        anon = APIClient()
        r = anon.get(
            f'/api/inspections/report-verification/'
            f'{verification.verification_code}/')
        assert r.status_code == 200
        payload = str(r.data)
        # نشت ممنوع: مبلغ/مشتری/یادداشت/فایل خصوصی
        assert 'inspector_notes' not in payload
        assert 'یادداشت داخلی' not in payload
        assert 'amount' not in payload
        assert self.customer.username not in payload
        assert 'pdf_file' not in payload or 'pdf' not in payload.lower()
        # فقط داده مجاز
        assert r.data['verification_code'] == 'V4SECRET99999'
        assert r.data['report_number'] == 'V4-TEST-2'


class TestProtectedPdfDownloads(_Base):
    def _paid_invoice(self):
        method, _ = PaymentMethod.objects.get_or_create(
            name='online', defaults={'is_active': True})
        payment = Payment.objects.create(
            inspection_request=self.request,
            amount=1090000,
            amount_rial=10900000,
            online_amount=1090000,
            method=method,
            status='paid',
        )
        invoice, _ = InvoiceSettlementService.settle(
            self.request, payment=payment, is_paid=True)
        return invoice

    def test_invoice_pdf_owner_ok_other_404(self):
        invoice = self._paid_invoice()
        r = self.client.get(f'/api/core/invoices/{invoice.id}/pdf/')
        assert r.status_code == 200
        assert r['Content-Type'].startswith('application/pdf')

        other_client = APIClient()
        other_client.force_authenticate(user=self.other)
        r = other_client.get(f'/api/core/invoices/{invoice.id}/pdf/')
        assert r.status_code == 404  # IDOR blocked

    def test_invoice_pdf_admin_ok(self):
        invoice = self._paid_invoice()
        r = self.admin_client.get(f'/api/core/invoices/{invoice.id}/pdf/')
        assert r.status_code == 200


class TestReceiptHash(_Base):
    def test_hash_stored_on_upload(self):
        from django.core.files.uploadedfile import SimpleUploadedFile
        method, _ = PaymentMethod.objects.get_or_create(
            name='manual', defaults={'is_active': True})
        content = b'\x89PNG\r\n\x1a\nfake-png-content-for-hash'
        payment = Payment.objects.create(
            inspection_request=self.request,
            amount=1090000,
            amount_rial=10900000,
            manual_amount=1090000,
            method=method,
            status='pending_verification',
            bank_receipt=SimpleUploadedFile(
                'receipt.png', content, content_type='image/png'),
        )
        # شبیه‌سازی مسیر آپلود: هش روی فیلد ثبت می‌شود
        payment.bank_receipt_hash = hashlib.sha256(content).hexdigest()
        payment.save(update_fields=['bank_receipt_hash'])
        payment.refresh_from_db()
        assert payment.bank_receipt_hash == hashlib.sha256(content).hexdigest()
        assert len(payment.bank_receipt_hash) == 64


class TestAuditEvents(_Base):
    def test_otp_login_audited(self, monkeypatch):
        from django.conf import settings
        monkeypatch.setattr(settings, 'DEV_OTP_ENABLED', True)
        monkeypatch.setattr(settings, 'DEV_OTP_ALLOWED_PHONES',
                            ['09120004001'])
        monkeypatch.setattr(settings, 'DEV_OTP_CODE', '246810')
        anon = APIClient()
        assert anon.post('/api/core/otp/request/',
                         {'phone': '09120004001'}).status_code == 200
        assert anon.post('/api/core/otp/verify/',
                         {'phone': '09120004001',
                          'code': '246810'}).status_code == 200
        assert AuditLog.objects.filter(action='otp_login').exists()

    def test_assign_expert_audited(self):
        expert = User.objects.create_user(
            username="v4_expert", password=PASSWORD)
        expert_group, _ = Group.objects.get_or_create(name='Expert')
        expert.groups.add(expert_group)
        r = self.admin_client.post(
            f'/api/core/inspection-requests/{self.request.id}/assign_expert/',
            {'expert_id': expert.id}, format='json')
        assert r.status_code == 200
        assert AuditLog.objects.filter(
            action='assign_expert', object_id=self.request.id).exists()

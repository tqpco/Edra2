# core/tests/test_integration.py
import pytest
import os
from django.contrib.auth import get_user_model
from django.contrib.auth.models import Group
from rest_framework.test import APIClient
from core.models import EquipmentType, InspectionRequest

User = get_user_model()

pytestmark = pytest.mark.django_db


class TestFullScenario:
    def setup_method(self):
        self.client = APIClient()
        self.user = User.objects.create_user(
            username="customer", password=os.getenv(
                "PASSWORD", "CHANGE_ME"))

        # ایجاد ادمین با گروه Admin
        self.admin = User.objects.create_superuser(
            username="admin", password=os.getenv(
                "PASSWORD", "CHANGE_ME"))
        admin_group, _ = Group.objects.get_or_create(name="Admin")
        self.admin.groups.add(admin_group)

        self.expert = User.objects.create_user(
            username="expert", password=os.getenv(
                "PASSWORD", "CHANGE_ME"))
        self.eq = EquipmentType.objects.create(
            name_fa="تست",
            code="TEST",
            param_schema={}
        )

    def test_full_workflow(self):
        # 1. ایجاد درخواست با format='json'
        response = self.client.post(
            "/api/core/inspection-requests/",
            {
                "city": "تهران",
                "address": "خیابان تست، پلاک ۱۲۳",
                "equipment_type": self.eq.id,
                "brand_model": "مدل تست",
                "manufacture_year": 1400,
                "params": {},
                "install_state": "installed",
                "phone": "09123456789",
            },
            format='json'  # ✅ ضروری برای ارسال دیکشنری params
        )
        assert response.status_code == 201, f"Response data: {response.data}"
        request_id = response.data["id"]

        # 2. تخصیص کارشناس (با ادمین)
        self.client.force_authenticate(user=self.admin)
        response = self.client.post(
            f"/api/core/inspection-requests/{request_id}/assign_expert/", {
                "expert_id": self.expert.id})
        assert response.status_code == 200

        # 3. تغییر وضعیت به paid (با ادمین)
        response = self.client.post(
            f"/api/core/inspection-requests/{request_id}/change_status/", {"status": "paid"})
        assert response.status_code == 200

        # 4. بررسی اینکه فاکتور ایجاد شده است
        request_obj = InspectionRequest.objects.get(id=request_id)
        assert hasattr(request_obj, 'invoice')

        # 5. بررسی وضعیت نهایی
        request_obj.refresh_from_db()
        assert request_obj.status == "paid"

# core/tests/test_integrations.py
"""
تست یکپارچه‌سازی‌های جدید (P2):
- SMS واقعی Kavenegar (با requests مقلد) و fallback لاگ
- فلگ تولید PDF ناهمزمان (PDF_GENERATION_ASYNC)
- امضای دیجیتال PAdES با گواهی تست
"""
import os
from decimal import Decimal
from unittest import mock

import pytest
from django.conf import settings
from django.contrib.auth import get_user_model
from django.core.files.uploadedfile import SimpleUploadedFile

from core.models import EquipmentType, InspectionRequest, Invoice
from notifications.models import NotificationLog, NotificationTemplate
from pricing.models import PricingRule

User = get_user_model()
pytestmark = pytest.mark.django_db


class _Base:
    def setup_method(self):
        self.customer = User.objects.create_user(
            username="09120000555", password="CHANGE_ME")
        self.eq = EquipmentType.objects.create(
            code='int_eq', name_fa='تجهیز یکپارچه')
        self.request = InspectionRequest.objects.create(
            customer=self.customer,
            equipment_type=self.eq,
            city="تهران",
            address="تست",
            brand_model="م",
            calculated_price=1000000,
            final_price=1000000,
            status='pending_payment',
        )


class TestSMSProvider(_Base):
    def _template(self):
        return NotificationTemplate.objects.create(
            code='sms_test', channel='sms', subject='تست',
            body_template='سلام {user.username}', is_active=True)

    def test_fallback_logs_and_succeeds(self):
        """بدون کلید → لاگ + وضعیت sent."""
        template = self._template()
        from notifications.services import send_notification
        send_notification(self.customer, 'sms_test')
        log = NotificationLog.objects.get(type='sms_test')
        assert log.status == 'sent'
        assert log.recipient == '09120000555'  # username fallback

    def test_kavenegar_success(self):
        template = self._template()
        with mock.patch.dict(
                'os.environ', {'SMS_PROVIDER': 'kavenegar',
                               'SMS_API_KEY': 'FAKE-KEY'}):
            # settings خوانده می‌شوند؛ مقدار را هم مستقیماً ست می‌کنیم
            settings.SMS_PROVIDER = 'kavenegar'
            settings.SMS_API_KEY = 'FAKE-KEY'
            from notifications.services import send_notification
            with mock.patch('requests.post') as mock_post:
                mock_post.return_value.json.return_value = {
                    'return': {'status': 200, 'message': 'ok'}}
                mock_post.return_value.raise_for_status.return_value = None
                send_notification(self.customer, 'sms_test')

            mock_post.assert_called_once()
            assert '/FAKE-KEY/sms/send.json' in mock_post.call_args[0][0]
            assert mock_post.call_args.kwargs['data']['receptor'] == '09120000555'
        settings.SMS_PROVIDER = ''
        settings.SMS_API_KEY = ''

        log = NotificationLog.objects.get(type='sms_test')
        assert log.status == 'sent'

    def test_kavenegar_failure_marks_failed(self):
        self._template()
        settings.SMS_PROVIDER = 'kavenegar'
        settings.SMS_API_KEY = 'FAKE-KEY'
        from notifications.services import send_notification
        with mock.patch('requests.post') as mock_post:
            mock_post.return_value.json.return_value = {
                'return': {'status': 403, 'message': 'invalid api key'}}
            mock_post.return_value.raise_for_status.return_value = None
            send_notification(self.customer, 'sms_test')
        settings.SMS_PROVIDER = ''
        settings.SMS_API_KEY = ''
        log = NotificationLog.objects.get(type='sms_test')
        assert log.status == 'failed'
        assert 'invalid api key' in log.error_message


class TestAsyncPdfFlag(_Base):
    def test_sync_default_generates_pdf(self):
        from core.services.invoice_service import InvoiceSettlementService
        settings.PDF_GENERATION_ASYNC = False
        invoice, created = InvoiceSettlementService.settle(
            self.request, is_paid=True)
        assert created is True
        invoice.refresh_from_db()
        assert invoice.pdf_file
        assert invoice.status == 'generated'

    def test_async_flag_queues_task(self):
        from core.services.invoice_service import InvoiceSettlementService
        settings.PDF_GENERATION_ASYNC = True
        try:
            invoice, created = InvoiceSettlementService.settle(
                self.request, is_paid=True)
            assert created is True
            invoice.refresh_from_db()
            # در حالت async (بدون worker فعال) وضعیت pending می‌ماند؛
            # تولید واقعی توسط worker انجام می‌شود.
            assert invoice.status == 'pending'
        finally:
            settings.PDF_GENERATION_ASYNC = False


class TestPadesSignature(_Base):
    def _real_pdf(self):
        from core.services.invoice_service import InvoiceSettlementService
        settings.PDF_GENERATION_ASYNC = False
        invoice, _ = InvoiceSettlementService.settle(self.request, is_paid=True)
        return invoice.pdf_file.read()

    def test_signs_with_test_cert(self):
        cert = os.path.abspath('certs/edra_test_cert.pem')
        key = os.path.abspath('certs/edra_test_key.pem')
        if not (os.path.exists(cert) and os.path.exists(key)):
            pytest.skip("گواهی تست موجود نیست")
        from inspections.utils import sign_pdf_with_pyhanko
        raw = self._real_pdf()
        signed = sign_pdf_with_pyhanko(raw, cert_path=cert, key_path=key)
        assert signed != raw
        assert b'/Sig' in signed

    def test_returns_original_without_cert(self):
        from inspections.utils import sign_pdf_with_pyhanko
        raw = self._real_pdf()
        settings.PDF_SIGN_CERT_PATH = ''
        settings.PDF_SIGN_KEY_PATH = ''
        assert sign_pdf_with_pyhanko(raw) == raw

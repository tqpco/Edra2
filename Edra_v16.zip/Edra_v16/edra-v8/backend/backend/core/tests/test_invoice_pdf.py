import pytest
import os
from django.contrib.auth import get_user_model
from core.models import EquipmentType, InspectionRequest
from core.services.invoice_service import InvoiceSettlementService

User = get_user_model()

pytestmark = pytest.mark.django_db


class TestInvoicePDF:
    def test_create_invoice(self):
        # فاکتور فقط از سرویس مرکزی ساخته می‌شود (FIN-01/FIN-02)
        user = User.objects.create_user(
            username="09121112222", password=os.getenv(
                "PASSWORD", "CHANGE_ME"))
        eq = EquipmentType.objects.create(
            name_fa="تست",
            code="TEST",
            param_schema={}
        )
        request = InspectionRequest.objects.create(
            customer=user,
            equipment_type=eq,
            city="تهران",
            address="تست",
            final_price=1000000,
            calculated_price=1000000,
            status="pending_payment"
        )
        invoice, created = InvoiceSettlementService.settle(
            request, is_paid=True)
        assert created is True
        assert invoice.invoice_number.startswith("INV-")
        assert invoice.final_amount == 1090000
        assert invoice.final_rial == 10900000

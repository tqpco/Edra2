# core/tests/test_ledger.py
"""
تست دفتر کل و عودت حسابداری (P0-7/15 گزارش V3):
- ثبت settlement خودکار و idempotent
- append-only بودن LedgerEntry
- refund با reason/performed_by/gateway_ref + reversal entry
- گزارش مالی از دفتر کل reconcile می‌شود و بدون float است
"""
import os
from decimal import Decimal

import pytest
from django.contrib.auth import get_user_model
from django.contrib.auth.models import Group
from rest_framework.test import APIClient

from core.models import (
    EquipmentType, InspectionRequest, Invoice, LedgerEntry, Payment,
    PaymentMethod, UserCredit,
)
from core.services.invoice_service import InvoiceSettlementService
from core.services.money import toman_to_rial

User = get_user_model()
pytestmark = pytest.mark.django_db
PASSWORD = os.getenv("PASSWORD", "CHANGE_ME")


class _Base:
    def setup_method(self):
        self.customer = User.objects.create_user(
            username="09120003001", password=PASSWORD)
        self.admin_group, _ = Group.objects.get_or_create(name='Admin')
        self.admin = User.objects.create_user(
            username="ledger_admin", password=PASSWORD, is_staff=True)
        self.admin.groups.add(self.admin_group)
        self.admin_client = APIClient()
        self.admin_client.force_authenticate(user=self.admin)

        self.eq = EquipmentType.objects.create(
            code='ledger_eq', name_fa='تجهیز لجر')
        self.request = InspectionRequest.objects.create(
            customer=self.customer,
            equipment_type=self.eq,
            city='تهران',
            address='تست',
            brand_model='م',
            calculated_price=1000000,
            final_price=1000000,
            status='pending_payment',
        )

    def _pay_and_settle(self):
        method, _ = PaymentMethod.objects.get_or_create(
            name='online', defaults={'is_active': True})
        payment = Payment.objects.create(
            inspection_request=self.request,
            amount=1090000,
            amount_rial=10900000,
            online_amount=1090000,
            method=method,
            status='paid',
            ref_id='LEDGER-REF-1',
        )
        invoice, _ = InvoiceSettlementService.settle(
            self.request, payment=payment, is_paid=True)
        return payment, invoice


class TestLedgerSettlement(_Base):
    def test_settlement_entry_created(self):
        payment, invoice = self._pay_and_settle()
        entry = LedgerEntry.objects.get(
            payment=payment, entry_type='settlement')
        assert int(entry.amount_rial) == 10900000
        assert entry.reference == 'LEDGER-REF-1'

    def test_settlement_idempotent(self):
        payment, invoice = self._pay_and_settle()
        # settle تکراری → بدون ورودی دوم
        InvoiceSettlementService.settle(
            self.request, payment=payment, is_paid=True)
        assert LedgerEntry.objects.filter(
            payment=payment, entry_type='settlement').count() == 1

    def test_append_only(self):
        payment, invoice = self._pay_and_settle()
        entry = LedgerEntry.objects.get(payment=payment)
        with pytest.raises(ValueError):
            entry.amount_rial = 1
            entry.save()
        with pytest.raises(ValueError):
            entry.delete()


class TestRefundLedger(_Base):
    def test_refund_full_flow(self):
        payment, invoice = self._pay_and_settle()
        r = self.admin_client.post(
            f"/api/core/payment/refund/{payment.id}/", {
                'reason': 'خطای انسانی در ثبت',
                'gateway_ref': 'GW-REFUND-1',
            }, format='json')
        assert r.status_code == 200, r.content
        assert r.data['reason'] == 'خطای انسانی در ثبت'

        refund = LedgerEntry.objects.get(
            payment=payment, entry_type='refund')
        assert int(refund.amount_rial) == 10900000
        assert refund.performed_by_id == self.admin.id
        assert refund.metadata['reason'] == 'خطای انسانی در ثبت'
        assert refund.reference == 'GW-REFUND-1'

        payment.refresh_from_db()
        assert payment.status == 'refunded'

    def test_report_reconciles_from_ledger(self):
        payment, invoice = self._pay_and_settle()
        r = self.admin_client.get('/api/core/admin/reports/financial/')
        assert r.status_code == 200
        s = r.data['summary']
        # مقادیر int و بدون float
        assert isinstance(s['total_revenue_rial'], int)
        assert s['ledger_reconciled'] is True
        assert s['total_revenue_rial'] == 10900000

        # عودت → درآمد لجر صفر می‌شود
        assert self.admin_client.post(
            f"/api/core/payment/refund/{payment.id}/",
            {'reason': 'تست'}, format='json').status_code == 200
        r = self.admin_client.get('/api/core/admin/reports/financial/')
        s = r.data['summary']
        assert s['total_revenue_rial'] == 0
        assert s['ledger_refunds_rial'] == 10900000

# core/tests/test_metrics_and_groups.py
"""
تست P2:
- /metrics/ (Prometheus) فقط برای Admin؛ خروجی فرمت Prometheus معتبر
- دستور مدیریتی setup_groups گروه‌های Admin/Expert/Support را idempotent می‌سازد
"""
import io
import os

import pytest
from django.contrib.auth import get_user_model
from django.contrib.auth.models import Group
from django.core.management import call_command
from django.test import Client
from rest_framework.test import APIClient

User = get_user_model()
pytestmark = pytest.mark.django_db
PASSWORD = os.getenv("PASSWORD", "CHANGE_ME")


@pytest.fixture
def users():
    admin = User.objects.create_user(
        username='m_admin', password=PASSWORD, is_staff=True)
    admin_group, _ = Group.objects.get_or_create(name='Admin')
    admin.groups.add(admin_group)
    customer = User.objects.create_user(
        username='m_cust', password=PASSWORD)
    return admin, customer


class TestMetricsEndpoint:
    def test_metrics_requires_admin(self, users):
        admin, customer = users
        c = Client()
        # anonymous
        assert c.get('/metrics/').status_code == 403
        # مشتری معمولی
        c.force_login(customer)
        assert c.get('/metrics/').status_code == 403
        c.logout()
        # ادمین
        c.force_login(admin)
        r = c.get('/metrics/')
        assert r.status_code == 200
        body = r.content.decode('utf-8')
        assert 'django_http_requests_total' in body  # فرمت Prometheus
        assert '# HELP' in body or '# TYPE' in body


class TestSetupGroupsCommand:
    def test_creates_groups_idempotently(self):
        out = io.StringIO()
        call_command('setup_groups', stdout=out)
        assert Group.objects.filter(name='Admin').exists()
        assert Group.objects.filter(name='Expert').exists()
        assert Group.objects.filter(name='Support').exists()

        # idempotent — اجرای دوم هم موفق است
        out2 = io.StringIO()
        call_command('setup_groups', stdout=out2)
        assert 'Admin' in out2.getvalue()

    def test_admin_group_has_all_permissions(self):
        call_command('setup_groups')
        group = Group.objects.get(name='Admin')
        # حداقل دسترسی‌های مدل InspectionRequest را دارد
        from django.contrib.contenttypes.models import ContentType
        from django.contrib.auth.models import Permission
        ct = ContentType.objects.get_for_model(
            __import__('core.models', fromlist=['InspectionRequest']).InspectionRequest)
        assert group.permissions.filter(
            content_type=ct, codename='view_inspectionrequest').exists()
        assert group.permissions.filter(
            content_type=ct, codename='change_inspectionrequest').exists()

    def test_support_group_has_ticket_permissions(self):
        call_command('setup_groups')
        group = Group.objects.get(name='Support')
        from django.contrib.contenttypes.models import ContentType
        ct = ContentType.objects.get(
            app_label='support', model='ticket')
        assert group.permissions.filter(
            content_type=ct, codename__startswith='view_').exists()

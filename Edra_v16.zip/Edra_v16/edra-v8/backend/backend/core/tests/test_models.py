import pytest
import os
from django.contrib.auth import get_user_model
from core.models import EquipmentType, InspectionRequest

User = get_user_model()

pytestmark = pytest.mark.django_db


class TestEquipmentType:
    def test_create_equipment_type(self):
        eq = EquipmentType.objects.create(
            name_fa="تست",
            code="TEST",
            param_schema={}
        )
        assert eq.name_fa == "تست"
        assert eq.code == "TEST"


class TestInspectionRequest:
    def test_create_inspection_request(self):
        user = User.objects.create_user(
            username="testuser", password=os.getenv(
                "PASSWORD", "CHANGE_ME"))
        eq = EquipmentType.objects.create(
            name_fa="تست",
            code="TEST",
            param_schema={}
        )
        request = InspectionRequest.objects.create(
            customer=user,
            equipment_type=eq,
            city="تهران",
            address="خیابان تست",
            brand_model="مدل تست",
            final_price=1000000,
            calculated_price=1000000,
            status="pending_payment"
        )
        assert request.customer == user
        assert request.status == "pending_payment"
        assert request.final_price == 1000000

    def test_request_status_choices(self):
        assert InspectionRequest.STATUS_CHOICES[0][0] == "draft"
        assert InspectionRequest.STATUS_CHOICES[1][0] == "pending_payment"

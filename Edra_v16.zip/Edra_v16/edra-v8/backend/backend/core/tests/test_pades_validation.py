# core/tests/test_pades_validation.py
"""
تست اعتبارسنجی امضای دیجیتال PAdES (P0-10 گزارش V3):

- امضای واقعی PAdES با گواهی تست (pyhanko.sign)
- اعتبارسنجی رمزنگاری واقعی با openssl cms:
  استخراج /ByteRange و /Contents از شیء امضا و verify روی محتوای
  ByteRange-sliced (بدون نیاز به trust chain — بررسی یکپارچگی امضا).
- تست دستکاری: تغییر یک بایت → امضا دیگر معتبر نیست (تشخیص tamper).

نکته: پکیج pyhanko این محیط بدون ماژول validation عرضه شده؛ به همین دلیل
اعتبارسنجی با openssl انجام می‌شود که معادل رمزنگاری همان بررسی است.
"""
import io
import os
import shutil
import subprocess
import tempfile

import pytest
from django.conf import settings
from django.contrib.auth import get_user_model

from core.models import EquipmentType, InspectionRequest
from core.services.invoice_service import InvoiceSettlementService

User = get_user_model()
pytestmark = pytest.mark.django_db
PASSWORD = os.getenv("PASSWORD", "CHANGE_ME")

_OPENSSL = shutil.which('openssl')


def _real_pdf():
    user = User.objects.create_user(username="09120005001", password=PASSWORD)
    eq = EquipmentType.objects.create(code='pades_eq', name_fa='امضا pades')
    request = InspectionRequest.objects.create(
        customer=user, equipment_type=eq, city='تهران', address='تست',
        brand_model='م', calculated_price=1000000, final_price=1000000,
        status='pending_payment')
    settings.PDF_GENERATION_ASYNC = False
    invoice, _ = InvoiceSettlementService.settle(request, is_paid=True)
    return invoice.pdf_file.read()


def _extract_signature(pdf_bytes):
    """استخراج (byte_range, sig_der, signed_content) از PDF امضاشده
    با parsing مستقیم دیکشنری امضا (مستقل از API خواننده pyhanko)."""
    import re
    m = re.search(
        rb'/ByteRange\s*\[\s*(\d+)\s+(\d+)\s+(\d+)\s+(\d+)\s*\]',
        pdf_bytes)
    assert m, "ByteRange امضا یافت نشد"
    br = [int(x) for x in m.groups()]
    # قرارداد PDF: [start1, length1, start2, length2]
    content = (
        pdf_bytes[br[0]:br[0] + br[1]]
        + pdf_bytes[br[2]:br[2] + br[3]])
    m2 = re.search(rb'/Contents\s*<([0-9a-fA-F\s]*)>', pdf_bytes)
    assert m2, "Contents امضا یافت نشد"
    sig_der = bytes.fromhex(
        re.sub(rb'\s', b'', m2.group(1)).decode())
    return br, sig_der, content


class TestPadesValidation:
    def test_sign_and_cryptographic_validation(self):
        if _OPENSSL is None:
            pytest.skip("openssl در دسترس نیست")
        cert = os.path.abspath('certs/edra_test_cert.pem')
        key = os.path.abspath('certs/edra_test_key.pem')
        if not (os.path.exists(cert) and os.path.exists(key)):
            pytest.skip("گواهی تست موجود نیست")

        from inspections.utils import sign_pdf_with_pyhanko
        raw = _real_pdf()
        signed = sign_pdf_with_pyhanko(raw, cert_path=cert, key_path=key)
        assert signed != raw and b'/Sig' in signed

        br, sig_der, content = _extract_signature(signed)
        # ByteRange معتبر است (offset+length)
        assert br[0] == 0 and br[1] < br[2] and br[2] + br[3] <= len(signed)

        with tempfile.TemporaryDirectory() as tmp:
            sig_path = os.path.join(tmp, 'sig.der')
            content_path = os.path.join(tmp, 'content.bin')
            open(sig_path, 'wb').write(sig_der)
            open(content_path, 'wb').write(content)

            # verify رمزنگاری امضا روی محتوای ByteRange-sliced
            result = subprocess.run(
                [_OPENSSL, 'cms', '-verify', '-inform', 'DER',
                 '-in', sig_path, '-content', content_path,
                 '-binary', '-noverify', '-out', os.devnull],
                capture_output=True, timeout=30)
            assert result.returncode == 0, (
                f"امضا از نظر رمزنگاری معتبر نیست: {result.stderr[:200]}")

    def test_tamper_detection(self):
        """تغییر یک بایت در سند → امضا دیگر معتبر نیست."""
        if _OPENSSL is None:
            pytest.skip("openssl در دسترس نیست")
        cert = os.path.abspath('certs/edra_test_cert.pem')
        key = os.path.abspath('certs/edra_test_key.pem')
        if not (os.path.exists(cert) and os.path.exists(key)):
            pytest.skip("گواهی تست موجود نیست")

        from inspections.utils import sign_pdf_with_pyhanko
        raw = _real_pdf()
        signed = sign_pdf_with_pyhanko(raw, cert_path=cert, key_path=key)

        br, sig_der, content = _extract_signature(signed)
        # دستکاری: تغییر یک بایت از محتوای سند (نه داخل امضا)
        tampered_content = bytearray(content)
        tampered_content[10] ^= 0xFF

        with tempfile.TemporaryDirectory() as tmp:
            sig_path = os.path.join(tmp, 'sig.der')
            content_path = os.path.join(tmp, 'content.bin')
            open(sig_path, 'wb').write(sig_der)
            open(content_path, 'wb').write(bytes(tampered_content))
            result = subprocess.run(
                [_OPENSSL, 'cms', '-verify', '-inform', 'DER',
                 '-in', sig_path, '-content', content_path,
                 '-binary', '-noverify', '-out', os.devnull],
                capture_output=True, timeout=30)
            assert result.returncode != 0, (
                "سند دستکاری‌شده نباید امضای معتبر داشته باشد")

    def test_without_cert_no_signature(self):
        from inspections.utils import sign_pdf_with_pyhanko
        raw = _real_pdf()
        settings.PDF_SIGN_CERT_PATH = ''
        settings.PDF_SIGN_KEY_PATH = ''
        unsigned = sign_pdf_with_pyhanko(raw)
        assert unsigned == raw
        assert b'/Sig' not in unsigned

# core/tests/test_reference_financial.py
"""
تست مرجع مالی (گزارش V3، بندهای ۴۶ و ۴۷) — قرارداد رسمی:

Base   = 100,000,000 تومان
Discount = 10,000,000 (٪۱۰)
Tax    = 8,100,000 (٪۹ از ۹۰٬۰۰۰٬۰۰۰)
Final  = 98,100,000 تومان
درگاه  = 981,000,000 ریال (پرداخت نقدی کامل)
حسابداری = 981,000,000 IRR
UI     = 98,100,000 تومان

ترکیبی (بند ۴۷):
Invoice = 98,100,000 تومان
Credit  = 20,000,000 تومان
Online  = 78,100,000 تومان
Gateway = 781,000,000 IRR
Payment.amount = 98,100,000
Payment.amount_rial = 981,000,000
credit + online = total
"""
import os
from decimal import Decimal

import pytest
from django.contrib.auth import get_user_model
from django.contrib.auth.models import Group
from rest_framework.test import APIClient

from core.models import (
    CityMultiplier, EquipmentParameter, EquipmentType, InspectionRequest,
    Invoice, Payment, UserCredit,
)
from core.services.invoice_service import InvoiceSettlementService
from core.services.money import toman_to_rial
from pricing.models import ParameterPrice, PricingRule

User = get_user_model()
pytestmark = pytest.mark.django_db
PASSWORD = os.getenv("PASSWORD", "CHANGE_ME")

BASE = Decimal('100000000')
DISCOUNT = Decimal('10000000')
NET = BASE - DISCOUNT                      # 90,000,000
TAX = (NET * Decimal('0.09')).quantize(Decimal(1))   # 8,100,000
FINAL = NET + TAX                          # 98,100,000
FINAL_RIAL = toman_to_rial(FINAL)          # 981,000,000


class _Base:
    def setup_method(self):
        self.client = APIClient()
        self.customer = User.objects.create_user(
            username="09120001000", password=PASSWORD)
        self.client.force_authenticate(user=self.customer)

        self.eq = EquipmentType.objects.create(
            code='ref_eq', name_fa='تجهیز مرجع')
        self.rule = PricingRule.objects.create(
            equipment_type=self.eq, base_price=BASE,
            standard_multiplier=Decimal('1.0'),
            pro_multiplier=Decimal('1.0'))
        CityMultiplier.objects.create(
            city='تهران', multiplier=Decimal('1.0'), base_cost=0)

    def _make_request(self, discount_percent=10):
        """درخواست با calculated_price=BASE و final_price پس از تخفیف."""
        final_price = BASE if discount_percent == 0 else BASE - DISCOUNT
        return InspectionRequest.objects.create(
            customer=self.customer,
            equipment_type=self.eq,
            city='تهران',
            address='تست',
            brand_model='م',
            calculated_price=BASE,
            final_price=final_price,
            status='pending_payment',
        )


class TestReferenceNumbers(_Base):
    """بند ۴۶: اعداد مرجع کاملاً ثابت."""

    def test_snapshot_reference(self):
        snap = InvoiceSettlementService.build_snapshot(self._make_request())
        assert snap['base_amount'] == BASE
        assert snap['total_amount'] == NET
        assert snap['discount_amount'] == DISCOUNT
        assert snap['tax_amount'] == TAX
        assert snap['final_amount'] == FINAL
        assert snap['final_rial'] == FINAL_RIAL

    def test_invoice_reference(self):
        req = self._make_request()
        invoice, _ = InvoiceSettlementService.settle(req, is_paid=False)
        assert int(invoice.final_amount) == 98100000
        assert int(invoice.final_rial) == 981000000

    def test_full_online_payment_reference(self):
        """بدون اعتبار: gateway = کل مبلغ شامل مالیات."""
        req = self._make_request()
        snap = InvoiceSettlementService.payment_snapshot(req, credit_amount=0)
        assert snap['amount'] == FINAL
        assert snap['amount_rial'] == FINAL_RIAL
        assert snap['online_amount'] == FINAL
        assert snap['online_rial'] == FINAL_RIAL  # 981,000,000 IRR


class TestCombinedPaymentReference(_Base):
    """بند ۴۷: پرداخت ترکیبی Credit + Online."""

    def test_split_amounts(self):
        req = self._make_request()
        snap = InvoiceSettlementService.payment_snapshot(
            req, credit_amount=20000000)
        assert snap['amount'] == FINAL                     # 98,100,000
        assert snap['credit_amount'] == Decimal('20000000')
        assert snap['online_amount'] == Decimal('78100000')
        assert snap['online_rial'] == Decimal('781000000')  # 781,000,000 IRR
        assert snap['amount_rial'] == FINAL_RIAL
        # invariant: credit + online = total
        assert snap['credit_amount'] + snap['online_amount'] == snap['amount']

    def test_credit_capped_at_final(self):
        req = self._make_request()
        snap = InvoiceSettlementService.payment_snapshot(
            req, credit_amount=Decimal('200000000'))  # بیشتر از کل
        assert snap['credit_amount'] == FINAL
        assert snap['online_amount'] == 0

    def test_payment_invariant_enforced(self):
        """Payment با مبلغ ناسازگار نباید ساخته شود (بند ۸)."""
        from django.core.exceptions import ValidationError
        req = self._make_request()
        method, _ = __import__(
            'core.models', fromlist=['PaymentMethod']).PaymentMethod \
            .objects.get_or_create(name='credit', defaults={'is_active': True})
        with pytest.raises(ValidationError):
            Payment.objects.create(
                inspection_request=req,
                amount=FINAL,
                amount_rial=FINAL_RIAL,
                credit_amount=20000000,   # فقط ۲۰M
                online_amount=50000000,   # مجموع ۷۰M ≠ ۹۸.۱M
                method=method,
                status='paid',
            )
        # حالت سازگار ساخته می‌شود
        payment = Payment.objects.create(
            inspection_request=req,
            amount=FINAL,
            amount_rial=FINAL_RIAL,
            credit_amount=Decimal('20000000'),
            online_amount=Decimal('78100000'),
            method=method,
            status='paid',
        )
        assert payment.amount_rial == FINAL_RIAL

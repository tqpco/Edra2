# core/tests/test_security_idor.py
"""
تست‌های object-level authorization (SEC-01 از گزارش ممیزی)

سناریوهای الزامی:
- Customer A → Payment/Invoice/Credit/Report B = 404/403
- Expert A → Customer B = 404
- کاربر عادی → Admin mutation = 403
- فیلدهای مالی Payment از سمت کلاینت قابل نوشتن نیستند
"""
import os

import pytest
from django.contrib.auth import get_user_model
from django.contrib.auth.models import Group
from rest_framework.test import APIClient

from core.models import (
    CreditReservation, CreditTransaction, EquipmentType, InspectionReport,
    InspectionRequest, Invoice, Payment, PaymentMethod, UserCredit,
)
from core.services.invoice_service import InvoiceSettlementService
from core.services.money import toman_to_rial

User = get_user_model()

pytestmark = pytest.mark.django_db

PASSWORD = os.getenv("PASSWORD", "CHANGE_ME")


class _BaseSetup:
    def setup_method(self):
        self.client = APIClient()
        self.customer_a = User.objects.create_user(
            username="09120000001", password=PASSWORD)
        self.customer_b = User.objects.create_user(
            username="09120000002", password=PASSWORD)
        self.eq = EquipmentType.objects.create(
            name_fa="تست", code="TEST", param_schema={})
        self.method_online, _ = PaymentMethod.objects.get_or_create(
            name='online', defaults={'is_active': True})

        # درخواست مشتری A (دارای فاکتور و پرداخت)
        self.request_a = InspectionRequest.objects.create(
            customer=self.customer_a,
            equipment_type=self.eq,
            city="تهران",
            address="آدرس A",
            brand_model="مدل A",
            calculated_price=1000000,
            final_price=1000000,
            status='pending_payment',
        )
        # درخواست مشتری B
        self.request_b = InspectionRequest.objects.create(
            customer=self.customer_b,
            equipment_type=self.eq,
            city="شیراز",
            address="آدرس B",
            brand_model="مدل B",
            calculated_price=2000000,
            final_price=2000000,
            status='pending_payment',
        )

        # پرداخت و فاکتور برای درخواست A (تسویه کامل اعتبار برای سادگی)
        self.payment_a = Payment.objects.create(
            inspection_request=self.request_a,
            amount=1000000,
            amount_rial=toman_to_rial(1000000),
            online_amount=1000000,
            method=self.method_online,
            status='paid',
            verified_at=None,
        )
        self.invoice_a, _ = InvoiceSettlementService.settle(
            self.request_a, payment=self.payment_a, is_paid=True)


class TestPaymentIDOR(_BaseSetup):
    def test_customer_b_cannot_view_payment_a(self):
        self.client.force_authenticate(user=self.customer_b)
        resp = self.client.get(f"/api/core/payments/{self.payment_a.id}/")
        assert resp.status_code == 404  # object-level scoping

    def test_customer_a_can_view_own_payment(self):
        self.client.force_authenticate(user=self.customer_a)
        resp = self.client.get(f"/api/core/payments/{self.payment_a.id}/")
        assert resp.status_code == 200

    def test_cannot_create_payment_directly(self):
        """PaymentViewSet فقط خواندنی است (SEC-01)."""
        self.client.force_authenticate(user=self.customer_a)
        resp = self.client.post("/api/core/payments/", {
            'inspection_request': self.request_b.id,
            'amount': 999,
            'method': self.method_online.id,
        })
        assert resp.status_code in (403, 405)


class TestInvoiceIDOR(_BaseSetup):
    def test_customer_b_cannot_view_invoice_a(self):
        self.client.force_authenticate(user=self.customer_b)
        resp = self.client.get(f"/api/core/invoices/{self.invoice_a.id}/")
        assert resp.status_code == 404

    def test_customer_a_can_view_own_invoice(self):
        self.client.force_authenticate(user=self.customer_a)
        resp = self.client.get(f"/api/core/invoices/{self.invoice_a.id}/")
        assert resp.status_code == 200
        assert resp.data['invoice_number'] == self.invoice_a.invoice_number

    def test_invoice_has_rial_snapshot(self):
        self.client.force_authenticate(user=self.customer_a)
        resp = self.client.get(f"/api/core/invoices/{self.invoice_a.id}/")
        assert resp.status_code == 200
        # ۱٬۰۰۰٬۰۰۰ تومان = ۱۰٬۰۰۰٬۰۰۰ ریال + ۹٪ مالیات → ۱۰٬۹۰۰٬۰۰۰ ریال
        assert int(resp.data['final_rial']) == 10900000
        assert int(resp.data['final_amount']) == 1090000


class TestCreditIDOR(_BaseSetup):
    def test_credit_transactions_scoped_to_user(self):
        UserCredit.objects.create(user=self.customer_a, balance=5000000)
        CreditTransaction.objects.create(
            user=self.customer_a,
            amount=100000,
            transaction_type='deposit',
            description='تست',
            balance_after=5100000,
        )
        self.client.force_authenticate(user=self.customer_b)
        resp = self.client.get("/api/core/credit-transactions/")
        assert resp.status_code == 200
        assert len(resp.data) == 0  # مشتری B هیچ تراکنشی نمی‌بیند

    def test_credit_balance_scoped_to_user(self):
        UserCredit.objects.create(user=self.customer_a, balance=5000000)
        self.client.force_authenticate(user=self.customer_b)
        resp = self.client.get("/api/core/credit/")
        assert resp.status_code == 200
        # مشتری B هیچ رکورد اعتباری نمی‌بیند (لیست خالی)
        assert resp.data == []


class TestReportIDOR(_BaseSetup):
    def test_expert_a_cannot_view_customer_b_request(self):
        expert_a = User.objects.create_user(
            username="expert_a", password=PASSWORD)
        expert_group, _ = Group.objects.get_or_create(name="Expert")
        expert_a.groups.add(expert_group)

        # درخواست B به مشتری B تعلق دارد و به expert_a ارجاع نشده
        # کارشناس A فقط درخواست‌های assigned به خودش را می‌بیند → 404
        self.client.force_authenticate(user=expert_a)
        resp = self.client.get(
            f"/api/core/inspection-requests/{self.request_b.id}/")
        assert resp.status_code == 404

    def test_customer_b_cannot_see_request_a(self):
        self.client.force_authenticate(user=self.customer_b)
        resp = self.client.get(
            f"/api/core/inspection-requests/{self.request_a.id}/")
        assert resp.status_code == 404


class TestPaymentSerializerReadOnly(_BaseSetup):
    def test_financial_fields_read_only(self):
        """کلاینت نمی‌تواند status/authority/amount را بنویسد."""
        from core.serializers import PaymentSerializer
        data = {
            'inspection_request': self.request_b.id,
            'method': self.method_online.id,
            'status': 'paid',
            'authority': 'HACKED',
            'ref_id': 'HACKED',
            'amount': 1,
        }
        serialized = PaymentSerializer(data=data)
        # فیلدهای مالی read-only هستند → در validated_data وجود ندارند
        assert serialized.is_valid() is True
        assert 'status' not in serialized.validated_data
        assert 'authority' not in serialized.validated_data
        assert 'ref_id' not in serialized.validated_data
        assert 'amount' not in serialized.validated_data


class TestCreditReservationFlow:
    """تست رزرو/مصرف/آزادسازی اعتبار (FIN-04)."""

    def setup_method(self):
        from core.services.credit_service import CreditService
        self.credit_service = CreditService
        self.customer = User.objects.create_user(
            username="09120000003", password=PASSWORD)
        self.eq = EquipmentType.objects.create(
            name_fa="تست", code="TEST2", param_schema={})
        self.request = InspectionRequest.objects.create(
            customer=self.customer,
            equipment_type=self.eq,
            city="تهران",
            address="آدرس",
            brand_model="مدل",
            calculated_price=3000000,
            final_price=3000000,
            status='pending_payment',
        )
        UserCredit.objects.create(user=self.customer, balance=5000000)

    def test_reserve_then_release(self):
        reservation = self.credit_service.reserve(
            self.customer, 1000000, inspection_request=self.request)
        assert reservation.status == 'reserved'
        # موجودی کم نشده ولی رزرو شده
        credit = UserCredit.objects.get(user=self.customer)
        assert credit.balance == 5000000

        self.credit_service.release(reservation, reason='gateway failed')
        reservation.refresh_from_db()
        assert reservation.status == 'released'
        assert CreditReservation.objects.filter(status='reserved').count() == 0

    def test_reserve_then_consume(self):
        reservation = self.credit_service.reserve(
            self.customer, 2000000, inspection_request=self.request)
        self.credit_service.consume(reservation, description='پرداخت')
        credit = UserCredit.objects.get(user=self.customer)
        assert credit.balance == 3000000
        reservation.refresh_from_db()
        assert reservation.status == 'consumed'
        tx = CreditTransaction.objects.get(user=self.customer)
        assert tx.transaction_type == 'purchase'
        assert tx.amount == 2000000

    def test_insufficient_credit(self):
        from core.services.credit_service import InsufficientCreditError
        with pytest.raises(InsufficientCreditError):
            self.credit_service.reserve(
                self.customer, 6000000, inspection_request=self.request)

    def test_double_reservation_respects_available(self):
        r1 = self.credit_service.reserve(
            self.customer, 3000000, inspection_request=self.request)
        from core.services.credit_service import InsufficientCreditError
        with pytest.raises(InsufficientCreditError):
            self.credit_service.reserve(
                self.customer, 3000000, inspection_request=self.request)
        # آزادسازی اول → دومی ممکن می‌شود
        self.credit_service.release(r1)
        r2 = self.credit_service.reserve(
            self.customer, 3000000, inspection_request=self.request)
        assert r2.status == 'reserved'


class TestPaymentCallbackIdempotency(_BaseSetup):
    """تست idempotency کال‌بک درگاه (FIN-05)."""

    def test_duplicate_callback_creates_single_invoice(self, monkeypatch):
        from core.views.payment_views import ZarinpalService

        payment = Payment.objects.create(
            inspection_request=self.request_a,
            amount=1000000,
            amount_rial=toman_to_rial(1000000),
            online_amount=1000000,
            method=self.method_online,
            status='pending',
            authority='AUTH-TEST-123',
        )

        def fake_verify(authority, amount):
            return {'success': True, 'ref_id': 'REF-999'}

        monkeypatch.setattr(ZarinpalService, 'verify_payment', fake_verify)

        url = "/api/core/payment/callback/?Authority=AUTH-TEST-123&Status=OK"
        # کال‌بک اول
        resp1 = self.client.get(url)
        assert resp1.status_code == 302
        assert 'payment/success' in resp1.url

        payment.refresh_from_db()
        assert payment.status == 'paid'
        assert payment.ref_id == 'REF-999'

        # کال‌بک تکراری → بدون ایجاد فاکتور دوم
        resp2 = self.client.get(url)
        assert resp2.status_code == 302
        assert 'payment/success' in resp2.url
        assert Invoice.objects.filter(
            inspection_request=self.request_a).count() == 1

    def test_unknown_authority_returns_404(self):
        resp = self.client.get(
            "/api/core/payment/callback/?Authority=NOT-EXIST&Status=OK")
        assert resp.status_code == 404

    def test_cancel_releases_credit(self):
        from core.services.credit_service import CreditService
        UserCredit.objects.create(user=self.customer_a, balance=5000000)

        reservation = CreditService.reserve(
            self.customer_a, 1000000, inspection_request=self.request_a)
        payment = Payment.objects.create(
            inspection_request=self.request_a,
            amount=2000000,
            amount_rial=toman_to_rial(2000000),
            credit_amount=1000000,
            online_amount=1000000,
            method=self.method_online,
            status='pending',
            authority='AUTH-CANCEL-1',
        )
        reservation.payment = payment
        reservation.save(update_fields=['payment'])

        resp = self.client.get(
            "/api/core/payment/callback/?Authority=AUTH-CANCEL-1&Status=NOK")
        assert resp.status_code == 302
        assert 'payment/canceled' in resp.url

        reservation.refresh_from_db()
        assert reservation.status == 'released'
        # موجودی دست‌نخورده است
        credit = UserCredit.objects.get(user=self.customer_a)
        assert credit.balance == 5000000


class TestInvoiceService:
    """تست سرویس مرکزی فاکتور (FIN-01/FIN-02/FIN-03)."""

    def setup_method(self):
        self.customer = User.objects.create_user(
            username="09120000004", password=PASSWORD)
        self.eq = EquipmentType.objects.create(
            name_fa="تست", code="TEST3", param_schema={})
        self.request = InspectionRequest.objects.create(
            customer=self.customer,
            equipment_type=self.eq,
            city="تهران",
            address="آدرس",
            brand_model="مدل",
            calculated_price=1500000,
            final_price=1000000,  # ۵۰۰ هزار تخفیف
            status='pending_payment',
        )

    def test_idempotent_settle(self):
        from core.services.invoice_service import (
            DuplicateInvoiceError, InvoiceSettlementService)
        inv1, created1 = InvoiceSettlementService.settle(self.request)
        inv2, created2 = InvoiceSettlementService.settle(self.request)
        assert created1 is True
        assert created2 is False
        assert inv1.id == inv2.id
        assert Invoice.objects.count() == 1

        with pytest.raises(DuplicateInvoiceError):
            InvoiceSettlementService.settle(
                self.request, raise_on_duplicate=True)

    def test_sequence_number_format(self):
        from core.services.invoice_service import InvoiceSettlementService
        invoice, _ = InvoiceSettlementService.settle(self.request)
        assert invoice.invoice_number.startswith("INV-")
        assert invoice.invoice_number.count("-") == 2

    def test_snapshot_values(self):
        from core.services.invoice_service import InvoiceSettlementService
        invoice, _ = InvoiceSettlementService.settle(self.request)
        assert int(invoice.base_amount) == 1500000
        assert int(invoice.discount_amount) == 500000
        assert int(invoice.total_amount) == 1000000
        assert int(invoice.tax_amount) == 90000          # ۹٪ از ۱٬۰۰۰٬۰۰۰
        assert int(invoice.final_amount) == 1090000
        assert int(invoice.final_rial) == 10900000

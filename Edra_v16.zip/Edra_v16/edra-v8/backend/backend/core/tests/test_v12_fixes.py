# core/tests/test_v12_fixes.py
"""
EDRA v12 — تست‌های اصلاحات P1-04 (TaxRate invariants) و P1-01 (PDF auth).
"""
import pytest
from django.core.exceptions import ValidationError

from core.models import TaxRate
from core.services.invoice_service import resolve_tax_rate_percent

pytestmark = pytest.mark.django_db


class TestTaxRateInvariants:
    def test_negative_rate_rejected(self):
        rate = TaxRate(
            rate_percent=-1,
            effective_from='1405-01-01')
        with pytest.raises(ValidationError):
            rate.clean()

    def test_effective_to_before_from_rejected(self):
        rate = TaxRate(
            rate_percent=9,
            effective_from='1405-02-01',
            effective_to='1405-01-01')
        with pytest.raises(ValidationError):
            rate.clean()

    def test_overlap_rejected(self):
        TaxRate.objects.create(
            rate_percent=9, effective_from='1405-01-01',
            is_active=True)
        overlap = TaxRate(
            rate_percent=10, effective_from='1405-06-01',
            is_active=True)  # داخل بازه نرخ ۹٪
        with pytest.raises(ValidationError):
            overlap.clean()

    def test_open_ended_overlap_rejected(self):
        TaxRate.objects.create(
            rate_percent=9, effective_from='1405-01-01',
            effective_to=None, is_active=True)
        later = TaxRate(
            rate_percent=10, effective_from='1405-12-01',
            is_active=True)
        with pytest.raises(ValidationError):
            later.clean()

    def test_sequential_rates_allowed(self):
        r1 = TaxRate.objects.create(
            rate_percent=9, effective_from='1404-01-01',
            effective_to='1404-12-29', is_active=True)
        r2 = TaxRate(
            rate_percent=10, effective_from='1405-01-01',
            is_active=True)
        r2.clean()  # نباید خطا بدهد (بازه بعدی)
        assert r2.rate_percent == 10

    def test_resolve_returns_latest_active(self):
        """هر دو نرخ در گذشته فعال‌اند؛ جدیدترین (۱۰٪) باید برگردد."""
        TaxRate.objects.all().delete()
        TaxRate.objects.create(
            rate_percent=9, effective_from='1404-01-01',
            effective_to='1404-12-29', is_active=True)
        TaxRate.objects.create(
            rate_percent=10, effective_from='1405-01-01',
            is_active=True)
        assert float(resolve_tax_rate_percent()) == 10.0

    def test_snapshot_keeps_old_rate(self):
        """نرخی که snapshot شده بعد از تغییر نرخ فعلی تغییر نمی‌کند."""
        from core.services.invoice_service import resolve_tax_rate_percent
        TaxRate.objects.all().delete()
        TaxRate.objects.create(
            rate_percent=9, effective_from='1404-01-01',
            effective_to='1404-12-29', is_active=True)
        old_rate = resolve_tax_rate_percent()
        TaxRate.objects.create(
            rate_percent=10, effective_from='1405-01-01', is_active=True)
        assert float(old_rate) == 9.0


class TestPdfAuthNoQueryToken:
    """P1-01: توکن در query-string دیگر پذیرفته نمی‌شود (فقط Bearer)."""

    def test_query_token_rejected(self, rf):
        from django.contrib.auth import get_user_model
        from core.views.pdf_views import generate_report_pdf
        User = get_user_model()
        u = User.objects.create_user(
            username='pdf_tester', password='x' * 8)
        request = rf.get('/pdf/report/1/?token=invalid.jwt.token')
        request.user = u
        res = generate_report_pdf(request, 999999)
        # بدون Authorization هدر → 401 (نه fallback به query)
        assert res.status_code == 401

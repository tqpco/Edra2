# core/tests/test_v13_fixes.py
"""
EDRA v13 — تست‌های اصلاحات:
- P1-08: امنیت آپلود (magic bytes، پسوند جعلی، حجم، filename مخرب)
- P1-07: قرارداد مسیرها (resolve همه endpoint های حیاتی)
- P2-04: شمارش کوئری‌ها (بدون N+1 در مسیرهای سنگین)
"""
import pytest
from django.core.files.uploadedfile import SimpleUploadedFile

from core.validators import (
    validate_uploaded_file,
    sniff_content_type,
    ALLOWED_RECEIPT_EXTENSIONS,
    MAX_RECEIPT_SIZE,
)

pytestmark = pytest.mark.django_db


class TestUploadSecurity:
    def test_png_magic_accepted(self):
        import base64 as _b64
        _png = _b64.b64decode(
            'iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNkYPhfDwAChwGA60e6kgAAAABJRU5ErkJggg==')
        f = SimpleUploadedFile('receipt.png', _png)
        err = validate_uploaded_file(
            f, allowed_extensions=ALLOWED_RECEIPT_EXTENSIONS)
        assert err is None

    def test_fake_extension_rejected(self):
        """یک فایل اجرایی با پسوند png باید رد شود (magic bytes)."""
        f = SimpleUploadedFile(
            'evil.png',
            b'MZ\x90\x00' + b'\x00' * 64)  # PE executable
        err = validate_uploaded_file(
            f, allowed_extensions=ALLOWED_RECEIPT_EXTENSIONS)
        assert err is not None
        assert 'مطابقت' in (err or '')

    def test_oversize_rejected(self):
        f = SimpleUploadedFile(
            'big.jpg',
            b'\xff\xd8\xff' + b'\x00' * (MAX_RECEIPT_SIZE + 1))
        err = validate_uploaded_file(
            f, allowed_extensions=ALLOWED_RECEIPT_EXTENSIONS)
        assert err is not None

    def test_unsafe_filename_rejected(self):
        f = SimpleUploadedFile(
            '../../etc/passwd.jpg',
            b'\xff\xd8\xff' + b'\x00' * 64)
        err = validate_uploaded_file(
            f, allowed_extensions=ALLOWED_RECEIPT_EXTENSIONS)
        assert err is not None

    def test_sniff_unknown_rejected(self):
        assert sniff_content_type(b'plain text not an image') is None


class TestRouteContract:
    """P1-07: مسیرهای حیاتی باید resolve شوند (بدون شکستن URL)."""

    def test_core_routes_resolve(self):
        from django.urls import reverse
        for name in ['token_obtain_pair', 'token_refresh',
                     'token_blacklist', 'health_live', 'health_ready']:
            try:
                reverse(name)
            except Exception as exc:
                pytest.fail(f'route {name} resolve failed: {exc}')

    def test_critical_paths_resolve(self):
        from django.urls import resolve
        for path in [
            '/api/core/payment/callback/',
            '/api/core/otp/request/',
            '/api/core/otp/verify/',
            '/api/core/credit/deposit/',
            '/api/core/admin/dashboard-stats/',
            '/api/core/inspection-requests/',
            '/health/live/',
            '/health/ready/',
            '/api/notifications/',
            '/api/support/tickets/',
        ]:
            try:
                resolve(path)
            except Exception as exc:
                pytest.fail(f'path {path} resolve failed: {exc}')

    def test_inspection_routes_resolve(self):
        from django.urls import resolve
        for path in [
            '/api/inspections/checklist-templates/',
            '/api/inspections/checklist-templates/1/items/',
        ]:
            try:
                resolve(path)
            except Exception as exc:
                pytest.fail(f'path {path} resolve failed: {exc}')


class TestListSmoke:
    """P2-04 (ساده): لیست درخواست‌ها با داده واقعی پاسخ می‌دهد."""

    def test_request_list_smoke(self):
        from django.contrib.auth import get_user_model
        from rest_framework.test import APIClient
        from core.models import InspectionRequest, EquipmentType
        User = get_user_model()
        admin = User.objects.create_superuser(
            username='q_admin2', password='x' * 8)
        eq = EquipmentType.objects.create(
            code='test', name_fa='تست')
        for i in range(5):
            InspectionRequest.objects.create(
                customer=admin,
                equipment_type=eq,
                city='تهران',
                status='pending_payment',
                calculated_price=1000000,
                final_price=1000000)
        client = APIClient()
        client.force_authenticate(user=admin)
        resp = client.get('/api/core/inspection-requests/')
        assert resp.status_code == 200
        data = resp.json()
        if isinstance(data, dict):
            data = data.get('results', [])
        assert isinstance(data, list) and len(data) >= 5

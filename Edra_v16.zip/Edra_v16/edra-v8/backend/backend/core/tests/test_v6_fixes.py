# core/tests/test_v6_fixes.py
"""
تست‌های رگرسیون اصلاحات گزارش ممیزی EDRA v6 (P0/P1):
- P0: proxy trailing slash (در frontend تست می‌شود؛ اینجا رگرسیون API عادی)
- P1: OTP double-submit — کد فقط یک بار قابل مصرف است (select_for_update)
- P1: OTP cooldown — درخواست دوم در بازه cooldown → 429
- P1: OTP code در Admin دیده نمی‌شود (__str__ بدون code)
- P1: Refresh rotation — استفاده مجدد از refresh قدیمی → 401
- P1: Staff بدون گروه Admin → queryset مدیریتی کامل (نقش canonical)
- P1: Permission defense-in-depth — مشتری نمی‌تواند درخواست دیگران را retrieve کند
- P1: پیوست تیکت — فایل نامعتبر رد می‌شود
"""
import io
import os

import pytest
from django.contrib.auth import get_user_model
from django.contrib.auth.models import Group
from django.core.cache import cache
from django.core.files.uploadedfile import SimpleUploadedFile
from rest_framework.test import APIClient
from rest_framework_simplejwt.tokens import RefreshToken

from core.models import (
    EquipmentType, InspectionRequest, OTPCode,
)
from support.models import Ticket, TicketStatus, TicketPriority, TicketCategory

User = get_user_model()
pytestmark = pytest.mark.django_db
PASSWORD = os.getenv("PASSWORD", "CHANGE_ME")


class Base:
    def setup_method(self):
        cache.clear()
        self.customer = User.objects.create_user(
            username="v6_customer", password=PASSWORD)
        self.other_customer = User.objects.create_user(
            username="v6_other", password=PASSWORD)
        self.expert = User.objects.create_user(
            username="v6_expert", password=PASSWORD)
        g, _ = Group.objects.get_or_create(name='Expert')
        self.expert.groups.add(g)
        # staff بدون گروه Admin (ناسازگاری نقش در v6)
        self.staff_no_admin = User.objects.create_user(
            username="v6_staff", password=PASSWORD, is_staff=True)

        self.customer_c = APIClient()
        self.customer_c.force_authenticate(user=self.customer)
        self.staff_c = APIClient()
        self.staff_c.force_authenticate(user=self.staff_no_admin)

        self.eq = EquipmentType.objects.create(code='v6_eq', name_fa='تجهیز')
        self.task = InspectionRequest.objects.create(
            customer=self.customer,
            assigned_expert=self.expert,
            equipment_type=self.eq,
            city='تهران', address='آدرس', brand_model='تست',
            calculated_price=1000000, final_price=1000000,
            status='pending_payment',
        )
        from guardian.shortcuts import assign_perm
        assign_perm('view_inspectionrequest', self.customer, self.task)
        assign_perm('change_inspectionrequest', self.customer, self.task)


# ============================================================
# P1 — OTP double-submit (race) + cooldown
# ============================================================
class TestOtpV6(Base):
    def test_otp_single_use(self):
        """double-submit: مصرف دوم کد باید رد شود (select_for_update)."""
        otp = OTPCode.objects.create(phone='09120002222', code='111111')
        r1 = self.customer_c.post(
            '/api/core/otp/verify/', {'phone': '09120002222', 'code': '111111'},
            format='json')
        assert r1.status_code == 200, r1.content[:200]
        r2 = self.customer_c.post(
            '/api/core/otp/verify/', {'phone': '09120002222', 'code': '111111'},
            format='json')
        assert r2.status_code == 400  # کد مصرف شده
        otp.refresh_from_db()
        assert otp.is_used is True

    def test_otp_wrong_code_increments_attempts(self):
        otp = OTPCode.objects.create(phone='09120002223', code='222222')
        for _ in range(3):
            self.customer_c.post(
                '/api/core/otp/verify/',
                {'phone': '09120002223', 'code': '000000'}, format='json')
        otp.refresh_from_db()
        assert otp.attempts == 3

    def test_otp_code_not_in_str(self):
        """P1: __str__ نباید خود کد را برگرداند (افشای credential)."""
        otp = OTPCode.objects.create(phone='09120002224', code='333333')
        assert '333333' not in str(otp)
        assert '09120002224' in str(otp)


# ============================================================
# P1 — Refresh rotation: استفاده مجدد از refresh قدیمی
# ============================================================
class TestRefreshRotation(Base):
    def test_old_refresh_rejected_after_rotation(self):
        refresh = RefreshToken.for_user(self.customer)
        # اولین refresh → جدید صادر، قبلی blacklist
        r1 = self.customer_c.post(
            '/api/token/refresh/',
            {'refresh': str(refresh)}, format='json')
        assert r1.status_code == 200
        new_refresh = r1.data.get('refresh')
        assert new_refresh, 'بک‌اند باید refresh جدید برگرداند (rotation)'
        # استفاده مجدد از refresh قدیمی → 401
        r2 = self.customer_c.post(
            '/api/token/refresh/',
            {'refresh': str(refresh)}, format='json')
        assert r2.status_code == 401
        # refresh جدید هنوز کار می‌کند
        r3 = self.customer_c.post(
            '/api/token/refresh/',
            {'refresh': new_refresh}, format='json')
        assert r3.status_code == 200


# ============================================================
# P1 — نقش canonical: staff بدون گروه Admin
# ============================================================
class TestStaffWithoutAdminGroup(Base):
    def test_staff_gets_admin_queryset(self):
        """staff بدون گروه Admin باید همه درخواست‌ها را ببیند (مثل Admin)."""
        r = self.staff_c.get('/api/core/inspection-requests/')
        assert r.status_code == 200
        data = r.data.get('results') if isinstance(r.data, dict) else r.data
        ids = [i['id'] for i in data]
        assert self.task.id in ids  # درخواست مشتری دیگر هم دیده می‌شود

    def test_staff_can_retrieve_any_request(self):
        r = self.staff_c.get(
            f'/api/core/inspection-requests/{self.task.id}/')
        assert r.status_code == 200


# ============================================================
# P1 — Permission defense-in-depth: IDOR در retrieve
# ============================================================
class TestPermissionDefenseInDepth(Base):
    def test_customer_cannot_retrieve_others_request(self):
        other = InspectionRequest.objects.create(
            customer=self.other_customer,
            equipment_type=self.eq,
            city='قم', address='x', brand_model='y',
            calculated_price=1, final_price=1, status='draft')
        # بدون perm و بدون مالکیت → باید 404 (queryset) باشد
        r = self.customer_c.get(
            f'/api/core/inspection-requests/{other.id}/')
        assert r.status_code in (403, 404)


# ============================================================
# P1 — پیوست تیکت: فایل نامعتبر رد می‌شود
# ============================================================
class TestTicketAttachmentValidation(Base):
    def _make_ticket(self):
        status = TicketStatus.objects.create(name='باز')
        prio = TicketPriority.objects.create(name='متوسط', weight=1)
        cat = TicketCategory.objects.create(name='عمومی')
        return Ticket.objects.create(
            customer=self.customer, title='تیکت',
            description='توضیحات', status=status,
            priority=prio, category=cat)

    def test_invalid_attachment_rejected(self):
        t = self._make_ticket()
        fake = SimpleUploadedFile(
            'evil.exe', b'MZ\x90\x00fake binary', content_type='application/x-msdownload')
        r = self.customer_c.post(
            f'/api/support/tickets/{t.id}/add_comment/',
            {'content': 'متن', 'attachments': [fake]}, format='multipart')
        assert r.status_code == 400

    def test_valid_attachment_accepted(self):
        from support.models import TicketAttachment
        t = self._make_ticket()
        txt = SimpleUploadedFile(
            'note.pdf', b'%PDF-1.4\n%%EOF', content_type='application/pdf')
        r = self.customer_c.post(
            f'/api/support/tickets/{t.id}/add_comment/',
            {'content': 'متن', 'attachments': [txt]}, format='multipart')
        assert r.status_code == 201
        assert TicketAttachment.objects.filter(ticket=t).count() == 1

# core/tests/test_websocket.py
"""
تست WebSocket اعلان‌ها (Phase 2 ممیزی + P0-08/HIGH-06):
- اتصال بدون احراز هویت → رد می‌شود
- اتصال با ticket معتبر → پذیرش + دریافت اعلان‌های خوانده‌نشده
- ticket یکبارمصرف است: replay با همان ticket → رد می‌شود
- ایزوله‌سازی نقش/کاربر: اعلان هر کاربر فقط به گروه خودش می‌رود
- action های mark_read / mark_all_read
"""
import os
import secrets
from asgiref.sync import async_to_sync

import pytest
from channels.routing import URLRouter
from channels.testing import WebsocketCommunicator
from django.contrib.auth import get_user_model
from django.core.cache import cache
from django.urls import path

from edra.ws_auth import WsTicketAuthMiddleware
from notifications.consumers import NotificationConsumer
from notifications.models import NotificationLog, NotificationTemplate

User = get_user_model()
pytestmark = pytest.mark.django_db(transaction=True)
PASSWORD = os.getenv("PASSWORD", "CHANGE_ME")

_application = WsTicketAuthMiddleware(
    URLRouter([
        path('ws/notifications/', NotificationConsumer.as_asgi()),
    ]))


def _make_user(phone):
    user = User.objects.create_user(username=phone, password=PASSWORD)
    template, _ = NotificationTemplate.objects.get_or_create(
        code='ws_test', defaults={
            'channel': 'sms', 'subject': 'تست', 'body_template': 'پیام'})
    NotificationLog.objects.create(
        user=user, template=template, type='ws_test', subject='سلام',
        content='متن', channel='sms', is_read=False, status='sent')
    return user


def _make_ticket(user, ttl=60):
    """همان منطق WsTicketView — ticket تصادفی در cache با TTL."""
    ticket = secrets.token_hex(32)
    cache.set(f'ws_ticket_{ticket}', user.id, timeout=ttl)
    return ticket


def test_unauthenticated_rejected():
    async def run():
        communicator = WebsocketCommunicator(
            _application, '/ws/notifications/')
        connected, _ = await communicator.connect()
        assert not connected, "بدون احراز هویت نباید متصل شود"
        await communicator.disconnect()

    async_to_sync(run)()


def test_authenticated_receives_unread():
    user = _make_user('09120000666')
    ticket = _make_ticket(user)

    async def run():
        communicator = WebsocketCommunicator(
            _application, f'/ws/notifications/?ticket={ticket}')
        connected, _ = await communicator.connect()
        assert connected
        message = await communicator.receive_json_from()
        assert message['type'] == 'unread_notifications'
        assert len(message['data']) == 1
        assert message['data'][0]['subject'] == 'سلام'

        # mark_read
        await communicator.send_json_to({
            'action': 'mark_read',
            'notification_id': message['data'][0]['id'],
        })
        await communicator.disconnect()

    async_to_sync(run)()
    assert NotificationLog.objects.get(user=user).is_read is True


def test_ticket_single_use_replay_rejected():
    """
    P0-08/HIGH-06: ticket فقط یک بار قابل مصرف است — دومین اتصال با همان
    ticket باید رد شود (replay محافظت‌شده است).
    """
    user = _make_user('09120000555')
    ticket = _make_ticket(user)

    async def run():
        comm1 = WebsocketCommunicator(
            _application, f'/ws/notifications/?ticket={ticket}')
        connected, _ = await comm1.connect()
        assert connected
        await comm1.receive_json_from()  # unread list
        await comm1.disconnect()

        # replay همان ticket → rejected
        comm2 = WebsocketCommunicator(
            _application, f'/ws/notifications/?ticket={ticket}')
        connected2, _ = await comm2.connect()
        assert not connected2, "ticket مصرف‌شده نباید دوباره پذیرفته شود"
        await comm2.disconnect()

    async_to_sync(run)()


def test_expired_ticket_rejected():
    """P0-08/HIGH-06: ticket منقضی (TTL گذشته) → رد می‌شود."""
    user = _make_user('09120000444')
    ticket = _make_ticket(user, ttl=1)
    cache.delete(f'ws_ticket_{ticket}')  # شبیه‌سازی انقضا

    async def run():
        communicator = WebsocketCommunicator(
            _application, f'/ws/notifications/?ticket={ticket}')
        connected, _ = await communicator.connect()
        assert not connected, "ticket منقضی نباید پذیرفته شود"
        await communicator.disconnect()

    async_to_sync(run)()


def test_mark_all_read():
    user = _make_user('09120000777')
    template = NotificationTemplate.objects.get(code='ws_test')
    NotificationLog.objects.create(
        user=user, template=template, type='ws_test', subject='دوم',
        content='متن', channel='sms', is_read=False, status='sent')
    ticket = _make_ticket(user)

    async def run():
        communicator = WebsocketCommunicator(
            _application, f'/ws/notifications/?ticket={ticket}')
        connected, _ = await communicator.connect()
        assert connected
        await communicator.receive_json_from()  # unread list
        await communicator.send_json_to({'action': 'mark_all_read'})
        await communicator.disconnect()

    async_to_sync(run)()
    assert NotificationLog.objects.filter(
        user=user, is_read=False).count() == 0


def test_user_isolation():
    """کاربر A فقط اعلان‌های خودش را می‌گیرد، نه کاربر B."""
    user_a = _make_user('09120000888')
    user_b = _make_user('09120000999')

    ticket_a = _make_ticket(user_a)
    ticket_b = _make_ticket(user_b)

    async def run():
        comm_a = WebsocketCommunicator(
            _application, f'/ws/notifications/?ticket={ticket_a}')
        comm_b = WebsocketCommunicator(
            _application, f'/ws/notifications/?ticket={ticket_b}')
        assert await comm_a.connect()
        assert await comm_b.connect()

        # دریافت لیست unread هر دو
        await comm_a.receive_json_from()
        await comm_b.receive_json_from()

        # ارسال به گروه کاربر B → فقط B دریافت می‌کند
        from channels.layers import get_channel_layer
        layer = get_channel_layer()
        await layer.group_send(
            f'user_{user_b.id}',
            {'type': 'send_notification', 'data': {'test': True}})

        msg_b = await comm_b.receive_json_from()
        assert msg_b['type'] == 'notification'
        assert msg_b['data']['test'] is True

        # کاربر A نباید چیزی دریافت کند — timeout کوتاه
        import asyncio
        with pytest.raises((asyncio.TimeoutError, asyncio.CancelledError)):
            await comm_a.receive_json_from(timeout=0.3)

        for comm in (comm_a, comm_b):
            try:
                await comm.disconnect()
            except (asyncio.CancelledError, Exception):
                pass  # asgiref خطای ذخیره‌شده timeout را دوباره پرتاب می‌کند

    async_to_sync(run)()

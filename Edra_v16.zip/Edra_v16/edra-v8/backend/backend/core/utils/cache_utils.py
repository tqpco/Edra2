# core/utils/cache_utils.py
from django.core.cache import cache
from ..models import CityMultiplier


def get_city_multiplier(city_name):
    """
    دریافت ضریب شهر با کش کردن نتیجه برای یک ساعت
    """
    cache_key = f'city_multiplier_{city_name}'
    cached = cache.get(cache_key)
    if cached is not None:
        return cached
    try:
        city = CityMultiplier.objects.get(city=city_name)
        multiplier = float(city.multiplier)
        cache.set(cache_key, multiplier, 3600)  # 3600 ثانیه = ۱ ساعت
        return multiplier
    except CityMultiplier.DoesNotExist:
        return 1.0

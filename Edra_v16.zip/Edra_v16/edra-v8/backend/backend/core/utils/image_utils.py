"""
core/utils/image_utils.py

فشرده‌سازی تصاویر آپلودی. عکس‌های خام دوربین موبایل معمولاً ۳ تا ۸ مگابایت
هستند؛ چون کارشناس‌ها می‌توانند برای هر آیتم چک‌لیست چند عکس ثبت کنند (و
ممکن است اتصال اینترنت در محل پروژه ضعیف باشد)، ذخیره‌ی خام باعث پر شدن
سریع فضای سرور و کند شدن آپلود می‌شود.
"""
from io import BytesIO
from PIL import Image, ImageOps
from django.core.files.base import ContentFile

MAX_DIMENSION = 1920  # پیکسل - برای عکس بازرسی کفایت می‌کند، جزئیات فنی خوانا می‌ماند
JPEG_QUALITY = 82


def compress_image_file(django_file, max_dimension=MAX_DIMENSION, quality=JPEG_QUALITY):
    """
    یک UploadedFile/ImageFieldFile را می‌گیرد، بر اساس EXIF orientation آن
    را می‌چرخاند (تا عکس‌های موبایل کج نمایش داده نشوند)، در صورت نیاز
    تغییر اندازه می‌دهد، و به‌صورت JPEG فشرده برمی‌گرداند.

    خروجی: django.core.files.base.ContentFile آماده برای انتساب به یک
    ImageField (مثال در پایین همین فایل).
    """
    django_file.seek(0)
    img = Image.open(django_file)
    # اصلاح چرخش بر اساس متادیتای EXIF (بسیار مهم برای عکس‌های گرفته‌شده با موبایل)
    img = ImageOps.exif_transpose(img)
    if img.mode in ('RGBA', 'P', 'LA'):
        img = img.convert('RGB')
    img.thumbnail((max_dimension, max_dimension), Image.LANCZOS)
    buffer = BytesIO()
    img.save(buffer, format='JPEG', quality=quality, optimize=True)
    buffer.seek(0)
    return ContentFile(buffer.read())


def compress_and_save_image_field(model_instance, field_name, quality=JPEG_QUALITY):
    """
    کمک‌کننده برای فراخوانی داخل save() یک مدل:

        def save(self, *args, **kwargs):
            if self.image and not self._compressed:
                compress_and_save_image_field(self, 'image')
            super().save(*args, **kwargs)

    نکته: چون خودِ save() را دوباره صدا نمی‌زند (فقط فایل را جایگزین
    می‌کند)، فراخوان باید بعد از این تابع خودش super().save() را صدا بزند.
    """
    field_file = getattr(model_instance, field_name)
    if not field_file:
        return
    original_name = field_file.name.rsplit('/', 1)[-1]
    # اگر از قبل jpg با پسوند درست است ولی برای اطمینان همیشه به jpg تبدیل می‌کنیم
    base_name = original_name.rsplit('.', 1)[0]
    compressed = compress_image_file(field_file, quality=quality)
    field_file.save(f"{base_name}.jpg", compressed, save=False)

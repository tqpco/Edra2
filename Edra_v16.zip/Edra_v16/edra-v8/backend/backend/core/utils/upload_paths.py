"""
core/utils/upload_paths.py

مسیرهای آپلود سازمان‌یافته - قبلاً تمام فایل‌ها (عکس چک‌لیست، PDF گزارش،
فیش پرداخت، فاکتور) در پوشه‌های مسطح و مشترک ذخیره می‌شدند
(مثل 'checklist_photos/', 'reports/') که با رشد تعداد کاربران/درخواست‌ها
پیدا کردن فایل‌های یک مشتری یا یک درخواست خاص عملاً غیرممکن می‌شد.

ساختار جدید:
    media/inspections/customer_<id>/request_<id>/photos/<uuid>.jpg
    media/inspections/customer_<id>/request_<id>/reports/<report_number>.pdf
    media/inspections/customer_<id>/request_<id>/reports/signed/<report_number>_signed.pdf
    media/inspections/customer_<id>/request_<id>/receipts/<uuid>.<ext>
    media/invoices/customer_<id>/<invoice_number>.pdf
    media/tickets/customer_<id>/ticket_<id>/<uuid>.<ext>

توجه: توابع upload_to باید قابل pickle باشند (برای migrations) بنابراین
حتماً باید تابع سطح-ماژول باشند، نه lambda یا متد کلاس/closure تودرتو.
"""
import uuid
import os


def _ext(filename):
    return os.path.splitext(filename)[1].lower()


def _unique_name(filename):
    return f"{uuid.uuid4().hex}{_ext(filename)}"


def checklist_photo_upload_path(instance, filename):
    """instance: ChecklistPhoto (report -> inspection_request -> customer)"""
    report = instance.report
    customer_id = report.inspection_request.customer_id
    request_id = report.inspection_request_id
    return (f"inspections/customer_{customer_id}/request_{request_id}"
            f"/photos/{_unique_name(filename)}")


def report_pdf_upload_path(instance, filename):
    """instance: InspectionReport"""
    customer_id = instance.inspection_request.customer_id
    request_id = instance.inspection_request_id
    return (f"inspections/customer_{customer_id}/request_{request_id}"
            f"/reports/{instance.report_number or _unique_name(filename)}.pdf")


def signed_report_pdf_upload_path(instance, filename):
    """instance: InspectionReport"""
    customer_id = instance.inspection_request.customer_id
    request_id = instance.inspection_request_id
    return (f"inspections/customer_{customer_id}/request_{request_id}"
            f"/reports/signed/{instance.report_number or _unique_name(filename)}_signed.pdf")


def bank_receipt_upload_path(instance, filename):
    """instance: Payment (has inspection_request FK)"""
    ir = instance.inspection_request
    customer_id = ir.customer_id if ir else 'unknown'
    request_id = ir.id if ir else 'unknown'
    return (f"inspections/customer_{customer_id}/request_{request_id}"
            f"/receipts/{_unique_name(filename)}")


def invoice_pdf_upload_path(instance, filename):
    """instance: Invoice (has customer FK یا از طریق payment/inspection_request)"""
    customer_id = getattr(instance, 'customer_id', None)
    if not customer_id and getattr(instance, 'inspection_request', None):
        customer_id = instance.inspection_request.customer_id
    customer_id = customer_id or 'unknown'
    name = getattr(instance, 'invoice_number', None) or _unique_name(filename)
    return f"invoices/customer_{customer_id}/{name}.pdf"


def ticket_attachment_upload_path(instance, filename):
    """instance: TicketAttachment (has ticket FK -> customer)"""
    ticket = instance.ticket
    customer_id = ticket.customer_id
    return (f"tickets/customer_{customer_id}/ticket_{ticket.id}"
            f"/{_unique_name(filename)}")

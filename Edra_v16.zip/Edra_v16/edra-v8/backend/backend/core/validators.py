# core/validators.py
"""
MEDIUM-16/P1-05: اعتبارسنجی امن متمرکز آپلود فایل.

کنترل‌ها: پسوند، حجم، magic bytes (نه فقط extension)، نام فایل و MIME.
برای سیستم مالی/اسناد رسمی فقط extension کافی نیست؛ این ولیدیتور در تمام
مسیرهای آپلود (فیش بانکی، عکس چک‌لیست، پیوست تیکت و ...) استفاده می‌شود.
"""
import os
import re

# whitelist: پسوند → (mime, magic checker)
ALLOWED_IMAGE_EXTENSIONS = {
    '.jpg', '.jpeg', '.png', '.webp',
}
ALLOWED_DOCUMENT_EXTENSIONS = {
    '.pdf',
}
ALLOWED_RECEIPT_EXTENSIONS = ALLOWED_IMAGE_EXTENSIONS | ALLOWED_DOCUMENT_EXTENSIONS
ALLOWED_EXCEL_EXTENSIONS = {'.xlsx'}
MAX_UPLOAD_SIZE = 10 * 1024 * 1024  # ۱۰ مگابایت پیش‌فرض
MAX_RECEIPT_SIZE = 5 * 1024 * 1024   # فیش بانکی: ۵ مگابایت
MAX_IMAGE_SIZE = 8 * 1024 * 1024     # عکس چک‌لیست: ۸ مگابایت

_UNSAFE_FILENAME_RE = re.compile(r'[\\/:*?"<>|\x00-\x1f]')


def sniff_content_type(head: bytes) -> str | None:
    """تشخیص MIME از magic bytes — بر اساس whitelist واقعی."""
    if head.startswith(b'%PDF'):
        return 'application/pdf'
    if head.startswith(b'\x89PNG\r\n\x1a\n'):
        return 'image/png'
    if head[:3] == b'\xff\xd8\xff':
        return 'image/jpeg'
    if head[:4] == b'RIFF' and head[8:12] == b'WEBP':
        return 'image/webp'
    if head[:4] == b'PK\x03\x04':
        # ZIP-based — می‌تواند xlsx/docx باشد؛ بررسی دقیق‌تر با نام فایل
        return 'application/zip'
    return None


def extension_for_mime(mime: str) -> str | None:
    return {
        'application/pdf': '.pdf',
        'image/png': '.png',
        'image/jpeg': '.jpg',
        'image/webp': '.webp',
    }.get(mime)


class SecureUploadError(ValueError):
    """خطای اعتبارسنجی فایل — message فارسی برای پاسخ API."""


def validate_uploaded_file(
        uploaded_file,
        *,
        allowed_extensions=ALLOWED_RECEIPT_EXTENSIONS,
        max_size=MAX_RECEIPT_SIZE,
        allowed_mimes=None) -> str | None:
    """
    اعتبارسنجی امن فایل آپلودشده.

    خروجی: در صورت نامعتبر بودن، پیام خطای فارسی؛ در غیر این صورت None.
    کنترل‌ها:
      1. نام فایل امن (بدون کاراکترهای خطرناک)
      2. پسوند در whitelist
      3. حجم ≤ max_size
      4. magic bytes با MIME اعلام‌شده/پسوند تطبیق دارد (ضد spoofing)
    """
    name = getattr(uploaded_file, 'name', '') or ''
    ext = os.path.splitext(name)[1].lower()

    if not name or _UNSAFE_FILENAME_RE.search(name):
        return 'نام فایل نامعتبر است.'

    if ext not in allowed_extensions:
        return (
            f'فرمت فایل پشتیبانی نمی‌شود. فقط '
            f'{", ".join(sorted(allowed_extensions))} مجاز است.')

    if getattr(uploaded_file, 'size', 0) and uploaded_file.size > max_size:
        return f'حجم فایل نباید بیشتر از {max_size // (1024 * 1024)} مگابایت باشد.'

    head = uploaded_file.read(16)
    uploaded_file.seek(0)
    sniffed = sniff_content_type(head)
    if sniffed is None:
        return 'محتوای فایل با فرمت اعلام‌شده مطابقت ندارد.'

    # تطبیق magic bytes با پسوند (ضد فایل جعلی با extension جعلی)
    expected_mime = {
        '.pdf': 'application/pdf',
        '.png': 'image/png',
        '.jpg': 'image/jpeg',
        '.jpeg': 'image/jpeg',
        '.webp': 'image/webp',
    }.get(ext)
    if expected_mime and sniffed != expected_mime:
        return 'محتوای فایل با فرمت اعلام‌شده مطابقت ندارد.'

    if allowed_mimes and sniffed not in allowed_mimes:
        return 'نوع فایل مجاز نیست.'

    # EDRA v5 — HIGH-23: تصویر باید واقعاً قابل باز شدن باشد (PIL) تا
    # فایل خراب/جعلی با magic درست، بعداً در فشرده‌سازی مدل خطای 500
    # ندهد ("Truncated File Read").
    if sniffed in ('image/jpeg', 'image/png', 'image/webp'):
        try:
            from PIL import Image
            uploaded_file.seek(0)
            img = Image.open(uploaded_file)
            img.verify()
            uploaded_file.seek(0)
        except Exception:
            return 'فایل تصویر خراب یا نامعتبر است.'

    return None


def validate_excel_file(uploaded_file) -> str | None:
    """
    اعتبارسنجی فایل اکسل برای ایمپورت چک‌لیست.

    EDRA v5 — MEDIUM-21: فقط ZIP magic کافی نیست؛ ساختار داخلی XLSX
    (workbook parts) و یکپارچگی zip و حجم decompress هم بررسی می‌شود تا
    فایل جعلی (مثلاً zip معمولی با پسوند xlsx) رد شود.
    """
    import zipfile

    name = getattr(uploaded_file, 'name', '') or ''
    ext = os.path.splitext(name)[1].lower()
    if ext != '.xlsx':
        return 'فقط فایل Excel با پسوند .xlsx مجاز است.'
    if getattr(uploaded_file, 'size', 0) and uploaded_file.size > 2 * 1024 * 1024:
        return 'حجم فایل اکسل نباید بیشتر از ۲ مگابایت باشد.'
    head = uploaded_file.read(16)
    uploaded_file.seek(0)
    if head[:4] != b'PK\x03\x04':
        return 'فایل انتخابی یک فایل Excel معتبر نیست.'

    # ساختار داخلی XLSX (ZIP container)
    try:
        with zipfile.ZipFile(uploaded_file) as zf:
            names = set(zf.namelist())
            if '[Content_Types].xml' not in names:
                return 'فایل انتخابی یک فایل Excel معتبر نیست (Content_Types).'
            if not any(n.startswith('xl/workbook') for n in names):
                return 'فایل انتخابی یک فایل Excel معتبر نیست (workbook).'
            if not any(n.startswith('xl/worksheets/sheet') for n in names):
                return 'فایل انتخابی sheet ندارد.'
            # محدودیت حجم decompress (ضد zip bomb)
            total = sum(i.file_size for i in zf.infolist())
            if total > 64 * 1024 * 1024:  # ۶۴ مگابایت محتوای بازشده
                return 'محتوای فایل اکسل بیش از حد مجاز است.'
    except zipfile.BadZipFile:
        return 'فایل انتخابی یک فایل Excel معتبر نیست.'
    except Exception:
        return 'فایل انتخابی قابل خواندن نیست.'
    uploaded_file.seek(0)
    return None

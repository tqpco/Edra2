# core/views/audit_views.py
from .base_views import AuditLog, AuditLogSerializer, ErrorLog, ErrorLogSerializer, IsAdminUserOrGroup, OrderingFilter, Response, SearchFilter, action, permission_classes, status, timezone, viewsets
from ..models import ErrorLog
from ..serializers import ErrorLogSerializer


# ============================================================
# ErrorLogViewSet
# ============================================================
class ErrorLogViewSet(viewsets.ReadOnlyModelViewSet):
    """مشاهده لاگ‌های خطا (فقط ادمین)"""
    queryset = ErrorLog.objects.all()
    serializer_class = ErrorLogSerializer
    permission_classes = [IsAdminUserOrGroup]
    filter_backends = [SearchFilter, OrderingFilter]
    search_fields = ['error_id', 'error_type', 'error_message', 'path']
    ordering_fields = ['timestamp', 'status_code', 'severity']

    def get_queryset(self):
        queryset = super().get_queryset()
        resolved = self.request.query_params.get('resolved')
        if resolved is not None:
            if resolved.lower() == 'true':
                queryset = queryset.filter(resolved=True)
            elif resolved.lower() == 'false':
                queryset = queryset.filter(resolved=False)

        severity = self.request.query_params.get('severity')
        if severity:
            queryset = queryset.filter(severity=severity)

        return queryset

    @action(detail=True, methods=['post'], permission_classes=[IsAdminUserOrGroup])
    def resolve(self, request, pk=None):
        error = self.get_object()
        if error.resolved:
            return Response({'message': 'این خطا قبلاً برطرف شده است.'},
                            status=status.HTTP_400_BAD_REQUEST)

        error.resolved = True
        error.resolved_at = timezone.now()
        error.resolved_by = request.user
        error.resolution_note = request.data.get('resolution_note', '')
        error.save()

        return Response(
            {'message': f'خطا {error.error_id} به عنوان برطرف‌شده علامت‌گذاری شد.'})


# ============================================================
# AuditLogViewSet
# ============================================================
class AuditLogViewSet(viewsets.ReadOnlyModelViewSet):
    """مشاهده لاگ‌های حسابرسی (فقط ادمین)"""
    permission_classes = [IsAdminUserOrGroup]
    queryset = AuditLog.objects.all().order_by('-timestamp')
    serializer_class = AuditLogSerializer
    filter_backends = [SearchFilter, OrderingFilter]
    search_fields = ['user__username', 'action', 'object_id']
    ordering_fields = ['timestamp', 'action']

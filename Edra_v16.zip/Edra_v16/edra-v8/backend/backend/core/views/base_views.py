# core/views/base_views.py
# ✅ فایل پایه برای تمام ویوها - حذف کدهای تکراری

from ..models import AuditLog, ChecklistItem, ChecklistPhoto, ChecklistTemplate, CityMultiplier, CreditReservation, CreditTransaction, DiscountCode, EquipmentParameter, EquipmentType, ErrorLog, InspectionReport, InspectionRequest, Invoice, LedgerEntry, OTPCode, Organization, Payment, PaymentMethod, Project, Refund, ReportVerification, SequenceCounter, TaxRate, UserCredit, UserProfile
from ..serializers import AuditLog, AuditLogSerializer, ChecklistItem, ChecklistItemSerializer, ChecklistTemplate, ChecklistTemplateSerializer, CityMultiplier, CityMultiplierSerializer, CreditTransaction, CreditTransactionSerializer, DiscountCode, DiscountCodeSerializer, EquipmentType, EquipmentTypeSerializer, ErrorLog, ErrorLogSerializer, InspectionReport, InspectionReportDetailSerializer, InspectionReportSerializer, InspectionRequest, InspectionRequestListSerializer, InspectionRequestSerializer, InspectionRequestUpdateSerializer, Invoice, InvoiceSerializer, OTPCode, OTPRequestSerializer, OTPVerifySerializer, Organization, OrganizationSerializer, Payment, PaymentMethod, PaymentMethodSerializer, PaymentSerializer, Project, ProjectSerializer, ReportVerification, ReportVerificationSerializer, SequenceCounter, User, UserCredit, UserCreditSerializer, UserSerializer, get_bank_receipt_uploaded_at_jalali, get_closed_at_jalali, get_created_at_jalali, get_date_joined_jalali, get_due_date_jalali, get_expires_at_jalali, get_issue_date_jalali, get_last_run_at_jalali, get_last_viewed_at_jalali, get_paid_at_jalali, get_rejected_at_jalali, get_resolved_at_jalali, get_scheduled_at_jalali, get_sent_at_jalali, get_signed_at_jalali, get_timestamp_jalali, get_updated_at_jalali, get_used_at_jalali, get_user_model, get_verified_at_jalali, serializers, timezone, to_jalali
from ..filters import BooleanFilter, CharFilter, DateFilter, DiscountCode, DiscountCodeFilter, EquipmentType, EquipmentTypeFilter, FilterSet, InspectionReport, InspectionReportFilter, InspectionRequest, InspectionRequestFilter, Invoice, InvoiceFilter, NumberFilter, Organization, OrganizationFilter, Payment, PaymentFilter, Project, ProjectFilter, User, UserFilter, filters, get_user_model

from rest_framework import viewsets, status, generics
from rest_framework.decorators import (
    action, api_view, permission_classes, throttle_classes)
from rest_framework.response import Response
from rest_framework.permissions import AllowAny, IsAuthenticated, IsAdminUser
from ..permissions import IsAdminUserOrGroup
from rest_framework.filters import SearchFilter, OrderingFilter
from rest_framework.throttling import AnonRateThrottle, ScopedRateThrottle
from rest_framework.views import APIView
from django.contrib.auth import get_user_model
from django.utils import timezone
from django.core.cache import cache
from django.db import transaction
from django.core.files.storage import default_storage
from django.core.files.base import ContentFile
from decimal import Decimal
import random
import logging
import json
import os

from drf_spectacular.utils import extend_schema, extend_schema_view, OpenApiResponse
from django_filters.rest_framework import DjangoFilterBackend




from ..invoice_pdf_generator import generate_invoice_pdf
from ..utils.cache_utils import get_city_multiplier  # ✅ مستقیم از utils
from ..tasks import generate_report_pdf_task, generate_invoice_pdf_task

from notifications.serializers import NotificationLogSerializer
from notifications.models import NotificationLog
from notifications.services import send_notification

from guardian.shortcuts import assign_perm, get_objects_for_user
from ..permissions import (
    IsAdminGroup,
    IsExpertGroup,
    IsAdminOrExpert,
    IsCustomerOrAdmin,
    ObjectPermissionForInspectionReport,
    IsAdminOrHasObjectPermissionForInspectionRequest,
    is_admin_user,
    is_expert_user,
    is_support_user,
)

User = get_user_model()
logger = logging.getLogger(__name__)

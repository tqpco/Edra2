# core/views/common_views.py
import secrets
from django.conf import settings
from django.db.models import F
from django.utils.crypto import get_random_string
from rest_framework.exceptions import APIException
from ..models import EquipmentParameter
from django.contrib.admin.views.decorators import staff_member_required
from django.views.decorators.csrf import csrf_exempt
from django.views.decorators.http import require_POST
from django.http import JsonResponse
from .base_views import APIView, AllowAny, AuditLog, CityMultiplier, CityMultiplierSerializer, DjangoFilterBackend, EquipmentParameter, EquipmentType, EquipmentTypeFilter, EquipmentTypeSerializer, IsAdminUserOrGroup, IsAuthenticated, OTPCode, OTPRequestSerializer, OTPVerifySerializer, OrderingFilter, Organization, OrganizationFilter, OrganizationSerializer, Project, ProjectFilter, ProjectSerializer, Response, ScopedRateThrottle, SearchFilter, User, UserProfile, UserSerializer, cache, generics, logger, permission_classes, serializers, status, throttle_classes, timezone, viewsets


# ============================================================
# EquipmentTypeViewSet
# ============================================================
class EquipmentTypeViewSet(viewsets.ModelViewSet):
    queryset = EquipmentType.objects.all()
    serializer_class = EquipmentTypeSerializer
    filter_backends = [DjangoFilterBackend, SearchFilter, OrderingFilter]
    filterset_class = EquipmentTypeFilter
    search_fields = ['name_fa', 'code']
    ordering_fields = ['name_fa', 'base_price', 'code']
    ordering = ['name_fa']

    def get_permissions(self):
        if self.action in ['list', 'retrieve']:
            return [AllowAny()]
        return [IsAdminUserOrGroup()]


# ============================================================
# CityMultiplierViewSet
# ============================================================
class CityMultiplierViewSet(viewsets.ReadOnlyModelViewSet):
    """ضرایب شهرها (عمومی)"""
    permission_classes = [AllowAny]
    queryset = CityMultiplier.objects.all()
    serializer_class = CityMultiplierSerializer


# ============================================================
# OTPRequestView
# ============================================================
class OTPRequestView(generics.GenericAPIView):
    permission_classes = [AllowAny]
    serializer_class = OTPRequestSerializer
    throttle_classes = [ScopedRateThrottle]
    throttle_scope = 'otp_request'

    def post(self, request):
        try:
            serializer = self.get_serializer(data=request.data)
            serializer.is_valid(raise_exception=True)
            phone = serializer.validated_data['phone']

            # EDRA v5/v6 — HIGH-37: cooldown هر شماره (جلوگیری از هزینه
            # SMS و spam) — ۹۰ ثانیه بین دو درخواست OTP برای یک شماره.
            # EDRA v6 — P1: `cache.add` به‌جای get→set (GET→SET race).
            # در Redis production این عملیات atomic است؛ در LocMemCache هم
            # قفل داخلی دارد؛ فقط یک request می‌تواند cooldown را بگیرد.
            cooldown_key = f'otp_cooldown_{phone}'
            if not cache.add(cooldown_key, '1', timeout=90):
                return Response(
                    {'error': 'کد قبلی هنوز معتبر است. کمی صبر کنید.'},
                    status=status.HTTP_429_TOO_MANY_REQUESTS)

            # secrets به‌جای random: تولید عدد با کیفیت رمزنگاری مناسب برای کد امنیتی
            code = ''.join(secrets.choice('0123456789') for _ in range(6))
            otp = OTPCode.objects.create(phone=phone, code=code)
            cache.set(f'otp_{phone}', code, timeout=120)

            # P0-10/P0-11/HIGH-07: کد OTP هرگز نباید در log ثبت شود. در
            # Production اگر ارسال SMS شکست بخورد، کد صادرشده باطل می‌شود
            # (fail-closed) و درخواست موفق تلقی نمی‌شود. فقط در حالت رسمی
            # DEV_OTP (که کد ثابت است و SMS واقعی لازم نیست) شکست پیامک
            # غیرفاجعه است.
            try:
                from notifications.services import send_sms
                send_sms(phone, f"کد تایید ادرو: {code}")
            except Exception as send_error:
                # EDRA v6 — P1: cooldown پاک می‌شود تا کاربر برای پیامک
                # ناموفق مجبور نباشد ۹۰ ثانیه صبر کند.
                cache.delete(cooldown_key)
                if settings.DEV_OTP_ENABLED:
                    # حالت توسعه رسمی — فقط metadata لاگ می‌شود
                    logger.info(
                        f"OTP dev mode request_id={otp.id} phone={phone} "
                        f"(SMS غیرفعال)")
                else:
                    otp.is_used = True
                    otp.save(update_fields=['is_used'])
                    cache.delete(f'otp_{phone}')
                    # فقط metadata لاگ می‌شود — هرگز خود کد
                    logger.error(
                        f"OTP send failed request_id={otp.id} phone={phone}: "
                        f"{send_error}")
                    return Response(
                        {'error': 'ارسال پیامک ناموفق بود. لطفاً دوباره تلاش کنید.'},
                        status=status.HTTP_500_INTERNAL_SERVER_ERROR)

            # ⚠️ هرگز کد OTP را در پاسخ API برنگردان - این دقیقاً هدف
            # احراز هویت پیامکی را از بین می‌برد. قبلاً اینجا 'debug_code'
            # کد را مستقیم در پاسخ برمی‌گرداند که یک باگ امنیتی جدی بود.
            return Response({
                'message': 'کد تایید ارسال شد.',
            }, status=status.HTTP_200_OK)
        except serializers.ValidationError:
            raise
        except Exception as e:
            logger.error(f"OTPRequestView error: {e}")
            return Response({'error': 'خطای داخلی سرور'}, status=500)


# ============================================================
# OTPVerifyView
# ============================================================
class OTPVerifyView(generics.GenericAPIView):
    permission_classes = [AllowAny]
    serializer_class = OTPVerifySerializer
    throttle_classes = [ScopedRateThrottle]
    throttle_scope = 'otp_verify'

    MAX_ATTEMPTS = 5
    OTP_TTL_SECONDS = 120

    def post(self, request):
        try:
            serializer = self.get_serializer(data=request.data)
            serializer.is_valid(raise_exception=True)
            phone = serializer.validated_data['phone']
            code = serializer.validated_data['code']

            # ⚠️ قبلاً اینجا "if code == '123456':" یک بک‌دور کامل بود که
            # با هر شماره موبایل و کد ثابت 123456 امکان ورود/ثبت‌نام بدون
            # داشتن کد واقعی پیامک را می‌داد. کاملاً حذف شد - هیچ کد
            # میان‌بر/جهانی نباید وجود داشته باشد.

            # حالت توسعه رسمی (DEV_OTP): فقط وقتی DEBUG=True و شماره در
            # allowlist باشد. در Production این مسیر به‌کلی غیرممکن است
            # (تنظیمات در زمان استارت سرور چک می‌شود).
            if (settings.DEV_OTP_ENABLED
                    and phone in settings.DEV_OTP_ALLOWED_PHONES
                    and code == settings.DEV_OTP_CODE):
                has_recent = OTPCode.objects.filter(
                    phone=phone,
                    is_used=False,
                    created_at__gte=timezone.now() - timezone.timedelta(
                        seconds=self.OTP_TTL_SECONDS)
                ).exists()
                if has_recent:
                    user, created = self._get_or_create_user(phone)
                    try:
                        from ..models import AuditLog
                        AuditLog.objects.create(
                            user=user, action='otp_login',
                            object_id=user.id,
                            changes={'phone': phone, 'is_new_user': created,
                                     'channel': 'dev'})
                    except Exception as log_error:
                        logger.error(f"Error writing audit log: {log_error}")
                    return self._issue_tokens(user, created)
                return Response({'error': 'ابتدا کد تایید را درخواست کنید.'},
                                status=status.HTTP_400_BAD_REQUEST)

            # EDRA v6 — P1: verify در transaction + select_for_update انجام
            # می‌شود تا دو درخواست همزمان با کد صحیح نتوانند هر دو کد را
            # معتبر ببینند (قبلاً SELECT بدون قفل → هر دو is_used=False
            # می‌دیدند و هر دو token می‌گرفتند). فقط یک request کد را
            # consume می‌کند.
            from django.db import transaction as db_transaction
            with db_transaction.atomic():
                try:
                    otp = OTPCode.objects.select_for_update().filter(
                        phone=phone, is_used=False
                    ).latest('created_at')
                except OTPCode.DoesNotExist:
                    return Response({'error': 'کد نامعتبر است.'},
                                    status=status.HTTP_400_BAD_REQUEST)

                # محدودیت تلاش‌های ناموفق برای هر کد (ضد brute-force)
                if otp.attempts >= self.MAX_ATTEMPTS:
                    otp.is_used = True
                    otp.save(update_fields=['is_used'])
                    return Response(
                        {'error': 'تعداد تلاش‌های مجاز به پایان رسیده است. کد جدید درخواست کنید.'},
                        status=status.HTTP_400_BAD_REQUEST)

                # انقضا با total_seconds (نه .seconds که بخش روز را نادیده می‌گیرد)
                if (timezone.now() - otp.created_at).total_seconds() > self.OTP_TTL_SECONDS:
                    return Response({'error': 'کد منقضی شده است.'},
                                    status=status.HTTP_400_BAD_REQUEST)

                if otp.code != code:
                    # افزایش اتمیک شمارنده تلاش‌های ناموفق
                    OTPCode.objects.filter(pk=otp.pk).update(
                        attempts=F('attempts') + 1)
                    return Response({'error': 'کد نامعتبر است.'},
                                    status=status.HTTP_400_BAD_REQUEST)

                otp.is_used = True
                otp.save(update_fields=['is_used'])

            user, created = self._get_or_create_user(phone)

            # رویداد ممیزی ورود (P1 بند ۴۰)
            try:
                from ..models import AuditLog
                AuditLog.objects.create(
                    user=user,
                    action='otp_login',
                    object_id=user.id,
                    changes={'phone': phone, 'is_new_user': created})
            except Exception as log_error:
                logger.error(f"Error writing audit log: {log_error}")

            return self._issue_tokens(user, created)

        except (serializers.ValidationError, APIException):
            # خطاهای DRF (مثل 429 throttle) باید با کد مناسب خودشان برگردند،
            # نه اینکه به 500 تبدیل شوند
            raise
        except Exception as e:
            logger.error(f"OTPVerifyView error: {e}")
            return Response(
                {'error': 'خطای داخلی سرور'},
                status=status.HTTP_500_INTERNAL_SERVER_ERROR
            )

    def _get_or_create_user(self, phone):
        """ساخت یا دریافت کاربر بر اساس شماره موبایل"""
        user, created = User.objects.get_or_create(
            username=phone,
            defaults={'email': f'{phone}@temp.com'}
        )
        if created:
            # رمز تصادفی امن (قبلاً با یک باگ import، رمز واقعاً تصادفی
            # نبود و همیشه رشته‌ی ثابت "CHANGE_ME" را بین کاراکترها
            # تکرار می‌کرد - یک الگوی قابل‌حدس و ناامن)
            random_password = get_random_string(32)
            user.set_password(random_password)
            user.save()
        # اطمینان از وجود پروفایل با شماره موبایل (پیش‌نیاز ارسال
        # نوتیفیکیشن SMS — کاربران OTP پروفایل نداشتند و اعلان‌ها
        # بی‌صدا drop می‌شدند)
        try:
            from ..models import UserProfile
            UserProfile.objects.get_or_create(
                user=user, defaults={'phone': phone})
        except Exception as e:
            logger.error(f"Error creating profile for {phone}: {e}")
        return user, created

    def _issue_tokens(self, user, created):
        from rest_framework_simplejwt.tokens import RefreshToken
        refresh = RefreshToken.for_user(user)
        return Response({
            'access': str(refresh.access_token),
            'refresh': str(refresh),
            'user': UserSerializer(user).data,
            'is_new': created
        }, status=status.HTTP_200_OK)


# ============================================================
# CurrentUserView
# ============================================================
class CurrentUserView(APIView):
    permission_classes = [IsAuthenticated]

    def get(self, request):
        serializer = UserSerializer(request.user)
        return Response(serializer.data)


# ============================================================
# ChangePasswordView
# ============================================================
class ChangePasswordView(APIView):
    permission_classes = [IsAuthenticated]

    def post(self, request):
        user = request.user
        old_password = request.data.get('old_password')
        new_password = request.data.get('new_password')

        if not old_password or not new_password:
            return Response({'error': 'رمز فعلی و جدید را وارد کنید.'},
                            status=status.HTTP_400_BAD_REQUEST)

        if not user.check_password(old_password):
            return Response({'error': 'رمز فعلی اشتباه است.'},
                            status=status.HTTP_400_BAD_REQUEST)

        user.set_password(new_password)
        user.save()
        # P1-07 (EDRA v8): باطل کردن همه refresh token های قبلی
        from ..security import revoke_user_refresh_tokens
        revoke_user_refresh_tokens(user)
        return Response({'success': True,
                         'message': 'رمز عبور با موفقیت تغییر کرد.'})


# ============================================================
# DebugView
# ============================================================
class DebugView(APIView):
    permission_classes = [IsAdminUserOrGroup]

    def post(self, request):
        error_message = request.data.get('error')
        context = request.data.get('context', '')

        if not error_message:
            return Response({
                'success': False,
                'error': 'لطفاً پیام خطا را ارسال کنید.'
            }, status=400)

        try:
            from ..services.deepseek import analyze_error
            result = analyze_error(error_message, context)
        except ImportError:
            result = {
                'error': 'سرویس تحلیل خطا در دسترس نیست.',
                'message': error_message,
                'context': context
            }
        return Response(result)


# ============================================================
# OrganizationViewSet
# ============================================================
class OrganizationViewSet(viewsets.ModelViewSet):
    queryset = Organization.objects.all()
    serializer_class = OrganizationSerializer
    permission_classes = [IsAdminUserOrGroup]
    filter_backends = [DjangoFilterBackend, SearchFilter, OrderingFilter]
    filterset_class = OrganizationFilter
    search_fields = ['name', 'code']
    ordering_fields = ['name']
    ordering = ['name']


# ============================================================
# ProjectViewSet
# ============================================================
class ProjectViewSet(viewsets.ModelViewSet):
    serializer_class = ProjectSerializer
    permission_classes = [IsAuthenticated]
    filter_backends = [DjangoFilterBackend, SearchFilter, OrderingFilter]
    filterset_class = ProjectFilter
    search_fields = ['name', 'code']
    ordering_fields = ['name']
    ordering = ['name']

    def get_queryset(self):
        user = self.request.user
        if user.is_staff:
            return Project.objects.all()
        try:
            org = Organization.objects.filter(billing_contact=user).first()
            if org:
                return Project.objects.filter(organization=org)
        except Exception:
            pass
        return Project.objects.none()

    def perform_create(self, serializer):
        # EDRA v5 — HIGH-16: organization برای کاربر غیرادمین همیشه
        # server-derived است (هرگز از request body قابل تعیین نیست).
        if not self.request.user.is_staff:
            org = Organization.objects.filter(
                billing_contact=self.request.user).first()
            serializer.save(organization=org)  # می‌تواند None باشد
        else:
            serializer.save()


# ============================================================
# ویو جدید برای حذف پارامتر تجهیزات با AJAX
# ============================================================


@staff_member_required
@require_POST
# EDRA v5 — HIGH-17: CSRF protection فعال نگه داشته می‌شود (session-based
# auth + csrf_exempt = سطح حمله CSRF برای کاربر staff). هیچ caller
# فرانت‌اندی در پروژه وجود ندارد؛ در صورت افزودن، توکن CSRF ارسال شود.
def ajax_delete_parameter(request, pk):
    """
    حذف یک پارامتر تجهیزات به‌صورت AJAX و به‌روزرسانی param_schema
    """
    try:
        param = EquipmentParameter.objects.select_related(
            'equipment_type').get(pk=pk)
        equipment = param.equipment_type

        # حذف پارامتر
        param.delete()

        # به‌روزرسانی param_schema (سیگنال post_delete خودکار است، اما برای
        # بازگرداندن مقدار جدید در پاسخ)
        if equipment.parameters.exists():
            schema = [p.to_json_schema()
                      for p in equipment.parameters.all().order_by('order')]
            equipment.param_schema = schema
        else:
            equipment.param_schema = None
        equipment.save(update_fields=['param_schema'])

        return JsonResponse({
            'status': 'success',
            'message': 'پارامتر با موفقیت حذف شد.',
            'param_schema': equipment.param_schema
        })
    except EquipmentParameter.DoesNotExist:
        return JsonResponse({
            'status': 'error',
            'message': 'پارامتر یافت نشد.'
        }, status=404)
    except Exception as e:
        return JsonResponse({
            'status': 'error',
            'message': f'خطا در حذف پارامتر: {str(e)}'
        }, status=500)

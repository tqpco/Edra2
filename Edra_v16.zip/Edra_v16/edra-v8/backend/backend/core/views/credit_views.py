# core/views/credit_views.py
from .base_views import CityMultiplier, ContentFile, CreditReservation, CreditTransaction, CreditTransactionSerializer, Decimal, EquipmentType, InspectionRequest, IsAdminUserOrGroup, IsAuthenticated, Payment, PaymentMethod, Response, User, UserCredit, UserCreditSerializer, api_view, default_storage, logger, os, permission_classes, random, send_notification, timezone, transaction, viewsets
import hashlib
import os
import random
from django.utils import timezone
from django.core.files.base import ContentFile
from django.core.files.storage import default_storage

# ============================================================
# سخت‌سازی آپلود فیش (FILE-01 از گزارش ممیزی)
# — اعتبارسنجی مرکزی از core/validators.py (MEDIUM-16/P1-05)
# ============================================================
from ..validators import (
    validate_uploaded_file, MAX_RECEIPT_SIZE,  # noqa: F401 — سازگاری عقب‌رو
)


def _validate_receipt_file(uploaded_file):
    """
    اعتبارسنجی فایل فیش: پسوند + حجم + magic bytes واقعی + نام فایل.
    در صورت نامعتبر بودن، پیام خطای فارسی برمی‌گرداند؛ در غیر این صورت None.
    """
    return validate_uploaded_file(uploaded_file)


def _save_receipt_file(receipt_file, user_id):
    """
    EDRA v5 — CRITICAL-04/HIGH-05:
    ذخیره فیش با hash درست.
      - bytes فقط یک بار خوانده می‌شود (قبلاً بعد از read اول، hash از
        cursor خالی گرفته می‌شد → hash اشتباه).
      - extension از نام فایل معتبر استخراج می‌شود (قبلاً متغیر `ext`
        تعریف نشده بود → NameError).
      - نام اصلی فایل به storage path منتقل نمی‌شود (فقط id+timestamp+random).

    خروجی: (storage_path, sha256_hexdigest)
    """
    content = receipt_file.read()
    name = getattr(receipt_file, 'name', '') or ''
    ext = os.path.splitext(name)[1].lower()
    path = (
        f'receipts/{user_id}_{int(timezone.now().timestamp())}_'
        f'{random.randint(1000, 9999)}{ext}')
    storage_path = default_storage.save(path, ContentFile(content))
    digest = hashlib.sha256(content).hexdigest()
    return storage_path, digest


# ============================================================
# UserCreditViewSet
# ============================================================
class UserCreditViewSet(viewsets.ReadOnlyModelViewSet):
    permission_classes = [IsAuthenticated]
    serializer_class = UserCreditSerializer

    def get_queryset(self):
        return UserCredit.objects.filter(user=self.request.user)

    def get_object(self):
        try:
            return UserCredit.objects.get(user=self.request.user)
        except UserCredit.DoesNotExist:
            return UserCredit.objects.create(user=self.request.user)


# ============================================================
# CreditTransactionViewSet
# ============================================================
class CreditTransactionViewSet(viewsets.ReadOnlyModelViewSet):
    permission_classes = [IsAuthenticated]
    serializer_class = CreditTransactionSerializer

    def get_queryset(self):
        return CreditTransaction.objects.filter(
            user=self.request.user).order_by('-created_at')


# ============================================================
# request_credit_deposit
# ============================================================
@api_view(['POST'])
@permission_classes([IsAuthenticated])
def request_credit_deposit(request):
    """
    افزایش اعتبار یا پرداخت دستی با آپلود فیش
    پارامترها:
    - amount: مبلغ
    - method: 'manual' یا 'online' یا 'credit'
    - request_id: (اختیاری) شناسه درخواست برای پرداخت مستقیم
    - receipt_file: (برای روش manual) فایل فیش
    """
    try:
        amount = request.data.get('amount')
        method = request.data.get('method', 'manual')
        request_id = request.data.get('request_id')

        # P0-01 (EDRA v9): اگر request_id داده شده باشد، مبلغ پرداخت فقط از
        # snapshot فاکتور server-side گرفته می‌شود و amount کلاینت نادیده
        # گرفته می‌شود (Wizard قبلاً amount=0 ارسال می‌کرد و Backend با
        # «مبلغ باید بیشتر از صفر باشد» رد می‌کرد → پرداخت دستی شکست می‌خورد).
        if request_id and method in ('manual', 'online', 'credit'):
            amount = None
        elif not amount:
            return Response({'error': 'مبلغ را وارد کنید.'}, status=400)
        else:
            amount = Decimal(str(amount))
            if amount <= 0:
                return Response(
                    {'error': 'مبلغ باید بیشتر از صفر باشد.'}, status=400)

        # --- پرداخت ترکیبی: بخشی از اعتبار + باقی‌مانده با روش دیگر ---
        # رزرو اتمیک (FIN-04): اعتبار کسر نمی‌شود تا پرداخت آنلاین موفق شود؛
        # در شکست درگاه رزرو آزاد می‌شود و در موفقیت مصرف می‌گردد.
        credit_amount_requested = request.data.get('credit_amount')
        reserved_credit = None
        if credit_amount_requested and request_id and method in ('online', 'manual'):
            try:
                inspection_request_for_credit = InspectionRequest.objects.get(
                    id=request_id, customer=request.user)
            except InspectionRequest.DoesNotExist:
                return Response({'error': 'درخواست یافت نشد.'}, status=404)

            from ..services.credit_service import (
                CreditService, InsufficientCreditError)

            credit_amount_requested = Decimal(str(credit_amount_requested))
            if credit_amount_requested > inspection_request_for_credit.final_price:
                return Response(
                    {'error': 'مبلغ اعتبار نمی‌تواند بیشتر از مبلغ درخواست باشد.'},
                    status=400)

            try:
                reserved_credit = CreditService.reserve(
                    request.user, credit_amount_requested,
                    inspection_request=inspection_request_for_credit)
            except InsufficientCreditError as e:
                return Response({'error': str(e)}, status=400)

            # اگر کل مبلغ با اعتبار پوشش داده شد، همان‌جا مصرف و تسویه می‌شود
            # مبلغ از snapshot فاکتور (پس از تخفیف + مالیات) — P0-6
            snap = InvoiceSettlementService.payment_snapshot(
                inspection_request_for_credit,
                credit_amount=credit_amount_requested)
            if credit_amount_requested >= snap['amount']:
                from ..models import PaymentMethod
                from ..services.credit_service import CreditService as CS
                from ..services.invoice_service import InvoiceSettlementService

                payment_method, _ = PaymentMethod.objects.get_or_create(
                    name='credit', defaults={'is_active': True})
                with transaction.atomic():
                    payment = Payment.objects.create(
                        inspection_request=inspection_request_for_credit,
                        amount=snap['amount'],
                        amount_rial=snap['amount_rial'],
                        credit_amount=snap['amount'],
                        online_amount=0,
                        manual_amount=0,
                        method=payment_method,
                        status='paid',
                        verified_at=timezone.now(),
                    )
                    reserved_credit.payment = payment
                    reserved_credit.save(update_fields=['payment'])
                    CS.consume(reserved_credit, description=(
                        f'پرداخت کامل با اعتبار بابت درخواست '
                        f'#{inspection_request_for_credit.id}'))
                    inspection_request_for_credit.status = 'paid'
                    inspection_request_for_credit.save(update_fields=['status'])

                # فاکتور از سرویس مرکزی (idempotent)
                InvoiceSettlementService.settle(
                    inspection_request_for_credit, payment=payment,
                    is_paid=True, paid_at=timezone.now(), user=request.user)

                try:
                    from notifications.services import send_notification
                    send_notification(request.user, 'payment_successful', {
                        'request_id': inspection_request_for_credit.id,
                        'amount': str(inspection_request_for_credit.final_price),
                        'method': 'credit'
                    })
                except Exception as e:
                    logger.error(f"Error sending notification: {e}")

                credit_after = UserCredit.objects.get(user=request.user).balance
                return Response({
                    'success': True,
                    'message': 'کل مبلغ با اعتبار شما پوشش داده شد.',
                    'new_balance': credit_after,
                    'applied_credit': credit_amount_requested,
                    'remaining_amount': 0,
                })

        # اگر روش اعتبار شرکتی باشد
        if method == 'credit':
            from ..services.credit_service import CreditService
            from ..services.invoice_service import InvoiceSettlementService

            if request_id:
                try:
                    inspection_request = InspectionRequest.objects.get(
                        id=request_id, customer=request.user)
                    if inspection_request.status != 'pending_payment':
                        return Response(
                            {'error': 'این درخواست در وضعیت قابل پرداخت نیست.'}, status=400)

                    # پرداخت کامل با اعتبار: رزرو + مصرف اتمیک (FIN-04)
                    # مبلغ از snapshot فاکتور (پس از تخفیف + مالیات) — P0-6
                    snap = InvoiceSettlementService.payment_snapshot(
                        inspection_request,
                        credit_amount=inspection_request.final_price)
                    reservation = CreditService.reserve(
                        request.user, snap['amount'],
                        inspection_request=inspection_request)

                    payment_method, _ = PaymentMethod.objects.get_or_create(
                        name='credit', defaults={'is_active': True})
                    with transaction.atomic():
                        payment = Payment.objects.create(
                            inspection_request=inspection_request,
                            amount=snap['amount'],
                            amount_rial=snap['amount_rial'],
                            credit_amount=snap['amount'],
                            online_amount=0,
                            method=payment_method,
                            status='paid',
                            verified_at=timezone.now(),
                        )
                        reservation.payment = payment
                        reservation.save(update_fields=['payment'])
                        CreditService.consume(reservation, description=(
                            f'پرداخت هزینه بازرسی درخواست #{inspection_request.id} با اعتبار'))
                        inspection_request.status = 'paid'
                        inspection_request.save(update_fields=['status'])

                    # فاکتور فقط از سرویس مرکزی (idempotent)
                    InvoiceSettlementService.settle(
                        inspection_request, payment=payment,
                        is_paid=True, paid_at=timezone.now(), user=request.user)

                    credit = UserCredit.objects.get(user=request.user)
                    try:
                        send_notification(request.user, 'payment_successful', {
                            'request_id': inspection_request.id,
                            'amount': str(inspection_request.final_price),
                            'method': 'credit'
                        })
                    except Exception as e:
                        logger.error(f"Error sending notification: {e}")

                    return Response({
                        'success': True,
                        'message': f'پرداخت با اعتبار انجام شد. موجودی جدید: {credit.balance:,} تومان',
                        'new_balance': credit.balance
                    })
                except InspectionRequest.DoesNotExist:
                    return Response({'error': 'درخواست یافت نشد.'}, status=404)
            else:
                credit, _ = UserCredit.objects.get_or_create(user=request.user)
                if credit.balance < amount:
                    return Response(
                        {'error': f'اعتبار کافی نیست. موجودی: {credit.balance:,} تومان'}, status=400)

                credit.balance += amount
                credit.save()
                CreditTransaction.objects.create(
                    user=request.user,
                    amount=amount,
                    transaction_type='deposit',
                    description=f'افزایش اعتبار به مبلغ {amount:,} تومان',
                    balance_after=credit.balance
                )
                return Response({
                    'success': True,
                    'message': f'مبلغ {amount:,} تومان به اعتبار شما اضافه شد.',
                    'new_balance': credit.balance
                })

        # روش دستی (آپلود فیش)
        if method == 'manual':
            receipt_file = request.FILES.get('receipt_file')
            if not receipt_file:
                return Response(
                    {'error': 'فایل فیش ارسال نشده است.'}, status=400)

            file_error = _validate_receipt_file(receipt_file)
            if file_error:
                return Response({'error': file_error}, status=400)

            if request_id:
                # پرداخت مستقیم برای یک درخواست خاص (با آپلود فیش)
                try:
                    inspection_request = InspectionRequest.objects.get(
                        id=request_id, customer=request.user)
                    if inspection_request.status != 'pending_payment':
                        return Response(
                            {'error': 'این درخواست در وضعیت قابل پرداخت نیست.'}, status=400)

                    # مبلغ از snapshot فاکتور (پس از تخفیف + مالیات) — P0-6
                    snap = InvoiceSettlementService.payment_snapshot(
                        inspection_request, credit_amount=0)
                    # اگر کاربر قبلاً اعتبار رزرو کرده، در فیش لحاظ می‌شود
                    from core.models import CreditReservation
                    reservation = CreditReservation.objects.filter(
                        user=request.user,
                        inspection_request=inspection_request,
                        status='reserved').first()
                    credit_part = reservation.amount if reservation else 0

                    payment_method, _ = PaymentMethod.objects.get_or_create(
                        name='manual', defaults={'is_active': True})
                    payment = Payment.objects.create(
                        inspection_request=inspection_request,
                        amount=snap['amount'],
                        amount_rial=snap['amount_rial'],
                        credit_amount=credit_part,
                        online_amount=0,
                        manual_amount=snap['amount'] - credit_part,
                        method=payment_method,
                        status='pending_verification',
                        created_at=timezone.now()
                    )
                    if reservation:
                        reservation.payment = payment
                        reservation.save(update_fields=['payment'])

                    file_path, digest = _save_receipt_file(
                        receipt_file, request.user.id)
                    payment.bank_receipt = file_path
                    payment.bank_receipt_uploaded_at = timezone.now()
                    payment.bank_receipt_hash = digest
                    payment.save()

                    admins = User.objects.filter(is_staff=True)
                    for admin in admins:
                        try:
                            send_notification(admin, 'payment_manual_upload', {
                                'request_id': inspection_request.id,
                                'payment_id': payment.id,
                                'customer': request.user.username,
                                'amount': str(inspection_request.final_price)
                            })
                        except Exception as e:
                            logger.error(
                                f"Error sending admin notification: {e}")

                    return Response({
                        'success': True,
                        'message': 'فیش با موفقیت آپلود شد. پس از تأیید مدیر، درخواست شما تکمیل می‌شود.',
                        'payment_id': payment.id,
                        'status': 'pending_verification'
                    })
                except InspectionRequest.DoesNotExist:
                    return Response({'error': 'درخواست یافت نشد.'}, status=404)
            else:
                # ✅ افزایش اعتبار با آپلود فیش (شارژ کیف پول) - اصلاح شده
                equipment = EquipmentType.objects.first()
                city = CityMultiplier.objects.first()
                if not equipment or not city:
                    return Response(
                        {'error': 'داده‌های پایه یافت نشد.'}, status=500)

                # ✅ تغییر: brand_model به "واریز اعتبار" و manufacture_year به None
                temp_request = InspectionRequest.objects.create(
                    customer=request.user,
                    equipment_type=equipment,
                    city=city.city,
                    address='واریز اعتبار - آپلود فیش',
                    brand_model='واریز اعتبار',  # ✅ اصلاح شده
                    manufacture_year=None,     # ✅ اصلاح شده
                    calculated_price=amount,
                    final_price=amount,
                    status='pending_payment',
                    params={'is_deposit': True}  # برای تشخیص در تایید
                )

                payment_method, _ = PaymentMethod.objects.get_or_create(
                    name='manual', defaults={'is_active': True})
                payment = Payment.objects.create(
                    inspection_request=temp_request,
                    amount=amount,
                    amount_rial=toman_to_rial(amount),
                    manual_amount=amount,
                    method=payment_method,
                    status='pending_verification',
                    created_at=timezone.now()
                )

                file_path, digest = _save_receipt_file(
                    receipt_file, request.user.id)
                payment.bank_receipt = file_path
                payment.bank_receipt_uploaded_at = timezone.now()
                payment.bank_receipt_hash = digest
                payment.save()

                return Response({
                    'success': True,
                    'message': 'فیش با موفقیت آپلود شد. پس از تأیید مدیر، اعتبار شما افزایش می‌یابد.',
                    'payment_id': payment.id,
                    'status': 'pending_verification'
                })

        # روش آنلاین (زرین‌پال)
        if method == 'online':
            from ..services.payment_service import ZarinpalService
            from ..services.money import toman_to_rial as _to_rial

            # اگر برای یک درخواست مشخص باشد → همان مسیر initiate_payment
            if request_id:
                from ..views.payment_views import initiate_payment
                return initiate_payment(request)

            equipment = EquipmentType.objects.first()
            city = CityMultiplier.objects.first()
            if not equipment or not city:
                return Response(
                    {'error': 'داده‌های پایه یافت نشد.'}, status=500)

            temp_request = InspectionRequest.objects.create(
                customer=request.user,
                equipment_type=equipment,
                city=city.city,
                address='افزایش اعتبار - آنلاین',
                brand_model='واریز اعتبار',  # ✅ اصلاح شده
                manufacture_year=None,       # ✅ اصلاح شده
                calculated_price=amount,
                final_price=amount,
                status='pending_payment',
                params={'is_deposit': True}
            )

            payment_method, _ = PaymentMethod.objects.get_or_create(
                name='online', defaults={'is_active': True})
            payment = Payment.objects.create(
                inspection_request=temp_request,
                amount=amount,
                amount_rial=_to_rial(amount),
                online_amount=amount,
                method=payment_method,
                status='pending',
                created_at=timezone.now()
            )

            # ✅ اصلاح: initiation واقعی درگاه (قبلاً بدون gateway رها می‌شد)
            callback_url = request.build_absolute_uri(
                '/api/core/payment/callback/')
            result = ZarinpalService.create_payment(
                int(_to_rial(amount)),
                f'افزایش اعتبار - درخواست #{temp_request.id}',
                callback_url,
                {'mobile': request.user.username,
                 'email': request.user.email or ''})
            if result['success']:
                payment.authority = result['authority']
                payment.save(update_fields=['authority'])
                return Response({
                    'success': True,
                    'message': 'لطفاً پرداخت را از طریق درگاه انجام دهید.',
                    'payment_id': payment.id,
                    'payment_url': result['payment_url'],
                    'authority': result['authority'],
                    'status': 'pending'
                })
            else:
                payment.status = 'failed'
                payment.save(update_fields=['status'])
                return Response({'error': result['error']}, status=500)

        return Response({'error': 'روش پرداخت نامعتبر است.'}, status=400)

    except Exception as e:
        import traceback
        traceback.print_exc()
        return Response({'error': str(e)}, status=500)


# ============================================================
# upload_deposit_receipt
# ============================================================
@api_view(['POST'])
@permission_classes([IsAuthenticated])
def upload_deposit_receipt(request):
    """
    آپلود فیش برای پرداخت موجود (قابل استفاده برای پرداخت‌های قبلی)
    """
    try:
        payment_id = request.data.get('payment_id')
        if not payment_id:
            return Response(
                {'error': 'شناسه پرداخت وارد نشده است.'}, status=400)

        payment = Payment.objects.get(id=payment_id)
        if payment.inspection_request.customer != request.user and not request.user.is_staff:
            return Response({'error': 'دسترسی غیرمجاز.'}, status=403)

        if payment.status not in ['pending', 'pending_verification']:
            return Response(
                {'error': 'این پرداخت در وضعیت قابل آپلود نیست.'}, status=400)

        receipt_file = request.FILES.get('receipt_file')
        if not receipt_file:
            return Response({'error': 'فایل فیش ارسال نشده است.'}, status=400)

        file_error = _validate_receipt_file(receipt_file)
        if file_error:
            return Response({'error': file_error}, status=400)

        file_path, digest = _save_receipt_file(
            receipt_file, request.user.id)
        payment.bank_receipt = file_path
        payment.bank_receipt_uploaded_at = timezone.now()
        payment.bank_receipt_hash = digest
        payment.status = 'pending_verification'
        payment.save()

        admins = User.objects.filter(is_staff=True)
        for admin in admins:
            try:
                send_notification(admin, 'payment_manual_upload', {
                    'request_id': payment.inspection_request.id,
                    'payment_id': payment.id,
                    'customer': request.user.username,
                    'amount': str(payment.amount)
                })
            except Exception as e:
                logger.error(f"Error sending admin notification: {e}")

        return Response({
            'success': True,
            'message': 'فیش با موفقیت آپلود شد. پس از تأیید مدیر، پرداخت شما تکمیل می‌شود.',
            'status': 'pending_verification'
        })
    except Exception as e:
        return Response({'error': str(e)}, status=500)


# ============================================================
# verify_deposit_payment
# ============================================================
@api_view(['POST'])
@permission_classes([IsAdminUserOrGroup])
def verify_deposit_payment(request, payment_id):
    """
    تایید فیش توسط مدیر
    """
    try:
        payment = Payment.objects.get(id=payment_id)
        if payment.status != 'pending_verification':
            return Response(
                {'error': 'این پرداخت در وضعیت انتظار تأیید نیست.'}, status=400)

        with transaction.atomic():
            payment.status = 'paid'
            payment.verified_by = request.user
            payment.verified_at = timezone.now()
            payment.save()

            inspection_request = payment.inspection_request
            user = inspection_request.customer

            is_deposit = inspection_request.params.get(
                'is_deposit', False) if inspection_request.params else False

            if is_deposit:
                # افزایش اعتبار کاربر
                credit, _ = UserCredit.objects.get_or_create(user=user)
                credit.balance += payment.amount
                credit.save()

                CreditTransaction.objects.create(
                    user=user,
                    amount=payment.amount,
                    transaction_type='deposit',
                    description=f'واریز اعتبار به مبلغ {payment.amount:,} تومان - تأیید شده توسط {request.user.username}',
                    balance_after=credit.balance,
                    reference_id=str(payment.id)
                )

                inspection_request.status = 'completed'
                inspection_request.save()

                try:
                    send_notification(user, 'payment_verified', {
                        'request_id': inspection_request.id,
                        'amount': str(payment.amount),
                        'message': 'اعتبار شما با موفقیت افزایش یافت.'
                    })
                except Exception as e:
                    logger.error(f"Error sending notification: {e}")

                return Response({
                    'success': True,
                    'message': f'پرداخت تأیید شد و مبلغ {payment.amount:,} تومان به اعتبار کاربر اضافه شد.',
                    'new_balance': credit.balance
                })

            else:
                if inspection_request.status == 'pending_payment':
                    inspection_request.status = 'scheduled'
                    inspection_request.save(update_fields=['status'])

                    # مصرف رزروهای اعتبار (پرداخت ترکیبی فیش + اعتبار)
                    if payment.credit_amount:
                        from ..services.credit_service import CreditService
                        CreditService.consume_for_payment(payment)

                    # فاکتور از سرویس مرکزی (idempotent؛ سیگنال post_save
                    # payment-paid قبلاً آن را ساخته است — اینجا تضمین می‌کنیم)
                    from ..services.invoice_service import InvoiceSettlementService
                    InvoiceSettlementService.settle(
                        inspection_request, payment=payment,
                        is_paid=True, paid_at=payment.verified_at,
                        user=user)

                    try:
                        send_notification(
                            user, 'payment_verified_request', {
                                'request_id': inspection_request.id, 'amount': str(
                                    payment.amount), 'message': f'پرداخت شما بابت درخواست #{inspection_request.id} با موفقیت تأیید شد. درخواست شما زمان‌بندی شد.'})
                    except Exception as e:
                        logger.error(f"Error sending notification: {e}")

                    return Response(
                        {
                            'success': True,
                            'message': f'پرداخت تأیید شد. درخواست #{inspection_request.id} به وضعیت زمان‌بندی شده تغییر یافت. فاکتور در حال تولید است.',
                            'request_status': 'scheduled'})
                else:
                    return Response(
                        {'error': 'وضعیت درخواست برای پرداخت مناسب نیست.'}, status=400)

    except Payment.DoesNotExist:
        return Response({'error': 'پرداخت یافت نشد.'}, status=404)
    except Exception as e:
        logger.error(f"Error in verify_deposit_payment: {e}")
        return Response({'error': str(e)}, status=500)


# ============================================================
# reject_payment
# ============================================================
@api_view(['POST'])
@permission_classes([IsAdminUserOrGroup])
def reject_payment(request, payment_id):
    """
    رد فیش توسط مدیر + ارسال نوتیفیکیشن و پیامک به مشتری
    """
    try:
        payment = Payment.objects.get(id=payment_id)
        if payment.status != 'pending_verification':
            return Response(
                {'error': 'این پرداخت در وضعیت انتظار تأیید نیست.'}, status=400)

        rejection_reason = request.data.get(
            'rejection_reason', 'دلیل مشخص نشده است.')

        with transaction.atomic():
            payment.status = 'rejected'
            payment.rejected_by = request.user
            payment.rejected_at = timezone.now()
            payment.rejection_reason = rejection_reason
            payment.save()

            user = payment.inspection_request.customer

            # P0-04 (EDRA v9): قبلاً credit.balance += credit_amount انجام
            # می‌شد در حالی که Reservation هنوز 'reserved' بود → double credit.
            # حالا: رزروهای فعال آزاد می‌شوند (موجودی دست نمی‌خورد)؛ فقط اگر
            # اعتبار واقعاً consume شده بود (status != reserved) برگردانده
            # می‌شود.
            from ..services.credit_service import CreditService
            active_reservations = CreditReservation.objects.filter(
                payment=payment, status='reserved')
            if active_reservations.exists():
                CreditService.release_for_payment(payment)
            elif payment.credit_amount and payment.credit_amount > 0:
                # اعتبار قبلاً مصرف شده بود → refund واقعی به موجودی
                try:
                    credit = UserCredit.objects.get(user=user)
                    credit.balance += payment.credit_amount
                    credit.save()

                    CreditTransaction.objects.create(
                        user=user,
                        amount=payment.credit_amount,
                        transaction_type='refund',
                        description=f'بازگشت اعتبار بابت رد فیش درخواست #{
                            payment.inspection_request.id}',
                        balance_after=credit.balance,
                        reference_id=str(
                            payment.id))
                except UserCredit.DoesNotExist:
                    pass

            try:
                send_notification(user, 'payment_rejected', {
                    'request_id': payment.inspection_request.id,
                    'reason': rejection_reason,
                    'payment_id': payment.id
                })

                try:
                    from notifications.services import send_sms
                    send_sms(
                        phone=user.username, message=f'پرداخت شما بابت درخواست #{
                            payment.inspection_request.id} رد شد. دلیل: {rejection_reason}')
                except (ImportError, Exception) as sms_error:
                    logger.warning(f"SMS service not available: {sms_error}")

            except Exception as e:
                logger.error(f"Error sending rejection notification: {e}")

        return Response({
            'success': True,
            'message': 'فیش با موفقیت رد شد. پیامک و نوتیفیکیشن برای مشتری ارسال شد.',
            'status': 'rejected'
        })

    except Payment.DoesNotExist:
        return Response({'error': 'پرداخت یافت نشد.'}, status=404)
    except Exception as e:
        logger.error(f"Error in reject_payment: {e}")
        return Response({'error': str(e)}, status=500)

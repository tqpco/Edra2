# core/views/dashboard_views.py
from .base_views import APIView, InspectionReport, InspectionReportSerializer, InspectionRequest, InspectionRequestSerializer, IsAdminUserOrGroup, IsAuthenticated, Payment, Response, User, UserCredit, cache, get_user_model, logger, permission_classes, timezone, to_jalali
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework.permissions import IsAdminUser, IsAuthenticated
from core.permissions import IsAdminUserOrGroup
from django.db.models import Count, Sum
from ..utils.date_utils import to_jalali


# ============================================================
# AdminDashboardStatsView با کش کردن آمار
# ============================================================
class AdminDashboardStatsView(APIView):
    permission_classes = [IsAdminUserOrGroup]

    def get(self, request):
        # کش کردن آمار به مدت ۱ ساعت برای کاهش بار دیتابیس
        cache_key = 'admin_dashboard_stats'
        stats = cache.get(cache_key)

        if stats is None:
            from ..models import InspectionRequest, Payment, InspectionReport
            from django.contrib.auth import get_user_model
            from django.utils import timezone
            from datetime import timedelta
            from django.db.models import Count, Sum
            User = get_user_model()

            now = timezone.now()
            month_start = now.replace(
                day=1, hour=0, minute=0, second=0, microsecond=0)

            # ✅ استفاده از aggregate برای کاهش تعداد کوئری‌ها
            stats = {
                'totalRequests': InspectionRequest.objects.count(),
                'totalPayments': Payment.objects.filter(status='paid').count(),
                'totalUsers': User.objects.count(),
                'totalReports': InspectionReport.objects.count(),
                'pendingRequests': InspectionRequest.objects.filter(status='pending_payment').count(),
                'completedRequests': InspectionRequest.objects.filter(status='completed').count(),
                'revenueThisMonth': Payment.objects.filter(
                    status='paid', created_at__gte=month_start
                ).aggregate(total=Sum('amount'))['total'] or 0,
                'recentActivities': list(
                    InspectionRequest.objects.select_related('customer')
                    .order_by('-created_at')[:5]
                    .values('id', 'created_at', 'customer__username')
                ),
            }

            # ✅ ذخیره در کش برای ۱ ساعت (۳۶۰۰ ثانیه)
            cache.set(cache_key, stats, 3600)

        # تبدیل timestamp به isoformat برای JSON
        for activity in stats.get('recentActivities', []):
            if activity.get('created_at'):
                activity['timestamp'] = activity['created_at'].isoformat()
                activity['action'] = f'درخواست جدید #{
                    activity["id"]} توسط {
                    activity["customer__username"]}'
                activity['user'] = activity['customer__username']

        return Response(stats)


# ============================================================
# CustomerDashboardView
# ============================================================
class CustomerDashboardView(APIView):
    permission_classes = [IsAuthenticated]

    def get(self, request):
        user = request.user
        if not user or not user.is_authenticated:
            return Response({
                'total_requests': 0,
                'active_requests': 0,
                'approved_reports': 0,
                'credit': 0,
                'user': {
                    'id': None,
                    'username': 'میهمان',
                    'full_name': 'میهمان',
                }
            })

        try:
            total_requests = InspectionRequest.objects.filter(
                customer=user).count()
            active_requests = InspectionRequest.objects.filter(
                customer=user, status__in=[
                    'pending_payment', 'paid', 'scheduled', 'in_progress']).count()
            approved_reports = InspectionReport.objects.filter(
                inspection_request__customer=user,
                pdf_file__isnull=False
            ).count()

            try:
                credit = UserCredit.objects.get(user=user)
                balance = credit.balance
            except UserCredit.DoesNotExist:
                balance = 0

            recent_requests = InspectionRequest.objects.filter(
                customer=user
            ).select_related('equipment_type').order_by('-created_at')[:5]

            next_inspection = InspectionRequest.objects.filter(
                customer=user,
                status__in=['scheduled', 'assigned'],
                scheduled_at__isnull=False,
            ).order_by('scheduled_at').first()

            return Response({
                'total_requests': total_requests,
                'active_requests': active_requests,
                'approved_reports': approved_reports,
                'credit': balance,
                'user': {
                    'id': user.id,
                    'username': user.username,
                    'full_name': user.get_full_name() or user.username,
                },
                'recent_requests': [{
                    'id': r.id,
                    'request_number': r.request_number,
                    'equipment': r.equipment_type.name_fa if r.equipment_type_id else None,
                    'status': r.status,
                    'final_price': r.final_price,
                    'created_at_jalali': to_jalali(r.created_at),
                } for r in recent_requests],
                'next_inspection': {
                    'id': next_inspection.id,
                    'request_number': next_inspection.request_number,
                    'scheduled_at_jalali': to_jalali(next_inspection.scheduled_at),
                    'address': next_inspection.address,
                } if next_inspection else None,
            })
        except Exception as e:
            logger.error(f"خطا در CustomerDashboardView: {e}")
            return Response({
                'total_requests': 0,
                'active_requests': 0,
                'approved_reports': 0,
                'credit': 0,
                'user': {
                    'id': user.id,
                    'username': user.username,
                    'full_name': user.get_full_name() or user.username,
                },
                'recent_requests': [],
                'next_inspection': None,
            })


# ============================================================
# ExpertDashboardView
# ============================================================
class ExpertDashboardView(APIView):
    permission_classes = [IsAuthenticated]

    def get(self, request):
        user = request.user
        # فقط ادمین و کارشناسان (گروه Expert) دسترسی دارند؛ مشتری عادی 403 بگیرد
        if not user.is_staff and not user.groups.filter(
                name='Expert').exists():
            return Response({'error': 'دسترسی غیرمجاز'}, status=403)
        if not user or not user.is_authenticated:
            return Response({
                'total_assigned': 0,
                'pending_inspections': 0,
                'completed_reports': 0,
                'user': {
                    'id': None,
                    'username': 'میهمان',
                    'full_name': 'میهمان',
                }
            })

        total_assigned = InspectionRequest.objects.filter(
            assigned_expert=user).count()
        pending_inspections = InspectionRequest.objects.filter(
            assigned_expert=user, status='in_progress').count()
        completed_reports = InspectionReport.objects.filter(
            inspection_request__assigned_expert=user).count()

        now = timezone.now()
        today_start = now.replace(hour=0, minute=0, second=0, microsecond=0)
        today_end = today_start + timezone.timedelta(days=1)

        todays_tasks = InspectionRequest.objects.filter(
            assigned_expert=user,
            status__in=['assigned', 'scheduled', 'in_progress'],
            scheduled_at__gte=today_start,
            scheduled_at__lt=today_end,
        ).select_related('equipment_type').order_by('scheduled_at')

        upcoming_tasks = InspectionRequest.objects.filter(
            assigned_expert=user,
            status__in=['assigned', 'scheduled'],
            scheduled_at__gte=today_end,
        ).select_related('equipment_type').order_by('scheduled_at')[:5]

        def _serialize_task(r):
            return {
                'id': r.id,
                'request_number': r.request_number,
                'equipment': r.equipment_type.name_fa if r.equipment_type_id else None,
                'status': r.status,
                'scheduled_at_jalali': to_jalali(r.scheduled_at) if r.scheduled_at else None,
                'address': r.address,
                'city': r.city,
            }

        return Response({
            'total_assigned': total_assigned,
            'pending_inspections': pending_inspections,
            'completed_reports': completed_reports,
            'user': {
                'id': user.id,
                'username': user.username,
                'full_name': user.get_full_name() or user.username,
            },
            'todays_tasks': [_serialize_task(r) for r in todays_tasks],
            'upcoming_tasks': [_serialize_task(r) for r in upcoming_tasks],
        })


# ============================================================
# CustomerRequestsView
# ============================================================
class CustomerRequestsView(APIView):
    permission_classes = [IsAuthenticated]

    def get(self, request):
        from ..serializers import InspectionRequestSerializer
        requests = InspectionRequest.objects.filter(
            customer=request.user).order_by('-created_at')
        serializer = InspectionRequestSerializer(requests, many=True)
        return Response(serializer.data)


# ============================================================
# CustomerReportsView
# ============================================================
class CustomerReportsView(APIView):
    permission_classes = [IsAuthenticated]

    def get(self, request):
        from ..serializers import InspectionReportSerializer
        queryset = InspectionReport.objects.filter(
            inspection_request__customer=request.user,
            pdf_file__isnull=False
        )
        # فیلتر اختیاری بر اساس درخواست بازرسی (برای صفحه جزئیات درخواست)
        inspection_request_id = request.query_params.get('inspection_request')
        if inspection_request_id:
            queryset = queryset.filter(
                inspection_request_id=inspection_request_id)
        reports = queryset.order_by('-created_at')
        serializer = InspectionReportSerializer(reports, many=True)
        return Response(serializer.data)

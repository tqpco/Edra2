# core/views/discount_views.py
from .base_views import Decimal, DiscountCode, DiscountCodeFilter, DiscountCodeSerializer, DjangoFilterBackend, InspectionRequest, IsAdminUserOrGroup, IsAuthenticated, OrderingFilter, Response, SearchFilter, action, permission_classes, status, timezone, viewsets
from rest_framework.decorators import action
from rest_framework.response import Response
from rest_framework import status
from rest_framework.permissions import IsAuthenticated
from django.utils import timezone


class DiscountCodeViewSet(viewsets.ModelViewSet):
    """
    مدیریت کدهای تخفیف (فقط ادمین)
    """
    queryset = DiscountCode.objects.all()
    serializer_class = DiscountCodeSerializer
    permission_classes = [IsAdminUserOrGroup]
    filter_backends = [DjangoFilterBackend, SearchFilter, OrderingFilter]
    filterset_class = DiscountCodeFilter
    search_fields = ['code', 'description']
    ordering_fields = ['code', 'value', 'used_count']
    ordering = ['code']

    @action(detail=False, methods=['post'],
            permission_classes=[IsAuthenticated])
    def apply(self, request):
        """
        اعمال کد تخفیف برای کاربر جاری.
        اگر کد دارای apply_to_all=True باشد، بدون در نظر گرفتن نوع تجهیزات اعمال می‌شود.
        در غیر این صورت، نوع تجهیزات درخواست باید با equipment_type کد مطابقت داشته باشد.
        """
        # این endpoint صرفاً «پیش‌نمایش» تخفیف در ویزارد رزرو است:
        # - مبلغ از server-side خوانده می‌شود (request_id اختیاری) تا کلاینت
        #   نتواند مبلغ دلخواه بفرستد.
        # - used_count تغییر نمی‌کند (شمارش فقط در اعمال واقعی انجام می‌شود).
        code = request.data.get('code')
        request_id = request.data.get('request_id')
        amount = request.data.get('amount', 0)
        equipment_type_id = request.data.get('equipment_type_id')  # اختیاری

        if not code:
            return Response({'error': 'کد تخفیف را وارد کنید.'},
                            status=status.HTTP_400_BAD_REQUEST)

        # مبلغ معتبر: از خود درخواست (در صورت ارسال request_id)
        equipment_type = None
        if request_id:
            try:
                inspection_request = InspectionRequest.objects.get(
                    id=request_id, customer=request.user)
            except InspectionRequest.DoesNotExist:
                return Response({'error': 'درخواست یافت نشد.'}, status=404)
            amount = inspection_request.final_price
            equipment_type = inspection_request.equipment_type
            equipment_type_id = equipment_type.id

        try:
            discount = DiscountCode.objects.get(code=code)
        except DiscountCode.DoesNotExist:
            return Response({'error': 'کد تخفیف نامعتبر است.'},
                            status=status.HTTP_400_BAD_REQUEST)

        from ..services.discount_service import (
            compute_discount_amount, validate_discount)
        error = validate_discount(
            discount, amount=amount,
            equipment_type=equipment_type,
            user=request.user)
        if error:
            return Response({'error': error}, status=400)

        discount_amount = compute_discount_amount(discount, amount)
        final_price = max(Decimal(str(amount)) - discount_amount, 0)

        return Response({
            'success': True,
            'discount_amount': discount_amount,
            'final_price': final_price,
            'code': discount.code,
            'preview': True,  # فقط پیش‌نمایش؛ اعمال نهایی از apply-discount
        })


# ============================================================
# CustomerDiscountCodeViewSet
# ============================================================
class CustomerDiscountCodeViewSet(viewsets.ReadOnlyModelViewSet):
    """
    لیست کدهای تخفیف فعال برای مشتریان (فقط خواندنی)
    """
    permission_classes = [IsAuthenticated]
    serializer_class = DiscountCodeSerializer

    def get_queryset(self):
        now = timezone.now()
        return DiscountCode.objects.filter(
            is_active=True,
            expires_at__gt=now,
        ).exclude(
            usage_limit=0
        ).order_by('expires_at')

# core/views/inspection_views.py
from .base_views import AllowAny, AuditLog, Decimal, DjangoFilterBackend, InspectionRequest, InspectionRequestFilter, InspectionRequestListSerializer, InspectionRequestSerializer, InspectionRequestUpdateSerializer, IsAdminOrHasObjectPermissionForInspectionRequest, IsAdminUserOrGroup, IsAuthenticated, OpenApiResponse, OrderingFilter, Payment, PaymentMethod, Response, ScopedRateThrottle, SearchFilter, User, UserCredit, action, assign_perm, extend_schema, extend_schema_view, is_admin_user, is_expert_user, logger, permission_classes, send_notification, serializers, timezone, transaction, viewsets


# ============================================================
# InspectionRequestViewSet با بهینه‌سازی کوئری
# ============================================================
@extend_schema_view(
    list=extend_schema(
        summary="لیست درخواست‌های بازرسی",
        description="دریافت لیست درخواست‌های کاربر فعلی (فقط احراز هویت‌شده)"
    ),
    create=extend_schema(
        summary="ایجاد درخواست بازرسی جدید",
        description="ایجاد درخواست بازرسی با اطلاعات دستگاه و آدرس (دسترسی عمومی برای ایجاد)",
        request=InspectionRequestSerializer,
        responses={201: InspectionRequestSerializer}
    ),
    retrieve=extend_schema(
        summary="دریافت جزئیات یک درخواست",
        description="دریافت اطلاعات کامل یک درخواست (فقط احراز هویت‌شده)"
    ),
    update=extend_schema(
        summary="بروزرسانی کامل درخواست",
        description="بروزرسانی همه فیلدهای درخواست (فقط ادمین)"
    ),
    partial_update=extend_schema(
        summary="بروزرسانی جزئی درخواست",
        description="بروزرسانی بخشی از فیلدهای درخواست (فقط ادمین)"
    ),
    destroy=extend_schema(
        summary="حذف درخواست",
        description="حذف یک درخواست (فقط ادمین)"
    ),
)
class InspectionRequestViewSet(viewsets.ModelViewSet):
    """
    مدیریت درخواست‌های بازرسی
    """
    permission_classes = [IsAuthenticated]
    serializer_class = InspectionRequestSerializer
    queryset = InspectionRequest.objects.all()
    filter_backends = [DjangoFilterBackend, SearchFilter, OrderingFilter]
    filterset_class = InspectionRequestFilter
    search_fields = ['brand_model', 'city', 'address', 'customer__username']
    ordering_fields = ['created_at', 'final_price', 'status']
    ordering = ['-created_at']

    def get_serializer_class(self):
        """
        CRITICAL-01: serializer بر اساس اکشن تفکیک می‌شود:
        - list   → InspectionRequestListSerializer (سبک)
        - update/partial_update → InspectionRequestUpdateSerializer که
          فیلدهای workflow (status/assigned_expert/request_number/مبالغ/...)
          را read-only می‌کند؛ تغییر وضعیت فقط از طریق actionهای مشخص.
        - بقیه   → InspectionRequestSerializer (create/retrieve)
        """
        if self.action == 'list':
            return InspectionRequestListSerializer
        if self.action in ('update', 'partial_update'):
            return InspectionRequestUpdateSerializer
        return InspectionRequestSerializer

    def get_permissions(self):
        if self.action == 'create':
            return [AllowAny()]
        elif self.action in ['list', 'retrieve']:
            return [IsAuthenticated()]
        elif self.action in ['update', 'partial_update', 'destroy']:
            return [IsAdminOrHasObjectPermissionForInspectionRequest()]
        return super().get_permissions()

    def get_throttles(self):
        # P1-06 (EDRA v8): create عمومی (anonymous) است؛ برای کاهش سوءاستفاده
        # (رشد DB/notification/storage) throttle سخت روی create اعمال می‌شود.
        if self.action == 'create':
            return [ScopedRateThrottle()]
        return super().get_throttles()

    throttle_scope = 'inspection_create'

    def get_queryset(self):
        user = self.request.user

        # ✅ کوئری پایه با select_related و prefetch_related
        base_queryset = InspectionRequest.objects.select_related(
            'customer',
            'equipment_type',
            'assigned_expert',
            'project',
            'discount_code').prefetch_related(
            'payments',
            'invoice')

        # ✅ برای لیست (اکشن list)، فقط فیلدهای ضروری را بارگذاری کن.
        # توجه: select_related شامل project و discount_code هم هست؛ اگر این
        # فیلدها در only() نیایند، Django خطای "cannot be both deferred and
        # traversed using select_related" می‌دهد و لیست با 500 می‌شکند.
        if self.action == 'list':
            base_queryset = base_queryset.only(
                'id', 'status', 'city', 'final_price', 'created_at',
                'brand_model', 'install_state', 'address',
                'customer__username', 'equipment_type__name_fa',
                'assigned_expert__username',
                'project__id', 'project__name',
                'discount_code__id', 'discount_code__code',
            )

        # EDRA v6 — P1 (نقش canonical): is_staff هم مثل گروه Admin کامل
        # دیده می‌شود (قبلاً staff بدون گروه Admin queryset مدیریتی نمی‌گرفت
        # ولی در بعضی actionها دسترسی داشت → ناسازگاری).
        if user.is_authenticated:
            if is_admin_user(user):
                return base_queryset
            elif is_expert_user(user):
                return base_queryset.filter(assigned_expert=user)
            else:
                return base_queryset.filter(customer=user)
        return InspectionRequest.objects.none()

    def perform_create(self, serializer):
        try:
            if self.request.user.is_authenticated:
                user = self.request.user
            else:
                # P0-10 (EDRA v9): اتصال anonymous به User موجود با شماره
                # تلفن دیگران (ownership hijack) حذف شد. کاربر مهمان همیشه
                # یک حساب یکتا با پسوند تصادفی می‌گیرد — هرگز به username
                # یک User موجود وصل نمی‌شود. (فرانت‌اند قبل از ثبت نهایی
                # OTP/login دارد؛ این مسیر فقط fallback امن است.)
                import secrets
                phone = (self.request.data.get('phone') or '').strip()
                suffix = secrets.token_hex(6)
                if phone:
                    user, _ = User.objects.get_or_create(
                        username=f'guest_{phone[:11]}_{suffix}',
                        defaults={'is_active': True})
                else:
                    user, _ = User.objects.get_or_create(
                        username=f'guest_{suffix}',
                        defaults={'is_active': True})

            equipment = serializer.validated_data.get('equipment_type')
            if not equipment:
                raise serializers.ValidationError(
                    {"equipment_type": "نوع تجهیزات الزامی است."})

            params = serializer.validated_data.get('params', {})
            install_state = serializer.validated_data.get('install_state')
            city = serializer.validated_data.get('city')
            brand_model = serializer.validated_data.get(
                'brand_model') or 'نامشخص'
            manufacture_year = serializer.validated_data.get(
                'manufacture_year') or 1400
            if params is None:
                params = {}

            # ✅ دریافت service_type از داده‌های درخواست (روش ۴)
            service_type = self.request.data.get('service_type', 'standard')
            params['service_type'] = service_type

            try:
                from pricing.utils import calculate_price_with_rounding_info
                # ✅ محاسبه قیمت با جزئیات رندینگ
                price_info = calculate_price_with_rounding_info(
                    equipment_type=equipment,
                    params=params,
                    install_state=install_state,
                    city_name=city,
                    service_type=service_type
                )
                final_price = price_info['rounded_total']
                exact_price = price_info['exact_total']
                rounding_discount = price_info['rounding_discount']
            except ImportError:
                # اگر تابع موجود نباشد، قیمت پیش‌فرض
                final_price = Decimal(1000000)
                exact_price = Decimal(1000000)
                rounding_discount = Decimal('0')

            # EDRA v5 — HIGH-11: قیمت‌ها را اینجا overwrite نمی‌کنیم.
            # serializer.create() قبلاً قیمت (با تخفیف) را محاسبه و ذخیره
            # کرده؛ بازنویسی آن باعث می‌شد discount.used_count افزایش یابد
            # ولی final_price بدون تخفیف بماند. فقط همین‌جا برای لاگ نگه
            # می‌داریم.
            instance = serializer.save(
                customer=user,
                status='pending_payment',
                brand_model=brand_model,
                manufacture_year=manufacture_year,
                params=params,
            )

            # ✅ ذخیره تخفیف رندینگ در لاگ محاسبه قیمت
            from pricing.models import PriceCalculationLog
            PriceCalculationLog.objects.create(
                inspection_request=instance,
                rule_version=instance.equipment_type.pricing_rule if hasattr(
                    instance.equipment_type, 'pricing_rule') else None,
                calculated_price=instance.final_price,  # HIGH-11: قیمت نهایی واقعی (با تخفیف)
                params_used={
                    **params,
                    'exact_price': float(exact_price),
                    'rounding_discount': float(rounding_discount),
                    'rounding_method': 'nearest_100000'
                },
                service_type=service_type,
                # P1 (EDRA v9): city_multiplier واقعی از محاسبه قیمت
                # (قبلاً ثابت ۱.۰ ذخیره می‌شد → لاگ قیمت نادرست)
                city_multiplier=price_info['components'].get(
                    'city_multiplier', Decimal('1.0')),
                install_state=install_state,
            )

            assign_perm('view_inspectionrequest', user, instance)
            assign_perm('change_inspectionrequest', user, instance)

            if instance.assigned_expert:
                assign_perm(
                    'view_inspectionrequest',
                    instance.assigned_expert,
                    instance)
                assign_perm(
                    'change_inspectionrequest',
                    instance.assigned_expert,
                    instance)

            try:
                send_notification(user, 'request_created', {
                    'request_id': instance.id,
                    'status': 'pending_payment'
                })
                # EDRA v11 (P1): تعریف canonical ادمین — is_staff یا گروه Admin
                from django.db.models import Q
                admins = User.objects.filter(
                    Q(is_staff=True) | Q(groups__name='Admin')).distinct()
                for admin in admins:
                    send_notification(admin, 'new_request_admin', {
                        'request_id': instance.id,
                        'customer': user.username
                    })
            except Exception as e:
                logger.error(f"Error sending notification: {e}")

        except Exception as e:
            logger.error(f"Error in perform_create: {e}")
            raise

    # ============================================================
    # سایر اکشن‌ها (assign_expert, change_status, credit_pay)
    # ============================================================
    @extend_schema(summary="تخصیص کارشناس به درخواست",
                   description="تخصیص یک کارشناس به درخواست (فقط ادمین)",
                   request={'application/json': {'type': 'object',
                                                 'properties': {'expert_id': {'type': 'integer',
                                                                              'description': 'شناسه کاربر کارشناس'}},
                                                 'required': ['expert_id']}},
                   responses={200: OpenApiResponse(description='کارشناس با موفقیت تخصیص داده شد'),
                              400: OpenApiResponse(description='خطا در درخواست'),
                              404: OpenApiResponse(description='کارشناس یافت نشد')})
    @action(detail=True, methods=['post'],
            permission_classes=[IsAdminUserOrGroup])
    def assign_expert(self, request, pk=None):
        instance = self.get_object()
        expert_id = request.data.get('expert_id')
        if not expert_id:
            return Response({'error': 'شناسه کارشناس الزامی است.'}, status=400)
        try:
            expert = User.objects.get(id=expert_id)
        except User.DoesNotExist:
            return Response({'error': 'کارشناس یافت نشد.'}, status=404)
        instance.assigned_expert = expert
        if instance.status == 'paid':
            instance.status = 'assigned'
        instance.save()

        # رویداد ممیزی تخصیص کارشناس (P1 بند ۴۰)
        try:
            from ..models import AuditLog
            AuditLog.objects.create(
                user=request.user,
                action='assign_expert',
                object_id=instance.id,
                changes={'expert_id': expert.id,
                         'request_id': instance.id})
        except Exception as log_error:
            logger.error(f"Error writing audit log: {log_error}")

        assign_perm('view_inspectionrequest', expert, instance)
        assign_perm('change_inspectionrequest', expert, instance)

        try:
            send_notification(expert, 'assigned_to_expert', {
                'request_id': instance.id,
                'customer': instance.customer.username
            })
        except Exception as e:
            logger.error(f"Error sending notification: {e}")
        return Response(
            {'message': f'کارشناس {expert.username} به این درخواست تخصیص داده شد.'})

    @extend_schema(
        summary="تغییر وضعیت درخواست",
        description="تغییر وضعیت درخواست (فقط ادمین)",
        request={
            'application/json': {
                'type': 'object',
                'properties': {
                    'status': {
                        'type': 'string',
                        'enum': [
                            'draft',
                            'pending_payment',
                            'waiting_manual_payment',
                            'paid',
                            'assigned',
                            'scheduled',
                            'rescheduled',
                            'in_progress',
                            'completed',
                            'cancelled',
                            'expired'],
                        'description': 'وضعیت جدید'}},
                'required': ['status']}},
        responses={
            200: OpenApiResponse(
                description='وضعیت با موفقیت تغییر یافت'),
            400: OpenApiResponse(
                description='وضعیت نامعتبر است')})
    @action(detail=True, methods=['post'],
            permission_classes=[IsAdminUserOrGroup])
    def change_status(self, request, pk=None):
        instance = self.get_object()
        new_status = request.data.get('status')
        if new_status not in dict(InspectionRequest.STATUS_CHOICES):
            return Response({'error': 'وضعیت نامعتبر است.'}, status=400)

        # P0-03: تغییر وضعیت فقط از طریق workflow مجاز (state machine).
        # هر transition باید هم actor و هم state قبلی/بعدی مجاز باشد تا
        # مسیرهای غیرمنتظره (مثلاً draft → completed یا paid → cancelled)
        # خارج از سرویس‌های پرداخت/بازرسی ممکن نباشند.
        from ..services.inspection_service import (
            can_transition, transition_error)

        old_status = instance.status
        if not can_transition(old_status, new_status):
            return Response(
                {'error': transition_error(old_status, new_status)},
                status=400)

        if new_status == 'paid' and old_status != 'paid':
            # فاکتور فقط از سرویس مرکزی (idempotent — FIN-01/FIN-02)
            from ..services.invoice_service import InvoiceSettlementService
            try:
                InvoiceSettlementService.settle(
                    instance, is_paid=False, paid_at=None,
                    user=instance.customer)
            except Exception as e:
                logger.error(f"Error creating invoice on status change: {e}")

        instance.status = new_status
        instance.save()

        try:
            from ..models import AuditLog
            AuditLog.objects.create(
                user=request.user,
                action='change_status',
                object_id=instance.id,
                changes={
                    'request_id': instance.id,
                    'old_status': old_status,
                    'new_status': new_status,
                })
        except Exception as log_error:
            logger.error(f"Error writing audit log: {log_error}")

        try:
            send_notification(instance.customer, 'status_changed', {
                'request_id': instance.id,
                'new_status': new_status
            })
        except Exception as e:
            logger.error(f"Error sending notification: {e}")

        return Response({'message': f'وضعیت به {new_status} تغییر یافت.'})

    @action(detail=True, methods=['post'], url_path='apply-discount',
            permission_classes=[IsAuthenticated])
    def apply_discount(self, request, pk=None):
        """
        اعمال کد تخفیف روی یک درخواست ساخته‌شده (فقط مالک، فقط pending_payment).

        POST /api/core/inspection-requests/{id}/apply-discount/  {"code": "T10"}
        - idempotent: کد تکراری → بدون تغییر و بدون شمارش دوباره.
        - تعویض کد → کد قبلی آزاد و کد جدید اعمال می‌شود.
        - مبلغ همیشه از calculated_price درخواست (server-side) محاسبه می‌شود.
        """
        from ..services.discount_service import (
            DiscountApplyError, apply_discount_to_request)

        try:
            inspection_request = InspectionRequest.objects.get(
                id=pk, customer=request.user)
        except InspectionRequest.DoesNotExist:
            return Response({'error': 'درخواست یافت نشد.'}, status=404)

        if inspection_request.status != 'pending_payment':
            return Response(
                {'error': 'در این وضعیت امکان تغییر تخفیف وجود ندارد.'}, status=400)

        code = request.data.get('code')
        if not code:
            return Response({'error': 'کد تخفیف را وارد کنید.'}, status=400)

        try:
            discount, discount_amount, new_final_price = \
                apply_discount_to_request(
                    inspection_request, code, user=request.user)
        except DiscountApplyError as e:
            return Response({'error': str(e)}, status=400)

        return Response({
            'success': True,
            'code': discount.code,
            'discount_amount': discount_amount,
            'final_price': new_final_price,
            'calculated_price': inspection_request.calculated_price,
            'message': f'تخفیف {discount_amount:,} تومان اعمال شد.',
        })

    @action(detail=False, methods=['post'],
            permission_classes=[IsAuthenticated])
    def credit_pay(self, request):
        """
        پرداخت با اعتبار شرکتی
        """
        request_id = request.data.get('request_id')
        if not request_id:
            return Response({'error': 'شناسه درخواست الزامی است.'}, status=400)

        try:
            inspection_request = InspectionRequest.objects.get(
                id=request_id, customer=request.user)
        except InspectionRequest.DoesNotExist:
            return Response({'error': 'درخواست یافت نشد.'}, status=404)

        if inspection_request.status != 'pending_payment':
            return Response(
                {'error': 'این درخواست در وضعیت قابل پرداخت نیست.'}, status=400)

        try:
            credit = UserCredit.objects.get(user=request.user)
        except UserCredit.DoesNotExist:
            return Response({'error': 'شما اعتبار شرکتی ندارید.'}, status=400)

        if credit.balance < inspection_request.final_price:
            return Response({
                'error': f'اعتبار کافی نیست. موجودی: {credit.balance:,} تومان'
            }, status=400)

        from ..services.credit_service import CreditService
        from ..services.invoice_service import InvoiceSettlementService

        # مبلغ از snapshot فاکتور (پس از تخفیف + مالیات) — P0-6
        snap = InvoiceSettlementService.payment_snapshot(
            inspection_request, credit_amount=inspection_request.final_price)

        with transaction.atomic():
            # رزرو + مصرف اتمیک (FIN-04)
            reservation = CreditService.reserve(
                request.user, snap['amount'],
                inspection_request=inspection_request)
            payment_method, _ = PaymentMethod.objects.get_or_create(
                name='credit', defaults={'is_active': True})
            payment = Payment.objects.create(
                inspection_request=inspection_request,
                amount=snap['amount'],
                amount_rial=snap['amount_rial'],
                credit_amount=snap['amount'],
                online_amount=0,
                method=payment_method,
                status='paid',
                verified_at=timezone.now(),
            )
            reservation.payment = payment
            reservation.save(update_fields=['payment'])
            CreditService.consume(reservation, description=(
                f'پرداخت هزینه بازرسی درخواست #{inspection_request.id}'))
            inspection_request.status = 'paid'
            inspection_request.save(update_fields=['status'])

        # فاکتور از سرویس مرکزی (idempotent)
        InvoiceSettlementService.settle(
            inspection_request, payment=payment,
            is_paid=True, paid_at=timezone.now(), user=request.user)

        credit = UserCredit.objects.get(user=request.user)
        try:
            send_notification(request.user, 'payment_successful', {
                'request_id': inspection_request.id,
                'amount': str(inspection_request.final_price),
                'method': 'credit'
            })
        except Exception as e:
            logger.error(f"Error sending notification: {e}")

        return Response({
            'success': True,
            'message': f'پرداخت با اعتبار انجام شد. موجودی جدید: {credit.balance:,} تومان',
            'new_balance': credit.balance
        })

# core/views/notification_views.py
from .base_views import IsAuthenticated, NotificationLog, NotificationLogSerializer, Response, action, permission_classes, status, viewsets


# ============================================================
# NotificationViewSet
# ============================================================
class NotificationViewSet(viewsets.ReadOnlyModelViewSet):
    permission_classes = [IsAuthenticated]
    serializer_class = NotificationLogSerializer

    def get_queryset(self):
        from notifications.models import NotificationLog
        return NotificationLog.objects.filter(
            user=self.request.user).order_by('-created_at')

    @action(detail=True, methods=['post'])
    def mark_read(self, request, pk=None):
        notification = self.get_object()
        if notification.user != request.user:
            return Response({'error': 'دسترسی غیرمجاز'},
                            status=status.HTTP_403_FORBIDDEN)
        notification.status = 'read'
        notification.save()
        return Response({'success': True})

    @action(detail=False, methods=['post'])
    def mark_all_read(self, request):
        from notifications.models import NotificationLog
        NotificationLog.objects.filter(
            user=request.user,
            status='pending').update(
            status='read')
        return Response({'success': True})

# core/views/payment_views.py
from .base_views import AllowAny, AuditLog, CreditReservation, CreditTransaction, DjangoFilterBackend, InspectionRequest, Invoice, InvoiceFilter, InvoiceSerializer, IsAdminUserOrGroup, IsAuthenticated, OrderingFilter, Payment, PaymentFilter, PaymentMethod, PaymentMethodSerializer, PaymentSerializer, Refund, Response, ScopedRateThrottle, SearchFilter, UserCredit, action, api_view, generate_invoice_pdf_task, logger, permission_classes, send_notification, status, throttle_classes, timezone, transaction, viewsets
from ..services.payment_service import ZarinpalService
from ..services.money import toman_to_rial
from django.shortcuts import redirect
from django.http import HttpResponse
from django.conf import settings


# ============================================================
# refund_payment (فلوی عودت — Phase 2 از گزارش ممیزی)
# ============================================================
@api_view(['POST'])
@permission_classes([IsAdminUserOrGroup])
def refund_payment(request, payment_id):
    """
    عودت پرداخت توسط ادمین (idempotent) — P0-7 از گزارش V3:
    شامل: مبلغ ریالی، علت، کاربر انجام‌دهنده، زمان، reference درگاه،
    reversal ledger entry و audit.
    - فقط پرداخت با status='paid' قابل عودت است.
    - سهم اعتباری (credit_amount) بلافاصله به موجودی کاربر برمی‌گردد.
    - سهم آنلاین (online_amount) باید از طریق درگاه (دستی) عودت شود؛
      در دفتر کل به‌عنوان refund ثبت و در گزارش مالی منعکس می‌شود.
    """
    from ..services.ledger_service import record_refund
    from ..models import Refund
    from ..services.payment_service import ZarinpalService

    reason = (request.data.get('reason') or '').strip() or 'درخواست ادمین'
    gateway_ref = (request.data.get('gateway_ref') or '').strip()

    # ============================================================
    # EDRA v11 (P1): فراخوانی درگاه (external side-effect) هرگز داخل
    # transaction دیتابیس اجرا نمی‌شود. سه فاز:
    #   ۱) atomic: قفل + ثبت Refund(requested) + بازگشت سهم اعتبار
    #   ۲) خارج از تراکنش: فراخوانی درگاه (بدون lock دیتابیس)
    #   ۳) atomic: ثبت نتیجه درگاه + نهایی‌سازی/خطا
    # این کار ریسک «Gateway=refunded ولی DB=not» را حذف می‌کند.
    # ============================================================
    # فاز ۱ — ثبت عودت (commit می‌شود؛ Refund همیشه قابل رهگیری است)
    with transaction.atomic():
        try:
            payment = Payment.objects.select_for_update().get(id=payment_id)
        except Payment.DoesNotExist:
            return Response({'error': 'پرداخت یافت نشد.'}, status=404)

        if payment.status != 'paid':
            return Response(
                {'error': 'فقط پرداخت‌های موفق قابل عودت هستند.'}, status=400)

        # P0 (EDRA v10): جلوگیری از عودت تکراری
        if payment.refunds.filter(
                status__in=['requested', 'gateway_processing',
                            'gateway_refunded', 'completed']).exists():
            return Response(
                {'error': 'برای این پرداخت قبلاً عودت ثبت شده است.'}, status=400)

        user = payment.inspection_request.customer
        gateway_ref = gateway_ref or payment.ref_id or payment.authority or ''

        refund = Refund.objects.create(
            payment=payment,
            inspection_request=payment.inspection_request,
            customer=user,
            invoice=payment.inspection_request.invoice if hasattr(
                payment.inspection_request, 'invoice') else None,
            amount_toman=payment.amount,
            amount_rial=payment.amount_rial or 0,
            credit_amount=payment.credit_amount or 0,
            online_amount=payment.online_amount or 0,
            reason=reason,
            requested_by=request.user,
            status='requested',
        )

        # سهم اعتباری: بازگشت واقعی به موجودی (حرکت پول واقعی)
        if payment.credit_amount and payment.credit_amount > 0:
            credit, _ = UserCredit.objects.select_for_update().get_or_create(
                user=user)
            credit.balance += payment.credit_amount
            credit.save(update_fields=['balance'])
            CreditTransaction.objects.create(
                user=user,
                amount=payment.credit_amount,
                transaction_type='refund',
                description=(
                    f'عودت سهم اعتباری پرداخت #{payment.id} بابت درخواست '
                    f'#{payment.inspection_request_id} — {reason}'),
                balance_after=credit.balance,
                reference_id=str(payment.id))

    # فاز ۲ — فراخوانی درگاه (خارج از هر transaction)
    online_refunded = False
    if payment.online_amount and payment.online_amount > 0:
        with transaction.atomic():
            refund.status = 'gateway_processing'
            refund.save(update_fields=['status'])
        result = ZarinpalService.refund_payment(
            authority=payment.authority or '',
            ref_id=payment.ref_id or '',
            amount_rial=payment.online_amount * 10)  # تومان → ریال
        # فاز ۳ — ثبت نتیجه درگاه
        with transaction.atomic():
            if result['success']:
                refund.status = 'gateway_refunded'
                refund.gateway_reference = result.get('reference') or ''
                refund.gateway_status = result.get('gateway_status', '')
                refund.processed_at = timezone.now()
                refund.save(update_fields=[
                    'status', 'gateway_reference', 'gateway_status',
                    'processed_at'])
                online_refunded = True
            else:
                refund.status = 'gateway_failed'
                refund.failure_reason = result.get('error') or 'خطای درگاه'
                refund.processed_at = timezone.now()
                refund.save(update_fields=[
                    'status', 'failure_reason', 'processed_at'])
                # سهم اعتبار قبلاً برگشت؛ خطای درگاه نباید پنهان بماند
                return Response({
                    'error': (
                        'سهم اعتبار به موجودی مشتری برگشت، اما عودت وجه '
                        'آنلاین در درگاه ناموفق بود و باید دستی پیگیری شود.'),
                    'refund_id': refund.id,
                    'failure_reason': refund.failure_reason,
                    'payment_status': payment.status,
                }, status=502)

    # فاز ۳ — نهایی‌سازی (فقط وقتی همه سهم‌ها واقعاً برگشتند)
    if (not payment.online_amount or online_refunded):
        with transaction.atomic():
            refund.status = 'completed'
            refund.approved_by = request.user
            refund.completed_at = timezone.now()
            refund.save(update_fields=['status', 'approved_by', 'completed_at'])

            payment.status = 'refunded'
            payment.save(update_fields=['status'])

            # reversal ledger entry (immutable) با علت/انجام‌دهنده/مرجع
            record_refund(
                payment, performed_by=request.user,
                reason=reason, gateway_ref=gateway_ref,
                refund=refund)

    try:
        from ..models import AuditLog
        AuditLog.objects.create(
            user=request.user,
            action='refund_payment',
            object_id=payment.id,
            changes={
                'payment_id': payment.id,
                'amount_rial': str(payment.amount_rial),
                'reason': reason,
                'gateway_ref': gateway_ref,
                'request_id': payment.inspection_request_id,
            })
    except Exception as log_error:
        logger.error(f"Error writing audit log: {log_error}")

    try:
        send_notification(user, 'payment_refunded', {
            'payment_id': payment.id,
            'amount': str(payment.credit_amount or 0),
            'request_id': payment.inspection_request_id,
            'reason': reason,
        })
    except Exception as notif_error:
        logger.error(f"Error sending refund notification: {notif_error}")

    return Response({
        'success': True,
        'message': 'پرداخت عودت داده شد. سهم اعتباری به موجودی کاربر بازگشت.',
        'refunded_credit': str(payment.credit_amount or 0),
        'refunded_rial': str(payment.amount_rial or 0),
        'reason': reason,
        'status': 'refunded',
    })


# ============================================================
# payment_receipt (محافظت از فیش بانکی — FILE-01/08)
# ============================================================
@api_view(['GET'])
@permission_classes([IsAuthenticated])
def payment_receipt(request, payment_id):
    """
    دریافت فایل فیش بانکی یک پرداخت — فقط مالک درخواست یا ادمین.
    فیش فقط از این endpoint خوانده می‌شود (فرانت از /api/download/... با
    توکن JWT استفاده می‌کند)، نه URL مستقیم media.
    """
    try:
        payment = Payment.objects.select_related(
            'inspection_request__customer').get(id=payment_id)
    except Payment.DoesNotExist:
        return Response({'error': 'پرداخت یافت نشد.'}, status=404)

    user = request.user
    is_admin = user.is_staff or user.groups.filter(name='Admin').exists()
    if not is_admin and payment.inspection_request.customer != user:
        return Response({'error': 'شما دسترسی به این فیش ندارید.'}, status=403)

    if not payment.bank_receipt:
        return Response(
            {'error': 'فیش بانکی برای این پرداخت ثبت نشده است.'}, status=404)

    try:
        from django.http import FileResponse

        # MEDIUM-15: Content-Type از magic bytes واقعی فایل تشخیص داده می‌شود،
        # نه فقط extension — قبلاً هر چیز غیر از .pdf به‌اشتباه image/jpeg
        # معرفی می‌شد (PNG/WebP/فایل نامعتبر رفتار نادرست داشت).
        head = payment.bank_receipt.open('rb').read(16)
        payment.bank_receipt.seek(0)
        if head.startswith(b'%PDF'):
            content_type = 'application/pdf'
        elif head.startswith(b'\x89PNG\r\n\x1a\n'):
            content_type = 'image/png'
        elif head[:3] == b'\xff\xd8\xff':
            content_type = 'image/jpeg'
        elif head[:4] == b'RIFF' and head[8:12] == b'WEBP':
            content_type = 'image/webp'
        else:
            # فرمت ناشناخته/نامعتبر — به‌جای حدس اشتباه، خطا بده
            return Response(
                {'error': 'فرمت فایل فیش نامعتبر است.'}, status=415)

        return FileResponse(
            payment.bank_receipt.open('rb'), content_type=content_type)
    except Exception as e:
        logger.error(f"Error streaming receipt {payment.id}: {e}")
        return Response({'error': 'خطا در خواندن فایل فیش.'}, status=500)


# ============================================================
# PaymentMethodViewSet
# ============================================================
class PaymentMethodViewSet(viewsets.ReadOnlyModelViewSet):
    queryset = PaymentMethod.objects.filter(is_active=True)
    serializer_class = PaymentMethodSerializer
    permission_classes = [AllowAny]


# ============================================================
# PaymentViewSet
# ============================================================
class PaymentViewSet(viewsets.ReadOnlyModelViewSet):
    """
    پرداخت‌ها فقط خواندنی هستند (SEC-01): تغییرات وضعیت/مبلغ صرفاً از
    طریق اکشن‌های server-side (callback، verify، reject) انجام می‌شود.
    """
    serializer_class = PaymentSerializer
    permission_classes = [IsAuthenticated]
    filter_backends = [DjangoFilterBackend, SearchFilter, OrderingFilter]
    filterset_class = PaymentFilter
    search_fields = ['inspection_request__id', 'authority', 'ref_id']
    ordering_fields = ['created_at', 'amount', 'status']
    ordering = ['-created_at']

    def get_queryset(self):
        user = self.request.user
        qs = Payment.objects.select_related(
            'inspection_request', 'inspection_request__customer', 'method')
        # ادمین همه را می‌بیند (مدیریت پرداخت‌ها)؛ مشتری فقط پرداخت‌های خودش
        if user.groups.filter(name='Admin').exists() or user.is_staff:
            return qs
        return qs.filter(inspection_request__customer=user)


# ============================================================
# InvoiceViewSet
# ============================================================
class InvoiceViewSet(viewsets.ReadOnlyModelViewSet):
    @action(detail=True, methods=['get'])
    def pdf(self, request, pk=None):
        """
        دانلود محافظتشده PDF فاکتور (P0-8): مالک درخواست یا ادمین.
        get_object از queryset محدودشده استفاده می‌کند → 404 برای غیرمجاز.
        """
        from django.http import FileResponse
        invoice = self.get_object()
        if not invoice.pdf_file:
            return Response(
                {'error': 'PDF فاکتور هنوز تولید نشده است.'}, status=404)
        return FileResponse(
            invoice.pdf_file.open('rb'),
            content_type='application/pdf',
            filename=f'{invoice.invoice_number}.pdf')
    serializer_class = InvoiceSerializer
    permission_classes = [IsAuthenticated]
    filter_backends = [DjangoFilterBackend, SearchFilter, OrderingFilter]
    filterset_class = InvoiceFilter
    search_fields = ['invoice_number', 'inspection_request__id']
    ordering_fields = ['issue_date', 'final_amount', 'due_date']
    ordering = ['-issue_date']

    def get_queryset(self):
        user = self.request.user
        qs = Invoice.objects.select_related(
            'inspection_request',
            'inspection_request__customer',
            'inspection_request__equipment_type')
        # ادمین همه فاکتورها را می‌بیند؛ مشتری فقط فاکتورهای خودش (SEC-01)
        if user.groups.filter(name='Admin').exists() or user.is_staff:
            return qs
        return qs.filter(inspection_request__customer=user)

    @action(detail=True, methods=['post'],
            permission_classes=[IsAuthenticated])
    def retry_pdf(self, request, pk=None):
        invoice = self.get_object()

        if invoice.inspection_request.customer != request.user and not request.user.is_staff:
            return Response(
                {'error': 'شما دسترسی به این فاکتور ندارید.'}, status=status.HTTP_403_FORBIDDEN)

        if invoice.status != 'failed' and invoice.pdf_file:
            return Response({'error': 'فاکتور قبلاً تولید شده است.'},
                            status=status.HTTP_400_BAD_REQUEST)

        if invoice.retry_count >= 3:
            return Response(
                {
                    'error': 'تعداد تلاش مجدد بیش از حد مجاز است. لطفاً با پشتیبانی تماس بگیرید.'},
                status=status.HTTP_400_BAD_REQUEST)

        generate_invoice_pdf_task.delay(invoice.id, request.user.id)

        return Response({
            'message': 'تولید PDF فاکتور در صف قرار گرفت. پس از اتمام به شما اطلاع داده می‌شود.',
            'invoice_id': invoice.id,
            'status': 'queued'
        }, status=status.HTTP_202_ACCEPTED)


# ============================================================
# initiate_payment
# ============================================================
@api_view(['POST'])
@permission_classes([IsAuthenticated])
@throttle_classes([ScopedRateThrottle])
def initiate_payment(request):
    """
    شروع فرآیند پرداخت برای یک درخواست (idempotent — FIN-05)

    بدنه (اختیاری):
      request_id   : شناسه درخواست بازرسی
      credit_amount: مبلغ اعتباری که کاربر می‌خواهد از اعتبار خود کم کند
                     (رزرو اتمیک؛ در شکست درگاه آزاد می‌شود — FIN-04)

    مبلغ درگاه همیشه server-side از final_price درخواست محاسبه می‌شود.
    """
    request_id = request.data.get('request_id')
    if not request_id:
        return Response({'error': 'شناسه درخواست الزامی است.'}, status=400)

    try:
        inspection_request = InspectionRequest.objects.get(
            id=request_id, customer=request.user)
    except InspectionRequest.DoesNotExist:
        return Response({'error': 'درخواست یافت نشد.'}, status=404)

    if inspection_request.status not in (
            'pending_payment', 'waiting_manual_payment'):
        return Response(
            {'error': 'این درخواست در وضعیت قابل پرداخت نیست.'}, status=400)

    from decimal import Decimal
    from ..services.credit_service import CreditService, InsufficientCreditError
    from ..services.invoice_service import InvoiceSettlementService

    # --- مبالغ پرداخت فقط از snapshot فاکتور (تخفیف+مالیات؛ server-side) ---
    credit_amount = request.data.get('credit_amount') or 0
    snap = InvoiceSettlementService.payment_snapshot(
        inspection_request, credit_amount=credit_amount)
    amount = snap['amount']
    amount_rial = snap['amount_rial']
    credit_amount = snap['credit_amount']
    online_amount = snap['online_amount']
    online_rial = snap['online_rial']

    # --- پرداخت ترکیبی: رزرو اتمیک اعتبار ---
    # P0-02 (EDRA v9): قبل از رزرو جدید، همه رزروهای فعال قبلی همین
    # درخواست (از initiate های همزمان/ناقص) آزاد می‌شوند تا هرگز دو
    # Reservation همزمان برای یک پرداخت وجود نداشته باشد (قبلاً چند
    # request همزمان چند رزرو می‌ساخت و consume_for_payment همه را
    # مصرف می‌کرد → debit اضافه).
    reserved = None
    if credit_amount > 0:
        from ..models import CreditReservation
        with transaction.atomic():
            stale = CreditReservation.objects.filter(
                inspection_request=inspection_request,
                status='reserved')
            for r in stale:
                CreditService.release(
                    r, reason='superseded by new payment initiate')
        try:
            reserved = CreditService.reserve(
                request.user, credit_amount,
                inspection_request=inspection_request)
        except InsufficientCreditError as e:
            return Response({'error': str(e)}, status=400)

    description = f'پرداخت هزینه بازرسی - درخواست #{inspection_request.id}'
    callback_url = request.build_absolute_uri('/api/core/payment/callback/')

    # EDRA v13 — P1 #9: پرداخت تمام‌اعتباری (online_amount == 0) نباید به
    # درگاه ارسال شود — درخواست ۰ ریالی به زرین‌پال خطا/رفتار غلط دارد.
    full_credit = online_rial <= 0

    if full_credit:
        # بدون درگاه: Payment با status=paid ایجاد و بلافاصله تسویه می‌شود
        # (consume اعتبار + فاکتور + ledger — همان مسیر canonical callback)
        from ..services.invoice_service import InvoiceSettlementService
        method, _ = PaymentMethod.objects.get_or_create(
            name='credit', defaults={'is_active': True})
        payment, _ = Payment.objects.get_or_create(
            inspection_request=inspection_request,
            status='paid',
            method=method,
            defaults={
                'amount': amount,
                'amount_rial': amount_rial,
                'credit_amount': credit_amount,
                'online_amount': 0,
                'verified_at': timezone.now(),
            })
        if reserved is not None:
            reserved.payment = payment
            reserved.save(update_fields=['payment'])
        with transaction.atomic():
            if credit_amount:
                CreditService.consume_for_payment(payment)
            InvoiceSettlementService.settle(
                inspection_request, payment=payment,
                is_paid=True, paid_at=payment.verified_at,
                user=inspection_request.customer)
        inspection_request.status = 'paid'
        inspection_request.save(update_fields=['status'])
        return Response({
            'payment_url': None,
            'authority': '',
            'online_amount': '0',
            'credit_amount': str(credit_amount or 0),
            'status': 'paid',
            'message': 'پرداخت با اعتبار انجام شد.',
        })

    # مبلغ درگاه = فقط سهم آنلاین (به ریال)
    result = ZarinpalService.create_payment(
        int(online_rial), description, callback_url, {
            'mobile': request.user.username,
            'email': request.user.email or '',
        })

    if not result['success']:
        # آزادسازی رزرو در شکست initiation
        if reserved is not None:
            CreditService.release(
                reserved, reason='zarinpal initiation failed')
        return Response({'error': result['error']}, status=500)

    # یک Payment pending برای هر درخواست (idempotent)؛ authority جدید جایگزین می‌شود
    method, _ = PaymentMethod.objects.get_or_create(
        name='online', defaults={'is_active': True})
    payment, created = Payment.objects.get_or_create(
        inspection_request=inspection_request,
        status='pending',
        method=method,
        defaults={
            'amount': amount,
            'amount_rial': amount_rial,
            'credit_amount': credit_amount,
            'online_amount': online_amount,
            'authority': result['authority'],
        })
    if not created:
        payment.authority = result['authority']
        payment.amount_rial = amount_rial
        payment.amount = amount
        payment.credit_amount = credit_amount
        payment.online_amount = online_amount
        payment.save(update_fields=[
            'authority', 'amount_rial', 'amount',
            'credit_amount', 'online_amount'])

    # اتصال رزرو به پرداخت
    if reserved is not None:
        reserved.payment = payment
        reserved.save(update_fields=['payment'])

    return Response({
        'payment_url': result['payment_url'],
        'authority': result['authority'],
        'online_amount': str(online_amount),
        'credit_amount': str(credit_amount or 0),
    })


# ============================================================
# payment_callback
# ============================================================
@api_view(['GET'])
@permission_classes([AllowAny])
@throttle_classes([ScopedRateThrottle])
def payment_callback(request):
    """
    بازگشت از درگاه پرداخت (idempotent — FIN-05)

    - authority ناشناخته → 404
    - callback تکراری (قبلاً paid) → redirect success (بدون عملیات مجدد)
    - موفق → consume رزروهای اعتبار + فاکتور از طریق سیگنال/سرویس مرکزی
    - ناموفق/انصراف → release رزروهای اعتبار + redirect مربوطه
    """
    from ..services.credit_service import CreditService
    from ..services.invoice_service import InvoiceSettlementService

    authority = request.GET.get('Authority')
    status_param = request.GET.get('Status')

    if not authority:
        return HttpResponse('Authority یافت نشد.', status=400)

    try:
        payment = Payment.objects.get(authority=authority)
    except Payment.DoesNotExist:
        return HttpResponse('پرداخت یافت نشد.', status=404)

    inspection_request = payment.inspection_request

    # --- idempotent: callback تکراری ---
    if payment.status == 'paid':
        return redirect(
            f'{settings.FRONTEND_URL}/payment/success?ref_id={payment.ref_id or ""}')

    if status_param != 'OK':
        # انصراف کاربر از درگاه → آزادسازی اعتبار رزروشده
        if payment.status == 'pending':
            payment.status = 'cancelled'
            payment.save(update_fields=['status'])
        CreditService.release_for_payment(payment)
        return redirect(f'{settings.FRONTEND_URL}/payment/canceled')

    # مبلغ مورد انتظار درگاه = فقط سهم آنلاین (به ریال) — source of truth
    expected_amount_rial = (
        toman_to_rial(payment.online_amount)
        if payment.online_amount
        else (payment.amount_rial or toman_to_rial(payment.amount)))
    result = ZarinpalService.verify_payment(
        authority, int(expected_amount_rial))

    if result['success']:
        # P1-01 (EDRA v8): کل settlement (paid + consume اعتبار + فاکتور +
        # ledger) داخل یک transaction واحد انجام می‌شود تا شکست هر مرحله
        # کل تسویه را rollback کند و سیستم مالی هرگز نیمه‌تسویه نماند.
        # (verify درگاه خارج از تراکنش است چون فراخوانی external است.)
        with transaction.atomic():
            # قفل ردیف برای جلوگیری از race در callback همزمان
            payment = Payment.objects.select_for_update().get(
                id=payment.id)
            if payment.status == 'paid':
                # race: callback دیگر همین پرداخت را نهایی کرده
                return redirect(
                    f'{settings.FRONTEND_URL}/payment/success?ref_id={payment.ref_id or ""}')

            payment.status = 'paid'
            payment.ref_id = result['ref_id']
            payment.verified_at = timezone.now()
            payment.save(update_fields=[
                'status', 'ref_id', 'verified_at'])

            inspection_request.status = 'paid'
            inspection_request.save(update_fields=['status'])

            # مصرف رزروهای اعتبار (همان تراکنش — شکست = rollback کل)
            if payment.credit_amount:
                CreditService.consume_for_payment(payment)

            # فاکتور فقط از طریق سرویس مرکزی (idempotent — همان تراکنش)
            InvoiceSettlementService.settle(
                inspection_request, payment=payment,
                is_paid=True, paid_at=timezone.now(),
                user=inspection_request.customer)

        try:
            send_notification(inspection_request.customer, 'payment_successful', {
                'request_id': inspection_request.id,
                'ref_id': result['ref_id'],
                'amount': str(payment.amount),
            })
        except Exception as notif_error:
            logger.error(f"Error sending notification: {notif_error}")

        return redirect(
            f'{settings.FRONTEND_URL}/payment/success?ref_id={result["ref_id"]}')
    else:
        # verify ناموفق → آزادسازی اعتبار رزروشده
        if payment.status == 'pending':
            payment.status = 'failed'
            payment.save(update_fields=['status'])
        CreditService.release_for_payment(payment)
        return redirect(f'{settings.FRONTEND_URL}/payment/failed')

# scope های throttle (P1 بند ۴۳)
initiate_payment.throttle_scope = 'payment_initiate'
payment_callback.throttle_scope = 'payment_callback'

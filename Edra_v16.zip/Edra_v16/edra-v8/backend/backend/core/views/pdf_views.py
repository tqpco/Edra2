# core/views/pdf_views.py

from django.http import HttpResponse
from django.shortcuts import get_object_or_404
from django.contrib.auth import get_user_model
from rest_framework_simplejwt.authentication import JWTAuthentication
from rest_framework.exceptions import AuthenticationFailed
from ..models import InspectionReport, Invoice


# ============================================================
# generate_report_pdf
# ============================================================
def generate_report_pdf(request, report_id):
    # EDRA v12 — P1-01: قبول Bearer در query-string حذف شد — توکن هرگز
    # در URL قرار نمی‌گیرد (ریسک لو رفتن در log/proxy/history). فقط
    # Authorization Bearer یا کوکی پذیرفته می‌شود.
    auth = JWTAuthentication()
    try:
        user_auth = auth.authenticate(request)
        if user_auth is None:
            return HttpResponse('احراز هویت لازم است.', status=401)
        request.user = user_auth[0]
    except AuthenticationFailed:
        return HttpResponse('توکن نامعتبر یا منقضی شده است.', status=401)

    report = get_object_or_404(InspectionReport, id=report_id)
    inspection_request = report.inspection_request

    if request.user != inspection_request.customer and not request.user.is_staff:
        return HttpResponse(
            'دسترسی غیرمجاز. شما مالک این گزارش نیستید.',
            status=403)

    if not report.pdf_file:
        return HttpResponse(
            'PDF هنوز تولید نشده است. لطفاً بعداً مراجعه کنید.',
            status=404)

    response = HttpResponse(report.pdf_file, content_type='application/pdf')
    response['Content-Disposition'] = f'attachment; filename="گزارش_{
        report.report_number}.pdf"'
    return response


# ============================================================
# generate_invoice_pdf
# ============================================================
def generate_invoice_pdf(request, invoice_id):
    # EDRA v12 — P1-01: فقط Authorization Bearer/کوکی — بدون توکن در query
    auth = JWTAuthentication()
    try:
        user_auth = auth.authenticate(request)
        if user_auth is None:
            return HttpResponse('احراز هویت لازم است.', status=401)
        request.user = user_auth[0]
    except AuthenticationFailed:
        return HttpResponse('توکن نامعتبر یا منقضی شده است.', status=401)

    invoice = get_object_or_404(Invoice, id=invoice_id)
    inspection_request = invoice.inspection_request

    if request.user != inspection_request.customer and not request.user.is_staff:
        return HttpResponse('دسترسی غیرمجاز', status=403)

    if not invoice.pdf_file:
        return HttpResponse(
            'PDF هنوز تولید نشده است. لطفاً بعداً مراجعه کنید.',
            status=404)

    response = HttpResponse(invoice.pdf_file, content_type='application/pdf')
    response['Content-Disposition'] = f'attachment; filename="فاکتور_{
        invoice.invoice_number}.pdf"'
    return response

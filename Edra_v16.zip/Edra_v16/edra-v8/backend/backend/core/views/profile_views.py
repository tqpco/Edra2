# core/views/profile_views.py
from .base_views import APIView, IsAuthenticated, Response, UserCredit, UserProfile, permission_classes


def _get_or_create_profile(user):
    profile, _ = UserProfile.objects.get_or_create(user=user)
    return profile


# ============================================================
# ExpertProfileView
# ============================================================
class ExpertProfileView(APIView):
    """
    دریافت و بروزرسانی اطلاعات پروفایل کارشناس

    نکته اصلاح‌شده: قبلاً این ویو مستقیماً از user.phone / user.bio و
    مشابه می‌خواند/می‌نوشت که هیچ‌کدام روی مدل User وجود نداشتند (فقط
    روی UserProfile مرتبط) - یعنی خواندن همیشه مقدار خالی برمی‌گرداند و
    نوشتن (save) هیچ اثری در دیتابیس نداشت چون این‌ها attribute های
    موقت پایتون بودند نه فیلد واقعی مدل.
    """
    permission_classes = [IsAuthenticated]

    def get(self, request):
        user = request.user
        profile = _get_or_create_profile(user)
        return Response({
            'id': user.id,
            'username': user.username,
            'first_name': user.first_name,
            'last_name': user.last_name,
            'full_name': user.get_full_name() or user.username,
            'email': user.email,
            'phone': profile.phone,
            'bio': profile.bio,
            'expertise': profile.expertise,
            'years_experience': profile.years_experience,
        })

    def put(self, request):
        user = request.user
        profile = _get_or_create_profile(user)
        data = request.data

        if 'first_name' in data:
            user.first_name = data['first_name']
        if 'last_name' in data:
            user.last_name = data['last_name']
        if 'email' in data:
            user.email = data['email']
        user.save()

        if 'phone' in data:
            profile.phone = data['phone']
        if 'bio' in data:
            profile.bio = data['bio']
        if 'expertise' in data:
            profile.expertise = data['expertise']
        if 'years_experience' in data:
            profile.years_experience = data['years_experience'] or None
        profile.save()

        return Response({'success': True,
                         'message': 'اطلاعات با موفقیت بروزرسانی شد'})


# ============================================================
# CustomerProfileView
# ============================================================
class CustomerProfileView(APIView):
    """
    دریافت و بروزرسانی اطلاعات پروفایل مشتری (همان اصلاح بالا)
    """
    permission_classes = [IsAuthenticated]

    def get(self, request):
        user = request.user
        profile = _get_or_create_profile(user)
        try:
            credit = UserCredit.objects.get(user=user)
            balance = credit.balance
        except UserCredit.DoesNotExist:
            balance = 0

        return Response({
            'id': user.id,
            'username': user.username,
            'first_name': user.first_name,
            'last_name': user.last_name,
            'full_name': user.get_full_name() or user.username,
            'email': user.email,
            'phone': profile.phone,
            'company_name': profile.company_name,
            'registration_number': profile.registration_number,
            'credit': balance,
        })

    def put(self, request):
        user = request.user
        profile = _get_or_create_profile(user)
        data = request.data

        if 'first_name' in data:
            user.first_name = data['first_name']
        if 'last_name' in data:
            user.last_name = data['last_name']
        if 'email' in data:
            user.email = data['email']
        user.save()

        if 'phone' in data:
            profile.phone = data['phone']
        if 'company_name' in data:
            profile.company_name = data['company_name']
        if 'registration_number' in data:
            profile.registration_number = data['registration_number']
        profile.save()

        return Response({'success': True,
                         'message': 'اطلاعات با موفقیت بروزرسانی شد'})


# ============================================================
# CustomerCreditView
# ============================================================
class CustomerCreditView(APIView):
    """
    دریافت اعتبار مشتری
    """
    permission_classes = [IsAuthenticated]

    def get(self, request):
        try:
            credit = UserCredit.objects.get(user=request.user)
            return Response({'balance': credit.balance})
        except UserCredit.DoesNotExist:
            return Response({'balance': 0})

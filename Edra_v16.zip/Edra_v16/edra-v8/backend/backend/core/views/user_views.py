# core/views/user_views.py
from .base_views import DjangoFilterBackend, IsAdminUserOrGroup, IsAuthenticated, OrderingFilter, Response, SearchFilter, User, UserFilter, UserSerializer, action, permission_classes, status, viewsets


# ============================================================
# UserViewSet
# ============================================================
class UserViewSet(viewsets.ReadOnlyModelViewSet):
    queryset = User.objects.all()
    serializer_class = UserSerializer
    permission_classes = [IsAdminUserOrGroup]
    filter_backends = [DjangoFilterBackend, SearchFilter, OrderingFilter]
    filterset_class = UserFilter
    search_fields = ['username', 'email', 'first_name', 'last_name']
    ordering_fields = ['username', 'date_joined']
    ordering = ['username']

    @action(detail=False, methods=['post'],
            permission_classes=[IsAuthenticated])
    def change_password(self, request):
        user = request.user
        old_password = request.data.get('old_password')
        new_password = request.data.get('new_password')

        if not old_password or not new_password:
            return Response({'error': 'رمز فعلی و جدید را وارد کنید.'},
                            status=status.HTTP_400_BAD_REQUEST)

        if not user.check_password(old_password):
            return Response({'error': 'رمز فعلی اشتباه است.'},
                            status=status.HTTP_400_BAD_REQUEST)

        user.set_password(new_password)
        user.save()
        # P1-07 (EDRA v8): باطل کردن همه refresh token های قبلی — یک رمز
        # دزدیده‌شده/قدیمی نباید session باز نگه دارد.
        from ..security import revoke_user_refresh_tokens
        revoke_user_refresh_tokens(user)
        return Response({'success': True,
                         'message': 'رمز عبور با موفقیت تغییر کرد.'})

from rest_framework import serializers
from django.contrib.auth import get_user_model
from .models import DiscountCampaign, DiscountCodeUsage

User = get_user_model()


class UserSearchSerializer(serializers.ModelSerializer):
    phone = serializers.SerializerMethodField()

    class Meta:
        model = User
        fields = ['id', 'username', 'email', 'phone']

    def get_phone(self, obj):
        if hasattr(obj, 'profile') and obj.profile:
            return obj.profile.phone
        return None


class DiscountCampaignSerializer(serializers.ModelSerializer):
    class Meta:
        model = DiscountCampaign
        fields = '__all__'


class DiscountCodeUsageSerializer(serializers.ModelSerializer):
    class Meta:
        model = DiscountCodeUsage
        fields = '__all__'

document.addEventListener('DOMContentLoaded', function() {
    const conditionTypeField = document.querySelector('#id_condition_type');
    const daysThresholdField = document.querySelector('.field-new_user_days_threshold');

    if (conditionTypeField && daysThresholdField) {
        function toggleDaysThreshold() {
            if (conditionTypeField.value === 'new_user') {
                daysThresholdField.style.display = 'table-row';
            } else {
                daysThresholdField.style.display = 'none';
            }
        }

        // اجرای اولیه
        toggleDaysThreshold();

        // شنود تغییرات
        conditionTypeField.addEventListener('change', toggleDaysThreshold);
    }
});
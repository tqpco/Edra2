from celery import shared_task
import logging
import secrets
import string
from django.contrib.auth import get_user_model
from django.utils import timezone
from django.db import transaction, models
from datetime import timedelta

from core.models import DiscountCode, InspectionRequest, Payment
from core.utils.date_utils import to_jalali
from notifications.models import NotificationTemplate, NotificationLog
from .models import DiscountCampaign, DiscountCodeUsage

logger = logging.getLogger(__name__)

User = get_user_model()

# EDRA v14 — MEDIUM 3.1.3: batch کوچک برای تراکنش‌های کوتاه
_CAMPAIGN_BATCH = 200

# ============================================================
# توابع کمکی برای ارسال نوتیفیکیشن و پیامک
# ============================================================


def queue_discount_notification(user, template_code, context):
    """
    برخلاف notifications.services.send_notification (که فوری ارسال می‌کند)،
    این تابع فقط یک لاگ با status='pending' می‌سازد؛ چون این تابع معمولاً
    داخل حلقه روی تعداد زیادی کاربر (کمپین تخفیف) صدا زده می‌شود و ارسال
    فوری/همزمان برای همه به‌صرفه نیست. تسک دوره‌ای
    notifications.tasks.process_pending_notifications این لاگ‌های pending
    را بعداً واقعاً ارسال می‌کند.
    """
    try:
        template = NotificationTemplate.objects.get(
            code=template_code, is_active=True)
    except NotificationTemplate.DoesNotExist:
        logger.error(f"قالب اعلان {template_code} یافت نشد.")
        return

    content = template.body_template
    for key, value in context.items():
        content = content.replace(f'{{{{ {key} }}}}', str(value))

    NotificationLog.objects.create(
        user=user,
        template=template,
        channel=template.channel,
        subject=template.subject,
        content=content,
        status='pending',
        type='new_discount_code'
    )

    logger.info(f"Queued discount notification for {user.username}")


def _generate_and_send_discount_for_user(user, campaign):
    while True:
        # EDRA v14 — MEDIUM 3.1.4: CSPRNG (secrets) به‌جای random — کدها
        # ارزش مالی دارند (usage_limit=1) و نباید قابل پیش‌بینی باشند.
        code = ''.join(
            secrets.choice(
                string.ascii_uppercase +
                string.digits)
            for _ in range(8))
        if not DiscountCode.objects.filter(code=code).exists():
            break

    template = campaign.discount_code_template
    new_discount = DiscountCode.objects.create(
        code=code,
        discount_type=template.discount_type,
        value=template.value,
        min_amount=template.min_amount,
        max_amount=template.max_amount,
        equipment_type=template.equipment_type,
        usage_limit=1,
        per_user_limit=1,
        expires_at=template.expires_at,
        is_active=True,
        description=f"تخفیف خودکار از کمپین {campaign.name}"
    )

    # EDRA v14 — HIGH 3.1.1: رکورد usage توسط caller (get_or_create +
    # constraint منحصربه‌فرد) قبل از فراخوانی این تابع ثبت می‌شود —
    # پس اینجا هیچ side effect تکراری رخ نمی‌دهد.

    context = {
        'code': new_discount.code,
        'discount_value': new_discount.value,
        'discount_type': new_discount.get_discount_type_display(),
        'expires_at': to_jalali(new_discount.expires_at) if new_discount.expires_at else 'نامحدود',
    }
    queue_discount_notification(user, 'new_discount_code', context)

    logger.info(
        f"Discount {
            new_discount.code} sent to {
            user.username} from campaign {
                campaign.name}")


# ============================================================
# تسک‌های اصلی
# ============================================================

@shared_task
def send_discount_to_user(user_id, discount_id):
    try:
        user = User.objects.get(id=user_id)
        discount = DiscountCode.objects.get(id=discount_id)
    except (User.DoesNotExist, DiscountCode.DoesNotExist):
        logger.error("کاربر یا کد تخفیف یافت نشد.")
        return

    # EDRA v14 — HIGH 3.1.1: فقط اگر رکورد usage جدیداً ساخته شد
    # (created=True) نوتیفیکیشن/پیامک ارسال می‌شود — retry تسک یا
    # double-click ادمین دیگر ارسال تکراری نمی‌سازد.
    _, created = DiscountCodeUsage.objects.get_or_create(
        user=user,
        discount_code=discount
    )
    if not created:
        logger.info(
            f"Duplicate send blocked for user {user.username} "
            f"code {discount.code}")
        return

    context = {
        'code': discount.code,
        'discount_value': discount.value,
        'discount_type': discount.get_discount_type_display(),
        'expires_at': to_jalali(discount.expires_at) if discount.expires_at else 'نامحدود',
    }
    queue_discount_notification(user, 'new_discount_code', context)


@shared_task
def send_discount_to_all_users(discount_id):
    try:
        discount = DiscountCode.objects.get(id=discount_id)
    except DiscountCode.DoesNotExist:
        logger.error("کد تخفیف یافت نشد.")
        return

    # EDRA v14 — HIGH 3.1.2: بدون لود کامل در حافظه (iterator) + بدون
    # ارسال به کاربرانی که قبلاً همین کد را گرفته‌اند (idempotency).
    existing = set(DiscountCodeUsage.objects.filter(
        discount_code=discount).values_list('user_id', flat=True))
    users = User.objects.filter(
        is_active=True).exclude(id__in=existing).iterator()
    batch = []
    for user in users:
        batch.append(user.id)
        if len(batch) >= 500:
            for uid in batch:
                send_discount_to_user.delay(uid, discount.id)
            batch = []
    for uid in batch:
        send_discount_to_user.delay(uid, discount.id)


@shared_task
def process_campaign_task(campaign_id):
    try:
        campaign = DiscountCampaign.objects.get(id=campaign_id, is_active=True)
    except DiscountCampaign.DoesNotExist:
        logger.error(f"کمپین {campaign_id} یافت نشد یا غیرفعال است.")
        return

    if campaign.condition_type == 'completed_requests':
        user_ids = InspectionRequest.objects.filter(
            status='completed').values('customer').annotate(
            count=models.Count('id')).filter(
            count__gte=campaign.condition_value).values_list(
                'customer',
            flat=True)
    elif campaign.condition_type == 'purchase_count':
        user_ids = Payment.objects.filter(
            status='paid').values('inspection_request__customer').annotate(
            count=models.Count('id')).filter(
            count__gte=campaign.condition_value).values_list(
                'inspection_request__customer',
            flat=True)
    elif campaign.condition_type == 'total_spent':
        user_ids = Payment.objects.filter(
            status='paid').values('inspection_request__customer').annotate(
            total=models.Sum('amount')).filter(
            total__gte=campaign.condition_value).values_list(
                'inspection_request__customer',
            flat=True)
    elif campaign.condition_type == 'new_user':
        # ✅ شرط جدید: کاربران ثبت‌نام‌شده در روزهای اخیر
        threshold = timezone.now() - timedelta(days=campaign.new_user_days_threshold)
        user_ids = User.objects.filter(
            date_joined__gte=threshold,
            is_active=True
        ).values_list('id', flat=True)
    else:
        logger.error(f"نوع شرط {campaign.condition_type} پشتیبانی نمی‌شود.")
        return

    # EDRA v14 — HIGH 3.1.2 / MEDIUM 3.1.3:
    # - پیش‌واکشی یک‌باره‌ی کاربرانی که قبلاً از این کمپین کد گرفته‌اند
    #   (حذف N+1 — جایگزین .exists() در حلقه)
    # - پردازش در batch های کوچک با transaction کوتاه (بدون قفل طولانی)
    existing = set(DiscountCodeUsage.objects.filter(
        campaign=campaign).values_list('user_id', flat=True))
    user_ids_qs = User.objects.filter(
        id__in=user_ids, is_active=True).exclude(
        id__in=existing).values_list('id', flat=True)

    def _process_batch(ids):
        with transaction.atomic():
            for uid in ids:
                try:
                    user = User.objects.get(id=uid)
                except User.DoesNotExist:
                    continue
                # get_or_create در سطح DB با constraint منحصربه‌فرد —
                # race-safe و idempotent
                _, created = DiscountCodeUsage.objects.get_or_create(
                    user=user, campaign=campaign)
                if created:
                    _generate_and_send_discount_for_user(user, campaign)

    batch = []
    processed = 0
    for uid in user_ids_qs.iterator():
        batch.append(uid)
        if len(batch) >= _CAMPAIGN_BATCH:
            _process_batch(batch)
            processed += len(batch)
            batch = []
    if batch:
        _process_batch(batch)
        processed += len(batch)

    campaign.last_run_at = timezone.now()
    campaign.save(update_fields=['last_run_at'])
    logger.info(
        f"کمپین {campaign.name} برای {processed} کاربر جدید اجرا شد.")


@shared_task
def check_user_campaigns_task(user_id):
    try:
        user = User.objects.get(id=user_id)
    except User.DoesNotExist:
        logger.error(f"User {user_id} not found.")
        return

    campaigns = DiscountCampaign.objects.filter(is_active=True)

    for campaign in campaigns:
        if DiscountCodeUsage.objects.filter(
                user=user, campaign=campaign).exists():
            continue

        condition_met = False
        if campaign.condition_type == 'completed_requests':
            count = InspectionRequest.objects.filter(
                customer=user, status='completed').count()
            condition_met = count >= campaign.condition_value
        elif campaign.condition_type == 'purchase_count':
            count = Payment.objects.filter(
                inspection_request__customer=user,
                status='paid'
            ).count()
            condition_met = count >= campaign.condition_value
        elif campaign.condition_type == 'total_spent':
            total = Payment.objects.filter(
                inspection_request__customer=user,
                status='paid'
            ).aggregate(total=models.Sum('amount'))['total'] or 0
            condition_met = total >= campaign.condition_value
        elif campaign.condition_type == 'new_user':
            # ✅ بررسی شرط جدید برای یک کاربر خاص
            threshold = timezone.now() - timedelta(days=campaign.new_user_days_threshold)
            condition_met = user.date_joined >= threshold
        else:
            continue

        if condition_met:
            _generate_and_send_discount_for_user(user, campaign)

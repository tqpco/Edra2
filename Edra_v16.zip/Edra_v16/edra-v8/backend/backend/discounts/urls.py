from django.urls import path
from . import views

app_name = 'discounts'

urlpatterns = [
    path('user-search/', views.UserSearchView.as_view(), name='user_search'),
    path(
        'send-to-user/',
        views.SendDiscountToUserView.as_view(),
        name='send_to_user'),
    path(
        'send-to-all/',
        views.SendDiscountToAllUsersView.as_view(),
        name='send_to_all'),
    # ✅ مسیر جدید
]

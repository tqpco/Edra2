# edra/asgi.py
"""
ASGI config for edra project.
It exposes the ASGI callable as a module-level variable named ``application``.
"""

import os
from django.core.asgi import get_asgi_application
from channels.routing import ProtocolTypeRouter, URLRouter
from django.urls import path
from notifications.consumers import NotificationConsumer
from edra.ws_auth import WsTicketAuthMiddleware

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'edra.settings')

application = ProtocolTypeRouter({
    'http': get_asgi_application(),
    'websocket': WsTicketAuthMiddleware(
        URLRouter([
            path('ws/notifications/', NotificationConsumer.as_asgi()),
        ])
    ),
})

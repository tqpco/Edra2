from celery.schedules import crontab
from celery import Celery
import os
import logging
logger = logging.getLogger(__name__)
# edra/celery.py

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'edra.settings')

app = Celery('edra')
app.config_from_object('django.conf:settings', namespace='CELERY')
app.autodiscover_tasks()

# ✅ تنظیم تسک‌های دوره‌ای
app.conf.beat_schedule = {
    'check-expiring-discount-codes': {
        'task': 'core.tasks.check_expiring_discount_codes',
        'schedule': crontab(hour=8, minute=0),  # هر روز ساعت ۸ صبح
    },
    'close-expired-manual-payments': {
        'task': 'core.tasks.close_expired_manual_payments',
        'schedule': crontab(minute=0),  # هر ساعت - بستن درخواست‌های پرداخت دستی که ۴۸ ساعت گذشته
    },
    'process-pending-notifications': {
        'task': 'notifications.tasks.process_pending_notifications',
        'schedule': crontab(minute='*/5'),  # هر ۵ دقیقه - ارسال اعلان‌های صف‌شده
    },
    'auto-close-inactive-tickets': {
        'task': 'support.tasks.auto_close_inactive_tickets',
        'schedule': crontab(minute=0),  # هر ساعت - بستن تیکت‌های بی‌پاسخ بعد از ۷۲ ساعت
    },
}


@app.task(bind=True)
def debug_task(self):
    logger.info(f'Request: {self.request!r}')

# edra/settings.py
import os
import logging
from pathlib import Path
from datetime import timedelta
from dotenv import load_dotenv

logger = logging.getLogger(__name__)

# تعیین مسیر پایه پروژه
BASE_DIR = Path(__file__).resolve().parent.parent

# بارگذاری متغیرهای محیطی از فایل .env (فقط یک بار)
load_dotenv(BASE_DIR / '.env')

# ================================================================
# تنظیمات امنیتی و محیطی
# ================================================================
SECRET_KEY = os.environ.get(
    'SECRET_KEY',
    'django-insecure-default-key-change-this'
)
DEBUG = os.environ.get('DEBUG', 'False') == 'True'
ALLOWED_HOSTS = os.environ.get(
    'ALLOWED_HOSTS',
    'localhost,127.0.0.1'
).split(',')

DEEPSEEK_API_KEY = os.environ.get('DEEPSEEK_API_KEY', '')
ZARINPAL_MERCHANT_ID = os.environ.get(
    'ZARINPAL_MERCHANT_ID',
    'your_merchant_id'
)
ZARINPAL_SANDBOX = os.environ.get('ZARINPAL_SANDBOX', 'True') == 'True'

# ================================================================
# حالت توسعه OTP (بدون پیامک واقعی)
# فقط در DEBUG مجاز است؛ در Production اگر DEV_OTP_ENABLED=True باشد
# سرور اصلاً بالا نمی‌آید (خطای پیکربندی).
# ================================================================
DEV_OTP_ENABLED = os.environ.get('DEV_OTP_ENABLED', 'False') == 'True'
DEV_OTP_CODE = os.environ.get('DEV_OTP_CODE', '246810')
DEV_OTP_ALLOWED_PHONES = [
    p.strip()
    for p in os.environ.get('DEV_OTP_ALLOWED_PHONES', '').split(',')
    if p.strip()
]
if DEV_OTP_ENABLED and not DEBUG:
    from django.core.exceptions import ImproperlyConfigured
    raise ImproperlyConfigured(
        'DEV_OTP_ENABLED=True فقط با DEBUG=True مجاز است.')

# محدودیت تلاش و انقضای کد OTP
OTP_MAX_ATTEMPTS = 5
OTP_TTL_SECONDS = 120

# ================================================================
# اپلیکیشن‌ها
# ================================================================
INSTALLED_APPS = [
    'django.contrib.admin',
    'django.contrib.auth',
    'django.contrib.contenttypes',
    'django.contrib.sessions',
    'django.contrib.messages',
    'django.contrib.staticfiles',
    'django.contrib.sites',

    # اپلیکیشن‌های اختصاصی پروژه
    'core.apps.CoreConfig',
    'pricing.apps.PricingConfig',
    'inspections.apps.InspectionsConfig',
    'public.apps.PublicConfig',
    'notifications.apps.NotificationsConfig',
    'support.apps.SupportConfig',
    'discounts.apps.DiscountsConfig',

    # اپلیکیشن‌های شخص ثالث
    'django_jalali',
    'jalali_date',
    'corsheaders',
    'rest_framework',
    'rest_framework_simplejwt',
    'rest_framework_simplejwt.token_blacklist',
    'drf_spectacular',
    # EDRA v14 — HIGH 3.2: django-allauth حذف شد (بی‌استفاده + سطح حمله‌ی
    # زنده) — ورود فقط از مسیر OTP پروژه انجام می‌شود.
    'django_filters',
    'guardian',
    'channels',
    # P2: متریک‌های Prometheus (اختیاری — در صورت نصب پکیج فعال می‌شود)
    'django_prometheus',
]

# ================================================================
# Middleware
# ================================================================
MIDDLEWARE = [
    # P2: متریک Prometheus — Before باید بالاترین اولویت باشد
    'django_prometheus.middleware.PrometheusBeforeMiddleware',
    'django.middleware.security.SecurityMiddleware',
    # EDRA v5 — CRITICAL-02: سرو static توسط خود Django (بدون نیاز به
    # volume/Nginx path جدا) — باید بلافاصله بعد از SecurityMiddleware باشد.
    'whitenoise.middleware.WhiteNoiseMiddleware',
    'corsheaders.middleware.CorsMiddleware',
    'django.contrib.sessions.middleware.SessionMiddleware',
    'django.middleware.common.CommonMiddleware',
    'core.middleware.RequestIdMiddleware',
    'django.middleware.csrf.CsrfViewMiddleware',
    'django.contrib.auth.middleware.AuthenticationMiddleware',
    'django.contrib.messages.middleware.MessageMiddleware',
    'django.middleware.clickjacking.XFrameOptionsMiddleware',
    # EDRA v14 — HIGH 3.2: middleware allauth حذف شد
    'core.middleware.ErrorLoggingMiddleware',
    # P2: متریک Prometheus — After باید پایین‌ترین اولویت باشد
    'django_prometheus.middleware.PrometheusAfterMiddleware',
]

ROOT_URLCONF = 'edra.urls'

TEMPLATES = [
    {
        'BACKEND': 'django.template.backends.django.DjangoTemplates',
        'DIRS': [BASE_DIR / 'templates'],
        'APP_DIRS': True,
        'OPTIONS': {
            'context_processors': [
                'django.template.context_processors.debug',
                'django.template.context_processors.request',
                'django.contrib.auth.context_processors.auth',
                'django.contrib.messages.context_processors.messages',
            ],
        },
    },
]

WSGI_APPLICATION = 'edra.wsgi.application'
ASGI_APPLICATION = 'edra.asgi.application'

# ================================================================
# دیتابیس (با پشتیبانی از محیط‌های مختلف)
# ================================================================
DATABASES = {
    'default': {
        'ENGINE': os.environ.get('DB_ENGINE', 'django.db.backends.sqlite3'),
        'NAME': os.environ.get('DB_NAME', str(BASE_DIR / 'db.sqlite3')),
        'USER': os.environ.get('DB_USER', ''),
        'PASSWORD': os.environ.get('DB_PASSWORD', ''),
        'HOST': os.environ.get('DB_HOST', ''),
        'PORT': os.environ.get('DB_PORT', ''),
    }
}

# ================================================================
# اعتبارسنجی رمز عبور
# ================================================================
AUTH_PASSWORD_VALIDATORS = [
    {
        'NAME': 'django.contrib.auth.password_validation.UserAttributeSimilarityValidator'
    },
    {
        'NAME': 'django.contrib.auth.password_validation.MinimumLengthValidator'
    },
    {
        'NAME': 'django.contrib.auth.password_validation.CommonPasswordValidator'
    },
    {
        'NAME': 'django.contrib.auth.password_validation.NumericPasswordValidator'
    },
]

# ================================================================
# زبان و زمان
# ================================================================
LANGUAGE_CODE = 'fa'
TIME_ZONE = 'Asia/Tehran'
USE_I18N = True
USE_TZ = True

# ================================================================
# فایل‌های استاتیک و رسانه
# ================================================================
STATIC_URL = 'static/'
STATIC_ROOT = BASE_DIR / 'staticfiles'
STATICFILES_DIRS = [BASE_DIR / 'static']

MEDIA_URL = '/media/'
MEDIA_ROOT = BASE_DIR / 'media'

DEFAULT_AUTO_FIELD = 'django.db.models.BigAutoField'

# ================================================================
# CORS
# ================================================================
CORS_ALLOW_ALL_ORIGINS = os.environ.get(
    'CORS_ALLOW_ALL_ORIGINS',
    'False'
) == 'True'
CORS_ALLOWED_ORIGINS = os.environ.get(
    'CORS_ALLOWED_ORIGINS',
    'http://localhost:3000,https://your-frontend-domain.com'
).split(',')

# ================================================================
# Django REST Framework
# ================================================================
# ================================================================
# سرویس پیامک و امضای PDF (از .env)
# ================================================================
# SMS_PROVIDER: خالی/پیش‌فرض = فقط لاگ؛ 'kavenegar' = ارسال واقعی
SMS_PROVIDER = os.environ.get('SMS_PROVIDER', '')
SMS_API_KEY = os.environ.get('SMS_API_KEY', '')
# P0-11: fail-closed بودن SMS. در settings_production همیشه True است؛ در
# محیط توسعه/تست (settings پایه) به‌صورت پیش‌فرض False می‌ماند تا mock
# بدون provider مجاز باشد. اگر می‌خواهید رفتار fail-closed در محیط‌های
# دیگر هم فعال باشد، SMS_FAIL_CLOSED=True را در .env بگذارید.
SMS_FAIL_CLOSED = os.environ.get('SMS_FAIL_CLOSED', 'False') == 'True'
# تولید PDF فاکتور: False = همزمان در request (پیش‌فرض dev/test)؛
# True = از طریق Celery task (تولید، همراه با Redis broker)
PDF_GENERATION_ASYNC = os.environ.get(
    'PDF_GENERATION_ASYNC', 'false').lower() in ('1', 'true', 'yes')

# ================================================================
# Object Storage (P2 — S3/MinIO؛ اختیاری و fail-open)
# اگر AWS_STORAGE_BUCKET_NAME تنظیم نشود، فایل‌ها روی دیسک محلی می‌مانند.
# ================================================================
AWS_STORAGE_BUCKET_NAME = os.environ.get('AWS_STORAGE_BUCKET_NAME', '')
AWS_S3_ENDPOINT_URL = os.environ.get('AWS_S3_ENDPOINT_URL', '')
AWS_ACCESS_KEY_ID = os.environ.get('AWS_ACCESS_KEY_ID', '')
AWS_SECRET_ACCESS_KEY = os.environ.get('AWS_SECRET_ACCESS_KEY', '')
AWS_S3_REGION_NAME = os.environ.get('AWS_S3_REGION_NAME', 'us-east-1')
AWS_S3_CUSTOM_DOMAIN = os.environ.get('AWS_S3_CUSTOM_DOMAIN', '')
if AWS_STORAGE_BUCKET_NAME and AWS_ACCESS_KEY_ID:
    INSTALLED_APPS += ('storages',)
    DEFAULT_FILE_STORAGE = 'storages.backends.s3boto3.S3Boto3Storage'
    AWS_QUERYSTRING_AUTH = True  # URL ها امضاشده و موقت‌اند (private)

# ================================================================
# Sentry (P2 — ردیابی خطای متمرکز؛ اختیاری و fail-open)
# اگر SENTRY_DSN تنظیم نباشد، هیچ‌کاری انجام نمی‌شود.
# ================================================================
SENTRY_DSN = os.environ.get('SENTRY_DSN', '')
SENTRY_TRACES_SAMPLE_RATE = float(os.environ.get(
    'SENTRY_TRACES_SAMPLE_RATE', '0.1'))
if SENTRY_DSN:
    try:
        import sentry_sdk
        from sentry_sdk.integrations.django import DjangoIntegration
        from sentry_sdk.integrations.celery import CeleryIntegration
        sentry_sdk.init(
            dsn=SENTRY_DSN,
            integrations=[
                DjangoIntegration(),
                CeleryIntegration(),
            ],
            traces_sample_rate=SENTRY_TRACES_SAMPLE_RATE,
            send_default_pii=False,   # اطلاعات شخصی ارسال نشود (PII)
            release=os.environ.get('GIT_SHA', None),
            environment=os.environ.get(
                'ENVIRONMENT', 'production' if not DEBUG else 'development'),
        )
    except Exception as _sentry_err:  # fail-open: نباید startup را بشکند
        logger.warning(f"Sentry init failed (continuing): {_sentry_err}")
# گواهی امضای دیجیتال PAdES (اختیاری؛ بدون آن فقط مهر یکپارچگی)
PDF_SIGN_CERT_PATH = os.environ.get('PDF_SIGN_CERT_PATH', '')
PDF_SIGN_KEY_PATH = os.environ.get('PDF_SIGN_KEY_PATH', '')
PDF_SIGN_KEY_PASSWORD = os.environ.get('PDF_SIGN_KEY_PASSWORD', '')

REST_FRAMEWORK = {
    'DEFAULT_AUTHENTICATION_CLASSES': (
        'rest_framework_simplejwt.authentication.JWTAuthentication',
    ),
    # قرارداد خطای یکسان: هر پاسخ خطا شامل error (انسانی) + detail (ساختار)
    'EXCEPTION_HANDLER': 'core.exceptions.api_exception_handler',
    'DEFAULT_SCHEMA_CLASS': 'drf_spectacular.openapi.AutoSchema',
    'DEFAULT_THROTTLE_CLASSES': [
        'rest_framework.throttling.AnonRateThrottle',
        'rest_framework.throttling.UserRateThrottle',
    ],
    'DEFAULT_THROTTLE_RATES': {
        'anon': '1000/day',
        'user': '10000/day',
        # محدودیت سخت‌گیرانه‌تر برای OTP: هر پیامک هزینه واقعی دارد و
        # حدس‌زدن کد ۶ رقمی باید محدود شود (این محدودیت‌ها قبلاً اصلاً
        # وجود نداشتند و OTP فقط زیر throttle عمومی anon بود).
        'otp_request': '5/hour',
        'otp_verify': '10/hour',
        # ضد spam برای فرم تماس عمومی
        'contact_message': '5/hour',
        # P1-09: محدودیت تلاش برای لاگین/رفرش توکن (ضد brute-force)
        'login': '20/hour',
        'refresh': '120/hour',
        # P1 — گزارش V3 بند ۴۳: throttle مسیرهای حساس مالی/عمومی
        'payment_initiate': '30/hour',
        'payment_callback': '120/hour',
        'public_verify': '60/hour',
        'ticket_create': '20/hour',
        # P1-06 (EDRA v8): create عمومی درخواست بازرسی — ضد سوءاستفاده
        'inspection_create': '20/hour',
    },
}

# ================================================================
# کش
# ================================================================
CACHES = {
    'default': {
        'BACKEND': 'django.core.cache.backends.locmem.LocMemCache',
        'LOCATION': 'unique-snowflake',
    }
}

# ================================================================
# احراز هویت (guardian) — EDRA v14: backend allauth حذف شد (HIGH 3.2)
# ================================================================
AUTHENTICATION_BACKENDS = [
    'django.contrib.auth.backends.ModelBackend',
    'guardian.backends.ObjectPermissionBackend',
]

SITE_ID = 1
LOGIN_REDIRECT_URL = '/'
LOGOUT_REDIRECT_URL = '/'

GUARDIAN_RAISE_403 = True
ANONYMOUS_USER_NAME = None

# ================================================================
# تنظیمات UNFOLD (پنل ادمین)
# ================================================================
UNFOLD = {
    "SITE_TITLE": "ادرو - مدیریت",
    "SITE_HEADER": "ادرو",
    "SITE_URL": "/",
    "SITE_ICON": None,
    "ENVIRONMENT": "production",
    # "DASHBOARD_CALLBACK": "core.admin.dashboard_callback",
    "LOGIN": {
        "image": None,
    },
    "STYLES": [],
    "SCRIPTS": [],
    "SIDEBAR": {
        "show_search": True,
        "show_all_applications": False,
        "navigation": [
            {
                "title": "داشبورد",
                "items": [
                    {
                        "title": "داشبورد اصلی",
                        "icon": "home",
                        "link": "/admin/",
                    }
                ]
            },
            {
                "title": "مدیریت کاربران",
                "icon": "users",
                "items": [
                    {
                        "title": "کاربران",
                        "icon": "user",
                        "link": "/admin/auth/user/",
                    },
                    {
                        "title": "گروه‌ها",
                        "icon": "users",
                        "link": "/admin/auth/group/",
                    },
                ]
            },
            {
                "title": "درخواست‌ها و بازرسی",
                "icon": "clipboard",
                "items": [
                    {
                        "title": "درخواست‌های بازرسی",
                        "icon": "file-text",
                        "link": "/admin/core/inspectionrequest/",
                    },
                    {
                        "title": "گزارش‌های بازرسی",
                        "icon": "file-check",
                        "link": "/admin/core/inspectionreport/",
                    },
                    {
                        "title": "قالب‌های چک‌لیست",
                        "icon": "list-check",
                        "link": "/admin/core/checklisttemplate/",
                    },
                ]
            },
            {
                "title": "پرداخت‌ها و مالی",
                "icon": "credit-card",
                "items": [
                    {
                        "title": "پرداخت‌ها",
                        "icon": "dollar-sign",
                        "link": "/admin/core/payment/",
                    },
                    {
                        "title": "فاکتورها",
                        "icon": "file-invoice",
                        "link": "/admin/core/invoice/",
                    },
                    {
                        "title": "اعتبار کاربران",
                        "icon": "coins",
                        "link": "/admin/core/usercredit/",
                    },
                    {
                        "title": "تراکنش‌های اعتباری",
                        "icon": "exchange",
                        "link": "/admin/core/credittransaction/",
                    },
                ]
            },
            {
                "title": "قیمت‌گذاری",
                "icon": "calculator",
                "items": [
                    {
                        "title": "قوانین قیمت‌گذاری",
                        "icon": "ruler",
                        "link": "/admin/pricing/pricingrule/",
                    },
                    {
                        "title": "تاریخچه تغییرات قیمت",
                        "icon": "history",
                        "link": "/admin/pricing/pricingrulechangelog/",
                    },
                    {
                        "title": "لاگ محاسبه قیمت",
                        "icon": "bar-chart",
                        "link": "/admin/pricing/pricecalculationlog/",
                    },
                ]
            },
            {
                "title": "تنظیمات پایه",
                "icon": "settings",
                "items": [
                    {
                        "title": "انواع تجهیزات",
                        "icon": "package",
                        "link": "/admin/core/equipmenttype/",
                    },
                    {
                        "title": "ضرایب شهرها",
                        "icon": "map-pin",
                        "link": "/admin/core/citymultiplier/",
                    },
                    {
                        "title": "سازمان‌ها",
                        "icon": "building",
                        "link": "/admin/core/organization/",
                    },
                    {
                        "title": "پروژه‌ها",
                        "icon": "folder",
                        "link": "/admin/core/project/",
                    },
                ]
            },
            {
                "title": "پشتیبانی",
                "icon": "headphones",
                "items": [
                    {
                        "title": "تیکت‌ها",
                        "icon": "ticket",
                        "link": "/admin/support/ticket/",
                    },
                    {
                        "title": "نظرات تیکت‌ها",
                        "icon": "message-circle",
                        "link": "/admin/support/ticketcomment/",
                    },
                ]
            },
            {
                "title": "اعلان‌ها",
                "icon": "bell",
                "items": [
                    {
                        "title": "لاگ اعلان‌ها",
                        "icon": "bell-ring",
                        "link": "/admin/notifications/notificationlog/",
                    },
                    {
                        "title": "قالب‌های اعلان",
                        "icon": "mail",
                        "link": "/admin/notifications/notificationtemplate/",
                    },
                ]
            },
            {
                "title": "گزارش‌ها و لاگ‌ها",
                "icon": "activity",
                "items": [
                    {
                        "title": "لاگ خطاها",
                        "icon": "alert-octagon",
                        "link": "/admin/core/errorlog/",
                    },
                    {
                        "title": "لاگ حسابرسی",
                        "icon": "eye",
                        "link": "/admin/core/auditlog/",
                    },
                ]
            },
            {
                "title": "تخفیف‌ها",
                "icon": "gift",
                "items": [
                    {
                        "title": "کدهای تخفیف",
                        "icon": "ticket",
                        "link": "/admin/core/discountcode/",
                    },
                    {
                        "title": "کمپین‌های تخفیف",
                        "icon": "settings",
                        "link": "/admin/discounts/discountcampaign/",
                    },
                    {
                        "title": "استفاده از کدها",
                        "icon": "list",
                        "link": "/admin/discounts/discountcodeusage/",
                    },
                ]
            },
        ],
    },
}

# ================================================================
# JWT
# ================================================================
SIMPLE_JWT = {
    # قبلاً ۱ روز بود که برای access token خیلی طولانی و ریسک امنیتی
    # محسوب می‌شود (اگر توکن لو برود، پنجره سوءاستفاده باز می‌ماند).
    # استاندارد صنعتی: عمر کوتاه برای access + رفرش با چرخش/بلاک‌لیست.
    'ACCESS_TOKEN_LIFETIME': timedelta(minutes=30),
    'REFRESH_TOKEN_LIFETIME': timedelta(days=7),
    'ROTATE_REFRESH_TOKENS': True,
    'BLACKLIST_AFTER_ROTATION': True,
    'UPDATE_LAST_LOGIN': True,
}

# ================================================================
# ایمیل
# ================================================================
# قبلاً هیچ تنظیمی نبود، یعنی جنگو از پیش‌فرض خودش (اتصال SMTP به
# localhost:25) استفاده می‌کرد که در هیچ محیطی (نه لوکال، نه سرور) از
# پیش آماده نیست و هر send_mail با خطای اتصال شکست می‌خورد. پیش‌فرض
# ایمن برای توسعه: چاپ در کنسول؛ در Production با env var مقداردهی شود.
EMAIL_BACKEND = os.environ.get(
    'EMAIL_BACKEND', 'django.core.mail.backends.console.EmailBackend')
EMAIL_HOST = os.environ.get('EMAIL_HOST', 'localhost')
EMAIL_PORT = int(os.environ.get('EMAIL_PORT', 587))
EMAIL_HOST_USER = os.environ.get('EMAIL_HOST_USER', '')
EMAIL_HOST_PASSWORD = os.environ.get('EMAIL_HOST_PASSWORD', '')
EMAIL_USE_TLS = os.environ.get('EMAIL_USE_TLS', 'True') == 'True'
DEFAULT_FROM_EMAIL = os.environ.get('DEFAULT_FROM_EMAIL', 'noreply@inspectpro.ir')

# آدرس پایه سایت - برای لینک‌هایی که داخل پیامک/ایمیل اعلان‌ها ساخته می‌شود
SITE_URL = os.environ.get('SITE_URL', 'http://localhost:8000')

# آدرس فرانت‌اند Next.js - برای ریدایرکت بعد از بازگشت از درگاه پرداخت
# (قبلاً وجود نداشت و ریدایرکت به آدرس نسبی روی همین دامنه بک‌اند می‌رفت
# که چون این یک API-only backend است، صفحه‌ای برای نمایش وجود نداشت)
FRONTEND_URL = os.environ.get('FRONTEND_URL', 'http://localhost:3000')

# ================================================================
# Celery
# ================================================================
CELERY_BROKER_URL = os.environ.get('CELERY_BROKER_URL', 'memory://')
CELERY_RESULT_BACKEND = os.environ.get(
    'CELERY_RESULT_BACKEND',
    'cache+memory://'
)
CELERY_ACCEPT_CONTENT = ['application/json']
CELERY_TASK_SERIALIZER = 'json'
CELERY_RESULT_SERIALIZER = 'json'
CELERY_TIMEZONE = TIME_ZONE
CELERY_TASK_TRACK_STARTED = True
CELERY_TASK_TIME_LIMIT = 30 * 60
CELERY_TASK_SOFT_TIME_LIMIT = 20 * 60

# ================================================================
# Channels (WebSocket)
# ================================================================
# نکته: InMemoryChannelLayer فقط داخل یک پردازش کار می‌کند - یعنی با چند
# worker (حالت معمول gunicorn/uvicorn در Production) اعلان بلادرنگ به
# کاربری که روی worker دیگری وصل است نمی‌رسد. اگر REDIS_URL تنظیم شده
# باشد از Redis استفاده می‌شود (توصیه‌شده برای Production)، در غیر این
# صورت برای توسعه‌ی محلی ساده از InMemory استفاده می‌شود.
_channel_redis_url = os.environ.get('CHANNEL_REDIS_URL') or os.environ.get('REDIS_URL')
if _channel_redis_url:
    CHANNEL_LAYERS = {
        'default': {
            'BACKEND': 'channels_redis.core.RedisChannelLayer',
            'CONFIG': {
                'hosts': [_channel_redis_url],
            },
        },
    }
else:
    CHANNEL_LAYERS = {
        'default': {
            'BACKEND': 'channels.layers.InMemoryChannelLayer',
        },
    }

# ================================================================
# Swagger / Spectacular
# ================================================================
SPECTACULAR_SETTINGS = {
    'TITLE': 'API ادرو - سیستم مدیریت بازرسی',
    'DESCRIPTION': 'مستندات کامل API پروژه ادرو',
    'VERSION': '1.0.0',
    'SERVE_INCLUDE_SCHEMA': False,
    'COMPONENT_SPLIT_REQUEST': True,
    'SCHEMA_PATH_PREFIX': '/api/',
    'TAGS': [
        {'name': 'core', 'description': 'عملیات اصلی سیستم'},
        {'name': 'pricing', 'description': 'قیمت‌گذاری و محاسبات'},
        {'name': 'inspections', 'description': 'بازرسی و گزارش‌ها'},
        {'name': 'notifications', 'description': 'اعلان‌ها'},
        {'name': 'support', 'description': 'پشتیبانی و تیکت‌ها'},
        {'name': 'auth', 'description': 'احراز هویت و OTP'},
    ],
}

# ================================================================
# لاگینگ (جایگزین print)
# ================================================================
# EDRA v6 — P1: پوشه logs باید قبل از ساخت FileHandler وجود داشته باشد
# (در اجرای مستقیم runserver خارج Docker قبلاً fail می‌شد).
_LOG_DIR = BASE_DIR / 'logs'
_LOG_DIR.mkdir(parents=True, exist_ok=True)

LOGGING = {
    'version': 1,
    'disable_existing_loggers': False,
    'formatters': {
        'verbose': {
            'format': '{levelname} {asctime} {module} {process:d} {thread:d} {message}',
            'style': '{',
        },
        'simple': {
            'format': '{levelname} {asctime} {message}',
            'style': '{',
        },
    },
    'handlers': {
        'console': {
            'class': 'logging.StreamHandler',
            'formatter': 'simple',
        },
        # EDRA v13 — P1-06: چرخش لاگ + سقف + retention (جلوگیری از پر شدن دیسک)
        'file': {
            'class': 'logging.handlers.RotatingFileHandler',
            'filename': os.path.join(BASE_DIR, 'logs', 'django.log'),
            'maxBytes': 10 * 1024 * 1024,
            'backupCount': 10,
            'formatter': 'verbose',
        },
    },
    'root': {
        'handlers': ['console', 'file'],
        'level': 'INFO',
    },
    'loggers': {
        'django': {
            'handlers': ['console', 'file'],
            'level': os.environ.get('DJANGO_LOG_LEVEL', 'INFO'),
            'propagate': False,
        },
        'core': {
            'handlers': ['console', 'file'],
            'level': 'DEBUG',
            'propagate': False,
        },
    },
}

# ================================================================
# تنظیمات امنیتی Production (اضافه شده توسط اسکریپت)
# ================================================================
SECURE_SSL_REDIRECT = os.environ.get('SECURE_SSL_REDIRECT', 'False') == 'True'
SESSION_COOKIE_SECURE = os.environ.get('SESSION_COOKIE_SECURE', 'False') == 'True'
CSRF_COOKIE_SECURE = os.environ.get('CSRF_COOKIE_SECURE', 'False') == 'True'
SECURE_HSTS_SECONDS = int(os.environ.get('SECURE_HSTS_SECONDS', 0))
SECURE_HSTS_INCLUDE_SUBDOMAINS = os.environ.get('SECURE_HSTS_INCLUDE_SUBDOMAINS', 'False') == 'True'
SECURE_HSTS_PRELOAD = os.environ.get('SECURE_HSTS_PRELOAD', 'False') == 'True'

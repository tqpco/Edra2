# edra/settings_production.py
"""
تنظیمات محیط Production.

نکته‌ی مهم (باگ اصلی که اینجا بود): این فایل قبلاً از تنظیمات پایه
(edra/settings.py) ارث‌بری نمی‌کرد - یعنی INSTALLED_APPS، MIDDLEWARE،
ROOT_URLCONF، TEMPLATES، REST_FRAMEWORK، SIMPLE_JWT و ده‌ها تنظیم دیگر را
اصلاً نداشت. چون edra/wsgi.py دقیقاً همین فایل را به‌عنوان
DJANGO_SETTINGS_MODULE استفاده می‌کند، یعنی با gunicorn/هر WSGI server
واقعی، جنگو حتی بالا نمی‌آمد (روی همین خط اول هم NameError می‌داد چون
`Path` وارد نشده بود).

راه‌حل درست: این فایل حالا همه چیز را از settings.py می‌گیرد و فقط مقادیر
مخصوص Production را رویش می‌نویسد (override).
"""
import os
from django.core.exceptions import ImproperlyConfigured

from .settings import *  # noqa: F401,F403  -- عمداً همه‌چیز از پایه به ارث می‌رسد
from .settings import BASE_DIR

# ================================================================
# EDRA v13 — P1 #6: Swagger/OpenAPI در Production عمومی نیست
# فقط با SWAGGER_PUBLIC=true (staging) نمایش داده می‌شود؛
# در Production پیش‌فرض غیرفعال است.
# ================================================================
SWAGGER_PUBLIC = os.getenv('SWAGGER_PUBLIC', 'false').lower() == 'true'

# ================================================================
# امنیت پایه
# ================================================================
# P0-12: settings_production هرگز نباید با DEBUG=True بالا بیاید —
# fail-closed.
DEBUG = os.getenv('DEBUG', 'False') == 'True'
if DEBUG:
    raise ImproperlyConfigured(
        'DEBUG=True در edra.settings_production مجاز نیست. این ماژول فقط '
        'برای Production است؛ برای توسعه از edra.settings استفاده کنید.'
    )
ALLOWED_HOSTS = [h for h in os.getenv('ALLOWED_HOSTS', '').split(',') if h]

# SECRET_KEY باید حتماً در محیط Production از .env بیاید. اگر تنظیم نشده
# باشد یا همان مقدار پیش‌فرض ناامن settings.py باشد، عمداً خطا می‌دهیم
# تا با یک کلید ضعیف/پیش‌فرض دیپلوی تصادفی انجام نشود.
SECRET_KEY = os.getenv('SECRET_KEY', '')
if not SECRET_KEY or SECRET_KEY == 'django-insecure-default-key-change-this':
    raise ImproperlyConfigured(
        'SECRET_KEY در محیط Production تنظیم نشده یا مقدار پیش‌فرض ناامن '
        'است. یک مقدار تصادفی و قوی در متغیر محیطی SECRET_KEY قرار دهید '
        '(مثلاً با: python -c "import secrets; print(secrets.token_urlsafe(50))")'
    )
if not ALLOWED_HOSTS:
    raise ImproperlyConfigured(
        'ALLOWED_HOSTS در محیط Production خالی است. دامنه(های) واقعی سرور '
        'را با کاما جدا و در متغیر محیطی ALLOWED_HOSTS قرار دهید.'
    )

# ================================================================
# P0-12: اعتبارسنجی startup سایر تنظیمات حیاتی (fail-closed)
# ================================================================
_PLACEHOLDERS = (
    'your-domain.example', 'your-frontend-domain.com', 'example.com',
    'localhost', '127.0.0.1',
)


def _fail(msg: str):
    raise ImproperlyConfigured(msg)


# CORS — در Production هرگز CORS_ALLOW_ALL_ORIGINS مجاز نیست
CORS_ALLOW_ALL_ORIGINS = False
CORS_ALLOWED_ORIGINS = [o for o in os.getenv('CORS_ALLOWED_ORIGINS', '').split(',') if o]
if not CORS_ALLOWED_ORIGINS:
    _fail('CORS_ALLOWED_ORIGINS در Production خالی است. دامنه‌ی واقعی '
          'فرانت‌اند را تنظیم کنید (با کاما جدا).')
for _origin in CORS_ALLOWED_ORIGINS:
    if _origin in _PLACEHOLDERS or 'localhost' in _origin:
        _fail(f'CORS_ALLOWED_ORIGINS شامل origin نامعتبر/placeholder است: {_origin}')

# CSRF — EDRA v7 (P1): همان validation سخت‌گیرانه‌ی CORS؛ فقط origin های
# https و بدون placeholder. اگر خالی باشد fail می‌شود (fail-closed).
CSRF_TRUSTED_ORIGINS = [o for o in os.getenv('CSRF_TRUSTED_ORIGINS', '').split(',') if o]
if not CSRF_TRUSTED_ORIGINS:
    _fail('CSRF_TRUSTED_ORIGINS در Production خالی است (fail-closed).')
for _csrf_origin in CSRF_TRUSTED_ORIGINS:
    if not _csrf_origin.startswith('https://'):
        _fail(f'CSRF_TRUSTED_ORIGINS باید https باشد: {_csrf_origin}')
    if any(p in _csrf_origin for p in _PLACEHOLDERS):
        _fail(f'CSRF_TRUSTED_ORIGINS شامل placeholder است: {_csrf_origin}')

# SITE_URL / FRONTEND_URL — placeholder نباید اجازه‌ی بالا آمدن بدهد
SITE_URL = os.getenv('SITE_URL', '')
FRONTEND_URL = os.getenv('FRONTEND_URL', '')
if not SITE_URL or any(p in SITE_URL for p in _PLACEHOLDERS):
    _fail('SITE_URL در Production تنظیم نشده یا placeholder است '
          '(مثلاً your-domain.example).')
if not FRONTEND_URL or any(p in FRONTEND_URL for p in _PLACEHOLDERS):
    _fail('FRONTEND_URL در Production تنظیم نشده یا placeholder است.')

# P0-11: SMS — بدون provider واقعی، production نباید بالا بیاید
SMS_PROVIDER = os.getenv('SMS_PROVIDER', '')
SMS_API_KEY = os.getenv('SMS_API_KEY', '')
if not SMS_PROVIDER or not SMS_API_KEY:
    _fail('SMS_PROVIDER و SMS_API_KEY در Production باید تنظیم شوند. '
          'بدون سرویس پیامک واقعی، OTP/اعلان‌ها fail-closed خواهند بود.')
# fail-closed در زمان اجرا هم (نه فقط startup)
SMS_FAIL_CLOSED = True

# Redis (channel layer + celery + cache)
if not os.getenv('REDIS_URL') and not os.getenv('CELERY_BROKER_URL'):
    _fail('REDIS_URL یا CELERY_BROKER_URL در Production تنظیم نشده است.')

# Zarinpal — در حالت غیر sandbox نباید placeholder باشد
ZARINPAL_MERCHANT_ID = os.getenv('ZARINPAL_MERCHANT_ID', '')
if not ZARINPAL_SANDBOX and (not ZARINPAL_MERCHANT_ID or ZARINPAL_MERCHANT_ID == 'your_merchant_id'):
    _fail('ZARINPAL_MERCHANT_ID در Production (غیر sandbox) تنظیم نشده یا placeholder است.')

# DATABASE — در Production sqlite مجاز نیست
if os.getenv('DB_ENGINE', 'django.db.backends.sqlite3') == 'django.db.backends.sqlite3':
    _fail('DB_ENGINE=sqlite3 در Production مجاز نیست. از PostgreSQL استفاده کنید.')

# ================================================================
# دیتابیس - در Production ترجیحاً PostgreSQL (پیش‌فرض SQLite برای تست)
# ================================================================
DATABASES = {
    'default': {
        'ENGINE': os.getenv('DB_ENGINE', 'django.db.backends.sqlite3'),
        'NAME': os.getenv('DB_NAME', str(BASE_DIR / 'db.sqlite3')),
        'USER': os.getenv('DB_USER', ''),
        'PASSWORD': os.getenv('DB_PASSWORD', ''),
        'HOST': os.getenv('DB_HOST', ''),
        'PORT': os.getenv('DB_PORT', ''),
        'CONN_MAX_AGE': int(os.getenv('DB_CONN_MAX_AGE', 60)),
    }
}

# ================================================================
# کش با Redis (به‌جای LocMemCache تک‌پردازه‌ی settings.py پایه)
# ================================================================
REDIS_URL = os.getenv('REDIS_URL', 'redis://localhost:6379/1')
CACHES = {
    'default': {
        'BACKEND': 'django_redis.cache.RedisCache',
        'LOCATION': REDIS_URL,
        'OPTIONS': {
            'CLIENT_CLASS': 'django_redis.client.DefaultClient',
        }
    }
}

# ================================================================
# Channels (WebSocket) با Redis - نسخه‌ی پایه InMemory است که بین
# چند worker/پردازش کار نمی‌کند (اعلان بلادرنگ در Production نیاز به این دارد)
# ================================================================
CHANNEL_LAYERS = {
    'default': {
        'BACKEND': 'channels_redis.core.RedisChannelLayer',
        'CONFIG': {
            'hosts': [os.getenv('CHANNEL_REDIS_URL', 'redis://localhost:6379/2')],
        },
    },
}

# ================================================================
# Celery با Redis (نسخه‌ی پایه memory:// است که فقط برای تست تک‌پردازه است)
# ================================================================
CELERY_BROKER_URL = os.getenv('CELERY_BROKER_URL', 'redis://localhost:6379/0')
CELERY_RESULT_BACKEND = os.getenv('CELERY_RESULT_BACKEND', 'redis://localhost:6379/0')

# ================================================================
# ایمیل واقعی (SMTP) - نسخه‌ی پایه فقط console/بدون تنظیم است
# ================================================================
EMAIL_BACKEND = 'django.core.mail.backends.smtp.EmailBackend'
EMAIL_HOST = os.getenv('EMAIL_HOST', 'smtp.gmail.com')
EMAIL_PORT = int(os.getenv('EMAIL_PORT', 587))
EMAIL_HOST_USER = os.getenv('EMAIL_HOST_USER', '')
EMAIL_HOST_PASSWORD = os.getenv('EMAIL_HOST_PASSWORD', '')
EMAIL_USE_TLS = os.getenv('EMAIL_USE_TLS', 'True') == 'True'
DEFAULT_FROM_EMAIL = os.getenv('DEFAULT_FROM_EMAIL', 'noreply@inspectpro.ir')

# ================================================================
# هدرهای امنیتی HTTPS (DEBUG در این ماژول همیشه False است — بالا چک شد)
# ================================================================
# EDRA v5 — CRITICAL-01: رفع redirect loop پشت Nginx.
# ۱) SECURE_PROXY_SSL_HEADER: به Django می‌گوید X-Forwarded-Proto از
#    Nginx قابل اعتماد است (درخواست‌های واقعی کاربر HTTPS تشخیص داده شود).
# ۲) SECURE_SSL_REDIRECT به‌صورت پیش‌فرض False است؛ redirect به HTTPS را
#    خود Nginx انجام می‌دهد (deploy/nginx.conf). اگر بخواهید Django هم
#    redirect کند (مثلاً بدون Nginx)، SECURE_SSL_REDIRECT=true بگذارید —
#    فقط در آن صورت healthcheck داخلی Compose باید هدر
#    X-Forwarded-Proto: https را شبیه‌سازی کند (الان docker-compose این
#    کار را می‌کند).
SECURE_PROXY_SSL_HEADER = ('HTTP_X_FORWARDED_PROTO', 'https')
SECURE_SSL_REDIRECT = os.getenv('SECURE_SSL_REDIRECT', 'False') == 'True'
SESSION_COOKIE_SECURE = True
CSRF_COOKIE_SECURE = True
SECURE_HSTS_SECONDS = int(os.getenv('SECURE_HSTS_SECONDS', 31536000))
SECURE_HSTS_INCLUDE_SUBDOMAINS = True
SECURE_HSTS_PRELOAD = True
SECURE_CONTENT_TYPE_NOSNIFF = True

# ================================================================
# فایل‌های استاتیک/رسانه - همان مسیرهای settings پایه (اینجا فقط برای
# تاکید صریح تکرار شده، تغییری نمی‌کند)
# ================================================================
STATIC_ROOT = BASE_DIR / 'staticfiles'
MEDIA_ROOT = BASE_DIR / 'media'

# CORS از بخش اعتبارسنجی startup بالا می‌آید (فقط دامنه‌های واقعی مجازند).

# ================================================================
# لاگ‌گیری Production - JSON ساختاریافته (P2/P1-10) + فایل ERROR
# هر لاگ یک شیء JSON تک‌خطی با request_id است (خوراک ELK/Sentry/جمع‌آور).
# ================================================================
LOGGING = {
    'version': 1,
    'disable_existing_loggers': False,
    'formatters': {
        'json': {
            '()': 'core.logging.JsonFormatter',
        },
    },
    'handlers': {
        'console': {
            'class': 'logging.StreamHandler',
            'formatter': 'json',
        },
        'file': {
            'level': 'ERROR',
            'class': 'logging.FileHandler',
            'filename': BASE_DIR / 'logs' / 'django.log',
            'formatter': 'json',
        },
    },
    'root': {
        'handlers': ['console', 'file'],
        'level': 'INFO',
    },
    'loggers': {
        'django': {
            'handlers': ['console', 'file'],
            'level': os.getenv('DJANGO_LOG_LEVEL', 'INFO'),
            'propagate': False,
        },
        'core': {
            'handlers': ['console', 'file'],
            'level': 'INFO',
            'propagate': False,
        },
        'celery': {
            'handlers': ['console', 'file'],
            'level': 'INFO',
            'propagate': False,
        },
    },
}

from django.contrib import admin
from django.urls import path, include
from django.conf import settings
from django.conf.urls.static import static
from django.contrib.staticfiles.urls import staticfiles_urlpatterns
from django.contrib.auth import views as auth_views
from django.shortcuts import redirect
from django.http import HttpResponse, JsonResponse
from django.contrib.auth import logout
from django.views.decorators.http import require_POST
from django.db import connections
from rest_framework.permissions import AllowAny
from core.permissions import IsAdminUserOrGroup
from rest_framework.throttling import ScopedRateThrottle
from rest_framework_simplejwt.views import (
    TokenObtainPairView, TokenRefreshView, TokenBlacklistView)
from drf_spectacular.views import SpectacularAPIView, SpectacularSwaggerView


class TokenObtainPairThrottledView(TokenObtainPairView):
    """P1-09: محدودیت تلاش لاگین (ضد brute-force)."""
    throttle_classes = [ScopedRateThrottle]
    throttle_scope = 'login'


class TokenRefreshThrottledView(TokenRefreshView):
    """P1-09: محدودیت نرخ refresh token."""
    throttle_classes = [ScopedRateThrottle]
    throttle_scope = 'refresh'


class TokenBlacklistAllowAnyView(TokenBlacklistView):
    """
    HIGH-05/P0-05: logout باید بدون Authorization کار کند — فرانت‌اند توکن
    را در کوکی httpOnly دارد و نمی‌تواند header بفرستد. بلاک‌لیست کردن
    توکن خود کاربر (بدنه شامل refresh) خطر DoS ندارد چون refresh token
    تصادفی و غیرقابل حدس است.
    """
    permission_classes = [AllowAny]


def favicon(request):
    return HttpResponse(status=204)


def health_live(request):
    """P1-12: liveness probe — فرآیند زنده است."""
    return JsonResponse({'status': 'ok'})


def health_ready(request):
    """P1-12: readiness probe — دیتابیس و کش در دسترس‌اند."""
    try:
        connections['default'].cursor().execute('SELECT 1')
    except Exception:
        return JsonResponse({'status': 'unavailable'}, status=503)
    try:
        from django.core.cache import cache
        cache.set('health_check', '1', 5)
        cache.get('health_check')
    except Exception:
        return JsonResponse({'status': 'degraded'}, status=503)
    return JsonResponse({'status': 'ok'})


def metrics_view(request):
    """
    P2: خروجی متریک Prometheus — فقط برای کاربران Admin/staff.
    (افشای متریک‌های داخلی برای عموم توصیه نمی‌شود.)
    """
    if not (request.user.is_authenticated
            and (request.user.is_staff
                 or request.user.groups.filter(name='Admin').exists())):
        return JsonResponse({'error': 'دسترسی غیرمجاز'}, status=403)
    from django_prometheus.exports import ExportToDjangoView
    return ExportToDjangoView(request)


def home(request):
    return redirect('/admin/')


# EDRA v7 — SEC-02: logout دیگر با GET و csrf_exempt انجام نمی‌شود.
# حالا POST-only + CSRF-protected است (طبق استاندارد Django admin).
# قالب‌های Admin (unfold) دکمه logout را به‌صورت فرم POST با CSRF token
# ارسال می‌کنند؛ درخواست GET → 405.
@require_POST
def logout_view(request):
    logout(request)
    return redirect('/admin/')


urlpatterns = [
    path('', home, name='home'),
    path('admin/logout/', logout_view, name='custom_logout'),

    # ===== مسیرهای بازیابی رمز =====
    path('admin/password_reset/',
         auth_views.PasswordResetView.as_view(
             template_name='admin/password_reset_form.html',
             email_template_name='admin/password_reset_email.html',
             subject_template_name='admin/password_reset_subject.txt',
             success_url='/admin/password_reset/done/'
         ),
         name='admin_password_reset'),

    path('admin/password_reset/done/',
         auth_views.PasswordResetDoneView.as_view(
             template_name='admin/password_reset_done.html'
         ),
         name='password_reset_done'),

    path('admin/reset/<uidb64>/<token>/',
         auth_views.PasswordResetConfirmView.as_view(
             template_name='admin/password_reset_confirm.html',
             success_url='/admin/reset/done/'
         ),
         name='password_reset_confirm'),

    path('admin/reset/done/',
         auth_views.PasswordResetCompleteView.as_view(
             template_name='admin/password_reset_complete.html'
         ),
         name='password_reset_complete'),

    # ===== ادمین =====
    path('admin/', admin.site.urls),

    # ===== سایر مسیرها =====
    path('favicon.ico', favicon),
    path('health/live/', health_live, name='health_live'),
    path('health/ready/', health_ready, name='health_ready'),
    path('metrics/', metrics_view, name='prometheus_metrics'),
    path(
        'api/token/',
        TokenObtainPairThrottledView.as_view(),
        name='token_obtain_pair'),
    path(
        'api/token/refresh/',
        TokenRefreshThrottledView.as_view(),
        name='token_refresh'),
    # HIGH-05/P0-05: logout واقعی — refresh token باید blacklist شود.
    # (قبلاً این route ثبت نشده بود و logout فقط cookie را پاک می‌کرد.)
    path(
        'api/token/blacklist/',
        TokenBlacklistAllowAnyView.as_view(),
        name='token_blacklist'),
    # EDRA v13 — P1 #6: Swagger فقط در staging؛ در Production مسیرها به
    # IsAdminUserOrGroup محدود می‌شوند (SWAGGER_PUBLIC=false → 403 برای غیرادمین).
    path(
        'api/schema/',
        SpectacularAPIView.as_view(
            permission_classes=(
                [AllowAny]
                if getattr(settings, 'SWAGGER_PUBLIC', False)
                else [IsAdminUserOrGroup]),
            urlconf=settings.ROOT_URLCONF),
        name='schema'),
    path(
        'api/docs/',
        SpectacularSwaggerView.as_view(
            url_name='schema'),
        name='swagger-ui'),
    path('api/core/', include('core.urls')),
    path('api/expert/', include('core.expert.urls')),
    path('api/pricing/', include('pricing.urls')),
    path('api/inspections/', include('inspections.urls')),
    path('api/notifications/', include('notifications.urls')),
    path('api/public/', include('public.urls')),
    # EDRA v14 — HIGH 3.2: include('allauth.urls') حذف شد — مسیر موازی
    # ثبت‌نام/ورود allauth بی‌استفاده، سطح حمله‌ی زنده بود (کل امنیت
    # پروژه حول OTP طراحی شده است).
    path('api/support/', include('support.urls')),
    path('api/discounts/', include('discounts.urls')),  # ✅ اضافه شده
]

if settings.DEBUG:
    urlpatterns += static(settings.STATIC_URL,
                          document_root=settings.STATIC_ROOT)
    urlpatterns += static(settings.MEDIA_URL,
                          document_root=settings.MEDIA_ROOT)
    urlpatterns += staticfiles_urlpatterns()

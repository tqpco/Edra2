"""
edra/ws_auth.py

احراز هویت WebSocket — P0-08/HIGH-06.

معماری قبلی: access JWT از httpOnly cookie خارج و به جاوااسکریپت داده
می‌شد و سپس در query string (?token=...) ارسال می‌شد. ریسک‌ها:
  - JWT در URL/log/proxy history ثبت می‌شود
  - در صورت XSS، access token اصلی قابل برداشت است

معماری جدید: کلاینت ابتدا POST /api/notifications/ws-ticket/ می‌زند و یک
ticket تصادفی یکبارمصرف با TTL کوتاه (۶۰ ثانیه) می‌گیرد؛ سپس با
?ticket=... به WebSocket وصل می‌شود. این middleware ticket را در cache
اعتبارسنجی کرده، بلافاصله حذف می‌کند (single-use) و کاربر را در
scope['user'] قرار می‌دهد.
"""
from urllib.parse import parse_qs

from channels.db import database_sync_to_async
from django.contrib.auth import get_user_model
from django.contrib.auth.models import AnonymousUser
from django.core.cache import cache

User = get_user_model()


def _consume_ticket(ticket: str):
    """
    مصرف اتمیک ticket: شناسه کاربر را برمی‌گرداند و ticket را در یک
    عملیات اتمیک حذف می‌کند (single-use بدون race condition).

    روی Redis (django-redis) از دستور اتمیک GETDEL استفاده می‌شود؛
    برای سایر backends (LocMemCache و...) fallback به get+delete است که
    روی آن backend ها single-process هستند و race وجود ندارد.
    اگر ticket وجود نداشته باشد یا منقضی شده باشد → None.
    """
    if not ticket:
        return None
    key = f'ws_ticket_{ticket}'
    try:
        # django-redis: دسترسی به client اصلی Redis برای GETDEL اتمیک
        client = cache.client.get_client(write=True)
        if hasattr(client, 'getdel'):
            user_id = client.getdel(key)
            return user_id.decode('utf-8') if isinstance(user_id, bytes) else user_id
    except (AttributeError, TypeError, ValueError):
        pass  # backend غیر Redis → fallback پایین

    # fallback برای backends غیر اتمیک (تک‌پردازه — بدون race)
    user_id = cache.get(key)
    if user_id is None:
        return None
    cache.delete(key)  # یکبارمصرف — replay با همین ticket rejected می‌شود
    return user_id


class WsTicketAuthMiddleware:
    """خواندن ticket از query string، مصرف و ست کردن scope['user']."""

    def __init__(self, inner):
        self.inner = inner

    async def __call__(self, scope, receive, send):
        query = parse_qs((scope.get('query_string') or b'').decode('utf-8'))
        ticket = (query.get('ticket') or [None])[0]
        user_id = await database_sync_to_async(_consume_ticket)(ticket)
        if user_id:
            scope['user'] = await self.get_user(user_id)
        else:
            scope['user'] = AnonymousUser()
        return await self.inner(scope, receive, send)

    @database_sync_to_async
    def get_user(self, user_id):
        try:
            return User.objects.get(id=user_id)
        except User.DoesNotExist:
            return AnonymousUser()

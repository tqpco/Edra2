from drf_spectacular.generators import SchemaGenerator
import django
import json
import os
import logging
logger = logging.getLogger(__name__)
# export_openapi.py
# خروجي OpenAPI (JSON) براي مستندات API
# اجرا: python export_openapi.py

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'edra.settings')
django.setup()


generator = SchemaGenerator()
schema = generator.get_schema(request=None, public=True)

with open('openapi.json', 'w', encoding='utf-8') as f:
    json.dump(schema, f, indent=2, ensure_ascii=False)

logger.info("✅ openapi.json created successfully!")

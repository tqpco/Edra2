from django.db import models
from django_jalali.db import models as jmodels
from django.contrib.auth import get_user_model
User = get_user_model()

# مدل‌های چک‌لیست و گزارش در core/models.py قرار دارند
# این فایل فقط برای ساختار اپ است

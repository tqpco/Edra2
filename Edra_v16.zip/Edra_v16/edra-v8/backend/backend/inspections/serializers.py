# backend/inspections/serializers.py
from rest_framework import serializers
from django.utils import timezone
import jdatetime
from core.models import (
    InspectionRequest, ChecklistTemplate, ChecklistItem,
    InspectionReport, ReportVerification, EquipmentType
)


def to_jalali(dt):
    if not dt:
        return None
    try:
        if timezone.is_aware(dt):
            dt = timezone.localtime(dt)
        else:
            dt = timezone.make_aware(dt, timezone.get_current_timezone())
        jalali = jdatetime.datetime.fromgregorian(datetime=dt)
        return jalali.strftime("%Y/%m/%d - %H:%M")
    except Exception:
        return str(dt)


class EquipmentTypeSerializer(serializers.ModelSerializer):
    class Meta:
        model = EquipmentType
        fields = ('id', 'code', 'name_fa', 'param_schema')


class InspectionRequestSerializer(serializers.ModelSerializer):
    equipment_type_detail = EquipmentTypeSerializer(
        source='equipment_type', read_only=True)

    class Meta:
        model = InspectionRequest
        fields = '__all__'
        read_only_fields = (
            'customer',
            'calculated_price',
            'final_price',
            'status',
            'created_at',
            'updated_at')


class ChecklistItemSerializer(serializers.ModelSerializer):
    """EDRA v5 (MEDIUM-34): فیلدهای صریح (نه __all__)."""
    class Meta:
        model = ChecklistItem
        fields = (
            'id', 'category', 'title', 'description', 'order',
            'requires_photo', 'requires_note', 'is_critical', 'is_active')


class ChecklistTemplateSerializer(serializers.ModelSerializer):
    """
    EDRA v5 (MEDIUM-26): فیلدهای صریح + items_count برای جلوگیری از N+1
    در صفحه ادمین (لیست قالب‌ها بدون دریافت nested items).
    """
    items = ChecklistItemSerializer(many=True, read_only=True)
    items_count = serializers.SerializerMethodField()
    created_at_jalali = serializers.SerializerMethodField()
    updated_at_jalali = serializers.SerializerMethodField()

    class Meta:
        model = ChecklistTemplate
        fields = (
            'id', 'name', 'description', 'version', 'equipment_type',
            'is_active', 'items', 'items_count',
            'created_at_jalali', 'updated_at_jalali')

    def get_items_count(self, obj):
        return obj.items.filter(is_active=True).count()

    def get_created_at_jalali(self, obj):
        return to_jalali(obj.created_at)

    def get_updated_at_jalali(self, obj):
        return to_jalali(obj.updated_at)


class InspectionReportSerializer(serializers.ModelSerializer):
    """
    EDRA v5 — CRITICAL-09: فیلدهای صریح (نه __all__). برای خواندن/لیست.
    تغییرات فقط از طریق submit_results / sign_report انجام می‌شود، نه PATCH عمومی.
    """
    inspection_request_detail = InspectionRequestSerializer(
        source='inspection_request', read_only=True)
    overall_result_display = serializers.SerializerMethodField()
    created_at_jalali = serializers.SerializerMethodField()
    updated_at_jalali = serializers.SerializerMethodField()
    signed_at_jalali = serializers.SerializerMethodField()

    class Meta:
        model = InspectionReport
        fields = (
            'id', 'inspection_request', 'inspection_request_detail',
            'report_number', 'checklist_template_version', 'results',
            'overall_result', 'overall_result_display', 'inspector_notes',
            'gps_start_lat', 'gps_start_lng', 'gps_end_lat', 'gps_end_lng',
            'gps_distance_meters', 'inspection_started_at',
            'inspection_ended_at', 'pdf_file', 'signed_pdf_file',
            'signature_hash', 'signed_by', 'signed_at', 'signed_at_jalali',
            'created_at', 'created_at_jalali', 'updated_at',
            'updated_at_jalali')
        read_only_fields = fields

    def get_overall_result_display(self, obj):
        return obj.get_overall_result_display() if obj.overall_result else None

    def get_created_at_jalali(self, obj):
        return to_jalali(obj.created_at)

    def get_updated_at_jalali(self, obj):
        return to_jalali(obj.updated_at)

    def get_signed_at_jalali(self, obj):
        return to_jalali(obj.signed_at)


class InspectionReportUpdateSerializer(serializers.ModelSerializer):
    """
    EDRA v5 — CRITICAL-09: serializer محدود برای update/partial_update.
    فقط یادداشت کارشناس قابل ویرایش است؛ بقیه فقط از سرویس/اکشن‌ها.
    """
    class Meta:
        model = InspectionReport
        fields = ('inspector_notes',)


class ReportVerificationSerializer(serializers.ModelSerializer):
    report_number = serializers.CharField(
        source='report.report_number', read_only=True)
    inspection_request_id = serializers.IntegerField(
        source='report.inspection_request.id', read_only=True)
    equipment_name = serializers.CharField(
        source='report.inspection_request.equipment_type.name_fa',
        read_only=True)
    overall_result = serializers.CharField(
        source='report.overall_result', read_only=True)
    signed_at = serializers.DateTimeField(
        source='report.signed_at', read_only=True)
    created_at_jalali = serializers.SerializerMethodField()
    last_viewed_at_jalali = serializers.SerializerMethodField()

    class Meta:
        model = ReportVerification
        fields = (
            'verification_code',
            'report_number',
            'inspection_request_id',
            'equipment_name',
            'overall_result',
            'signed_at',
            'view_count',
            'last_viewed_at',
            'created_at_jalali',
            'last_viewed_at_jalali')

    def get_created_at_jalali(self, obj):
        return to_jalali(obj.created_at)

    def get_last_viewed_at_jalali(self, obj):
        return to_jalali(obj.last_viewed_at)

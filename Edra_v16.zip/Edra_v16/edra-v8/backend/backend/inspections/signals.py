from django.db.models.signals import post_save
from django.dispatch import receiver
from django.utils import timezone
import logging

from core.models import InspectionReport
from core.tasks import generate_report_pdf_task

logger = logging.getLogger(__name__)


@receiver(post_save, sender=InspectionReport)
def auto_generate_report_pdf(sender, instance, created, **kwargs):
    """
    سیگنال برای تولید خودکار PDF پس از ایجاد گزارش
    (در صورت عدم وجود فایل PDF)
    """
    if created and not instance.pdf_file:
        # ارسال تسک به Celery برای تولید PDF
        generate_report_pdf_task.delay(
            instance.id, instance.inspection_request.customer.id)
        logger.info(
            f"PDF generation task queued for report {
                instance.report_number}")

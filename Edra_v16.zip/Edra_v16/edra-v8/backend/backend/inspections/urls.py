from django.urls import path, include
from rest_framework.routers import DefaultRouter
from .views import (
    ExpertQueueViewSet,
    ChecklistTemplateViewSet,
    InspectionReportViewSet,
    ReportVerificationView,
)

app_name = "inspections"

router = DefaultRouter()
router.register(
    r'checklist-templates',
    ChecklistTemplateViewSet,
    basename='checklist_templates')
router.register(
    r'inspection-reports',
    InspectionReportViewSet,
    basename='inspection_reports')
router.register(r'expert-queue', ExpertQueueViewSet, basename='expert_queue')

urlpatterns = [
    path('', include(router.urls)),
    # مسیر استعلام عمومی گزارش (بدون نیاز به احراز هویت)
    path(
        'report-verification/<str:code>/',
        ReportVerificationView.as_view(),
        name='report_verification'),
]

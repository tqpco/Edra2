import hashlib
import secrets
import string
from django.db import transaction
from django.utils import timezone
from django.core.files.base import ContentFile
from django.conf import settings
from core.models import SequenceCounter, ReportVerification
import logging

# تلاش برای import تبدیل تاریخ جلالی – در صورت عدم نصب، fallback
try:
    from django_jalali.utils import to_jalali as jalali_convert  # type: ignore
except ImportError:
    jalali_convert = None

logger = logging.getLogger(__name__)


def generate_report_number(equipment_code):
    """
    تولید شماره گزارش بر اساس کد تجهیز و شمارنده ترتیبی
    مثال: TWR-2025-001
    """
    # P1 (EDRA v9): شمارنده بدون قفل race داشت — حالا select_for_update
    year = timezone.now().year
    with transaction.atomic():
        counter, _ = SequenceCounter.objects.select_for_update().get_or_create(
            key=f'report_{equipment_code}_{year}',
            defaults={'value': 0}
        )
        counter.value += 1
        counter.save()
    return f"{equipment_code.upper()}-{year}-{str(counter.value).zfill(3)}"


def generate_verification_code(report_number):
    """
    تولید کد استعلام ۱۲ رقمی تصادفی
    P1 (EDRA v9): از secrets (CSPRNG) به‌جای random استفاده می‌شود.
    """
    chars = string.ascii_uppercase + string.digits
    code = ''.join(secrets.choice(chars) for _ in range(12))
    # اطمینان از یکتا بودن
    while ReportVerification.objects.filter(verification_code=code).exists():
        code = ''.join(secrets.choice(chars) for _ in range(12))
    return code


def to_jalali(date):
    """
    تبدیل تاریخ میلادی به شمسی (با استفاده از django-jalali)
    اگر پکیج نصب نباشد، تاریخ میلادی را به صورت رشته برمی‌گرداند.
    """
    if not date:
        return None
    if jalali_convert is not None:
        return jalali_convert(date)
    else:
        logger.warning(
            "django_jalali not installed. Returning Gregorian date as string.")
        return date.strftime("%Y-%m-%d %H:%M:%S")


def generate_pdf_report(report, request=None):
    """
    تولید فایل PDF گزارش و ذخیره آن در مدل
    از core.report_pdf_generator استفاده می‌کند
    """
    try:
        from core.report_pdf_generator import generate_report_pdf as core_generate_pdf
        from core.models import InspectionReport

        inspection_request = report.inspection_request
        customer = inspection_request.customer
        equipment = inspection_request.equipment_type
        checklist_items = report.results if report.results else []

        pdf_content = core_generate_pdf(
            report=report,
            inspection_request=inspection_request,
            customer=customer,
            equipment=equipment,
            checklist_items=checklist_items
        )

        filename = f"report_{report.report_number}.pdf"
        report.pdf_file.save(filename, ContentFile(pdf_content), save=True)
        report.save()
        logger.info(f"PDF generated for report {report.report_number}")
        return True
    except Exception as e:
        logger.error(f"Error generating PDF for report {report.id}: {e}")
        raise


def sign_pdf_with_pyhanko(pdf_content, cert_path=None, key_path=None, key_password=None):
    """
    امضای دیجیتال PDF (PAdES) با pyHanko — اصلاح PDF-02 از گزارش ممیزی.

    - اگر گواهی/کلید در settings (PDF_SIGN_CERT_PATH/PDF_SIGN_KEY_PATH) یا
      آرگومان‌ها تنظیم شده باشد، امضای واقعی PAdES روی PDF اعمال می‌شود.
    - در غیر این صورت تابع به‌صورت شفاف log می‌کند که امضا فعال نیست و
      همان محتوا را برمی‌گرداند (signature_hash صرفاً یکپارچگی است، نه امضا).

    توجه: برای امضای معتبر حقوقی، cert/key باید معتبر و در زنجیره اعتماد
    باشند. امضای self-signed فقط یکپارچگی/اصالت فنی فراهم می‌کند.
    """
    cert_path = cert_path or getattr(settings, 'PDF_SIGN_CERT_PATH', None)
    key_path = key_path or getattr(settings, 'PDF_SIGN_KEY_PATH', None)
    # رشته خالی در .env یعنی بدون رمز → باید None شود وگرنه
    # SimpleSigner.load با passphrase خالی برای کلید بدون رمز None برمی‌گرداند
    key_password = key_password or getattr(
        settings, 'PDF_SIGN_KEY_PASSWORD', None) or None

    if not (cert_path and key_path):
        logger.warning(
            "PDF digital signature NOT applied: certificate/key not configured "
            "(set PDF_SIGN_CERT_PATH and PDF_SIGN_KEY_PATH in settings). "
            "Returning unsigned content; signature_hash covers integrity only.")
        return pdf_content

    try:
        import io

        from pyhanko.pdf_utils.incremental_writer import IncrementalPdfFileWriter
        from pyhanko.sign import sign_pdf, signers
        from pyhanko.sign.fields import SigFieldSpec

        signer = signers.SimpleSigner.load(
            key_file=key_path,
            cert_file=cert_path,
            key_passphrase=key_password,
        )
        writer = IncrementalPdfFileWriter(io.BytesIO(pdf_content))
        out = io.BytesIO()
        sign_pdf(
            writer,
            signature_meta=signers.PdfSignatureMetadata(
                field_name='EDRA_Signature',
                name='EDRA Inspection Platform',
                reason='تأیید رسمی گزارش بازرسی',
            ),
            signer=signer,
            output=out,
            new_field_spec=SigFieldSpec(
                'EDRA_Signature',
                box=(430, 40, 570, 90),  # گوشه پایین-چپ صفحه
            ),
        )
        signed_content = out.getvalue()
        logger.info(
            "PDF digitally signed (PAdES) with certificate %s", cert_path)
        return signed_content
    except Exception as e:
        logger.error(f"PDF digital signature failed: {e}")
        raise

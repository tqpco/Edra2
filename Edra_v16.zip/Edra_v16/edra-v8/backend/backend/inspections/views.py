# ============================================================
# ۴. inspections/views.py (فایل کامل اصلاح‌شده)
# ============================================================
from rest_framework import viewsets, status, generics, serializers
from rest_framework.decorators import action
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated, AllowAny
from rest_framework.throttling import ScopedRateThrottle
from core.permissions import IsAdminOrExpert, IsAdminUserOrGroup
from django.db import models, transaction
from django.utils import timezone
from django.shortcuts import get_object_or_404
from django.core.exceptions import PermissionDenied
from django.conf import settings
from core.validators import validate_excel_file

from django.http import HttpResponse
from core.models import (
    InspectionRequest, ChecklistTemplate, ChecklistItem,
    InspectionReport, SequenceCounter, ReportVerification
)
from core.tasks import generate_report_pdf_task
from .utils import generate_report_number, generate_verification_code, to_jalali
from .serializers import (
    InspectionReportSerializer,
    InspectionReportUpdateSerializer,
    ChecklistTemplateSerializer,
    ChecklistItemSerializer,
    EquipmentTypeSerializer,
    ReportVerificationSerializer,
    InspectionRequestSerializer as InspectionsRequestSerializer,
)
import logging

logger = logging.getLogger(__name__)

# ============================================================
# ویوهای کارشناس
# ============================================================


class ExpertQueueViewSet(viewsets.ReadOnlyModelViewSet):
    """صف بازرسی‌های تخصیص‌یافته به کارشناس"""
    serializer_class = InspectionsRequestSerializer
    permission_classes = [IsAuthenticated]

    def get_queryset(self):
        # فقط درخواست‌هایی که به این کارشناس تخصیص داده شده‌اند
        return InspectionRequest.objects.filter(
            assigned_expert=self.request.user,
            status__in=['paid', 'scheduled']
        ).order_by('scheduled_at')


class ChecklistTemplateViewSet(viewsets.ReadOnlyModelViewSet):
    """مشاهده قالب‌های چک‌لیست (فقط ادمین و کارشناس)"""
    queryset = ChecklistTemplate.objects.filter(is_active=True)
    serializer_class = ChecklistTemplateSerializer
    permission_classes = [IsAdminOrExpert]

    @action(detail=True, methods=['get'])
    def items(self, request, pk=None):
        """دریافت آیتم‌های یک چک‌لیست"""
        template = self.get_object()
        items = template.items.filter(is_active=True).order_by('order')
        serializer = ChecklistItemSerializer(items, many=True)
        return Response(serializer.data)

    # ============================================================
    # FEATURE: ایمپورت آیتم‌های چک‌لیست از فایل Excel
    # ============================================================
    # ستون‌های موردانتظار فایل Excel (ردیف اول = هدرها)
    EXCEL_COLUMNS = {
        'category': 'دسته‌بندی',
        'title': 'عنوان',
        'description': 'توضیحات',
        'order': 'ترتیب',
        'requires_photo': 'نیاز به عکس',
        'requires_note': 'نیاز به یادداشت',
        'is_critical': 'نیاز حیاتی',   # اختیاری (HIGH-46)
    }
    MAX_IMPORT_ROWS = 500

    @action(detail=True, methods=['get'],
            permission_classes=[IsAdminUserOrGroup],
            url_path='import-template')
    def import_template(self, request, pk=None):
        """
        دانلود قالب Excel نمونه برای ایمپورت آیتم‌های چک‌لیست.
        GET /api/inspections/checklist-templates/{id}/import-template/
        """
        template = self.get_object()
        from openpyxl import Workbook
        from openpyxl.styles import Font, PatternFill, Alignment

        wb = Workbook()
        ws = wb.active
        ws.title = 'آیتم‌های چک‌لیست'
        ws.sheet_view.rightToLeft = True

        header_fill = PatternFill(
            start_color='1F2937', end_color='1F2937', fill_type='solid')
        header_font = Font(color='FFFFFF', bold=True, size=11)

        headers = list(self.EXCEL_COLUMNS.values())
        for col_idx, header in enumerate(headers, start=1):
            cell = ws.cell(row=1, column=col_idx, value=header)
            cell.fill = header_fill
            cell.font = header_font
            cell.alignment = Alignment(horizontal='center')

        # ردیف نمونه برای راهنمایی کاربر (ستون «نیاز حیاتی» اختیاری است)
        sample_row = [
            'سازه فلزی', 'بررسی سلامت جوش‌های اتصال', 'تست بصری جوش‌ها',
            1, 'بله', 'خیر', 'بله',
        ]
        for col_idx, value in enumerate(sample_row, start=1):
            ws.cell(row=2, column=col_idx, value=value)

        # عرض ستون‌ها
        for col_idx, header in enumerate(headers, start=1):
            ws.column_dimensions[
                chr(64 + col_idx)].width = max(len(header) + 4, 18)

        response = HttpResponse(
            content_type='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')
        filename = f'checklist_items_template_{template.id}.xlsx'
        response['Content-Disposition'] = f'attachment; filename="{filename}"'
        wb.save(response)
        return response

    @action(detail=True, methods=['post'],
            permission_classes=[IsAdminUserOrGroup],
            url_path='import-items')
    def import_items(self, request, pk=None):
        """
        ایمپورت آیتم‌های چک‌لیست از فایل Excel.
        POST /api/inspections/checklist-templates/{id}/import-items/
          (multipart/form-data با فیلد file)
        POST .../import-items/?preview=true  → فقط پیش‌نمایش، بدون ذخیره

        ستون‌ها (ردیف اول): دسته‌بندی | عنوان | توضیحات | ترتیب |
        نیاز به عکس | نیاز به یادداشت
        """
        template = self.get_object()
        preview = request.query_params.get('preview') in ('1', 'true', 'True')
        # EDRA v5 — HIGH-19: mode=replace آیتم‌های فعال قبلی را در همان
        # transaction حذف می‌کند (جلوگیری از duplicate با ایمپورت دوباره).
        mode = request.query_params.get('mode', 'append')
        if mode not in ('append', 'replace'):
            return Response({'error': 'mode باید append یا replace باشد.'},
                            status=400)

        uploaded = request.FILES.get('file')
        if not uploaded:
            return Response({'error': 'فایل Excel ارسال نشده است.'}, status=400)

        file_error = validate_excel_file(uploaded)
        if file_error:
            return Response({'error': file_error}, status=400)

        try:
            from openpyxl import load_workbook
            wb = load_workbook(uploaded, data_only=True)
        except Exception:
            return Response(
                {'error': 'فایل Excel قابل خواندن نیست.'}, status=400)

        ws = wb.active
        rows = list(ws.iter_rows(values_only=True))
        if len(rows) < 2:
            return Response(
                {'error': 'فایل حداقل باید یک ردیف هدر و یک ردیف داده داشته باشد.'},
                status=400)

        # نرمال‌سازی هدرها (پشتیبانی از نام‌های فارسی و انگلیسی)
        header_row = rows[0]
        col_map = {}  # index → normalized key
        for idx, raw in enumerate(header_row):
            if raw is None:
                continue
            normalized = str(raw).strip().replace(' ', '').lower()
            for key, fa_name in self.EXCEL_COLUMNS.items():
                fa_norm = fa_name.replace(' ', '').lower()
                if (normalized == fa_name or normalized == fa_norm
                        or normalized == key
                        or normalized == key.replace('_', '')):
                    col_map[idx] = key
                    break

        required = {'category', 'title'}
        missing = required - set(col_map.values())
        if missing:
            fa_missing = [self.EXCEL_COLUMNS[m] for m in sorted(missing)]
            return Response({
                'error': f'ستون‌های الزامی در فایل یافت نشد: '
                         f'{", ".join(fa_missing)}. لطفاً از فایل قالب '
                         f'نمونه (import-template) استفاده کنید.'
            }, status=400)

        parsed_items = []
        row_errors = []
        auto_order = 0
        seen_keys = set()
        seen_orders = set()

        _TRUE_VALUES = {'بله', 'true', '1', 'yes', 'y', 'checked'}
        _FALSE_VALUES = {'خیر', 'false', '0', 'no', 'n', 'unchecked', ''}

        def _to_bool(value, row_idx):
            """EDRA v5 — HIGH-20: مقدار نامعتبر boolean → خطای ردیف (نه silent False)."""
            if value is None:
                return False
            if isinstance(value, bool):
                return value
            s = str(value).strip().lower()
            if s in _TRUE_VALUES:
                return True
            if s in _FALSE_VALUES:
                return False
            raise ValueError(f'مقدار boolean نامعتبر: «{value}»')

        def _to_int(value):
            if value is None or str(value).strip() == '':
                return None
            try:
                return int(float(value))
            except (TypeError, ValueError):
                return None

        def _norm(s):
            # نرمال‌سازی Unicode (NFC) برای تشخیص یکسان تکراری‌ها
            import unicodedata
            return unicodedata.normalize('NFC', s)

        for row_idx, row in enumerate(rows[1:], start=2):
            # ردیف کاملاً خالی → رد شود
            if all(cell is None or str(cell).strip() == '' for cell in row):
                continue
            if len(parsed_items) + len(row_errors) >= self.MAX_IMPORT_ROWS:
                row_errors.append(
                    {'row': row_idx,
                     'error': f'تعداد ردیف‌ها بیشتر از حداکثر مجاز '
                              f'({self.MAX_IMPORT_ROWS}) است.'})
                break

            item = {}
            for idx, key in col_map.items():
                value = row[idx] if idx < len(row) else None
                item[key] = value

            category = _norm(str(item.get('category') or '').strip())
            title = _norm(str(item.get('title') or '').strip())

            if not category:
                row_errors.append(
                    {'row': row_idx, 'error': 'دسته‌بندی الزامی است.'})
                continue
            if not title:
                row_errors.append(
                    {'row': row_idx, 'error': 'عنوان الزامی است.'})
                continue
            if len(title) > 200:
                row_errors.append(
                    {'row': row_idx, 'error': 'عنوان نباید بیشتر از ۲۰۰ کاراکتر باشد.'})
                continue
            if len(category) > 100:
                row_errors.append(
                    {'row': row_idx, 'error': 'دسته‌بندی نباید بیشتر از ۱۰۰ کاراکتر باشد.'})
                continue
            description = _norm(str(item.get('description') or '').strip())
            if len(description) > 1000:
                row_errors.append(
                    {'row': row_idx, 'error': 'توضیحات نباید بیشتر از ۱۰۰۰ کاراکتر باشد.'})
                continue

            # HIGH-19: duplicate درون فایل (category+title)
            dup_key = (category, title)
            if dup_key in seen_keys:
                row_errors.append(
                    {'row': row_idx,
                     'error': f'آیتم تکراری با همین عنوان قبلاً در فایل آمده: {title}'})
                continue
            seen_keys.add(dup_key)

            order = _to_int(item.get('order'))
            if order is None:
                auto_order += 1
                order = auto_order
            else:
                if order < 0:
                    row_errors.append(
                        {'row': row_idx, 'error': 'ترتیب نمی‌تواند منفی باشد.'})
                    continue
                if order in seen_orders:
                    row_errors.append(
                        {'row': row_idx, 'error': f'ترتیب تکراری: {order}.'})
                    continue
                seen_orders.add(order)

            try:
                requires_photo = _to_bool(item.get('requires_photo'), row_idx)
                requires_note = _to_bool(item.get('requires_note'), row_idx)
                is_critical = _to_bool(item.get('is_critical'), row_idx)
            except ValueError as e:
                row_errors.append({'row': row_idx, 'error': str(e)})
                continue

            parsed_items.append({
                'category': category,
                'title': title,
                'description': description,
                'order': order,
                'requires_photo': requires_photo,
                'requires_note': requires_note,
                'is_critical': is_critical,
            })

        if not parsed_items:
            return Response({
                'error': 'هیچ ردیف معتبری در فایل یافت نشد.',
                'errors': row_errors,
            }, status=400)

        # HIGH-19: آمار مقایسه با آیتم‌های موجود (جلوگیری از duplicate ناخواسته)
        existing_titles = set()
        if template.items.exists():
            existing_titles = {
                (i.category, i.title)
                for i in template.items.filter(is_active=True)}
        duplicate_existing = sum(
            1 for it in parsed_items
            if (it['category'], it['title']) in existing_titles)

        if preview:
            return Response({
                'preview': True,
                'template_id': template.id,
                'template_name': template.name,
                'mode': mode,
                'items': parsed_items,
                'errors': row_errors,
                'total': len(parsed_items),
                'existing_count': template.items.filter(is_active=True).count(),
                'duplicate_with_existing': duplicate_existing,
            })

        # ذخیره اتمیک
        # P1-03 (EDRA v8): در حالت replace، وجود هر row error یعنی آیتم‌های
        # قبلی غیرفعال می‌شوند و فقط ردیف‌های valid جایگزین می‌شوند → از
        # دست رفتن داده. بنابراین replace با خطا از سمت Backend مسدود است.
        if mode == 'replace' and row_errors:
            return Response({
                'error': (
                    'در حالت جایگزینی (Replace) خطاهای سطر وجود دارد و '
                    'ایمپورت مسدود است. ابتدا فایل را اصلاح کنید تا همه '
                    'سطرها معتبر شوند.'),
                'errors': row_errors,
                'items': parsed_items,
            }, status=400)

        with transaction.atomic():
            if mode == 'replace':
                # حذف آیتم‌های فعال قبلی (snapshot‌های گزارش‌شده دست‌نخورده‌اند
                # چون گزارش‌ها به template_version اشاره دارند، نه خود آیتم‌ها)
                template.items.filter(is_active=True).update(is_active=False)
            created = []
            for item in parsed_items:
                obj = ChecklistItem.objects.create(
                    checklist_template=template,
                    category=item['category'],
                    title=item['title'],
                    description=item['description'],
                    order=item['order'],
                    requires_photo=item['requires_photo'],
                    requires_note=item['requires_note'],
                    is_critical=item['is_critical'],
                )
                created.append(obj.id)

        return Response({
            'success': True,
            'message': f'{len(created)} آیتم با موفقیت به چک‌لیست '
                       f'«{template.name}» اضافه شد.',
            'template_id': template.id,
            'created_count': len(created),
            'errors': row_errors,
        })


class InspectionReportViewSet(viewsets.ModelViewSet):
    """مدیریت گزارش‌های بازرسی"""
    serializer_class = InspectionReportSerializer
    permission_classes = [IsAuthenticated]

    def get_queryset(self):
        user = self.request.user
        if user.is_staff:
            return InspectionReport.objects.all()
        return InspectionReport.objects.filter(
            inspection_request__assigned_expert=user
        )

    def get_serializer_class(self):
        # EDRA v5 — CRITICAL-09: update عمومی فقط یادداشت را اجازه می‌دهد
        if self.action in ('update', 'partial_update'):
            return InspectionReportUpdateSerializer
        return InspectionReportSerializer

    def perform_update(self, serializer):
        # CRITICAL-09: گزارش امضاشده/نهایی قابل تغییر نیست
        report = self.get_object()
        if report.signed_at is not None or report.signed_pdf_file:
            raise PermissionDenied(
                'گزارش امضا/نهایی شده و دیگر قابل ویرایش نیست.')
        super().perform_update(serializer)

    @action(detail=True, methods=['get'])
    def pdf(self, request, pk=None):
        """
        دانلود محافظتشده PDF گزارش (P0-8): کارشناس تعیین‌شده یا ادمین
        یا مالک درخواست. get_object از queryset محدودشده استفاده می‌کند.
        """
        from django.http import FileResponse
        report = self.get_object()
        file_field = report.signed_pdf_file or report.pdf_file
        if not file_field:
            return Response(
                {'error': 'PDF گزارش هنوز تولید نشده است.'}, status=404)
        return FileResponse(
            file_field.open('rb'),
            content_type='application/pdf',
            filename=f'{report.report_number}.pdf')

    @transaction.atomic
    def perform_create(self, serializer):
        """ایجاد گزارش جدید (شروع بازرسی)"""
        request = self.request
        inspection_request_id = request.data.get('inspection_request')

        inspection_request = get_object_or_404(
            InspectionRequest,
            id=inspection_request_id,
            assigned_expert=request.user
        )

        if hasattr(inspection_request, 'report'):
            raise serializers.ValidationError("این درخواست قبلاً گزارش دارد.")

        equipment_code = inspection_request.equipment_type.code
        report_number = generate_report_number(equipment_code)

        report = serializer.save(
            inspection_request=inspection_request,
            report_number=report_number,
            overall_result='pending'
        )

        inspection_request.status = 'in_progress'
        inspection_request.save()

        # ایجاد کد استعلام
        verification_code = generate_verification_code(report_number)
        ReportVerification.objects.create(
            report=report,
            verification_code=verification_code
        )

        return report

    @action(detail=True, methods=['post'])
    def submit_results(self, request, pk=None):
        """
        ثبت نتایج چک‌لیست و نهایی‌سازی گزارش.

        EDRA v5 (MEDIUM-27): همین سرویس یکپارچه‌ی ExpertSubmitChecklistView
        (report_service) استفاده می‌شود تا قوانین یکسان باشند:
        کامل‌بودن آیتم‌ها، نتیجه معتبر، note/photo الزامی، overall سمت
        سرور، و عدم تغییر گزارش امضاشده.
        """
        from core.services.report_service import (
            validate_and_finalize_existing, ChecklistSubmissionError)

        report = self.get_object()
        try:
            validate_and_finalize_existing(
                report,
                user=request.user,
                results=request.data.get('results', []),
                overall_result=request.data.get('overall_result'),
                inspector_notes=request.data.get('inspector_notes', ''),
                request=request,
            )
        except ChecklistSubmissionError as e:
            return Response({'error': str(e)}, status=e.status_code)

        # تولید PDF به صورت غیرهمزمان با Celery
        generate_report_pdf_task.delay(report.id, request.user.id)

        return Response({
            'message': 'نتایج ثبت شد و تولید گزارش در صف قرار گرفت.',
            'report_id': report.id,
            'report_number': report.report_number
        })

    @action(detail=True, methods=['post'])
    def sign_report(self, request, pk=None):
        """
        تأیید صحت گزارش (PDF-02):
        - اگر گواهی امضا تنظیم شده باشد (PDF_SIGN_CERT_PATH/PDF_SIGN_KEY_PATH)
          امضای واقعی PAdES با pyHanko اعمال می‌شود.
        - در غیر این صورت مهر یکپارچگی (SHA-256) ثبت می‌شود و لاگ شفاف
          می‌گوید که امضای PKI اعمال نشده است.
        """
        report = self.get_object()

        # P0-07 (EDRA v9): قبل از امضا باید نهایی بودن گزارش اثبات شود —
        # قبلاً فقط وجود pdf_file چک می‌شد و گزارش ناقص/stale قابل امضا بود.
        if not report.pdf_file:
            return Response(
                {'error': 'فایل PDF گزارش هنوز تولید نشده است.'}, status=400)
        if report.signed_at is not None or report.signed_pdf_file:
            return Response(
                {'error': 'این گزارش قبلاً امضا شده است.'}, status=400)
        if report.overall_result not in ('pass', 'fail'):
            return Response(
                {'error': 'نتیجه نهایی گزارش هنوز تعیین نشده است (pending).'},
                status=400)
        if report.inspection_request.status != 'completed':
            return Response(
                {'error': 'درخواست بازرسی هنوز تکمیل نشده است؛ امکان امضا نیست.'},
                status=400)
        if not report.results:
            return Response(
                {'error': 'نتایج چک‌لیست خالی است؛ امکان امضا نیست.'}, status=400)

        if report.inspection_request.assigned_expert != request.user and not request.user.is_staff:
            raise PermissionDenied("شما دسترسی به امضای این گزارش ندارید.")

        try:
            from django.core.files.base import ContentFile
            import hashlib
            from .utils import sign_pdf_with_pyhanko

            # خواندن محتوای PDF
            pdf_content = report.pdf_file.read()

            # امضای PAdES (در صورت تنظیم گواهی)؛ در غیر این صورت همان محتوا
            signed_content = sign_pdf_with_pyhanko(pdf_content)

            filename = f"report_{report.report_number}_signed.pdf"
            report.signed_pdf_file.save(
                filename, ContentFile(signed_content), save=True)
            report.signature_hash = hashlib.sha256(
                signed_content).hexdigest()
            report.signed_at = timezone.now()
            report.signed_by = request.user
            report.save()

            # ثبت لاگ ممیزی
            try:
                from core.models import AuditLog
                AuditLog.objects.create(
                    user=request.user,
                    action='sign_report',
                    object_id=report.id,
                    changes={'report_number': report.report_number,
                             'signature_hash': report.signature_hash[:16],
                             'pades': signed_content != pdf_content},
                )
            except Exception as log_error:
                logger.error(f"Error writing audit log: {log_error}")

            message = (
                'گزارش با موفقیت امضای دیجیتال (PAdES) گرفت و مهر یکپارچگی '
                'ثبت شد.'
                if signed_content != pdf_content else
                'گزارش تأیید شد و مهر یکپارچگی ثبت گردید. '
                '(امضای PKI فعال نیست؛ PDF_SIGN_CERT_PATH تنظیم نشده است.)')
            return Response({'message': message, 'signed': signed_content != pdf_content})

        except Exception as e:
            logger.error(f"Error signing PDF: {e}")
            return Response(
                {'error': f'خطا در امضای PDF: {str(e)}'}, status=500)


# ============================================================
# ویوهای عمومی (استعلام گزارش)
# ============================================================

class ReportVerificationView(generics.RetrieveAPIView):
    """استعلام عمومی گزارش با کد استعلام (P1 بند ۲۷: ضد enumeration)"""
    permission_classes = [AllowAny]
    serializer_class = ReportVerificationSerializer
    throttle_classes = [ScopedRateThrottle]
    throttle_scope = 'public_verify'

    def get_object(self):
        verification_code = self.kwargs.get('code')
        verification = get_object_or_404(
            ReportVerification,
            verification_code=verification_code)
        # EDRA v7 — PERF-01/P1-16: افزایش اتمیک (F()) به‌جای
        # read-modify-write که در ترافیک بالا Write Hotspot می‌شد.
        ReportVerification.objects.filter(pk=verification.pk).update(
            view_count=models.F('view_count') + 1,
            last_viewed_at=timezone.now())
        verification.view_count += 1
        verification.last_viewed_at = timezone.now()
        return verification

from django.contrib import admin
from jalali_date.admin import ModelAdminJalaliMixin
from .models import NotificationTemplate, NotificationLog
from core.utils.date_utils import to_jalali


class JalaliDateDisplayMixin:
    """نمایش تاریخ‌های خام به‌صورت جلالی در ستون‌های لیست ادمین"""

    def created_at_display(self, obj):
        return to_jalali(obj.created_at)
    created_at_display.short_description = "تاریخ ایجاد"

    def updated_at_display(self, obj):
        return to_jalali(obj.updated_at)
    updated_at_display.short_description = "تاریخ بروزرسانی"

    def sent_at_display(self, obj):
        return to_jalali(obj.sent_at)
    sent_at_display.short_description = "تاریخ ارسال"


@admin.register(NotificationTemplate)
class NotificationTemplateAdmin(
        JalaliDateDisplayMixin, ModelAdminJalaliMixin, admin.ModelAdmin):
    list_display = ('code', 'channel', 'subject', 'is_active',
                    'updated_at_display')
    list_filter = ('channel', 'is_active')
    search_fields = ('code', 'subject')
    ordering = ('code',)


@admin.register(NotificationLog)
class NotificationLogAdmin(
        JalaliDateDisplayMixin, ModelAdminJalaliMixin, admin.ModelAdmin):
    list_display = (
        'id', 'user', 'template', 'type', 'channel',
        'status', 'is_read', 'created_at_display',
    )
    list_filter = ('status', 'channel', 'type', 'is_read')
    search_fields = ('user__username', 'template__code', 'recipient', 'subject')
    readonly_fields = (
        'user', 'template', 'channel', 'type', 'subject', 'content',
        'recipient', 'error_message', 'sent_at', 'created_at',
    )
    ordering = ('-created_at',)

    def has_add_permission(self, request):
        # این لاگ‌ها فقط به‌صورت خودکار توسط سیستم ساخته می‌شوند، نه دستی
        return False

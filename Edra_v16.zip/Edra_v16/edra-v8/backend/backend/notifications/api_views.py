import secrets

from django.core.cache import cache
from rest_framework import viewsets
from rest_framework.permissions import IsAdminUser, IsAuthenticated
from rest_framework.response import Response
from core.permissions import IsAdminUserOrGroup
from .models import NotificationTemplate, NotificationLog
from .serializers import NotificationTemplateSerializer, NotificationLogSerializer

# عمر ticket اتصال WebSocket (ثانیه) — P0-08/HIGH-06
WS_TICKET_TTL_SECONDS = 60

# اصلاح NOT-01 از گزارش ممیزی: مدیریت Template/Log فقط برای Admin است.
# مشتریان فقط از طریق /api/core/notifications/ (user-scoped) اعلان خود را
# می‌بینند؛ این ViewSet ها نباید در معرض کاربر عادی قرار گیرند.


class NotificationTemplateViewSet(viewsets.ReadOnlyModelViewSet):
    """خواندن قالب‌های اعلان (تغییر فقط در پنل جنگو)."""
    queryset = NotificationTemplate.objects.all()
    serializer_class = NotificationTemplateSerializer
    permission_classes = [IsAdminUserOrGroup]


class NotificationLogViewSet(viewsets.ReadOnlyModelViewSet):
    """لاگ ارسال نوتیفیکیشن — فقط ادمین."""
    queryset = NotificationLog.objects.all().order_by('-created_at')
    serializer_class = NotificationLogSerializer
    permission_classes = [IsAdminUserOrGroup]


class WsTicketView(viewsets.ViewSet):
    """
    P0-08/HIGH-06: صدور ticket یکبارمصرف برای اتصال WebSocket.

    معماری امن:
      1. access JWT هرگز به جاوااسکریپت تحویل داده نمی‌شود (httpOnly cookie).
      2. برای WebSocket، کلاینت یک ticket تصادفی با عمر ۶۰ ثانیه می‌گیرد.
      3. ticket فقط یک بار قابل مصرف است (در اولین اتصال از cache حذف می‌شود)
         و در query string قرار می‌گیرد؛ افشای آن فقط یک اتصال کوتاه و
         محدود به همان کاربر می‌دهد، نه توکن اصلی.
    """

    permission_classes = [IsAuthenticated]

    def create(self, request):
        ticket = secrets.token_hex(32)
        cache.set(
            f'ws_ticket_{ticket}',
            request.user.id,
            timeout=WS_TICKET_TTL_SECONDS)
        return Response({
            'ticket': ticket,
            'expires_in': WS_TICKET_TTL_SECONDS,
        })

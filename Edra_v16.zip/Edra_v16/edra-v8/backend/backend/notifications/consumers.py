# notifications/consumers.py
import json
from channels.generic.websocket import AsyncWebsocketConsumer
from channels.db import database_sync_to_async
from django.contrib.auth import get_user_model
from .models import NotificationLog

User = get_user_model()


class NotificationConsumer(AsyncWebsocketConsumer):
    async def connect(self):
        self.user = self.scope['user']
        if not self.user.is_authenticated:
            await self.close()
            return

        self.room_group_name = f'user_{self.user.id}'
        await self.channel_layer.group_add(
            self.room_group_name,
            self.channel_name
        )
        await self.accept()

        # ارسال اعلان‌های خوانده‌نشده هنگام اتصال
        await self.send_unread_notifications()

    async def disconnect(self, close_code):
        if hasattr(self, 'room_group_name'):
            await self.channel_layer.group_discard(
                self.room_group_name,
                self.channel_name
            )

    async def receive(self, text_data):
        data = json.loads(text_data)
        action = data.get('action')

        if action == 'mark_read':
            notification_id = data.get('notification_id')
            await self.mark_notification_read(notification_id)
        elif action == 'mark_all_read':
            await self.mark_all_notifications_read()

    async def send_notification(self, event):
        """ارسال اعلان به کاربر"""
        await self.send(text_data=json.dumps({
            'type': 'notification',
            'data': event['data']
        }))

    async def send_unread_notifications(self):
        """ارسال اعلان‌های خوانده‌نشده"""
        notifications = await self.get_unread_notifications()
        if notifications:
            await self.send(text_data=json.dumps({
                'type': 'unread_notifications',
                'data': notifications
            }))

    @database_sync_to_async
    def get_unread_notifications(self):
        # نکته: «خوانده‌نشده» با فیلد is_read مشخص می‌شود، نه status
        # (status وضعیت ارسال است: pending/sent/failed - مستقل از خوانده‌شدن)
        # توجه: created_at را با isoformat سریال می‌کنیم چون json.dumps
        # نمی‌تواند مستقیم datetime را سریال کند (باگ قبلی: اتصال بعد از
        # accept با خطای TypeError بسته می‌شد و پیام هرگز به کلاینت نمی‌رسید)
        # P1-11 (EDRA v8): فقط ۵۰ اعلان اخیر ارسال می‌شود — کاربر با
        # هزاران اعلان خوانده‌نشده نباید payload بزرگ/memory-heavy بگیرد.
        rows = NotificationLog.objects.filter(
            user=self.user,
            is_read=False
        ).order_by('-created_at')[:50]
        return [{
            'id': r.id,
            'subject': r.subject,
            'content': r.content,
            'created_at': r.created_at.isoformat() if r.created_at else None,
            'type': r.type,
        } for r in rows]

    @database_sync_to_async
    def mark_notification_read(self, notification_id):
        try:
            notification = NotificationLog.objects.get(
                id=notification_id,
                user=self.user
            )
            notification.is_read = True
            notification.save(update_fields=['is_read'])
        except NotificationLog.DoesNotExist:
            pass

    @database_sync_to_async
    def mark_all_notifications_read(self):
        NotificationLog.objects.filter(
            user=self.user,
            is_read=False
        ).update(is_read=True)

# backend/notifications/serializers.py
from rest_framework import serializers
from django.utils import timezone
import jdatetime
from .models import NotificationTemplate, NotificationLog


def to_jalali(dt):
    if not dt:
        return None
    try:
        if timezone.is_aware(dt):
            dt = timezone.localtime(dt)
        else:
            dt = timezone.make_aware(dt, timezone.get_current_timezone())
        jalali = jdatetime.datetime.fromgregorian(datetime=dt)
        return jalali.strftime("%Y/%m/%d - %H:%M")
    except Exception:
        return str(dt)


class NotificationTemplateSerializer(serializers.ModelSerializer):
    created_at_jalali = serializers.SerializerMethodField()
    updated_at_jalali = serializers.SerializerMethodField()

    class Meta:
        model = NotificationTemplate
        fields = '__all__'

    def get_created_at_jalali(self, obj):
        return to_jalali(obj.created_at)

    def get_updated_at_jalali(self, obj):
        return to_jalali(obj.updated_at)


class NotificationLogSerializer(serializers.ModelSerializer):
    created_at_jalali = serializers.SerializerMethodField()
    sent_at_jalali = serializers.SerializerMethodField()

    class Meta:
        model = NotificationLog
        fields = '__all__'

    def get_created_at_jalali(self, obj):
        return to_jalali(obj.created_at)

    def get_sent_at_jalali(self, obj):
        return to_jalali(obj.sent_at)

# notifications/services.py
from django.core.mail import send_mail
from django.template import Template, Context
from django.conf import settings
from django.utils import timezone
from .models import NotificationTemplate, NotificationLog
import logging

logger = logging.getLogger(__name__)


class SMSProviderNotConfiguredError(Exception):
    """در Production بدون provider پیامک، ارسال SMS مجاز نیست."""


def _send_sms_via_provider(recipient, text):
    """
    ارسال SMS واقعی از طریق Kavenegar (در صورت پیکربندی).

    فعال‌سازی در .env:
      SMS_PROVIDER=kavenegar
      SMS_API_KEY=... کلید اختصاصی سرویس کاوه‌نگار ...

    P0-10/HIGH-07: محتوای پیام (که می‌تواند OTP باشد) هرگز در log ثبت
    نمی‌شود — فقط metadata (گیرنده/وضعیت/خطا).
    خروجی: (success: bool, error_message: str|None)
    """
    provider = getattr(settings, 'SMS_PROVIDER', None)
    api_key = getattr(settings, 'SMS_API_KEY', '')
    fail_closed = getattr(settings, 'SMS_FAIL_CLOSED', False)

    if not provider or not api_key:
        if fail_closed:
            # P0-11: fail-closed — بدون provider، هرگز mock نمی‌شویم و OTP
            # صادر نمی‌شود (فعال در settings_production).
            return False, 'SMS_PROVIDER/SMS_API_KEY تنظیم نشده است.'
        # حالت توسعه/تست: فقط metadata لاگ می‌شود (بدون body پیام)
        logger.info(f"[SMS MOCK] to={recipient} (بدون ارسال واقعی)")
        return True, None

    if provider == 'kavenegar':
        try:
            import requests
            url = f'https://api.kavenegar.com/v1/{api_key}/sms/send.json'
            resp = requests.post(
                url,
                data={'receptor': recipient, 'message': text},
                timeout=10)
            resp.raise_for_status()
            result = resp.json()
            status = result.get('return', {}).get('status')
            if status != 200:
                message = result.get('return', {}).get('message', 'نامشخص')
                logger.error(f"Kavenegar returned status {status}: {message}")
                return False, message
            return True, None
        except Exception as e:
            logger.error(f"Kavenegar SMS failed for {recipient}: {e}")
            return False, str(e)

    logger.error(f"Unknown SMS_PROVIDER: {provider}")
    return False, f'SMS_PROVIDER نامعتبر است: {provider}'


def send_sms(phone, message):
    """
    P0-11: ارسال SMS با fail-closed.

    - اگر SMS_FAIL_CLOSED=True (در settings_production همیشه) و provider
      تنظیم نشده باشد → SMSProviderNotConfiguredError (به‌جای mock و موفق
      برگشتن). صادرکننده‌ی OTP باید کد را باطل کند.
    - در Development/test بدون provider → mock (metadata-only log) و موفق.
    - محتوای پیام هرگز log نمی‌شود.
    """
    provider = getattr(settings, 'SMS_PROVIDER', None)
    api_key = getattr(settings, 'SMS_API_KEY', '')
    fail_closed = getattr(settings, 'SMS_FAIL_CLOSED', False)
    if fail_closed and (not provider or not api_key):
        raise SMSProviderNotConfiguredError(
            'SMS_PROVIDER/SMS_API_KEY تنظیم نشده است و SMS fail-closed است.')

    ok, error = _send_sms_via_provider(phone, message)
    if not ok:
        raise RuntimeError(error or 'ارسال SMS ناموفق بود.')
    return True


def send_notification(user, template_code, context=None, extra_recipient=None):
    """
    ارسال اعلان بر اساس قالب
    user: کاربر دریافت‌کننده
    template_code: کد قالب (مثلاً 'request_created')
    context: دیکشنری داده‌های جایگزین در قالب
    extra_recipient: در صورت نیاز، ایمیل یا شماره دیگری
    """
    if context is None:
        context = {}

    try:
        template = NotificationTemplate.objects.get(
            code=template_code, is_active=True)
    except NotificationTemplate.DoesNotExist:
        logger.error(f"Template {template_code} not found or inactive.")
        return

    context['user'] = user
    context['site_url'] = settings.SITE_URL if hasattr(
        settings, 'SITE_URL') else 'http://localhost:8000'

    body = Template(template.body_template).render(Context(context))

    recipient = extra_recipient
    if not recipient:
        if template.channel == 'email':
            recipient = user.email
        else:
            recipient = getattr(getattr(user, 'profile', None), 'phone', None)
            if not recipient:
                # کاربران OTP شماره موبایل را به‌عنوان username دارند
                recipient = user.username
            if not recipient:
                logger.warning(f"No phone for user {user.username}")
                return

    if not recipient:
        logger.warning(f"No recipient for user {user.username}")
        return

    log = NotificationLog.objects.create(
        user=user,
        template=template,
        channel=template.channel,
        type=template_code,
        recipient=recipient,
        subject=template.subject,
        content=body,
        status='pending'
    )

    try:
        if template.channel in ['email', 'both']:
            send_mail(
                subject=template.subject,
                message=body,
                from_email=settings.DEFAULT_FROM_EMAIL,
                recipient_list=[recipient],
                fail_silently=False,
            )
        if template.channel in ['sms', 'both']:
            sms_ok, sms_error = _send_sms_via_provider(recipient, body)
            if not sms_ok:
                raise Exception(f"SMS provider error: {sms_error}")

        log.status = 'sent'
        log.sent_at = timezone.now()
        log.save()
        logger.info(
            f"Notification sent to {recipient} for template {template_code}")
    except Exception as e:
        log.status = 'failed'
        log.error_message = str(e)
        log.save()
        logger.error(f"Failed to send notification: {e}")

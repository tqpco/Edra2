# notifications/signals.py
from django.db.models.signals import post_save
from django.dispatch import receiver
import logging
from channels.layers import get_channel_layer
from asgiref.sync import async_to_sync
from .models import NotificationLog

logger = logging.getLogger(__name__)


@receiver(post_save, sender=NotificationLog)
def notification_created(sender, instance, created, **kwargs):
    """
    سیگنال برای ارسال اعلان از طریق WebSocket
    """
    if created and instance.status == 'pending':
        channel_layer = get_channel_layer()
        try:
            async_to_sync(channel_layer.group_send)(
                f'user_{instance.user.id}',
                {
                    'type': 'send_notification',
                    'data': {
                        'id': instance.id,
                        'title': instance.subject,
                        'message': instance.content,
                        'created_at': instance.created_at.isoformat(),
                        'type': instance.type,
                        'status': instance.status,
                    }
                }
            )
            logger.info(
                f"WebSocket notification sent to user {
                    instance.user.id}")
        except Exception as e:
            logger.error(f"Error sending WebSocket notification: {e}")

from celery import shared_task
from django.conf import settings
from django.core.mail import send_mail
from django.utils import timezone
import logging

from .models import NotificationLog

logger = logging.getLogger(__name__)


@shared_task
def process_pending_notifications():
    """
    تسک دوره‌ای برای تلاش مجدد ارسال اعلان‌هایی که در دیتابیس ساخته شده‌اند
    ولی هنوز ارسال نشده‌اند (status='pending') - مثلاً اعلان‌های گروهی که
    مستقیماً در دیتابیس ثبت می‌شوند (نمونه: کد تخفیف جدید برای همه مشتریان).

    نکته مهم: این تسک عمداً send_notification() را دوباره صدا نمی‌زند؛
    آن تابع یک لاگ *جدید* می‌سازد و محتوای واقعی رندرشده (context اولیه)
    از دست می‌رفت و رکورد pending اصلی هم برای همیشه در همان وضعیت
    می‌ماند (یعنی هر بار اجرای این تسک دوباره پردازشش می‌کرد و پیام‌های
    تکراری تولید می‌شد). در عوض همان رکورد موجود را با محتوای ذخیره‌شده‌اش
    ارسال و وضعیت خودش را به‌روزرسانی می‌کند.
    """
    pending = NotificationLog.objects.filter(
        status='pending').select_related('user', 'user__profile')
    count = pending.count()
    if count == 0:
        return

    sent_count = 0
    failed_count = 0
    for notification in pending:
        try:
            recipient = notification.recipient
            if not recipient:
                if notification.channel == 'email':
                    recipient = notification.user.email
                else:
                    recipient = getattr(
                        getattr(notification.user, 'profile', None), 'phone', None)

            if not recipient:
                notification.status = 'failed'
                notification.error_message = 'گیرنده (ایمیل/موبایل) یافت نشد'
                notification.save(update_fields=['status', 'error_message'])
                failed_count += 1
                continue

            if notification.channel in ['email', 'both']:
                send_mail(
                    subject=notification.subject,
                    message=notification.content,
                    from_email=settings.DEFAULT_FROM_EMAIL,
                    recipient_list=[recipient],
                    fail_silently=False,
                )
            if notification.channel in ['sms', 'both']:
                logger.info(f"SMS to {recipient}: {notification.content}")

            notification.status = 'sent'
            notification.sent_at = timezone.now()
            notification.recipient = recipient
            notification.save(update_fields=['status', 'sent_at', 'recipient'])
            sent_count += 1
        except Exception as e:
            notification.status = 'failed'
            notification.error_message = str(e)
            notification.save(update_fields=['status', 'error_message'])
            failed_count += 1
            logger.error(
                f"Error processing notification {notification.id}: {e}")

    logger.info(
        f"Processed {count} pending notifications: {sent_count} sent, {failed_count} failed")

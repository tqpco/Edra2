from django.urls import path, include
from rest_framework.routers import DefaultRouter
from .api_views import (
    NotificationTemplateViewSet, NotificationLogViewSet, WsTicketView)

app_name = 'notifications'

router = DefaultRouter()
router.register(
    r'templates',
    NotificationTemplateViewSet,
    basename='notification_templates')
router.register(r'logs', NotificationLogViewSet, basename='notification_logs')

urlpatterns = [
    path('', include(router.urls)),
    # P0-08/HIGH-06: صدور ticket یکبارمصرف برای WebSocket (POST)
    path('ws-ticket/', WsTicketView.as_view({'post': 'create'}),
         name='ws_ticket'),
]

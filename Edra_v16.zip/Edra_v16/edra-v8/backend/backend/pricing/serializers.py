from rest_framework import serializers
from django.utils import timezone
import jdatetime
from .models import PricingRule, PricingRuleChangeLog, PriceCalculationLog, ParameterPrice
from core.models import EquipmentType


def to_jalali(dt):
    if not dt:
        return None
    try:
        if timezone.is_aware(dt):
            dt = timezone.localtime(dt)
        else:
            dt = timezone.make_aware(dt, timezone.get_current_timezone())
        jalali = jdatetime.datetime.fromgregorian(datetime=dt)
        return jalali.strftime("%Y/%m/%d - %H:%M")
    except Exception:
        return str(dt)


class ParameterPriceSerializer(serializers.ModelSerializer):
    class Meta:
        model = ParameterPrice
        fields = ['id', 'rate_type', 'rate']


class PricingRuleSerializer(serializers.ModelSerializer):
    equipment_type_name = serializers.CharField(
        source='equipment_type.name_fa', read_only=True)
    equipment_type_code = serializers.CharField(
        source='equipment_type.code', read_only=True)
    created_at_jalali = serializers.SerializerMethodField()
    updated_at_jalali = serializers.SerializerMethodField()
    parameter_prices = ParameterPriceSerializer(many=True, read_only=True)

    class Meta:
        model = PricingRule
        fields = '__all__'
        read_only_fields = ('id', 'created_at', 'updated_at')

    def get_created_at_jalali(self, obj):
        return to_jalali(obj.created_at)

    def get_updated_at_jalali(self, obj):
        return to_jalali(obj.updated_at)

    def validate(self, data):
        standard_multiplier = data.get('standard_multiplier', 0)
        pro_multiplier = data.get('pro_multiplier', 0)

        if standard_multiplier <= 0:
            raise serializers.ValidationError(
                {"standard_multiplier": "ضریب خدمات استاندارد باید بزرگتر از صفر باشد."}
            )

        if pro_multiplier <= 0:
            raise serializers.ValidationError(
                {"pro_multiplier": "ضریب خدمات حرفه‌ای باید بزرگتر از صفر باشد."}
            )

        if pro_multiplier < standard_multiplier:
            raise serializers.ValidationError(
                {"pro_multiplier": "ضریب خدمات حرفه‌ای باید از ضریب استاندارد بیشتر باشد."}
            )

        base_price = data.get('base_price', 0)
        if base_price <= 0:
            raise serializers.ValidationError(
                {"base_price": "قیمت پایه باید بیشتر از صفر باشد."}
            )

        install_price = data.get('install_price', 0)
        dismantle_price = data.get('dismantle_price', 0)

        if install_price < 0:
            raise serializers.ValidationError(
                {"install_price": "هزینه نصب نمی‌تواند منفی باشد."}
            )

        if dismantle_price < 0:
            raise serializers.ValidationError(
                {"dismantle_price": "هزینه دمونتاژ نمی‌تواند منفی باشد."}
            )

        return data


class PricingRuleChangeLogSerializer(serializers.ModelSerializer):
    pricing_rule_name = serializers.CharField(
        source='pricing_rule.equipment_type.name_fa', read_only=True)
    changed_by_name = serializers.CharField(
        source='changed_by.username', read_only=True)
    created_at_jalali = serializers.SerializerMethodField()

    class Meta:
        model = PricingRuleChangeLog
        fields = '__all__'
        read_only_fields = ('id', 'created_at')

    def get_created_at_jalali(self, obj):
        return to_jalali(obj.created_at)


class PriceCalculationLogSerializer(serializers.ModelSerializer):
    inspection_request_id = serializers.IntegerField(
        source='inspection_request.id', read_only=True)
    rule_version_name = serializers.CharField(
        source='rule_version.equipment_type.name_fa', read_only=True)
    created_at_jalali = serializers.SerializerMethodField()

    class Meta:
        model = PriceCalculationLog
        fields = '__all__'
        read_only_fields = ('id', 'created_at')

    def get_created_at_jalali(self, obj):
        return to_jalali(obj.created_at)


class PricePreviewSerializer(serializers.Serializer):
    equipment_type_id = serializers.IntegerField(required=True)
    params = serializers.JSONField(required=False, default=dict)
    install_state = serializers.CharField(
        required=False, allow_null=True, allow_blank=True)
    city = serializers.CharField(required=True)
    service_type = serializers.ChoiceField(
        choices=PricingRule.ServiceType.choices,
        default='standard'
    )

    def validate(self, data):
        try:
            equipment = EquipmentType.objects.get(id=data['equipment_type_id'])
            data['equipment_type'] = equipment
        except EquipmentType.DoesNotExist:
            raise serializers.ValidationError(
                {"equipment_type_id": "نوع تجهیزات یافت نشد."}
            )

        if not hasattr(equipment, 'pricing_rule'):
            raise serializers.ValidationError(
                {"equipment_type_id": "قانون قیمت‌گذاری برای این تجهیز تعریف نشده است."}
            )

        from core.models import CityMultiplier
        if not CityMultiplier.objects.filter(city=data['city']).exists():
            raise serializers.ValidationError(
                {"city": "شهر وارد شده در سیستم وجود ندارد."}
            )

        return data

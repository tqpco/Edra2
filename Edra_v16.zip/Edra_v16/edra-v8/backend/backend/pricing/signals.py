from django.db.models.signals import post_save, post_delete
from django.dispatch import receiver
import logging

from .models import PricingRule, PricingRuleChangeLog, ParameterPrice

logger = logging.getLogger(__name__)


@receiver(post_save, sender=PricingRule)
def log_pricing_rule_change(sender, instance, created, **kwargs):
    if created:
        logger.info(
            f"New pricing rule created for {
                instance.equipment_type.name_fa}")
    else:
        logger.info(
            f"Pricing rule updated for {
                instance.equipment_type.name_fa}")


@receiver(post_save, sender=ParameterPrice)
@receiver(post_delete, sender=ParameterPrice)
def log_parameter_price_change(sender, instance, **kwargs):
    """
    سیگنال برای لاگ تغییرات نرخ پارامترها.
    در صورت نیاز می‌توانید تغییرات را در PricingRuleChangeLog ثبت کنید.
    """
    # برای سادگی، فقط لاگ می‌کنیم
    action = 'created' if kwargs.get('created', False) else 'updated'
    if instance.pk:
        logger.info(
            f"Parameter price {action} for {instance.pricing_rule.equipment_type.name_fa} - "
            f"{instance.parameter.label if instance.parameter else 'نامشخص'}: "
            f"{instance.rate} ({instance.get_rate_type_display()})"
        )
    else:
        logger.info(
            f"Parameter price deleted for {
                instance.pricing_rule.equipment_type.name_fa}")

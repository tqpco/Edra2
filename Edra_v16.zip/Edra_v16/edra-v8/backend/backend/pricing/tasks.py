from celery import shared_task
import logging

from .models import PriceCalculationLog

logger = logging.getLogger(__name__)


@shared_task
def clean_old_price_logs(days=30):
    """
    تسک برای پاک‌سازی لاگ‌های قدیمی محاسبه قیمت
    """
    from django.utils import timezone
    from datetime import timedelta

    threshold = timezone.now() - timedelta(days=days)
    deleted, _ = PriceCalculationLog.objects.filter(
        created_at__lt=threshold).delete()
    logger.info(f"Deleted {deleted} old price calculation logs")
    return deleted

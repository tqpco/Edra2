from django.urls import path, include
from rest_framework.routers import DefaultRouter
from .views import (
    PriceDebugView,
    PricingRuleViewSet,
    PricingRuleChangeLogViewSet,
    PriceCalculateView,
    PriceComponentsView,
    get_equipment_params,
)

app_name = 'pricing'

router = DefaultRouter()
router.register(r'rules', PricingRuleViewSet, basename='pricing_rules')
router.register(
    r'changelog',
    PricingRuleChangeLogViewSet,
    basename='pricing_changelog')

urlpatterns = [
    path(
        'debug/',
        PriceDebugView.as_view(),
        name='price_debug'),
    path(
        'calculate/',
        PriceCalculateView.as_view(),
        name='price_calculate'),
    path(
        'preview/',
        PriceCalculateView.as_view(),
        name='price_preview'),
    path(
        'components/',
        PriceComponentsView.as_view(),
        name='price_components'),
    path(
        '',
        include(
            router.urls)),
    path(
        'equipment-params/<int:equipment_id>/',
        get_equipment_params,
        name='get_equipment_params'),
]

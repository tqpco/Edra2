from decimal import Decimal, DecimalException, ROUND_HALF_UP, getcontext
from core.models import EquipmentType, CityMultiplier
from .models import PricingRule, ParameterPrice
import ast
import operator

# تنظیم دقت محاسبات اعشاری
getcontext().prec = 28

# ============================================================
# توابع کمکی برای رند کردن
# ============================================================


def round_price(price, step=100000):
    """
    رند کردن یک عدد اعشاری به نزدیک‌ترین مضرب step.
    مثال: round_price(22416333.333, 100000) -> 22400000
    """
    if not isinstance(price, Decimal):
        price = Decimal(str(price))
    if step <= 0:
        return price
    # تبدیل به مضرب step
    step = Decimal(str(step))
    # تقسیم بر step، رند کردن، ضرب در step
    rounded = (price / step).quantize(Decimal('1'),
                                      rounding=ROUND_HALF_UP) * step
    return rounded


# ============================================================
# توابع مجاز برای استفاده در فرمول سفارشی
# ============================================================

ALLOWED_FUNCTIONS = {
    'abs': abs,
    'max': max,
    'min': min,
    'round': round,
}

ALLOWED_OPERATORS = {
    ast.Add: operator.add,
    ast.Sub: operator.sub,
    ast.Mult: operator.mul,
    ast.Div: operator.truediv,
    ast.FloorDiv: operator.floordiv,
    ast.Mod: operator.mod,
    ast.Pow: operator.pow,
    ast.UAdd: operator.pos,
    ast.USub: operator.neg,
}


def safe_eval(expr, context=None):
    """
    ارزیابی امن عبارات ریاضی بدون استفاده از eval
    """
    import ast
    import operator

    # عملگرهای مجاز
    allowed_ops = {
        ast.Add: operator.add,
        ast.Sub: operator.sub,
        ast.Mult: operator.mul,
        ast.Div: operator.truediv,
        ast.Pow: operator.pow,
        ast.USub: operator.neg,
        ast.UAdd: operator.pos,
    }

    # متغیرهای مجاز
    allowed_names = {
        'pi': 3.14159,
        'e': 2.71828,
    }
    if context:
        allowed_names.update(context)

    def _eval(node):
        if isinstance(node, ast.Constant):
            return node.value
        elif isinstance(node, ast.Name):
            if node.id in allowed_names:
                return allowed_names[node.id]
            raise ValueError(f"متغیر مجاز نیست: {node.id}")
        elif isinstance(node, ast.BinOp):
            op = allowed_ops.get(type(node.op))
            if op is None:
                raise ValueError(f"عملگر مجاز نیست: {type(node.op).__name__}")
            return op(_eval(node.left), _eval(node.right))
        elif isinstance(node, ast.UnaryOp):
            op = allowed_ops.get(type(node.op))
            if op is None:
                raise ValueError(f"عملگر مجاز نیست: {type(node.op).__name__}")
            return op(_eval(node.operand))
        elif isinstance(node, ast.Call):
            # فقط توابع مجاز مثل min, max
            if node.func.id == 'min':
                return min(_eval(arg) for arg in node.args)
            elif node.func.id == 'max':
                return max(_eval(arg) for arg in node.args)
            elif node.func.id == 'abs':
                return abs(_eval(node.args[0]))
            raise ValueError(f"فراخوانی تابع مجاز نیست: {node.func.id}")
        else:
            raise ValueError(f"نوع گره مجاز نیست: {type(node).__name__}")

    try:
        tree = ast.parse(expr, mode='eval')
        return _eval(tree.body)
    except Exception as e:
        raise ValueError(f"خطا در ارزیابی عبارت: {e}")


def calculate_price(
        equipment_type,
        params,
        install_state=None,
        city_name=None,
        service_type='standard'):
    """
    محاسبه قیمت بر اساس ۴ روش:
    1. نوع دستگاه (قیمت پایه + نرخ پارامترها)
    2. وضعیت نصب (هزینه نصب یا دمونتاژ + ضریب کاهش پارامترها در حالت دمونتاژ)
    3. هزینه شهر (base_cost × multiplier)
    4. نوع سرویس (استاندارد یا حرفه‌ای)
    """
    try:
        rule = PricingRule.objects.get(equipment_type=equipment_type)
    except PricingRule.DoesNotExist:
        return Decimal(1000000)

    base = Decimal(str(rule.base_price))
    param_total = Decimal(0)

    param_prices = ParameterPrice.objects.filter(
        pricing_rule=rule).select_related('parameter')
    for param_price in param_prices:
        if param_price.parameter is None:
            continue
        param_value = params.get(param_price.parameter.name)
        if param_value is None:
            continue
        try:
            value = Decimal(str(param_value))
        except (ValueError, TypeError, DecimalException):
            continue

        rate_type = param_price.rate_type
        rate = param_price.rate

        if rate_type == 'per_unit':
            param_total += rate * value
        else:  # fixed
            param_total += rate

    # ============================================================
    # اعمال ضریب کاهش پارامترها در حالت دمونتاژ (۱/۳)
    # ============================================================
    param_factor = Decimal('1')
    if install_state == 'dismantle':
        param_factor = Decimal('1') / Decimal('3')

    param_total = param_total * param_factor

    # ============================================================
    # محاسبه هزینه شهر (base_cost × multiplier)
    # ============================================================
    city_cost = Decimal('0')
    if city_name:
        try:
            city_obj = CityMultiplier.objects.get(city=city_name)
            city_cost = city_obj.base_cost * city_obj.multiplier
        except CityMultiplier.DoesNotExist:
            pass

    # قیمت پس از اعمال پارامترها و هزینه شهر (بدون ضریب)
    price = base + param_total + city_cost

    # اعمال ضریب سرویس
    if service_type == 'pro':
        price = price * Decimal(str(rule.pro_multiplier))
    else:
        price = price * Decimal(str(rule.standard_multiplier))

    # هزینه نصب/دمونتاژ (بعد از ضریب سرویس)
    if install_state == 'installed':
        price += Decimal(str(rule.install_price))
    elif install_state == 'dismantle':
        price += Decimal(str(rule.dismantle_price))

    # فرمول سفارشی
    if rule.custom_formula:
        try:
            safe_dict = {
                'price': float(price),
                'base': float(base),
                'param_total': float(param_total),
                'param_factor': float(param_factor),
                'params': params,
                'city_cost': float(city_cost),
                'install_state': install_state,
                'service_type': service_type,
                'standard_multiplier': float(rule.standard_multiplier),
                'pro_multiplier': float(rule.pro_multiplier),
                'install_price': float(rule.install_price),
                'dismantle_price': float(rule.dismantle_price),
            }
            result = safe_eval(rule.custom_formula, safe_dict)
            price = Decimal(str(result))
        except Exception:
            pass

    # ✅ رند کردن قیمت نهایی به نزدیک‌ترین مضرب ۱۰۰,۰۰۰ تومان
    price = round_price(price, step=100000)

    return price


def calculate_price_with_components(
        equipment_type,
        params,
        install_state=None,
        city_name=None,
        service_type='standard'):
    try:
        rule = PricingRule.objects.get(equipment_type=equipment_type)
    except PricingRule.DoesNotExist:
        return {
            'total': Decimal(1000000),
            'base_price': Decimal(1000000),
            'param_total': Decimal(0),
            'param_factor': Decimal('1'),
            'city_cost': Decimal('0'),
            'service_multiplier': Decimal('1.0'),
            'install_cost': Decimal('0'),
            'service_type': service_type,
            'install_state': install_state,
        }

    base = Decimal(str(rule.base_price))
    param_total = Decimal(0)
    param_details = {}

    param_prices = ParameterPrice.objects.filter(
        pricing_rule=rule).select_related('parameter')
    for param_price in param_prices:
        if param_price.parameter is None:
            continue
        param_value = params.get(param_price.parameter.name)
        if param_value is None:
            continue
        try:
            value = Decimal(str(param_value))
        except (ValueError, TypeError, DecimalException):
            continue

        rate_type = param_price.rate_type
        rate = param_price.rate

        if rate_type == 'per_unit':
            cost = rate * value
        else:
            cost = rate
        param_total += cost
        param_details[param_price.parameter.name] = {
            'rate': float(rate),
            'value': float(value),
            'total': float(cost),
            'type': rate_type
        }

    # اعمال ضریب کاهش پارامترها در حالت دمونتاژ (۱/۳)
    param_factor = Decimal('1')
    if install_state == 'dismantle':
        param_factor = Decimal('1') / Decimal('3')

    param_total = param_total * param_factor

    # محاسبه هزینه شهر (base_cost × multiplier)
    city_cost = Decimal('0')
    city_multiplier = Decimal('1.0')
    if city_name:
        try:
            city_obj = CityMultiplier.objects.get(city=city_name)
            city_multiplier = city_obj.multiplier
            city_cost = city_obj.base_cost * city_obj.multiplier
        except CityMultiplier.DoesNotExist:
            pass

    price = base + param_total + city_cost

    # ضریب سرویس
    if service_type == 'pro':
        service_multiplier = Decimal(str(rule.pro_multiplier))
    else:
        service_multiplier = Decimal(str(rule.standard_multiplier))

    price = price * service_multiplier

    install_cost = Decimal(0)
    if install_state == 'installed':
        install_cost = Decimal(str(rule.install_price))
        price += install_cost
    elif install_state == 'dismantle':
        install_cost = Decimal(str(rule.dismantle_price))
        price += install_cost

    # ✅ رند کردن قیمت نهایی به نزدیک‌ترین مضرب ۱۰۰,۰۰۰ تومان
    price = round_price(price, step=100000)

    return {
        'base_price': base,
        'param_total': param_total,
        'param_factor': param_factor,
        'param_details': param_details,
        'city_cost': city_cost,
        'city_multiplier': city_multiplier,
        'service_multiplier': service_multiplier,
        'install_cost': install_cost,
        'total': price,
        'service_type': service_type,
        'install_state': install_state,
        'equipment_name': equipment_type.name_fa,
        'rule_id': rule.id,
    }


def calculate_price_with_rounding_info(
        equipment_type,
        params=None,
        install_state=None,
        city_name=None,
        service_type='standard'):
    """
    محاسبه قیمت با جزئیات رندینگ — رابطی که core/views/inspection_views.py
    به آن نیاز دارد (قبلاً وجود نداشت و ImportError باعث fallback به
    ۱٬۰۰۰٬۰۰۰ تومان ثابت برای همه درخواست‌ها می‌شد).

    خروجی:
      rounded_total      = قیمت نهایی رندشده (مضرب ۱۰۰,۰۰۰) — مبلغ نمایش/فاکتور
      exact_total        = قیمت دقیق پیش از رند (برای محاسبات داخلی)
      rounding_discount  = exact − rounded (≥ 0؛ تخفیف ناشی از رند)
      components         = اجزای محاسبه (برای گزارش/لاگ قیمت)
    """
    params = params or {}
    components = calculate_price_with_components(
        equipment_type, params, install_state, city_name, service_type)
    exact_total = (
        (components['base_price']
         + components['param_total']
         + components['city_cost'])
        * components['service_multiplier']
        + components['install_cost']
    ).quantize(Decimal(1), rounding=ROUND_HALF_UP)
    rounded_total = components['total']
    rounding_discount = max(
        exact_total - rounded_total, Decimal('0'))
    return {
        'rounded_total': rounded_total,
        'exact_total': exact_total,
        'rounding_discount': rounding_discount,
        'components': components,
    }


# ===== Baseline Cases برای تست =====
BASELINE_CASES = [
    {
        'equipment_code': 'tower_crane',
        'params': {'tonnage': 12, 'height': 50, 'jib_length': 40},
        'install_state': None,
        'expected': 5000000,
    },
    {
        'equipment_code': 'tower_crane',
        'params': {'tonnage': 12, 'height': 50, 'jib_length': 40},
        'install_state': 'installed',
        'expected': 6000000,
    },
]


def check_baselines(rule):
    errors = []
    for case in BASELINE_CASES:
        if case['equipment_code'] != rule.equipment_type.code:
            continue
        try:
            price = calculate_price(
                rule.equipment_type,
                case['params'],
                case['install_state'],
                city_name=None,
                service_type='standard'
            )
            expected = Decimal(str(case['expected']))
            if abs(price - expected) > Decimal(1000):
                errors.append({
                    'case': case,
                    'calculated': float(price),
                    'expected': float(expected),
                })
        except Exception as e:
            errors.append({
                'case': case,
                'error': str(e)
            })
    return errors


def debug_price(
        equipment_type,
        params,
        install_state=None,
        city_name=None,
        service_type='standard'):
    try:
        rule = PricingRule.objects.get(equipment_type=equipment_type)
    except PricingRule.DoesNotExist:
        return {
            'error': 'قانون قیمت‌گذاری برای این تجهیز یافت نشد.',
            'base_price': 0,
            'param_total': 0,
            'param_factor': 1.0,
            'param_details': {},
            'city_cost': 0,
            'service_multiplier': 1.0,
            'install_cost': 0,
            'total': 0,
            'equipment_name': equipment_type.name_fa,
            'service_type': service_type,
            'install_state': install_state,
        }

    base = Decimal(str(rule.base_price))
    param_total = Decimal(0)
    param_details = {}

    param_prices = ParameterPrice.objects.filter(
        pricing_rule=rule).select_related('parameter')
    for param_price in param_prices:
        if param_price.parameter is None:
            continue
        param_value = params.get(param_price.parameter.name)
        if param_value is None:
            continue
        try:
            value = Decimal(str(param_value))
        except (ValueError, TypeError, DecimalException):
            continue

        rate_type = param_price.rate_type
        rate = param_price.rate

        if rate_type == 'per_unit':
            cost = rate * value
        else:
            cost = rate
        param_total += cost
        param_details[param_price.parameter.name] = {
            'rate': float(rate),
            'value': float(value),
            'total': float(cost),
            'type': rate_type
        }

    param_factor = Decimal('1')
    if install_state == 'dismantle':
        param_factor = Decimal('1') / Decimal('3')
    param_total = param_total * param_factor

    city_cost = Decimal('0')
    if city_name:
        try:
            city_obj = CityMultiplier.objects.get(city=city_name)
            city_cost = city_obj.base_cost * city_obj.multiplier
        except CityMultiplier.DoesNotExist:
            pass

    price = base + param_total + city_cost

    if service_type == 'pro':
        service_multiplier = Decimal(str(rule.pro_multiplier))
    else:
        service_multiplier = Decimal(str(rule.standard_multiplier))

    price = price * service_multiplier

    install_cost = Decimal(0)
    if install_state == 'installed':
        install_cost = Decimal(str(rule.install_price))
        price += install_cost
    elif install_state == 'dismantle':
        install_cost = Decimal(str(rule.dismantle_price))
        price += install_cost

    # رند کردن برای دیباگ نیز
    price = round_price(price, step=100000)

    return {
        'base_price': float(base),
        'param_total': float(param_total),
        'param_factor': float(param_factor),
        'param_details': param_details,
        'city_cost': float(city_cost),
        'service_multiplier': float(service_multiplier),
        'install_cost': float(install_cost),
        'total': float(price),
        'rule_id': rule.id,
        'equipment_name': rule.equipment_type.name_fa,
        'service_type': service_type,
        'install_state': install_state,
    }

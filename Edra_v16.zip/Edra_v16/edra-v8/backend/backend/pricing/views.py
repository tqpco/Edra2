from decimal import Decimal
from rest_framework import viewsets, status, generics
from rest_framework.decorators import action
from rest_framework.response import Response
from rest_framework.permissions import AllowAny, IsAuthenticated
from core.permissions import IsAdminUserOrGroup
from django.db import transaction
from django.core.cache import cache
from django.http import JsonResponse
from core.models import EquipmentType, CityMultiplier
from core.serializers import EquipmentTypeSerializer, CityMultiplierSerializer
from .models import PricingRule, PricingRuleChangeLog, PriceCalculationLog
from .serializers import (
    PricingRuleSerializer, PricingRuleChangeLogSerializer,
    PriceCalculationLogSerializer, PricePreviewSerializer,
)
from .utils import calculate_price, calculate_price_with_components, check_baselines, debug_price
import logging

logger = logging.getLogger(__name__)


def get_equipment_params(request, equipment_id):
    try:
        equipment = EquipmentType.objects.get(pk=equipment_id)
        schema = equipment.param_schema
        return JsonResponse({'schema': schema})
    except EquipmentType.DoesNotExist:
        return JsonResponse({'schema': None}, status=404)


class PricingRuleViewSet(viewsets.ModelViewSet):
    queryset = PricingRule.objects.select_related(
        'equipment_type', 'updated_by')
    serializer_class = PricingRuleSerializer
    permission_classes = [IsAdminUserOrGroup]

    @transaction.atomic
    def perform_create(self, serializer):
        rule = serializer.save(updated_by=self.request.user)
        after = {
            'base_price': str(rule.base_price),
            'install_price': str(rule.install_price),
            'dismantle_price': str(rule.dismantle_price),
            'standard_multiplier': str(rule.standard_multiplier),
            'pro_multiplier': str(rule.pro_multiplier),
            'custom_formula': rule.custom_formula,
        }
        PricingRuleChangeLog.objects.create(
            pricing_rule=rule,
            changed_by=self.request.user,
            before={},
            after=after,
            baseline_check_passed=True
        )
        cache_key = f'pricing_rule_{rule.equipment_type.id}'
        cache.delete(cache_key)
        logger.info(
            f"Pricing rule created for {
                rule.equipment_type.name_fa} by {
                self.request.user.username}")

    @transaction.atomic
    def perform_update(self, serializer):
        instance = self.get_object()
        before = {
            'base_price': str(instance.base_price),
            'install_price': str(instance.install_price),
            'dismantle_price': str(instance.dismantle_price),
            'standard_multiplier': str(instance.standard_multiplier),
            'pro_multiplier': str(instance.pro_multiplier),
            'custom_formula': instance.custom_formula,
        }
        updated = serializer.save(updated_by=self.request.user)
        after = {
            'base_price': str(updated.base_price),
            'install_price': str(updated.install_price),
            'dismantle_price': str(updated.dismantle_price),
            'standard_multiplier': str(updated.standard_multiplier),
            'pro_multiplier': str(updated.pro_multiplier),
            'custom_formula': updated.custom_formula,
        }
        errors = check_baselines(updated)
        baseline_passed = len(errors) == 0
        PricingRuleChangeLog.objects.create(
            pricing_rule=updated,
            changed_by=self.request.user,
            before=before,
            after=after,
            baseline_check_passed=baseline_passed
        )
        cache_key = f'pricing_rule_{updated.equipment_type.id}'
        cache.delete(cache_key)
        if not baseline_passed:
            logger.warning(
                f"Baseline Guard failed for rule {
                    updated.id} ({
                    updated.equipment_type.name_fa}): {errors}")
        else:
            logger.info(
                f"Pricing rule updated for {
                    updated.equipment_type.name_fa} by {
                    self.request.user.username}")

    @action(detail=False, methods=['post'], permission_classes=[AllowAny])
    def preview(self, request):
        serializer = PricePreviewSerializer(data=request.data)
        if not serializer.is_valid():
            return Response(
                serializer.errors,
                status=status.HTTP_400_BAD_REQUEST)

        data = serializer.validated_data

        try:
            equipment = EquipmentType.objects.get(id=data['equipment_type_id'])
        except EquipmentType.DoesNotExist:
            return Response({'error': 'نوع تجهیز یافت نشد.'},
                            status=status.HTTP_404_NOT_FOUND)

        try:
            rule = PricingRule.objects.get(equipment_type=equipment)
        except PricingRule.DoesNotExist:
            return Response({
                'error': 'قانون قیمت‌گذاری برای این تجهیز تعریف نشده است.',
                'suggestion': 'ابتدا یک قانون قیمت‌گذاری ایجاد کنید.'
            }, status=status.HTTP_404_NOT_FOUND)

        city_name = data.get('city')
        components = calculate_price_with_components(
            equipment,
            data.get('params', {}),
            data.get('install_state'),
            city_name=city_name,
            service_type=data.get('service_type', 'standard')
        )

        return Response({
            'equipment': {
                'id': equipment.id,
                'name': equipment.name_fa,
                'code': equipment.code,
            },
            'params': data.get('params', {}),
            'install_state': data.get('install_state'),
            'city': city_name,
            'city_cost': float(components.get('city_cost', 0)),
            'service_type': data.get('service_type', 'standard'),
            'components': {
                'base_price': float(components['base_price']),
                'param_total': float(components['param_total']),
                'param_details': components.get('param_details', {}),
                'city_cost': float(components.get('city_cost', 0)),
                'service_multiplier': float(components['service_multiplier']),
                'install_cost': float(components['install_cost']),
            },
            'total_price': float(components['total']),
            'rule_id': rule.id,
        })

    @action(detail=True, methods=['get'])
    def changelog(self, request, pk=None):
        rule = self.get_object()
        logs = PricingRuleChangeLog.objects.filter(
            pricing_rule=rule).order_by('-created_at')
        serializer = PricingRuleChangeLogSerializer(logs, many=True)
        return Response(serializer.data)


class PricingRuleChangeLogViewSet(viewsets.ReadOnlyModelViewSet):
    queryset = PricingRuleChangeLog.objects.select_related(
        'pricing_rule', 'changed_by').order_by('-created_at')
    serializer_class = PricingRuleChangeLogSerializer
    permission_classes = [IsAdminUserOrGroup]


class EquipmentTypeViewSet(viewsets.ReadOnlyModelViewSet):
    queryset = EquipmentType.objects.all().order_by('name_fa')
    serializer_class = EquipmentTypeSerializer
    permission_classes = [AllowAny]
    search_fields = ['name_fa', 'code']
    ordering_fields = ['name_fa', 'code']


class CityMultiplierViewSet(viewsets.ReadOnlyModelViewSet):
    queryset = CityMultiplier.objects.all().order_by('city')
    serializer_class = CityMultiplierSerializer
    permission_classes = [AllowAny]
    search_fields = ['city']
    ordering_fields = ['city', 'multiplier']


class PriceCalculateView(generics.GenericAPIView):
    permission_classes = [AllowAny]
    serializer_class = PricePreviewSerializer

    def post(self, request):
        serializer = self.get_serializer(data=request.data)
        if not serializer.is_valid():
            return Response(
                serializer.errors,
                status=status.HTTP_400_BAD_REQUEST)

        data = serializer.validated_data

        try:
            equipment = EquipmentType.objects.get(id=data['equipment_type_id'])
        except EquipmentType.DoesNotExist:
            return Response({'error': 'نوع تجهیز یافت نشد.'},
                            status=status.HTTP_404_NOT_FOUND)

        components = calculate_price_with_components(
            equipment,
            data.get('params', {}),
            data.get('install_state'),
            city_name=data.get('city'),
            service_type=data.get('service_type', 'standard')
        )
        total_price = components['total']

        try:
            rule = PricingRule.objects.get(equipment_type=equipment)
            PriceCalculationLog.objects.create(
                inspection_request=None,
                rule_version=rule,
                calculated_price=total_price,
                params_used=data.get('params', {}),
                service_type=data.get('service_type', 'standard'),
                city_multiplier=components['city_multiplier'],
                install_state=data.get('install_state'),
            )
        except PricingRule.DoesNotExist:
            pass

        # P0-09 (EDRA v9): مالیات server-side — Review باید دقیقاً همان
        # مبلغی را نشان دهد که درگاه/فاکتور دریافت می‌کند.
        from core.services.invoice_service import resolve_tax_rate_percent
        from decimal import Decimal, ROUND_HALF_UP
        tax_rate_percent = resolve_tax_rate_percent()
        tax_amount = (Decimal(str(total_price)) * tax_rate_percent / Decimal(
            '100')).quantize(Decimal(1), rounding=ROUND_HALF_UP)
        final_amount = Decimal(str(total_price)) + tax_amount

        return Response({
            'success': True,
            'equipment': equipment.name_fa,
            'equipment_id': equipment.id,
            'params': data.get('params', {}),
            'city': data.get('city'),
            'city_cost': float(components['city_cost']),
            'service_type': data.get('service_type', 'standard'),
            'install_state': data.get('install_state'),
            'total_price': float(total_price),
            'tax_rate_percent': float(tax_rate_percent),
            'tax_amount': float(tax_amount),
            'final_amount': float(final_amount),
        })


class PriceDebugView(generics.GenericAPIView):
    permission_classes = [IsAdminUserOrGroup]

    def post(self, request):
        data = request.data

        try:
            equipment = EquipmentType.objects.get(
                id=data.get('equipment_type_id'))
        except EquipmentType.DoesNotExist:
            return Response({'error': 'نوع تجهیز یافت نشد.'},
                            status=status.HTTP_404_NOT_FOUND)

        result = debug_price(
            equipment,
            data.get('params', {}),
            data.get('install_state'),
            city_name=data.get('city'),
            service_type=data.get('service_type', 'standard')
        )

        if 'error' in result:
            return Response(result, status=status.HTTP_404_NOT_FOUND)

        return Response({
            'success': True,
            'debug_info': result,
            'equipment': {
                'id': equipment.id,
                'name': equipment.name_fa,
                'code': equipment.code,
            },
            'params_used': data.get('params', {}),
            'city': data.get('city'),
            'service_type': data.get('service_type', 'standard'),
            'install_state': data.get('install_state'),
        })


class PriceComponentsView(generics.GenericAPIView):
    permission_classes = [AllowAny]

    def post(self, request):
        serializer = PricePreviewSerializer(data=request.data)
        if not serializer.is_valid():
            return Response(
                serializer.errors,
                status=status.HTTP_400_BAD_REQUEST)

        data = serializer.validated_data

        try:
            equipment = EquipmentType.objects.get(id=data['equipment_type_id'])
        except EquipmentType.DoesNotExist:
            return Response({'error': 'نوع تجهیز یافت نشد.'},
                            status=status.HTTP_404_NOT_FOUND)

        components = calculate_price_with_components(
            equipment,
            data.get('params', {}),
            data.get('install_state'),
            city_name=data.get('city'),
            service_type=data.get('service_type', 'standard')
        )

        return Response({
            'success': True,
            'equipment': {
                'id': equipment.id,
                'name': equipment.name_fa,
            },
            'components': {
                'base_price': float(components['base_price']),
                'param_total': float(components['param_total']),
                'param_details': components.get('param_details', {}),
                'city_cost': float(components.get('city_cost', 0)),
                'service_multiplier': float(components['service_multiplier']),
                'install_cost': float(components['install_cost']),
            },
            'total_price': float(components['total']),
            'service_type': data.get('service_type', 'standard'),
            'install_state': data.get('install_state'),
        })

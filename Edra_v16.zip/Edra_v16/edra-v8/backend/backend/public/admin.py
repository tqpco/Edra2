from django.contrib import admin
from django.utils.html import format_html
from jalali_date.admin import ModelAdminJalaliMixin
from .models import BlogPost, FAQ, ContactMessage
from core.utils.date_utils import to_jalali


class JalaliDateDisplayMixin:
    """نمایش تاریخ‌های خام به‌صورت جلالی در ستون‌های لیست ادمین"""

    def created_at_display(self, obj):
        return to_jalali(obj.created_at)
    created_at_display.short_description = "تاریخ ایجاد"

    def updated_at_display(self, obj):
        return to_jalali(obj.updated_at)
    updated_at_display.short_description = "تاریخ بروزرسانی"


@admin.register(BlogPost)
class BlogPostAdmin(JalaliDateDisplayMixin, ModelAdminJalaliMixin, admin.ModelAdmin):
    list_display = (
        'title',
        'category',
        'is_published',
        'author',
        'created_at_display')
    list_filter = ('category', 'is_published', 'author')
    search_fields = ('title', 'summary', 'content', 'tags')
    prepopulated_fields = {'slug': ('title',)}
    date_hierarchy = 'created_at'
    readonly_fields = ('created_at', 'updated_at')

    fieldsets = (
        ('اطلاعات اصلی', {
            'fields': ('title', 'slug', 'summary', 'content', 'featured_image')
        }),
        ('دسته‌بندی و انتشار', {
            'fields': ('category', 'tags', 'is_published', 'published_at', 'author')
        }),
        ('اطلاعات سیستمی', {
            'fields': ('created_at', 'updated_at'),
            'classes': ('collapse',)
        }),
    )


@admin.register(FAQ)
class FAQAdmin(admin.ModelAdmin):
    list_display = ('question', 'category', 'order', 'is_active')
    list_filter = ('category', 'is_active')
    search_fields = ('question', 'answer')
    ordering = ('order',)


@admin.register(ContactMessage)
class ContactMessageAdmin(JalaliDateDisplayMixin, ModelAdminJalaliMixin, admin.ModelAdmin):
    list_display = ('name', 'email', 'phone', 'created_at_display')
    list_filter = ('created_at',)
    search_fields = ('name', 'email', 'phone', 'message')
    readonly_fields = ('created_at',)

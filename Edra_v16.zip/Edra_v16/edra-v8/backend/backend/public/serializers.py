from rest_framework import serializers
from .models import BlogPost, FAQ, ContactMessage
from core.utils.date_utils import to_jalali


class BlogPostSerializer(serializers.ModelSerializer):
    author_name = serializers.CharField(
        source='author.get_full_name', read_only=True)
    created_at_jalali = serializers.SerializerMethodField()
    updated_at_jalali = serializers.SerializerMethodField()
    published_at_jalali = serializers.SerializerMethodField()

    class Meta:
        model = BlogPost
        fields = '__all__'
        read_only_fields = ('created_at', 'updated_at', 'author')

    def get_created_at_jalali(self, obj):
        return to_jalali(obj.created_at)

    def get_updated_at_jalali(self, obj):
        return to_jalali(obj.updated_at)

    def get_published_at_jalali(self, obj):
        return to_jalali(obj.published_at)


class FAQSerializer(serializers.ModelSerializer):
    class Meta:
        model = FAQ
        fields = '__all__'


class ContactMessageSerializer(serializers.ModelSerializer):
    created_at_jalali = serializers.SerializerMethodField()

    class Meta:
        model = ContactMessage
        fields = '__all__'
        read_only_fields = ('created_at',)

    def get_created_at_jalali(self, obj):
        return to_jalali(obj.created_at)

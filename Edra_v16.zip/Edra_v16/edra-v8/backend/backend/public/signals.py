from django.db.models.signals import post_save
from django.dispatch import receiver
import logging

from .models import BlogPost, ContactMessage

logger = logging.getLogger(__name__)


@receiver(post_save, sender=BlogPost)
def notify_blog_post_created(sender, instance, created, **kwargs):
    """
    سیگنال برای ارسال اعلان هنگام انتشار مقاله جدید
    """
    if created and instance.is_published:
        logger.info(f"New blog post published: {instance.title}")
        # در صورت نیاز، می‌توان اعلان به ادمین‌ها ارسال کرد


@receiver(post_save, sender=ContactMessage)
def notify_new_contact_message(sender, instance, created, **kwargs):
    """
    سیگنال برای اطلاع از پیام تماس جدید
    """
    if created:
        logger.info(
            f"New contact message from {instance.name} - {instance.email}")
        # در صورت نیاز، می‌توان اعلان به ادمین‌ها ارسال کرد

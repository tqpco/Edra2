from celery import shared_task
import logging

from .models import ContactMessage

logger = logging.getLogger(__name__)


@shared_task
def send_contact_notification_to_admin(message_id):
    """
    تسک برای ارسال اعلان پیام تماس به ادمین
    """
    try:
        message = ContactMessage.objects.get(id=message_id)
        # در صورت نیاز، ایمیل یا اعلان ارسال شود
        logger.info(
            f"Notification sent for contact message from {
                message.name}")
        return True
    except ContactMessage.DoesNotExist:
        logger.error(f"Contact message with id {message_id} not found")
        return False

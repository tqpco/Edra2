from django.urls import path, include
from rest_framework.routers import DefaultRouter
from .views import BlogPostViewSet, FAQViewSet, ContactMessageViewSet

app_name = "public"
router = DefaultRouter()

router.register(r'blog-posts', BlogPostViewSet, basename='blog_posts')
router.register(r'faqs', FAQViewSet, basename='faqs')
router.register(
    r'contact-messages',
    ContactMessageViewSet,
    basename='contact_messages')

urlpatterns = [
    path('', include(router.urls)),
]

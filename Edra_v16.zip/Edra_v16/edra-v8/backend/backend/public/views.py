from rest_framework import viewsets
from rest_framework.permissions import AllowAny, IsAuthenticatedOrReadOnly
from core.permissions import IsAdminUserOrGroup
from rest_framework.throttling import ScopedRateThrottle
from django_filters.rest_framework import DjangoFilterBackend
from .models import BlogPost, FAQ, ContactMessage
from .serializers import BlogPostSerializer, FAQSerializer, ContactMessageSerializer
from core.permissions import IsAdminOrReadOnly


class BlogPostViewSet(viewsets.ModelViewSet):
    queryset = BlogPost.objects.filter(is_published=True)
    serializer_class = BlogPostSerializer
    # CRITICAL-02/HIGH-09: کامنت «فقط ادمین» باید با permission واقعی هماهنگ
    # باشد — قبلاً IsAuthenticatedOrReadOnly بود که write را برای هر کاربر
    # احراز هویت‌شده باز می‌کرد. حالا write فقط برای Admin (is_staff یا
    # گروه Admin).
    permission_classes = [IsAdminOrReadOnly]
    # فیلتر دسته‌بندی برای صفحه «پروژه‌های ما» (?category=case_study)
    filter_backends = [DjangoFilterBackend]
    filterset_fields = ['category']

    def get_queryset(self):
        # ادمین همه مقالات را می‌بیند
        if self.request.user.is_staff or (
                self.request.user.is_authenticated
                and self.request.user.groups.filter(name='Admin').exists()):
            return BlogPost.objects.all()
        return BlogPost.objects.filter(is_published=True)


class FAQViewSet(viewsets.ModelViewSet):
    queryset = FAQ.objects.filter(is_active=True)
    serializer_class = FAQSerializer
    permission_classes = [IsAdminOrReadOnly]

    def get_queryset(self):
        if self.request.user.is_staff or (
                self.request.user.is_authenticated
                and self.request.user.groups.filter(name='Admin').exists()):
            return FAQ.objects.all()
        return FAQ.objects.filter(is_active=True)


class ContactMessageViewSet(viewsets.ModelViewSet):
    queryset = ContactMessage.objects.all()
    serializer_class = ContactMessageSerializer
    # فقط ادمین می‌تواند پیام‌ها را مدیریت کند
    permission_classes = [IsAdminUserOrGroup]
    # برای ارسال پیام جدید (create) باید مجوز جداگانه تعریف شود

    def get_permissions(self):
        if self.action == 'create':
            return [AllowAny()]  # هر کسی می‌تواند پیام ارسال کند
        return [IsAdminUserOrGroup()]

    def get_throttles(self):
        # محدودیت ارسال برای جلوگیری از spam: هر IP چند بار در ساعت
        if self.action == 'create':
            return [ScopedRateThrottle()]
        return []

    throttle_scope = 'contact_message'

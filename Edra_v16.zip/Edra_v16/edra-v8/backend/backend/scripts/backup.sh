#!/usr/bin/env bash
# ============================================================
# EDRA — اسکریپت Backup/Restore (P1-13)
#
# استفاده:
#   ./scripts/backup.sh backup            # پشتیبان‌گیری کامل
#   ./scripts/backup.sh restore <file>    # بازیابی از فایل پشتیبان
#
# شامل: dump دیتابیس (PostgreSQL) + فایل‌های media + retention (۷ روز)
# ============================================================
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
BACKEND_DIR="$(cd "$SCRIPT_DIR/.." && pwd)"
BACKUP_DIR="${BACKUP_DIR:-$BACKEND_DIR/backups}"
KEEP_DAYS="${KEEP_DAYS:-7}"

# --- مقادیر دیتابیس (از .env یا پیش‌فرض) ---
if [ -f "$BACKEND_DIR/.env" ]; then
  set -a; . "$BACKEND_DIR/.env"; set +a
fi
DB_NAME="${DB_NAME:-edra}"
DB_USER="${DB_USER:-edra}"
DB_HOST="${DB_HOST:-localhost}"
DB_PORT="${DB_PORT:-5432}"

mkdir -p "$BACKUP_DIR"
STAMP="$(date +%Y%m%d_%H%M%S)"
PREFIX="$BACKUP_DIR/edra_$STAMP"

backup() {
  echo "▶ پشتیبان‌گیری دیتابیس ($DB_NAME)..."
  PGPASSWORD="${DB_PASSWORD:-}" pg_dump -h "$DB_HOST" -p "$DB_PORT" -U "$DB_USER" \
    -F c -Z 9 -f "$PREFIX.dump" "$DB_NAME"

  echo "▶ پشتیبان‌گیری فایل‌های media..."
  if [ -d "$BACKEND_DIR/media" ]; then
    tar czf "$PREFIX.media.tar.gz" -C "$BACKEND_DIR" media
  else
    echo "   (پوشه media وجود ندارد — رد شد)"
    touch "$PREFIX.media.tar.gz"
  fi

  # خلاصه
  echo "▶ خلاصه:"
  ls -lh "$PREFIX".*

  # retention: حذف پشتیبان‌های قدیمی‌تر از KEEP_DAYS
  echo "▶ حذف پشتیبان‌های قدیمی‌تر از $KEEP_DAYS روز..."
  find "$BACKUP_DIR" -name 'edra_*.dump' -mtime +"$KEEP_DAYS" -delete
  find "$BACKUP_DIR" -name 'edra_*.media.tar.gz' -mtime +"$KEEP_DAYS" -delete
  echo "✔ پشتیبان‌گیری کامل شد → $PREFIX"
}

restore() {
  FILE="${1:-}"
  if [ -z "$FILE" ] || [ ! -f "$FILE" ]; then
    echo "✖ فایل پشتیبان معتبر وارد کنید: ./scripts/backup.sh restore backups/edra_XXXX.dump" >&2
    exit 1
  fi
  echo "⚠ بازیابی دیتابیس از $FILE (داده فعلی overwrite می‌شود)..."
  read -r -p "ادامه؟ (yes/no) " confirm
  [ "$confirm" = "yes" ] || { echo "لغو شد."; exit 0; }

  PGPASSWORD="${DB_PASSWORD:-}" pg_restore -h "$DB_HOST" -p "$DB_PORT" -U "$DB_USER" \
    --clean --if-exists -d "$DB_NAME" "$FILE"
  echo "✔ بازیابی دیتابیس انجام شد."

  MEDIA_FILE="${FILE%.dump}.media.tar.gz"
  if [ -f "$MEDIA_FILE" ]; then
    echo "▶ بازیابی media..."
    tar xzf "$MEDIA_FILE" -C "$BACKEND_DIR"
    echo "✔ بازیابی media انجام شد."
  fi
}

case "${1:-}" in
  backup) backup ;;
  restore) restore "${2:-}" ;;
  *) echo "استفاده: $0 {backup|restore <file>}" >&2; exit 1 ;;
esac

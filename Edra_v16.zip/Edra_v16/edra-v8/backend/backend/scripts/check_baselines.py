from pricing.utils import check_baselines
from core.models import PricingRule
import django
import os
import sys
import logging
logger = logging.getLogger(__name__)
# backend/scripts/check_baselines.py
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'edra.settings')
django.setup()


rules = PricingRule.objects.all()
for rule in rules:
    errors = check_baselines(rule)
    if errors:
        logger.info(f"⚠️ Baseline errors for {rule.equipment_type.code}:")
        for err in errors:
            logger.info(f"   {err}")
    else:
        logger.info(f"✅ Baseline passed for {rule.equipment_type.code}")

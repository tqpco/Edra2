# backend/scripts/init_checklist.py
# راه‌اندازی: python3 scripts/init_checklist.py
import os
import sys
import logging

logger = logging.getLogger(__name__)

# مسیر پروژه را قبل از هر ایمپورتی به sys.path اضافه کن (باگ قدیمی:
# ایمپورت قبل از django.setup() بود و با ModuleNotFoundError شکست می‌خورد)
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'edra.settings')

import django  # noqa: E402
django.setup()

from core.models import EquipmentType, ChecklistTemplate, ChecklistItem  # noqa: E402


# اگر تجهیزات وجود نداشته باشند، یکی ایجاد کن
equipment, _ = EquipmentType.objects.get_or_create(
    code='tower_crane',
    defaults={
        'name_fa': 'تاور کرین',
        'supports_install_state': True,
        'install_state_required': True,
        'param_schema': [
            {'key': 'tonnage', 'label_fa': 'تناژ', 'unit': 'تن'},
            {'key': 'height', 'label_fa': 'ارتفاع زیر قلاب', 'unit': 'متر'},
            {'key': 'boom', 'label_fa': 'طول فلش', 'unit': 'متر'},
        ]
    }
)

# ایجاد چک‌لیست پیش‌فرض
template, created = ChecklistTemplate.objects.get_or_create(
    equipment_type=equipment,
    version=1,
    defaults={
        'name': 'چک‌لیست تاور کرین - نسخه ۱',
        'description': 'چک‌لیست استاندارد بازرسی تاور کرین',
        'is_active': True,
    }
)

if created:
    items = [
        {'category': 'سازه فلزی', 'title': 'بررسی سلامت سازه اصلی', 'description': 'بدون ترک و تغییر شکل', 'order': 1, 'requires_photo': True},
        {'category': 'سازه فلزی', 'title': 'بررسی اتصالات و جوش‌ها', 'description': 'بدون خوردگی و ترک', 'order': 2, 'requires_photo': True},
        {'category': 'مکانیزم بالابر', 'title': 'بررسی موتور و گیربکس', 'description': 'عملکرد صحیح و بدون صدا', 'order': 3, 'requires_note': True},
        {'category': 'مکانیزم بالابر', 'title': 'بررسی ترمزها', 'description': 'عملکرد صحیح', 'order': 4},
        {'category': 'سیم‌بکسل و قلاب', 'title': 'بررسی سیم‌بکسل', 'description': 'بدون سایش و شکستگی', 'order': 5, 'requires_photo': True},
        {'category': 'سیم‌بکسل و قلاب', 'title': 'بررسی قلاب', 'description': 'بدون تغییر شکل', 'order': 6},
        {'category': 'تجهیزات ایمنی', 'title': 'بررسی محدودکننده بار', 'description': 'عملکرد صحیح', 'order': 7},
        {'category': 'تجهیزات ایمنی', 'title': 'بررسی دکمه توقف اضطراری', 'description': 'عملکرد صحیح', 'order': 8},
        {'category': 'برق', 'title': 'بررسی کابل‌ها و اتصالات', 'description': 'بدون آسیب', 'order': 9},
        {'category': 'مستندات', 'title': 'بررسی مدارک و گواهی‌ها', 'description': 'معتبر و کامل', 'order': 10},
    ]

    for item in items:
        ChecklistItem.objects.create(checklist_template=template, **item)

    logger.info(
        f"✅ چک‌لیست با {len(items)} آیتم برای تجهیز {equipment.name_fa} ایجاد شد.")
else:
    logger.info(f"⏩ چک‌لیست برای {equipment.name_fa} از قبل وجود دارد.")

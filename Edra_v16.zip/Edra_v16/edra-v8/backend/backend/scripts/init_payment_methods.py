# backend/scripts/init_payment_methods.py
# راه‌اندازی: python3 scripts/init_payment_methods.py
import os
import sys
import logging

logger = logging.getLogger(__name__)

# مسیر پروژه را قبل از هر ایمپورتی به sys.path اضافه کن (باگ قدیمی:
# ایمپورت قبل از django.setup() بود و با ModuleNotFoundError شکست می‌خورد)
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'edra.settings')

import django  # noqa: E402
django.setup()

from core.models import PaymentMethod  # noqa: E402


methods = [
    ('online', 'درگاه آنلاین', True, 'پرداخت از طریق درگاه بانکی'),
    ('manual', 'واریز دستی', True, 'واریز به حساب و آپلود فیش'),
    ('credit', 'اعتبار شرکتی', True, 'استفاده از اعتبار سازمانی'),
]

for name, display, active, desc in methods:
    obj, created = PaymentMethod.objects.get_or_create(
        name=name,
        defaults={'is_active': active, 'description': desc}
    )
    if created:
        logger.info(f"✅ روش پرداخت {display} ایجاد شد.")
    else:
        logger.info(f"⏩ روش پرداخت {display} از قبل وجود دارد.")

#!/usr/bin/env bash
# ============================================================
# EDRA — اسکن امنیتی Dependency (EDRA v7 — SEC-03)
#
#   ./scripts/security-scan.sh
#
# اجرا: pip-audit + npm audit + (اختیاری) trivy برای image ها
# پیش‌نیاز: pip install pip-audit && npm audit (داخلی npm)
# ============================================================
set -uo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
BACKEND_DIR="$(cd "$SCRIPT_DIR/.." && pwd)"
FRONTEND_DIR="$(cd "$BACKEND_DIR/../../../frontend/frontend" 2>/dev/null && pwd || echo '')"

FAIL=0

# P1-08 (EDRA v8): عدم نصب scanner = FAILURE (نه فقط warning). هیچ
# advisory با wildcard ignore نمی‌شود (قبلاً --ignore-vuln GHSA-* بود).

echo "▶ 1) pip-audit (Python dependencies)..."
if command -v pip-audit >/dev/null 2>&1; then
  pip-audit -r "$BACKEND_DIR/requirements.txt" || FAIL=1
else
  echo "✖ pip-audit نصب نیست — نصب: pip install pip-audit"
  FAIL=1
fi

echo "▶ 2) npm audit (Node dependencies)..."
if [ -n "$FRONTEND_DIR" ] && [ -f "$FRONTEND_DIR/package-lock.json" ]; then
  (cd "$FRONTEND_DIR" && npm audit --audit-level=high) || FAIL=1
else
  echo "✖ package-lock.json یافت نشد."
  FAIL=1
fi

echo "▶ 3) Trivy container scan (اجباری)..."
if command -v trivy >/dev/null 2>&1; then
  if [ -n "$FRONTEND_DIR" ] && [ -f "$FRONTEND_DIR/Dockerfile" ]; then
    trivy image edra-backend:latest --severity HIGH,CRITICAL --no-progress || FAIL=1
    trivy image edra-frontend:latest --severity HIGH,CRITICAL --no-progress || FAIL=1
  else
    trivy image edra-backend:latest --severity HIGH,CRITICAL --no-progress || FAIL=1
  fi
else
  echo "✖ trivy نصب نیست — نصب: https://aquasecurity.github.io/trivy"
  FAIL=1
fi

if [ "$FAIL" -eq 1 ]; then
  echo "✖ اسکن امنیتی: آسیب‌پذیری با شدت بالا یافت شد → Release ممنوع."
  exit 1
fi
echo "✔ اسکن امنیتی بدون آسیب‌پذیری با شدت بالا."

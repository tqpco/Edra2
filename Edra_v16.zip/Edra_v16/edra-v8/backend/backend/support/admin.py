from django.contrib import admin
from django.utils.html import format_html
from jalali_date.admin import ModelAdminJalaliMixin
from .models import (
    TicketSystemSettings, TicketCategory, TicketPriority, TicketStatus,
    TicketDepartment, TicketLabel, Ticket, TicketComment, TicketAttachment,
    TicketActivityLog, SavedReply, KnowledgeBaseCategory, KnowledgeBaseArticle,
    Announcement, TicketNotification, UserAccountSettings
)
from core.utils.date_utils import to_jalali


class JalaliDateDisplayMixin:
    """نمایش تاریخ‌های خام به‌صورت جلالی در ستون‌های لیست ادمین"""

    def created_at_display(self, obj):
        return to_jalali(obj.created_at)
    created_at_display.short_description = "تاریخ ایجاد"

    def updated_at_display(self, obj):
        return to_jalali(obj.updated_at)
    updated_at_display.short_description = "تاریخ بروزرسانی"

    def uploaded_at_display(self, obj):
        return to_jalali(obj.uploaded_at)
    uploaded_at_display.short_description = "تاریخ آپلود"


@admin.register(TicketSystemSettings)
class TicketSystemSettingsAdmin(
        JalaliDateDisplayMixin, ModelAdminJalaliMixin, admin.ModelAdmin):
    list_display = (
        'system_title',
        'is_active',
        'items_per_page',
        'max_upload_size')
    list_filter = ('is_active',)
    search_fields = ('system_title',)


@admin.register(TicketCategory)
class TicketCategoryAdmin(
        JalaliDateDisplayMixin, ModelAdminJalaliMixin, admin.ModelAdmin):
    list_display = ('name', 'is_active', 'created_at_display')
    list_filter = ('is_active',)
    search_fields = ('name', 'description')


@admin.register(TicketPriority)
class TicketPriorityAdmin(
        JalaliDateDisplayMixin, ModelAdminJalaliMixin, admin.ModelAdmin):
    list_display = ('name', 'color', 'weight', 'is_active')
    list_filter = ('is_active',)
    search_fields = ('name',)


@admin.register(TicketStatus)
class TicketStatusAdmin(
        JalaliDateDisplayMixin, ModelAdminJalaliMixin, admin.ModelAdmin):
    list_display = ('name', 'color', 'is_closed', 'is_active')
    list_filter = ('is_active', 'is_closed')
    search_fields = ('name',)


@admin.register(TicketDepartment)
class TicketDepartmentAdmin(
        JalaliDateDisplayMixin, ModelAdminJalaliMixin, admin.ModelAdmin):
    list_display = ('name', 'is_active')
    list_filter = ('is_active',)
    search_fields = ('name', 'description')
    filter_horizontal = ('members',)


@admin.register(TicketLabel)
class TicketLabelAdmin(
        JalaliDateDisplayMixin, ModelAdminJalaliMixin, admin.ModelAdmin):
    list_display = ('name', 'color')
    search_fields = ('name',)


@admin.register(Ticket)
class TicketAdmin(JalaliDateDisplayMixin, ModelAdminJalaliMixin, admin.ModelAdmin):
    list_display = (
        'id',
        'title',
        'customer',
        'status',
        'priority',
        'assigned_to',
        'created_at_display')
    list_filter = ('status', 'priority', 'category', 'department', 'is_pinned')
    search_fields = (
        'title',
        'description',
        'customer__username',
        'customer__email')
    date_hierarchy = 'created_at'
    readonly_fields = ('created_at', 'updated_at', 'closed_at', 'view_count')
    filter_horizontal = ('labels',)

    fieldsets = (
        ('اطلاعات اصلی', {
            'fields': ('title', 'description', 'customer', 'assigned_to')
        }),
        ('وضعیت و اولویت', {
            'fields': ('status', 'priority', 'category', 'department', 'labels')
        }),
        ('زمان‌بندی', {
            'fields': ('due_date', 'closed_at')
        }),
        ('تنظیمات', {
            'fields': ('is_pinned', 'is_confidential')
        }),
        ('آمار', {
            'fields': ('view_count', 'created_at', 'updated_at'),
            'classes': ('collapse',)
        }),
    )


@admin.register(TicketComment)
class TicketCommentAdmin(
        JalaliDateDisplayMixin, ModelAdminJalaliMixin, admin.ModelAdmin):
    list_display = ('ticket', 'user', 'is_internal', 'created_at_display')
    list_filter = ('is_internal', 'created_at')
    search_fields = ('content', 'user__username')


@admin.register(TicketAttachment)
class TicketAttachmentAdmin(
        JalaliDateDisplayMixin, ModelAdminJalaliMixin, admin.ModelAdmin):
    list_display = (
        'filename',
        'ticket',
        'uploaded_by',
        'file_size',
        'uploaded_at_display')
    list_filter = ('uploaded_at',)
    search_fields = ('filename',)


@admin.register(TicketActivityLog)
class TicketActivityLogAdmin(
        JalaliDateDisplayMixin, ModelAdminJalaliMixin, admin.ModelAdmin):
    list_display = ('ticket', 'user', 'action', 'created_at_display')
    list_filter = ('action', 'created_at')
    search_fields = ('user__username',)


@admin.register(SavedReply)
class SavedReplyAdmin(
        JalaliDateDisplayMixin, ModelAdminJalaliMixin, admin.ModelAdmin):
    list_display = (
        'title',
        'category',
        'is_active',
        'created_by',
        'created_at_display')
    list_filter = ('is_active', 'category')
    search_fields = ('title', 'content')


@admin.register(KnowledgeBaseCategory)
class KnowledgeBaseCategoryAdmin(
        JalaliDateDisplayMixin, ModelAdminJalaliMixin, admin.ModelAdmin):
    list_display = ('name', 'parent', 'is_active', 'order')
    list_filter = ('is_active',)
    search_fields = ('name', 'description')


@admin.register(KnowledgeBaseArticle)
class KnowledgeBaseArticleAdmin(
        JalaliDateDisplayMixin, ModelAdminJalaliMixin, admin.ModelAdmin):
    list_display = (
        'title',
        'category',
        'is_published',
        'view_count',
        'created_at_display')
    list_filter = ('is_published', 'category')
    search_fields = ('title', 'summary', 'content', 'tags')


@admin.register(Announcement)
class AnnouncementAdmin(
        JalaliDateDisplayMixin, ModelAdminJalaliMixin, admin.ModelAdmin):
    list_display = (
        'title',
        'audience',
        'is_active',
        'created_by',
        'created_at_display')
    list_filter = ('is_active', 'audience')
    search_fields = ('title', 'content')


@admin.register(TicketNotification)
class TicketNotificationAdmin(
        JalaliDateDisplayMixin, ModelAdminJalaliMixin, admin.ModelAdmin):
    list_display = ('user', 'ticket', 'type', 'is_read', 'created_at_display')
    list_filter = ('is_read', 'type')
    search_fields = ('user__username',)


@admin.register(UserAccountSettings)
class UserAccountSettingsAdmin(
        JalaliDateDisplayMixin, ModelAdminJalaliMixin, admin.ModelAdmin):
    list_display = ('user', 'is_suspended', 'account_expiry')
    list_filter = ('is_suspended',)
    search_fields = ('user__username',)

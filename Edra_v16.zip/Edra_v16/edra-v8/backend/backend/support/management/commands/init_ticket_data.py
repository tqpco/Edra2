from django.core.management.base import BaseCommand
from support.models import TicketCategory, TicketPriority, TicketStatus


class Command(BaseCommand):
    help = 'ایجاد داده‌های اولیه برای سیستم تیکتینگ (دسته‌بندی، اولویت، وضعیت)'

    def handle(self, *args, **options):
        # ایجاد دسته‌بندی‌های پیش‌فرض
        categories = [
            {'name': 'عمومی', 'description': 'مسائل عمومی و متفرقه', 'is_active': True},
            {'name': 'فنی', 'description': 'مشکلات فنی و باگ‌ها', 'is_active': True},
            {'name': 'مالی', 'description': 'مسائل مالی و صورتحساب', 'is_active': True},
            {'name': 'پشتیبانی', 'description': 'سوالات پشتیبانی و راهنمایی', 'is_active': True},
        ]
        for cat in categories:
            obj, created = TicketCategory.objects.get_or_create(
                name=cat['name'], defaults=cat)
            if created:
                self.stdout.write(
                    self.style.SUCCESS(
                        f'دسته‌بندی "{
                            cat["name"]}" ایجاد شد.'))

        # ایجاد اولویت‌های پیش‌فرض
        priorities = [
            {'name': 'کم', 'color': '#6B7280', 'weight': 1, 'is_active': True},
            {'name': 'متوسط', 'color': '#F59E0B', 'weight': 2, 'is_active': True},
            {'name': 'بالا', 'color': '#EF4444', 'weight': 3, 'is_active': True},
            {'name': 'فوری', 'color': '#DC2626', 'weight': 4, 'is_active': True},
        ]
        for pri in priorities:
            obj, created = TicketPriority.objects.get_or_create(
                name=pri['name'], defaults=pri)
            if created:
                self.stdout.write(
                    self.style.SUCCESS(
                        f'اولویت "{
                            pri["name"]}" ایجاد شد.'))

        # ایجاد وضعیت‌های پیش‌فرض
        statuses = [
            {'name': 'باز', 'color': '#3B82F6', 'is_closed': False, 'is_active': True},
            {'name': 'در حال بررسی', 'color': '#F59E0B', 'is_closed': False, 'is_active': True},
            {'name': 'پاسخ داده شده', 'color': '#8B5CF6', 'is_closed': False, 'is_active': True},
            {'name': 'بسته شده', 'color': '#6B7280', 'is_closed': True, 'is_active': True},
            {'name': 'حل شده', 'color': '#10B981', 'is_closed': True, 'is_active': True},
        ]
        for st in statuses:
            obj, created = TicketStatus.objects.get_or_create(
                name=st['name'], defaults=st)
            if created:
                self.stdout.write(
                    self.style.SUCCESS(
                        f'وضعیت "{
                            st["name"]}" ایجاد شد.'))

        self.stdout.write(self.style.SUCCESS(
            '✅ داده‌های اولیه تیکتینگ با موفقیت ایجاد شد.'))

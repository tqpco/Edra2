# support/serializers.py
from rest_framework import serializers
from django.utils import timezone
import jdatetime
from .models import (
    TicketSystemSettings, TicketCategory, TicketPriority, TicketStatus,
    TicketDepartment, TicketLabel, Ticket, TicketComment, TicketAttachment,
    TicketActivityLog, SavedReply, KnowledgeBaseCategory, KnowledgeBaseArticle,
    Announcement, TicketNotification, UserAccountSettings
)


def to_jalali(dt):
    if not dt:
        return None
    try:
        if timezone.is_aware(dt):
            dt = timezone.localtime(dt)
        else:
            dt = timezone.make_aware(dt, timezone.get_current_timezone())
        jalali = jdatetime.datetime.fromgregorian(datetime=dt)
        return jalali.strftime("%Y/%m/%d - %H:%M")
    except Exception:
        return str(dt)


class TicketSystemSettingsSerializer(serializers.ModelSerializer):
    class Meta:
        model = TicketSystemSettings
        fields = '__all__'


class TicketCategorySerializer(serializers.ModelSerializer):
    class Meta:
        model = TicketCategory
        fields = '__all__'


class TicketPrioritySerializer(serializers.ModelSerializer):
    class Meta:
        model = TicketPriority
        fields = '__all__'


class TicketStatusSerializer(serializers.ModelSerializer):
    class Meta:
        model = TicketStatus
        fields = '__all__'


class TicketDepartmentSerializer(serializers.ModelSerializer):
    members_count = serializers.IntegerField(
        source='members.count', read_only=True)

    class Meta:
        model = TicketDepartment
        fields = '__all__'


class TicketLabelSerializer(serializers.ModelSerializer):
    class Meta:
        model = TicketLabel
        fields = '__all__'


# ============================================================
# سریالایزرهای تیکت با تاریخ شمسی
# ============================================================

class TicketCommentSerializer(serializers.ModelSerializer):
    """
    EDRA v5 — CRITICAL-14: فیلدهای صریح (نه __all__).
    برای مشتری، کامنت‌های internal در TicketDetailSerializer فیلتر می‌شوند.
    """
    user_name = serializers.CharField(
        source='user.get_full_name', read_only=True)
    created_at_jalali = serializers.SerializerMethodField()
    updated_at_jalali = serializers.SerializerMethodField()

    class Meta:
        model = TicketComment
        fields = (
            'id', 'ticket', 'user', 'user_name', 'content', 'is_internal',
            'created_at', 'created_at_jalali', 'updated_at',
            'updated_at_jalali')
        read_only_fields = ('created_at', 'updated_at', 'user')

    def get_created_at_jalali(self, obj):
        return to_jalali(obj.created_at)

    def get_updated_at_jalali(self, obj):
        return to_jalali(obj.updated_at)


class TicketUpdateSerializer(serializers.ModelSerializer):
    """
    EDRA v5 — HIGH-15: update عمومی فقط فیلدهای متنی/برچسب را اجازه می‌دهد.
    workflow (status/priority/assigned_to/department/customer) فقط از
    اکشن‌های Support/Admin تغییر می‌کند.
    """
    class Meta:
        model = Ticket
        fields = (
            'id', 'title', 'description', 'due_date', 'labels')
        extra_kwargs = {
            'title': {'required': False},
            'description': {'required': False},
            'due_date': {'required': False},
            'labels': {'required': False},
        }


class TicketAttachmentSerializer(serializers.ModelSerializer):
    uploaded_at_jalali = serializers.SerializerMethodField()

    class Meta:
        model = TicketAttachment
        fields = '__all__'
        read_only_fields = ('uploaded_at', 'uploaded_by')

    def get_uploaded_at_jalali(self, obj):
        return to_jalali(obj.uploaded_at)


class TicketActivityLogSerializer(serializers.ModelSerializer):
    user_name = serializers.CharField(
        source='user.get_full_name', read_only=True)
    created_at_jalali = serializers.SerializerMethodField()

    class Meta:
        model = TicketActivityLog
        fields = '__all__'
        read_only_fields = ('created_at',)

    def get_created_at_jalali(self, obj):
        return to_jalali(obj.created_at)


class TicketListSerializer(serializers.ModelSerializer):
    customer_name = serializers.CharField(
        source='customer.get_full_name', read_only=True)
    assigned_to_name = serializers.CharField(
        source='assigned_to.get_full_name', read_only=True)
    status_name = serializers.CharField(source='status.name', read_only=True)
    priority_name = serializers.CharField(
        source='priority.name', read_only=True)
    comments_count = serializers.SerializerMethodField()
    created_at_jalali = serializers.SerializerMethodField()
    updated_at_jalali = serializers.SerializerMethodField()

    class Meta:
        model = Ticket
        fields = (
            'id',
            'title',
            'customer_name',
            'assigned_to_name',
            'status_name',
            'priority_name',
            'created_at',
            'updated_at',
            'comments_count',
            'is_pinned',
            'created_at_jalali',
            'updated_at_jalali')
        read_only_fields = ('created_at', 'updated_at')

    def get_comments_count(self, obj):
        return obj.comments.count()

    def get_created_at_jalali(self, obj):
        return to_jalali(obj.created_at)

    def get_updated_at_jalali(self, obj):
        return to_jalali(obj.updated_at)


class TicketCreateSerializer(serializers.ModelSerializer):
    category = serializers.PrimaryKeyRelatedField(
        queryset=TicketCategory.objects.all(),
        required=False,
        allow_null=True
    )
    priority = serializers.PrimaryKeyRelatedField(
        queryset=TicketPriority.objects.all(),
        required=False,
        allow_null=True
    )

    class Meta:
        model = Ticket
        fields = (
            'id',
            'title',
            'description',
            'category',
            'priority',
            'department',
            'due_date',
            'is_confidential',
            'labels')
        extra_kwargs = {
            'title': {
                'required': True,
                'error_messages': {
                    'required': 'عنوان تیکت الزامی است.',
                    'blank': 'عنوان تیکت نمی‌تواند خالی باشد.'
                }
            },
            'description': {
                'required': True,
                'error_messages': {
                    'required': 'توضیحات تیکت الزامی است.',
                    'blank': 'توضیحات تیکت نمی‌تواند خالی باشد.'
                }
            },
            'department': {'required': False},
            'due_date': {'required': False},
            'is_confidential': {'required': False},
            'labels': {'required': False},
        }

    def create(self, validated_data):
        request = self.context.get('request')
        if not request or not request.user.is_authenticated:
            raise serializers.ValidationError("کاربر احراز هویت نشده است.")

        if not validated_data.get('category'):
            category = TicketCategory.objects.filter(is_active=True).first()
            if category:
                validated_data['category'] = category
            else:
                category = TicketCategory.objects.create(
                    name='عمومی',
                    description='دسته‌بندی پیش‌فرض برای تیکت‌ها',
                    is_active=True
                )
                validated_data['category'] = category

        if not validated_data.get('priority'):
            priority = TicketPriority.objects.filter(is_active=True).first()
            if priority:
                validated_data['priority'] = priority
            else:
                priority = TicketPriority.objects.create(
                    name='متوسط',
                    color='#6B7280',
                    weight=1,
                    is_active=True
                )
                validated_data['priority'] = priority

        validated_data['customer'] = request.user
        return super().create(validated_data)

    def validate_title(self, value):
        if len(value.strip()) < 3:
            raise serializers.ValidationError(
                "عنوان تیکت باید حداقل ۳ کاراکتر باشد.")
        return value.strip()

    def validate_description(self, value):
        if len(value.strip()) < 10:
            raise serializers.ValidationError(
                "توضیحات تیکت باید حداقل ۱۰ کاراکتر باشد.")
        return value.strip()


class TicketDetailSerializer(serializers.ModelSerializer):
    """
    EDRA v5 — CRITICAL-14: فیلدهای صریح. کامنت‌های internal فقط برای
    Support/Admin نمایش داده می‌شوند (confidentiality boundary).
    """
    customer_name = serializers.CharField(
        source='customer.get_full_name', read_only=True)
    assigned_to_name = serializers.CharField(
        source='assigned_to.get_full_name', read_only=True)
    status_name = serializers.CharField(source='status.name', read_only=True)
    priority_name = serializers.CharField(
        source='priority.name', read_only=True)
    category_name = serializers.CharField(
        source='category.name', read_only=True)
    department_name = serializers.CharField(
        source='department.name', read_only=True)
    comments = serializers.SerializerMethodField()
    attachments = TicketAttachmentSerializer(many=True, read_only=True)
    activity_logs = TicketActivityLogSerializer(many=True, read_only=True)
    comments_count = serializers.SerializerMethodField()
    created_at_jalali = serializers.SerializerMethodField()
    updated_at_jalali = serializers.SerializerMethodField()
    closed_at_jalali = serializers.SerializerMethodField()
    due_date_jalali = serializers.SerializerMethodField()

    class Meta:
        model = Ticket
        fields = (
            'id', 'title', 'description', 'customer', 'customer_name',
            'assigned_to', 'assigned_to_name', 'status', 'status_name',
            'priority', 'priority_name', 'category', 'category_name',
            'department', 'department_name', 'comments', 'attachments',
            'activity_logs', 'comments_count', 'is_pinned', 'due_date',
            'due_date_jalali', 'closed_at', 'closed_at_jalali', 'view_count',
            'created_at', 'created_at_jalali', 'updated_at',
            'updated_at_jalali')
        read_only_fields = (
            'created_at', 'updated_at', 'closed_at', 'view_count')

    def get_comments(self, obj):
        """CRITICAL-14: کامنت داخلی فقط برای Support/Admin."""
        request = self.context.get('request')
        user = getattr(request, 'user', None)
        can_see_internal = bool(
            user and user.is_authenticated
            and (user.is_staff
                 or user.groups.filter(name__in=['Support', 'Admin']).exists()))
        qs = obj.comments.all()
        if not can_see_internal:
            qs = qs.filter(is_internal=False)
        return TicketCommentSerializer(qs, many=True).data

    def get_comments_count(self, obj):
        return obj.comments.count()

    def get_created_at_jalali(self, obj):
        return to_jalali(obj.created_at)

    def get_updated_at_jalali(self, obj):
        return to_jalali(obj.updated_at)

    def get_closed_at_jalali(self, obj):
        return to_jalali(obj.closed_at)

    def get_due_date_jalali(self, obj):
        return to_jalali(obj.due_date)


# ============================================================
# سایر سریالایزرها (بدون تغییر)
# ============================================================

class SavedReplySerializer(serializers.ModelSerializer):
    class Meta:
        model = SavedReply
        fields = '__all__'
        read_only_fields = ('created_at', 'created_by')


class KnowledgeBaseCategorySerializer(serializers.ModelSerializer):
    class Meta:
        model = KnowledgeBaseCategory
        fields = '__all__'


class KnowledgeBaseArticleSerializer(serializers.ModelSerializer):
    category_name = serializers.CharField(
        source='category.name', read_only=True)

    class Meta:
        model = KnowledgeBaseArticle
        fields = '__all__'
        read_only_fields = (
            'created_at',
            'updated_at',
            'created_by',
            'view_count')


class AnnouncementSerializer(serializers.ModelSerializer):
    created_by_name = serializers.CharField(
        source='created_by.get_full_name', read_only=True)
    created_at_jalali = serializers.SerializerMethodField()
    expires_at_jalali = serializers.SerializerMethodField()

    class Meta:
        model = Announcement
        fields = '__all__'
        read_only_fields = ('created_at', 'created_by')

    def get_created_at_jalali(self, obj):
        return to_jalali(obj.created_at)

    def get_expires_at_jalali(self, obj):
        return to_jalali(obj.expires_at)


class TicketNotificationSerializer(serializers.ModelSerializer):
    created_at_jalali = serializers.SerializerMethodField()

    class Meta:
        model = TicketNotification
        fields = '__all__'
        read_only_fields = ('created_at',)

    def get_created_at_jalali(self, obj):
        return to_jalali(obj.created_at)


class UserAccountSettingsSerializer(serializers.ModelSerializer):
    created_at_jalali = serializers.SerializerMethodField()
    updated_at_jalali = serializers.SerializerMethodField()

    class Meta:
        model = UserAccountSettings
        fields = '__all__'
        read_only_fields = ('created_at', 'updated_at')

    def get_created_at_jalali(self, obj):
        return to_jalali(obj.created_at)

    def get_updated_at_jalali(self, obj):
        return to_jalali(obj.updated_at)

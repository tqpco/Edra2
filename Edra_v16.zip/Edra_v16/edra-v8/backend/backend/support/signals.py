from django.db.models.signals import post_save
from django.dispatch import receiver
import logging

from .models import Ticket, TicketComment

logger = logging.getLogger(__name__)


@receiver(post_save, sender=Ticket)
def ticket_created_or_updated(sender, instance, created, **kwargs):
    """
    سیگنال برای ثبت لاگ و ارسال اعلان هنگام ایجاد یا تغییر تیکت
    """
    if created:
        logger.info(f"New ticket created: #{instance.id} - {instance.title}")
        # در صورت نیاز، اعلان به ادمین‌ها ارسال شود
    else:
        # تغییر وضعیت یا اولویت
        logger.info(
            f"Ticket #{
                instance.id} updated: status={
                instance.status}, priority={
                instance.priority}")


@receiver(post_save, sender=TicketComment)
def ticket_comment_created(sender, instance, created, **kwargs):
    """
    سیگنال برای ثبت لاگ و ارسال اعلان هنگام ایجاد کامنت در تیکت
    """
    if created:
        logger.info(
            f"New comment on ticket #{
                instance.ticket.id} by {
                instance.user.username}")
        # در صورت نیاز، اعلان به کاربران مربوطه ارسال شود

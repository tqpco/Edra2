from celery import shared_task
import logging

from django.core.mail import send_mail
from django.conf import settings
from .models import Ticket, TicketNotification

logger = logging.getLogger(__name__)


@shared_task
def send_ticket_assignment_notification(
        ticket_id, assigned_to_id, assigned_by_id):
    """
    تسک برای ارسال ایمیل اعلان تخصیص تیکت
    """
    from django.contrib.auth import get_user_model
    User = get_user_model()

    try:
        ticket = Ticket.objects.get(id=ticket_id)
        assigned_to = User.objects.get(id=assigned_to_id)
        assigned_by = User.objects.get(id=assigned_by_id)

        subject = f"تیکت #{ticket.id} به شما اختصاص داده شد"
        message = f"""
        سلام {assigned_to.get_full_name() or assigned_to.username}

        تیکت "{ticket.title}" توسط {assigned_by.get_full_name() or assigned_by.username} به شما اختصاص داده شد.

        لطفاً برای مشاهده تیکت به سامانه مراجعه کنید.
        """

        send_mail(
            subject=subject,
            message=message,
            from_email=settings.DEFAULT_FROM_EMAIL,
            recipient_list=[assigned_to.email],
            fail_silently=True
        )

        # ثبت اعلان در دیتابیس
        TicketNotification.objects.create(
            user=assigned_to,
            ticket=ticket,
            type='assigned',
            message=f'تیکت #{ticket.id} به شما اختصاص داده شد.'
        )

        logger.info(
            f"Ticket assignment notification sent for ticket {
                ticket.id}")
        return True
    except Exception as e:
        logger.error(f"Error sending ticket assignment notification: {e}")
        return False


@shared_task
def auto_close_inactive_tickets():
    """
    بستن خودکار تیکت‌هایی که پشتیبانی پاسخ داده ولی ۷۲ ساعت از مشتری
    پاسخی نیامده (یعنی آخرین نظر از طرف خود مشتری *نبوده*). تیکت‌هایی
    که هنوز پاسخی از پشتیبانی نگرفته‌اند (یا آخرین نظر از خود مشتری است،
    یعنی منتظر پشتیبانی است) دست‌نخورده باقی می‌مانند تا هیچ درخواستی
    نادیده گرفته نشود.
    """
    from django.utils import timezone
    from django.db.models import Max
    from .models import Ticket, TicketStatus, TicketComment

    closed_status = TicketStatus.objects.filter(
        is_closed=True).order_by('id').first()
    if not closed_status:
        logger.warning(
            "auto_close_inactive_tickets: هیچ TicketStatus با "
            "is_closed=True تعریف نشده، تسک متوقف شد.")
        return 0

    cutoff = timezone.now() - timezone.timedelta(hours=72)

    candidates = Ticket.objects.filter(
        closed_at__isnull=True
    ).exclude(
        status=closed_status
    ).annotate(
        last_comment_at=Max('comments__created_at')
    )

    closed_count = 0
    for ticket in candidates:
        last_activity = ticket.last_comment_at or ticket.created_at
        if last_activity > cutoff:
            continue

        last_comment = ticket.comments.order_by('-created_at').first()
        # اگر هنوز هیچ پاسخی از پشتیبانی نیامده یا آخرین نظر از خود
        # مشتری است، یعنی این مشتری است که منتظر است - نباید بسته شود.
        if last_comment is None or last_comment.user_id == ticket.customer_id:
            continue

        ticket.status = closed_status
        ticket.closed_at = timezone.now()
        ticket.save(update_fields=['status', 'closed_at'])
        closed_count += 1

        TicketComment.objects.create(
            ticket=ticket,
            user=ticket.assigned_to or last_comment.user,
            content='این تیکت به دلیل عدم پاسخ طی ۷۲ ساعت به‌صورت خودکار بسته شد.',
            is_internal=True,
        )

    logger.info(
        f"auto_close_inactive_tickets: {closed_count} تیکت بسته شد.")
    return closed_count

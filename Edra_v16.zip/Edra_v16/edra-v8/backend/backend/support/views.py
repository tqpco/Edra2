# ============================================================
# ۲. فایل support/views.py (فایل کامل با اصلاح دسترسی)
# مسیر: backend/support/views.py
# ============================================================
from rest_framework import viewsets, generics, status
from rest_framework.decorators import action
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated, AllowAny
from core.permissions import (
    IsAdminUserOrGroup,
    IsAdminOrReadOnly, IsAdminOrSupportOrReadOnly, IsAdminOrAuthenticatedReadOnly,
)
from rest_framework.filters import SearchFilter, OrderingFilter
from django.db.models import Q
from django.utils import timezone
from django.core.mail import send_mail
from django.conf import settings
from .models import (Announcement, KnowledgeBaseArticle, KnowledgeBaseCategory, SavedReply, Ticket, TicketActivityLog, TicketAttachment, TicketCategory, TicketComment, TicketDepartment, TicketLabel, TicketNotification, TicketPriority, TicketStatus, TicketSystemSettings, User, UserAccountSettings, get_user_model, jmodels, models, ticket_attachment_upload_path)
from .serializers import (Announcement, AnnouncementSerializer, KnowledgeBaseArticle, KnowledgeBaseArticleSerializer, KnowledgeBaseCategory, KnowledgeBaseCategorySerializer, SavedReply, SavedReplySerializer, Ticket, TicketActivityLog, TicketActivityLogSerializer, TicketAttachment, TicketAttachmentSerializer, TicketCategory, TicketCategorySerializer, TicketComment, TicketCommentSerializer, TicketCreateSerializer, TicketDepartment, TicketDepartmentSerializer, TicketDetailSerializer, TicketLabel, TicketLabelSerializer, TicketListSerializer, TicketNotification, TicketNotificationSerializer, TicketPriority, TicketPrioritySerializer, TicketStatus, TicketStatusSerializer, TicketSystemSettings, TicketSystemSettingsSerializer, TicketUpdateSerializer, UserAccountSettings, UserAccountSettingsSerializer, jdatetime, serializers, timezone, to_jalali)
from django.contrib.auth import get_user_model

User = get_user_model()

try:
    from django_filters.rest_framework import DjangoFilterBackend
    HAS_FILTER = True
except ImportError:
    HAS_FILTER = False

    class DjangoFilterBackend:
        pass


class TicketViewSet(viewsets.ModelViewSet):
    # ← اصلاح شده از AllowAny به IsAuthenticated
    permission_classes = [IsAuthenticated]
    filter_backends = [SearchFilter, OrderingFilter]
    if HAS_FILTER:
        filter_backends.insert(0, DjangoFilterBackend)
        filterset_fields = [
            'status',
            'priority',
            'category',
            'department',
            'assigned_to',
            'customer',
            'is_pinned']
    search_fields = [
        'title',
        'description',
        'customer__username',
        'customer__email']
    ordering_fields = [
        'created_at',
        'due_date',
        'priority__weight',
        'is_pinned']

    def get_serializer_class(self):
        if self.action == 'create':
            return TicketCreateSerializer
        if self.action == 'retrieve':
            return TicketDetailSerializer
        # EDRA v5 — HIGH-15: update عمومی با serializer محدود (بدون
        # تغییر workflow از طریق PATCH).
        if self.action in ('update', 'partial_update'):
            return TicketUpdateSerializer
        return TicketListSerializer

    @staticmethod
    def _is_support_or_admin(user):
        return bool(
            user.is_authenticated
            and (user.is_staff
                 or user.groups.filter(name='Support').exists()
                 or user.groups.filter(name='Admin').exists()))

    def get_queryset(self):
        user = self.request.user
        # P1-12 (EDRA v8): prefetch سنگین فقط برای retrieve (جزئیات) لازم
        # است؛ در list بارگذاری همه comments/attachments برای هر تیکت
        # memory-heavy است. برای list فقط labels (سبک) prefetch می‌شود.
        if self.action == 'retrieve':
            queryset = Ticket.objects.prefetch_related(
                'labels', 'comments', 'attachments',
                'comments__user', 'comments__attachments')
        else:
            queryset = Ticket.objects.prefetch_related('labels')
        # EDRA v5 — HIGH-12: Support/Admin تمام تیکت‌ها را می‌بینند
        # (بدون نیاز به assignment — قبلاً support بدون تخصیص، تیکت را
        # 404 می‌گرفت و عملاً نمی‌توانست پشتیبانی کند).
        if (user.is_staff
                or user.groups.filter(name__in=['Support', 'Admin']).exists()):
            return queryset
        return queryset.filter(customer=user)

    def perform_create(self, serializer):
        ticket = serializer.save(customer=self.request.user)
        default_status = TicketStatus.objects.filter(is_active=True).first()
        if default_status:
            ticket.status = default_status
            ticket.save()
        TicketActivityLog.objects.create(
            ticket=ticket,
            user=self.request.user,
            action='created',
            details={'title': ticket.title}
        )
        self._send_notification(
            ticket, 'ticket_created', f'تیکت جدید توسط {
                self.request.user.username} ایجاد شد.')

    def _send_notification(self, ticket, type, message):
        admins = User.objects.filter(is_staff=True)
        for admin in admins:
            TicketNotification.objects.create(
                user=admin,
                ticket=ticket,
                type=type,
                message=message
            )
        try:
            send_mail(
                f'نوتیفیکیشن تیکت #{ticket.id}',
                message,
                settings.DEFAULT_FROM_EMAIL,
                [admin.email for admin in admins if admin.email],
                fail_silently=True
            )
        except Exception as e:
            pass

    @action(detail=True, methods=['post'])
    def assign(self, request, pk=None):
        ticket = self.get_object()
        user_id = request.data.get('user_id')
        if not user_id:
            return Response({'error': 'شناسه کاربر الزامی است.'}, status=400)
        try:
            user = User.objects.get(id=user_id)
        except User.DoesNotExist:
            return Response({'error': 'کاربر یافت نشد.'}, status=404)
        if not (
            request.user.is_staff or request.user.groups.filter(
                name='Support').exists()):
            return Response(
                {'error': 'شما مجاز به اختصاص تیکت نیستید.'}, status=403)
        ticket.assigned_to = user
        ticket.save()
        TicketActivityLog.objects.create(
            ticket=ticket,
            user=request.user,
            action='assigned',
            details={'assigned_to': user.username}
        )
        self._send_notification(
            ticket, 'ticket_assigned', f'تیکت #{
                ticket.id} به {
                user.username} اختصاص یافت.')
        return Response({'message': f'تیکت به {user.username} اختصاص یافت.'})

    @action(detail=True, methods=['post'])
    def change_status(self, request, pk=None):
        # EDRA v5 — HIGH-12: تغییر workflow فقط Support/Admin
        if not self._is_support_or_admin(request.user):
            return Response(
                {'error': 'شما مجاز به تغییر وضعیت تیکت نیستید.'}, status=403)
        ticket = self.get_object()
        status_id = request.data.get('status_id')
        if not status_id:
            return Response({'error': 'شناسه وضعیت الزامی است.'}, status=400)
        try:
            status = TicketStatus.objects.get(id=status_id)
        except TicketStatus.DoesNotExist:
            return Response({'error': 'وضعیت یافت نشد.'}, status=404)
        old_status = ticket.status
        ticket.status = status
        ticket.save()
        TicketActivityLog.objects.create(
            ticket=ticket,
            user=request.user,
            action='status_changed',
            details={
                'old_status': old_status.name if old_status else None,
                'new_status': status.name})
        self._send_notification(
            ticket,
            'ticket_status_changed',
            f'وضعیت تیکت #{
                ticket.id} به {
                status.name} تغییر یافت.')
        return Response({'message': f'وضعیت به {status.name} تغییر یافت.'})

    @action(detail=True, methods=['post'])
    def change_priority(self, request, pk=None):
        # EDRA v5 — HIGH-12
        if not self._is_support_or_admin(request.user):
            return Response(
                {'error': 'شما مجاز به تغییر اولویت تیکت نیستید.'}, status=403)
        ticket = self.get_object()
        priority_id = request.data.get('priority_id')
        if not priority_id:
            return Response({'error': 'شناسه اولویت الزامی است.'}, status=400)
        try:
            priority = TicketPriority.objects.get(id=priority_id)
        except TicketPriority.DoesNotExist:
            return Response({'error': 'اولویت یافت نشد.'}, status=404)
        old_priority = ticket.priority
        ticket.priority = priority
        ticket.save()
        TicketActivityLog.objects.create(
            ticket=ticket,
            user=request.user,
            action='priority_changed',
            details={
                'old_priority': old_priority.name if old_priority else None,
                'new_priority': priority.name})
        return Response({'message': f'اولویت به {priority.name} تغییر یافت.'})

    @action(detail=True, methods=['post'])
    def add_comment(self, request, pk=None):
        # EDRA v5 — CRITICAL-13: is_internal فقط برای Support/Admin.
        # Customer نمی‌تواند کامنت داخلی بسازد.
        can_internal = self._is_support_or_admin(request.user)
        is_internal = bool(request.data.get('is_internal', False))
        if is_internal and not can_internal:
            return Response(
                {'error': 'فقط پشتیبانی می‌تواند کامنت داخلی ثبت کند.'},
                status=403)
        ticket = self.get_object()
        content = request.data.get('content')
        if not content:
            return Response({'error': 'متن کامنت الزامی است.'}, status=400)
        comment = TicketComment.objects.create(
            ticket=ticket,
            user=request.user,
            content=content,
            is_internal=is_internal
        )
        # EDRA v6 — P1: اعتبارسنجی امن پیوست‌ها (validator مرکزی: پسوند +
        # حجم + magic bytes + PIL) — قبلاً هر فایلی بدون بررسی ذخیره می‌شد.
        from core.validators import validate_uploaded_file, ALLOWED_IMAGE_EXTENSIONS
        files = request.FILES.getlist('attachments')
        if len(files) > 10:
            return Response(
                {'error': 'حداکثر ۱۰ فایل پیوست مجاز است.'}, status=400)
        for file in files:
            file_error = validate_uploaded_file(
                file,
                allowed_extensions=ALLOWED_IMAGE_EXTENSIONS | {'.pdf', '.zip', '.doc', '.docx', '.xls', '.xlsx'},
                max_size=10 * 1024 * 1024)
            if file_error:
                return Response(
                    {'error': f'پیوست {file.name}: {file_error}'}, status=400)
        for file in files:
            TicketAttachment.objects.create(
                ticket=ticket,
                comment=comment,
                file=file,
                filename=file.name,
                file_size=file.size,
                uploaded_by=request.user
            )
        TicketActivityLog.objects.create(
            ticket=ticket,
            user=request.user,
            action='commented',
            details={'comment_id': comment.id}
        )
        message = f'کامنت جدید در تیکت #{
            ticket.id} توسط {
            request.user.username}'
        self._send_notification(ticket, 'ticket_comment', message)
        serializer = TicketCommentSerializer(comment)
        return Response(serializer.data, status=201)

    @action(detail=True, methods=['post'])
    def toggle_pin(self, request, pk=None):
        # EDRA v5 — HIGH-12
        if not self._is_support_or_admin(request.user):
            return Response(
                {'error': 'شما مجاز به پین کردن تیکت نیستید.'}, status=403)
        ticket = self.get_object()
        ticket.is_pinned = not ticket.is_pinned
        ticket.save()
        action_type = 'pinned' if ticket.is_pinned else 'unpinned'
        TicketActivityLog.objects.create(
            ticket=ticket,
            user=request.user,
            action=action_type,
            details={}
        )
        return Response({'message': 'پین تیکت با موفقیت تغییر یافت.'})

    @action(detail=True, methods=['post'])
    def refer(self, request, pk=None):
        # EDRA v5 — HIGH-12: ارجاع/اختصاص فقط Support/Admin
        if not self._is_support_or_admin(request.user):
            return Response(
                {'error': 'شما مجاز به ارجاع تیکت نیستید.'}, status=403)
        ticket = self.get_object()
        department_id = request.data.get('department_id')
        user_id = request.data.get('user_id')
        if department_id:
            try:
                dept = TicketDepartment.objects.get(id=department_id)
                ticket.department = dept
            except TicketDepartment.DoesNotExist:
                return Response({'error': 'دپارتمان یافت نشد.'}, status=404)
        if user_id:
            try:
                user = User.objects.get(id=user_id)
                ticket.assigned_to = user
            except User.DoesNotExist:
                return Response({'error': 'کاربر یافت نشد.'}, status=404)
        ticket.save()
        TicketActivityLog.objects.create(
            ticket=ticket,
            user=request.user,
            action='referred',
            details={'department': department_id, 'user': user_id}
        )
        self._send_notification(
            ticket, 'ticket_referred', f'تیکت #{
                ticket.id} ارجاع شد.')
        return Response({'message': 'تیکت با موفقیت ارجاع شد.'})


class TicketCategoryViewSet(viewsets.ModelViewSet):
    queryset = TicketCategory.objects.all()
    serializer_class = TicketCategorySerializer
    permission_classes = [IsAdminUserOrGroup]


class TicketPriorityViewSet(viewsets.ModelViewSet):
    queryset = TicketPriority.objects.all()
    serializer_class = TicketPrioritySerializer
    permission_classes = [IsAdminUserOrGroup]


class TicketStatusViewSet(viewsets.ModelViewSet):
    queryset = TicketStatus.objects.all()
    serializer_class = TicketStatusSerializer
    permission_classes = [IsAdminUserOrGroup]


class TicketDepartmentViewSet(viewsets.ModelViewSet):
    queryset = TicketDepartment.objects.all()
    serializer_class = TicketDepartmentSerializer
    permission_classes = [IsAdminUserOrGroup]


class TicketLabelViewSet(viewsets.ModelViewSet):
    queryset = TicketLabel.objects.all()
    serializer_class = TicketLabelSerializer
    permission_classes = [IsAdminUserOrGroup]


class SavedReplyViewSet(viewsets.ModelViewSet):
    queryset = SavedReply.objects.filter(is_active=True)
    serializer_class = SavedReplySerializer
    # CRITICAL-02: قبلاً IsAuthenticated بود که به هر کاربر عادی اجازه‌ی
    # create/update/delete پاسخ‌های ذخیره‌شده پشتیبانی را می‌داد. حالا
    # write فقط برای Admin و Support.
    permission_classes = [IsAdminOrSupportOrReadOnly]

    def perform_create(self, serializer):
        serializer.save(created_by=self.request.user)


class KnowledgeBaseCategoryViewSet(viewsets.ModelViewSet):
    queryset = KnowledgeBaseCategory.objects.filter(is_active=True)
    serializer_class = KnowledgeBaseCategorySerializer
    # CRITICAL-02: قبلاً AllowAny بود — هر anonymous کاربری می‌توانست
    # دسته‌بندی بسازد/حذف کند. خواندن عمومی، write فقط Admin.
    permission_classes = [IsAdminOrReadOnly]
    filter_backends = [SearchFilter]
    search_fields = ['name', 'description']


class KnowledgeBaseArticleViewSet(viewsets.ModelViewSet):
    queryset = KnowledgeBaseArticle.objects.filter(is_published=True)
    serializer_class = KnowledgeBaseArticleSerializer
    permission_classes = [IsAdminOrReadOnly]
    filter_backends = [SearchFilter]
    if HAS_FILTER:
        filter_backends.insert(0, DjangoFilterBackend)
        filterset_fields = ['category', 'is_published']
    search_fields = ['title', 'content', 'tags', 'summary']

    def get_queryset(self):
        if self.request.user.is_staff or (
                self.request.user.is_authenticated
                and self.request.user.groups.filter(name='Admin').exists()):
            return KnowledgeBaseArticle.objects.all()
        return KnowledgeBaseArticle.objects.filter(is_published=True)

    def retrieve(self, request, *args, **kwargs):
        instance = self.get_object()
        instance.view_count += 1
        instance.save(update_fields=['view_count'])
        return super().retrieve(request, *args, **kwargs)


class AnnouncementViewSet(viewsets.ModelViewSet):
    queryset = Announcement.objects.filter(is_active=True)
    serializer_class = AnnouncementSerializer
    # CRITICAL-02: قبلاً IsAuthenticated بود — هر کاربر احراز هویت‌شده
    # می‌توانست announcement بسازد/حذف کند. خواندن برای کاربران، write فقط Admin.
    permission_classes = [IsAdminOrAuthenticatedReadOnly]
    if HAS_FILTER:
        filter_backends = [DjangoFilterBackend]
        filterset_fields = ['audience']

    def get_queryset(self):
        user = self.request.user
        qs = super().get_queryset()
        if user.is_staff or (
                user.is_authenticated
                and user.groups.filter(name='Admin').exists()):
            return qs
        return qs.filter(Q(audience='customers') | Q(audience='all'))


class TicketNotificationViewSet(viewsets.ReadOnlyModelViewSet):
    serializer_class = TicketNotificationSerializer
    permission_classes = [IsAuthenticated]

    def get_queryset(self):
        return TicketNotification.objects.filter(
            user=self.request.user).order_by('-created_at')

    @action(detail=True, methods=['post'])
    def mark_read(self, request, pk=None):
        notification = self.get_object()
        if notification.user != request.user:
            return Response({'error': 'دسترسی غیرمجاز'}, status=403)
        notification.is_read = True
        notification.save()
        return Response({'message': 'نوتیفیکیشن خوانده شد.'})

    @action(detail=False, methods=['post'])
    def mark_all_read(self, request):
        TicketNotification.objects.filter(
            user=request.user,
            is_read=False).update(
            is_read=True)
        return Response({'message': 'همه نوتیفیکیشن‌ها خوانده شدند.'})


class TicketActivityLogViewSet(viewsets.ReadOnlyModelViewSet):
    queryset = TicketActivityLog.objects.all()
    serializer_class = TicketActivityLogSerializer
    permission_classes = [IsAdminUserOrGroup]
    filter_backends = [SearchFilter, OrderingFilter]
    search_fields = ['ticket__title', 'user__username', 'action']
    ordering_fields = ['created_at']


class UserAccountSettingsViewSet(viewsets.ModelViewSet):
    queryset = UserAccountSettings.objects.all()
    serializer_class = UserAccountSettingsSerializer
    permission_classes = [IsAdminUserOrGroup]
    filter_backends = [SearchFilter]
    search_fields = ['user__username', 'user__email']


class TicketSystemSettingsView(generics.RetrieveUpdateAPIView):
    queryset = TicketSystemSettings.objects.all()
    serializer_class = TicketSystemSettingsSerializer
    permission_classes = [IsAdminUserOrGroup]

    def get_object(self):
        return TicketSystemSettings.objects.first() or TicketSystemSettings.objects.create()

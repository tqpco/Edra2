# فرانت‌اند ادرو (Edra) - Next.js 16 + React 19 + Tailwind v4 + shadcn/ui

## پیش‌نیاز
- Node.js نسخه ۲۰ یا بالاتر
- بک‌اند جنگو باید همزمان روی `http://localhost:8000` در حال اجرا باشد (فایل بک‌اند را جدا دریافت کردی)

## راه‌اندازی

```bash
# ۱. نصب پکیج‌ها
npm install

# ۲. کپی متغیرهای محیطی
cp .env.local.example .env.local
# در صورت نیاز مقادیر داخلش رو ویرایش کن

# ۳. اجرای سرور توسعه
npm run dev
```

سایت روی `http://localhost:3000` بالا می‌آید.

## بررسی نوع (TypeScript)
```bash
npm run typecheck
```

## ساخت نسخه Production
```bash
npm run build
npm run start
```

## نکات مهم
- **فونت یکان بخ**: فایل‌های واقعی فونت (`.woff2`) باید در `public/fonts/` قرار بگیرند
  (چون در محیط ساخت این پروژه به اینترنت دسترسی نبود، فقط تعریف CSS آماده شده،
  خودِ فایل‌ها را باید اضافه کنی - نام‌های مورد انتظار در `app/globals.css` آمده).
- **احراز هویت**: توکن‌ها در کوکی httpOnly ذخیره می‌شوند (نه localStorage) - امن‌تر در برابر XSS.
- **اتصال به بک‌اند**: تمام درخواست‌های Client Component از `/api/proxy/*` عبور می‌کنند
  (که خودشان را با توکن معتبر به جنگو forward می‌کنند). Server Component ها مستقیم
  از `lib/api-server.ts` استفاده می‌کنند.

## ساختار پوشه‌ها
```
app/
  (marketing)/     صفحات عمومی: خانه، درباره، تماس، پروژه‌ها
  (auth)/          صفحات ورود (کارکنان + مشتری)
  dashboard/
    admin/          داشبورد مدیریت
    expert/         داشبورد کارشناس
    customer/       داشبورد مشتری
  booking/          ویزارد ۸ مرحله‌ای رزرو
  payment/          صفحات نتیجه پرداخت
  api/              Route Handler ها (auth, proxy)
components/
  ui/               کامپوننت‌های پایه shadcn
  layout/           سایدبار، نوار بالا
  shared/           کامپوننت‌های مشترک بین داشبوردها
  marketing/        کامپوننت‌های صفحات عمومی
  wizard/           مراحل ویزارد رزرو
lib/                توابع کمکی (تقویم جلالی، API client، ...)
```

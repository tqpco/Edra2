"use client";

import * as React from "react";
import { useRouter, useSearchParams } from "next/navigation";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Loader2, Phone, ShieldAlert, ArrowRight } from "lucide-react";

import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { toPersianDigits, toEnglishDigits } from "@/lib/jalali";
import { getDashboardPath } from "@/types/user";
import { safeNextPath } from "@/lib/safe-redirect";
import type { User } from "@/types/user";

const phoneSchema = z.object({
  phone: z
    .string()
    .transform(toEnglishDigits)
    .pipe(z.string().regex(/^09\d{9}$/, "شماره موبایل معتبر نیست (مثال: ۰۹۱۲۳۴۵۶۷۸۹)")),
});
type PhoneValues = z.infer<typeof phoneSchema>;

const codeSchema = z.object({
  code: z
    .string()
    .transform(toEnglishDigits)
    .pipe(z.string().regex(/^\d{6}$/, "کد تایید باید ۶ رقم باشد")),
});
type CodeValues = z.infer<typeof codeSchema>;

const RESEND_SECONDS = 120;

export function CustomerOtpForm() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const [step, setStep] = React.useState<"phone" | "code">("phone");
  const [phone, setPhone] = React.useState("");
  const [serverError, setServerError] = React.useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = React.useState(false);
  const [secondsLeft, setSecondsLeft] = React.useState(0);

  const phoneForm = useForm<PhoneValues>({ resolver: zodResolver(phoneSchema) });
  const codeForm = useForm<CodeValues>({ resolver: zodResolver(codeSchema) });

  React.useEffect(() => {
    if (secondsLeft <= 0) return;
    const t = setInterval(() => setSecondsLeft((s: number) => s - 1), 1000);
    return () => clearInterval(t);
  }, [secondsLeft]);

  async function requestOtp(values: PhoneValues) {
    setServerError(null);
    setIsSubmitting(true);
    try {
      const res = await fetch("/api/auth/otp-request", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ phone: values.phone }),
      });
      const data = await res.json();
      if (!res.ok) {
        setServerError(data.error || data.detail || "ارسال کد ناموفق بود.");
        return;
      }
      setPhone(values.phone);
      setStep("code");
      setSecondsLeft(RESEND_SECONDS);
    } catch {
      setServerError("ارتباط با سرور برقرار نشد. دوباره تلاش کنید.");
    } finally {
      setIsSubmitting(false);
    }
  }

  async function verifyOtp(values: CodeValues) {
    setServerError(null);
    setIsSubmitting(true);
    try {
      const res = await fetch("/api/auth/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ phone, code: values.code }),
      });
      const data = await res.json();
      if (!res.ok) {
        setServerError(data.error || data.detail || "کد وارد شده نامعتبر است.");
        return;
      }
      const user = data.user as User;
      const next = safeNextPath(searchParams.get("next"));
      router.push(next || getDashboardPath(user));
      router.refresh();
    } catch {
      setServerError("ارتباط با سرور برقرار نشد. دوباره تلاش کنید.");
    } finally {
      setIsSubmitting(false);
    }
  }

  if (step === "phone") {
    return (
      <form
        onSubmit={phoneForm.handleSubmit(requestOtp)}
        className="grid gap-5"
        noValidate
      >
        {serverError && (
          <Alert variant="destructive">
            <ShieldAlert />
            <AlertDescription>{serverError}</AlertDescription>
          </Alert>
        )}
        <div className="grid gap-2">
          <Label htmlFor="phone">شماره موبایل</Label>
          <div className="relative">
            <Phone className="text-muted-foreground pointer-events-none absolute right-3 top-1/2 size-4 -translate-y-1/2" />
            <Input
              id="phone"
              inputMode="numeric"
              dir="ltr"
              className="pr-9 text-center tracking-widest"
              placeholder="09123456789"
              aria-invalid={!!phoneForm.formState.errors.phone}
              {...phoneForm.register("phone")}
            />
          </div>
          {phoneForm.formState.errors.phone && (
            <p className="text-destructive text-xs">
              {phoneForm.formState.errors.phone.message}
            </p>
          )}
        </div>
        <Button type="submit" disabled={isSubmitting}>
          {isSubmitting && <Loader2 className="animate-spin" />}
          دریافت کد تایید
        </Button>
      </form>
    );
  }

  return (
    <form onSubmit={codeForm.handleSubmit(verifyOtp)} className="grid gap-5" noValidate>
      {serverError && (
        <Alert variant="destructive">
          <ShieldAlert />
          <AlertDescription>{serverError}</AlertDescription>
        </Alert>
      )}
      <div className="grid gap-2">
        <Label htmlFor="code">
          کد ۶ رقمی ارسال‌شده به {toPersianDigits(phone)}
        </Label>
        <Input
          id="code"
          inputMode="numeric"
          dir="ltr"
          maxLength={6}
          className="text-center text-lg tracking-[0.5em]"
          placeholder="------"
          autoFocus
          aria-invalid={!!codeForm.formState.errors.code}
          {...codeForm.register("code")}
        />
        {codeForm.formState.errors.code && (
          <p className="text-destructive text-xs">
            {codeForm.formState.errors.code.message}
          </p>
        )}
      </div>

      <Button type="submit" disabled={isSubmitting}>
        {isSubmitting && <Loader2 className="animate-spin" />}
        تایید و ورود
      </Button>

      <div className="flex items-center justify-between text-sm">
        <button
          type="button"
          onClick={() => {
            setStep("phone");
            setServerError(null);
          }}
          className="text-muted-foreground hover:text-foreground inline-flex items-center gap-1"
        >
          <ArrowRight className="size-3.5" />
          تغییر شماره
        </button>
        {secondsLeft > 0 ? (
          <span className="text-muted-foreground">
            ارسال مجدد تا {toPersianDigits(secondsLeft)} ثانیه دیگر
          </span>
        ) : (
          <button
            type="button"
            className="text-primary hover:underline"
            onClick={() => phoneForm.handleSubmit(requestOtp)()}
          >
            ارسال مجدد کد
          </button>
        )}
      </div>
    </form>
  );
}

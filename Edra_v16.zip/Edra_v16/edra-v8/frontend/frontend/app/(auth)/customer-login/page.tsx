import type { Metadata } from "next";
import { Suspense } from "react";
import { AuthShell } from "@/components/shared/auth-shell";
import { CustomerOtpForm } from "./customer-otp-form";

export const metadata: Metadata = {
  title: "ورود / ثبت‌نام مشتریان",
};

export default function CustomerLoginPage() {
  return (
    <AuthShell
      title="ورود یا ثبت‌نام"
      subtitle="با شماره موبایل خود وارد شوید - اگر حساب ندارید، به‌صورت خودکار ساخته می‌شود"
    >
      <Suspense>
        <CustomerOtpForm />
      </Suspense>
    </AuthShell>
  );
}

import type { Metadata } from "next";
import { Suspense } from "react";
import { AuthShell } from "@/components/shared/auth-shell";
import { StaffLoginForm } from "./staff-login-form";

export const metadata: Metadata = {
  title: "ورود پنل مدیریت و کارشناسی",
};

export default function LoginPage() {
  return (
    <AuthShell
      title="ورود به پنل"
      subtitle="ویژه‌ی مدیران و کارشناسان بازرسی"
    >
      <Suspense>
        <StaffLoginForm />
      </Suspense>
    </AuthShell>
  );
}

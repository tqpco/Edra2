import type { Metadata } from "next";
import { Target, Eye, ShieldCheck, Users, Award, Zap, ArrowLeft } from "lucide-react";
import Link from "next/link";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";

export const metadata: Metadata = { title: "درباره ما" };

/* EDRA v11 — بازطراحی مینیمال: پالت خاکستری / مشکی / سفید */

const VALUES = [
  {
    icon: ShieldCheck,
    title: "دقت و استانداردسازی",
    desc: "چک‌لیست‌های بازرسی متناسب با هر نوع تجهیز، طراحی‌شده توسط کارشناسان مجرب",
  },
  {
    icon: Zap,
    title: "سرعت در ارائه خدمات",
    desc: "از ثبت درخواست تا دریافت گزارش نهایی، با کمترین زمان انتظار",
  },
  {
    icon: Users,
    title: "شبکه کارشناسان مجرب",
    desc: "تیمی از کارشناسان بازرسی با سال‌ها تجربه در صنعت تجهیزات سنگین",
  },
  {
    icon: Award,
    title: "شفافیت کامل",
    desc: "قیمت‌گذاری شفاف، پیگیری آنلاین وضعیت درخواست در هر لحظه",
  },
];

export default function AboutPage() {
  return (
    <div className="mx-auto max-w-4xl px-4 py-16">
      {/* هدر — مینیمال */}
      <div className="mb-16 text-center">
        <span className="mb-4 inline-block rounded-full border border-neutral-300 bg-white px-3 py-1 text-xs font-medium text-neutral-600">
          درباره ادرو
        </span>
        <h1 className="text-3xl font-bold tracking-tight text-neutral-950 sm:text-4xl">
          استاندارد دیجیتال بازرسی تجهیزات صنعتی
        </h1>
        <p className="mx-auto mt-5 max-w-2xl leading-relaxed text-neutral-500">
          ادرو با هدف دیجیتالی‌کردن و استانداردسازی فرآیند بازرسی تجهیزات
          سنگین صنعتی راه‌اندازی شده است. ما مسیر رزرو، انجام بازرسی و صدور
          گواهی را از یک فرآیند کاغذی و پراکنده، به تجربه‌ای سریع، شفاف و
          کاملاً آنلاین تبدیل کرده‌ایم.
        </p>
      </div>

      {/* ماموریت / چشم‌انداز */}
      <div className="mb-16 grid gap-6 sm:grid-cols-2">
        <Card className="border-neutral-200 bg-white">
          <CardContent className="flex flex-col gap-3 px-6 py-7">
            <span className="flex size-11 items-center justify-center rounded-lg border border-neutral-200 bg-white text-neutral-950">
              <Target className="size-5" strokeWidth={1.5} />
            </span>
            <h2 className="font-semibold text-neutral-900">ماموریت ما</h2>
            <p className="text-sm leading-relaxed text-neutral-500">
              تضمین ایمنی محیط‌های کاری صنعتی از طریق ارائه‌ی خدمات بازرسی
              سریع، استاندارد و قابل‌استناد برای تمام تجهیزات سنگین.
            </p>
          </CardContent>
        </Card>
        <Card className="border-neutral-200 bg-white">
          <CardContent className="flex flex-col gap-3 px-6 py-7">
            <span className="flex size-11 items-center justify-center rounded-lg border border-neutral-200 bg-white text-neutral-950">
              <Eye className="size-5" strokeWidth={1.5} />
            </span>
            <h2 className="font-semibold text-neutral-900">چشم‌انداز ما</h2>
            <p className="text-sm leading-relaxed text-neutral-500">
              تبدیل‌شدن به مرجع اصلی بازرسی و صدور گواهی تجهیزات صنعتی در
              ایران، با پوشش کامل انواع تجهیزات و شهرها.
            </p>
          </CardContent>
        </Card>
      </div>

      {/* ارزش‌ها — لیست مینیمال */}
      <div className="mb-16">
        <h2 className="mb-8 text-center text-2xl font-bold tracking-tight text-neutral-950">
          ارزش‌های ما
        </h2>
        <div className="grid gap-6 sm:grid-cols-2">
          {VALUES.map((v) => (
            <div
              key={v.title}
              className="flex items-start gap-4 rounded-xl border border-neutral-200 bg-white p-5 transition-colors hover:border-neutral-950"
            >
              <span className="flex size-10 shrink-0 items-center justify-center rounded-lg bg-neutral-950 text-white">
                <v.icon className="size-5" strokeWidth={1.5} />
              </span>
              <div>
                <p className="font-medium text-neutral-900">{v.title}</p>
                <p className="mt-1 text-sm leading-relaxed text-neutral-500">
                  {v.desc}
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* CTA */}
      <div className="text-center">
        <p className="mb-4 text-sm text-neutral-500">
          آماده‌اید تجهیز خود را استاندارد بازرسی کنید؟
        </p>
        <Button
          className="bg-neutral-950 text-white hover:bg-neutral-800"
          size="lg"
          asChild
        >
          <Link href="/booking">
            شروع رزرو بازرسی
            <ArrowLeft />
          </Link>
        </Button>
      </div>
    </div>
  );
}

import Link from "next/link";
import { notFound } from "next/navigation";
import { ArrowRight, CalendarDays } from "lucide-react";
import { apiServerFetch } from "@/lib/api-server";
import { Badge } from "@/components/ui/badge";

export const metadata = { title: "مقاله | ادرو" };

interface BlogPostDetail {
  id: number;
  title: string;
  slug: string;
  summary: string;
  content: string;
  category: string;
  featured_image: string | null;
  author_name?: string;
  published_at_jalali?: string | null;
}

const CATEGORY_LABEL: Record<string, string> = {
  news: "اخبار",
  article: "مقالات",
  tutorial: "آموزش‌ها",
  case_study: "مطالعات موردی",
  announcement: "اعلان‌ها",
};

async function fetchPost(slug: string): Promise<BlogPostDetail | null> {
  try {
    const data = await apiServerFetch<{ results: BlogPostDetail[] } | BlogPostDetail[]>(
      `/api/public/blog-posts/?slug=${encodeURIComponent(slug)}`,
      { authenticated: false, cache: "no-store" }
    );
    const posts = Array.isArray(data) ? data : data.results ?? [];
    return posts.find((p) => p.slug === slug) ?? posts[0] ?? null;
  } catch {
    return null;
  }
}

export default async function BlogPostPage({
  params,
}: {
  params: Promise<{ slug: string }>;
}) {
  const { slug } = await params;
  const post = await fetchPost(slug);
  if (!post) notFound();

  return (
    <article className="mx-auto max-w-3xl px-4 py-14">
      <Link
        href="/blog"
        className="text-muted-foreground hover:text-foreground inline-flex items-center gap-1 text-sm"
      >
        <ArrowRight className="size-4" />
        بازگشت به وبلاگ
      </Link>

      <header className="mt-6">
        <Badge variant="outline">{CATEGORY_LABEL[post.category] ?? post.category}</Badge>
        <h1 className="mt-3 text-3xl font-bold">{post.title}</h1>
        <div className="text-muted-foreground mt-3 flex items-center gap-4 text-sm">
          <span className="flex items-center gap-1">
            <CalendarDays className="size-4" />
            {post.published_at_jalali ?? ""}
          </span>
          {post.author_name && <span>{post.author_name}</span>}
        </div>
      </header>

      {post.featured_image && (
        <img src={post.featured_image} alt={post.title} className="mt-6 h-64 w-full rounded-2xl object-cover" />
      )}

      <p className="text-muted-foreground mt-6 text-base leading-7">{post.summary}</p>
      <div className="mt-4 space-y-4 text-sm leading-8 whitespace-pre-wrap">{post.content}</div>
    </article>
  );
}

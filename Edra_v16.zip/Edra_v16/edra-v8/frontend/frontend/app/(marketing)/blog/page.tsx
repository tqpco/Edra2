import Link from "next/link";
import { Newspaper } from "lucide-react";
import { apiServerFetch } from "@/lib/api-server";
import { Badge } from "@/components/ui/badge";

export const metadata = { title: "وبلاگ | ادرو" };

interface BlogPostItem {
  id: number;
  title: string;
  slug: string;
  summary: string;
  category: string;
  featured_image: string | null;
  author_name?: string;
  published_at_jalali?: string | null;
}

const CATEGORY_LABEL: Record<string, string> = {
  news: "اخبار",
  article: "مقالات",
  tutorial: "آموزش‌ها",
  case_study: "مطالعات موردی",
  announcement: "اعلان‌ها",
};

async function fetchPosts(): Promise<BlogPostItem[]> {
  try {
    const data = await apiServerFetch<{ results: BlogPostItem[] } | BlogPostItem[]>(
      "/api/public/blog-posts/",
      { authenticated: false, cache: "no-store" }
    );
    return Array.isArray(data) ? data : data.results ?? [];
  } catch {
    return [];
  }
}

export default async function BlogPage() {
  const posts = await fetchPosts();

  return (
    <div className="mx-auto max-w-4xl px-4 py-14">
      <div className="mb-10 text-center">
        <div className="bg-primary/10 text-primary mx-auto mb-4 flex size-12 items-center justify-center rounded-2xl">
          <Newspaper className="size-6" />
        </div>
        <h1 className="text-3xl font-bold">وبلاگ ادرو</h1>
        <p className="text-muted-foreground mt-2 text-sm">
          اخبار، مقالات و آموزش‌های تخصصی بازرسی ماشین‌آلات سنگین
        </p>
      </div>

      {posts.length === 0 && (
        <p className="text-muted-foreground text-center text-sm">مقاله‌ای منتشر نشده است.</p>
      )}

      <div className="grid gap-6 sm:grid-cols-2">
        {posts.map((post) => (
          <Link
            key={post.id}
            href={`/blog/${post.slug}`}
            className="bg-card group flex flex-col overflow-hidden rounded-2xl border transition-shadow hover:shadow-md"
          >
            {post.featured_image ? (
              <img
                src={post.featured_image}
                alt={post.title}
                className="h-44 w-full object-cover"
              />
            ) : (
              <div className="bg-primary/5 flex h-44 items-center justify-center">
                <Newspaper className="text-primary/30 size-10" />
              </div>
            )}
            <div className="flex flex-1 flex-col gap-2 p-5">
              <Badge variant="outline" className="w-fit">
                {CATEGORY_LABEL[post.category] ?? post.category}
              </Badge>
              <h2 className="text-base font-semibold group-hover:text-primary transition-colors">
                {post.title}
              </h2>
              <p className="text-muted-foreground line-clamp-3 flex-1 text-sm">{post.summary}</p>
              <p className="text-muted-foreground mt-2 text-xs">
                {post.published_at_jalali ?? ""}
                {post.author_name ? ` • ${post.author_name}` : ""}
              </p>
            </div>
          </Link>
        ))}
      </div>
    </div>
  );
}

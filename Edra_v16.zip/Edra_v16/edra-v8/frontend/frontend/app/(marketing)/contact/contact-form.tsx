"use client";

import * as React from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Loader2, CheckCircle2, Send } from "lucide-react";

import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { toEnglishDigits } from "@/lib/jalali";

const schema = z.object({
  name: z.string().min(2, "نام را کامل وارد کنید"),
  email: z.string().email("ایمیل معتبر نیست"),
  phone: z
    .string()
    .transform(toEnglishDigits)
    .pipe(z.string().regex(/^09\d{9}$/, "شماره موبایل معتبر نیست")),
  message: z.string().min(10, "پیام باید حداقل ۱۰ کاراکتر باشد"),
});
type FormValues = z.infer<typeof schema>;

export function ContactForm() {
  const [submitted, setSubmitted] = React.useState(false);
  const [serverError, setServerError] = React.useState<string | null>(null);
  const {
    register,
    handleSubmit,
    formState: { errors, isSubmitting },
  } = useForm<FormValues>({ resolver: zodResolver(schema) });

  async function onSubmit(values: FormValues) {
    setServerError(null);
    try {
      const res = await fetch("/api/proxy/public/contact-messages/", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(values),
      });
      if (!res.ok) {
        setServerError("ارسال پیام ناموفق بود. دوباره تلاش کنید.");
        return;
      }
      setSubmitted(true);
    } catch {
      setServerError("ارتباط با سرور برقرار نشد.");
    }
  }

  if (submitted) {
    return (
      <div className="flex flex-col items-center gap-3 py-10 text-center">
        <CheckCircle2 className="text-success size-10" />
        <p className="font-medium">پیام شما با موفقیت ارسال شد</p>
        <p className="text-muted-foreground text-sm">
          تیم پشتیبانی در اسرع وقت با شما تماس خواهد گرفت
        </p>
      </div>
    );
  }

  return (
    <form onSubmit={handleSubmit(onSubmit)} className="grid gap-4" noValidate>
      {serverError && (
        <Alert variant="destructive">
          <AlertDescription>{serverError}</AlertDescription>
        </Alert>
      )}
      <div className="grid gap-4 sm:grid-cols-2">
        <div className="grid gap-2">
          <Label htmlFor="name">نام و نام‌خانوادگی</Label>
          <Input id="name" aria-invalid={!!errors.name} {...register("name")} />
          {errors.name && <p className="text-destructive text-xs">{errors.name.message}</p>}
        </div>
        <div className="grid gap-2">
          <Label htmlFor="phone">شماره موبایل</Label>
          <Input id="phone" dir="ltr" aria-invalid={!!errors.phone} {...register("phone")} />
          {errors.phone && <p className="text-destructive text-xs">{errors.phone.message}</p>}
        </div>
      </div>
      <div className="grid gap-2">
        <Label htmlFor="email">ایمیل</Label>
        <Input id="email" dir="ltr" type="email" aria-invalid={!!errors.email} {...register("email")} />
        {errors.email && <p className="text-destructive text-xs">{errors.email.message}</p>}
      </div>
      <div className="grid gap-2">
        <Label htmlFor="message">پیام شما</Label>
        <textarea
          id="message"
          rows={5}
          className="border-input placeholder:text-muted-foreground focus-visible:border-ring focus-visible:ring-ring/50 aria-invalid:border-destructive w-full rounded-md border bg-transparent px-3 py-2 text-sm shadow-xs outline-none focus-visible:ring-[3px]"
          {...register("message")}
        />
        {errors.message && <p className="text-destructive text-xs">{errors.message.message}</p>}
      </div>
      <Button type="submit" disabled={isSubmitting} className="mt-1 w-fit">
        {isSubmitting && <Loader2 className="animate-spin" />}
        ارسال پیام
        {!isSubmitting && <Send />}
      </Button>
    </form>
  );
}

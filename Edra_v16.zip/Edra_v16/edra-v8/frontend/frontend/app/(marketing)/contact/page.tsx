import type { Metadata } from "next";
import { Phone, Mail, MapPin, Clock } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { ContactForm } from "./contact-form";

export const metadata: Metadata = { title: "تماس با ما" };

const INFO = [
  { icon: Phone, label: "تلفن پشتیبانی", value: "021-XXXXXXXX", dir: "ltr" as const },
  { icon: Mail, label: "ایمیل", value: "info@edra-inspect.ir", dir: "ltr" as const },
  { icon: MapPin, label: "آدرس", value: "تهران، ایران" },
  { icon: Clock, label: "ساعات پاسخ‌گویی", value: "شنبه تا چهارشنبه، ۸ تا ۱۶" },
];

export default function ContactPage() {
  return (
    <div className="mx-auto max-w-5xl px-4 py-14">
      <div className="mb-10 text-center">
        <h1 className="text-3xl font-bold">تماس با ما</h1>
        <p className="text-muted-foreground mt-2">
          سوالی دارید؟ خوشحال می‌شویم کمکتان کنیم
        </p>
      </div>

      <div className="grid gap-8 lg:grid-cols-5">
        <div className="flex flex-col gap-4 lg:col-span-2">
          {INFO.map((item) => (
            <Card key={item.label}>
              <CardContent className="flex items-center gap-3 px-4 py-4">
                <span className="bg-primary/10 text-primary flex size-10 shrink-0 items-center justify-center rounded-lg">
                  <item.icon className="size-5" />
                </span>
                <div>
                  <p className="text-muted-foreground text-xs">{item.label}</p>
                  <p className="text-sm font-medium" dir={item.dir}>
                    {item.value}
                  </p>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        <Card className="lg:col-span-3">
          <CardContent className="px-6 py-6">
            <ContactForm />
          </CardContent>
        </Card>
      </div>
    </div>
  );
}

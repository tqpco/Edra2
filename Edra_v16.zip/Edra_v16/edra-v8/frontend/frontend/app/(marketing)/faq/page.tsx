import { HelpCircle } from "lucide-react";
import { apiServerFetch } from "@/lib/api-server";

export const metadata = { title: "سوالات متداول | ادرو" };

interface FaqItem {
  id: number;
  question: string;
  answer: string;
  category: string;
}

const CATEGORY_LABEL: Record<string, string> = {
  general: "عمومی",
  technical: "فنی",
  billing: "مالی",
  support: "پشتیبانی",
  inspection: "بازرسی",
};

async function fetchFaqs(): Promise<FaqItem[]> {
  try {
    const data = await apiServerFetch<{ results: FaqItem[] } | FaqItem[]>(
      "/api/public/faqs/",
      { authenticated: false, cache: "no-store" }
    );
    return Array.isArray(data) ? data : data.results ?? [];
  } catch {
    return [];
  }
}

export default async function FaqPage() {
  const faqs = await fetchFaqs();

  const grouped = faqs.reduce<Record<string, FaqItem[]>>((acc, faq) => {
    const key = faq.category || "general";
    (acc[key] ||= []).push(faq);
    return acc;
  }, {});

  return (
    <div className="mx-auto max-w-3xl px-4 py-14">
      <div className="mb-10 text-center">
        <div className="bg-primary/10 text-primary mx-auto mb-4 flex size-12 items-center justify-center rounded-2xl">
          <HelpCircle className="size-6" />
        </div>
        <h1 className="text-3xl font-bold">سوالات متداول</h1>
        <p className="text-muted-foreground mt-2 text-sm">
          پاسخ سوالات پرتکرار شما درباره بازرسی ماشین‌آلات و فرایند دریافت گزارش
        </p>
      </div>

      {Object.keys(grouped).length === 0 && (
        <p className="text-muted-foreground text-center text-sm">سوالی ثبت نشده است.</p>
      )}

      {Object.entries(grouped).map(([category, items]) => (
        <section key={category} className="mb-8">
          <h2 className="mb-3 text-lg font-semibold">
            {CATEGORY_LABEL[category] ?? category}
          </h2>
          <div className="bg-card flex flex-col divide-y rounded-xl border">
            {items.map((faq) => (
              <details key={faq.id} className="group px-4 py-3">
                <summary className="flex cursor-pointer list-none items-center justify-between gap-3 text-sm font-medium [&::-webkit-details-marker]:hidden">
                  {faq.question}
                  <span className="text-muted-foreground text-lg transition-transform group-open:rotate-45">
                    +
                  </span>
                </summary>
                <p className="text-muted-foreground mt-2 text-sm leading-7">{faq.answer}</p>
              </details>
            ))}
          </div>
        </section>
      ))}
    </div>
  );
}

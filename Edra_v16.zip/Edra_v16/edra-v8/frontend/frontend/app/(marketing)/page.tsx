import Link from "next/link";
import {
  ArrowLeft,
  ShieldCheck,
  Calendar,
  FileCheck2,
  Wrench,
  Construction,
  Forklift,
  Container,
  Building2,
  Gauge,
  ClipboardCheck,
  Smartphone,
  BadgeCheck,
} from "lucide-react";

import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { TrustStats } from "@/components/marketing/trust-stats";

/* EDRA v11 — بازطراحی مینیمال: پالت خاکستری / مشکی / سفید
 * حذف رنگ برند؛ ساختار با کنتراست، فاصله و تایپوگرافی تعریف می‌شود. */

const EQUIPMENT = [
  { icon: Construction, name: "جرثقیل برجی" },
  { icon: Building2, name: "جرثقیل سیار" },
  { icon: Forklift, name: "لیفتراک" },
  { icon: Container, name: "بالابر" },
  { icon: Gauge, name: "جرثقیل سقفی" },
  { icon: Wrench, name: "سایر تجهیزات صنعتی" },
];

const STEPS = [
  {
    icon: ClipboardCheck,
    title: "ثبت درخواست",
    desc: "نوع تجهیز، مشخصات فنی و شهر خود را در چند دقیقه وارد کنید",
  },
  {
    icon: Calendar,
    title: "زمان‌بندی",
    desc: "زمان مناسب برای بازرسی را از تقویم انتخاب کنید",
  },
  {
    icon: Smartphone,
    title: "بازرسی توسط کارشناس",
    desc: "کارشناس مجرب در محل، چک‌لیست استاندارد را تکمیل می‌کند",
  },
  {
    icon: BadgeCheck,
    title: "دریافت گزارش",
    desc: "گزارش رسمی و قابل‌استناد را به‌صورت دیجیتال دریافت کنید",
  },
];

export default function HomePage() {
  return (
    <>
      {/* Hero — مینیمال و متمرکز */}
      <section className="relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-b from-neutral-100 via-white to-white" />
        <div className="relative mx-auto max-w-6xl px-4 pt-16 pb-20 md:pt-24 md:pb-28">
          <div className="mx-auto max-w-2xl text-center">
            <span className="mx-auto mb-6 inline-flex items-center gap-1.5 rounded-full border border-neutral-300 bg-white px-3 py-1 text-xs font-medium text-neutral-600">
              <ShieldCheck className="size-3.5" />
              گواهی رسمی و قابل‌استناد بازرسی
            </span>
            <h1 className="text-3xl leading-tight font-bold tracking-tight text-neutral-950 sm:text-5xl">
              بازرسی تخصصی تجهیزات سنگین صنعتی،
              <span className="text-neutral-900"> کاملاً آنلاین</span>
            </h1>
            <p className="mt-5 text-base leading-relaxed text-neutral-500 sm:text-lg">
              جرثقیل، لیفتراک و سایر تجهیزات صنعتی خود را رزرو کنید؛ کارشناس
              مجرب ما در محل حضور می‌یابد و گزارش استاندارد را دیجیتال دریافت
              می‌کنید.
            </p>
            <div className="mt-8 flex flex-col justify-center gap-3 sm:flex-row">
              <Button
                size="lg"
                className="bg-neutral-950 text-white hover:bg-neutral-800"
                asChild
              >
                <Link href="/booking">
                  شروع رزرو بازرسی
                  <ArrowLeft />
                </Link>
              </Button>
              <Button size="lg" variant="outline" className="border-neutral-300 text-neutral-800 hover:bg-neutral-100" asChild>
                <Link href="/about">آشنایی با ادرو</Link>
              </Button>
            </div>
          </div>

          <div className="mt-16">
            <TrustStats />
          </div>
        </div>
      </section>

      {/* تجهیزات — کارت‌های مینیمال */}
      <section className="mx-auto max-w-6xl px-4 py-16">
        <div className="mb-10 text-center">
          <h2 className="text-2xl font-bold tracking-tight text-neutral-950 sm:text-3xl">
            تجهیزات تحت پوشش
          </h2>
          <p className="mt-2 text-neutral-500">
            بازرسی استاندارد برای طیف گسترده‌ای از تجهیزات صنعتی
          </p>
        </div>
        <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-6">
          {EQUIPMENT.map((eq) => (
            <Card
              key={eq.name}
              className="border-neutral-200 transition-all hover:border-neutral-950 hover:shadow-sm"
            >
              <CardContent className="flex flex-col items-center gap-3 px-4 py-6 text-center">
                <span className="flex size-12 items-center justify-center rounded-xl border border-neutral-200 bg-white text-neutral-900">
                  <eq.icon className="size-6" strokeWidth={1.5} />
                </span>
                <span className="text-sm font-medium text-neutral-800">{eq.name}</span>
              </CardContent>
            </Card>
          ))}
        </div>
      </section>

      {/* فرآیند کار — مینیمال با شماره */}
      <section className="border-y border-neutral-200 bg-neutral-50 py-16">
        <div className="mx-auto max-w-6xl px-4">
          <div className="mb-10 text-center">
            <h2 className="text-2xl font-bold tracking-tight text-neutral-950 sm:text-3xl">
              فرآیند کار
            </h2>
            <p className="mt-2 text-neutral-500">
              از ثبت درخواست تا دریافت گواهی، فقط ۴ گام ساده
            </p>
          </div>
          <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
            {STEPS.map((step, i) => (
              <Card key={step.title} className="h-full border-neutral-200 bg-white">
                <CardContent className="flex flex-col items-start gap-3 px-5 py-6">
                  <span className="flex size-10 items-center justify-center rounded-lg bg-neutral-950 text-sm font-bold text-white">
                    {["۱", "۲", "۳", "۴"][i]}
                  </span>
                  <step.icon className="size-5 text-neutral-700" strokeWidth={1.5} />
                  <div>
                    <p className="font-semibold text-neutral-900">{step.title}</p>
                    <p className="mt-1 text-sm leading-relaxed text-neutral-500">
                      {step.desc}
                    </p>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* CTA پایانی — بلوک معکوس (مشکی) */}
      <section className="mx-auto max-w-6xl px-4 py-20">
        <div className="overflow-hidden rounded-2xl bg-neutral-950">
          <div className="flex flex-col items-center gap-5 px-6 py-14 text-center">
            <FileCheck2 className="size-10 text-white" strokeWidth={1.25} />
            <h2 className="text-2xl font-bold tracking-tight text-white sm:text-3xl">
              همین حالا بازرسی تجهیز خود را رزرو کنید
            </h2>
            <p className="max-w-lg text-neutral-400">
              ثبت درخواست کمتر از ۵ دقیقه زمان می‌برد و می‌توانید بلافاصله
              قیمت دقیق را مشاهده کنید.
            </p>
            <Button
              size="lg"
              className="mt-2 bg-white text-neutral-950 hover:bg-neutral-200"
              asChild
            >
              <Link href="/booking">
                شروع رزرو
                <ArrowLeft />
              </Link>
            </Button>
          </div>
        </div>
      </section>
    </>
  );
}

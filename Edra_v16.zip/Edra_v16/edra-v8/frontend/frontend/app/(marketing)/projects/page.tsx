import type { Metadata } from "next";
import { FolderKanban } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { formatJalali } from "@/lib/jalali";

export const metadata: Metadata = { title: "پروژه‌های ما" };

interface CaseStudy {
  id: number;
  title: string;
  slug: string;
  summary: string;
  published_at: string | null;
}

async function fetchCaseStudies(): Promise<CaseStudy[]> {
  try {
    const apiUrl = process.env.NEXT_PUBLIC_API_URL || "http://localhost:8000";
    const res = await fetch(
      `${apiUrl}/api/public/blog-posts/?category=case_study`,
      { next: { revalidate: 300 } }
    );
    if (!res.ok) return [];
    const data = await res.json();
    return data.results ?? data;
  } catch {
    return [];
  }
}

export default async function ProjectsPage() {
  const projects = await fetchCaseStudies();

  return (
    <div className="mx-auto max-w-5xl px-4 py-16">
      <div className="mb-10 text-center">
        <h1 className="text-3xl font-bold sm:text-4xl">پروژه‌های ما</h1>
        <p className="text-muted-foreground mx-auto mt-3 max-w-2xl">
          نمونه‌ای از پروژه‌های بازرسی انجام‌شده توسط تیم ادرو
        </p>
      </div>

      {projects.length === 0 ? (
        <div className="text-muted-foreground flex flex-col items-center gap-3 rounded-xl border border-dashed py-20 text-center">
          <FolderKanban className="size-10 opacity-40" />
          <p>به‌زودی نمونه‌کارهای بیشتری اینجا منتشر می‌شود</p>
        </div>
      ) : (
        <div className="grid gap-6 sm:grid-cols-2">
          {projects.map((p) => (
            <Card key={p.id} className="transition-shadow hover:shadow-md">
              <CardContent className="flex flex-col gap-3 px-6 py-6">
                <span className="bg-primary/10 text-primary flex size-10 items-center justify-center rounded-lg">
                  <FolderKanban className="size-5" />
                </span>
                <h2 className="font-semibold">{p.title}</h2>
                <p className="text-muted-foreground line-clamp-3 text-sm leading-relaxed">
                  {p.summary}
                </p>
                {p.published_at && (
                  <span className="text-muted-foreground text-xs">
                    {formatJalali(new Date(p.published_at))}
                  </span>
                )}
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}

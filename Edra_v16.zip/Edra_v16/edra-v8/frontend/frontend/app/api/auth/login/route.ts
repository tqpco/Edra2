import { NextRequest, NextResponse } from "next/server";
import { setSessionTokens } from "@/lib/session";

const API_BASE_URL = process.env.NEXT_PUBLIC_API_URL || "http://localhost:8000";

/**
 * POST /api/auth/login
 * ورودی: { phone, code } (تایید نهایی کد OTP)
 * بک‌اند جنگو access/refresh را برمی‌گرداند؛ اینجا آن‌ها را در کوکی
 * httpOnly ذخیره می‌کنیم و فقط اطلاعات کاربر (بدون خود توکن‌ها) را به
 * کلاینت برمی‌گردانیم.
 */
export async function POST(request: NextRequest) {
  const body = await request.json();

  const res = await fetch(`${API_BASE_URL}/api/core/otp/verify/`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body),
    cache: "no-store",
  });

  const data = await res.json();

  if (!res.ok) {
    return NextResponse.json(data, { status: res.status });
  }

  const { access, refresh, user, is_new } = data;
  if (!access || !refresh) {
    return NextResponse.json(
      { detail: "پاسخ نامعتبر از سرور احراز هویت" },
      { status: 502 }
    );
  }

  await setSessionTokens(access, refresh);

  return NextResponse.json({ user, is_new });
}

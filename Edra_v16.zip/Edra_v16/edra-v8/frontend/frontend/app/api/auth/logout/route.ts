import { NextResponse } from "next/server";
import { clearSessionTokens, getRefreshToken } from "@/lib/session";

const API_BASE_URL = process.env.NEXT_PUBLIC_API_URL || "http://localhost:8000";

export async function POST() {
  // باطل کردن refresh token در سمت سرور (blacklist) - پاک کردن کوکی به‌تنهایی
  // توکن دزدیده‌شده را باطل نمی‌کند. اگر سرور در دسترس نبود، باز هم
  // session محلی پاک می‌شود تا کاربر گیر نیفتد.
  const refresh = await getRefreshToken();
  if (refresh) {
    try {
      await fetch(`${API_BASE_URL}/api/token/blacklist/`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ refresh }),
        cache: "no-store",
      });
    } catch {
      // بی‌صدا رد شو - logout محلی همچنان انجام می‌شود
    }
  }

  await clearSessionTokens();
  return NextResponse.json({ ok: true });
}

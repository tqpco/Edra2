import { NextResponse } from "next/server";
import { apiServerFetch, ApiError } from "@/lib/api-server";
import { getAccessToken } from "@/lib/session";
import type { User } from "@/types/user";

export async function GET() {
  const token = await getAccessToken();
  if (!token) {
    return NextResponse.json({ user: null }, { status: 200 });
  }

  try {
    const user = await apiServerFetch<User>("/api/core/users/me/");
    return NextResponse.json({ user });
  } catch (err) {
    if (err instanceof ApiError && err.status === 401) {
      return NextResponse.json({ user: null }, { status: 200 });
    }
    return NextResponse.json(
      { user: null, detail: "خطای ارتباط با سرور" },
      { status: 200 }
    );
  }
}

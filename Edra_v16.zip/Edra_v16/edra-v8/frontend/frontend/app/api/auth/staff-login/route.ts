import { NextRequest, NextResponse } from "next/server";
import { setSessionTokens, clearSessionTokens } from "@/lib/session";
import { apiServerFetch } from "@/lib/api-server";
import type { User } from "@/types/user";

const API_BASE_URL = process.env.NEXT_PUBLIC_API_URL || "http://localhost:8000";

/**
 * POST /api/auth/staff-login
 * ورودی: { username, password } - برای ادمین و کارشناس (حساب‌هایی که
 * از قبل توسط مدیر ساخته شده‌اند، بدون ثبت‌نام آزاد).
 */
export async function POST(request: NextRequest) {
  const body = await request.json();

  const res = await fetch(`${API_BASE_URL}/api/token/`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body),
    cache: "no-store",
  });

  const data = await res.json();

  if (!res.ok) {
    return NextResponse.json(
      { detail: "نام کاربری یا رمز عبور اشتباه است." },
      { status: res.status }
    );
  }

  const { access, refresh } = data;

  // توکن‌ها را ذخیره می‌کنیم تا /api/core/users/me/ بتواند احراز هویت کند؛
  // اگر دسترسی نامعتبر بود، بلافاصله پاک می‌شوند.
  await setSessionTokens(access, refresh);
  try {
    const user = await apiServerFetch<User>("/api/core/users/me/");
    if (!user.is_staff && !user.groups?.includes("Expert")) {
      // دسترسی غیرمجاز: توکن‌هایی که همین الان ست شدند را پاک کن تا
      // کوکی‌های بی‌استفاده/نیمه‌معتبر روی مرورگر باقی نمانند
      await clearSessionTokens();
      return NextResponse.json(
        { detail: "این حساب دسترسی به پنل مدیریت/کارشناسی ندارد." },
        { status: 403 }
      );
    }
    return NextResponse.json({ user });
  } catch {
    await clearSessionTokens();
    return NextResponse.json(
      { detail: "خطا در دریافت اطلاعات کاربر" },
      { status: 502 }
    );
  }
}

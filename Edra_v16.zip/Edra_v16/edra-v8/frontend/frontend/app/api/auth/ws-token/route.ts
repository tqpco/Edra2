import { NextResponse } from "next/server";
import { getAccessToken } from "@/lib/session";

const API_BASE_URL = process.env.NEXT_PUBLIC_API_URL || "http://localhost:8000";

/**
 * GET /api/auth/ws-token
 *
 * P0-08/HIGH-06: access JWT هرگز به جاوااسکریپت داده نمی‌شود (httpOnly
 * cookie). برای اتصال WebSocket، این endpoint سمت سرور با access token
 * از backend یک ticket یکبارمصرف با عمر کوتاه (۶۰ ثانیه) می‌گیرد و فقط
 * همان ticket را به کلاینت برمی‌گرداند. ticket در query string قرار می‌گیرد
 * و افشای آن فقط یک اتصال محدود می‌دهد، نه توکن اصلی.
 */
export async function GET() {
  const token = await getAccessToken();
  if (!token) {
    return NextResponse.json({ ticket: null }, { status: 401 });
  }

  try {
    const res = await fetch(`${API_BASE_URL}/api/notifications/ws-ticket/`, {
      method: "POST",
      headers: { Authorization: `Bearer ${token}` },
      cache: "no-store",
    });
    if (!res.ok) {
      return NextResponse.json({ ticket: null }, { status: 401 });
    }
    const data = await res.json();
    return NextResponse.json({ ticket: data.ticket ?? null });
  } catch {
    return NextResponse.json({ ticket: null }, { status: 502 });
  }
}

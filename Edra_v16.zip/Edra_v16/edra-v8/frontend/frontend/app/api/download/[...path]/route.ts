/**
 * app/api/download/[...path]/route.ts
 * برای دانلود فایل‌های باینری (خروجی اکسل گزارش‌ها، PDF و ...) - برخلاف
 * /api/proxy که پاسخ را JSON فرض می‌کند، این مسیر بدنه‌ی پاسخ را عیناً
 * (باینری) پاس می‌دهد.
 */
import { NextRequest, NextResponse } from "next/server";
import {
  getAccessToken,
  refreshAccessToken,
} from "@/lib/session";

const API_BASE_URL = process.env.NEXT_PUBLIC_API_URL || "http://localhost:8000";

export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ path: string[] }> }
) {
  const { path } = await params;
  // EDRA v6 — P0: trailing slash حفظ می‌شود (جلوگیری از 301 در دانلودها)
  const joined = path.join("/");
  const trailing = request.nextUrl.pathname.endsWith("/") ? "/" : "";
  const targetPath = `/api/${joined}${trailing}${request.nextUrl.search}`;
  const token = await getAccessToken();

  // EDRA v8 — P1-12: دانلود هم مثل proxy باید refresh داشته باشد؛ اگر
  // access token منقضی شده باشد، یک‌بار refresh و retry می‌شود — در غیر
  // این صورت دانلود PDF/فیش برای کاربر بی‌دلیل با 401 شکست می‌خورد.
  let res = await fetch(`${API_BASE_URL}${targetPath}`, {
    headers: token ? { Authorization: `Bearer ${token}` } : undefined,
  });

  if (res.status === 401 && token) {
    // P1 (EDRA v9): refresh single-flight مشترک
    const newAccess = await refreshAccessToken();
    if (newAccess) {
      res = await fetch(`${API_BASE_URL}${targetPath}`, {
        headers: { Authorization: `Bearer ${newAccess}` },
      });
    }
  }

  if (!res.ok) {
    return NextResponse.json(
      { detail: "دانلود فایل ناموفق بود" },
      { status: res.status }
    );
  }

  const blob = await res.blob();
  return new NextResponse(blob, {
    headers: {
      "Content-Type":
        res.headers.get("content-type") || "application/octet-stream",
      "Content-Disposition": res.headers.get("content-disposition") || "attachment",
    },
  });
}

/**
 * app/api/proxy/[...path]/route.ts
 *
 * Client Component ها نمی‌توانند مستقیم به بک‌اند جنگو با Authorization
 * header وصل شوند (چون توکن در کوکی httpOnly است و از جاوااسکریپت قابل
 * خواندن نیست - که دقیقاً هدف امنیتی‌مان است). به‌جایش این پروکسی را صدا
 * می‌زنند؛ اینجا (سمت سرور Next.js) توکن از کوکی خوانده، به بک‌اند جنگو
 * فوروارد، و در صورت انقضا خودکار تازه‌سازی می‌شود.
 */
import { NextRequest, NextResponse } from "next/server";
import { ApiError, apiServerFetch } from "@/lib/api-server";

const METHODS = ["GET", "POST", "PUT", "PATCH", "DELETE"] as const;

async function handler(
  request: NextRequest,
  { params }: { params: Promise<{ path: string[] }> }
) {
  const { path } = await params;
  // EDRA v6 — P0: trailing slash حفظ می‌شود. Django/CommonMiddleware برای
  // مسیر بدون slash جواب 301 می‌دهد که در POST/PATCH می‌تواند body را
  // حذف کند یا method را تغییر دهد؛ مسیرهای API همه با slash تعریف شده‌اند.
  const joined = path.join("/");
  const trailing = request.nextUrl.pathname.endsWith("/") ? "/" : "";
  const targetPath = `/api/${joined}${trailing}${request.nextUrl.search}`;

  let body: unknown;
  const contentType = request.headers.get("content-type") || "";
  if (request.method !== "GET" && request.method !== "DELETE") {
    if (contentType.includes("multipart/form-data")) {
      // آپلود فایل (عکس چک‌لیست، فیش پرداخت و ...) - مستقیم پاس می‌دهیم
      // چون FormData را نباید JSON.stringify کرد.
      return proxyFormData(request, targetPath);
    }
    try {
      body = await request.json();
    } catch {
      body = undefined;
    }
  }

  try {
    const data = await apiServerFetch(targetPath, {
      method: request.method,
      body,
    });
    return NextResponse.json(data ?? {});
  } catch (err) {
    if (err instanceof ApiError) {
      return NextResponse.json(err.data ?? { detail: err.message }, {
        status: err.status,
      });
    }
    return NextResponse.json(
      { detail: "خطای ارتباط با سرور" },
      { status: 502 }
    );
  }
}

/**
 * EDRA v5 — HIGH-24: برای multipart هم refresh/retry انجام می‌شود (مثل
 * apiServerFetch)؛ اگر access token هنگام آپلود منقضی شده باشد، ابتدا
 * refresh می‌شود و همان request یک‌بار دیگر ارسال می‌شود — کاربر در وسط
 * آپلود فیش/عکس 401 نمی‌خورد.
 */
async function proxyFormData(request: NextRequest, targetPath: string) {
  const { getAccessToken, refreshAccessToken } = await import("@/lib/session");
  const API_BASE_URL = process.env.NEXT_PUBLIC_API_URL || "http://localhost:8000";

  // EDRA v6 — P1: FormData فقط یک بار parse می‌شود؛ در retry دوباره از
  // همان FormData استفاده می‌شود (مصرف دوباره request body در retry
  // برای آپلودها body خالی می‌فرستاد).
  const formData = await request.formData();

  async function sendFormData(token: string | null) {
    return fetch(`${API_BASE_URL}${targetPath}`, {
      method: request.method,
      headers: token ? { Authorization: `Bearer ${token}` } : undefined,
      body: formData,
    });
  }

  const token = (await getAccessToken()) ?? null;
  let res = await sendFormData(token);

  if (res.status === 401 && token) {
    // P1 (EDRA v9): refresh single-flight — فقط یک refresh انجام می‌شود
    const newAccess = await refreshAccessToken();
    if (newAccess) {
      res = await sendFormData(newAccess);  // retry با token تازه
    }
  }

  const data = await res.json().catch(() => ({}));
  return NextResponse.json(data, { status: res.status });
}

export const GET = handler;
export const POST = handler;
export const PUT = handler;
export const PATCH = handler;
export const DELETE = handler;

"use client";

import * as React from "react";
import Link from "next/link";
import { ShieldCheck } from "lucide-react";

import { useWizardStore } from "@/lib/wizard-store";
import { WizardStepIndicator } from "@/components/wizard/step-indicator";
import { StepEquipment } from "@/components/wizard/step-1-equipment";
import { StepParameters } from "@/components/wizard/step-2-parameters";
import { StepServiceLevel } from "@/components/wizard/step-3-service-level";
import { StepAuth } from "@/components/wizard/step-4-auth";
import { StepScheduling } from "@/components/wizard/step-5-scheduling";
import { StepApplicantInfo } from "@/components/wizard/step-6-applicant-info";
import { StepReview } from "@/components/wizard/step-7-review";
import { StepPayment } from "@/components/wizard/step-8-payment";

const STEP_COMPONENTS: Record<number, React.ComponentType> = {
  1: StepEquipment,
  2: StepParameters,
  3: StepServiceLevel,
  4: StepAuth,
  5: StepScheduling,
  6: StepApplicantInfo,
  7: StepReview,
  8: StepPayment,
};

export default function BookingWizardPage() {
  const step = useWizardStore((s) => s.step);
  const StepComponent = STEP_COMPONENTS[step] ?? StepEquipment;

  return (
    <div className="bg-muted/30 min-h-svh">
      <header className="bg-background border-b">
        <div className="mx-auto flex max-w-3xl items-center justify-between px-4 py-3">
          <Link href="/" className="flex items-center gap-2 font-semibold">
            <span className="flex size-7 items-center justify-center rounded-md bg-primary text-primary-foreground">
              <ShieldCheck className="size-3.5" />
            </span>
            ادرو
          </Link>
          <span className="text-muted-foreground text-xs">رزرو بازرسی</span>
        </div>
      </header>

      <div className="mx-auto max-w-3xl px-4 py-6 md:py-10">
        <div className="mb-8">
          <WizardStepIndicator current={step} />
        </div>
        <StepComponent />
      </div>
    </div>
  );
}

import { ScrollText } from "lucide-react";
import { apiServerFetch } from "@/lib/api-server";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";

export const metadata = { title: "لاگ ممیزی" };

interface AuditLogItem {
  id: number;
  action: string;
  object_id: number;
  changes: Record<string, unknown>;
  timestamp_jalali?: string;
  user?: { username: string } | number | string | null;
}

const ACTION_LABEL: Record<string, string> = {
  sign_report: "امضای گزارش",
  verify_payment: "تأیید پرداخت",
  reject_payment: "رد پرداخت",
  assign_expert: "تخصیص کارشناس",
  change_status: "تغییر وضعیت",
  create_invoice: "صدور فاکتور",
  create_report: "ایجاد گزارش",
};

async function fetchLogs(): Promise<AuditLogItem[]> {
  try {
    const data = await apiServerFetch<{ results: AuditLogItem[] } | AuditLogItem[]>(
      "/api/core/audit-logs/"
    );
    return Array.isArray(data) ? data : data.results ?? [];
  } catch {
    return [];
  }
}

function formatChanges(changes: Record<string, unknown>): string {
  if (!changes || typeof changes !== "object") return "—";
  try {
    return JSON.stringify(changes);
  } catch {
    return "—";
  }
}

export default async function AdminAuditLogsPage() {
  const logs = await fetchLogs();

  return (
    <div className="flex flex-col gap-6">
      <div>
        <h1 className="text-2xl font-semibold">لاگ ممیزی</h1>
        <p className="text-muted-foreground text-sm">
          ثبت عملیات حساس مالی و امنیتی سیستم
        </p>
      </div>

      <Card>
        <CardContent className="px-0 py-2">
          {logs.length === 0 ? (
            <p className="text-muted-foreground py-10 text-center text-sm">
              <ScrollText className="mx-auto mb-2 size-8 opacity-40" />
              رویدادی ثبت نشده است
            </p>
          ) : (
            <div className="flex flex-col divide-y">
              {logs.map((log) => (
                <div key={log.id} className="flex flex-wrap items-start justify-between gap-2 px-5 py-3">
                  <div className="flex items-start gap-3">
                    <span className="bg-primary/10 text-primary mt-0.5 flex size-8 shrink-0 items-center justify-center rounded-lg">
                      <ScrollText className="size-4" />
                    </span>
                    <div className="min-w-0">
                      <div className="flex items-center gap-2">
                        <Badge variant="outline">
                          {ACTION_LABEL[log.action] ?? log.action}
                        </Badge>
                        <span className="text-muted-foreground text-xs">
                          شیء #{log.object_id}
                        </span>
                      </div>
                      <p className="text-muted-foreground mt-1 font-mono text-xs break-all">
                        {formatChanges(log.changes)}
                      </p>
                    </div>
                  </div>
                  <div className="shrink-0 text-left">
                    <p className="text-xs font-medium">
                      {typeof log.user === "object" && log.user && "username" in log.user
                        ? (log.user as { username: string }).username
                        : typeof log.user === "string"
                          ? log.user
                          : "سیستم"}
                    </p>
                    <p className="text-muted-foreground mt-0.5 text-xs">
                      {log.timestamp_jalali ?? ""}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}

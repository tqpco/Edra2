"use client";

/**
 * checklist-excel-import.tsx
 *
 * FEATURE: ایمپورت آیتم‌های چک‌لیست از فایل Excel.
 * ۱) انتخاب قالب چک‌لیست (مثلاً تاور کرین)
 * ۲) آپلود فایل .xlsx → پیش‌نمایش آیتم‌های خوانده‌شده (preview، بدون ذخیره)
 * ۳) تأیید → ذخیره اتمیک در backend
 * همچنین دکمه دانلود قالب نمونه (import-template).
 */
import * as React from "react";
import { FileSpreadsheet, Download, Upload, Loader2, CheckCircle2 } from "lucide-react";
import { toast } from "sonner";
import { apiClientUpload } from "@/lib/api-client";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";

interface TemplateOption {
  id: number;
  name: string;
}

interface ParsedItem {
  category: string;
  title: string;
  description: string;
  order: number;
  requires_photo: boolean;
  requires_note: boolean;
  /** EDRA v8 — P1-03: فیلد «نیاز حیاتی» از Backend می‌آید و باید نمایش داده شود. */
  is_critical?: boolean;
}

interface RowError {
  row: number;
  error: string;
}

interface PreviewResponse {
  preview: boolean;
  template_id: number;
  template_name: string;
  mode: "append" | "replace";
  items: ParsedItem[];
  errors: RowError[];
  total: number;
  existing_count: number;
  duplicate_with_existing: number;
}

interface ImportResponse {
  success: boolean;
  message: string;
  created_count: number;
  errors: RowError[];
}

export function ChecklistExcelImport({ templates }: { templates: TemplateOption[] }) {
  const [templateId, setTemplateId] = React.useState<string>("");
  const [mode, setMode] = React.useState<"append" | "replace">("append");
  const [file, setFile] = React.useState<File | null>(null);
  const [preview, setPreview] = React.useState<ParsedItem[] | null>(null);
  const [previewMeta, setPreviewMeta] = React.useState<{
    existing: number;
    duplicates: number;
  } | null>(null);
  const [errors, setErrors] = React.useState<RowError[]>([]);
  const [busy, setBusy] = React.useState(false);
  const [importedCount, setImportedCount] = React.useState<number | null>(null);
  const fileInputRef = React.useRef<HTMLInputElement>(null);

  const selectedTemplate = templates.find((t) => String(t.id) === templateId);

  function handleFileChange(e: React.ChangeEvent<HTMLInputElement>) {
    const f = e.target.files?.[0] ?? null;
    setFile(f);
    setPreview(null);
    setPreviewMeta(null);
    setErrors([]);
    setImportedCount(null);
  }

  async function handlePreview() {
    if (!templateId || !file) {
      toast.warning("ابتدا قالب و فایل Excel را انتخاب کنید");
      return;
    }
    setBusy(true);
    setErrors([]);
    setImportedCount(null);
    try {
      const form = new FormData();
      form.append("file", file);
      const data = await apiClientUpload<PreviewResponse>(
        `/api/inspections/checklist-templates/${templateId}/import-items/?preview=true&mode=${mode}`,
        form
      );
      setPreview(data.items ?? []);
      setErrors(data.errors ?? []);
      setPreviewMeta({
        existing: data.existing_count ?? 0,
        duplicates: data.duplicate_with_existing ?? 0,
      });
      toast.success(`${data.total} آیتم از فایل خوانده شد`);
    } catch (err) {
      const message =
        (err as { data?: { error?: string } }).data?.error ?? "خواندن فایل ناموفق بود";
      toast.error(message);
    } finally {
      setBusy(false);
    }
  }

  async function handleImport() {
    if (!templateId || !file || !preview) return;
    // EDRA v8 — P1-03: در حالت replace، وجود خطای سطر یعنی آیتم‌های قبلی
    // غیرفعال می‌شوند و فقط ردیف‌های معتبر جایگزین می‌شوند (از دست رفتن
    // داده). Backend هم این را enforce می‌کند؛ UI هم پیش‌گیری می‌کند.
    if (mode === "replace" && errors.length > 0) {
      toast.error(
        "در حالت جایگزینی (Replace) خطاهای سطر وجود دارد و ایمپورت مسدود است. ابتدا فایل را اصلاح کنید."
      );
      return;
    }
    setBusy(true);
    try {
      const form = new FormData();
      form.append("file", file);
      const data = await apiClientUpload<ImportResponse>(
        `/api/inspections/checklist-templates/${templateId}/import-items/?mode=${mode}`,
        form
      );
      setImportedCount(data.created_count);
      setPreview(null);
      setPreviewMeta(null);
      setFile(null);
      if (fileInputRef.current) fileInputRef.current.value = "";
      toast.success(data.message ?? "ایمپورت انجام شد");
      // تازه‌سازی صفحه بعد از ذخیره
      window.location.reload();
    } catch (err) {
      const message =
        (err as { data?: { error?: string } }).data?.error ?? "ایمپورت ناموفق بود";
      toast.error(message);
    } finally {
      setBusy(false);
    }
  }

  function handleDownloadTemplate() {
    if (!templateId) {
      toast.warning("ابتدا قالب را انتخاب کنید");
      return;
    }
    // از پروکسی سمت سرور استفاده می‌شود تا Authorization اضافه شود
    window.location.href = `/api/download/inspections/checklist-templates/${templateId}/import-template/`;
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2 text-base">
          <FileSpreadsheet className="size-4" />
          ایمپورت آیتم‌ها از فایل Excel
        </CardTitle>
        <CardDescription className="text-xs">
          آیتم‌های بازرسی را در اکسل بنویسید، ذخیره کنید و همین‌جا برای قالب
          موردنظر آپلود کنید (ستون‌ها: دسته‌بندی، عنوان، توضیحات، ترتیب،
          نیاز به عکس، نیاز به یادداشت، نیاز حیاتی).
        </CardDescription>
      </CardHeader>
      <CardContent className="flex flex-col gap-3">
        <div className="flex flex-wrap items-center gap-2">
          <Select value={templateId} onValueChange={setTemplateId}>
            <SelectTrigger className="w-56">
              <SelectValue placeholder="انتخاب قالب چک‌لیست..." />
            </SelectTrigger>
            <SelectContent>
              {templates.map((t) => (
                <SelectItem key={t.id} value={String(t.id)}>
                  {t.name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>

          {/* EDRA v5 — HIGH-19: append = افزودن؛ replace = جایگزینی آیتم‌ها */}
          <Select value={mode} onValueChange={(v) => setMode(v as "append" | "replace")}>
            <SelectTrigger className="w-36">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="append">افزودن (Append)</SelectItem>
              <SelectItem value="replace">جایگزینی (Replace)</SelectItem>
            </SelectContent>
          </Select>

          <input
            ref={fileInputRef}
            type="file"
            accept=".xlsx"
            className="hidden"
            onChange={handleFileChange}
          />
          <Button
            type="button"
            variant="outline"
            onClick={() => fileInputRef.current?.click()}
          >
            <Upload className="size-4" />
            {file ? file.name : "انتخاب فایل Excel"}
          </Button>

          <Button
            type="button"
            variant="outline"
            size="sm"
            onClick={handleDownloadTemplate}
            disabled={!templateId}
          >
            <Download className="size-4" />
            دانلود قالب نمونه
          </Button>

          <Button
            type="button"
            onClick={handlePreview}
            disabled={!templateId || !file || busy}
          >
            {busy ? <Loader2 className="size-4 animate-spin" /> : null}
            پیش‌نمایش آیتم‌ها
          </Button>

          {preview && preview.length > 0 && (
            <Button
              type="button"
              variant="success"
              onClick={handleImport}
              disabled={busy || (mode === "replace" && errors.length > 0)}
            >
              <CheckCircle2 className="size-4" />
              ذخیره {preview.length} آیتم
            </Button>
          )}
        </div>

        {importedCount !== null && (
          <p className="text-emerald-600 text-sm">
            {importedCount} آیتم با موفقیت به «{selectedTemplate?.name}» اضافه شد.
          </p>
        )}

        {previewMeta && preview && (
          <p className="text-muted-foreground text-xs">
            آیتم‌های موجود: {previewMeta.existing} • جدید در فایل: {preview.length} •{" "}
            تکراری با آیتم‌های موجود: {previewMeta.duplicates} • حالت:{" "}
            {mode === "replace" ? "جایگزینی" : "افزودن"}
          </p>
        )}

        {preview && preview.length > 0 && (
          <div className="bg-muted/40 max-h-56 overflow-y-auto rounded-lg p-3">
            <p className="text-muted-foreground mb-2 text-xs">
              پیش‌نمایش — قبل از ذخیره بررسی کنید:
            </p>
            <ul className="flex flex-col gap-1.5">
              {preview.map((item, idx) => (
                <li key={idx} className="flex flex-wrap items-center gap-2 text-sm">
                  <Badge variant="secondary">{item.category}</Badge>
                  <span>{item.title}</span>
                  {item.description ? (
                    <span className="text-muted-foreground text-xs">
                      {item.description}
                    </span>
                  ) : null}
                  {item.requires_photo ? (
                    <Badge variant="outline">عکس</Badge>
                  ) : null}
                  {item.requires_note ? (
                    <Badge variant="outline">یادداشت</Badge>
                  ) : null}
                  {item.is_critical ? (
                    <Badge className="bg-destructive/10 text-destructive">
                      حیاتی
                    </Badge>
                  ) : null}
                </li>
              ))}
            </ul>
          </div>
        )}

        {errors.length > 0 && (
          <div className="bg-destructive/10 max-h-32 overflow-y-auto rounded-lg p-3 text-sm">
            <p className="mb-1 font-medium">خطاهای سطرهای نادیده‌گرفته‌شده:</p>
            {errors.map((e, i) => (
              <p key={i} className="text-xs">
                سطر {e.row}: {e.error}
              </p>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
}

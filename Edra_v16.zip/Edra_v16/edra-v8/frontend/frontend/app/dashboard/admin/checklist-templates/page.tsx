import { ClipboardCheck, ListChecks } from "lucide-react";
import { apiServerFetch } from "@/lib/api-server";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ChecklistExcelImport } from "./checklist-excel-import";

export const metadata = { title: "قالب‌های چک‌لیست" };

interface ChecklistTemplateItem {
  id: number;
  name: string;
  description?: string;
  version?: string;
  is_active: boolean;
  equipment_type?: { id: number; name_fa: string } | number | null;
  // EDRA v5 — MEDIUM-26: items_count از backend (بدون N+1)
  items_count?: number;
}

async function fetchTemplates(): Promise<ChecklistTemplateItem[]> {
  try {
    const data = await apiServerFetch<{ results: ChecklistTemplateItem[] } | ChecklistTemplateItem[]>(
      "/api/inspections/checklist-templates/"
    );
    return Array.isArray(data) ? data : data.results ?? [];
  } catch {
    return [];
  }
}

export default async function AdminChecklistTemplatesPage() {
  const templates = await fetchTemplates();

  return (
    <div className="flex flex-col gap-6">
      <div>
        <h1 className="text-2xl font-semibold">قالب‌های چک‌لیست بازرسی</h1>
        <p className="text-muted-foreground text-sm">
          قالب‌های استاندارد بازرسی به تفکیک نوع تجهیزات
        </p>
      </div>

      {/* FEATURE: ایمپورت آیتم‌ها از فایل Excel */}
      {templates.length > 0 && (
        <ChecklistExcelImport
          templates={templates.map((t) => ({ id: t.id, name: t.name }))}
        />
      )}

      <div className="grid gap-4">
        {templates.length === 0 && (
          <Card>
            <CardContent className="text-muted-foreground py-10 text-center text-sm">
              <ClipboardCheck className="mx-auto mb-2 size-8 opacity-40" />
              قالبی ثبت نشده است
            </CardContent>
          </Card>
        )}

        {templates.map((t) => (
          <Card key={t.id}>
            <CardContent className="px-5 py-4">
              <div className="flex items-center gap-3">
                <span className="bg-primary/10 text-primary flex size-9 items-center justify-center rounded-lg">
                  <ListChecks className="size-4" />
                </span>
                <div>
                  <div className="flex items-center gap-2">
                    <p className="font-medium">{t.name}</p>
                    <Badge variant={t.is_active ? "success" : "muted"}>
                      {t.is_active ? "فعال" : "غیرفعال"}
                    </Badge>
                  </div>
                  <p className="text-muted-foreground text-xs">
                    {typeof t.equipment_type === "object" && t.equipment_type
                      ? (t.equipment_type as { name_fa: string }).name_fa
                      : "همه تجهیزات"}
                    {t.version ? ` • نسخه ${t.version}` : ""} •{" "}
                    {t.items_count ?? 0} آیتم
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}

import Link from "next/link";
import { apiServerFetch } from "@/lib/api-server";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { FileBarChart } from "lucide-react";
import { toPersianDigits } from "@/lib/jalali";

export const metadata = { title: "مشتریان" };

interface CustomerRow {
  id: number;
  username: string;
  full_name: string;
  phone: string | null;
  company_name: string | null;
  date_joined_jalali: string;
}

export default async function AdminCustomersPage() {
  const data = await apiServerFetch<{ results: CustomerRow[] }>(
    "/api/core/users/?role=customer"
  );
  const customers = data.results ?? [];

  return (
    <div className="flex flex-col gap-6">
      <div>
        <h1 className="text-2xl font-semibold">مشتریان</h1>
        <p className="text-muted-foreground text-sm">
          {toPersianDigits(customers.length)} مشتری ثبت‌شده
        </p>
      </div>

      <Card>
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b text-right">
                  <th className="text-muted-foreground px-4 py-3 text-xs font-medium">نام</th>
                  <th className="text-muted-foreground px-4 py-3 text-xs font-medium">موبایل</th>
                  <th className="text-muted-foreground px-4 py-3 text-xs font-medium">شرکت</th>
                  <th className="text-muted-foreground px-4 py-3 text-xs font-medium">تاریخ عضویت</th>
                  <th className="text-muted-foreground px-4 py-3 text-xs font-medium"></th>
                </tr>
              </thead>
              <tbody>
                {customers.map((c) => (
                  <tr key={c.id} className="hover:bg-accent/50 border-b last:border-0">
                    <td className="px-4 py-3 font-medium">{c.full_name || c.username}</td>
                    <td className="ltr-numerals px-4 py-3">{c.phone ?? "—"}</td>
                    <td className="px-4 py-3">{c.company_name || "—"}</td>
                    <td className="text-muted-foreground px-4 py-3">
                      {c.date_joined_jalali}
                    </td>
                    <td className="px-4 py-3">
                      <Button variant="ghost" size="sm" asChild>
                        <a
                          href={`/api/download/core/admin/customers/${c.id}/full-report/?format=xlsx`}
                          target="_blank"
                        >
                          <FileBarChart className="size-3.5" />
                          گزارش کامل
                        </a>
                      </Button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

import { TicketPercent, ExternalLink } from "lucide-react";
import { apiServerFetch } from "@/lib/api-server";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { toPersianDigits } from "@/lib/jalali";

export const metadata = { title: "کدهای تخفیف" };

interface DiscountRow {
  id: number;
  code: string;
  discount_type: string;
  value: number;
  is_active: boolean;
  used_count: number;
  usage_limit: number | null;
}

export default async function AdminDiscountsPage() {
  const data = await apiServerFetch<{ results: DiscountRow[] } | DiscountRow[]>(
    "/api/core/discount-codes/"
  );
  const codes = Array.isArray(data) ? data : data.results ?? [];

  return (
    <div className="flex flex-col gap-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="text-2xl font-semibold">کدهای تخفیف</h1>
        </div>
        <Button variant="outline" asChild>
          <a
            href={`${process.env.NEXT_PUBLIC_API_URL}/admin/core/discountcode/add/`}
            target="_blank"
          >
            <ExternalLink className="size-3.5" />
            ساخت کد تخفیف جدید
          </a>
        </Button>
      </div>

      <Card>
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b text-right">
                  <th className="text-muted-foreground px-4 py-3 text-xs font-medium">کد</th>
                  <th className="text-muted-foreground px-4 py-3 text-xs font-medium">مقدار</th>
                  <th className="text-muted-foreground px-4 py-3 text-xs font-medium">استفاده‌شده</th>
                  <th className="text-muted-foreground px-4 py-3 text-xs font-medium">وضعیت</th>
                </tr>
              </thead>
              <tbody>
                {codes.map((d) => (
                  <tr key={d.id} className="hover:bg-accent/50 border-b last:border-0">
                    <td className="px-4 py-3 font-mono font-medium">{d.code}</td>
                    <td className="px-4 py-3">
                      {toPersianDigits(d.value)}
                      {d.discount_type === "percent" ? "٪" : " تومان"}
                    </td>
                    <td className="px-4 py-3">
                      {toPersianDigits(d.used_count)}
                      {d.usage_limit ? ` / ${toPersianDigits(d.usage_limit)}` : ""}
                    </td>
                    <td className="px-4 py-3">
                      <Badge variant={d.is_active ? "success" : "muted"}>
                        {d.is_active ? "فعال" : "غیرفعال"}
                      </Badge>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
            {codes.length === 0 && (
              <p className="text-muted-foreground flex items-center justify-center gap-2 py-10 text-sm">
                <TicketPercent className="size-4 opacity-40" />
                کد تخفیفی ثبت نشده است
              </p>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

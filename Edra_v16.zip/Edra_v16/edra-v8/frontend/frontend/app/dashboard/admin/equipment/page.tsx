import Link from "next/link";
import { Wrench, ExternalLink } from "lucide-react";
import { apiServerFetch } from "@/lib/api-server";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import type { EquipmentType } from "@/types/equipment";

export const metadata = { title: "تجهیزات" };

export default async function AdminEquipmentPage() {
  const data = await apiServerFetch<{ results: EquipmentType[] } | EquipmentType[]>(
    "/api/core/equipment-types/"
  );
  const items = Array.isArray(data) ? data : data.results ?? [];

  return (
    <div className="flex flex-col gap-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="text-2xl font-semibold">تجهیزات</h1>
          <p className="text-muted-foreground text-sm">
            انواع تجهیزات و پارامترهای فنی هر کدام
          </p>
        </div>
        <Button variant="outline" asChild>
          <a
            href={`${process.env.NEXT_PUBLIC_API_URL}/admin/core/equipmenttype/`}
            target="_blank"
          >
            <ExternalLink className="size-3.5" />
            مدیریت کامل در پنل جنگو
          </a>
        </Button>
      </div>

      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {items.map((eq) => (
          <Card key={eq.id}>
            <CardContent className="flex flex-col gap-3 px-5 py-5">
              <span className="bg-primary/10 text-primary flex size-10 items-center justify-center rounded-lg">
                <Wrench className="size-5" />
              </span>
              <div>
                <p className="font-medium">{eq.name_fa}</p>
                <p className="text-muted-foreground text-xs" dir="ltr">
                  {eq.code}
                </p>
              </div>
              <div className="flex flex-wrap gap-1.5">
                <Badge variant="outline">
                  {eq.param_schema?.length ?? 0} پارامتر فنی
                </Badge>
                {eq.supports_install_state && (
                  <Badge variant="outline">وضعیت نصب</Badge>
                )}
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}

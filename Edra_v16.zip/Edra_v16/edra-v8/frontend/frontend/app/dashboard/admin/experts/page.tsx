import { apiServerFetch } from "@/lib/api-server";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { toPersianDigits } from "@/lib/jalali";

export const metadata = { title: "کارشناسان" };

interface ExpertRow {
  id: number;
  username: string;
  full_name: string;
  phone: string | null;
  is_active: boolean;
  date_joined_jalali: string;
}

export default async function AdminExpertsPage() {
  const data = await apiServerFetch<{ results: ExpertRow[] }>(
    "/api/core/users/?role=expert"
  );
  const experts = data.results ?? [];

  return (
    <div className="flex flex-col gap-6">
      <div>
        <h1 className="text-2xl font-semibold">کارشناسان</h1>
        <p className="text-muted-foreground text-sm">
          {toPersianDigits(experts.length)} کارشناس فعال در سیستم
        </p>
      </div>

      <Card>
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b text-right">
                  <th className="text-muted-foreground px-4 py-3 text-xs font-medium">نام</th>
                  <th className="text-muted-foreground px-4 py-3 text-xs font-medium">موبایل</th>
                  <th className="text-muted-foreground px-4 py-3 text-xs font-medium">تاریخ عضویت</th>
                  <th className="text-muted-foreground px-4 py-3 text-xs font-medium">وضعیت</th>
                </tr>
              </thead>
              <tbody>
                {experts.map((e) => (
                  <tr key={e.id} className="hover:bg-accent/50 border-b last:border-0">
                    <td className="px-4 py-3 font-medium">{e.full_name || e.username}</td>
                    <td className="ltr-numerals px-4 py-3">{e.phone ?? "—"}</td>
                    <td className="text-muted-foreground px-4 py-3">
                      {e.date_joined_jalali}
                    </td>
                    <td className="px-4 py-3">
                      <Badge variant={e.is_active ? "success" : "muted"}>
                        {e.is_active ? "فعال" : "غیرفعال"}
                      </Badge>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
        {experts.length === 0 && (
          <p className="text-muted-foreground py-10 text-center text-sm">
            کارشناسی ثبت نشده. کارشناسان از پنل ادمین جنگو (Group: Expert) اضافه می‌شوند.
          </p>
        )}
      </Card>
    </div>
  );
}

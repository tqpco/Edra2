import { requireRole } from "@/lib/require-role";
import { DashboardSidebar } from "@/components/layout/dashboard-sidebar";
import { DashboardTopbar } from "@/components/layout/dashboard-topbar";
import { ADMIN_NAV } from "@/lib/nav-config";

export default async function AdminDashboardLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  await requireRole(["admin"], "/login");

  return (
    <div className="flex min-h-svh">
      <DashboardSidebar sections={ADMIN_NAV} />
      <div className="flex min-w-0 flex-1 flex-col">
        <DashboardTopbar sections={ADMIN_NAV} profileHref="/dashboard/admin/settings" />
        <main className="flex-1 p-4 md:p-6">{children}</main>
      </div>
    </div>
  );
}

import { Bell, ExternalLink } from "lucide-react";
import { apiServerFetch } from "@/lib/api-server";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";

export const metadata = { title: "قالب‌های اعلان" };

interface TemplateRow {
  id: number;
  code: string;
  channel: string;
  subject: string;
  is_active: boolean;
}

export default async function AdminNotificationsPage() {
  const data = await apiServerFetch<{ results: TemplateRow[] } | TemplateRow[]>(
    "/api/notifications/templates/"
  );
  const templates = Array.isArray(data) ? data : data.results ?? [];

  const channelLabel: Record<string, string> = {
    sms: "پیامک",
    email: "ایمیل",
    both: "پیامک و ایمیل",
    in_app: "درون‌برنامه‌ای",
  };

  return (
    <div className="flex flex-col gap-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="text-2xl font-semibold">قالب‌های اعلان</h1>
          <p className="text-muted-foreground text-sm">
            متن پیامک/ایمیل ارسالی برای هر رویداد سیستم
          </p>
        </div>
        <Button variant="outline" asChild>
          <a
            href={`${process.env.NEXT_PUBLIC_API_URL}/admin/notifications/notificationtemplate/`}
            target="_blank"
          >
            <ExternalLink className="size-3.5" />
            ویرایش کامل در پنل جنگو
          </a>
        </Button>
      </div>

      <div className="grid gap-3">
        {templates.map((t) => (
          <Card key={t.id}>
            <CardContent className="flex flex-wrap items-center justify-between gap-3 px-5 py-4">
              <div className="flex items-center gap-3">
                <span className="bg-primary/10 text-primary flex size-9 items-center justify-center rounded-lg">
                  <Bell className="size-4" />
                </span>
                <div>
                  <p className="font-mono text-sm font-medium">{t.code}</p>
                  <p className="text-muted-foreground text-xs">{t.subject}</p>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <Badge variant="outline">{channelLabel[t.channel] ?? t.channel}</Badge>
                <Badge variant={t.is_active ? "success" : "muted"}>
                  {t.is_active ? "فعال" : "غیرفعال"}
                </Badge>
              </div>
            </CardContent>
          </Card>
        ))}
        {templates.length === 0 && (
          <p className="text-muted-foreground py-10 text-center text-sm">
            قالبی یافت نشد. دستور{" "}
            <code className="bg-muted rounded px-1 py-0.5">
              seed_notification_templates
            </code>{" "}
            را اجرا کنید.
          </p>
        )}
      </div>
    </div>
  );
}

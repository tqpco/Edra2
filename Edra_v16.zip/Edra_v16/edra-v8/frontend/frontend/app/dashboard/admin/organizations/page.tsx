import { Building2 } from "lucide-react";
import { apiServerFetch } from "@/lib/api-server";
import { Card, CardContent } from "@/components/ui/card";

export const metadata = { title: "سازمان‌ها" };

interface OrganizationItem {
  id: number;
  name: string;
  billing_contact?: number | null;
}

async function fetchOrgs(): Promise<OrganizationItem[]> {
  try {
    const data = await apiServerFetch<{ results: OrganizationItem[] } | OrganizationItem[]>(
      "/api/core/organizations/"
    );
    return Array.isArray(data) ? data : data.results ?? [];
  } catch {
    return [];
  }
}

export default async function AdminOrganizationsPage() {
  const orgs = await fetchOrgs();

  return (
    <div className="flex flex-col gap-6">
      <div>
        <h1 className="text-2xl font-semibold">سازمان‌ها</h1>
        <p className="text-muted-foreground text-sm">
          سازمان‌های دارای قرارداد بازرسی
        </p>
      </div>

      <Card>
        <CardContent className="px-0 py-2">
          {orgs.length === 0 ? (
            <p className="text-muted-foreground py-10 text-center text-sm">
              <Building2 className="mx-auto mb-2 size-8 opacity-40" />
              سازمانی ثبت نشده است
            </p>
          ) : (
            <div className="flex flex-col divide-y">
              {orgs.map((org) => (
                <div key={org.id} className="flex items-center justify-between px-5 py-4">
                  <div className="flex items-center gap-3">
                    <span className="bg-primary/10 text-primary flex size-9 items-center justify-center rounded-lg">
                      <Building2 className="size-4" />
                    </span>
                    <div>
                      <p className="text-sm font-medium">{org.name}</p>
                      <p className="text-muted-foreground text-xs">
                        {org.billing_contact ? `تماس مالی: کاربر #${org.billing_contact}` : "بدون تماس مالی"}
                      </p>
                    </div>
                  </div>
                  <span className="text-muted-foreground text-xs">#{org.id}</span>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}

import {
  ClipboardList,
  Users,
  FileCheck,
  Wallet,
  Hourglass,
  CheckCircle2,
  Activity,
} from "lucide-react";

import { apiServerFetch } from "@/lib/api-server";
import type { AdminDashboardData } from "@/types/dashboard";
import { StatCard } from "@/components/shared/stat-card";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { formatToman } from "@/lib/format";
import { formatPersianTime, formatJalali } from "@/lib/jalali";

export const metadata = { title: "داشبورد مدیریت" };

export default async function AdminDashboardPage() {
  const data = await apiServerFetch<AdminDashboardData>(
    "/api/core/admin/dashboard-stats/"
  );

  return (
    <div className="flex flex-col gap-6">
      <div>
        <h1 className="text-2xl font-semibold">داشبورد مدیریت</h1>
        <p className="text-muted-foreground text-sm">نمای کلی عملکرد سیستم</p>
      </div>

      <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
        <StatCard
          title="درآمد این ماه"
          value={formatToman(data.revenueThisMonth)}
          icon={Wallet}
          tone="success"
        />
        <StatCard title="کل درخواست‌ها" value={data.totalRequests} icon={ClipboardList} />
        <StatCard
          title="در انتظار پرداخت"
          value={data.pendingRequests}
          icon={Hourglass}
          tone="warning"
        />
        <StatCard
          title="تکمیل‌شده"
          value={data.completedRequests}
          icon={CheckCircle2}
          tone="primary"
        />
      </div>

      <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
        <StatCard title="کل کاربران" value={data.totalUsers} icon={Users} />
        <StatCard title="پرداخت موفق" value={data.totalPayments} icon={Wallet} />
        <StatCard title="کل گزارش‌ها" value={data.totalReports} icon={FileCheck} />
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Activity className="size-4" />
            فعالیت‌های اخیر
          </CardTitle>
        </CardHeader>
        <CardContent>
          {data.recentActivities.length === 0 ? (
            <p className="text-muted-foreground py-8 text-center text-sm">
              فعالیتی ثبت نشده است
            </p>
          ) : (
            <div className="flex flex-col divide-y">
              {data.recentActivities.map((a) => (
                <div key={a.id} className="flex items-center justify-between py-2.5">
                  <span className="text-sm">{a.action}</span>
                  <span className="text-muted-foreground text-xs">
                    {formatJalali(new Date(a.timestamp))} ·{" "}
                    {formatPersianTime(new Date(a.timestamp))}
                  </span>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}

import { Calculator, ExternalLink } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";

export const metadata = { title: "قیمت‌گذاری" };

export default function AdminPricingPage() {
  return (
    <div className="flex flex-col gap-6">
      <div>
        <h1 className="text-2xl font-semibold">قیمت‌گذاری</h1>
        <p className="text-muted-foreground text-sm">
          مدیریت قوانین قیمت، ضرایب شهر و فرمول‌های محاسبه
        </p>
      </div>

      <Card>
        <CardContent className="flex flex-col items-center gap-4 py-14 text-center">
          <span className="bg-primary/10 text-primary flex size-14 items-center justify-center rounded-xl">
            <Calculator className="size-7" />
          </span>
          <div>
            <p className="font-medium">مدیریت کامل قوانین قیمت‌گذاری</p>
            <p className="text-muted-foreground mt-1 max-w-md text-sm leading-relaxed">
              چون فرمول‌های قیمت (ثابت/درصدی/فرمول سفارشی) و ضرایب شهر
              پیچیده هستند، ویرایش آن‌ها از طریق پنل مدیریت جنگو با تمام
              اعتبارسنجی‌های لازم انجام می‌شود.
            </p>
          </div>
          <Button asChild>
            <a
              href={`${process.env.NEXT_PUBLIC_API_URL}/admin/pricing/pricingrule/`}
              target="_blank"
            >
              <ExternalLink />
              باز کردن پنل قیمت‌گذاری
            </a>
          </Button>
        </CardContent>
      </Card>
    </div>
  );
}

import { FolderKanban } from "lucide-react";
import { apiServerFetch } from "@/lib/api-server";
import { Card, CardContent } from "@/components/ui/card";

export const metadata = { title: "پروژه‌ها" };

interface ProjectItem {
  id: number;
  name: string;
  organization?: number | null;
}

async function fetchProjects(): Promise<ProjectItem[]> {
  try {
    const data = await apiServerFetch<{ results: ProjectItem[] } | ProjectItem[]>(
      "/api/core/projects/"
    );
    return Array.isArray(data) ? data : data.results ?? [];
  } catch {
    return [];
  }
}

async function fetchOrgs(): Promise<Record<number, string>> {
  try {
    const data = await apiServerFetch<{ results: { id: number; name: string }[] } | { id: number; name: string }[]>(
      "/api/core/organizations/"
    );
    const list = Array.isArray(data) ? data : data.results ?? [];
    return Object.fromEntries(list.map((o) => [o.id, o.name]));
  } catch {
    return {};
  }
}

export default async function AdminProjectsPage() {
  const [projects, orgs] = await Promise.all([fetchProjects(), fetchOrgs()]);

  return (
    <div className="flex flex-col gap-6">
      <div>
        <h1 className="text-2xl font-semibold">پروژه‌ها</h1>
        <p className="text-muted-foreground text-sm">
          پروژه‌های بازرسی سازمان‌ها
        </p>
      </div>

      <Card>
        <CardContent className="px-0 py-2">
          {projects.length === 0 ? (
            <p className="text-muted-foreground py-10 text-center text-sm">
              <FolderKanban className="mx-auto mb-2 size-8 opacity-40" />
              پروژه‌ای ثبت نشده است
            </p>
          ) : (
            <div className="flex flex-col divide-y">
              {projects.map((project) => (
                <div key={project.id} className="flex items-center justify-between px-5 py-4">
                  <div className="flex items-center gap-3">
                    <span className="bg-primary/10 text-primary flex size-9 items-center justify-center rounded-lg">
                      <FolderKanban className="size-4" />
                    </span>
                    <div>
                      <p className="text-sm font-medium">{project.name}</p>
                      {project.organization && (
                        <p className="text-muted-foreground text-xs">
                          {orgs[project.organization] ?? `سازمان #${project.organization}`}
                        </p>
                      )}
                    </div>
                  </div>
                  <span className="text-muted-foreground text-xs">#{project.id}</span>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}

import { DollarSign, ClipboardList, Download } from "lucide-react";
import { apiServerFetch } from "@/lib/api-server";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { formatToman } from "@/lib/format";
import { toPersianDigits } from "@/lib/jalali";

export const metadata = { title: "گزارش‌های مدیریتی" };

interface FinancialSummary {
  summary: { total_revenue: number; total_paid_count: number };
}
// EDRA v11 (P1): قرارداد رسمی با Backend — پاسخ در ساختار summary.* می‌آید
interface InspectionSummary {
  summary: {
    total_requests: number;
    total_reports: number;
    completed_requests: number;
    cancelled_requests: number;
    expired_requests: number;
    avg_gps_distance_meters: number | null;
  };
}

export default async function AdminReportsPage() {
  const [financial, inspection] = await Promise.all([
    apiServerFetch<FinancialSummary>("/api/core/admin/reports/financial/"),
    apiServerFetch<InspectionSummary>("/api/core/admin/reports/inspections/"),
  ]);

  const totalRequests = inspection.summary?.total_requests ?? 0;
  const completedRequests = inspection.summary?.completed_requests ?? 0;
  const completionRate =
    totalRequests > 0
      ? Math.round((completedRequests / totalRequests) * 1000) / 10
      : 0;

  return (
    <div className="flex flex-col gap-6">
      <div>
        <h1 className="text-2xl font-semibold">گزارش‌های مدیریتی</h1>
        <p className="text-muted-foreground text-sm">
          گزارش کلی مالی و عملکرد کارشناسی (۹۰ روز اخیر)
        </p>
      </div>

      <div className="grid gap-4 md:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-base">
              <DollarSign className="size-4" />
              گزارش کلی مالی
            </CardTitle>
          </CardHeader>
          <CardContent className="flex flex-col gap-3">
            <div className="flex justify-between text-sm">
              <span className="text-muted-foreground">جمع درآمد</span>
              <span className="font-semibold">
                {formatToman(financial.summary.total_revenue)}
              </span>
            </div>
            <div className="flex justify-between text-sm">
              <span className="text-muted-foreground">تعداد پرداخت موفق</span>
              <span className="font-semibold">
                {toPersianDigits(financial.summary.total_paid_count)}
              </span>
            </div>
            <Button size="sm" variant="outline" className="mt-2 w-fit" asChild>
              {/* eslint-disable-next-line @next/next/no-html-link-for-pages -- لینک دانلود API (نه ناوبری داخلی) */}
              <a href="/api/download/core/admin/reports/financial/?format=xlsx">
                <Download className="size-3.5" />
                دانلود گزارش کامل (اکسل)
              </a>
            </Button>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-base">
              <ClipboardList className="size-4" />
              گزارش کلی کارشناسی
            </CardTitle>
          </CardHeader>
          <CardContent className="flex flex-col gap-3">
            <div className="flex justify-between text-sm">
              <span className="text-muted-foreground">کل درخواست‌ها</span>
              <span className="font-semibold">
                {toPersianDigits(totalRequests)}
              </span>
            </div>
            <div className="flex justify-between text-sm">
              <span className="text-muted-foreground">تکمیل‌شده</span>
              <span className="font-semibold">
                {toPersianDigits(completedRequests)}
              </span>
            </div>
            <div className="flex justify-between text-sm">
              <span className="text-muted-foreground">نرخ تکمیل</span>
              <span className="font-semibold">
                {toPersianDigits(completionRate)}٪
              </span>
            </div>
            <Button size="sm" variant="outline" className="mt-2 w-fit" asChild>
              {/* eslint-disable-next-line @next/next/no-html-link-for-pages -- لینک دانلود API (نه ناوبری داخلی) */}
              <a href="/api/download/core/admin/reports/inspections/?format=xlsx">
                <Download className="size-3.5" />
                دانلود گزارش کامل (اکسل)
              </a>
            </Button>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}

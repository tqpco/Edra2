"use client";

import * as React from "react";
import { useRouter } from "next/navigation";
import { UserCog } from "lucide-react";
import { Button } from "@/components/ui/button";
import { AssignExpertDialog } from "@/components/shared/assign-expert-dialog";

export function AssignExpertButton({
  requestId,
  currentExpert,
}: {
  requestId: number;
  currentExpert: string | null;
}) {
  const router = useRouter();
  const [open, setOpen] = React.useState(false);

  return (
    <>
      <Button variant="outline" onClick={() => setOpen(true)}>
        <UserCog />
        {currentExpert ? "تغییر کارشناس" : "تخصیص کارشناس"}
      </Button>
      <AssignExpertDialog
        requestId={requestId}
        open={open}
        onOpenChange={(o) => {
          setOpen(o);
          if (!o) router.refresh();
        }}
      />
    </>
  );
}

import { notFound } from "next/navigation";
import { MapPin, Calendar, Package, User as UserIcon, Wallet } from "lucide-react";

import { apiServerFetch, ApiError } from "@/lib/api-server";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { getStatusInfo, REQUEST_STATUS_MAP, PAYMENT_STATUS_MAP } from "@/lib/status-map";
import { formatToman } from "@/lib/format";
import { AssignExpertButton } from "./assign-expert-button";

export const metadata = { title: "جزئیات درخواست" };

interface RequestDetail {
  id: number;
  request_number: string;
  equipment_type_name: string;
  customer_name: string;
  status: string;
  final_price: number;
  calculated_price: number;
  created_at_jalali: string;
  scheduled_at_jalali: string | null;
  city: string;
  address: string;
  service_type: string;
  brand_model: string;
  params: Record<string, unknown>;
  assigned_expert_name: string | null;
}

interface PaymentRow {
  id: number;
  amount: number;
  status: string;
  created_at_jalali: string;
}

export default async function AdminRequestDetailPage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = await params;

  let request: RequestDetail;
  try {
    request = await apiServerFetch<RequestDetail>(
      `/api/core/inspection-requests/${id}/`
    );
  } catch (err) {
    if (err instanceof ApiError && err.status === 404) notFound();
    throw err;
  }

  let payments: PaymentRow[] = [];
  try {
    const res = await apiServerFetch<{ results: PaymentRow[] } | PaymentRow[]>(
      `/api/core/payments/?inspection_request=${id}`
    );
    payments = Array.isArray(res) ? res : res.results ?? [];
  } catch {
    payments = [];
  }

  const status = getStatusInfo(REQUEST_STATUS_MAP, request.status);

  return (
    <div className="flex flex-col gap-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-2xl font-semibold">{request.equipment_type_name}</h1>
            <Badge variant={status.variant}>{status.label}</Badge>
          </div>
          <p className="text-muted-foreground text-sm">
            درخواست {request.request_number} · {request.customer_name}
          </p>
        </div>
        <AssignExpertButton requestId={request.id} currentExpert={request.assigned_expert_name} />
      </div>

      <div className="grid gap-4 md:grid-cols-3">
        <Card className="md:col-span-2">
          <CardHeader>
            <CardTitle className="text-base">جزئیات</CardTitle>
          </CardHeader>
          <CardContent className="grid gap-3 text-sm sm:grid-cols-2">
            <Row icon={UserIcon} label="مشتری">{request.customer_name}</Row>
            <Row icon={Package} label="برند/مدل">{request.brand_model || "—"}</Row>
            <Row icon={Package} label="سطح سرویس">
              {request.service_type === "pro" ? "حرفه‌ای" : "استاندارد"}
            </Row>
            {request.scheduled_at_jalali && (
              <Row icon={Calendar} label="زمان کارشناسی">
                {request.scheduled_at_jalali}
              </Row>
            )}
            <Row icon={MapPin} label="آدرس">
              {request.city} - {request.address}
            </Row>
            <Row icon={UserIcon} label="کارشناس">
              {request.assigned_expert_name || "تخصیص‌نیافته"}
            </Row>
            {Object.keys(request.params || {}).length > 0 && (
              <div className="sm:col-span-2">
                <p className="text-muted-foreground mb-1.5 text-xs">مشخصات فنی</p>
                <div className="flex flex-wrap gap-1.5">
                  {Object.entries(request.params).map(([k, v]) => (
                    <Badge key={k} variant="outline">
                      {k}: {String(v)}
                    </Badge>
                  ))}
                </div>
              </div>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-base">
              <Wallet className="size-4" />
              مالی
            </CardTitle>
          </CardHeader>
          <CardContent className="flex flex-col gap-2 text-sm">
            <div className="flex justify-between">
              <span className="text-muted-foreground">قیمت محاسبه‌شده</span>
              <span>{formatToman(request.calculated_price)}</span>
            </div>
            <div className="flex justify-between font-medium">
              <span className="text-muted-foreground">مبلغ نهایی</span>
              <span>{formatToman(request.final_price)}</span>
            </div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="text-base">پرداخت‌ها</CardTitle>
        </CardHeader>
        <CardContent>
          {payments.length === 0 ? (
            <p className="text-muted-foreground py-4 text-center text-sm">
              پرداختی ثبت نشده است
            </p>
          ) : (
            <div className="flex flex-col divide-y">
              {payments.map((p) => {
                const pStatus = getStatusInfo(PAYMENT_STATUS_MAP, p.status);
                return (
                  <div key={p.id} className="flex items-center justify-between py-2.5 text-sm">
                    <span className="text-muted-foreground">{p.created_at_jalali}</span>
                    <div className="flex items-center gap-2">
                      <span>{formatToman(p.amount)}</span>
                      <Badge variant={pStatus.variant}>{pStatus.label}</Badge>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}

function Row({
  icon: Icon,
  label,
  children,
}: {
  icon: typeof MapPin;
  label: string;
  children: React.ReactNode;
}) {
  return (
    <div className="flex items-start gap-2">
      <Icon className="text-muted-foreground mt-0.5 size-4 shrink-0" />
      <div>
        <span className="text-muted-foreground">{label}: </span>
        <span className="font-medium">{children}</span>
      </div>
    </div>
  );
}

import { AdminRequestsTable } from "./requests-table";

export const metadata = { title: "درخواست‌ها" };

export default function AdminRequestsPage() {
  return (
    <div className="flex flex-col gap-6">
      <div>
        <h1 className="text-2xl font-semibold">مدیریت درخواست‌ها</h1>
        <p className="text-muted-foreground text-sm">
          مشاهده، فیلتر و تخصیص کارشناس به درخواست‌های بازرسی
        </p>
      </div>
      <AdminRequestsTable />
    </div>
  );
}

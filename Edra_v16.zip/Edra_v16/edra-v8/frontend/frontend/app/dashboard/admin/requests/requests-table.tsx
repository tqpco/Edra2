"use client";

import * as React from "react";
import Link from "next/link";
import { useQuery } from "@tanstack/react-query";
import { UserCog, Search, ExternalLink } from "lucide-react";

import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Select,
  SelectTrigger,
  SelectValue,
  SelectContent,
  SelectItem,
} from "@/components/ui/select";
import { AssignExpertDialog } from "@/components/shared/assign-expert-dialog";
import { getStatusInfo, REQUEST_STATUS_MAP } from "@/lib/status-map";
import { formatToman } from "@/lib/format";
import { toPersianDigits } from "@/lib/jalali";

interface AdminRequestRow {
  id: number;
  request_number: string;
  equipment_type_name: string;
  customer_name: string;
  city: string;
  status: string;
  final_price: number;
  assigned_expert_name: string | null;
  created_at_jalali: string;
}

async function fetchRequests(status: string, search: string) {
  const params = new URLSearchParams();
  if (status !== "all") params.set("status", status);
  if (search) params.set("search", search);
  const res = await fetch(`/api/proxy/core/inspection-requests/?${params}`);
  const data = await res.json();
  return (data.results ?? data) as AdminRequestRow[];
}

const STATUS_FILTERS = [
  { value: "all", label: "همه وضعیت‌ها" },
  ...Object.entries(REQUEST_STATUS_MAP).map(([value, info]) => ({
    value,
    label: info.label,
  })),
];

export function AdminRequestsTable() {
  const [status, setStatus] = React.useState("all");
  const [search, setSearch] = React.useState("");
  const [assignTarget, setAssignTarget] = React.useState<number | null>(null);

  const { data: requests, isLoading } = useQuery({
    queryKey: ["admin-requests", status, search],
    queryFn: () => fetchRequests(status, search),
  });

  return (
    <>
      <div className="flex flex-wrap gap-3">
        <div className="relative max-w-xs flex-1">
          <Search className="text-muted-foreground pointer-events-none absolute right-3 top-1/2 size-4 -translate-y-1/2" />
          <Input
            placeholder="جستجو (شماره، شهر، مشتری...)"
            className="pr-9"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
        </div>
        <Select value={status} onValueChange={setStatus}>
          <SelectTrigger className="w-48">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            {STATUS_FILTERS.map((f) => (
              <SelectItem key={f.value} value={f.value}>
                {f.label}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      <Card>
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b text-right">
                  <Th>شماره</Th>
                  <Th>تجهیز</Th>
                  <Th>مشتری</Th>
                  <Th>شهر</Th>
                  <Th>کارشناس</Th>
                  <Th>مبلغ</Th>
                  <Th>وضعیت</Th>
                  <Th></Th>
                </tr>
              </thead>
              <tbody>
                {isLoading ? (
                  <tr>
                    <td colSpan={8} className="text-muted-foreground py-10 text-center">
                      در حال بارگذاری...
                    </td>
                  </tr>
                ) : !requests?.length ? (
                  <tr>
                    <td colSpan={8} className="text-muted-foreground py-10 text-center">
                      موردی یافت نشد
                    </td>
                  </tr>
                ) : (
                  requests.map((r) => {
                    const s = getStatusInfo(REQUEST_STATUS_MAP, r.status);
                    return (
                      <tr key={r.id} className="hover:bg-accent/50 border-b last:border-0">
                        <Td className="ltr-numerals font-medium">
                          {toPersianDigits(r.request_number)}
                        </Td>
                        <Td>{r.equipment_type_name}</Td>
                        <Td>{r.customer_name}</Td>
                        <Td>{r.city}</Td>
                        <Td>
                          {r.assigned_expert_name ?? (
                            <span className="text-muted-foreground">تخصیص‌نیافته</span>
                          )}
                        </Td>
                        <Td>{formatToman(r.final_price)}</Td>
                        <Td>
                          <Badge variant={s.variant}>{s.label}</Badge>
                        </Td>
                        <Td>
                          <div className="flex items-center gap-1">
                            <Button
                              variant="ghost"
                              size="icon"
                              className="size-8"
                              onClick={() => setAssignTarget(r.id)}
                              title="تخصیص کارشناس"
                            >
                              <UserCog className="size-4" />
                            </Button>
                            <Button variant="ghost" size="icon" className="size-8" asChild>
                              <Link href={`/dashboard/admin/requests/${r.id}`}>
                                <ExternalLink className="size-4" />
                              </Link>
                            </Button>
                          </div>
                        </Td>
                      </tr>
                    );
                  })
                )}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>

      {assignTarget !== null && (
        <AssignExpertDialog
          requestId={assignTarget}
          open={assignTarget !== null}
          onOpenChange={(open) => !open && setAssignTarget(null)}
        />
      )}
    </>
  );
}

function Th({ children }: { children?: React.ReactNode }) {
  return (
    <th className="text-muted-foreground px-4 py-3 text-xs font-medium">{children}</th>
  );
}
function Td({ children, className }: { children: React.ReactNode; className?: string }) {
  return <td className={`px-4 py-3 ${className ?? ""}`}>{children}</td>;
}

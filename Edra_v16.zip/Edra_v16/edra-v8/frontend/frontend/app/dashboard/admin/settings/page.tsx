import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { ChangePasswordCard } from "@/components/shared/profile-form";
import { apiServerFetch } from "@/lib/api-server";
import type { User } from "@/types/user";

export const metadata = { title: "تنظیمات" };

export default async function AdminSettingsPage() {
  const me = await apiServerFetch<User>("/api/core/users/me/");

  return (
    <div className="mx-auto flex max-w-2xl flex-col gap-6">
      <div>
        <h1 className="text-2xl font-semibold">تنظیمات</h1>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="text-base">مشخصات حساب</CardTitle>
        </CardHeader>
        <CardContent className="grid gap-2 text-sm">
          <div className="flex justify-between border-b py-2">
            <span className="text-muted-foreground">نام</span>
            <span>{me.full_name}</span>
          </div>
          <div className="flex justify-between border-b py-2">
            <span className="text-muted-foreground">نام کاربری</span>
            <span dir="ltr">{me.username}</span>
          </div>
          <div className="flex justify-between py-2">
            <span className="text-muted-foreground">ایمیل</span>
            <span dir="ltr">{me.email || "—"}</span>
          </div>
        </CardContent>
      </Card>

      <ChangePasswordCard endpoint="/api/proxy/expert/profile/change-password/" />
    </div>
  );
}

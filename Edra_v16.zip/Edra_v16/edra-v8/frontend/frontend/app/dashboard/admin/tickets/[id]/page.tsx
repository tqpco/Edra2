import { notFound } from "next/navigation";
import { apiServerFetch, ApiError } from "@/lib/api-server";
import { TicketThread } from "@/components/shared/ticket-thread";
import type { TicketDetail } from "@/types/ticket";
import type { User } from "@/types/user";

export const metadata = { title: "جزئیات تیکت" };

export default async function AdminTicketDetailPage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = await params;

  let ticket: TicketDetail;
  let me: User;
  try {
    [ticket, me] = await Promise.all([
      apiServerFetch<TicketDetail>(`/api/support/tickets/${id}/`),
      apiServerFetch<User>("/api/core/users/me/"),
    ]);
  } catch (err) {
    if (err instanceof ApiError && err.status === 404) notFound();
    throw err;
  }

  return (
    <div className="mx-auto max-w-2xl">
      <TicketThread ticket={ticket} currentUserName={me.full_name} isStaff />
    </div>
  );
}

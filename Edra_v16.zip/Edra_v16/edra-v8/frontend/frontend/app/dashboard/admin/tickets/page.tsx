import Link from "next/link";
import { apiServerFetch } from "@/lib/api-server";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import type { TicketListItem } from "@/types/ticket";

export const metadata = { title: "مدیریت تیکت‌ها" };

export default async function AdminTicketsPage() {
  const data = await apiServerFetch<{ results: TicketListItem[] }>(
    "/api/support/tickets/"
  );
  const tickets = data.results ?? [];

  return (
    <div className="flex flex-col gap-6">
      <div>
        <h1 className="text-2xl font-semibold">مدیریت تیکت‌ها</h1>
        <p className="text-muted-foreground text-sm">
          {tickets.length} تیکت در سیستم
        </p>
      </div>

      <Card>
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b text-right">
                  <th className="text-muted-foreground px-4 py-3 text-xs font-medium">عنوان</th>
                  <th className="text-muted-foreground px-4 py-3 text-xs font-medium">مشتری</th>
                  <th className="text-muted-foreground px-4 py-3 text-xs font-medium">مسئول</th>
                  <th className="text-muted-foreground px-4 py-3 text-xs font-medium">اولویت</th>
                  <th className="text-muted-foreground px-4 py-3 text-xs font-medium">وضعیت</th>
                  <th className="text-muted-foreground px-4 py-3 text-xs font-medium">آخرین بروزرسانی</th>
                </tr>
              </thead>
              <tbody>
                {tickets.map((t) => (
                  <tr key={t.id} className="hover:bg-accent/50 border-b last:border-0">
                    <td className="px-4 py-3">
                      <Link
                        href={`/dashboard/admin/tickets/${t.id}`}
                        className="hover:text-primary font-medium"
                      >
                        {t.title}
                      </Link>
                    </td>
                    <td className="px-4 py-3">{t.customer_name}</td>
                    <td className="px-4 py-3">
                      {t.assigned_to_name ?? (
                        <span className="text-muted-foreground">تخصیص‌نیافته</span>
                      )}
                    </td>
                    <td className="px-4 py-3">{t.priority_name}</td>
                    <td className="px-4 py-3">
                      <Badge variant="outline">{t.status_name}</Badge>
                    </td>
                    <td className="text-muted-foreground px-4 py-3">
                      {t.updated_at_jalali}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

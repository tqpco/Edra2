"use client";

import * as React from "react";
import { Loader2, Plus } from "lucide-react";

import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { toEnglishDigits } from "@/lib/jalali";

const QUICK_AMOUNTS = [500000, 1000000, 2000000, 5000000];

export function CreditTopupForm() {
  const [amount, setAmount] = React.useState("");
  const [loading, setLoading] = React.useState(false);
  const [error, setError] = React.useState<string | null>(null);

  async function handleTopup() {
    setError(null);
    const value = Number(toEnglishDigits(amount));
    if (!value || value < 10000) {
      setError("مبلغ معتبر وارد کنید (حداقل ۱۰,۰۰۰ تومان)");
      return;
    }
    setLoading(true);
    try {
      const res = await fetch("/api/proxy/core/credit/deposit/", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ amount: value, method: "online" }),
      });
      const data = await res.json();
      if (!res.ok) {
        setError(data.error || "درخواست ناموفق بود.");
        return;
      }
      if (data.payment_url) {
        window.location.href = data.payment_url;
      }
    } catch {
      setError("ارتباط با سرور برقرار نشد.");
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="flex flex-col gap-3">
      {error && (
        <Alert variant="destructive">
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      )}
      <div className="flex flex-wrap gap-2">
        {QUICK_AMOUNTS.map((a) => (
          <Button
            key={a}
            type="button"
            variant="outline"
            size="sm"
            onClick={() => setAmount(String(a))}
          >
            {new Intl.NumberFormat("fa-IR").format(a)} تومان
          </Button>
        ))}
      </div>
      <div className="flex gap-2">
        <Input
          dir="ltr"
          inputMode="numeric"
          placeholder="مبلغ دلخواه (تومان)"
          value={amount}
          onChange={(e) => setAmount(e.target.value)}
        />
        <Button onClick={handleTopup} disabled={loading}>
          {loading ? <Loader2 className="animate-spin" /> : <Plus />}
          افزایش اعتبار
        </Button>
      </div>
    </div>
  );
}

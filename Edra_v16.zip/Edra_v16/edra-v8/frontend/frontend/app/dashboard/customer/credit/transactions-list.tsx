"use client";

import { useQuery } from "@tanstack/react-query";
import { ArrowDownLeft, ArrowUpRight } from "lucide-react";
import { formatToman } from "@/lib/format";

interface CreditTransaction {
  id: number;
  amount: number;
  transaction_type: string;
  description: string;
  created_at_jalali: string;
}

async function fetchTransactions(): Promise<CreditTransaction[]> {
  const res = await fetch("/api/proxy/core/credit-transactions/");
  const data = await res.json();
  return data.results ?? data;
}

export function CreditTransactionsList() {
  const { data, isLoading } = useQuery({
    queryKey: ["credit-transactions"],
    queryFn: fetchTransactions,
  });

  if (isLoading) {
    return <p className="text-muted-foreground py-6 text-center text-sm">در حال بارگذاری...</p>;
  }
  if (!data?.length) {
    return (
      <p className="text-muted-foreground py-6 text-center text-sm">
        تراکنشی ثبت نشده است
      </p>
    );
  }

  return (
    <div className="flex flex-col divide-y">
      {data.map((tx) => {
        const isDeposit = tx.transaction_type === "deposit";
        return (
          <div key={tx.id} className="flex items-center justify-between py-2.5">
            <div className="flex items-center gap-2.5">
              <span
                className={`flex size-8 items-center justify-center rounded-full ${
                  isDeposit ? "bg-success/10 text-success" : "bg-destructive/10 text-destructive"
                }`}
              >
                {isDeposit ? (
                  <ArrowDownLeft className="size-4" />
                ) : (
                  <ArrowUpRight className="size-4" />
                )}
              </span>
              <div>
                <p className="text-sm">{tx.description || (isDeposit ? "واریز" : "برداشت")}</p>
                <p className="text-muted-foreground text-xs">{tx.created_at_jalali}</p>
              </div>
            </div>
            <span className={`text-sm font-medium ${isDeposit ? "text-success" : ""}`}>
              {isDeposit ? "+" : "-"} {formatToman(tx.amount)}
            </span>
          </div>
        );
      })}
    </div>
  );
}

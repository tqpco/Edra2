import Link from "next/link";
import { notFound } from "next/navigation";
import { ArrowRight, FileDown, FileText, Receipt } from "lucide-react";
import { apiServerFetch } from "@/lib/api-server";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { formatToman, formatRial } from "@/lib/format";

export const metadata = { title: "جزئیات فاکتور" };

interface InvoiceDetail {
  id: number;
  invoice_number: string;
  base_amount: number;
  total_amount: number;
  discount_amount: number;
  tax_amount: number;
  final_amount: number;
  final_rial: number | null;
  is_paid: boolean;
  status: string;
  pdf_file: string | null;
  issue_date_jalali: string;
  due_date_jalali: string;
  paid_at_jalali: string | null;
  pricing_version: string;
  inspection_request: number;
}

export default async function CustomerInvoiceDetailPage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = await params;
  let invoice: InvoiceDetail;
  try {
    invoice = await apiServerFetch<InvoiceDetail>(`/api/core/invoices/${id}/`);
  } catch {
    notFound();
  }

  return (
    <div className="mx-auto flex max-w-3xl flex-col gap-6">
      <div className="flex items-center justify-between">
        <Link
          href="/dashboard/customer/invoices"
          className="text-muted-foreground hover:text-foreground inline-flex items-center gap-1 text-sm"
        >
          <ArrowRight className="size-4" />
          بازگشت به فاکتورها
        </Link>
        {invoice.pdf_file && (
          <Button size="sm" asChild>
            <a href={`/api/download/core/invoices/${invoice.id}/pdf/`} target="_blank" rel="noreferrer">
              <FileDown className="size-4" />
              دانلود PDF فاکتور
            </a>
          </Button>
        )}
      </div>

      <Card>
        <CardHeader className="flex flex-row items-center justify-between border-b">
          <CardTitle className="flex items-center gap-2 text-base">
            <FileText className="size-5" />
            {invoice.invoice_number}
          </CardTitle>
          {invoice.is_paid ? (
            <Badge variant="success">پرداخت شده</Badge>
          ) : (
            <Badge variant="warning">پرداخت نشده</Badge>
          )}
        </CardHeader>
        <CardContent className="grid gap-4 py-5 text-sm">
          <div className="grid grid-cols-2 gap-3 sm:grid-cols-3">
            <InfoBox label="تاریخ صدور" value={invoice.issue_date_jalali} />
            <InfoBox label="تاریخ سررسید" value={invoice.due_date_jalali} />
            <InfoBox label="تاریخ پرداخت" value={invoice.paid_at_jalali ?? "—"} />
            <InfoBox label="شماره درخواست" value={`#${invoice.inspection_request}`} />
            <InfoBox label="نسخه قیمت‌گذاری" value={invoice.pricing_version || "1.0"} />
            <InfoBox label="وضعیت تولید" value={invoice.status === "generated" ? "تولید شده" : invoice.status} />
          </div>

          <div className="bg-muted/40 mt-2 flex flex-col gap-2 rounded-xl p-4">
            <AmountRow label="مبلغ پایه (پیش از تخفیف)" value={formatToman(invoice.base_amount)} />
            {invoice.discount_amount > 0 && (
              <AmountRow label="تخفیف" value={`− ${formatToman(invoice.discount_amount)}`} negative />
            )}
            <AmountRow label="مبلغ پس از تخفیف" value={formatToman(invoice.total_amount)} />
            <AmountRow label="مالیات ارزش افزوده (۹٪)" value={formatToman(invoice.tax_amount)} />
            <div className="border-primary/30 border-t pt-2">
              <AmountRow
                label="مبلغ نهایی (تومان)"
                value={formatToman(invoice.final_amount)}
                bold
              />
            </div>
            <AmountRow
              label="معادل ریالی (دفتر مالی)"
              value={formatRial(invoice.final_rial ?? invoice.final_amount * 10)}
              mono
            />
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardContent className="flex items-center gap-3 px-5 py-4 text-sm">
          <Receipt className="text-muted-foreground size-5 shrink-0" />
          <span className="text-muted-foreground">
            این فاکتور به‌صورت الکترونیکی صادر شده است. برای پیگیری پرداخت به بخش
            <Link href="/dashboard/customer/payments" className="text-primary mx-1 hover:underline">
              پرداخت‌ها
            </Link>
            مراجعه کنید.
          </span>
        </CardContent>
      </Card>
    </div>
  );
}

function InfoBox({ label, value }: { label: string; value: string }) {
  return (
    <div>
      <p className="text-muted-foreground text-xs">{label}</p>
      <p className="mt-0.5 font-medium">{value}</p>
    </div>
  );
}

function AmountRow({
  label,
  value,
  negative,
  bold,
  mono,
}: {
  label: string;
  value: string;
  negative?: boolean;
  bold?: boolean;
  mono?: boolean;
}) {
  return (
    <div className="flex items-center justify-between">
      <span className="text-muted-foreground text-sm">{label}</span>
      <span
        className={`text-sm ${mono ? "font-mono" : ""} ${
          negative ? "text-destructive" : bold ? "text-primary font-bold text-base" : "font-medium"
        }`}
      >
        {value}
      </span>
    </div>
  );
}

import Link from "next/link";
import { FileDown, ChevronLeft } from "lucide-react";
import { apiServerFetch } from "@/lib/api-server";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { formatToman } from "@/lib/format";

export const metadata = { title: "فاکتورهای من" };

interface InvoiceItem {
  id: number;
  invoice_number: string;
  final_amount: number;
  final_rial: number | null;
  is_paid: boolean;
  status: string;
  pdf_file: string | null;
  issue_date_jalali: string;
  due_date_jalali: string;
}

async function fetchInvoices(): Promise<InvoiceItem[]> {
  try {
    const data = await apiServerFetch<{ results: InvoiceItem[] } | InvoiceItem[]>(
      "/api/core/invoices/?ordering=-issue_date"
    );
    return Array.isArray(data) ? data : data.results ?? [];
  } catch {
    return [];
  }
}

export default async function CustomerInvoicesPage() {
  const invoices = await fetchInvoices();

  return (
    <div className="flex flex-col gap-6">
      <div>
        <h1 className="text-2xl font-semibold">فاکتورهای من</h1>
        <p className="text-muted-foreground text-sm">
          فاکتورهای صادرشده بابت درخواست‌های بازرسی شما
        </p>
      </div>

      <Card>
        <CardContent className="px-0 py-2">
          {invoices.length === 0 ? (
            <p className="text-muted-foreground py-10 text-center text-sm">
              فاکتوری صادر نشده است
            </p>
          ) : (
            <div className="flex flex-col divide-y">
              {invoices.map((inv) => (
                <Link
                  key={inv.id}
                  href={`/dashboard/customer/invoices/${inv.id}`}
                  className="flex items-center justify-between gap-3 px-5 py-4 transition-colors hover:bg-muted/50"
                >
                  <div className="min-w-0">
                    <div className="flex items-center gap-2">
                      <p className="font-mono text-sm font-medium">{inv.invoice_number}</p>
                      {inv.is_paid ? (
                        <Badge variant="success">پرداخت شده</Badge>
                      ) : (
                        <Badge variant="warning">پرداخت نشده</Badge>
                      )}
                    </div>
                    <p className="text-muted-foreground mt-1 text-xs">
                      {inv.issue_date_jalali} • سررسید: {inv.due_date_jalali}
                    </p>
                  </div>
                  <div className="flex shrink-0 items-center gap-2">
                    <span className="text-sm font-semibold">
                      {formatToman(inv.final_amount)}
                    </span>
                    {inv.pdf_file && (
                      <Button size="icon" variant="ghost" className="size-8" asChild>
                        <a
                          href={`/api/download/core/invoices/${inv.id}/pdf/`}
                          target="_blank"
                          rel="noreferrer"
                          onClick={(e) => e.stopPropagation()}
                          title="دانلود PDF"
                        >
                          <FileDown className="size-4" />
                        </a>
                      </Button>
                    )}
                    <ChevronLeft className="text-muted-foreground size-4" />
                  </div>
                </Link>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}

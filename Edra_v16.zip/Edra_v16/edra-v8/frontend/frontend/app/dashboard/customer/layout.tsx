import { requireRole } from "@/lib/require-role";
import { DashboardSidebar } from "@/components/layout/dashboard-sidebar";
import { DashboardTopbar } from "@/components/layout/dashboard-topbar";
import { CUSTOMER_NAV } from "@/lib/nav-config";

export default async function CustomerDashboardLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  await requireRole(["customer"], "/customer-login");

  return (
    <div className="flex min-h-svh">
      <DashboardSidebar sections={CUSTOMER_NAV} />
      <div className="flex min-w-0 flex-1 flex-col">
        <DashboardTopbar sections={CUSTOMER_NAV} profileHref="/dashboard/customer/profile" />
        <main className="flex-1 p-4 md:p-6">{children}</main>
      </div>
    </div>
  );
}

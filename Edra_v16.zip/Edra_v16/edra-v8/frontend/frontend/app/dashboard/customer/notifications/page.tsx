"use client";

import { useCallback, useEffect, useState } from "react";
import { Bell, CheckCheck, MailOpen } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { apiClientFetch } from "@/lib/api-client";
import { toast } from "sonner";

interface NotificationItem {
  id: number;
  type: string;
  subject: string;
  content: string;
  status: string;
  is_read: boolean;
  created_at_jalali?: string;
}

export default function CustomerNotificationsPage() {
  const [notifications, setNotifications] = useState<NotificationItem[]>([]);
  const [loading, setLoading] = useState(true);

  const fetchNotifications = useCallback(async (): Promise<NotificationItem[]> => {
    const data = await apiClientFetch<{ results: NotificationItem[] } | NotificationItem[]>(
      "/api/core/notifications/"
    );
    return Array.isArray(data) ? data : data.results ?? [];
  }, []);

  useEffect(() => {
    fetchNotifications()
      .then(setNotifications)
      .catch(() => toast.error("خطا در دریافت اعلان‌ها"))
      .finally(() => setLoading(false));
  }, [fetchNotifications]);

  const markRead = async (id: number) => {
    try {
      await apiClientFetch(`/api/core/notifications/${id}/mark_read/`, { method: "POST", body: {} });
      setNotifications((prev) =>
        prev.map((n) => (n.id === id ? { ...n, is_read: true, status: "read" } : n))
      );
    } catch {
      toast.error("خطا در علامت‌گذاری");
    }
  };

  const markAllRead = async () => {
    try {
      await apiClientFetch("/api/core/notifications/mark_all_read/", { method: "POST", body: {} });
      setNotifications((prev) => prev.map((n) => ({ ...n, is_read: true, status: "read" })));
      toast.success("همه اعلان‌ها خوانده شد");
    } catch {
      toast.error("خطا در عملیات");
    }
  };

  const unread = notifications.filter((n) => !n.is_read).length;

  return (
    <div className="flex flex-col gap-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="text-2xl font-semibold">اعلان‌ها</h1>
          <p className="text-muted-foreground text-sm">
            {unread > 0 ? `${unread} اعلان خوانده‌نشده` : "اعلان خوانده‌نشده‌ای ندارید"}
          </p>
        </div>
        {unread > 0 && (
          <Button variant="outline" size="sm" onClick={markAllRead}>
            <CheckCheck className="size-4" />
            خواندن همه
          </Button>
        )}
      </div>

      <Card>
        <CardContent className="px-0 py-2">
          {loading ? (
            <p className="text-muted-foreground py-10 text-center text-sm">در حال بارگذاری...</p>
          ) : notifications.length === 0 ? (
            <p className="text-muted-foreground py-10 text-center text-sm">
              <Bell className="mx-auto mb-2 size-8 opacity-40" />
              اعلانی دریافت نکرده‌اید
            </p>
          ) : (
            <div className="flex flex-col divide-y">
              {notifications.map((n) => (
                <button
                  key={n.id}
                  onClick={() => !n.is_read && markRead(n.id)}
                  className={`flex w-full items-start gap-3 px-5 py-4 text-right transition-colors hover:bg-muted/40 ${
                    !n.is_read ? "bg-primary/[0.03]" : ""
                  }`}
                >
                  <span
                    className={`mt-0.5 flex size-9 shrink-0 items-center justify-center rounded-lg ${
                      n.is_read ? "bg-muted text-muted-foreground" : "bg-primary/10 text-primary"
                    }`}
                  >
                    {n.is_read ? <MailOpen className="size-4" /> : <Bell className="size-4" />}
                  </span>
                  <span className="min-w-0 flex-1">
                    <span className="flex flex-wrap items-center gap-2">
                      <span className="text-sm font-medium">{n.subject}</span>
                      {!n.is_read && <Badge variant="default">جدید</Badge>}
                    </span>
                    <span className="text-muted-foreground mt-0.5 block text-sm">{n.content}</span>
                    <span className="text-muted-foreground mt-1 block text-xs">
                      {n.created_at_jalali ?? ""}
                    </span>
                  </span>
                </button>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}

import Link from "next/link";
import { Receipt, FileDown, ChevronLeft } from "lucide-react";
import { apiServerFetch } from "@/lib/api-server";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { getStatusInfo, PAYMENT_STATUS_MAP } from "@/lib/status-map";
import { formatToman } from "@/lib/format";

export const metadata = { title: "پرداخت‌ها و فاکتورها" };

interface PaymentItem {
  id: number;
  amount: number;
  status: string;
  created_at_jalali: string;
}
interface InvoiceItem {
  id: number;
  invoice_number: string;
  final_amount: number;
  pdf_file: string | null;
  issue_date_jalali: string;
}

async function fetchList<T>(path: string): Promise<T[]> {
  try {
    const data = await apiServerFetch<{ results: T[] } | T[]>(path);
    return Array.isArray(data) ? data : data.results ?? [];
  } catch {
    return [];
  }
}

export default async function CustomerPaymentsPage() {
  const [payments, invoices] = await Promise.all([
    fetchList<PaymentItem>("/api/core/payments/"),
    fetchList<InvoiceItem>("/api/core/invoices/"),
  ]);

  return (
    <div className="flex flex-col gap-6">
      <div>
        <h1 className="text-2xl font-semibold">پرداخت‌ها و فاکتورها</h1>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="text-base">فاکتورها</CardTitle>
        </CardHeader>
        <CardContent>
          {invoices.length === 0 ? (
            <p className="text-muted-foreground py-6 text-center text-sm">
              فاکتوری صادر نشده است
            </p>
          ) : (
            <div className="flex flex-col divide-y">
              {invoices.map((inv) => (
                <Link
                  key={inv.id}
                  href={`/dashboard/customer/invoices/${inv.id}`}
                  className="flex items-center justify-between py-3 transition-colors hover:bg-muted/40"
                >
                  <div>
                    <p className="text-sm font-medium">فاکتور {inv.invoice_number}</p>
                    <p className="text-muted-foreground text-xs">{inv.issue_date_jalali}</p>
                  </div>
                  <div className="flex items-center gap-3">
                    <span className="text-sm font-medium">
                      {formatToman(inv.final_amount)}
                    </span>
                    {inv.pdf_file && (
                      <Button size="sm" variant="ghost" asChild>
                        <a
                          href={`/api/download/core/invoices/${inv.id}/pdf/`}
                          target="_blank"
                          rel="noreferrer"
                          onClick={(e) => e.stopPropagation()}
                        >
                          <FileDown className="size-4" />
                        </a>
                      </Button>
                    )}
                    <ChevronLeft className="text-muted-foreground size-4" />
                  </div>
                </Link>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="text-base">تاریخچه پرداخت‌ها</CardTitle>
        </CardHeader>
        <CardContent>
          {payments.length === 0 ? (
            <p className="text-muted-foreground py-6 text-center text-sm">
              <Receipt className="mx-auto mb-2 size-8 opacity-40" />
              پرداختی ثبت نشده است
            </p>
          ) : (
            <div className="flex flex-col divide-y">
              {payments.map((p) => {
                const status = getStatusInfo(PAYMENT_STATUS_MAP, p.status);
                return (
                  <div key={p.id} className="flex items-center justify-between py-3">
                    <span className="text-muted-foreground text-xs">
                      {p.created_at_jalali}
                    </span>
                    <div className="flex items-center gap-3">
                      <span className="text-sm font-medium">{formatToman(p.amount)}</span>
                      <Badge variant={status.variant}>{status.label}</Badge>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}

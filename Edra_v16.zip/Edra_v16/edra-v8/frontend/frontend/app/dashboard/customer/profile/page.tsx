import { ProfileForm } from "@/components/shared/profile-form";

export const metadata = { title: "پروفایل" };

export default function CustomerProfilePage() {
  return (
    <div className="mx-auto flex max-w-2xl flex-col gap-6">
      <div>
        <h1 className="text-2xl font-semibold">پروفایل من</h1>
      </div>
      <ProfileForm
        fetchUrl="/api/proxy/core/customer/profile/"
        fields={[
          { key: "first_name", label: "نام" },
          { key: "last_name", label: "نام خانوادگی" },
          { key: "email", label: "ایمیل", type: "email" },
          { key: "phone", label: "شماره موبایل" },
          { key: "company_name", label: "نام شرکت" },
          { key: "registration_number", label: "شماره ثبت شرکت" },
        ]}
      />
    </div>
  );
}

import { FileCheck2, FileDown } from "lucide-react";
import { apiServerFetch } from "@/lib/api-server";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { toPersianDigits } from "@/lib/jalali";

export const metadata = { title: "گزارش‌های بازرسی" };

interface ReportItem {
  id: number;
  report_number: string;
  overall_result: string;
  pdf_file: string | null;
  created_at_jalali: string;
}

export default async function CustomerReportsPage() {
  const data = await apiServerFetch<{ results: ReportItem[] } | ReportItem[]>(
    "/api/core/customer/reports/"
  );
  const reports = Array.isArray(data) ? data : data.results ?? [];

  return (
    <div className="flex flex-col gap-6">
      <div>
        <h1 className="text-2xl font-semibold">گزارش‌های بازرسی</h1>
        <p className="text-muted-foreground text-sm">
          {toPersianDigits(reports.length)} گزارش صادرشده
        </p>
      </div>

      {reports.length === 0 ? (
        <Card>
          <CardContent className="text-muted-foreground flex flex-col items-center gap-3 py-16 text-center">
            <FileCheck2 className="size-10 opacity-40" />
            هنوز گزارشی برای شما صادر نشده است
          </CardContent>
        </Card>
      ) : (
        <div className="flex flex-col gap-3">
          {reports.map((r) => (
            <Card key={r.id}>
              <CardContent className="flex flex-wrap items-center justify-between gap-3 px-5 py-4">
                <div className="flex items-center gap-3">
                  <Badge variant={r.overall_result === "pass" ? "success" : "destructive"}>
                    {r.overall_result === "pass" ? "موفق" : "مردود"}
                  </Badge>
                  <div>
                    <p className="text-sm font-medium">
                      گزارش {toPersianDigits(r.report_number)}
                    </p>
                    <p className="text-muted-foreground text-xs">{r.created_at_jalali}</p>
                  </div>
                </div>
                {r.pdf_file && (
                  <Button size="sm" variant="outline" asChild>
                    <a
                      href={`/api/download/inspections/inspection-reports/${r.id}/pdf/`}
                      target="_blank"
                      rel="noreferrer"
                    >
                      <FileDown />
                      دانلود PDF
                    </a>
                  </Button>
                )}
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}

import Link from "next/link";
import { notFound } from "next/navigation";
import { MapPin, Calendar, FileDown, MessageSquarePlus, Package } from "lucide-react";

import { apiServerFetch, ApiError } from "@/lib/api-server";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { getStatusInfo, REQUEST_STATUS_MAP } from "@/lib/status-map";
import { formatToman } from "@/lib/format";

export const metadata = { title: "جزئیات درخواست" };

interface RequestDetail {
  id: number;
  request_number: string;
  equipment_type_name: string;
  status: string;
  final_price: number;
  calculated_price: number;
  created_at_jalali: string;
  scheduled_at_jalali: string | null;
  city: string;
  address: string;
  service_type: string;
  brand_model: string;
  params: Record<string, unknown>;
  assigned_expert_name: string | null;
}

interface ReportSummary {
  id: number;
  report_number: string;
  overall_result: string;
  pdf_file: string | null;
}

export default async function CustomerRequestDetailPage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = await params;

  let request: RequestDetail;
  try {
    request = await apiServerFetch<RequestDetail>(
      `/api/core/inspection-requests/${id}/`
    );
  } catch (err) {
    if (err instanceof ApiError && err.status === 404) notFound();
    throw err;
  }

  let report: ReportSummary | null = null;
  try {
    const reports = await apiServerFetch<{ results: ReportSummary[] } | ReportSummary[]>(
      `/api/core/customer/reports/?inspection_request=${id}`
    );
    const list = Array.isArray(reports) ? reports : reports.results ?? [];
    report = list[0] ?? null;
  } catch {
    report = null;
  }

  const status = getStatusInfo(REQUEST_STATUS_MAP, request.status);

  return (
    <div className="flex flex-col gap-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-2xl font-semibold">{request.equipment_type_name}</h1>
            <Badge variant={status.variant}>{status.label}</Badge>
          </div>
          <p className="text-muted-foreground text-sm">
            درخواست {request.request_number}
          </p>
        </div>
        <Button variant="outline" asChild>
          <Link href={`/dashboard/customer/tickets/new?request=${request.id}`}>
            <MessageSquarePlus />
            ثبت تیکت برای این درخواست
          </Link>
        </Button>
      </div>

      <div className="grid gap-4 md:grid-cols-3">
        <Card className="md:col-span-2">
          <CardHeader>
            <CardTitle className="text-base">جزئیات درخواست</CardTitle>
          </CardHeader>
          <CardContent className="grid gap-3 text-sm sm:grid-cols-2">
            <Row icon={Package} label="سطح سرویس">
              {request.service_type === "pro" ? "حرفه‌ای" : "استاندارد"}
            </Row>
            <Row icon={Package} label="برند/مدل">
              {request.brand_model || "—"}
            </Row>
            {request.scheduled_at_jalali && (
              <Row icon={Calendar} label="زمان کارشناسی">
                {request.scheduled_at_jalali}
              </Row>
            )}
            <Row icon={MapPin} label="آدرس">
              {request.city} - {request.address}
            </Row>
            {request.assigned_expert_name && (
              <Row icon={Package} label="کارشناس">
                {request.assigned_expert_name}
              </Row>
            )}
            {Object.keys(request.params || {}).length > 0 && (
              <div className="sm:col-span-2">
                <p className="text-muted-foreground mb-1.5 text-xs">مشخصات فنی</p>
                <div className="flex flex-wrap gap-1.5">
                  {Object.entries(request.params).map(([k, v]) => (
                    <Badge key={k} variant="outline">
                      {k}: {String(v)}
                    </Badge>
                  ))}
                </div>
              </div>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-base">مالی</CardTitle>
          </CardHeader>
          <CardContent className="flex flex-col gap-2 text-sm">
            <div className="flex justify-between">
              <span className="text-muted-foreground">مبلغ نهایی</span>
              <span className="font-medium">{formatToman(request.final_price)}</span>
            </div>
          </CardContent>
        </Card>
      </div>

      {report && (
        <Card>
          <CardHeader>
            <CardTitle className="text-base">گزارش بازرسی</CardTitle>
          </CardHeader>
          <CardContent className="flex flex-wrap items-center justify-between gap-3">
            <div className="flex items-center gap-3">
              <Badge variant={report.overall_result === "pass" ? "success" : "destructive"}>
                {report.overall_result === "pass" ? "موفق" : "مردود"}
              </Badge>
              <span className="text-sm">گزارش {report.report_number}</span>
            </div>
            {report.pdf_file && (
              <Button size="sm" asChild>
                <a
                  href={`/api/download/inspections/inspection-reports/${report.id}/pdf/`}
                  target="_blank"
                  rel="noreferrer"
                >
                  <FileDown />
                  دانلود PDF
                </a>
              </Button>
            )}
          </CardContent>
        </Card>
      )}
    </div>
  );
}

function Row({
  icon: Icon,
  label,
  children,
}: {
  icon: typeof MapPin;
  label: string;
  children: React.ReactNode;
}) {
  return (
    <div className="flex items-start gap-2">
      <Icon className="text-muted-foreground mt-0.5 size-4 shrink-0" />
      <div>
        <span className="text-muted-foreground">{label}: </span>
        <span className="font-medium">{children}</span>
      </div>
    </div>
  );
}

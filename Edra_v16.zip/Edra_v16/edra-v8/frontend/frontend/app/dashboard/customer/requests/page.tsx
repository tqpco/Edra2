import Link from "next/link";
import { ClipboardList, PlusCircle } from "lucide-react";

import { apiServerFetch } from "@/lib/api-server";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { getStatusInfo, REQUEST_STATUS_MAP } from "@/lib/status-map";
import { formatToman } from "@/lib/format";
import { toPersianDigits } from "@/lib/jalali";

export const metadata = { title: "درخواست‌های من" };

interface RequestListItem {
  id: number;
  request_number: string;
  equipment_type_name: string;
  status: string;
  final_price: number;
  created_at_jalali: string;
  city: string;
}

interface RequestListResponse {
  results: RequestListItem[];
  count: number;
}

export default async function CustomerRequestsPage() {
  const data = await apiServerFetch<RequestListResponse>(
    "/api/core/inspection-requests/"
  );
  const requests = data.results ?? [];

  return (
    <div className="flex flex-col gap-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="text-2xl font-semibold">درخواست‌های من</h1>
          <p className="text-muted-foreground text-sm">
            {toPersianDigits(data.count ?? requests.length)} درخواست ثبت‌شده
          </p>
        </div>
        <Button asChild>
          <Link href="/booking">
            <PlusCircle />
            رزرو جدید
          </Link>
        </Button>
      </div>

      {requests.length === 0 ? (
        <Card>
          <CardContent className="text-muted-foreground flex flex-col items-center gap-3 py-16 text-center">
            <ClipboardList className="size-10 opacity-40" />
            هنوز درخواستی ثبت نکرده‌اید
            <Button size="sm" asChild>
              <Link href="/booking">شروع اولین رزرو</Link>
            </Button>
          </CardContent>
        </Card>
      ) : (
        <div className="flex flex-col gap-3">
          {requests.map((r) => {
            const status = getStatusInfo(REQUEST_STATUS_MAP, r.status);
            return (
              <Link key={r.id} href={`/dashboard/customer/requests/${r.id}`}>
                <Card className="transition-shadow hover:shadow-md">
                  <CardContent className="flex flex-wrap items-center justify-between gap-3 px-5 py-4">
                    <div>
                      <p className="text-sm font-medium">
                        {r.equipment_type_name} ·{" "}
                        {toPersianDigits(r.request_number)}
                      </p>
                      <p className="text-muted-foreground text-xs">
                        {r.city} · {r.created_at_jalali}
                      </p>
                    </div>
                    <div className="flex items-center gap-3">
                      <span className="text-sm font-medium">
                        {formatToman(r.final_price)}
                      </span>
                      <Badge variant={status.variant}>{status.label}</Badge>
                    </div>
                  </CardContent>
                </Card>
              </Link>
            );
          })}
        </div>
      )}
    </div>
  );
}

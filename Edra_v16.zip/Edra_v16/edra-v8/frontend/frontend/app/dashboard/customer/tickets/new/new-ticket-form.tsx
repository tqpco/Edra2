"use client";

import * as React from "react";
import { useRouter } from "next/navigation";
import { useQuery } from "@tanstack/react-query";
import { Loader2, Send } from "lucide-react";

import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { Alert, AlertDescription } from "@/components/ui/alert";
import {
  Select,
  SelectTrigger,
  SelectValue,
  SelectContent,
  SelectItem,
} from "@/components/ui/select";
import type { TicketCategory, TicketPriority } from "@/types/ticket";

async function fetchOptions<T>(path: string): Promise<T[]> {
  const res = await fetch(path);
  const data = await res.json();
  return data.results ?? data;
}

export function NewTicketForm({ relatedRequestId }: { relatedRequestId?: string }) {
  const router = useRouter();
  const [title, setTitle] = React.useState(
    relatedRequestId ? `درباره درخواست شماره ${relatedRequestId}` : ""
  );
  const [description, setDescription] = React.useState("");
  const [categoryId, setCategoryId] = React.useState<string>("");
  const [priorityId, setPriorityId] = React.useState<string>("");
  const [submitting, setSubmitting] = React.useState(false);
  const [error, setError] = React.useState<string | null>(null);

  const { data: categories } = useQuery({
    queryKey: ["ticket-categories"],
    queryFn: () => fetchOptions<TicketCategory>("/api/proxy/support/categories/"),
  });
  const { data: priorities } = useQuery({
    queryKey: ["ticket-priorities"],
    queryFn: () => fetchOptions<TicketPriority>("/api/proxy/support/priorities/"),
  });

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    if (title.trim().length < 3 || description.trim().length < 5) {
      setError("عنوان و توضیحات را کامل‌تر وارد کنید.");
      return;
    }
    setSubmitting(true);
    try {
      const res = await fetch("/api/proxy/support/tickets/", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          title,
          description,
          category: categoryId || undefined,
          priority: priorityId || undefined,
        }),
      });
      const data = await res.json();
      if (!res.ok) {
        setError(data.detail || data.title?.[0] || "ثبت تیکت ناموفق بود.");
        return;
      }
      router.push(`/dashboard/customer/tickets/${data.id}`);
      router.refresh();
    } catch {
      setError("ارتباط با سرور برقرار نشد.");
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <Card>
      <CardContent className="px-6 py-6">
        <form onSubmit={handleSubmit} className="grid gap-4">
          {error && (
            <Alert variant="destructive">
              <AlertDescription>{error}</AlertDescription>
            </Alert>
          )}
          <div className="grid gap-2">
            <Label htmlFor="title">عنوان</Label>
            <Input id="title" value={title} onChange={(e) => setTitle(e.target.value)} />
          </div>

          {(!!categories?.length || !!priorities?.length) && (
            <div className="grid grid-cols-2 gap-4">
              {!!categories?.length && (
                <div className="grid gap-2">
                  <Label>دسته‌بندی (اختیاری)</Label>
                  <Select value={categoryId} onValueChange={setCategoryId}>
                    <SelectTrigger className="w-full">
                      <SelectValue placeholder="انتخاب کنید" />
                    </SelectTrigger>
                    <SelectContent>
                      {categories.map((c) => (
                        <SelectItem key={c.id} value={String(c.id)}>
                          {c.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              )}
              {!!priorities?.length && (
                <div className="grid gap-2">
                  <Label>اولویت (اختیاری)</Label>
                  <Select value={priorityId} onValueChange={setPriorityId}>
                    <SelectTrigger className="w-full">
                      <SelectValue placeholder="انتخاب کنید" />
                    </SelectTrigger>
                    <SelectContent>
                      {priorities.map((p) => (
                        <SelectItem key={p.id} value={String(p.id)}>
                          {p.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              )}
            </div>
          )}

          <div className="grid gap-2">
            <Label htmlFor="description">توضیحات</Label>
            <Textarea
              id="description"
              rows={6}
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="مشکل یا سوال خود را با جزئیات شرح دهید..."
            />
          </div>

          <Button type="submit" disabled={submitting} className="w-fit">
            {submitting && <Loader2 className="animate-spin" />}
            ثبت تیکت
            {!submitting && <Send />}
          </Button>
        </form>
      </CardContent>
    </Card>
  );
}

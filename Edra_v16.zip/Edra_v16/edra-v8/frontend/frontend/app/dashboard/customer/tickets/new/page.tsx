import { NewTicketForm } from "./new-ticket-form";

export const metadata = { title: "ثبت تیکت جدید" };

export default async function NewTicketPage({
  searchParams,
}: {
  searchParams: Promise<{ request?: string }>;
}) {
  const { request } = await searchParams;

  return (
    <div className="mx-auto flex max-w-xl flex-col gap-6">
      <div>
        <h1 className="text-2xl font-semibold">ثبت تیکت جدید</h1>
        <p className="text-muted-foreground text-sm">
          سوال یا مشکل خود را برای تیم پشتیبانی شرح دهید
        </p>
      </div>
      <NewTicketForm relatedRequestId={request} />
    </div>
  );
}

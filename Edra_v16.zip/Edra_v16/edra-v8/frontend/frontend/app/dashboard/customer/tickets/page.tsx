import Link from "next/link";
import { MessagesSquare, Plus } from "lucide-react";

import { apiServerFetch } from "@/lib/api-server";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import type { TicketListItem } from "@/types/ticket";

export const metadata = { title: "تیکت‌های پشتیبانی" };

export default async function CustomerTicketsPage() {
  const data = await apiServerFetch<{ results: TicketListItem[] }>(
    "/api/support/tickets/"
  );
  const tickets = data.results ?? [];

  return (
    <div className="flex flex-col gap-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="text-2xl font-semibold">تیکت‌های پشتیبانی</h1>
          <p className="text-muted-foreground text-sm">
            سوالات و درخواست‌های خود را از اینجا پیگیری کنید
          </p>
        </div>
        <Button asChild>
          <Link href="/dashboard/customer/tickets/new">
            <Plus />
            تیکت جدید
          </Link>
        </Button>
      </div>

      {tickets.length === 0 ? (
        <Card>
          <CardContent className="text-muted-foreground flex flex-col items-center gap-3 py-16 text-center">
            <MessagesSquare className="size-10 opacity-40" />
            هنوز تیکتی ثبت نکرده‌اید
            <Button size="sm" asChild>
              <Link href="/dashboard/customer/tickets/new">ثبت تیکت جدید</Link>
            </Button>
          </CardContent>
        </Card>
      ) : (
        <div className="flex flex-col gap-3">
          {tickets.map((t) => (
            <Link key={t.id} href={`/dashboard/customer/tickets/${t.id}`}>
              <Card className="transition-shadow hover:shadow-md">
                <CardContent className="flex flex-wrap items-center justify-between gap-3 px-5 py-4">
                  <div>
                    <p className="text-sm font-medium">{t.title}</p>
                    <p className="text-muted-foreground text-xs">
                      {t.updated_at_jalali} · {t.comments_count} پاسخ
                    </p>
                  </div>
                  <Badge variant="outline">{t.status_name}</Badge>
                </CardContent>
              </Card>
            </Link>
          ))}
        </div>
      )}
    </div>
  );
}

import { CalendarDays, MapPin, Wrench } from "lucide-react";
import { apiServerFetch } from "@/lib/api-server";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { getStatusInfo, REQUEST_STATUS_MAP } from "@/lib/status-map";
import {
  dateToJalali,
  formatJalali,
  JALALI_MONTH_NAMES,
  jalaliMonthLength,
} from "@/lib/jalali";

export const metadata = { title: "تقویم برنامه بازرسی" };

interface RequestItem {
  id: number;
  request_number?: string;
  equipment_type_name?: string;
  customer_name?: string;
  city?: string;
  address?: string;
  status: string;
  scheduled_at?: string | null;
  scheduled_at_jalali?: string | null;
}

async function fetchRequests(): Promise<RequestItem[]> {
  try {
    const data = await apiServerFetch<{ results: RequestItem[] } | RequestItem[]>(
      "/api/core/inspection-requests/?ordering=scheduled_at"
    );
    return Array.isArray(data) ? data : data.results ?? [];
  } catch {
    return [];
  }
}

const SCHEDULED_STATUSES = new Set([
  "scheduled",
  "rescheduled",
  "assigned",
  "in_progress",
  "paid",
]);

export default async function ExpertCalendarPage() {
  const requests = await fetchRequests();
  const now = new Date();
  const { year: jy, month: jm, day: jd } = dateToJalali(now);
  const monthDays = jalaliMonthLength(jy, jm);

  const scheduled = requests.filter(
    (r) => SCHEDULED_STATUSES.has(r.status) && r.scheduled_at
  );
  const daysWithRequests = new Map<number, RequestItem[]>();
  for (const r of scheduled) {
    try {
      const d = new Date(r.scheduled_at!);
      const j = dateToJalali(d);
      if (j.year === jy && j.month === jm) {
        const list = daysWithRequests.get(j.day) ?? [];
        list.push(r);
        daysWithRequests.set(j.day, list);
      }
    } catch {
      // تاریخ نامعتبر - رد می‌شود
    }
  }

  const grouped = scheduled.reduce<Record<string, RequestItem[]>>((acc, r) => {
    const key = r.scheduled_at_jalali?.slice(0, 10) ?? "نامشخص";
    (acc[key] ||= []).push(r);
    return acc;
  }, {});

  return (
    <div className="flex flex-col gap-6">
      <div>
        <h1 className="text-2xl font-semibold">تقویم برنامه بازرسی</h1>
        <p className="text-muted-foreground text-sm">
          {formatJalali(now)} — بازرسی‌های زمان‌بندی‌شده شما
        </p>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-base">
            <CalendarDays className="size-5" />
            {JALALI_MONTH_NAMES[jm - 1]} {toFa(jy)}
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-7 gap-1 text-center">
            {["ش", "ی", "د", "س", "چ", "پ", "ج"].map((d, i) => (
              <div key={i} className="text-muted-foreground py-1 text-xs font-medium">
                {d}
              </div>
            ))}
            {Array.from({ length: monthDays }, (_, i) => i + 1).map((day) => {
              const items = daysWithRequests.get(day) ?? [];
              const isToday = day === jd;
              const hasItems = items.length > 0;
              return (
                <div
                  key={day}
                  className={`relative flex min-h-16 flex-col items-center justify-start gap-1 rounded-lg border p-1 ${
                    isToday ? "border-primary bg-primary/5" : "border-border/60"
                  }`}
                >
                  <span
                    className={`text-xs ${isToday ? "text-primary font-bold" : "text-muted-foreground"}`}
                  >
                    {toFa(day)}
                  </span>
                  {hasItems && (
                    <span className="flex flex-col gap-0.5">
                      {items.slice(0, 2).map((r) => (
                        <span key={r.id} className="bg-primary/10 text-primary rounded px-1 py-0.5 text-[9px]">
                          #{r.id}
                        </span>
                      ))}
                      {items.length > 2 && (
                        <span className="text-muted-foreground text-[9px]">
                          +{toFa(items.length - 2)}
                        </span>
                      )}
                    </span>
                  )}
                </div>
              );
            })}
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="text-base">بازرسی‌های زمان‌بندی‌شده</CardTitle>
        </CardHeader>
        <CardContent className="px-0 py-2">
          {Object.keys(grouped).length === 0 ? (
            <p className="text-muted-foreground py-10 text-center text-sm">
              بازرسی زمان‌بندی‌شده‌ای ندارید
            </p>
          ) : (
            <div className="flex flex-col divide-y">
              {Object.entries(grouped).sort().map(([date, items]) => (
                <div key={date} className="px-5 py-3">
                  <p className="text-muted-foreground mb-2 text-xs font-medium">{date}</p>
                  <div className="flex flex-col gap-2">
                    {items.map((r) => {
                      const status = getStatusInfo(REQUEST_STATUS_MAP, r.status);
                      return (
                        <div
                          key={r.id}
                          className="flex flex-wrap items-center justify-between gap-2 rounded-lg border p-3"
                        >
                          <div className="min-w-0">
                            <div className="flex items-center gap-2">
                              <span className="text-sm font-semibold">درخواست #{r.id}</span>
                              <Badge variant={status.variant}>{status.label}</Badge>
                            </div>
                            <p className="text-muted-foreground mt-1 flex items-center gap-1 text-xs">
                              <Wrench className="size-3" />
                              {r.equipment_type_name ?? "—"} • {r.customer_name ?? ""}
                            </p>
                            <p className="text-muted-foreground mt-0.5 flex items-center gap-1 text-xs">
                              <MapPin className="size-3" />
                              {r.city ?? ""} — {r.address ?? ""}
                            </p>
                          </div>
                          <span className="text-muted-foreground shrink-0 text-xs">
                            {r.scheduled_at_jalali ?? ""}
                          </span>
                        </div>
                      );
                    })}
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}

function toFa(n: number): string {
  return new Intl.NumberFormat("fa-IR").format(n);
}

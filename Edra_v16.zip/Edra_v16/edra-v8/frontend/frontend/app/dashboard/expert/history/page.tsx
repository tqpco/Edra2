import { History } from "lucide-react";
import { apiServerFetch } from "@/lib/api-server";
import { ExpertTaskCard } from "@/components/shared/expert-task-card";
import type { ExpertTask } from "@/types/dashboard";
import { toPersianDigits } from "@/lib/jalali";

export const metadata = { title: "تاریخچه گزارش‌ها" };

interface HistoryResponse {
  history: {
    id: number;
    request_number: string;
    equipment_name: string;
    status: string;
    city: string;
    address: string;
  }[];
  total: number;
}

export default async function ExpertHistoryPage() {
  const data = await apiServerFetch<HistoryResponse>(
    "/api/expert/history/?limit=50"
  );

  const tasks: ExpertTask[] = data.history.map((t) => ({
    id: t.id,
    request_number: t.request_number,
    equipment: t.equipment_name,
    status: t.status,
    scheduled_at_jalali: null,
    address: t.address,
    city: t.city,
  }));

  return (
    <div className="flex flex-col gap-6">
      <div>
        <h1 className="text-2xl font-semibold">تاریخچه گزارش‌ها</h1>
        <p className="text-muted-foreground text-sm">
          {toPersianDigits(data.total)} بازرسی تکمیل‌شده
        </p>
      </div>

      {tasks.length === 0 ? (
        <div className="text-muted-foreground flex flex-col items-center gap-3 rounded-xl border border-dashed py-16 text-center">
          <History className="size-10 opacity-40" />
          هنوز بازرسی تکمیل‌شده‌ای ندارید
        </div>
      ) : (
        <div className="flex flex-col gap-3">
          {tasks.map((task) => (
            <ExpertTaskCard key={task.id} task={task} />
          ))}
        </div>
      )}
    </div>
  );
}

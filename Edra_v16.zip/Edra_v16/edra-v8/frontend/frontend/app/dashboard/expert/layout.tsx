import { requireRole } from "@/lib/require-role";
import { DashboardSidebar } from "@/components/layout/dashboard-sidebar";
import { DashboardTopbar } from "@/components/layout/dashboard-topbar";
import { EXPERT_NAV } from "@/lib/nav-config";

export default async function ExpertDashboardLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  // ادمین هم به پنل کارشناسی دسترسی دارد (طبق درخواست: صفحه ورود مشترک)
  await requireRole(["expert", "admin"], "/login");

  return (
    <div className="flex min-h-svh">
      <DashboardSidebar sections={EXPERT_NAV} />
      <div className="flex min-w-0 flex-1 flex-col">
        <DashboardTopbar sections={EXPERT_NAV} profileHref="/dashboard/expert/profile" />
        <main className="flex-1 p-4 md:p-6">{children}</main>
      </div>
    </div>
  );
}

import { ClipboardList, Hourglass, FileCheck, CalendarCheck } from "lucide-react";

import { apiServerFetch } from "@/lib/api-server";
import type { ExpertDashboardData } from "@/types/dashboard";
import { StatCard } from "@/components/shared/stat-card";
import { ExpertTaskCard } from "@/components/shared/expert-task-card";

export const metadata = { title: "داشبورد کارشناس" };

export default async function ExpertDashboardPage() {
  const data = await apiServerFetch<ExpertDashboardData>(
    "/api/core/expert/dashboard/"
  );

  return (
    <div className="flex flex-col gap-6">
      <div>
        <h1 className="text-2xl font-semibold">سلام {data.user.full_name} 👋</h1>
        <p className="text-muted-foreground text-sm">
          برنامه‌ی کاری امروز و وظایف پیش‌رو
        </p>
      </div>

      <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
        <StatCard title="کل ارجاع‌شده" value={data.total_assigned} icon={ClipboardList} />
        <StatCard
          title="در حال انجام"
          value={data.pending_inspections}
          icon={Hourglass}
          tone="primary"
        />
        <StatCard
          title="گزارش تکمیل‌شده"
          value={data.completed_reports}
          icon={FileCheck}
          tone="success"
        />
        <StatCard
          title="وظایف امروز"
          value={data.todays_tasks.length}
          icon={CalendarCheck}
          tone="warning"
        />
      </div>

      <div className="flex flex-col gap-3">
        <h2 className="text-lg font-semibold">وظایف امروز</h2>
        {data.todays_tasks.length === 0 ? (
          <p className="text-muted-foreground rounded-lg border border-dashed py-8 text-center text-sm">
            برای امروز وظیفه‌ای برنامه‌ریزی نشده است
          </p>
        ) : (
          <div className="flex flex-col gap-3">
            {data.todays_tasks.map((task) => (
              <ExpertTaskCard key={task.id} task={task} />
            ))}
          </div>
        )}
      </div>

      {data.upcoming_tasks.length > 0 && (
        <div className="flex flex-col gap-3">
          <h2 className="text-lg font-semibold">وظایف پیش‌رو</h2>
          <div className="flex flex-col gap-3">
            {data.upcoming_tasks.map((task) => (
              <ExpertTaskCard key={task.id} task={task} />
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

import { ProfileForm, ChangePasswordCard } from "@/components/shared/profile-form";

export const metadata = { title: "پروفایل" };

export default function ExpertProfilePage() {
  return (
    <div className="mx-auto flex max-w-2xl flex-col gap-6">
      <div>
        <h1 className="text-2xl font-semibold">پروفایل من</h1>
      </div>
      <ProfileForm
        fetchUrl="/api/proxy/expert/profile/"
        fields={[
          { key: "first_name", label: "نام" },
          { key: "last_name", label: "نام خانوادگی" },
          { key: "email", label: "ایمیل", type: "email" },
          { key: "phone", label: "شماره موبایل" },
          { key: "expertise", label: "حوزه تخصص" },
          { key: "years_experience", label: "سابقه کار (سال)", type: "number" },
          { key: "bio", label: "بیوگرافی", type: "textarea" },
        ]}
      />
      <ChangePasswordCard endpoint="/api/proxy/expert/profile/change-password/" />
    </div>
  );
}

import type { Metadata, Viewport } from "next";
import { Providers } from "@/components/providers";
import "./globals.css";

export const metadata: Metadata = {
  title: {
    default: "ادرو | بازرسی و صدور گواهی تجهیزات صنعتی",
    template: "%s | ادرو",
  },
  description:
    "رزرو آنلاین بازرسی تخصصی تجهیزات سنگین صنعتی - جرثقیل برجی، جرثقیل سیار، لیفتراک و بیشتر. زمان‌بندی سریع، گزارش استاندارد، پیگیری کامل.",
  metadataBase: new URL(process.env.NEXT_PUBLIC_SITE_URL || "http://localhost:3000"),
};

export const viewport: Viewport = {
  width: "device-width",
  initialScale: 1,
  themeColor: "#ffffff",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="fa" dir="rtl" suppressHydrationWarning>
      <body className="antialiased">
        <Providers>{children}</Providers>
      </body>
    </html>
  );
}

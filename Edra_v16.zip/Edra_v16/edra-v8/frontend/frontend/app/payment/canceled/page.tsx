import Link from "next/link";
import { CircleSlash } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";

export const metadata = { title: "انصراف از پرداخت" };

export default function PaymentCanceledPage() {
  return (
    <div className="bg-muted/30 flex min-h-svh items-center justify-center p-4">
      <Card className="w-full max-w-md">
        <CardContent className="flex flex-col items-center gap-4 py-10 text-center">
          <span className="bg-muted flex size-16 items-center justify-center rounded-full">
            <CircleSlash className="text-muted-foreground size-9" />
          </span>
          <div>
            <h1 className="text-xl font-semibold">از پرداخت انصراف دادید</h1>
            <p className="text-muted-foreground mt-1 text-sm">
              درخواست شما همچنان ثبت است و می‌توانید هر زمان پرداخت را تکمیل
              کنید.
            </p>
          </div>
          <Button asChild className="mt-2 w-full">
            <Link href="/dashboard/customer/requests">مشاهده درخواست‌ها</Link>
          </Button>
        </CardContent>
      </Card>
    </div>
  );
}

import Link from "next/link";
import { CheckCircle2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { toPersianDigits } from "@/lib/jalali";

export const metadata = { title: "پرداخت موفق" };

export default async function PaymentSuccessPage({
  searchParams,
}: {
  searchParams: Promise<{ ref_id?: string }>;
}) {
  const { ref_id } = await searchParams;

  return (
    <div className="bg-muted/30 flex min-h-svh items-center justify-center p-4">
      <Card className="w-full max-w-md">
        <CardContent className="flex flex-col items-center gap-4 py-10 text-center">
          <span className="bg-success/10 flex size-16 items-center justify-center rounded-full">
            <CheckCircle2 className="text-success size-9" />
          </span>
          <div>
            <h1 className="text-xl font-semibold">پرداخت با موفقیت انجام شد</h1>
            <p className="text-muted-foreground mt-1 text-sm">
              فاکتور شما به‌زودی صادر و برایتان پیامک می‌شود.
            </p>
            {ref_id && (
              <p className="text-muted-foreground ltr-numerals mt-2 text-xs">
                کد پیگیری: {toPersianDigits(ref_id)}
              </p>
            )}
          </div>
          <div className="mt-2 flex w-full gap-2">
            <Button asChild className="flex-1">
              <Link href="/dashboard/customer/requests">مشاهده درخواست‌ها</Link>
            </Button>
            <Button asChild variant="outline" className="flex-1">
              <Link href="/dashboard/customer">داشبورد</Link>
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

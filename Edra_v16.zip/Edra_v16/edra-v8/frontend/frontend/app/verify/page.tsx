"use client";

import { useState } from "react";
import Link from "next/link";
import { Search, ShieldCheck, BadgeCheck, XCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { apiClientFetch } from "@/lib/api-client";
import { formatJalaliNumeric } from "@/lib/jalali";

interface VerificationData {
  verification_code: string;
  report_number: string;
  inspection_request_id: number;
  equipment_name: string;
  overall_result: string;
  signed_at: string | null;
  view_count: number;
  created_at_jalali: string | null;
  last_viewed_at_jalali: string | null;
}

const RESULT_MAP: Record<string, { label: string; variant: "success" | "destructive" | "outline" }> = {
  pass: { label: "قابل قبول", variant: "success" },
  fail: { label: "غیرقابل قبول", variant: "destructive" },
  na: { label: "قابل اعمال نیست", variant: "outline" },
};

export default function VerifyPage() {
  const [code, setCode] = useState("");
  const [data, setData] = useState<VerificationData | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const verify = async () => {
    const trimmed = code.trim();
    if (!trimmed) {
      setError("لطفاً کد استعلام را وارد کنید.");
      return;
    }
    setLoading(true);
    setError(null);
    setData(null);
    try {
      const result = await apiClientFetch<VerificationData>(
        `/api/inspections/report-verification/${encodeURIComponent(trimmed)}/`
      );
      setData(result);
    } catch (e) {
      setError(
        e instanceof Error && e.message.includes("404")
          ? "کد استعلام معتبر نیست یا گزارش یافت نشد."
          : "خطا در بررسی کد. لطفاً دوباره تلاش کنید."
      );
    } finally {
      setLoading(false);
    }
  };

  const resultInfo = data ? RESULT_MAP[data.overall_result] ?? { label: data.overall_result, variant: "outline" as const } : null;

  return (
    <div className="bg-muted/30 flex min-h-svh items-center justify-center px-4 py-10">
      <div className="w-full max-w-xl">
        <div className="mb-8 text-center">
          <div className="bg-primary/10 text-primary mx-auto mb-4 flex size-14 items-center justify-center rounded-2xl">
            <ShieldCheck className="size-7" />
          </div>
          <h1 className="text-2xl font-bold">استعلام اصالت گزارش بازرسی</h1>
          <p className="text-muted-foreground mt-2 text-sm">
            کد ۱۲ رقمی درج‌شده روی گزارش را وارد کنید تا از اصالت و اعتبار آن مطمئن شوید.
          </p>
        </div>

        <Card>
          <CardContent className="flex gap-2 px-5 py-5">
            <Input
              value={code}
              onChange={(e) => setCode(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && verify()}
              placeholder="کد استعلام، مانند: AB12CD34EF56"
              className="text-center font-mono"
              dir="ltr"
              maxLength={50}
            />
            <Button onClick={verify} disabled={loading}>
              <Search className="size-4" />
              {loading ? "در حال بررسی..." : "استعلام"}
            </Button>
          </CardContent>
        </Card>

        {error && (
          <Card className="mt-4 border-destructive/40">
            <CardContent className="flex items-center gap-3 px-5 py-4 text-destructive">
              <XCircle className="size-5 shrink-0" />
              <span className="text-sm">{error}</span>
            </CardContent>
          </Card>
        )}

        {data && resultInfo && (
          <Card className="mt-4">
            <CardHeader className="flex flex-row items-center justify-between">
              <CardTitle className="flex items-center gap-2 text-base">
                <BadgeCheck className="text-success size-5" />
                گزارش معتبر
              </CardTitle>
              <Badge variant={resultInfo.variant}>{resultInfo.label}</Badge>
            </CardHeader>
            <CardContent className="grid gap-3 text-sm">
              <Row label="شماره گزارش" value={data.report_number} mono />
              <Row label="نوع تجهیز" value={data.equipment_name} />
              <Row label="شماره درخواست" value={`#${data.inspection_request_id}`} />
              <Row label="تاریخ صدور گزارش" value={data.created_at_jalali ?? "—"} />
              <Row
                label="تاریخ امضا"
                value={
                  data.signed_at
                    ? formatJalaliNumeric(new Date(data.signed_at))
                    : "—"
                }
              />
              <Row label="تعداد بازدید این کد" value={`${data.view_count} بار`} />
              {data.last_viewed_at_jalali && (
                <Row label="آخرین استعلام" value={data.last_viewed_at_jalali} />
              )}
            </CardContent>
          </Card>
        )}

        <div className="mt-8 text-center text-sm">
          <Link href="/" className="text-primary hover:underline">
            بازگشت به صفحه اصلی
          </Link>
        </div>
      </div>
    </div>
  );
}

function Row({ label, value, mono }: { label: string; value: string; mono?: boolean }) {
  return (
    <div className="flex items-center justify-between gap-3">
      <span className="text-muted-foreground">{label}</span>
      <span className={`font-medium ${mono ? "font-mono" : ""}`}>{value}</span>
    </div>
  );
}

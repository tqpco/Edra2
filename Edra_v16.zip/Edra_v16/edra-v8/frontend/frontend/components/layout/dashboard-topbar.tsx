"use client";

import Link from "next/link";
import { LogOut, User as UserIcon, Settings } from "lucide-react";

import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuTrigger,
  DropdownMenuSeparator,
  DropdownMenuLabel,
  DropdownMenuItem,
} from "@/components/ui/dropdown-menu";
import { DashboardMobileNav } from "./dashboard-sidebar";
import { NotificationBell } from "@/components/shared/notification-bell";
import { useAuth } from "@/hooks/use-auth";
import type { NavSection } from "@/lib/nav-config";

function initials(name: string) {
  const parts = name.trim().split(/\s+/);
  if (parts.length === 1) return parts[0]!.slice(0, 2);
  return (parts[0]![0] || "") + (parts[1]![0] || "");
}

export function DashboardTopbar({
  sections,
  profileHref,
}: {
  sections: NavSection[];
  profileHref: string;
}) {
  const { user, logout } = useAuth();
  const displayName = user?.full_name || user?.username || "";

  return (
    <header className="bg-background/95 sticky top-0 z-30 flex h-14 items-center justify-between border-b px-4 backdrop-blur">
      <DashboardMobileNav sections={sections} />
      <div className="flex flex-1 items-center justify-end gap-1">
        <NotificationBell />
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <button className="flex items-center gap-2 rounded-full p-1 pl-2 hover:bg-accent">
              <span className="hidden text-sm font-medium sm:inline">
                {displayName}
              </span>
              <Avatar>
                <AvatarFallback className="bg-primary/10 text-primary">
                  {initials(displayName || "کاربر")}
                </AvatarFallback>
              </Avatar>
            </button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end" className="w-56">
            <DropdownMenuLabel>{displayName}</DropdownMenuLabel>
            <DropdownMenuSeparator />
            <DropdownMenuItem asChild>
              <Link href={profileHref}>
                <UserIcon />
                پروفایل
              </Link>
            </DropdownMenuItem>
            <DropdownMenuItem asChild>
              <Link href={`${profileHref}#settings`}>
                <Settings />
                تنظیمات
              </Link>
            </DropdownMenuItem>
            <DropdownMenuSeparator />
            <DropdownMenuItem variant="destructive" onClick={() => logout()}>
              <LogOut />
              خروج
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </div>
    </header>
  );
}

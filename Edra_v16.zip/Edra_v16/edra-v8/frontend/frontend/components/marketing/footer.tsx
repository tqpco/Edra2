import Link from "next/link";
import { ShieldCheck, Phone, Mail, MapPin } from "lucide-react";

const EQUIPMENT_LINKS = [
  "جرثقیل برجی",
  "جرثقیل سیار",
  "لیفتراک",
  "بالابر",
  "جرثقیل سقفی",
];

export function MarketingFooter() {
  return (
    <footer className="bg-foreground text-background/80 mt-20">
      <div className="mx-auto grid max-w-6xl gap-10 px-4 py-14 sm:grid-cols-2 lg:grid-cols-4">
        <div>
          <Link href="/" className="text-background flex items-center gap-2 font-bold">
            <span className="bg-primary flex size-8 items-center justify-center rounded-md">
              <ShieldCheck className="size-4" />
            </span>
            ادرو
          </Link>
          <p className="mt-4 text-sm leading-relaxed">
            بازرسی و صدور گواهی تخصصی تجهیزات سنگین صنعتی برای کسب‌وکارهای
            ایرانی - سریع، استاندارد، قابل‌اعتماد.
          </p>
        </div>

        <div>
          <h3 className="text-background mb-3 text-sm font-semibold">تجهیزات</h3>
          <ul className="flex flex-col gap-2 text-sm">
            {EQUIPMENT_LINKS.map((e) => (
              <li key={e}>{e}</li>
            ))}
          </ul>
        </div>

        <div>
          <h3 className="text-background mb-3 text-sm font-semibold">شرکت</h3>
          <ul className="flex flex-col gap-2 text-sm">
            <li><Link href="/about" className="hover:text-background">درباره ما</Link></li>
            <li><Link href="/projects" className="hover:text-background">پروژه‌های ما</Link></li>
            <li><Link href="/blog" className="hover:text-background">وبلاگ</Link></li>
            <li><Link href="/faq" className="hover:text-background">سوالات متداول</Link></li>
            <li><Link href="/verify" className="hover:text-background">استعلام گزارش</Link></li>
            <li><Link href="/contact" className="hover:text-background">تماس با ما</Link></li>
            <li><Link href="/booking" className="hover:text-background">رزرو بازرسی</Link></li>
          </ul>
        </div>

        <div>
          <h3 className="text-background mb-3 text-sm font-semibold">ارتباط با ما</h3>
          <ul className="flex flex-col gap-2.5 text-sm">
            <li className="flex items-center gap-2">
              <Phone className="size-3.5" />
              <span dir="ltr">021-XXXXXXXX</span>
            </li>
            <li className="flex items-center gap-2">
              <Mail className="size-3.5" />
              info@edra-inspect.ir
            </li>
            <li className="flex items-center gap-2">
              <MapPin className="size-3.5" />
              تهران، ایران
            </li>
          </ul>
        </div>
      </div>
      <div className="border-background/10 border-t px-4 py-5 text-center text-xs">
        © {new Date().getFullYear()} ادرو - تمامی حقوق محفوظ است
      </div>
    </footer>
  );
}

const STATS = [
  { value: "۷+", label: "نوع تجهیز تحت پوشش" },
  { value: "۴۸", label: "ساعت زمان پاسخ‌گویی" },
  { value: "۱۰۰٪", label: "گزارش دیجیتال و قابل‌پیگیری" },
  { value: "۸-۱۶", label: "بازه زمانی رزرو روزانه" },
];

export function TrustStats() {
  return (
    <div className="grid grid-cols-2 gap-6 sm:grid-cols-4">
      {STATS.map((s) => (
        <div key={s.label} className="text-center">
          <p className="text-primary text-3xl font-bold">{s.value}</p>
          <p className="text-muted-foreground mt-1 text-xs">{s.label}</p>
        </div>
      ))}
    </div>
  );
}

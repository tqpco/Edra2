"use client";

import * as React from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { UserCog, MapPin, Wrench, Loader2, CheckCircle2 } from "lucide-react";
import { toast } from "sonner";

import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";
import { toPersianDigits } from "@/lib/jalali";

interface ExpertSuggestion {
  expert_id: number;
  name: string;
  phone: string | null;
  covers_city: boolean;
  equipment_experience: number;
  active_workload: number;
  score: number;
}

interface SuggestionsResponse {
  request_number: string;
  city: string;
  equipment_type: string | null;
  suggestions: ExpertSuggestion[];
}

async function fetchSuggestions(requestId: number): Promise<SuggestionsResponse> {
  const res = await fetch(`/api/proxy/expert/suggest/${requestId}/`);
  return res.json();
}

export function AssignExpertDialog({
  requestId,
  open,
  onOpenChange,
}: {
  requestId: number;
  open: boolean;
  onOpenChange: (open: boolean) => void;
}) {
  const queryClient = useQueryClient();
  const [assigningId, setAssigningId] = React.useState<number | null>(null);

  const { data, isLoading } = useQuery({
    queryKey: ["expert-suggestions", requestId],
    queryFn: () => fetchSuggestions(requestId),
    enabled: open,
  });

  async function handleAssign(expertId: number) {
    setAssigningId(expertId);
    try {
      const res = await fetch(
        `/api/proxy/core/inspection-requests/${requestId}/assign_expert/`,
        {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ expert_id: expertId }),
        }
      );
      const result = await res.json();
      if (!res.ok) {
        toast.error(result.error || "تخصیص ناموفق بود.");
        return;
      }
      toast.success(result.message || "کارشناس با موفقیت تخصیص یافت.");
      queryClient.invalidateQueries({ queryKey: ["admin-requests"] });
      onOpenChange(false);
    } catch {
      toast.error("ارتباط با سرور برقرار نشد.");
    } finally {
      setAssigningId(null);
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-lg">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <UserCog className="size-5" />
            پیشنهاد تخصیص کارشناس
          </DialogTitle>
          <DialogDescription>
            {data
              ? `درخواست ${toPersianDigits(data.request_number)} · ${data.equipment_type} · ${data.city}`
              : "در حال بارگذاری..."}
          </DialogDescription>
        </DialogHeader>

        {isLoading ? (
          <div className="flex justify-center py-8">
            <Loader2 className="text-muted-foreground size-6 animate-spin" />
          </div>
        ) : !data?.suggestions.length ? (
          <p className="text-muted-foreground py-6 text-center text-sm">
            کارشناس فعالی یافت نشد.
          </p>
        ) : (
          <div className="flex max-h-96 flex-col gap-2 overflow-y-auto">
            {data.suggestions.map((exp, i) => (
              <div
                key={exp.expert_id}
                className={cn(
                  "flex items-center justify-between gap-3 rounded-lg border p-3",
                  i === 0 && "border-primary/40 bg-primary/[0.03]"
                )}
              >
                <div className="min-w-0">
                  <div className="flex items-center gap-1.5">
                    <span className="text-sm font-medium">{exp.name}</span>
                    {i === 0 && (
                      <Badge variant="success" className="h-4 px-1.5 text-[10px]">
                        بهترین گزینه
                      </Badge>
                    )}
                  </div>
                  <div className="text-muted-foreground mt-1 flex flex-wrap items-center gap-x-3 gap-y-0.5 text-xs">
                    {exp.covers_city && (
                      <span className="inline-flex items-center gap-1">
                        <MapPin className="size-3" />
                        پوشش شهر
                      </span>
                    )}
                    <span className="inline-flex items-center gap-1">
                      <Wrench className="size-3" />
                      {toPersianDigits(exp.equipment_experience)} سابقه مشابه
                    </span>
                    <span>
                      بار کاری: {toPersianDigits(exp.active_workload)}
                    </span>
                  </div>
                </div>
                <Button
                  size="sm"
                  variant={i === 0 ? "default" : "outline"}
                  disabled={assigningId !== null}
                  onClick={() => handleAssign(exp.expert_id)}
                >
                  {assigningId === exp.expert_id ? (
                    <Loader2 className="animate-spin" />
                  ) : (
                    <CheckCircle2 />
                  )}
                  تخصیص
                </Button>
              </div>
            ))}
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}

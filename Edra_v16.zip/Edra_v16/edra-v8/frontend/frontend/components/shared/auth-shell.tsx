import Link from "next/link";
import { ShieldCheck } from "lucide-react";

export function AuthShell({
  children,
  title,
  subtitle,
}: {
  children: React.ReactNode;
  title: string;
  subtitle: string;
}) {
  return (
    <div className="grid min-h-svh lg:grid-cols-2">
      <div className="flex flex-col gap-4 p-6 md:p-10">
        <div className="flex justify-center gap-2 md:justify-start">
          <Link href="/" className="flex items-center gap-2 font-semibold">
            <span className="flex size-8 items-center justify-center rounded-md bg-primary text-primary-foreground">
              <ShieldCheck className="size-4" />
            </span>
            ادرو
          </Link>
        </div>
        <div className="flex flex-1 items-center justify-center">
          <div className="w-full max-w-sm">
            <div className="mb-6 flex flex-col gap-1.5 text-center">
              <h1 className="text-xl font-semibold">{title}</h1>
              <p className="text-muted-foreground text-sm">{subtitle}</p>
            </div>
            {children}
          </div>
        </div>
      </div>
      <div className="relative hidden lg:block bg-muted">
        <div className="absolute inset-0 flex flex-col items-center justify-center gap-6 bg-gradient-to-br from-primary/5 via-background to-secondary/5 p-10 text-center">
          <div className="flex size-20 items-center justify-center rounded-2xl bg-primary/10">
            <ShieldCheck className="size-10 text-primary" />
          </div>
          <div className="max-w-sm space-y-2">
            <h2 className="text-lg font-semibold">
              بازرسی تخصصی تجهیزات صنعتی
            </h2>
            <p className="text-muted-foreground text-sm leading-relaxed">
              رزرو، زمان‌بندی و صدور گواهی بازرسی جرثقیل، لیفتراک و سایر
              تجهیزات سنگین - همه در یک پلتفرم.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}

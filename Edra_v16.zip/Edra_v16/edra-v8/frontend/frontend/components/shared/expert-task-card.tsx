import Link from "next/link";
import { MapPin, Clock, Wrench, ChevronLeft } from "lucide-react";

import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { getStatusInfo, REQUEST_STATUS_MAP } from "@/lib/status-map";
import { toPersianDigits } from "@/lib/jalali";
import type { ExpertTask } from "@/types/dashboard";

export function ExpertTaskCard({ task }: { task: ExpertTask }) {
  const status = getStatusInfo(REQUEST_STATUS_MAP, task.status);
  return (
    <Card>
      <CardContent className="flex flex-wrap items-center gap-4 px-5 py-4">
        <span className="flex size-11 shrink-0 items-center justify-center rounded-lg bg-primary/10 text-primary">
          <Wrench className="size-5" />
        </span>
        <div className="min-w-0 flex-1">
          <div className="flex items-center gap-2">
            <p className="truncate text-sm font-medium">
              {task.equipment || "—"} · {toPersianDigits(task.request_number)}
            </p>
            <Badge variant={status.variant}>{status.label}</Badge>
          </div>
          <p className="text-muted-foreground mt-1 flex flex-wrap items-center gap-x-4 gap-y-0.5 text-xs">
            {task.scheduled_at_jalali && (
              <span className="inline-flex items-center gap-1">
                <Clock className="size-3.5" />
                {task.scheduled_at_jalali}
              </span>
            )}
            <span className="inline-flex items-center gap-1">
              <MapPin className="size-3.5" />
              {task.city} - {task.address}
            </span>
          </p>
        </div>
        <Button variant="outline" size="sm" asChild>
          <Link href={`/dashboard/expert/tasks/${task.id}`}>
            جزئیات
            <ChevronLeft className="size-3.5" />
          </Link>
        </Button>
      </CardContent>
    </Card>
  );
}

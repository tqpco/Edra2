"use client";

import * as React from "react";
import { Bell, CheckCheck } from "lucide-react";

import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuTrigger,
  DropdownMenuSeparator,
  DropdownMenuLabel,
} from "@/components/ui/dropdown-menu";
import { useNotificationSocket } from "@/hooks/use-notification-socket";
import { formatPersianTime, toPersianDigits } from "@/lib/jalali";

async function fetchWsTicket(): Promise<string | null> {
  const res = await fetch("/api/auth/ws-token");
  if (!res.ok) return null;
  const data = await res.json();
  return data.ticket ?? null;
}

export function NotificationBell() {
  const { notifications, markAsRead, markAllAsRead } = useNotificationSocket(fetchWsTicket);
  const unreadCount = notifications.length;

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button variant="ghost" size="icon" className="relative">
          <Bell className="size-5" />
          {unreadCount > 0 && (
            <Badge
              variant="destructive"
              className="absolute -top-1 -left-1 h-4 min-w-4 justify-center rounded-full px-1 text-[10px]"
            >
              {toPersianDigits(unreadCount > 9 ? "۹+" : unreadCount)}
            </Badge>
          )}
          <span className="sr-only">اعلان‌ها</span>
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end" className="w-80">
        <div className="flex items-center justify-between px-2 py-1.5">
          <DropdownMenuLabel className="p-0">اعلان‌ها</DropdownMenuLabel>
          {unreadCount > 0 && (
            <button
              onClick={markAllAsRead}
              className="text-muted-foreground hover:text-foreground flex items-center gap-1 text-xs"
            >
              <CheckCheck className="size-3.5" />
              علامت‌گذاری همه
            </button>
          )}
        </div>
        <DropdownMenuSeparator />
        {notifications.length === 0 ? (
          <p className="text-muted-foreground py-6 text-center text-sm">
            اعلان خوانده‌نشده‌ای ندارید
          </p>
        ) : (
          <div className="max-h-80 overflow-y-auto">
            {notifications.map((n) => (
              <button
                key={n.id}
                onClick={() => markAsRead(n.id)}
                className="hover:bg-accent flex w-full flex-col gap-0.5 rounded-md px-2 py-2 text-right"
              >
                <span className="text-sm font-medium">{n.title}</span>
                <span className="text-muted-foreground line-clamp-2 text-xs">
                  {n.message}
                </span>
                <span className="text-muted-foreground mt-0.5 text-[10px]">
                  {formatPersianTime(new Date(n.created_at))}
                </span>
              </button>
            ))}
          </div>
        )}
      </DropdownMenuContent>
    </DropdownMenu>
  );
}

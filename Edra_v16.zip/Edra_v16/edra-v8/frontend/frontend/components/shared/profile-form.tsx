"use client";

import * as React from "react";
import { Loader2, Save, KeyRound } from "lucide-react";
import { toast } from "sonner";

import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";

export interface ProfileField {
  key: string;
  label: string;
  type?: "text" | "email" | "textarea" | "number";
}

export function ProfileForm({
  fetchUrl,
  fields,
}: {
  fetchUrl: string;
  fields: ProfileField[];
}) {
  const [data, setData] = React.useState<Record<string, string> | null>(null);
  const [saving, setSaving] = React.useState(false);

  React.useEffect(() => {
    fetch(fetchUrl)
      .then((r) => r.json())
      .then((d) => setData(d));
  }, [fetchUrl]);

  async function handleSave() {
    if (!data) return;
    setSaving(true);
    try {
      const res = await fetch(fetchUrl, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });
      if (res.ok) {
        toast.success("اطلاعات با موفقیت بروزرسانی شد");
      } else {
        toast.error("بروزرسانی ناموفق بود");
      }
    } finally {
      setSaving(false);
    }
  }

  if (!data) {
    return (
      <div className="flex justify-center py-10">
        <Loader2 className="text-muted-foreground size-6 animate-spin" />
      </div>
    );
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-base">اطلاعات پروفایل</CardTitle>
      </CardHeader>
      <CardContent className="grid gap-4 sm:grid-cols-2">
        {fields.map((f) => (
          <div
            key={f.key}
            className={`grid gap-2 ${f.type === "textarea" ? "sm:col-span-2" : ""}`}
          >
            <Label htmlFor={f.key}>{f.label}</Label>
            {f.type === "textarea" ? (
              <Textarea
                id={f.key}
                rows={3}
                value={data[f.key] ?? ""}
                onChange={(e) => setData({ ...data, [f.key]: e.target.value })}
              />
            ) : (
              <Input
                id={f.key}
                type={f.type ?? "text"}
                value={data[f.key] ?? ""}
                onChange={(e) => setData({ ...data, [f.key]: e.target.value })}
              />
            )}
          </div>
        ))}
        <div className="sm:col-span-2">
          <Button onClick={handleSave} disabled={saving}>
            {saving && <Loader2 className="animate-spin" />}
            <Save />
            ذخیره تغییرات
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}

export function ChangePasswordCard({ endpoint }: { endpoint: string }) {
  const [oldPassword, setOldPassword] = React.useState("");
  const [newPassword, setNewPassword] = React.useState("");
  const [confirm, setConfirm] = React.useState("");
  const [saving, setSaving] = React.useState(false);

  async function handleChange() {
    if (newPassword !== confirm) {
      toast.error("رمز جدید و تکرار آن یکسان نیستند");
      return;
    }
    setSaving(true);
    try {
      const res = await fetch(endpoint, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          old_password: oldPassword,
          new_password: newPassword,
          confirm_password: confirm,
        }),
      });
      const data = await res.json();
      if (!res.ok) {
        toast.error(data.error || "تغییر رمز ناموفق بود");
        return;
      }
      toast.success("رمز عبور با موفقیت تغییر کرد");
      setOldPassword("");
      setNewPassword("");
      setConfirm("");
    } finally {
      setSaving(false);
    }
  }

  return (
    <Card id="settings">
      <CardHeader>
        <CardTitle className="flex items-center gap-2 text-base">
          <KeyRound className="size-4" />
          تغییر رمز عبور
        </CardTitle>
      </CardHeader>
      <CardContent className="grid gap-4 sm:grid-cols-3">
        <div className="grid gap-2">
          <Label>رمز فعلی</Label>
          <Input
            type="password"
            value={oldPassword}
            onChange={(e) => setOldPassword(e.target.value)}
          />
        </div>
        <div className="grid gap-2">
          <Label>رمز جدید</Label>
          <Input
            type="password"
            value={newPassword}
            onChange={(e) => setNewPassword(e.target.value)}
          />
        </div>
        <div className="grid gap-2">
          <Label>تکرار رمز جدید</Label>
          <Input
            type="password"
            value={confirm}
            onChange={(e) => setConfirm(e.target.value)}
          />
        </div>
        <div className="sm:col-span-3">
          <Button onClick={handleChange} disabled={saving} variant="outline">
            {saving && <Loader2 className="animate-spin" />}
            تغییر رمز عبور
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}

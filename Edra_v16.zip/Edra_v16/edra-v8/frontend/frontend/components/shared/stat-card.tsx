import type { LucideIcon } from "lucide-react";
import { cn } from "@/lib/utils";
import { Card, CardContent } from "@/components/ui/card";
import { toPersianDigits } from "@/lib/jalali";

export function StatCard({
  title,
  value,
  icon: Icon,
  tone = "default",
  suffix,
  href,
}: {
  title: string;
  value: number | string;
  icon: LucideIcon;
  tone?: "default" | "primary" | "success" | "warning";
  suffix?: string;
  href?: string;
}) {
  const toneClasses: Record<string, string> = {
    default: "bg-muted text-foreground",
    primary: "bg-primary/10 text-primary",
    success: "bg-success/10 text-success",
    warning: "bg-warning/10 text-warning",
  };

  const content = (
    <Card className="transition-shadow hover:shadow-md">
      <CardContent className="flex items-center gap-4 px-5 py-4">
        <span
          className={cn(
            "flex size-11 shrink-0 items-center justify-center rounded-lg",
            toneClasses[tone]
          )}
        >
          <Icon className="size-5" />
        </span>
        <div className="flex flex-col">
          <span className="text-muted-foreground text-xs">{title}</span>
          <span className="text-xl font-semibold">
            {typeof value === "number" ? toPersianDigits(value) : value}
            {suffix && (
              <span className="text-muted-foreground mr-1 text-xs font-normal">
                {suffix}
              </span>
            )}
          </span>
        </div>
      </CardContent>
    </Card>
  );

  if (href) {
    return (
      <a href={href} className="block">
        {content}
      </a>
    );
  }
  return content;
}

"use client";

import * as React from "react";
import { useQuery } from "@tanstack/react-query";
import { Wrench, MapPin } from "lucide-react";

import { Card, CardHeader, CardTitle, CardDescription, CardContent } from "@/components/ui/card";
import {
  Select,
  SelectTrigger,
  SelectValue,
  SelectContent,
  SelectItem,
} from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { WizardFooter } from "./wizard-footer";
import { useWizardStore } from "@/lib/wizard-store";
import type { EquipmentType, CityMultiplier } from "@/types/equipment";

async function fetchEquipmentTypes(): Promise<EquipmentType[]> {
  const res = await fetch("/api/proxy/core/equipment-types/");
  const data = await res.json();
  return data.results ?? data;
}

async function fetchCities(): Promise<CityMultiplier[]> {
  const res = await fetch("/api/proxy/core/city-multipliers/");
  const data = await res.json();
  return data.results ?? data;
}

export function StepEquipment() {
  const { equipmentTypeId, city, setEquipment, setCity, setStep } = useWizardStore();

  const { data: equipmentTypes, isLoading: loadingEquipment } = useQuery({
    queryKey: ["equipment-types"],
    queryFn: fetchEquipmentTypes,
  });
  const { data: cities, isLoading: loadingCities } = useQuery({
    queryKey: ["cities"],
    queryFn: fetchCities,
  });

  const canContinue = !!equipmentTypeId && !!city;

  return (
    <Card>
      <CardHeader>
        <CardTitle>نوع تجهیز و محل بازرسی</CardTitle>
        <CardDescription>
          ابتدا نوع تجهیزی که نیاز به بازرسی دارد و شهر محل بازرسی را انتخاب کنید
        </CardDescription>
      </CardHeader>
      <CardContent className="flex flex-col gap-6">
        <div className="grid gap-2">
          <Label>
            <Wrench className="size-4" />
            نوع تجهیز
          </Label>
          <Select
            disabled={loadingEquipment}
            value={equipmentTypeId ? String(equipmentTypeId) : undefined}
            onValueChange={(val) => {
              const eq = equipmentTypes?.find((e) => e.id === Number(val));
              if (eq) setEquipment(eq.id, eq.name_fa);
            }}
          >
            <SelectTrigger className="w-full">
              <SelectValue placeholder="انتخاب کنید..." />
            </SelectTrigger>
            <SelectContent>
              {equipmentTypes?.map((eq) => (
                <SelectItem key={eq.id} value={String(eq.id)}>
                  {eq.name_fa}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        <div className="grid gap-2">
          <Label>
            <MapPin className="size-4" />
            شهر محل بازرسی
          </Label>
          <Select
            disabled={loadingCities}
            value={city ?? undefined}
            onValueChange={setCity}
          >
            <SelectTrigger className="w-full">
              <SelectValue placeholder="انتخاب کنید..." />
            </SelectTrigger>
            <SelectContent>
              {cities?.map((c) => (
                <SelectItem key={c.id} value={c.city}>
                  {c.city}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </CardContent>
      <CardContent>
        <WizardFooter
          hideBack
          nextDisabled={!canContinue}
          onNext={() => setStep(2)}
        />
      </CardContent>
    </Card>
  );
}

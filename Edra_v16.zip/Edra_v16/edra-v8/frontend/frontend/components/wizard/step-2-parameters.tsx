"use client";

import * as React from "react";
import { useQuery } from "@tanstack/react-query";
import { Settings2 } from "lucide-react";

import { Card, CardHeader, CardTitle, CardDescription, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import {
  Select,
  SelectTrigger,
  SelectValue,
  SelectContent,
  SelectItem,
} from "@/components/ui/select";
import { WizardFooter } from "./wizard-footer";
import { useWizardStore } from "@/lib/wizard-store";
import type { EquipmentType } from "@/types/equipment";

async function fetchEquipmentType(id: number): Promise<EquipmentType> {
  const res = await fetch(`/api/proxy/core/equipment-types/${id}/`);
  return res.json();
}

export function StepParameters() {
  const {
    equipmentTypeId,
    equipmentName,
    params,
    installState,
    setParams,
    setInstallState,
    setStep,
  } = useWizardStore();

  const { data: equipment, isLoading } = useQuery({
    queryKey: ["equipment-type", equipmentTypeId],
    queryFn: () => fetchEquipmentType(equipmentTypeId!),
    enabled: !!equipmentTypeId,
  });

  const schema = equipment?.param_schema ?? [];
  const requiredFilled = schema
    .filter((f) => f.required)
    .every((f) => {
      const v = params[f.name];
      return v !== undefined && v !== null && v !== "";
    });
  const installOk = !equipment?.install_state_required || !!installState;
  const canContinue = requiredFilled && installOk;

  function updateParam(name: string, value: string | number | boolean) {
    setParams({ ...params, [name]: value });
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Settings2 className="size-5" />
          مشخصات فنی {equipmentName}
        </CardTitle>
        <CardDescription>
          این اطلاعات مستقیماً روی محاسبه‌ی قیمت بازرسی تاثیر می‌گذارد
        </CardDescription>
      </CardHeader>
      <CardContent className="flex flex-col gap-5">
        {isLoading && (
          <p className="text-muted-foreground text-sm">در حال بارگذاری...</p>
        )}

        {schema.map((field) => (
          <div key={field.name} className="grid gap-2">
            <Label htmlFor={field.name}>
              {field.label}
              {field.required && <span className="text-destructive">*</span>}
            </Label>
            {field.type === "select" && field.options ? (
              <Select
                value={params[field.name] ? String(params[field.name]) : undefined}
                onValueChange={(v) => updateParam(field.name, v)}
              >
                <SelectTrigger className="w-full">
                  <SelectValue placeholder="انتخاب کنید..." />
                </SelectTrigger>
                <SelectContent>
                  {field.options.map((opt) => (
                    <SelectItem key={opt} value={opt}>
                      {opt}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            ) : field.type === "number" ? (
              <Input
                id={field.name}
                type="number"
                inputMode="decimal"
                value={(params[field.name] as string | number) ?? ""}
                onChange={(e) => updateParam(field.name, e.target.value)}
              />
            ) : (
              <Input
                id={field.name}
                value={(params[field.name] as string) ?? ""}
                onChange={(e) => updateParam(field.name, e.target.value)}
              />
            )}
          </div>
        ))}

        {equipment?.supports_install_state && (
          <div className="grid gap-2">
            <Label>
              وضعیت استقرار دستگاه
              {equipment.install_state_required && (
                <span className="text-destructive">*</span>
              )}
            </Label>
            <RadioGroup
              value={installState ?? undefined}
              onValueChange={setInstallState}
              className="grid-cols-2"
            >
              <Label
                htmlFor="install-installed"
                className="hover:bg-accent flex cursor-pointer items-center gap-2 rounded-md border p-3"
              >
                <RadioGroupItem value="installed" id="install-installed" />
                دستگاه نصب می‌باشد
              </Label>
              <Label
                htmlFor="install-dismantled"
                className="hover:bg-accent flex cursor-pointer items-center gap-2 rounded-md border p-3"
              >
                <RadioGroupItem value="dismantled" id="install-dismantled" />
                دستگاه دمونتاژ می‌باشد
              </Label>
            </RadioGroup>
          </div>
        )}
      </CardContent>
      <CardContent>
        <WizardFooter
          onBack={() => setStep(1)}
          onNext={() => setStep(3)}
          nextDisabled={!canContinue}
        />
      </CardContent>
    </Card>
  );
}

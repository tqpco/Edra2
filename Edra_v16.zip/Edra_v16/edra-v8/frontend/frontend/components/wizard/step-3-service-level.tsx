"use client";

import * as React from "react";
import { useQuery } from "@tanstack/react-query";
import { Star, ShieldCheck, Loader2 } from "lucide-react";

import { Card, CardHeader, CardTitle, CardDescription, CardContent } from "@/components/ui/card";
import { cn } from "@/lib/utils";
import { WizardFooter } from "./wizard-footer";
import { useWizardStore } from "@/lib/wizard-store";
import { formatToman } from "@/lib/format";
import type { PriceCalculateResponse } from "@/types/equipment";

async function calculatePrice(payload: {
  equipment_type_id: number;
  params: Record<string, unknown>;
  install_state: string | null;
  city: string;
  service_type: string;
}): Promise<PriceCalculateResponse> {
  const res = await fetch("/api/proxy/pricing/calculate/", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(payload),
  });
  if (!res.ok) throw new Error("خطا در محاسبه قیمت");
  return res.json();
}

export function StepServiceLevel() {
  const {
    equipmentTypeId,
    params,
    installState,
    city,
    serviceType,
    setServiceType,
    setPrice,
    setStep,
  } = useWizardStore();

  const standardQuery = useQuery({
    queryKey: ["price", equipmentTypeId, params, installState, city, "standard"],
    queryFn: () =>
      calculatePrice({
        equipment_type_id: equipmentTypeId!,
        params,
        install_state: installState,
        city: city!,
        service_type: "standard",
      }),
    enabled: !!equipmentTypeId && !!city,
  });

  const proQuery = useQuery({
    queryKey: ["price", equipmentTypeId, params, installState, city, "pro"],
    queryFn: () =>
      calculatePrice({
        equipment_type_id: equipmentTypeId!,
        params,
        install_state: installState,
        city: city!,
        service_type: "pro",
      }),
    enabled: !!equipmentTypeId && !!city,
  });

  function handleSelect(type: "standard" | "pro") {
    setServiceType(type);
    const q = type === "standard" ? standardQuery.data : proQuery.data;
    if (q) setPrice(q.total_price, q.city_cost);
  }

  function handleNext() {
    handleSelect(serviceType);
    setStep(4);
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>سطح سرویس بازرسی</CardTitle>
        <CardDescription>یکی از دو سطح سرویس زیر را انتخاب کنید</CardDescription>
      </CardHeader>
      <CardContent className="grid gap-4 sm:grid-cols-2">
        <ServiceOption
          icon={ShieldCheck}
          title="استاندارد"
          description="بازرسی کامل مطابق چک‌لیست استاندارد ادرو"
          query={standardQuery}
          selected={serviceType === "standard"}
          onSelect={() => handleSelect("standard")}
        />
        <ServiceOption
          icon={Star}
          title="حرفه‌ای"
          description="بازرسی تخصصی‌تر با بررسی‌های تکمیلی و اولویت زمان‌بندی"
          query={proQuery}
          selected={serviceType === "pro"}
          onSelect={() => handleSelect("pro")}
        />
      </CardContent>
      <CardContent>
        <WizardFooter onBack={() => setStep(2)} onNext={handleNext} />
      </CardContent>
    </Card>
  );
}

function ServiceOption({
  icon: Icon,
  title,
  description,
  query,
  selected,
  onSelect,
}: {
  icon: typeof ShieldCheck;
  title: string;
  description: string;
  query: { data?: PriceCalculateResponse; isLoading: boolean; isError: boolean };
  selected: boolean;
  onSelect: () => void;
}) {
  return (
    <button
      type="button"
      onClick={onSelect}
      className={cn(
        "flex flex-col gap-3 rounded-xl border p-5 text-right transition-all",
        selected
          ? "border-primary bg-primary/[0.04] ring-1 ring-primary"
          : "hover:border-primary/40"
      )}
    >
      <span
        className={cn(
          "flex size-10 items-center justify-center rounded-lg",
          selected ? "bg-primary text-primary-foreground" : "bg-muted"
        )}
      >
        <Icon className="size-5" />
      </span>
      <div>
        <p className="font-semibold">{title}</p>
        <p className="text-muted-foreground mt-0.5 text-xs leading-relaxed">
          {description}
        </p>
      </div>
      <div className="mt-auto pt-2">
        {query.isLoading ? (
          <Loader2 className="text-muted-foreground size-4 animate-spin" />
        ) : query.isError ? (
          <span className="text-destructive text-xs">خطا در محاسبه قیمت</span>
        ) : (
          <span className="text-lg font-bold">
            {query.data ? formatToman(query.data.total_price) : "—"}
          </span>
        )}
      </div>
    </button>
  );
}

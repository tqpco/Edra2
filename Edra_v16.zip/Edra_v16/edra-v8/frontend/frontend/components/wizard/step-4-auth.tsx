"use client";

import * as React from "react";
import { useQueryClient } from "@tanstack/react-query";
import { Phone, ShieldAlert, ArrowRight, Loader2 } from "lucide-react";

import { Card, CardHeader, CardTitle, CardDescription, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { WizardFooter } from "./wizard-footer";
import { useWizardStore } from "@/lib/wizard-store";
import { toPersianDigits, toEnglishDigits } from "@/lib/jalali";

export function StepAuth() {
  const setStep = useWizardStore((s) => s.setStep);
  const queryClient = useQueryClient();

  const [phase, setPhase] = React.useState<"phone" | "code">("phone");
  const [phone, setPhone] = React.useState("");
  const [code, setCode] = React.useState("");
  const [error, setError] = React.useState<string | null>(null);
  const [loading, setLoading] = React.useState(false);
  const [seconds, setSeconds] = React.useState(0);

  React.useEffect(() => {
    if (seconds <= 0) return;
    const t = setInterval(() => setSeconds((s: number) => s - 1), 1000);
    return () => clearInterval(t);
  }, [seconds]);

  async function requestCode() {
    setError(null);
    const normalized = toEnglishDigits(phone);
    if (!/^09\d{9}$/.test(normalized)) {
      setError("شماره موبایل معتبر نیست (مثال: ۰۹۱۲۳۴۵۶۷۸۹)");
      return;
    }
    setLoading(true);
    try {
      const res = await fetch("/api/auth/otp-request", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ phone: normalized }),
      });
      const data = await res.json();
      if (!res.ok) {
        setError(data.error || data.detail || "ارسال کد ناموفق بود.");
        return;
      }
      setPhone(normalized);
      setPhase("code");
      setSeconds(120);
    } catch {
      setError("ارتباط با سرور برقرار نشد.");
    } finally {
      setLoading(false);
    }
  }

  async function verifyCode() {
    setError(null);
    const normalizedCode = toEnglishDigits(code);
    if (!/^\d{6}$/.test(normalizedCode)) {
      setError("کد تایید باید ۶ رقم باشد");
      return;
    }
    setLoading(true);
    try {
      const res = await fetch("/api/auth/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ phone, code: normalizedCode }),
      });
      const data = await res.json();
      if (!res.ok) {
        setError(data.error || data.detail || "کد وارد شده نامعتبر است.");
        return;
      }
      queryClient.setQueryData(["current-user"], data.user);
      setStep(5);
    } catch {
      setError("ارتباط با سرور برقرار نشد.");
    } finally {
      setLoading(false);
    }
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Phone className="size-5" />
          ورود با شماره موبایل
        </CardTitle>
        <CardDescription>
          برای ادامه‌ی رزرو، شماره موبایل خود را تایید کنید (در صورت نبود حساب،
          به‌صورت خودکار برای شما ساخته می‌شود)
        </CardDescription>
      </CardHeader>
      <CardContent className="flex flex-col gap-4">
        {error && (
          <Alert variant="destructive">
            <ShieldAlert />
            <AlertDescription>{error}</AlertDescription>
          </Alert>
        )}

        {phase === "phone" ? (
          <div className="grid gap-2">
            <Label htmlFor="wizard-phone">شماره موبایل</Label>
            <Input
              id="wizard-phone"
              dir="ltr"
              inputMode="numeric"
              className="text-center tracking-widest"
              placeholder="09123456789"
              value={phone}
              onChange={(e) => setPhone(e.target.value)}
            />
          </div>
        ) : (
          <div className="grid gap-2">
            <Label htmlFor="wizard-code">
              کد ۶ رقمی ارسال‌شده به {toPersianDigits(phone)}
            </Label>
            <Input
              id="wizard-code"
              dir="ltr"
              inputMode="numeric"
              maxLength={6}
              autoFocus
              className="text-center text-lg tracking-[0.5em]"
              placeholder="------"
              value={code}
              onChange={(e) => setCode(e.target.value)}
            />
            <div className="flex items-center justify-between text-sm">
              <button
                type="button"
                onClick={() => setPhase("phone")}
                className="text-muted-foreground hover:text-foreground inline-flex items-center gap-1"
              >
                <ArrowRight className="size-3.5" />
                تغییر شماره
              </button>
              {seconds > 0 ? (
                <span className="text-muted-foreground">
                  ارسال مجدد تا {toPersianDigits(seconds)} ثانیه
                </span>
              ) : (
                <button
                  type="button"
                  className="text-primary hover:underline"
                  onClick={requestCode}
                >
                  ارسال مجدد کد
                </button>
              )}
            </div>
          </div>
        )}
      </CardContent>
      <CardContent>
        <WizardFooter
          onBack={() => setStep(3)}
          onNext={phase === "phone" ? requestCode : verifyCode}
          nextLabel={phase === "phone" ? "دریافت کد" : "تایید و ادامه"}
          isLoading={loading}
        />
      </CardContent>
    </Card>
  );
}

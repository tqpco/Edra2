"use client";

import * as React from "react";
import { ChevronRight, ChevronLeft, Clock, CalendarDays } from "lucide-react";

import { Card, CardHeader, CardTitle, CardDescription, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import { WizardFooter } from "./wizard-footer";
import { useWizardStore } from "@/lib/wizard-store";
import {
  dateToJalali,
  jalaliToDate,
  jalaliMonthLength,
  isWorkingDay,
  earliestBookableDate,
  availableTimeSlots,
  toPersianDigits,
  JALALI_MONTH_NAMES,
  JALALI_WEEKDAY_NAMES,
} from "@/lib/jalali";

// شنبه اول هفته‌ی ایرانی است؛ آرایه‌ی نمایش را بر همین اساس می‌چینیم
const WEEKDAY_HEADER = ["ش", "ی", "د", "س", "چ", "پ", "ج"];

export function StepScheduling() {
  const { scheduledAt, setScheduledAt, setStep } = useWizardStore();
  const earliest = React.useMemo(() => earliestBookableDate(), []);
  const earliestJalali = React.useMemo(() => dateToJalali(earliest), [earliest]);

  const [viewYear, setViewYear] = React.useState(earliestJalali.year);
  const [viewMonth, setViewMonth] = React.useState(earliestJalali.month);
  const [selectedDate, setSelectedDate] = React.useState<Date | null>(
    scheduledAt ? new Date(scheduledAt) : null
  );
  const [selectedTime, setSelectedTime] = React.useState<string | null>(
    scheduledAt
      ? `${String(new Date(scheduledAt).getHours()).padStart(2, "0")}:${String(
          new Date(scheduledAt).getMinutes()
        ).padStart(2, "0")}`
      : null
  );

  const monthLength = jalaliMonthLength(viewYear, viewMonth);
  const firstOfMonth = jalaliToDate(viewYear, viewMonth, 1);
  // getDay(): یکشنبه=۰..شنبه=۶ -> باید به «فاصله از شنبه» تبدیل شود
  const leadingBlanks = (firstOfMonth.getDay() + 1) % 7;

  const days: (Date | null)[] = [
    ...Array(leadingBlanks).fill(null),
    ...Array.from({ length: monthLength }, (_, i) => jalaliToDate(viewYear, viewMonth, i + 1)),
  ];

  function isSelectable(d: Date) {
    return d >= new Date(earliest.getFullYear(), earliest.getMonth(), earliest.getDate()) && isWorkingDay(d);
  }

  function goPrevMonth() {
    if (viewMonth === 1) {
      setViewMonth(12);
      setViewYear((y) => y - 1);
    } else {
      setViewMonth((m) => m - 1);
    }
  }
  function goNextMonth() {
    if (viewMonth === 12) {
      setViewMonth(1);
      setViewYear((y) => y + 1);
    } else {
      setViewMonth((m) => m + 1);
    }
  }

  function handleNext() {
    if (!selectedDate || !selectedTime) return;
    const [h, m] = selectedTime.split(":").map(Number);
    const combined = new Date(selectedDate);
    combined.setHours(h!, m!, 0, 0);
    setScheduledAt(combined.toISOString());
    setStep(6);
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <CalendarDays className="size-5" />
          زمان کارشناسی
        </CardTitle>
        <CardDescription>
          جمعه‌ها تعطیل است و فقط بین ساعت ۸ تا ۱۶ قابل رزرو است
        </CardDescription>
      </CardHeader>
      <CardContent className="flex flex-col gap-6">
        <div>
          <div className="mb-3 flex items-center justify-between">
            <Button variant="ghost" size="icon" onClick={goPrevMonth}>
              <ChevronRight className="size-4" />
            </Button>
            <span className="text-sm font-medium">
              {JALALI_MONTH_NAMES[viewMonth - 1]} {toPersianDigits(viewYear)}
            </span>
            <Button variant="ghost" size="icon" onClick={goNextMonth}>
              <ChevronLeft className="size-4" />
            </Button>
          </div>
          <div className="grid grid-cols-7 gap-1 text-center">
            {WEEKDAY_HEADER.map((d) => (
              <span key={d} className="text-muted-foreground py-1 text-xs">
                {d}
              </span>
            ))}
            {days.map((d, i) => {
              if (!d) return <span key={`blank-${i}`} />;
              const selectable = isSelectable(d);
              const isSelected =
                selectedDate && d.toDateString() === selectedDate.toDateString();
              const jd = dateToJalali(d);
              return (
                <button
                  key={i}
                  type="button"
                  disabled={!selectable}
                  onClick={() => setSelectedDate(d)}
                  className={cn(
                    "aspect-square rounded-md text-sm transition-colors",
                    !selectable && "text-muted-foreground/40 cursor-not-allowed",
                    selectable && !isSelected && "hover:bg-accent",
                    isSelected && "bg-primary text-primary-foreground font-medium"
                  )}
                >
                  {toPersianDigits(jd.day)}
                </button>
              );
            })}
          </div>
        </div>

        {selectedDate && (
          <div className="grid gap-2">
            <p className="flex items-center gap-1.5 text-sm font-medium">
              <Clock className="size-4" />
              ساعت کارشناسی
            </p>
            <div className="grid grid-cols-4 gap-2 sm:grid-cols-6">
              {availableTimeSlots().map((slot) => (
                <button
                  key={slot}
                  type="button"
                  onClick={() => setSelectedTime(slot)}
                  className={cn(
                    "rounded-md border py-1.5 text-sm transition-colors",
                    selectedTime === slot
                      ? "border-primary bg-primary text-primary-foreground"
                      : "hover:border-primary/40"
                  )}
                >
                  {toPersianDigits(slot)}
                </button>
              ))}
            </div>
          </div>
        )}
      </CardContent>
      <CardContent>
        <WizardFooter
          onBack={() => setStep(4)}
          onNext={handleNext}
          nextDisabled={!selectedDate || !selectedTime}
        />
      </CardContent>
    </Card>
  );
}

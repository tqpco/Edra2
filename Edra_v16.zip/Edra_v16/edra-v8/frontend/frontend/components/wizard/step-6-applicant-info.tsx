"use client";

import * as React from "react";
import { UserRound } from "lucide-react";

import { Card, CardHeader, CardTitle, CardDescription, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { WizardFooter } from "./wizard-footer";
import { useWizardStore } from "@/lib/wizard-store";

export function StepApplicantInfo() {
  const {
    applicantName,
    companyName,
    projectName,
    address,
    setApplicantInfo,
    setStep,
  } = useWizardStore();

  const canContinue = applicantName.trim().length > 1 && address.trim().length > 5;

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <UserRound className="size-5" />
          اطلاعات متقاضی
        </CardTitle>
        <CardDescription>
          نام شرکت و پروژه در صورتی که متقاضی حقوقی هستید تکمیل شود
        </CardDescription>
      </CardHeader>
      <CardContent className="grid gap-4 sm:grid-cols-2">
        <div className="grid gap-2 sm:col-span-2">
          <Label htmlFor="applicantName">نام و نام‌خانوادگی متقاضی *</Label>
          <Input
            id="applicantName"
            value={applicantName}
            onChange={(e) => setApplicantInfo({ applicantName: e.target.value })}
          />
        </div>
        <div className="grid gap-2">
          <Label htmlFor="companyName">نام شرکت (اختیاری)</Label>
          <Input
            id="companyName"
            value={companyName}
            onChange={(e) => setApplicantInfo({ companyName: e.target.value })}
          />
        </div>
        <div className="grid gap-2">
          <Label htmlFor="projectName">نام پروژه (اختیاری)</Label>
          <Input
            id="projectName"
            value={projectName}
            onChange={(e) => setApplicantInfo({ projectName: e.target.value })}
          />
        </div>
        <div className="grid gap-2 sm:col-span-2">
          <Label htmlFor="address">آدرس دقیق محل کارشناسی *</Label>
          <Input
            id="address"
            value={address}
            onChange={(e) => setApplicantInfo({ address: e.target.value })}
            placeholder="استان، شهر، خیابان، پلاک..."
          />
        </div>
      </CardContent>
      <CardContent>
        <WizardFooter
          onBack={() => setStep(5)}
          onNext={() => setStep(7)}
          nextDisabled={!canContinue}
        />
      </CardContent>
    </Card>
  );
}

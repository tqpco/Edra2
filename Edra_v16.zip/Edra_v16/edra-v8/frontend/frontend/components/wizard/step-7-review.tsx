"use client";

import * as React from "react";
import { useQuery } from "@tanstack/react-query";
import { FileText, MapPin, Calendar, Wallet, Tag, Loader2 } from "lucide-react";

import { Card, CardHeader, CardTitle, CardDescription, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { WizardFooter } from "./wizard-footer";
import { useWizardStore } from "@/lib/wizard-store";
import { formatToman } from "@/lib/format";
import { formatJalaliWithWeekday, formatPersianTime } from "@/lib/jalali";

interface CreditBalance {
  balance: number;
}

interface PricePreview {
  total_price: number;
  tax_rate_percent: number;
  tax_amount: number;
  final_amount: number;
}

async function fetchCredit(): Promise<CreditBalance> {
  const res = await fetch("/api/proxy/core/credit/");
  if (!res.ok) return { balance: 0 };
  const data = await res.json();
  const results = data.results ?? data;
  return results?.[0] ?? { balance: 0 };
}

// P0-09 (EDRA v9): مبلغ نهایی (شامل مالیات) از Backend — Review باید
// دقیقاً همان مبلغی را نشان دهد که درگاه/فاکتور دریافت می‌کند.
async function fetchPricePreview(payload: Record<string, unknown>): Promise<PricePreview | null> {
  try {
    const res = await fetch("/api/proxy/pricing/calculate/", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    });
    if (!res.ok) return null;
    const data = await res.json();
    return {
      total_price: Number(data.total_price ?? 0),
      tax_rate_percent: Number(data.tax_rate_percent ?? 0),
      tax_amount: Number(data.tax_amount ?? 0),
      final_amount: Number(data.final_amount ?? data.total_price ?? 0),
    };
  } catch {
    return null;
  }
}

export function StepReview() {
  const store = useWizardStore();
  const {
    equipmentName,
    city,
    serviceType,
    calculatedPrice,
    scheduledAt,
    applicantName,
    companyName,
    address,
    discountCode,
    setDiscountCode,
    useCreditAmount,
    setUseCreditAmount,
    setStep,
    setCreatedRequest,
  } = store;

  const { data: credit } = useQuery({ queryKey: ["my-credit"], queryFn: fetchCredit });

  // P0-09 (EDRA v9): preview قیمت server-side (شامل مالیات) — وقتی داده‌های
  // کافی باشد فراخوانی می‌شود و مبلغ نهایی منبع نمایش است.
  const canPreview = !!store.equipmentTypeId && !!city;
  const { data: pricePreview } = useQuery({
    queryKey: ["price-preview", store.equipmentTypeId, city, serviceType, JSON.stringify(store.params ?? {}), store.installState],
    queryFn: () =>
      fetchPricePreview({
        equipment_type_id: store.equipmentTypeId,
        params: store.params ?? {},
        install_state: store.installState,
        service_type: serviceType,
        city,
      }),
    enabled: canPreview,
    staleTime: 60_000,
  });

  const [discountInput, setDiscountInput] = React.useState(discountCode);
  const [submitting, setSubmitting] = React.useState(false);
  const [error, setError] = React.useState<string | null>(null);

  // مبلغ پایه نمایشی: قیمت محاسبه‌شده ویزارد (قبل از مالیات)
  const price = calculatedPrice ?? 0;
  // مبلغ نهایی شامل مالیات (server-derived) — fallback به قیمت پایه
  const finalWithTax = pricePreview?.final_amount ?? price;
  const maxCredit = Math.min(credit?.balance ?? 0, finalWithTax);
  const finalPayable = Math.max(finalWithTax - useCreditAmount, 0);

  async function handleSubmit() {
    setError(null);
    setSubmitting(true);
    try {
      const res = await fetch("/api/proxy/core/inspection-requests/", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          title: `${equipmentName} - ${applicantName}`,
          equipment_type: store.equipmentTypeId,
          params: store.params,
          install_state: store.installState,
          service_type: serviceType,
          city,
          address: [companyName, address].filter(Boolean).join(" - "),
          address_lat: store.addressLat,
          address_lng: store.addressLng,
          scheduled_at: scheduledAt,
          discount_code: discountInput || undefined,
        }),
      });
      const data = await res.json();
      if (!res.ok) {
        setError(
          data.discount_code?.[0] || data.detail || data.non_field_errors?.[0] ||
            "ثبت درخواست با خطا مواجه شد."
        );
        return;
      }
      setCreatedRequest(data.id, data.request_number);
      setStep(8);
    } catch {
      setError("ارتباط با سرور برقرار نشد.");
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <FileText className="size-5" />
          بررسی نهایی و پرداخت
        </CardTitle>
        <CardDescription>اطلاعات درخواست را بررسی و تایید کنید</CardDescription>
      </CardHeader>
      <CardContent className="flex flex-col gap-5">
        {error && (
          <Alert variant="destructive">
            <AlertDescription>{error}</AlertDescription>
          </Alert>
        )}

        <div className="grid gap-2 rounded-lg border p-4 text-sm">
          <Row icon={FileText} label="تجهیز و سرویس">
            {equipmentName} · {serviceType === "pro" ? "حرفه‌ای" : "استاندارد"}
          </Row>
          {scheduledAt && (
            <Row icon={Calendar} label="زمان کارشناسی">
              {formatJalaliWithWeekday(new Date(scheduledAt))} ساعت{" "}
              {formatPersianTime(new Date(scheduledAt))}
            </Row>
          )}
          <Row icon={MapPin} label="محل بازرسی">
            {city} - {address}
          </Row>
        </div>

        <div className="grid gap-2">
          <Label htmlFor="discount">
            <Tag className="size-4" />
            کد تخفیف (اختیاری)
          </Label>
          <Input
            id="discount"
            value={discountInput}
            onChange={(e) => {
              setDiscountInput(e.target.value);
              setDiscountCode(e.target.value);
            }}
            placeholder="کد تخفیف را وارد کنید"
          />
        </div>

        {!!credit?.balance && (
          <div className="grid gap-2">
            <Label htmlFor="credit-use">
              <Wallet className="size-4" />
              استفاده از اعتبار (موجودی: {formatToman(credit.balance)})
            </Label>
            <Input
              id="credit-use"
              type="number"
              min={0}
              max={maxCredit}
              value={useCreditAmount || ""}
              onChange={(e) =>
                setUseCreditAmount(
                  Math.min(Number(e.target.value) || 0, maxCredit)
                )
              }
            />
            <Button
              type="button"
              variant="link"
              size="sm"
              className="w-fit px-0"
              onClick={() => setUseCreditAmount(maxCredit)}
            >
              استفاده از کل اعتبار قابل استفاده ({formatToman(maxCredit)})
            </Button>
          </div>
        )}

        <div className="bg-muted flex flex-col gap-1.5 rounded-lg p-4">
          <div className="flex justify-between text-sm">
            <span className="text-muted-foreground">جمع هزینه بازرسی</span>
            <span>{formatToman(price)}</span>
          </div>
          {pricePreview && (
            <div className="flex justify-between text-sm">
              <span className="text-muted-foreground">
                مالیات بر ارزش افزوده ({pricePreview.tax_rate_percent}٪)
              </span>
              <span>{formatToman(pricePreview.tax_amount)}</span>
            </div>
          )}
          <div className="flex justify-between text-sm">
            <span className="text-muted-foreground">مبلغ نهایی (با مالیات)</span>
            <span>{formatToman(finalWithTax)}</span>
          </div>
          {useCreditAmount > 0 && (
            <div className="flex justify-between text-sm">
              <span className="text-muted-foreground">استفاده از اعتبار</span>
              <span>- {formatToman(useCreditAmount)}</span>
            </div>
          )}
          <div className="mt-1 flex justify-between border-t pt-1.5 text-base font-semibold">
            <span>قابل پرداخت</span>
            <span>{formatToman(finalPayable)}</span>
          </div>
        </div>
      </CardContent>
      <CardContent>
        <WizardFooter
          onBack={() => setStep(6)}
          onNext={handleSubmit}
          nextLabel="ثبت درخواست و ادامه"
          isLoading={submitting}
        />
      </CardContent>
    </Card>
  );
}

function Row({
  icon: Icon,
  label,
  children,
}: {
  icon: typeof FileText;
  label: string;
  children: React.ReactNode;
}) {
  return (
    <div className="flex items-start gap-2">
      <Icon className="text-muted-foreground mt-0.5 size-4 shrink-0" />
      <div>
        <span className="text-muted-foreground">{label}: </span>
        <span className="font-medium">{children}</span>
      </div>
    </div>
  );
}

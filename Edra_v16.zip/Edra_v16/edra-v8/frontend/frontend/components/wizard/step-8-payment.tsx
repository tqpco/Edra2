"use client";

import * as React from "react";
import { CreditCard, Building2, Loader2, Upload, CheckCircle2 } from "lucide-react";

import { Card, CardHeader, CardTitle, CardDescription, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { cn } from "@/lib/utils";
import { useWizardStore } from "@/lib/wizard-store";
import { toPersianDigits } from "@/lib/jalali";

type Method = "online" | "manual";

export function StepPayment() {
  const { requestId, requestNumber, useCreditAmount, reset } = useWizardStore();
  const [method, setMethod] = React.useState<Method>("online");
  const [receiptFile, setReceiptFile] = React.useState<File | null>(null);
  const [loading, setLoading] = React.useState(false);
  const [error, setError] = React.useState<string | null>(null);
  const [manualSubmitted, setManualSubmitted] = React.useState(false);

  async function payOnline() {
    setError(null);
    setLoading(true);
    try {
      const body: Record<string, unknown> = { request_id: requestId };
      if (useCreditAmount > 0) body.credit_amount = useCreditAmount;

      const res = await fetch("/api/proxy/core/payment/initiate/", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body),
      });
      const data = await res.json();
      if (!res.ok || !data.payment_url) {
        setError(data.error || "اتصال به درگاه پرداخت ناموفق بود.");
        return;
      }
      window.location.href = data.payment_url;
    } catch {
      setError("ارتباط با سرور برقرار نشد.");
    } finally {
      setLoading(false);
    }
  }

  async function payManual() {
    if (!receiptFile) {
      setError("لطفاً تصویر یا فایل فیش واریزی را انتخاب کنید.");
      return;
    }
    setError(null);
    setLoading(true);
    try {
      const formData = new FormData();
      formData.append("amount", "0"); // مبلغ از روی final_price درخواست محاسبه می‌شود
      formData.append("method", "manual");
      formData.append("request_id", String(requestId));
      if (useCreditAmount > 0) formData.append("credit_amount", String(useCreditAmount));
      formData.append("receipt_file", receiptFile);

      const res = await fetch("/api/proxy/core/credit/deposit/", {
        method: "POST",
        body: formData,
      });
      const data = await res.json();
      if (!res.ok) {
        setError(data.error || "آپلود فیش ناموفق بود.");
        return;
      }
      setManualSubmitted(true);
    } catch {
      setError("ارتباط با سرور برقرار نشد.");
    } finally {
      setLoading(false);
    }
  }

  if (manualSubmitted) {
    return (
      <Card>
        <CardContent className="flex flex-col items-center gap-4 py-12 text-center">
          <CheckCircle2 className="text-success size-14" />
          <div>
            <h2 className="text-lg font-semibold">فیش شما با موفقیت ثبت شد</h2>
            <p className="text-muted-foreground mt-1 text-sm">
              درخواست شماره {toPersianDigits(requestNumber ?? "")} پس از تایید فیش توسط
              مدیر، تکمیل خواهد شد و پیامک اطلاع‌رسانی برای شما ارسال می‌شود.
            </p>
          </div>
          <Button
            onClick={() => {
              reset();
              window.location.href = "/dashboard/customer/requests";
            }}
          >
            مشاهده درخواست‌های من
          </Button>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <CreditCard className="size-5" />
          روش پرداخت
        </CardTitle>
        <CardDescription>
          درخواست شما با شماره {toPersianDigits(requestNumber ?? "")} ثبت شد. روش
          پرداخت را انتخاب کنید
        </CardDescription>
      </CardHeader>
      <CardContent className="flex flex-col gap-5">
        {error && (
          <Alert variant="destructive">
            <AlertDescription>{error}</AlertDescription>
          </Alert>
        )}

        <div className="grid gap-3 sm:grid-cols-2">
          <button
            type="button"
            onClick={() => setMethod("online")}
            className={cn(
              "flex flex-col items-start gap-2 rounded-xl border p-4 text-right transition-all",
              method === "online"
                ? "border-primary bg-primary/[0.04] ring-1 ring-primary"
                : "hover:border-primary/40"
            )}
          >
            <CreditCard className="size-6 text-primary" />
            <span className="font-medium">پرداخت آنلاین</span>
            <span className="text-muted-foreground text-xs">
              پرداخت فوری از طریق درگاه بانکی (زرین‌پال)
            </span>
          </button>
          <button
            type="button"
            onClick={() => setMethod("manual")}
            className={cn(
              "flex flex-col items-start gap-2 rounded-xl border p-4 text-right transition-all",
              method === "manual"
                ? "border-primary bg-primary/[0.04] ring-1 ring-primary"
                : "hover:border-primary/40"
            )}
          >
            <Building2 className="size-6 text-primary" />
            <span className="font-medium">واریز دستی</span>
            <span className="text-muted-foreground text-xs">
              واریز به حساب و آپلود فیش (نیاز به تایید مدیر)
            </span>
          </button>
        </div>

        {method === "manual" && (
          <div className="rounded-lg border border-dashed p-4">
            <label className="flex cursor-pointer flex-col items-center gap-2 text-center">
              <Upload className="text-muted-foreground size-6" />
              <span className="text-sm font-medium">
                {receiptFile ? receiptFile.name : "برای آپلود فیش کلیک کنید"}
              </span>
              <span className="text-muted-foreground text-xs">JPG, PNG یا PDF</span>
              <input
                type="file"
                accept=".jpg,.jpeg,.png,.pdf"
                className="hidden"
                onChange={(e) => setReceiptFile(e.target.files?.[0] ?? null)}
              />
            </label>
          </div>
        )}

        <Button
          size="lg"
          onClick={method === "online" ? payOnline : payManual}
          disabled={loading}
        >
          {loading && <Loader2 className="animate-spin" />}
          {method === "online" ? "انتقال به درگاه پرداخت" : "ثبت فیش واریزی"}
        </Button>
      </CardContent>
    </Card>
  );
}

"use client";

import { Check } from "lucide-react";
import { cn } from "@/lib/utils";
import { toPersianDigits } from "@/lib/jalali";

const STEP_LABELS = [
  "تجهیز و شهر",
  "مشخصات فنی",
  "سطح سرویس",
  "ورود",
  "زمان‌بندی",
  "اطلاعات متقاضی",
  "بررسی نهایی",
  "پرداخت",
];

export function WizardStepIndicator({ current }: { current: number }) {
  return (
    <div className="w-full">
      {/* دسکتاپ: نمایش کامل مراحل */}
      <ol className="hidden items-center md:flex">
        {STEP_LABELS.map((label, i) => {
          const stepNum = i + 1;
          const isDone = stepNum < current;
          const isCurrent = stepNum === current;
          return (
            <li key={label} className="flex flex-1 items-center last:flex-none">
              <div className="flex flex-col items-center gap-1.5">
                <span
                  className={cn(
                    "flex size-8 shrink-0 items-center justify-center rounded-full border text-xs font-medium transition-colors",
                    isDone && "border-primary bg-primary text-primary-foreground",
                    isCurrent && "border-primary text-primary",
                    !isDone && !isCurrent && "border-border text-muted-foreground"
                  )}
                >
                  {isDone ? <Check className="size-4" /> : toPersianDigits(stepNum)}
                </span>
                <span
                  className={cn(
                    "text-[11px] whitespace-nowrap",
                    isCurrent ? "text-foreground font-medium" : "text-muted-foreground"
                  )}
                >
                  {label}
                </span>
              </div>
              {stepNum !== STEP_LABELS.length && (
                <div
                  className={cn(
                    "mx-2 h-px flex-1 -translate-y-3",
                    isDone ? "bg-primary" : "bg-border"
                  )}
                />
              )}
            </li>
          );
        })}
      </ol>

      {/* موبایل: فقط نوار پیشرفت + عنوان مرحله فعلی */}
      <div className="md:hidden">
        <div className="mb-2 flex items-center justify-between text-sm">
          <span className="font-medium">
            مرحله {toPersianDigits(current)} از {toPersianDigits(STEP_LABELS.length)}
          </span>
          <span className="text-muted-foreground">{STEP_LABELS[current - 1]}</span>
        </div>
        <div className="bg-muted h-1.5 w-full overflow-hidden rounded-full">
          <div
            className="bg-primary h-full transition-all"
            style={{ width: `${(current / STEP_LABELS.length) * 100}%` }}
          />
        </div>
      </div>
    </div>
  );
}

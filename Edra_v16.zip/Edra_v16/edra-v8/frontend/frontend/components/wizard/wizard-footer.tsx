import { ArrowLeft, ArrowRight, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";

export function WizardFooter({
  onBack,
  onNext,
  nextLabel = "ادامه",
  nextDisabled,
  isLoading,
  hideBack,
}: {
  onBack?: () => void;
  onNext?: () => void;
  nextLabel?: string;
  nextDisabled?: boolean;
  isLoading?: boolean;
  hideBack?: boolean;
}) {
  return (
    <div className="mt-8 flex items-center justify-between gap-3">
      {!hideBack && onBack ? (
        <Button type="button" variant="ghost" onClick={onBack}>
          <ArrowRight />
          مرحله قبل
        </Button>
      ) : (
        <span />
      )}
      {onNext && (
        <Button type="submit" onClick={onNext} disabled={nextDisabled || isLoading}>
          {isLoading && <Loader2 className="animate-spin" />}
          {nextLabel}
          {!isLoading && <ArrowLeft />}
        </Button>
      )}
    </div>
  );
}

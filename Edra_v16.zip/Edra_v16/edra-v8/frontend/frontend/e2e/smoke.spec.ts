/**
 * e2e/smoke.spec.ts — تست‌های دود (smoke) کلیدخوردگی اصلی سیستم.
 *
 * این تست‌ها در CI پس از بالا آمدن کامل stack اجرا می‌شوند:
 *   - صفحه اصلی بارگذاری می‌شود
 *   - لاگین با کاربر واقعی (از env) کار می‌کند
 *   - health backend در دسترس است
 */
import { expect, test } from "@playwright/test";

const E2E_USER = process.env.E2E_USERNAME || "";
const E2E_PASS = process.env.E2E_PASSWORD || "";
const API_BASE = process.env.BASE_URL
  ? process.env.BASE_URL.replace(/:\d+$/, ":8000")
  : "http://localhost:8000";

test("صفحه اصلی باز می‌شود", async ({ page }) => {
  const response = await page.goto("/");
  expect(response?.status()).toBeLessThan(400);
  await expect(page).toHaveTitle(/.+/);
});

test("health backend پاسخ می‌دهد", async ({ request }) => {
  const res = await request.get(`${API_BASE}/health/ready/`);
  expect(res.status()).toBe(200);
  const body = await res.json();
  expect(body.status).toBe("ok");
});

test("لاگین واقعی کار می‌کند (در صورت تنظیم کاربر E2E)", async ({ page }) => {
  test.skip(!E2E_USER || !E2E_PASS, "E2E_USERNAME/E2E_PASSWORD تنظیم نشده");
  await page.goto("/login");
  await page.getByLabel(/نام کاربری|شماره موبایل/i).fill(E2E_USER);
  await page.getByLabel(/رمز عبور/i).fill(E2E_PASS);
  await page.getByRole("button", { name: /ورود/i }).click();
  await expect(page).toHaveURL(/dashboard/);
});

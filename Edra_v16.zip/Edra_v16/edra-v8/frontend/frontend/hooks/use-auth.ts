"use client";

import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useRouter } from "next/navigation";
import type { User } from "@/types/user";

async function fetchCurrentUser(): Promise<User | null> {
  const res = await fetch("/api/auth/me", { cache: "no-store" });
  const data = await res.json();
  return data.user ?? null;
}

export function useAuth() {
  const queryClient = useQueryClient();
  const router = useRouter();

  const { data: user, isLoading } = useQuery({
    queryKey: ["current-user"],
    queryFn: fetchCurrentUser,
    staleTime: 60 * 1000,
  });

  async function logout() {
    await fetch("/api/auth/logout", { method: "POST" });
    queryClient.setQueryData(["current-user"], null);
    queryClient.clear();
    router.push("/");
  }

  function refreshUser() {
    return queryClient.invalidateQueries({ queryKey: ["current-user"] });
  }

  return {
    user: user ?? null,
    isLoading,
    isAuthenticated: !!user,
    logout,
    refreshUser,
  };
}

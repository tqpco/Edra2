"use client";

import * as React from "react";
import { useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";

export interface LiveNotification {
  id: number;
  title: string;
  message: string;
  created_at: string;
  type: string;
  status: string;
}

/**
 * اتصال WebSocket (اعلان‌های بلادرنگ). P0-08/HIGH-06: access JWT هرگز به
 * جاوااسکریپت داده نمی‌شود؛ از /api/auth/ws-token یک ticket یکبارمصرف
 * با عمر کوتاه می‌گیریم و فقط ticket در query string (?ticket=...) قرار
 * می‌گیرد.
 */
export function useNotificationSocket(wsTicketFetcher: () => Promise<string | null>) {
  const [notifications, setNotifications] = React.useState<LiveNotification[]>([]);
  const [isConnected, setIsConnected] = React.useState(false);
  const queryClient = useQueryClient();
  const socketRef = React.useRef<WebSocket | null>(null);

  React.useEffect(() => {
    let cancelled = false;
    let socket: WebSocket | null = null;

    async function connect() {
      const ticket = await wsTicketFetcher();
      if (!ticket || cancelled) return;

      // EDRA v6 — P1: اتصال same-origin از origin واقعی مرورگر ساخته
      // می‌شود (https → wss، http → ws) تا به build-time NEXT_PUBLIC_WS_URL
      // یا fallback localhost وابسته نباشد. Nginx هم /ws/ را proxy می‌کند.
      const proto = window.location.protocol === "https:" ? "wss:" : "ws:";
      const wsBase = `${proto}//${window.location.host}`;
      socket = new WebSocket(`${wsBase}/ws/notifications/?ticket=${ticket}`);
      socketRef.current = socket;

      socket.onopen = () => setIsConnected(true);
      socket.onclose = () => setIsConnected(false);
      socket.onmessage = (event) => {
        try {
          const payload = JSON.parse(event.data);
          if (payload.type === "notification") {
            const n = payload.data as LiveNotification;
            setNotifications((prev) => [n, ...prev].slice(0, 30));
            toast(n.title, { description: n.message });
            queryClient.invalidateQueries({ queryKey: ["unread-notifications-count"] });
          } else if (payload.type === "unread_notifications") {
            setNotifications(payload.data as LiveNotification[]);
          }
        } catch {
          // پیام غیرمنتظره - نادیده گرفته می‌شود
        }
      };
    }

    connect();

    return () => {
      cancelled = true;
      socket?.close();
    };
  }, [wsTicketFetcher, queryClient]);

  const markAsRead = React.useCallback((id: number) => {
    socketRef.current?.send(JSON.stringify({ action: "mark_read", notification_id: id }));
    setNotifications((prev) => prev.filter((n) => n.id !== id));
  }, []);

  const markAllAsRead = React.useCallback(() => {
    socketRef.current?.send(JSON.stringify({ action: "mark_all_read" }));
    setNotifications([]);
  }, []);

  return { notifications, isConnected, markAsRead, markAllAsRead };
}

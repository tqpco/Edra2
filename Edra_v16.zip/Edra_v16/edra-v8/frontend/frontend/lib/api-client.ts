/**
 * lib/api-client.ts
 * برای استفاده در Client Component ها ("use client") - از طریق پروکسی
 * داخلی /api/proxy می‌رود (نه مستقیم به جنگو)، چون توکن در کوکی httpOnly
 * است. برای Server Component از lib/api-server.ts استفاده کن.
 */
"use client";

export class ClientApiError extends Error {
  status: number;
  data: unknown;
  constructor(status: number, data: unknown) {
    super((data as { detail?: string })?.detail || `خطا (${status})`);
    this.status = status;
    this.data = data;
  }
}

interface ClientFetchOptions extends Omit<RequestInit, "body"> {
  body?: unknown;
}

/** path باید با /api/... شروع شود، مثال: /api/core/dashboard/customer/ */
export async function apiClientFetch<T = unknown>(
  path: string,
  options: ClientFetchOptions = {}
): Promise<T> {
  const proxyPath = path.replace(/^\/api\//, "/api/proxy/");
  const { body, headers, ...rest } = options;

  const res = await fetch(proxyPath, {
    ...rest,
    headers: {
      "Content-Type": "application/json",
      ...(headers as Record<string, string>),
    },
    body: body !== undefined ? JSON.stringify(body) : undefined,
  });

  const data = await res.json().catch(() => ({}));
  if (!res.ok) {
    throw new ClientApiError(res.status, data);
  }
  return data as T;
}

/** آپلود فایل (عکس/فیش/پیوست) - از FormData استفاده می‌کند */
export async function apiClientUpload<T = unknown>(
  path: string,
  formData: FormData,
  method: "POST" | "PUT" | "PATCH" = "POST"
): Promise<T> {
  const proxyPath = path.replace(/^\/api\//, "/api/proxy/");
  const res = await fetch(proxyPath, { method, body: formData });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) {
    throw new ClientApiError(res.status, data);
  }
  return data as T;
}

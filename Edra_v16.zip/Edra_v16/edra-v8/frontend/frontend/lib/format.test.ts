/**
 * lib/format.test.ts — فرمت مبالغ (تومان/ریال) با ارقام فارسی.
 */
import { describe, expect, it } from "vitest";
import { formatNumber, formatRial, formatToman } from "./format";

describe("formatToman", () => {
  it("مبلغ با جداکننده هزارگان و ارقام فارسی", () => {
    expect(formatToman(25000000)).toBe("۲۵,۰۰۰,۰۰۰ تومان");
  });

  it("عدد رشته‌ای را هم می‌پذیرد", () => {
    expect(formatToman("12500")).toBe("۱۲,۵۰۰ تومان");
  });

  it("مقدار نامعتبر → -", () => {
    expect(formatToman("abc")).toBe("-");
  });
});

describe("formatRial", () => {
  it("ریال با ارقام فارسی", () => {
    expect(formatRial(250000000)).toBe("۲۵۰,۰۰۰,۰۰۰ ریال");
  });
});

describe("formatNumber", () => {
  it("عدد گرد می‌شود", () => {
    expect(formatNumber(12345.6)).toBe("۱۲,۳۴۶");
  });

  it("مقدار نامعتبر → -", () => {
    expect(formatNumber(NaN)).toBe("-");
  });
});

import { toPersianDigits } from "./jalali";

/** فرمت مبلغ به تومان: "۲۵,۰۰۰,۰۰۰ تومان" */
export function formatToman(amount: number | string): string {
  const num = typeof amount === "string" ? parseFloat(amount) : amount;
  if (Number.isNaN(num)) return "-";
  const formatted = new Intl.NumberFormat("en-US").format(Math.round(num));
  return `${toPersianDigits(formatted)} تومان`;
}

/** فرمت مبلغ به ریال: "۲۵۰,۰۰۰,۰۰۰ ریال" */
export function formatRial(amount: number | string): string {
  const num = typeof amount === "string" ? parseFloat(amount) : amount;
  if (Number.isNaN(num)) return "-";
  const formatted = new Intl.NumberFormat("en-US").format(Math.round(num));
  return `${toPersianDigits(formatted)} ریال`;
}

/** فقط عدد با جداکننده هزارگان، بدون واحد */
export function formatNumber(amount: number | string): string {
  const num = typeof amount === "string" ? parseFloat(amount) : amount;
  if (Number.isNaN(num)) return "-";
  return toPersianDigits(new Intl.NumberFormat("en-US").format(Math.round(num)));
}

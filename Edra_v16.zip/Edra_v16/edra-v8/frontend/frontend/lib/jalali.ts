/**
 * lib/jalali.ts
 *
 * تبدیل و فرمت‌دهی تاریخ شمسی (جلالی) - بدون کتابخانه خارجی (طبق تصمیم
 * پروژه برای سبک ماندن باندل). الگوریتم بر پایه‌ی روش استاندارد نقاط‌شکست
 * ۳۳ ساله است و با چند تاریخ مرجع شناخته‌شده (از جمله ۲۲ بهمن ۱۳۵۷ و
 * سال‌های کبیسه ۱۴۰۳/۱۴۰۴) صحت‌سنجی شده.
 *
 * این فایل معادل TypeScript دقیقاً همان منطقی است که سمت بک‌اند پایتون
 * (django_jalali/jdatetime) استفاده می‌کند، تا تاریخ‌ها بین فرانت و بک
 * همیشه یکسان محاسبه شوند.
 */

function div(a: number, b: number): number {
  return Math.trunc(a / b);
}
function mod(a: number, b: number): number {
  return a - Math.trunc(a / b) * b;
}

const BREAKS = [
  -61, 9, 38, 199, 426, 686, 756, 818, 1111, 1181, 1210, 1635, 2060, 2097,
  2192, 2262, 2324, 2394, 2456, 3178,
];

interface JalCalResult {
  leap: number;
  gy: number;
  march: number;
}

function jalCal(jy: number): JalCalResult {
  const bl = BREAKS.length;
  const gy = jy + 621;
  let leapJ = -14;
  let jp = BREAKS[0]!;
  if (jy < jp || jy >= BREAKS[bl - 1]!) {
    throw new RangeError(`سال جلالی ${jy} خارج از بازه پشتیبانی‌شده است`);
  }
  let jump = 0;
  for (let i = 1; i < bl; i += 1) {
    const jm = BREAKS[i]!;
    jump = jm - jp;
    if (jy < jm) break;
    leapJ = leapJ + div(jump, 33) * 8 + div(mod(jump, 33), 4);
    jp = jm;
  }
  let n = jy - jp;
  leapJ = leapJ + div(n, 33) * 8 + div(mod(n, 33) + 3, 4);
  if (mod(jump, 33) === 4 && jump - n === 4) leapJ += 1;
  const leapG = div(gy, 4) - div((div(gy, 100) + 1) * 3, 4) - 150;
  const march = 20 + leapJ - leapG;
  if (jump - n < 6) n = n - jump + div(jump + 4, 33) * 33;
  let leap = mod(mod(n + 1, 33) - 1, 4);
  if (leap === -1) leap = 4;
  return { leap, gy, march };
}

/** آیا سال جلالی داده‌شده کبیسه است (اسفند ۳۰ روزه) */
export function isLeapJalaliYear(jy: number): boolean {
  return jalCal(jy).leap === 0;
}

/** تعداد روزهای یک ماه جلالی */
export function jalaliMonthLength(jy: number, jm: number): number {
  if (jm <= 6) return 31;
  if (jm <= 11) return 30;
  return isLeapJalaliYear(jy) ? 30 : 29;
}

function g2d(gy: number, gm: number, gd: number): number {
  let d =
    div((gy + div(gm - 8, 6) + 100100) * 1461, 4) +
    div(153 * mod(gm + 9, 12) + 2, 5) +
    gd -
    34840408;
  d = d - div(div(gy + 100100 + div(gm - 8, 6), 100) * 3, 4) + 752;
  return d;
}

function d2g(jdn: number): [number, number, number] {
  let j = 4 * jdn + 139361631;
  j = j + div(div(4 * jdn + 183187720, 146097) * 3, 4) * 4 - 3908;
  const i = div(mod(j, 1461), 4) * 5 + 308;
  const gd = div(mod(i, 153), 5) + 1;
  const gm = mod(div(i, 153), 12) + 1;
  const gy = div(j, 1461) - 100100 + div(8 - gm, 6);
  return [gy, gm, gd];
}

export type JalaliDate = { year: number; month: number; day: number };
export type GregorianDate = { year: number; month: number; day: number };

/** میلادی -> جلالی */
export function gregorianToJalali(gy: number, gm: number, gd: number): JalaliDate {
  const jdn = g2d(gy, gm, gd);
  const gy2 = d2g(jdn)[0];
  let jy = gy2 - 621;
  const r = jalCal(jy);
  const jdn1f = g2d(r.gy, 3, r.march);
  let k = jdn - jdn1f;
  if (k >= 0) {
    if (k <= 185) {
      return { year: jy, month: 1 + div(k, 31), day: mod(k, 31) + 1 };
    }
    k -= 186;
  } else {
    jy -= 1;
    k += 179;
    if (r.leap === 1) k += 1;
  }
  return { year: jy, month: 7 + div(k, 30), day: mod(k, 30) + 1 };
}

/** جلالی -> میلادی */
export function jalaliToGregorian(jy: number, jm: number, jd: number): GregorianDate {
  const r = jalCal(jy);
  const jdn =
    g2d(r.gy, 3, r.march) + (jm - 1) * 31 - div(jm, 7) * (jm - 7) + jd - 1;
  const [gy, gm, gd] = d2g(jdn);
  return { year: gy, month: gm, day: gd };
}

/** میان‌بر: شیء Date جاوااسکریپت -> جلالی */
export function dateToJalali(date: Date): JalaliDate {
  return gregorianToJalali(date.getFullYear(), date.getMonth() + 1, date.getDate());
}

/** میان‌بر: جلالی -> شیء Date جاوااسکریپت (ساعت محلی ۰۰:۰۰) */
export function jalaliToDate(jy: number, jm: number, jd: number): Date {
  const g = jalaliToGregorian(jy, jm, jd);
  return new Date(g.year, g.month - 1, g.day);
}

// ================================================================
// نام‌ها و فرمت‌دهی
// ================================================================
export const JALALI_MONTH_NAMES = [
  "فروردین", "اردیبهشت", "خرداد", "تیر", "مرداد", "شهریور",
  "مهر", "آبان", "آذر", "دی", "بهمن", "اسفند",
] as const;

export const JALALI_WEEKDAY_NAMES = [
  "یکشنبه", "دوشنبه", "سه‌شنبه", "چهارشنبه", "پنجشنبه", "جمعه", "شنبه",
] as const;
// توجه: getDay() جاوااسکریپت یکشنبه=۰...شنبه=۶ برمی‌گرداند، این آرایه هم با همان ترتیب است

const PERSIAN_DIGITS = ["۰", "۱", "۲", "۳", "۴", "۵", "۶", "۷", "۸", "۹"];

/** تبدیل ارقام انگلیسی به فارسی (برای نمایش) */
export function toPersianDigits(input: string | number): string {
  return String(input).replace(/[0-9]/g, (d) => PERSIAN_DIGITS[Number(d)]!);
}

/** تبدیل ارقام فارسی/عربی به انگلیسی (برای پردازش ورودی کاربر) */
export function toEnglishDigits(input: string): string {
  return input
    .replace(/[۰-۹]/g, (d) => String(PERSIAN_DIGITS.indexOf(d)))
    .replace(/[٠-٩]/g, (d) => String(d.charCodeAt(0) - 1632));
}

/** فرمت "۱۵ مرداد ۱۴۰۵" */
export function formatJalali(date: Date | JalaliDate): string {
  const j = date instanceof Date ? dateToJalali(date) : date;
  return `${toPersianDigits(j.day)} ${JALALI_MONTH_NAMES[j.month - 1]} ${toPersianDigits(j.year)}`;
}

/** فرمت عددی "۱۴۰۵/۰۵/۱۵" */
export function formatJalaliNumeric(date: Date | JalaliDate, separator = "/"): string {
  const j = date instanceof Date ? dateToJalali(date) : date;
  const mm = String(j.month).padStart(2, "0");
  const dd = String(j.day).padStart(2, "0");
  return toPersianDigits(`${j.year}${separator}${mm}${separator}${dd}`);
}

/** فرمت با روز هفته: "پنجشنبه، ۱۵ مرداد ۱۴۰۵" */
export function formatJalaliWithWeekday(date: Date): string {
  const weekday = JALALI_WEEKDAY_NAMES[date.getDay()];
  return `${weekday}، ${formatJalali(date)}`;
}

/** فرمت ساعت به فارسی: "۰۸:۳۰" */
export function formatPersianTime(date: Date): string {
  const hh = String(date.getHours()).padStart(2, "0");
  const mm = String(date.getMinutes()).padStart(2, "0");
  return toPersianDigits(`${hh}:${mm}`);
}

// ================================================================
// قوانین زمان‌بندی کارشناسی (باید دقیقاً هماهنگ با اعتبارسنجی سمت
// سرور در core/serializers.py::validate_scheduled_at باشد)
// ================================================================
const WORK_START_HOUR = 8;
const WORK_END_HOUR = 16;
const FRIDAY_JS_DAY = 5; // getDay(): یکشنبه=۰ ... جمعه=۵ ... شنبه=۶

/** آیا این روز، روز کاری است (جمعه تعطیل است) */
export function isWorkingDay(date: Date): boolean {
  return date.getDay() !== FRIDAY_JS_DAY;
}

/**
 * نزدیک‌ترین روز کاری مجاز برای شروع بازه‌ی قابل‌رزرو: حداقل «فردا»،
 * و اگر فردا جمعه بود یک روز دیگر جلو می‌رود (تا شنبه).
 */
export function earliestBookableDate(from: Date = new Date()): Date {
  const next = new Date(from);
  next.setDate(next.getDate() + 1);
  next.setHours(0, 0, 0, 0);
  while (!isWorkingDay(next)) {
    next.setDate(next.getDate() + 1);
  }
  return next;
}

/** ساعت‌های قابل‌انتخاب برای یک روز کاری (۸:۰۰ تا ۱۶:۰۰، هر نیم‌ساعت) */
export function availableTimeSlots(): string[] {
  const slots: string[] = [];
  for (let h = WORK_START_HOUR; h <= WORK_END_HOUR; h += 1) {
    slots.push(`${String(h).padStart(2, "0")}:00`);
    if (h !== WORK_END_HOUR) slots.push(`${String(h).padStart(2, "0")}:30`);
  }
  return slots;
}

/** بررسی معتبر بودن یک تاریخ/ساعت برای رزرو (همان قانون سمت سرور) */
export function isValidBookingSlot(date: Date): { valid: boolean; reason?: string } {
  const now = new Date();
  const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
  const target = new Date(date.getFullYear(), date.getMonth(), date.getDate());

  if (target <= today) {
    return { valid: false, reason: "زمان کارشناسی باید حداقل از فردا به بعد انتخاب شود." };
  }
  if (!isWorkingDay(date)) {
    return { valid: false, reason: "جمعه‌ها جزو بازه کاری نیست، لطفاً روز دیگری انتخاب کنید." };
  }
  const hour = date.getHours();
  const minute = date.getMinutes();
  const withinWindow =
    (hour >= WORK_START_HOUR && hour < WORK_END_HOUR) ||
    (hour === WORK_END_HOUR && minute === 0);
  if (!withinWindow) {
    return { valid: false, reason: "زمان کارشناسی فقط بین ساعت ۸:۰۰ تا ۱۶:۰۰ قابل انتخاب است." };
  }
  return { valid: true };
}

/**
 * lib/nav-config.ts
 * آیتم‌های سایدبار به تفکیک نقش. یک منبع واحد تا اضافه‌کردن مسیر جدید
 * فقط در یک‌جا لازم باشد.
 */
import type { LucideIcon } from "lucide-react";
import {
  LayoutDashboard,
  ClipboardList,
  Users,
  UserCog,
  Wrench,
  Calculator,
  TicketPercent,
  MessagesSquare,
  FileBarChart,
  Bell,
  BellRing,
  Settings,
  ListChecks,
  History,
  UserCircle,
  PlusCircle,
  FileText,
  Wallet,
  Receipt,
  CreditCard,
  ScrollText,
  CalendarDays,
  Building2,
  FolderKanban,
} from "lucide-react";

export interface NavItem {
  title: string;
  href: string;
  icon: LucideIcon;
  badgeKey?: "openTickets" | "unassignedRequests" | "pendingReceipts";
}

export interface NavSection {
  label?: string;
  items: NavItem[];
}

export const ADMIN_NAV: NavSection[] = [
  {
    items: [{ title: "داشبورد", href: "/dashboard/admin", icon: LayoutDashboard }],
  },
  {
    label: "عملیات",
    items: [
      { title: "درخواست‌ها", href: "/dashboard/admin/requests", icon: ClipboardList },
      { title: "مشتریان", href: "/dashboard/admin/customers", icon: Users },
      { title: "کارشناسان", href: "/dashboard/admin/experts", icon: UserCog },
      { title: "تیکت‌ها", href: "/dashboard/admin/tickets", icon: MessagesSquare },
      { title: "پرداخت‌ها", href: "/dashboard/admin/payments", icon: CreditCard, badgeKey: "pendingReceipts" },
      { title: "فاکتورها", href: "/dashboard/admin/invoices", icon: Receipt },
    ],
  },
  {
    label: "پیکربندی",
    items: [
      { title: "تجهیزات", href: "/dashboard/admin/equipment", icon: Wrench },
      { title: "قیمت‌گذاری", href: "/dashboard/admin/pricing", icon: Calculator },
      { title: "کدهای تخفیف", href: "/dashboard/admin/discounts", icon: TicketPercent },
      { title: "قالب‌های چک‌لیست", href: "/dashboard/admin/checklist-templates", icon: ListChecks },
      { title: "اعلان‌ها", href: "/dashboard/admin/notifications", icon: Bell },
      { title: "لاگ اعلان‌ها", href: "/dashboard/admin/notification-logs", icon: BellRing },
      { title: "سازمان‌ها", href: "/dashboard/admin/organizations", icon: Building2 },
      { title: "پروژه‌ها", href: "/dashboard/admin/projects", icon: FolderKanban },
    ],
  },
  {
    label: "گزارش‌گیری",
    items: [
      { title: "گزارش‌های مدیریتی", href: "/dashboard/admin/reports", icon: FileBarChart },
      { title: "لاگ ممیزی", href: "/dashboard/admin/audit-logs", icon: ScrollText },
    ],
  },
  {
    items: [{ title: "تنظیمات", href: "/dashboard/admin/settings", icon: Settings }],
  },
];

export const EXPERT_NAV: NavSection[] = [
  {
    items: [
      { title: "داشبورد", href: "/dashboard/expert", icon: LayoutDashboard },
      { title: "وظایف من", href: "/dashboard/expert/tasks", icon: ListChecks },
      { title: "تقویم برنامه", href: "/dashboard/expert/calendar", icon: CalendarDays },
      { title: "تاریخچه گزارش‌ها", href: "/dashboard/expert/history", icon: History },
      { title: "تیکت‌ها", href: "/dashboard/expert/tickets", icon: MessagesSquare },
      { title: "پروفایل", href: "/dashboard/expert/profile", icon: UserCircle },
    ],
  },
];

export const CUSTOMER_NAV: NavSection[] = [
  {
    items: [
      { title: "داشبورد", href: "/dashboard/customer", icon: LayoutDashboard },
      { title: "رزرو جدید", href: "/booking", icon: PlusCircle },
    ],
  },
  {
    label: "درخواست‌های من",
    items: [
      { title: "درخواست‌ها", href: "/dashboard/customer/requests", icon: ClipboardList },
      { title: "گزارش‌های بازرسی", href: "/dashboard/customer/reports", icon: FileText },
    ],
  },
  {
    label: "مالی",
    items: [
      { title: "اعتبار من", href: "/dashboard/customer/credit", icon: Wallet },
      { title: "فاکتورها", href: "/dashboard/customer/invoices", icon: Receipt },
      { title: "پرداخت‌ها", href: "/dashboard/customer/payments", icon: CreditCard },
    ],
  },
  {
    items: [
      { title: "اعلان‌ها", href: "/dashboard/customer/notifications", icon: Bell },
      { title: "تیکت‌های پشتیبانی", href: "/dashboard/customer/tickets", icon: MessagesSquare },
      { title: "پروفایل", href: "/dashboard/customer/profile", icon: UserCircle },
    ],
  },
];

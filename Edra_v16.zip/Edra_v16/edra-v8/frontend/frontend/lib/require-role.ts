import "server-only";
import { redirect } from "next/navigation";
import { apiServerFetch } from "@/lib/api-server";
import type { User, UserRole } from "@/types/user";
import { getUserRole } from "@/types/user";

export async function requireRole(allowed: UserRole[], loginPath: string): Promise<User> {
  let user: User;
  try {
    user = await apiServerFetch<User>("/api/core/users/me/");
  } catch {
    redirect(loginPath);
  }

  const role = getUserRole(user);
  if (!allowed.includes(role)) {
    redirect(loginPath);
  }

  return user;
}

/**
 * lib/safe-redirect.ts
 *
 * اعتبارسنجی پارامتر next برای جلوگیری از Open Redirect:
 * فقط مسیرهای داخلی (شروع با "/" و نه "//") پذیرفته می‌شوند.
 */
export function safeNextPath(next: string | null): string | null {
  if (!next) return null;
  if (!next.startsWith("/")) return null;
  if (next.startsWith("//")) return null;
  if (next.includes("\\")) return null;
  return next;
}

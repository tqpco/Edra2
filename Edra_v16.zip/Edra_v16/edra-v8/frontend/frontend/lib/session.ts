/**
 * lib/session.ts
 *
 * مدیریت توکن‌های JWT از طریق کوکی httpOnly (نه localStorage) - چون
 * localStorage در معرض دسترسی هر اسکریپتی (از جمله حملات XSS) است، ولی
 * کوکی httpOnly اصلاً از جاوااسکریپت سمت مرورگر قابل خواندن نیست.
 *
 * توکن دسترسی (access) عمر کوتاهی دارد (۳۰ دقیقه، هماهنگ با بک‌اند) و
 * توکن تازه‌سازی (refresh) عمر ۷ روزه دارد.
 */
import "server-only";
import { cookies } from "next/headers";

const ACCESS_COOKIE = "edra_access";
const REFRESH_COOKIE = "edra_refresh";

const isProd = process.env.NODE_ENV === "production";

const baseCookieOptions = {
  httpOnly: true,
  secure: isProd,
  sameSite: "lax" as const,
  path: "/",
};

export async function setSessionTokens(access: string, refresh: string | null) {
  const store = await cookies();
  store.set(ACCESS_COOKIE, access, {
    ...baseCookieOptions,
    maxAge: 30 * 60, // ۳۰ دقیقه - هماهنگ با ACCESS_TOKEN_LIFETIME بک‌اند
  });
  if (refresh) {
    store.set(REFRESH_COOKIE, refresh, {
      ...baseCookieOptions,
      maxAge: 7 * 24 * 60 * 60, // ۷ روز - هماهنگ با REFRESH_TOKEN_LIFETIME بک‌اند
    });
  }
}

export async function setAccessToken(access: string) {
  const store = await cookies();
  store.set(ACCESS_COOKIE, access, {
    ...baseCookieOptions,
    maxAge: 30 * 60,
  });
}

export async function getAccessToken(): Promise<string | undefined> {
  const store = await cookies();
  return store.get(ACCESS_COOKIE)?.value;
}

export async function getRefreshToken(): Promise<string | undefined> {
  const store = await cookies();
  return store.get(REFRESH_COOKIE)?.value;
}

export async function clearSessionTokens() {
  const store = await cookies();
  store.delete(ACCESS_COOKIE);
  store.delete(REFRESH_COOKIE);
}

// ============================================================
// P1 (EDRA v9): refresh single-flight
// چند درخواست همزمان بعد از expiry قبلاً هم‌زمان refresh قدیمی را اجرا
// می‌کردند؛ با rotation یکی موفق و بقیه fail می‌شدند → logout ناخواسته.
// حالا فقط یک refresh اجرا می‌شود و بقیه درخواست‌ها همان نتیجه را
// reuse می‌کنند.
// ============================================================
let refreshInFlight: Promise<string | null> | null = null;

export async function refreshAccessToken(): Promise<string | null> {
  if (refreshInFlight) {
    return refreshInFlight;
  }
  refreshInFlight = (async () => {
    const refresh = await getRefreshToken();
    if (!refresh) return null;
    const API_BASE_URL = process.env.NEXT_PUBLIC_API_URL || "http://localhost:8000";
    try {
      const res = await fetch(`${API_BASE_URL}/api/token/refresh/`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ refresh }),
      });
      if (!res.ok) {
        await clearSessionTokens();
        return null;
      }
      const data = await res.json();
      await setSessionTokens(data.access, data.refresh ?? refresh);
      return data.access as string;
    } catch {
      return null;
    } finally {
      refreshInFlight = null;
    }
  })();
  return refreshInFlight;
}

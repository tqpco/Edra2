/**
 * lib/status-map.test.ts — نگاشت وضعیت درخواست بازرسی (منبع واحد UI).
 * باید با workflow بک‌اند (core/services/inspection_service.py) هماهنگ باشد.
 */
import { describe, expect, it } from "vitest";
import { REQUEST_STATUS_MAP } from "./status-map";

describe("REQUEST_STATUS_MAP", () => {
  it("همه وضعیت‌های workflow بک‌اند پوشش داده شده‌اند", () => {
    const expected = [
      "draft",
      "pending_payment",
      "waiting_manual_payment",
      "paid",
      "assigned",
      "scheduled",
      "rescheduled",
      "in_progress",
      "completed",
      "cancelled",
      "expired",
    ];
    for (const s of expected) {
      expect(REQUEST_STATUS_MAP[s], `missing status: ${s}`).toBeDefined();
    }
  });

  it("هر وضعیت برچسب فارسی دارد", () => {
    for (const [key, info] of Object.entries(REQUEST_STATUS_MAP)) {
      expect(info.label, `label for ${key}`).toBeTruthy();
      expect(info.variant).toBeTruthy();
    }
  });
});

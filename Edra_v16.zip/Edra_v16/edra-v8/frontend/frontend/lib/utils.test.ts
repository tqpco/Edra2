/**
 * lib/utils.test.ts — cn (clsx + tailwind-merge)
 */
import { describe, expect, it } from "vitest";
import { cn } from "./utils";

describe("cn", () => {
  it("کلاس‌های شرطی را ترکیب می‌کند", () => {
    expect(cn("a", false && "b", "c")).toBe("a c");
  });

  it("تعارض tailwind را حل می‌کند (آخرین برد)", () => {
    expect(cn("p-2", "p-4")).toBe("p-4");
  });

  it("undefined/null را نادیده می‌گیرد", () => {
    expect(cn("x", undefined, null, "y")).toBe("x y");
  });
});

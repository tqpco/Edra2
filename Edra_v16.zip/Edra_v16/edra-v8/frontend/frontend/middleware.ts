import { NextRequest, NextResponse } from "next/server";

/**
 * middleware.ts
 * یک بررسی سریع و سبک (بدون تماس شبکه‌ای) که آیا اصلاً کوکی نشستی وجود
 * دارد یا نه؛ اگر نه، مستقیم به صفحه‌ی ورود مناسب هدایت می‌کند. اعتبار
 * دقیق توکن (و تازه‌سازی خودکار در صورت انقضا) در لایه‌ی API انجام
 * می‌شود - این middleware فقط از رندر بی‌فایده‌ی صفحات محافظت‌شده برای
 * کاربر کاملاً مهمان جلوگیری می‌کند.
 */
export function middleware(request: NextRequest) {
  const { pathname } = request.nextUrl;
  const hasSession =
    request.cookies.has("edra_access") || request.cookies.has("edra_refresh");

  if (pathname.startsWith("/dashboard") && !hasSession) {
    const loginPath = pathname.startsWith("/dashboard/customer")
      ? "/customer-login"
      : "/login";
    const url = new URL(loginPath, request.url);
    url.searchParams.set("next", pathname);
    return NextResponse.redirect(url);
  }

  return NextResponse.next();
}

export const config = {
  matcher: ["/dashboard/:path*"],
};

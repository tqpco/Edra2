import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  reactStrictMode: true,
  // EDRA v7 — SEC-04/P2: خروجی standalone → image نهایی فقط runtime
  // لازم را دارد (بدون node_modules کامل)؛ کوچک‌تر و حمله‌پذیری کمتر.
  output: "standalone",
  images: {
    remotePatterns: [
      {
        protocol: "http",
        hostname: "localhost",
      },
      {
        protocol: "https",
        hostname: process.env.NEXT_PUBLIC_API_HOSTNAME || "api.edra-inspect.ir",
      },
    ],
  },
  async rewrites() {
    // در توسعه، درخواست‌های /api/* را به بک‌اند جنگو پراکسی می‌کنیم تا
    // نیازی به تنظیم دستی CORS برای هر درخواست نباشد.
    return [
      {
        source: "/backend/:path*",
        destination: `${process.env.NEXT_PUBLIC_API_URL || "http://localhost:8000"}/:path*`,
      },
    ];
  },
};

export default nextConfig;

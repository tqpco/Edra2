import { defineConfig, devices } from "@playwright/test";

/**
 * E2E (P2 — HIGH-22). اجرا در CI پس از بالا آمدن stack:
 *
 *   docker compose up -d
 *   npx playwright install --with-deps chromium
 *   npm run e2e
 *
 * URL های پیش‌فرض را با محیط واقعی خود تنظیم کنید
 * (BASE_URL / API_BASE_URL).
 */
const BASE_URL = process.env.BASE_URL || "http://localhost:3000";

export default defineConfig({
  testDir: "./e2e",
  timeout: 30_000,
  fullyParallel: true,
  retries: process.env.CI ? 2 : 0,
  reporter: process.env.CI ? "github" : "list",
  use: {
    baseURL: BASE_URL,
    trace: "on-first-retry",
    screenshot: "only-on-failure",
  },
  projects: [{ name: "chromium", use: { ...devices["Desktop Chrome"] } }],
});

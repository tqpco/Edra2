export interface CustomerDashboardData {
  total_requests: number;
  active_requests: number;
  approved_reports: number;
  credit: number;
  user: { id: number | null; username: string; full_name: string };
  recent_requests: {
    id: number;
    request_number: string;
    equipment: string | null;
    status: string;
    final_price: number;
    created_at_jalali: string;
  }[];
  next_inspection: {
    id: number;
    request_number: string;
    scheduled_at_jalali: string;
    address: string;
  } | null;
}

export interface AdminDashboardData {
  totalRequests: number;
  totalPayments: number;
  totalUsers: number;
  totalReports: number;
  pendingRequests: number;
  completedRequests: number;
  revenueThisMonth: number;
  recentActivities: {
    id: number;
    timestamp: string;
    action: string;
    user: string;
  }[];
}

export interface ExpertTask {
  id: number;
  request_number: string;
  equipment: string | null;
  status: string;
  scheduled_at_jalali: string | null;
  address: string;
  city: string;
}

export interface ExpertDashboardData {
  total_assigned: number;
  pending_inspections: number;
  completed_reports: number;
  user: { id: number | null; username: string; full_name: string };
  todays_tasks: ExpertTask[];
  upcoming_tasks: ExpertTask[];
}

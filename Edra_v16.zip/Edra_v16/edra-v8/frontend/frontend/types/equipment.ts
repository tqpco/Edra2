export interface EquipmentParamSchema {
  name: string;
  label: string;
  type: "string" | "number" | "select" | "boolean";
  required: boolean;
  options?: string[];
}

export interface EquipmentType {
  id: number;
  code: string;
  name_fa: string;
  supports_install_state: boolean;
  install_state_required: boolean;
  param_schema: EquipmentParamSchema[] | null;
}

export interface CityMultiplier {
  id: number;
  city: string;
  multiplier: string;
  base_cost: string;
}

export interface PriceCalculateResponse {
  success: boolean;
  equipment: string;
  equipment_id: number;
  params: Record<string, unknown>;
  city: string;
  city_cost: number;
  service_type: "standard" | "pro";
  install_state: string | null;
  total_price: number;
}

/**
 * types/user.test.ts — HIGH-21: قرارداد نقش یکپارچه backend/frontend.
 * کاربر group Admin با is_staff=False باید admin شناخته شود.
 */
import { describe, expect, it } from "vitest";
import { getDashboardPath, getUserRole, type User } from "./user";

function makeUser(partial: Partial<User>): User {
  return {
    id: 1,
    username: "u",
    email: "",
    first_name: "",
    last_name: "",
    full_name: "u",
    is_staff: false,
    is_superuser: false,
    groups: [],
    phone: null,
    date_joined: "",
    date_joined_jalali: "",
    registration_number: null,
    company_name: null,
    projects: [],
    project_names: [],
    ...partial,
  };
}

describe("getUserRole — قرارداد HIGH-21", () => {
  it("از فیلد صریح role backend استفاده می‌کند", () => {
    const user = makeUser({ role: "expert", groups: [] });
    expect(getUserRole(user)).toBe("expert");
  });

  it("گروه Admin بدون is_staff → admin", () => {
    const user = makeUser({ groups: ["Admin"], is_staff: false });
    expect(getUserRole(user)).toBe("admin");
  });

  it("گروه Expert → expert", () => {
    const user = makeUser({ groups: ["Expert"] });
    expect(getUserRole(user)).toBe("expert");
  });

  it("is_staff → admin حتی بدون گروه", () => {
    const user = makeUser({ is_staff: true });
    expect(getUserRole(user)).toBe("admin");
  });

  it("بدون گروه/role → customer", () => {
    expect(getUserRole(makeUser({}))).toBe("customer");
  });

  it("role از گروه‌ها مقدم است (منبع رسمی backend)", () => {
    const user = makeUser({ role: "customer", groups: ["Admin"] });
    expect(getUserRole(user)).toBe("customer");
  });
});

describe("getDashboardPath", () => {
  it("admin → /dashboard/admin", () => {
    expect(getDashboardPath(makeUser({ is_staff: true }))).toBe("/dashboard/admin");
  });

  it("expert → /dashboard/expert", () => {
    expect(getDashboardPath(makeUser({ groups: ["Expert"] }))).toBe("/dashboard/expert");
  });

  it("customer → /dashboard/customer", () => {
    expect(getDashboardPath(makeUser({}))).toBe("/dashboard/customer");
  });

  it("group admin (بدون is_staff) → /dashboard/admin", () => {
    expect(getDashboardPath(makeUser({ groups: ["Admin"] }))).toBe("/dashboard/admin");
  });
});

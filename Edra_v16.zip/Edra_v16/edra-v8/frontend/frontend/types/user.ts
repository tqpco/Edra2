/**
 * types/user.ts
 * باید دقیقاً با خروجی core/serializers.py::UserSerializer هماهنگ باشد.
 */
export type UserRole = "admin" | "expert" | "customer";

export interface User {
  id: number;
  username: string;
  email: string;
  first_name: string;
  last_name: string;
  full_name: string;
  is_staff: boolean;
  is_superuser: boolean;
  groups: string[];
  /**
   * HIGH-21: نقش نهایی که backend به‌صورت صریح برمی‌گرداند
   * (admin = is_staff یا گروه Admin؛ expert = گروه Expert؛ در غیر این صورت customer).
   * فرانت‌اند نباید از چند flag نقش را حدس بزند — این فیلد source of truth است.
   */
  role?: UserRole;
  phone: string | null;
  date_joined: string;
  date_joined_jalali: string;
  registration_number: string | null;
  company_name: string | null;
  projects: number[];
  project_names: string[];
}

export function getUserRole(user: User): UserRole {
  // قرارداد مشترک با backend: اگر role صریح آمده، همان ملاک است.
  if (user.role) return user.role;
  // fallback برای سازگاری با پاسخ‌های قدیمی/کش‌شده
  if (user.is_superuser || user.is_staff) return "admin";
  if (user.groups?.includes("Admin")) return "admin";
  if (user.groups?.includes("Expert")) return "expert";
  return "customer";
}

export function getDashboardPath(user: User): string {
  const role = getUserRole(user);
  if (role === "admin") return "/dashboard/admin";
  if (role === "expert") return "/dashboard/expert";
  return "/dashboard/customer";
}
